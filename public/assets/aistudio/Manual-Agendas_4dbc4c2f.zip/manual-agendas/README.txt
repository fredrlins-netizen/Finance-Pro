MANUAL DA OPÇÃO AGENDAS

Conteúdo:
- manual-agendas.md: relação detalhada das abas, grades, formulários, campos,
  ações, padrões e efeitos das seleções.
- manual-agendas.html: versão de leitura em navegador e impressão.

Escopo:
- Agenda
- Bloquear Agenda
- Fila de Espera
- Serviços
- Configurações da Agenda
- Relação com Cadastros > Cargos, que define a participação dos colaboradores
  no rodízio da agenda

Os valores de cargos sinalizados como padrão são os definidos na inicialização
do sistema. O cadastro real pode ter sido alterado pela empresa.

O conteúdo foi conferido no código atual do projeto. A interface autenticada
não foi aberta nesta verificação; portanto, não se afirma que os dados reais
em produção correspondam aos exemplos padrão.

# Manual da opção Agendas

## Escopo e leitura

Este manual descreve a opção **Agendas** do sistema e as opções que aparecem dentro dela:

1. **Agenda**
2. **Bloquear Agenda**
3. **Fila de Espera**
4. **Serviços**
5. **Configurações**

Inclui também a relação com **Cadastros > Cargos**, porque o cargo define se o colaborador recebe a marca **✓ Fila** e participa da fila/rodízio de agendamento.

Os valores descritos como padrão são os valores de inicialização encontrados no projeto. Os registros da empresa podem ter sido personalizados. Os estados de confirmação e exclusão são os acionamentos que o sistema executa; não significam que um cadastro real tenha sido modificado.

---

## 1. Aba Agenda

### 1.1 Estrutura da tela

A tela principal não é uma tabela de registros. É uma **grade de calendário**:

- **Visão diária:** cada coluna representa uma agenda de colaborador visível; as linhas são os horários.
- **Visão semanal:** cada coluna representa um dia da semana; as linhas são os horários. Os cartões dos compromissos mostram o colaborador responsável.
- **Mini calendário lateral:** dias do mês corrente para pular diretamente a uma data.
- **Painel lateral “Agendas Ativas”:** colaboradores organizados por unidade e, quando aplicável, por grupo.
- **Painel lateral “Fila de Espera”:** resumo dos clientes aguardando, com atalhos para agendar, editar ou remover.

Os horários da grade são construídos com base em **Configurações > Horário Início, Horário Fim e Intervalo de Slot**.

### 1.2 Controles e filtros da grade

| Controle | Valor/estado inicial | O que faz |
|---|---|---|
| Visão | Diário | Alterna entre calendário diário e semanal. |
| Data selecionada | Data atual do sistema | Cabeçalho e grade mostram a data selecionada. |
| Setas anterior/próximo | — | Avançam ou retrocedem um dia; na visão semanal, avançam ou retrocedem uma semana. |
| Hoje | — | Retorna para a data atual. |
| Unidade | Unidade ativa; administradores podem escolher “Todas as Unidades” | Filtra as agendas conforme a unidade permitida. |
| Grupo | “Todos os Grupos” para administrador, quando há grupos configurados | Filtra compromissos por grupo. Para usuário não administrador, o grupo permitido é aplicado automaticamente. |
| Atualizar | — | Solicita atualização dos dados da agenda; quando disponível, mostra a hora da última atualização. |
| Mini calendário | Mês da data selecionada | Selecionar um dia muda a data da grade. Em telas estreitas, também recolhe o painel lateral. |
| Colaborador no painel lateral | Agendas visíveis inicialmente | Clicar no nome alterna a exibição da coluna/agenda. A seleção é de visualização, não altera o cadastro do colaborador. |

#### Botão de seleção de agendas

O código contém o modal **Gerenciar Consultores da Agenda**, mas no estado atual não há um botão/ação que o abra. A descrição abaixo registra os campos e as ações implementadas no modal e assinala que ele não está acessível pela navegação visível.

**Grade do modal**

- **Profissional:** foto (ou inicial), nome e cargo.
- **Exibir:** chave liga/desliga para incluir ou retirar a agenda da grade.
- Rodapé mostra a quantidade de agendas visíveis.

**Ações**

- Ligar/desligar um colaborador altera a visualização da grade.
- **Concluir** ou **X** fecha o modal.
- A seleção é de tela/sessão; não altera a participação no rodízio nem os dados do cadastro.
- A lista do modal parte dos colaboradores cadastrados; já o painel “Agendas Ativas” considera colaboradores ativos e o escopo de unidades permitido ao usuário.
- Como não existe acionador visível no código atual, esse modal não pode ser aberto pela tela normal da Agenda.

### 1.3 Fila de colaboradores e marca “✓ Fila”

No painel **Agendas Ativas**, o cargo do colaborador aparece abaixo do nome.

- O rótulo **✓ Fila** é mostrado quando o cargo tem **Participa da Fila de Agendamento** marcado.
- A fila considera colaboradores ativos com cargo habilitado para agendamento.
- O colaborador indicado como **Próximo** recebe destaque visual.
- O botão de calendário ao lado de um colaborador elegível abre um novo agendamento para aquele colaborador.
- Ao clicar em um horário vazio, o sistema usa o colaborador da coluna. Na visão semanal, quando não há coluna de colaborador, tenta usar o próximo da fila da unidade.
- Depois de criar um novo agendamento para o próximo da fila, a ordem avança automaticamente para o rodízio seguinte. A ordem é mantida por unidade; a interface não oferece um editor manual de posição.
- Colaboradores elegíveis ainda não presentes na ordem salva são incorporados como ausentes da fila. A disponibilidade efetiva pode depender do vínculo de unidade e das permissões do usuário.

**Cargos padrão definidos na inicialização do sistema**

`[x]` indica a opção marcada para o cargo padrão; `[ ]` indica desmarcada. A configuração atual da empresa pode ser diferente.

| Cargo padrão | Participa da fila |
|---|:---:|
| Gerente Comercial | [x] Sim |
| Consultor(a) de Negócios | [ ] Não |
| Analista Jurídico | [ ] Não |
| Atendente | [ ] Não |
| Analista Comercial | [x] Sim |
| Assistente Comercial | [x] Sim |
| Analista Financeiro | [ ] Não |
| Auditora | [ ] Não |

### 1.4 Grade do calendário e cartões de agendamento

**Linhas e colunas**

- A régua à esquerda lista os horários dentro da faixa configurada.
- Na visão diária, as colunas são os colaboradores selecionados.
- Na visão semanal, as colunas são os sete dias da semana.
- Clicar em um espaço vazio abre o formulário **Novo Agendamento**.
- O cartão de agendamento mostra nome do cliente, horário, modalidade (quando definida), telefone e endereço (quando disponíveis) e o primeiro nome do colaborador.
- A cor de fundo usa a cor configurada para o status. A borda lateral usa a cor da modalidade (laranja para presencial, azul para online) ou, sem modalidade, a cor do status.
- Passar o mouse no cartão mostra uma ficha com status, cliente, telefone/endereço disponíveis, data, horário, colaborador, serviço, unidade, modalidade, autoria de criação/alteração e observações.
- Clicar no cartão abre **Editar Agendamento**.
- Arrastar o cartão para outro horário/dia/coluna tenta salvar a mudança, mantendo a duração original. O resultado é confirmado pela mensagem de sucesso ou erro.

**Não há botão de exclusão física do agendamento na grade/modal.** Para registrar cancelamento, edite o compromisso e escolha um dos status de cancelamento.

### 1.5 Modal Novo Agendamento / Editar Agendamento

O mesmo modal serve para criar e editar.

| Campo | Padrão ao criar | Comportamento |
|---|---|---|
| Cliente | Vazio | Busca por nome, documento, telefone, telefone secundário ou e-mail; seleciona um cliente existente. Obrigatório para salvar. |
| Serviço | Vazio | Lista os serviços cadastrados. Obrigatório. Ao selecionar, recalcula o horário final usando a duração do serviço. |
| Data | Data selecionada na grade | Editável. |
| Horário Inicial | Horário da célula clicada; ao agendar pelo atalho do colaborador, próximo intervalo de 30 minutos | Editável. |
| Horário Final | Horário inicial + 30 minutos | Editável. Ao trocar o serviço, é preenchido com a duração cadastrada para o serviço. |
| Unidade | Vazio/definida pelo contexto; o seletor só aparece quando existem várias unidades | Lista unidades. O agendamento recebe também a unidade/grupo associados ao contexto quando disponíveis. |
| Modalidade | Nenhuma selecionada | Botões **Presencial** ou **OnLine**; seleção opcional no formulário. |
| Status | **Agendado** | Opções: Aguardando, Agendado, Confirmado, Cancelado (Cliente), Cancelado (Consultor), Não Compareceu. |
| Observações | Vazio | Texto livre. |

**Importante sobre o colaborador:** não há campo de colaborador editável dentro do modal. Ao abrir um espaço da grade, o profissional vem da coluna/horário ou da fila de rodízio; ao abrir um cartão existente, mantém o profissional daquele agendamento. Para mudar de profissional pela grade, arraste o cartão para outra coluna na visão diária.

**Ações do modal**

- **Salvar Agendamento:** cria ou atualiza o registro. Cliente e serviço precisam estar selecionados.
- **Fechar**, **X** ou atalho de cancelar: fecha sem salvar e limpa o vínculo temporário com uma promoção da fila de espera.
- Ao selecionar **Confirmado** em um agendamento novo ou ainda não confirmado, o sistema tenta enviar WhatsApp ao cliente se ele tiver telefone. O envio é assíncrono; uma notificação informa sucesso ou falha.
- Se o horário escolhido estiver coberto por bloqueio daquele colaborador/data, o sistema impede abrir o agendamento e avisa que o horário está bloqueado.
- Se o agendamento veio da fila de espera, o registro da fila só é removido depois que o agendamento é salvo com sucesso.

### 1.6 Gaveta Filtros da Agenda

É um painel lateral (em telas pequenas, sobe como gaveta inferior), não um formulário de alteração.

**Filtrar por Consultor**

- Lista consultores do escopo visível.
- Selecionar um nome restringe a grade àquele colaborador.
- **Limpar filtro** remove a seleção; clicar novamente no consultor ativo também a desmarca.

**Consultar Agendamentos do Cliente**

- Campo de pesquisa por nome, CPF/CNPJ, telefone ou e-mail.
- A busca começa com pelo menos dois caracteres e apresenta até oito correspondências.
- Ao escolher um cliente, exibe a quantidade e o histórico de agendamentos ordenado com futuros antes dos passados, por data e horário.
- Cada resultado mostra data, horário, consultor, serviço e status. Clicar navega a agenda para a data/horário do registro.
- **Limpar** remove cliente selecionado e texto de busca.
- Esta consulta não altera nem filtra a grade de calendário por cliente; ela lista o histórico no próprio painel.

### 1.7 Ações disponíveis e limites de CRUD

- **Criar:** clique em horário livre ou botão de agendar do colaborador elegível.
- **Consultar:** grade, cartão/tooltip e histórico de cliente pela gaveta.
- **Alterar:** abrir cartão; também pode mover por arrastar e soltar.
- **Excluir:** não há exclusão física nesta tela. Use status de cancelamento quando aplicável.
- Permissões do sistema podem impedir a inclusão/alteração.

---

## 2. Aba Bloquear Agenda

Formulário e grade tabular de bloqueios cadastrados.

### 2.1 Formulário “Bloquear Agenda de Profissional”

| Campo | Padrão | Regra/efeito |
|---|---|---|
| Consultor Responsável | Sem seleção | Obrigatório. Escolhe o colaborador afetado. |
| Bloquear dia inteiro | Marcado | Quando marcado, bloqueia toda a faixa configurada da agenda; oculta os campos de hora. |
| Data Início | Data atual | Primeiro dia do período. |
| Data Fim | Data atual | Último dia do período. |
| Hora Início | 08:00 | Aparece quando “Bloquear dia inteiro” está desmarcado. |
| Hora Fim | 18:00 | Aparece quando “Bloquear dia inteiro” está desmarcado. |
| Repetir nos dias da semana | Domingo a sábado selecionados por padrão | Cada botão alterna o dia da semana. Os índices usados são domingo=0 até sábado=6. |
| Motivo do Bloqueio | Vazio | Obrigatório; é exibido na grade e no detalhe do bloqueio. |

**Adicionar Bloqueio** envia o registro. Consultor e motivo são validados antes de salvar. O formulário não oferece botão para editar um bloqueio já criado.

### 2.2 Data Grid “Lista de Bloqueios Ativos”

Colunas:

1. **Colaborador**
2. **Período** (data início–fim)
3. **Tipo** (dia inteiro ou intervalo de horas)
4. **Motivo**
5. **Ações** (excluir)

**CRUD e acionamentos**

- **Criar:** preenchimento do formulário e botão Adicionar Bloqueio.
- **Consultar:** tabela; o bloqueio também aparece como faixa hachurada na grade de calendário nos dias/horários aplicáveis.
- **Alterar:** não há ação de edição; para corrigir, remova e cadastre novamente.
- **Excluir:** botão de lixeira abre confirmação nativa “Remover este bloqueio?”. Confirmar exclui; cancelar mantém.
- Ao tentar abrir agendamento em horário bloqueado, a criação é interrompida.

### 2.3 Detalhe do bloqueio na grade

Ao passar o mouse pela faixa:

- Identifica **Agenda Bloqueada/Indisponível**.
- Exibe data (na visão semanal), horário ou “Dia Inteiro”, consultor e motivo.
- É somente leitura; a exclusão ocorre pela tabela de bloqueios.

---

## 3. Aba Fila de Espera

Mantém clientes que desejam um horário. É diferente da **fila de colaboradores** (rodízio da Agenda).

### 3.1 Formulário Adicionar/Alterar Registro na Fila

| Campo | Padrão | Regra/efeito |
|---|---|---|
| Cliente | Vazio | Busca por nome, documento, telefone/telefone secundário ou e-mail; seleção de cliente cadastrado. Obrigatório. |
| Serviço Pretendido | Vazio | Serviço cadastrado. Obrigatório. |
| Consultor Preferencial | “Sem preferência (Qualquer um)” | Opcional. Se informado, guarda a preferência do cliente. |
| Data Pretendida | Data atual | Data solicitada. |
| Horário Inicial | 08:00 | Horário solicitado. |
| Observações | Vazio | Texto livre para urgência, restrições ou detalhes. |

**Adicionar à Fila** cria o registro. Em modo de edição, o título vira **Alterar Registro na Fila** e o botão salva alterações. **Cancelar Edição** descarta o modo de edição e limpa os campos de cliente/observação; a data/hora/serviço/preferência permanecem como estavam no estado do formulário.

### 3.2 Data Grid “Clientes Aguardando Horário”

Colunas:

1. **Cliente**
2. **Serviço**
3. **Preferência** de consultor
4. **Data/Hora**
5. **Ações**

Ações por registro:

- **Programar Agendamento:** abre o modal de agendamento preenchido com cliente, serviço, colaborador preferencial (ou primeiro visível), data, hora e observações. O horário final usa a duração do serviço; se o serviço não estiver disponível, usa 30 minutos. O registro só sai da fila após salvar o agendamento.
- **Editar Registro:** carrega o registro no formulário.
- **Remover da Fila:** pede confirmação nativa e remove o cliente da fila.
- **Auditoria:** botão de histórico associado ao registro, quando houver dados de auditoria.

O mesmo conteúdo aparece no resumo lateral da aba Agenda. No cartão lateral, os atalhos para programar, editar e excluir surgem ao passar o mouse.

---

## 4. Aba Serviços

### 4.1 Catálogo

Os serviços aparecem como cartões, não tabela. Cada cartão exibe:

- Nome do serviço.
- Duração em minutos.
- Preço em reais.
- Faixa lateral na cor padrão.
- Auditoria, quando disponível.
- Botão de edição.

**Novo Serviço** abre o formulário inline (não modal).

### 4.2 Formulário Novo/Editar Serviço

| Campo | Padrão ao criar | Regra/efeito |
|---|---|---|
| Nome do Serviço | Vazio | Único campo validado como obrigatório. |
| Duração (min) | 30 | Número; usada para calcular horário final do compromisso quando o serviço é selecionado. |
| Preço (R$) | 0 | Número decimal. |
| Cor Padrão | `#e0e7ff` | Seletor de cor; aplicada à faixa do cartão do serviço. |

**Salvar Serviço** cria/atualiza. **Cancelar** volta ao catálogo sem salvar.

**CRUD disponível:** criar, consultar e editar. O catálogo não apresenta ação de exclusão de serviço.

---

## 5. Aba Configurações

### 5.1 Grade de Horários

| Campo | Padrão | Efeito |
|---|---|---|
| Horário Início | 08:00 | Primeiro horário exibido na régua/grade. |
| Horário Fim | 19:00 | Limite final da faixa de horários. |
| Intervalo de Slot (Grade) | 30 minutos | Passo de horários. Opções: 15, 30 (padrão), 45 e 60 minutos. |

### 5.2 Cadastro de Status & Cores

Cada status tem uma amostra e um seletor de cor:

| Status | Cor padrão |
|---|---|
| Aguardando | `#fbbf24` |
| Agendado | `#3b82f6` |
| Confirmado | `#10b981` |
| Cancelado Pelo Cliente | `#ef4444` |
| Cancelado Pelo Consultor | `#9ca3af` |
| Cliente Não Veio | `#7f1d1d` |

As cores personalizadas identificam os cartões/legendas de status na agenda.

### 5.3 Salvar Configurações

O botão **Salvar Configurações** persiste a faixa/intervalo e as cores dos status. Não há botão de restauração para os valores padrão nesta aba.

---

## 6. Cadastros > Cargos: habilitar a participação na fila

Este cadastro é a origem da marca **✓ Fila** do colaborador na Agenda.

### 6.1 Data Grid de Cargos

| Coluna | Conteúdo/ação |
|---|---|
| Nome | Nome do cargo; cabeçalho alterna ordenação crescente/decrescente/desativada. |
| Fila de Agendamento | Mostra **Sim** (marcado) ou **Não** (desmarcado). |
| Ações | Auditoria; Editar; Duplicar; Excluir, conforme permissões do usuário. |

- Campo **Buscar** filtra pelo nome.
- Paginação inicial: 10 cargos por página; controle de paginação permite navegar e alterar a quantidade por página.
- **Novo Cargo** abre formulário.

### 6.2 Formulário Novo/Editar Cargo

| Campo | Padrão ao criar | Efeito |
|---|---|---|
| Nome do Cargo * | Vazio | Obrigatório. |
| Participa da Fila de Agendamento | **Desmarcado** | Marque para que colaboradores ativos com esse cargo possam aparecer com **✓ Fila** e participar do rodízio. |

**Duplicar** cria um novo cargo com os dados do original, nome inicial “Cópia de [nome]” e mantém o estado marcado/desmarcado do original.

**Salvar** cria ou atualiza. **Cancelar** abandona a edição. **Excluir** pede confirmação; se houver dependências, o sistema pode bloquear a exclusão e apresentar o motivo.

### 6.3 Regra prática da marca

Para colocar um colaborador na fila:

1. Abra **Cadastros > Cargos**.
2. Edite o cargo atribuído ao colaborador ou crie um cargo apropriado.
3. Marque **Participa da Fila de Agendamento** e salve.
4. Confirme que o colaborador está ativo e que sua unidade/grupo está no escopo de acesso.
5. Volte a **Agendas**: o cargo aparece com **✓ Fila** no painel “Agendas Ativas”.

A marca é do **cargo**, não de um colaborador individual. Assim, todos os colaboradores ativos com o mesmo cargo recebem a mesma elegibilidade. Desmarcar a opção retira a elegibilidade desse cargo, sem apagar o colaborador ou seus agendamentos anteriores.

---

## 7. Referência rápida dos padrões

| Tela/campo | Padrão |
|---|---|
| Agenda | Visão diária; data atual |
| Novo agendamento | Status Agendado; início da célula; fim +30 min; modalidade sem seleção; observações vazias |
| Configuração de horário | 08:00–19:00; intervalo de 30 minutos |
| Bloqueio novo | Dia inteiro marcado; início/fim hoje; 08:00–18:00 se parcial; todos os dias da semana marcados; motivo vazio |
| Fila de espera nova | Cliente/serviço sem seleção; consultor sem preferência; data atual; horário 08:00; observações vazias |
| Serviço novo | Nome vazio; 30 min; R$ 0,00; cor `#e0e7ff` |
| Cargo novo | Nome vazio; participação na fila desmarcada |

## 8. Observações de escopo e confirmação

- O manual cobre a opção Agendas, suas cinco abas, os painéis/modais auxiliares e o campo de cargo que controla a elegibilidade da fila.
- A seção de Cargos descreve apenas os elementos necessários para configurar a participação na fila; não é uma documentação completa dos demais cadastros.
- A indicação dos cargos marcados corresponde aos valores padrão definidos no inicializador do sistema. Não é uma leitura ao vivo dos cargos cadastrados pela empresa.
- A documentação foi conferida no código atual do projeto. A interface autenticada e os dados reais não foram verificados visualmente.

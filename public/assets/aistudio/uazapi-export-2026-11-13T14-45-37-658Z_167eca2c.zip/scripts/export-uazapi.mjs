import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUTPUT_DIR = path.join(ROOT, 'generated-artifacts');
const TEXT_EXTENSIONS = new Set([
  '.cjs', '.css', '.html', '.js', '.json', '.md', '.mjs', '.replit',
  '.sh', '.sql', '.toml', '.ts', '.tsx', '.txt', '.yaml', '.yml',
]);
const IGNORED_DIRS = new Set([
  '.agents', '.git', '.local', '.cache', 'artifacts', 'attached_assets',
  'build', 'coverage', 'dist', 'generated-artifacts', 'node_modules',
  'playwright-report', 'test-results', 'tmp', 'uploads',
]);
const EXPLICIT_FILES = [
  '.replit',
  'App.tsx',
  'package.json',
  'schema-contract.json',
  'server/index.js',
  'server/socket.js',
  'server/middleware/rateLimit.js',
  'server/middleware/security.js',
  'server/routes/uazapiAdvanced.js',
  'server/routes/uazapiChats.js',
  'server/routes/uazapiWebhook.js',
  'server/routes/units.js',
  'server/routes/prospection.js',
  'server/routes/gotalk.js',
  'server/routes/whatsappTemplates.js',
  'server/lib/uazapiProxy.js',
  'server/lib/uazapiInstanceCache.js',
  'server/lib/uazapiRecovery.js',
  'server/lib/uazapiWebhookRegistration.js',
  'server/lib/scheduledMessages.js',
  'server/utils/encryption.js',
  'components/settings/tabs/UazapiHistoryTab.tsx',
  'components/settings/tabs/UazapiQrModal.tsx',
  'components/settings/tabs/UnitsTab.tsx',
  'components/settings/tabs/WhatsappTemplatesTab.tsx',
  'components/gotalk/GotalkPhoneModal.tsx',
  'components/gotalk/GotalkSendTemplateModal.tsx',
  'components/conversas/ConversasPanel.tsx',
  'components/cadastros/ClientsPanel.tsx',
  'components/comercial/ProspeccaoWhatsappModal.tsx',
  'components/comercial/ProspeccaoComposer.tsx',
  'components/comercial/ProspeccaoDashboard.tsx',
  'components/comercial/ProspeccaoPanel.tsx',
  'components/financeiro/CollectionOperationalPanel.tsx',
  'components/financeiro/CollectionCoordinatorPanel.tsx',
  'contexts/MessagingContext.tsx',
  'contexts/GotalkContext.tsx',
  'hooks/useWhatsappMutePrefs.ts',
  'services/whatsappService.ts',
  'tests/serverStartupSchema.test.js',
  'tests/visual/fixtures.ts',
  'tests/visual/main-flows.visual.spec.ts',
  'tests/visual/unit-duplication.spec.ts',
  'docs/central-ajuda/mensagens-whatsapp.md',
  'docs/PRD-financepro-assessoria-as-is.md',
  'migrations/027_uazapi_foundation.sql',
  'migrations/028_uazapi_rename_token_column.sql',
  'migrations/029_uazapi_instance_unique.sql',
  'migrations/030_gotalk_messages_unit_id.sql',
  'migrations/031_uazapi_server_url.sql',
  'migrations/033_whatsapp_advanced.sql',
  'migrations/042_prospection_uazapi_unit_id.sql',
  'server/migrations/033_unit_whatsapp_credentials_multi_instance.sql',
];
const RELEVANCE = /uazapi/i;
const CODE_EXTENSIONS = new Set(['.cjs', '.css', '.html', '.js', '.jsx', '.mjs', '.sql', '.ts', '.tsx']);
const SECRET_VALUE_PATTERNS = [
  /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/,
  /\b(?:sk-[A-Za-z0-9_-]{24,}|AIza[A-Za-z0-9_-]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[A-Z0-9]{16})\b/,
  /\bpostgres(?:ql)?:\/\/[^/\s:@]+:[^@\s]+@/i,
];

function toPosixPath(filePath) {
  return filePath.split(path.sep).join('/');
}

function isExcludedPath(relativePath) {
  const normalized = toPosixPath(relativePath);
  const segments = normalized.split('/');
  const basename = segments.at(-1) || '';

  if (segments.some(segment => IGNORED_DIRS.has(segment))) return true;
  if (/^\.env(?:\.|$)/i.test(basename)) return true;
  if (/^\.env(?:\.|$)/i.test(normalized)) return true;
  if (/^\.{1,2}\/?$/.test(normalized)) return true;
  if (/(^|\/)(?:secrets?|credentials?)(?:\/|\.|$)/i.test(normalized)) return true;
  if (/\.(?:pem|key|p12|pfx|jks|keystore|log|zip|gz|pdf|png|jpe?g|webp|gif|mp4|webm)$/i.test(basename)) return true;
  if (/^(?:package-lock|pnpm-lock|yarn\.lock|bun\.lockb?)$/i.test(basename)) return true;
  return false;
}

async function walk(relativeDirectory = '') {
  const absoluteDirectory = path.join(ROOT, relativeDirectory);
  let entries;
  try {
    entries = await fs.readdir(absoluteDirectory, { withFileTypes: true });
  } catch (error) {
    if (error.code === 'ENOENT') return [];
    throw error;
  }

  const found = [];
  for (const entry of entries) {
    const relativePath = path.join(relativeDirectory, entry.name);
    if (isExcludedPath(relativePath)) continue;
    if (entry.isDirectory()) {
      found.push(...await walk(relativePath));
      continue;
    }
    if (entry.isFile()) found.push(relativePath);
  }
  return found;
}

async function readSafeText(relativePath) {
  if (isExcludedPath(relativePath)) return { excluded: 'path_excluded' };
  const extension = path.extname(relativePath).toLowerCase();
  if (!TEXT_EXTENSIONS.has(extension) && path.basename(relativePath) !== '.replit') {
    return { excluded: 'non_text_file' };
  }

  const bytes = await fs.readFile(path.join(ROOT, relativePath));
  if (bytes.includes(0)) return { excluded: 'binary_content' };

  let content;
  try {
    content = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  } catch {
    return { excluded: 'non_utf8_content' };
  }

  if (SECRET_VALUE_PATTERNS.some(pattern => pattern.test(content))) {
    return { excluded: 'possible_secret_value' };
  }
  return { bytes, content };
}

function timestampForFilename(date) {
  return date.toISOString().replace(/[:.]/g, '-');
}

function hasUazapiReference(relativePath, content) {
  if (RELEVANCE.test(relativePath)) return true;
  if (!content) return false;

  let searchable = content;
  const extension = path.extname(relativePath).toLowerCase();
  if (CODE_EXTENSIONS.has(extension)) {
    searchable = searchable
      .replace(/\/\*[\s\S]*?\*\//g, '')
      .replace(/^\s*\/\/.*$/gm, '')
      .replace(/^\s*--.*$/gm, '')
      .replace(/<!--[\s\S]*?-->/g, '');
  }
  return RELEVANCE.test(searchable);
}

async function main() {
  const candidates = new Set(EXPLICIT_FILES);
  for (const relativePath of await walk()) {
    const normalized = toPosixPath(relativePath);
    if (isExcludedPath(normalized)) continue;
    if (!TEXT_EXTENSIONS.has(path.extname(normalized).toLowerCase())) continue;

    const { content } = await readSafeText(normalized);
    if (hasUazapiReference(normalized, content)) {
      candidates.add(normalized);
    }
  }

  const entries = [];
  const excluded = [];
  const digestOwner = new Map();
  const zip = new JSZip();

  for (const candidate of [...candidates].sort()) {
    const normalized = toPosixPath(candidate);
    const safe = await readSafeText(normalized);
    if (safe.excluded) {
      excluded.push({ path: normalized, reason: safe.excluded });
      continue;
    }

    const digest = crypto.createHash('sha256').update(safe.bytes).digest('hex');
    const firstPath = digestOwner.get(digest);
    if (!firstPath) digestOwner.set(digest, normalized);

    zip.file(normalized, safe.bytes, { date: new Date(0) });
    entries.push({
      path: normalized,
      sizeBytes: safe.bytes.length,
      sha256: digest,
      ...(firstPath ? { duplicateContentOf: firstPath } : {}),
    });
  }

  if (entries.length === 0) {
    throw new Error('Nenhum arquivo uazapi elegível foi encontrado para exportação.');
  }

  const generatedAt = new Date();
  const manifest = {
    format: 'financepro-uazapi-source-export',
    version: 1,
    generatedAt: generatedAt.toISOString(),
    includedFileCount: entries.length,
    files: entries,
    excludedFiles: excluded,
    exclusions: [
      'Secrets, credenciais e arquivos .env (inclusive exemplos)',
      'Dados de clientes, uploads, logs e arquivos binários',
      'Dependências instaladas, builds, artefatos e diretórios temporários',
    ],
    notes: [
      'Os caminhos dentro do ZIP preservam a localização relativa no projeto original.',
      'Arquivos com referências uazapi são descobertos automaticamente e somados à lista central de arquivos.',
      'Arquivos idênticos recebem duplicateContentOf para destacar cópias sem removê-las.',
      'Arquivos compartilhados com o GoTalk são incluídos quando participam de fluxos combinados ou históricos unificados.',
    ],
  };

  zip.file('README-EXPORT.txt', [
    'Exportação de código-fonte relacionado à uazapi',
    '',
    `Gerado em: ${manifest.generatedAt}`,
    `Arquivos incluídos: ${entries.length}`,
    '',
    'O manifesto manifest.json lista caminhos originais, tamanho e SHA-256.',
    'As cópias idênticas permanecem no pacote e são indicadas no manifesto.',
    'Secrets, arquivos .env, dados de clientes, uploads, binários, dependências',
    'instaladas e builds não fazem parte desta exportação.',
    '',
  ].join('\n'));
  zip.file('manifest.json', JSON.stringify(manifest, null, 2));

  await fs.mkdir(OUTPUT_DIR, { recursive: true });
  const outputPath = path.join(OUTPUT_DIR, `uazapi-export-${timestampForFilename(generatedAt)}.zip`);
  const archive = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
  await fs.writeFile(outputPath, archive, { flag: 'wx' });

  console.log(`Exportação uazapi criada: ${toPosixPath(path.relative(ROOT, outputPath))}`);
  console.log(`Arquivos-fonte incluídos: ${entries.length}`);
  console.log(`Arquivos candidatos excluídos: ${excluded.length}`);
  console.log(`Tamanho do ZIP: ${archive.length} bytes`);
}

main().catch(error => {
  console.error(`[export:uazapi] ${error.message}`);
  process.exitCode = 1;
});

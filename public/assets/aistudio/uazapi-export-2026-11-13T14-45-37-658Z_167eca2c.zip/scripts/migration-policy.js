import fs from 'fs';
import path from 'path';

export const LEGACY_MIGRATIONS = new Set([
  '001_initial_schema.sql',
  '002_add_unitid_to_appointments.sql',
  '003_financial_relationships.sql',
  '004_report_builder.sql',
  '005_legal_processes.sql',
  '005a_prepare_database_hardening.sql',
  '006_database_hardening.sql',
  '007_integrity_fixes.sql',
  '008_admissions_unit_origin.sql',
  '009_admissions_tipo_cliente.sql',
  '010_admissions_titular_client.sql',
  '011_add_fatura_gerada_status.sql',
  '012_gotalk_integration.sql',
  '013_gotalk_ack_status.sql',
  '014_normalize_phones.sql',
  '015_gotalk_operators_attendances.sql',
  '016_gotalk_channels.sql',
  '017_bank_services_modality.sql',
  '018_gotalk_msg_imutavel.sql',
  '019_performance_indexes.sql',
  '020_gotalk_messages_archive.sql',
  '021_missing_indexes.sql',
  '022_rbac_admission_read.sql',
  '023_drop_duplicate_indexes.sql',
  '024_bank_contacts.sql',
  '025_mfa_totp.sql',
  '026_taxa_minima_decimal.sql',
  '027_uazapi_foundation.sql',
  '028_uazapi_rename_token_column.sql',
  '029_uazapi_instance_unique.sql',
  '030_gotalk_messages_unit_id.sql',
  '031_uazapi_server_url.sql',
  '032_admission_addendums.sql',
  '033_whatsapp_advanced.sql',
  '034_prospection.sql',
  '034a_prepare_prospection_backfill.sql',
  '035_backfill_prospection_contacts.sql',
  '036_prospection_notes.sql',
  '037_prospection_notes_drop_user_fk.sql',
  '038_prospection_instance_id.sql',
  '039_prospection_last_source.sql',
  '040_leo_knowledge_articles.sql',
  '041_app_user_restricted_role.sql',
  '042_prospection_uazapi_unit_id.sql',
  '043_prospection_sync_trigger.sql',
  '044_febraban_banks.sql',
  '045_immutable_messages.sql',
  '046_fix_immutable_messages_trigger.sql',
  '047_user_session_version.sql',
  '048_client_attachments.sql',
  '049_client_attachment_batch_idempotency.sql',
  '050_client_attachment_text_target_id.sql',
  '051_startup_schema.sql',
  '052_backfill_audit.sql',
]);

const CLASSIFICATION = /^\s*--\s*Type:\s*SCHEMA\s*$/im;
const DATA_WRITES = new Set([
  'INSERT',
  'UPDATE',
  'DELETE',
  'MERGE',
  'TRUNCATE',
  'COPY',
  'EXECUTE',
]);
const PROCEDURAL_BOUNDARIES = new Set([';', 'BEGIN', 'THEN', 'ELSE', 'LOOP']);
const ROUTINE_CALL_BOUNDARIES = new Set([';', 'BEGIN', 'THEN', 'ELSE', 'LOOP']);
const NON_ROUTINE_PAREN_TOKENS = new Set([
  'AND',
  'CASE',
  'ELSE',
  'EXISTS',
  'HAVING',
  'IF',
  'IN',
  'LOOP',
  'NOT',
  'ON',
  'OR',
  'SELECT',
  'THEN',
  'WHEN',
  'WHERE',
  'WHILE',
]);

function splitStatements(sql) {
  const statements = [];
  let start = 0;
  let quote = null;
  let dollarTag = null;
  let lineComment = false;
  let blockComment = false;

  for (let i = 0; i < sql.length; i++) {
    const char = sql[i];
    const next = sql[i + 1];

    if (lineComment) {
      if (char === '\n') lineComment = false;
      continue;
    }
    if (blockComment) {
      if (char === '*' && next === '/') {
        blockComment = false;
        i++;
      }
      continue;
    }
    if (dollarTag) {
      if (sql.startsWith(dollarTag, i)) {
        i += dollarTag.length - 1;
        dollarTag = null;
      }
      continue;
    }
    if (quote) {
      if (char === quote && next === quote) {
        i++;
      } else if (char === quote) {
        quote = null;
      }
      continue;
    }
    if (char === '-' && next === '-') {
      lineComment = true;
      i++;
      continue;
    }
    if (char === '/' && next === '*') {
      blockComment = true;
      i++;
      continue;
    }
    if (char === "'" || char === '"') {
      quote = char;
      continue;
    }
    if (char === '$') {
      const match = sql.slice(i).match(/^\$[A-Za-z_][A-Za-z0-9_]*\$|^\$\$/);
      if (match) {
        dollarTag = match[0];
        i += dollarTag.length - 1;
        continue;
      }
    }
    if (char === ';') {
      statements.push(sql.slice(start, i + 1));
      start = i + 1;
    }
  }
  if (sql.slice(start).trim()) statements.push(sql.slice(start));
  return statements;
}

function tokenize(sql, includeDollarBodies = true) {
  const tokens = [];
  let i = 0;
  while (i < sql.length) {
    if (sql.startsWith('--', i)) {
      i = sql.indexOf('\n', i + 2);
      if (i === -1) break;
      continue;
    }
    if (sql.startsWith('/*', i)) {
      const end = sql.indexOf('*/', i + 2);
      i = end === -1 ? sql.length : end + 2;
      continue;
    }
    if (sql[i] === "'" || sql[i] === '"') {
      const quote = sql[i++];
      let quotedIdentifier = '';
      while (i < sql.length) {
        if (sql[i] === quote && sql[i + 1] === quote) {
          if (quote === '"') quotedIdentifier += '"';
          i += 2;
        } else if (sql[i] === quote) {
          i++;
          break;
        } else {
          if (quote === '"') quotedIdentifier += sql[i];
          i++;
        }
      }
      if (quote === '"' && quotedIdentifier) tokens.push(quotedIdentifier.toUpperCase());
      continue;
    }
    if (sql[i] === '$') {
      const match = sql.slice(i).match(/^\$[A-Za-z_][A-Za-z0-9_]*\$|^\$\$/);
      if (match) {
        const tag = match[0];
        const bodyStart = i + tag.length;
        const bodyEnd = sql.indexOf(tag, bodyStart);
        if (bodyEnd === -1) break;
        if (includeDollarBodies) tokens.push(...tokenize(sql.slice(bodyStart, bodyEnd)));
        i = bodyEnd + tag.length;
        continue;
      }
    }
    const word = sql.slice(i).match(/^[A-Za-z_][A-Za-z0-9_$]*/);
    if (word) {
      tokens.push(word[0].toUpperCase());
      i += word[0].length;
    } else if (sql.startsWith(':=', i)) {
      tokens.push(':=');
      i += 2;
    } else if (sql[i] === ';' || sql[i] === '(') {
      tokens.push(sql[i]);
      i++;
    } else {
      i++;
    }
  }
  return tokens;
}

function isAllowedRoutineOrTrigger(tokens) {
  let index = 0;
  if (tokens[index++] !== 'CREATE') return false;
  if (tokens[index] === 'OR' && tokens[index + 1] === 'REPLACE') index += 2;
  return ['FUNCTION', 'PROCEDURE', 'TRIGGER'].includes(tokens[index]);
}

function explainExecutesStatement(tokens) {
  for (let i = 1; i < tokens.length; i++) {
    if (tokens[i] !== 'ANALYZE') continue;
    return !['FALSE', 'OFF', 'NO'].includes(tokens[i + 1]);
  }
  return false;
}

function findDataWrite(statement) {
  const headerTokens = tokenize(statement, false);
  if (isAllowedRoutineOrTrigger(headerTokens)) return null;

  const tokens = tokenize(statement);
  if (DATA_WRITES.has(tokens[0])) return tokens[0];

  if (tokens[0] === 'EXPLAIN' && explainExecutesStatement(tokens)) {
    return tokens.find(token => DATA_WRITES.has(token)) || null;
  }

  if (tokens[0] === 'WITH') {
    return tokens.find(token => DATA_WRITES.has(token)) || null;
  }

  for (let i = 1; i < tokens.length; i++) {
    if (DATA_WRITES.has(tokens[i]) && PROCEDURAL_BOUNDARIES.has(tokens[i - 1])) {
      return tokens[i];
    }
    if (tokens[i] === 'WITH' && PROCEDURAL_BOUNDARIES.has(tokens[i - 1])) {
      return tokens.slice(i + 1).find(token => DATA_WRITES.has(token)) || null;
    }
  }
  return null;
}

function findRoutineCall(statement) {
  const headerTokens = tokenize(statement, false);
  if (isAllowedRoutineOrTrigger(headerTokens)) return null;

  const tokens = tokenize(statement);
  for (let i = 0; i < tokens.length; i++) {
    const atStatementBoundary = i === 0 || ROUTINE_CALL_BOUNDARIES.has(tokens[i - 1]);
    if (tokens[i] === 'CALL' && atStatementBoundary) return 'CALL';
  }

  if (tokens[0] === 'EXPLAIN' && !explainExecutesStatement(tokens)) return null;

  const isExecutableQuery = ['SELECT', 'WITH'].includes(tokens[0])
    || (tokens[0] === 'EXPLAIN' && explainExecutesStatement(tokens));
  const isAnonymousBlock = tokens[0] === 'DO';
  if (!isExecutableQuery && !isAnonymousBlock) return null;

  for (let i = 0; i < tokens.length - 1; i++) {
    if (tokens[i + 1] !== '(' || NON_ROUTINE_PAREN_TOKENS.has(tokens[i])) continue;
    if (isExecutableQuery) return 'SELECT com chamada de função';

    const precedingTokens = tokens.slice(0, i);
    if (precedingTokens.includes('PERFORM')) return 'PERFORM com chamada de função';
    const precededByExecution = precedingTokens.some((token, index) =>
      token === ':='
      || (token === 'SELECT' && (index === 0 || ROUTINE_CALL_BOUNDARIES.has(precedingTokens[index - 1])))
    );
    if (precededByExecution) return 'expressão procedural com chamada de função';
  }
  return null;
}

export function validateMigration(filename, sql) {
  if (LEGACY_MIGRATIONS.has(filename)) return [];

  const errors = [];
  if (!CLASSIFICATION.test(sql)) {
    errors.push('classificação obrigatória ausente; adicione uma linha exatamente como "-- Type: SCHEMA"');
  }

  for (const statement of splitStatements(sql)) {
    const operation = findDataWrite(statement);
    if (operation) {
      errors.push(`${operation} de dados não é permitido em migrations de schema`);
    }
    const routineCall = findRoutineCall(statement);
    if (routineCall) {
      errors.push(`${routineCall} não é permitido em migrations de schema; rotinas podem alterar dados indiretamente, mova a transformação para backfills/`);
    }
  }
  return errors;
}

export function validateMigrationDirectory(migrationsDir) {
  const failures = [];
  const files = fs.readdirSync(migrationsDir).filter(file => file.endsWith('.sql')).sort();
  for (const filename of files) {
    const sql = fs.readFileSync(path.join(migrationsDir, filename), 'utf8');
    const errors = validateMigration(filename, sql);
    if (errors.length) failures.push({ filename, errors });
  }
  return failures;
}

export function formatMigrationPolicyFailures(failures) {
  const details = failures.flatMap(({ filename, errors }) =>
    errors.map(error => `  - migrations/${filename}: ${error}`)
  );
  return [
    '[Migration Policy] Validação falhou:',
    ...details,
    '',
    'Migrations novas devem conter apenas schema e declarar "-- Type: SCHEMA".',
    'Mova INSERT, UPDATE, DELETE, MERGE, TRUNCATE, COPY, EXECUTE, CALL e chamadas de funções executadas via SELECT/PERFORM para backfills/.',
    'Consulte backfills/README.md e copie backfills/_template.js.',
  ].join('\n');
}
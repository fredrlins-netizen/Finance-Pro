// Offline query builder only: deliberately has no database client or write mode.
// Run the resulting SELECT through the database skill with an explicit environment.
import { pathToFileURL } from 'node:url';

export const UUID_PATTERN = '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
export const PARENT_KEYS = {
  clients: ['name'],
  service_items: ['name'],
  companies: ['razao_social', 'nome_fantasia'],
  collaborators: ['name'],
  bank_accounts: ['description'],
  chart_of_accounts: ['code', 'name'],
  document_types: ['description'],
  bearers: ['code', 'name'],
  departments: ['code', 'name'],
  financial_titles: ['document_number', 'description'],
  banks: ['febraban_code', 'name'],
  users: ['name'],
  messages: [],
  gotalk_contacts: [],
  gotalk_attendances: [],
};

export const RELATIONS = [
  ['appointments', 'client_id', 'clients'],
  ['appointments', 'service_id', 'service_items'],
  ['appointments', 'unit_id', 'companies'],
  ['admissions', 'unit_id', 'companies'],
  ['commercial_deals', 'collaborator_id', 'collaborators'],
  ...['bank_account_id', 'category_id', 'document_type_id', 'bearer_id', 'department_id', 'title_id']
    .map((field, i) => ['bank_movements', field,
      ['bank_accounts', 'chart_of_accounts', 'document_types', 'bearers', 'departments', 'financial_titles'][i]]),
  ['collection_notes', 'collaborator_id', 'collaborators'],
  ['negotiation_records', 'bank_id', 'banks'],
  ...['negotiation_records', 'negotiation_contacts', 'negotiation_proposals', 'negotiation_goals']
    .map(table => [table, 'collaborator_id', 'collaborators']),
  ['messages', 'sender_id', 'users'],
  ['message_reads', 'message_id', 'messages'],
  ['message_reads', 'user_id', 'users'],
  ['message_deliveries', 'message_id', 'messages'],
  ['message_deliveries', 'user_id', 'users'],
  ['contract_attachment_operations', 'unit_id', 'companies'],
  ['contract_attachment_upload_sessions', 'unit_id', 'companies'],
  ['audit_logs', 'user_id', 'users', 'historico'],
  ['audit_logs', 'unit_id', 'companies', 'historico'],
  ['gotalk_messages_archive', 'gotalk_contact_id', 'gotalk_contacts', 'historico'],
  ['gotalk_messages_archive', 'attendance_id', 'gotalk_attendances', 'historico'],
];

const identifier = value => {
  if (!/^[a-z_][a-z0-9_]*$/.test(value)) throw new Error('Identificador não permitido');
  return `"${value}"`;
};

export function exclusionCategory(table, field) {
  const relation = `${table}.${field}`;
  if (['bank_movements.cost_center_id', 'gotalk_messages_archive.operator_id'].includes(relation)) {
    return 'sem_destino_confirmado';
  }
  if (['appointments.group_id', 'bank_movements.transfer_id'].includes(relation)) return 'agrupamento';
  if (['audit_logs.entity_id', 'audit_unit_backfill_unclassified.entity_id',
    'messages.recipient_id', 'client_attachments.target_id'].includes(relation)) return 'polimorfico';
  if (table.startsWith('data_backfill_') || relation === 'homologation_runs.run_id') return 'identificador_tecnico';
  if (relation === 'client_attachment_contract_folder_acl.bucket_id') return 'armazenamento_externo';
  if (table.startsWith('gotalk_') || table.startsWith('uazapi_')
    || field.includes('uazapi') || field === 'last_inbound_instance_id'
    || table === 'unit_whatsapp_credentials' || table === 'clients'
    || table.startsWith('whatsapp_')) return 'integracao_externa';
  // New/unmapped columns must be visible as unresolved, never silently ignored.
  return 'sem_destino_confirmado';
}

export function inventoryColumns(contract) {
  const baseTables = new Set(contract.tables.filter(t => t.schema === 'public'
    && ['r', 'p'].includes(t.kind)).map(t => t.name));
  return contract.columns.filter(c => c.schema === 'public' && baseTables.has(c.table)
    && /^(text|character varying)/.test(c.type) && c.name.endsWith('_id')
    && !c.name.startsWith('_reference_')
    && !RELATIONS.some(([t, f]) => t === c.table && f === c.name)
    && !contract.constraints.some(k => k.schema === 'public' && k.table === c.table
      && k.type === 'FOREIGN KEY' && k.definition.startsWith(`FOREIGN KEY (${c.name})`)));
}

export function buildInventoryQuery(contract) {
  const selects = inventoryColumns(contract).map(({ table, name: field }) => {
    identifier(table);
    identifier(field);
    return `SELECT '${table}.${field}' AS relation,
      '${exclusionCategory(table, field)}' AS category,
      count(*) AS total,
      count(*) FILTER (WHERE ${identifier(field)} IS NULL) AS nulo,
      count(*) FILTER (WHERE ${identifier(field)} IS NOT NULL AND btrim(${identifier(field)}::text) = '') AS vazio,
      count(*) FILTER (WHERE btrim(${identifier(field)}::text) <> '') AS preenchido
      FROM public.${identifier(table)}`;
  });
  if (!selects.length) throw new Error('Inventário vazio; conferir contrato');
  return `SELECT jsonb_agg(to_jsonb(r) ORDER BY relation) AS inventory FROM (${selects.join('\nUNION ALL\n')}) r`;
}

export function relationSelect(relation) {
  // Only code-owned relations can become SQL identifiers or literals.
  const spec = RELATIONS.find(row => row[0] === relation[0] && row[1] === relation[1]);
  if (!spec) throw new Error('Relação não permitida');
  const [table, field, parent, context = 'operacional'] = spec;
  const keys = PARENT_KEYS[parent];
  const idEquality = parent === 'messages'
    ? 'p.id::text = s.raw'
    : 'p.id::text = lower(s.raw)';
  const keyQuery = keys.length ? `
    SELECT key, count(DISTINCT parent_id) AS candidates
    FROM (
      ${keys.map(key => `SELECT lower(btrim(${identifier(key)}::text)) AS key, id::text AS parent_id FROM public.${identifier(parent)}`).join('\nUNION ALL\n')}
    ) k WHERE key IS NOT NULL AND key <> '' GROUP BY key`
    : 'SELECT NULL::text AS key, 0::bigint AS candidates WHERE false';
  return `
    SELECT '${table}.${field}' AS relation, '${parent}' AS parent, '${context}' AS context,
      count(*) AS total,
      count(*) FILTER (WHERE raw IS NULL) AS nulo,
      count(*) FILTER (WHERE raw IS NOT NULL AND btrim(raw) = '') AS vazio,
      count(*) FILTER (WHERE category = 'id_valido') AS id_valido,
      count(*) FILTER (WHERE category = 'uuid_orfao') AS uuid_orfao,
      count(*) FILTER (WHERE category = 'uuid_com_espacos') AS uuid_com_espacos,
      count(*) FILTER (WHERE category = 'texto_candidato_unico') AS texto_candidato_unico,
      count(*) FILTER (WHERE category = 'texto_ambiguo') AS texto_ambiguo,
      count(*) FILTER (WHERE category = 'texto_sem_candidato') AS texto_sem_candidato,
      count(*) FILTER (WHERE category = 'id_valido' AND raw ~* '${UUID_PATTERN}'
        AND raw <> lower(raw)) AS uuid_maiusculo
    FROM (
      SELECT s.raw, CASE
        WHEN s.raw IS NULL OR btrim(s.raw) = '' THEN 'ausente'
        WHEN p.id IS NOT NULL THEN 'id_valido'
        WHEN s.raw ~* '${UUID_PATTERN}' THEN 'uuid_orfao'
        WHEN btrim(s.raw) ~* '${UUID_PATTERN}' THEN 'uuid_com_espacos'
        WHEN k.candidates = 1 THEN 'texto_candidato_unico'
        WHEN k.candidates > 1 THEN 'texto_ambiguo'
        ELSE 'texto_sem_candidato'
      END AS category
      FROM (SELECT ${identifier(field)}::text AS raw FROM public.${identifier(table)}) s
      LEFT JOIN public.${identifier(parent)} p ON ${idEquality}
      LEFT JOIN (${keyQuery}) k ON k.key = lower(btrim(s.raw))
    ) classified`;
}

export function buildAuditQuery() {
  return `SELECT jsonb_build_object(
    'captured_at', statement_timestamp(),
    'database', current_database(),
    'relations', (SELECT jsonb_agg(to_jsonb(r) ORDER BY relation) FROM (
      ${RELATIONS.map(relationSelect).join('\nUNION ALL\n')}
    ) r)
  ) AS audit`;
}

if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  console.log(buildAuditQuery());
}

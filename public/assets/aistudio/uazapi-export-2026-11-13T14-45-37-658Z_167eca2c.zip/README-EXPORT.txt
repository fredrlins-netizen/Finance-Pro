Exportação de código-fonte relacionado à uazapi

Gerado em: 2026-11-13T14:45:37.658Z
Arquivos incluídos: 68

O manifesto manifest.json lista caminhos originais, tamanho e SHA-256.
As cópias idênticas permanecem no pacote e são indicadas no manifesto.
Secrets, arquivos .env, dados de clientes, uploads, binários, dependências
instaladas e builds não fazem parte desta exportação.

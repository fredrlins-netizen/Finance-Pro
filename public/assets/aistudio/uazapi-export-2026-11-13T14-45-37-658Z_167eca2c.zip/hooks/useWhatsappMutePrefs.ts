/**
 * Shared singleton store for WhatsApp toast mute preferences.
 *
 * All component instances share the same in-memory state via useSyncExternalStore,
 * so toggling mute from NotificationBell is immediately visible to GotalkContext
 * and vice-versa — no context provider or prop drilling needed.
 *
 * Persistence: localStorage key 'wa_toast_mute'.
 */

import { useSyncExternalStore, useCallback } from 'react';

const STORAGE_KEY = 'wa_toast_mute';

interface MutePrefs {
  globalMuted: boolean;
  mutedConversations: string[];
}

// ── Singleton store ───────────────────────────────────────────────────────────

let store: MutePrefs = loadFromStorage();

const listeners = new Set<() => void>();

function loadFromStorage(): MutePrefs {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        globalMuted: Boolean(parsed.globalMuted),
        mutedConversations: Array.isArray(parsed.mutedConversations) ? parsed.mutedConversations : [],
      };
    }
  } catch {}
  return { globalMuted: false, mutedConversations: [] };
}

function saveToStorage(prefs: MutePrefs): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(prefs));
  } catch {}
}

function notify(): void {
  listeners.forEach(l => l());
}

function setStore(updater: (prev: MutePrefs) => MutePrefs): void {
  const next = updater(store);
  store = next;
  saveToStorage(next);
  notify();
}

function getSnapshot(): MutePrefs {
  return store;
}

function subscribe(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

// ── Hook ─────────────────────────────────────────────────────────────────────

export interface WhatsappMutePrefs {
  globalMuted: boolean;
  mutedConversations: string[];
  muteGlobal: () => void;
  unmuteGlobal: () => void;
  muteConversation: (conversationId: string) => void;
  unmuteConversation: (conversationId: string) => void;
  isMuted: (conversationId?: string) => boolean;
}

export function useWhatsappMutePrefs(): WhatsappMutePrefs {
  const prefs = useSyncExternalStore(subscribe, getSnapshot);

  const muteGlobal = useCallback(() => {
    setStore(p => ({ ...p, globalMuted: true }));
  }, []);

  const unmuteGlobal = useCallback(() => {
    setStore(p => ({ ...p, globalMuted: false }));
  }, []);

  const muteConversation = useCallback((conversationId: string) => {
    setStore(p => ({
      ...p,
      mutedConversations: p.mutedConversations.includes(conversationId)
        ? p.mutedConversations
        : [...p.mutedConversations, conversationId],
    }));
  }, []);

  const unmuteConversation = useCallback((conversationId: string) => {
    setStore(p => ({
      ...p,
      mutedConversations: p.mutedConversations.filter(id => id !== conversationId),
    }));
  }, []);

  const isMuted = useCallback((conversationId?: string): boolean => {
    if (prefs.globalMuted) return true;
    if (conversationId && prefs.mutedConversations.includes(conversationId)) return true;
    return false;
  }, [prefs]);

  return {
    globalMuted: prefs.globalMuted,
    mutedConversations: prefs.mutedConversations,
    muteGlobal,
    unmuteGlobal,
    muteConversation,
    unmuteConversation,
    isMuted,
  };
}

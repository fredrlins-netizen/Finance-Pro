import React, { createContext, useContext, useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { Message, Conversation, User, PortalConfig } from '../types';
import MessageToast, { MessageToastItem } from '../components/ui/MessageToast';
import { useSocket } from './SocketContext';

interface SendMessagePayload {
    recipientType: 'USER' | 'GROUP' | 'ALL';
    recipientId: string;
    subject?: string;
    body: string;
    attachments?: { name: string; type: string; size: number; data: string }[];
    isSystem?: boolean;
    metadata?: Record<string, any>;
}

interface MessagingContextType {
    messages: Message[];
    conversations: Conversation[];
    unreadCount: number;
    gotalkUnreadCount: number;
    prospeccaoUnreadCount: number;
    isLoading: boolean;
    onlineUserIds: string[];
    sendMessage: (payload: SendMessagePayload) => Promise<void>;
    markAsRead: (messageId: string) => Promise<void>;
    markAllAsRead: () => Promise<void>;
    clearGotalkUnread: () => Promise<void>;
    markGotalkConversationRead: (phone: string, contactId?: string | null) => Promise<void>;
    incProspeccaoUnread: (n?: number) => void;
    decProspeccaoUnread: (n: number) => void;
    clearProspeccaoUnread: () => void;
    loadMore: (before: string) => Promise<void>;
    hasMore: boolean;
    navigateToConversation: (convId: string) => void;
    pendingNavConvId: string | null;
    clearPendingNav: () => void;
}

const MessagingContext = createContext<MessagingContextType>({
    messages: [],
    conversations: [],
    unreadCount: 0,
    gotalkUnreadCount: 0,
    prospeccaoUnreadCount: 0,
    isLoading: false,
    onlineUserIds: [],
    sendMessage: async () => {},
    markAsRead: async () => {},
    markAllAsRead: async () => {},
    clearGotalkUnread: async () => {},
    markGotalkConversationRead: async () => {},
    incProspeccaoUnread: () => {},
    decProspeccaoUnread: () => {},
    clearProspeccaoUnread: () => {},
    loadMore: async () => {},
    hasMore: false,
    navigateToConversation: () => {},
    pendingNavConvId: null,
    clearPendingNav: () => {},
});

export const useMessaging = () => useContext(MessagingContext);

interface Props {
    currentUser: User | null;
    config: PortalConfig;
    children: React.ReactNode;
}

function getInitials(name: string): string {
    return name.split(' ').map(p => p[0]).join('').toUpperCase().substring(0, 2);
}

function buildConversations(messages: Message[], currentUserId: string, config: PortalConfig): Conversation[] {
    const convMap = new Map<string, Conversation>();

    const systemConvId = '__sistema__';
    convMap.set(systemConvId, {
        id: systemConvId,
        name: 'Sistema Invicta',
        type: 'SYSTEM',
        unreadCount: 0,
        avatarInitials: '⚙',
        channelLabel: 'Sistema',
    });

    for (const msg of messages) {
        if (msg.is_system) {
            const conv = convMap.get(systemConvId)!;
            if (!conv.lastMessage || msg.created_at > conv.lastMessage.created_at) conv.lastMessage = msg;
            if (!msg.read) conv.unreadCount++;
            continue;
        }

        if (msg.recipient_type === 'GROUP') {
            const group = config.userGroups?.find(g => g.id === msg.recipient_id);
            const gid = `group_${msg.recipient_id}`;
            if (!convMap.has(gid)) {
                convMap.set(gid, { id: gid, name: group?.name || 'Grupo', type: 'GROUP', unreadCount: 0, avatarInitials: getInitials(group?.name || 'G'), channelLabel: 'Grupo' });
            }
            const conv = convMap.get(gid)!;
            if (!conv.lastMessage || msg.created_at > conv.lastMessage.created_at) conv.lastMessage = msg;
            if (!msg.read) conv.unreadCount++;
            continue;
        }

        if (msg.recipient_type === 'ALL') {
            const bid = '__broadcast__';
            if (!convMap.has(bid)) {
                convMap.set(bid, { id: bid, name: 'Todos os Usuários', type: 'GROUP', unreadCount: 0, avatarInitials: '📢', channelLabel: 'Broadcast' });
            }
            const conv = convMap.get(bid)!;
            if (!conv.lastMessage || msg.created_at > conv.lastMessage.created_at) conv.lastMessage = msg;
            if (!msg.read) conv.unreadCount++;
            continue;
        }

        const peerId = msg.sender_id === currentUserId ? msg.recipient_id : msg.sender_id;
        const peerName = msg.sender_id === currentUserId ? (config.users?.find(u => u.id === msg.recipient_id)?.name || msg.recipient_id) : msg.sender_name;
        const cid = `user_${peerId}`;
        if (!convMap.has(cid)) {
            convMap.set(cid, { id: cid, name: peerName, type: 'USER', unreadCount: 0, avatarInitials: getInitials(peerName), channelLabel: 'Mensagem Interna' });
        }
        const conv = convMap.get(cid)!;
        if (!conv.lastMessage || msg.created_at > conv.lastMessage.created_at) conv.lastMessage = msg;
        if (!msg.read && msg.sender_id !== currentUserId) conv.unreadCount++;
    }

    return Array.from(convMap.values())
        .filter(c => c.lastMessage)
        .sort((a, b) => {
            if (!a.lastMessage) return 1;
            if (!b.lastMessage) return -1;
            return b.lastMessage.created_at.localeCompare(a.lastMessage!.created_at);
        });
}

function getToastConvId(msg: Message): string {
    if (msg.is_system) return '__sistema__';
    if (msg.recipient_type === 'ALL') return '__broadcast__';
    if (msg.recipient_type === 'GROUP') return `group_${msg.recipient_id}`;
    return `user_${msg.sender_id}`;
}

export const MessagingProvider: React.FC<Props> = ({ currentUser, config, children }) => {
    const [messages, setMessages] = useState<Message[]>([]);
    const [unreadCount, setUnreadCount] = useState(0);
    const [gotalkUnreadCount, setGotalkUnreadCount] = useState(0);
    const [prospeccaoUnreadCount, setProspeccaoUnreadCount] = useState(0);
    const [isLoading, setIsLoading] = useState(false);
    const [hasMore, setHasMore] = useState(false);
    const [onlineUserIds, setOnlineUserIds] = useState<string[]>([]);
    const [messageToasts, setMessageToasts] = useState<MessageToastItem[]>([]);
    const [pendingNavConvId, setPendingNavConvId] = useState<string | null>(null);

    const eventSourceRef = useRef<EventSource | null>(null);
    const mountedRef = useRef(true);
    const sseBackoffRef = useRef(5000);

    const { socket } = useSocket();

    const conversations = React.useMemo(
        () => currentUser ? buildConversations(messages, currentUser.id, config) : [],
        [messages, currentUser, config]
    );

    const loadMessages = useCallback(async (before?: string) => {
        if (!currentUser) return;
        try {
            const params = new URLSearchParams({ userId: currentUser.id, limit: '50' });
            if (before) params.set('before', before);
            const res = await fetch(`/api/messages?${params}`);
            if (!res.ok) return;
            const data = await res.json();
            if (!mountedRef.current) return;
            if (before) {
                setMessages(prev => {
                    const ids = new Set(prev.map(m => m.id));
                    const newMsgs = data.messages.filter((m: Message) => !ids.has(m.id));
                    return [...prev, ...newMsgs];
                });
            } else {
                setMessages(data.messages || []);
            }
            setHasMore(data.hasMore || false);
            const unread = (data.messages || []).filter((m: Message) => !m.read && m.sender_id !== currentUser.id).length;
            if (!before) setUnreadCount(unread);
        } catch {
        }
    }, [currentUser]);

    // ── Presença online via Socket.io ────────────────────────────────────────
    // Substitui o polling de 60s. O servidor emite 'presence:update' quando
    // um usuário conecta ou desconecta do Socket.io.
    useEffect(() => {
        if (!socket) return;

        const handlePresence = (data: { onlineUserIds: string[] }) => {
            if (mountedRef.current) setOnlineUserIds(data.onlineUserIds || []);
        };

        socket.on('presence:update', handlePresence);

        return () => {
            socket.off('presence:update', handlePresence);
        };
    }, [socket]);

    // ── Polling de mensagens não lidas do GoTalk (a cada 60s) ───────────────
    const fetchGotalkUnread = useCallback(async () => {
        try {
            const res = await fetch('/api/gotalk/messages/unread-count');
            if (!res.ok) return;
            const data = await res.json();
            if (mountedRef.current) setGotalkUnreadCount(data.count || 0);
        } catch {}
    }, []);

    useEffect(() => {
        fetchGotalkUnread();
        const interval = setInterval(fetchGotalkUnread, 60000);
        return () => clearInterval(interval);
    }, [fetchGotalkUnread]);

    const clearGotalkUnread = useCallback(async () => {
        try {
            setGotalkUnreadCount(0);
            await fetch('/api/gotalk/messages/mark-all-read', { method: 'POST' });
        } catch {}
    }, []);

    const incProspeccaoUnread = useCallback((n: number = 1) => {
        if (n <= 0) return;
        setProspeccaoUnreadCount(prev => prev + n);
    }, []);

    const decProspeccaoUnread = useCallback((n: number) => {
        if (n <= 0) return;
        setProspeccaoUnreadCount(prev => Math.max(0, prev - n));
    }, []);

    const clearProspeccaoUnread = useCallback(() => {
        setProspeccaoUnreadCount(0);
    }, []);

    const markGotalkConversationRead = useCallback(async (phone: string, contactId?: string | null) => {
        try {
            const body = contactId ? { contactId } : { phone };
            const res = await fetch('/api/gotalk/messages/mark-read', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(body),
            });
            if (res.ok) {
                const data = await res.json();
                if ((data.updated || 0) > 0) {
                    fetchGotalkUnread();
                }
            }
        } catch {}
    }, [fetchGotalkUnread]);

    // ── SSE para mensagens internas ──────────────────────────────────────────
    // Mantemos SSE para mensagens internas (funciona bem e é unidirecional).
    // A presença online foi migrada para Socket.io acima.
    useEffect(() => {
        mountedRef.current = true;
        if (!currentUser) return;

        loadMessages();

        const connectSSE = () => {
            if (eventSourceRef.current) eventSourceRef.current.close();
            const es = new EventSource(`/api/messages/stream?userId=${currentUser.id}`);
            eventSourceRef.current = es;

            es.onopen = () => {
                sseBackoffRef.current = 5000;
            };

            es.onmessage = (e) => {
                try {
                    const event = JSON.parse(e.data);
                    if (event.type === 'NEW_MESSAGE' && mountedRef.current) {
                        const msg: Message = event.message;
                        setMessages(prev => {
                            if (prev.find(m => m.id === msg.id)) return prev;
                            return [msg, ...prev];
                        });
                        if (msg.sender_id !== currentUser.id) {
                            setUnreadCount(prev => prev + 1);

                            const isUrgentBlock = msg.is_system && (
                                msg.metadata?.eventType === 'CLIENT_BLOCK' ||
                                msg.metadata?.eventType === 'CLIENT_SUSPEND'
                            );

                            const toastType: MessageToastItem['type'] = isUrgentBlock
                                ? 'urgent'
                                : msg.is_system ? 'system' : 'normal';

                            const senderName = msg.is_system ? 'Sistema Invicta' : msg.sender_name;
                            const initials = msg.is_system ? '⚙' : getInitials(msg.sender_name);

                            setMessageToasts(prev => [
                                {
                                    id: msg.id + '_toast_' + Date.now(),
                                    senderName,
                                    senderInitials: initials,
                                    body: msg.body,
                                    createdAt: msg.created_at || new Date().toISOString(),
                                    type: toastType,
                                    conversationId: getToastConvId(msg),
                                },
                                ...prev,
                            ].slice(0, 3));
                        }
                    }
                } catch {}
            };

            es.onerror = () => {
                es.close();
                if (mountedRef.current) {
                    const delay = sseBackoffRef.current;
                    sseBackoffRef.current = Math.min(delay * 2, 60000);
                    setTimeout(connectSSE, delay);
                }
            };
        };

        connectSSE();

        return () => {
            mountedRef.current = false;
            eventSourceRef.current?.close();
        };
    }, [currentUser?.id, loadMessages]);

    const sendMessage = useCallback(async (payload: SendMessagePayload) => {
        if (!currentUser) return;
        const res = await fetch('/api/messages', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                senderId: currentUser.id,
                senderName: currentUser.name,
                ...payload,
            }),
        });
        if (!res.ok) {
            const err = await res.json().catch(() => ({}));
            throw new Error(err.error || 'Falha ao enviar mensagem');
        }
    }, [currentUser]);

    const markAsRead = useCallback(async (messageId: string) => {
        if (!currentUser) return;
        try {
            await fetch(`/api/messages/${messageId}/read`, {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId: currentUser.id }),
            });
            setMessages(prev => prev.map(m => m.id === messageId ? { ...m, read: true } : m));
            setUnreadCount(prev => Math.max(0, prev - 1));
        } catch {}
    }, [currentUser]);

    const markAllAsRead = useCallback(async () => {
        if (!currentUser) return;
        try {
            await fetch('/api/messages/read-all', {
                method: 'PATCH',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ userId: currentUser.id }),
            });
            setMessages(prev => prev.map(m => ({ ...m, read: true })));
            setUnreadCount(0);
        } catch {}
    }, [currentUser]);

    const loadMore = useCallback(async (before: string) => {
        await loadMessages(before);
    }, [loadMessages]);

    const navigateToConversation = useCallback((convId: string) => {
        setPendingNavConvId(convId);
    }, []);

    const clearPendingNav = useCallback(() => {
        setPendingNavConvId(null);
    }, []);

    const contextValue = useMemo(() => ({
        messages,
        conversations,
        unreadCount,
        gotalkUnreadCount,
        prospeccaoUnreadCount,
        isLoading,
        onlineUserIds,
        sendMessage,
        markAsRead,
        markAllAsRead,
        clearGotalkUnread,
        markGotalkConversationRead,
        incProspeccaoUnread,
        decProspeccaoUnread,
        clearProspeccaoUnread,
        loadMore,
        hasMore,
        navigateToConversation,
        pendingNavConvId,
        clearPendingNav,
    }), [messages, conversations, unreadCount, gotalkUnreadCount, prospeccaoUnreadCount, isLoading, onlineUserIds, sendMessage, markAsRead, markAllAsRead, clearGotalkUnread, markGotalkConversationRead, incProspeccaoUnread, decProspeccaoUnread, clearProspeccaoUnread, loadMore, hasMore, navigateToConversation, pendingNavConvId, clearPendingNav]);

    return (
        <MessagingContext.Provider value={contextValue}>
            {children}
            <MessageToast
                toasts={messageToasts}
                onDismiss={(id) => setMessageToasts(prev => prev.filter(t => t.id !== id))}
                onView={(toast) => {
                    if (toast.conversationId) navigateToConversation(toast.conversationId);
                    setMessageToasts([]);
                }}
            />
        </MessagingContext.Provider>
    );
};

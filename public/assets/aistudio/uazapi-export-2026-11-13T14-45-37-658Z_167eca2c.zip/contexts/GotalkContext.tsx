/**
 * GotalkContext — estado global para mensagens WhatsApp (GoTalk).
 *
 * Antes: polling HTTP a cada 30s → 400 req/30s com 200 usuários simultâneos.
 * Agora: recebe evento 'gotalk:new_message' via Socket.io em tempo real.
 *        Apenas uma busca HTTP na montagem para carregar o estado inicial.
 */

import React, { createContext, useContext, useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useSocket } from './SocketContext';
import MessageToast, { MessageToastItem } from '../components/ui/MessageToast';
import { useWhatsappMutePrefs } from '../hooks/useWhatsappMutePrefs';

export interface GotalkNewMessage {
  id: string;
  body: string;
  message_type: string;
  sent_at: string | null;
  imported_at?: string | null;
  gotalk_contact_id: string;
  client_id: string | null;
  contact_name: string | null;
  client_name: string | null;
}

interface GotalkContextType {
  whatsappUnreadCount: number;
  pendingClientId: string | null;
  clearPendingClient: () => void;
  openClient: (clientId: string) => void;
  refreshUnread: () => void;
  newMessages: GotalkNewMessage[];
  dismissNewMessages: () => void;
  pendingConversasNav: boolean;
  clearConversasNav: () => void;
}

const GotalkContext = createContext<GotalkContextType>({
  whatsappUnreadCount: 0,
  pendingClientId: null,
  openClient: () => {},
  clearPendingClient: () => {},
  refreshUnread: () => {},
  newMessages: [],
  dismissNewMessages: () => {},
  pendingConversasNav: false,
  clearConversasNav: () => {},
});

export const useGotalk = () => useContext(GotalkContext);

function getInitials(name: string): string {
  return name.split(' ').map(p => p[0]).join('').toUpperCase().substring(0, 2);
}

interface Props {
  children: React.ReactNode;
}

export const GotalkProvider: React.FC<Props> = ({ children }) => {
  const [whatsappUnreadCount, setWhatsappUnreadCount] = useState(0);
  const [pendingClientId, setPendingClientId] = useState<string | null>(null);
  const [newMessages, setNewMessages] = useState<GotalkNewMessage[]>([]);
  const [pendingConversasNav, setPendingConversasNav] = useState(false);
  const [gotalkToasts, setGotalkToasts] = useState<MessageToastItem[]>([]);

  const lastImportedAtRef = useRef<string>(new Date().toISOString());
  const initializedRef = useRef(false);

  const { socket } = useSocket();
  const mutePrefs = useWhatsappMutePrefs();

  // Keep a stable ref to isMuted so fetchRecent doesn't need mutePrefs as a dep
  const isMutedRef = useRef(mutePrefs.isMuted);
  isMutedRef.current = mutePrefs.isMuted;

  // Clear visible toasts whenever global mute is enabled from any component
  // (e.g. the NotificationBell toggle), not just when muting from the toast itself
  useEffect(() => {
    if (mutePrefs.globalMuted) {
      setGotalkToasts([]);
    }
  }, [mutePrefs.globalMuted]);

  // ── Busca inicial ao montar ───────────────────────────────────────────────
  const fetchUnread = useCallback(async () => {
    try {
      const res = await fetch('/api/gotalk/messages/unread-count');
      if (!res.ok) return;
      const data = await res.json();
      setWhatsappUnreadCount(data.count || 0);
    } catch {}
  }, []);

  const fetchRecent = useCallback(async () => {
    try {
      const since = lastImportedAtRef.current;
      const res = await fetch(`/api/gotalk/messages/recent?since=${encodeURIComponent(since)}`);
      if (!res.ok) return;
      const data = await res.json();
      const msgs: GotalkNewMessage[] = data.data || [];

      if (msgs.length > 0 && initializedRef.current) {
        setNewMessages(msgs);

        // Only create toasts for non-muted conversations (read via ref — stable dep)
        const toastItems: MessageToastItem[] = msgs
          .filter(m => m.body)
          .filter(m => !isMutedRef.current(m.client_id || undefined))
          .map(m => {
            const contactLabel = m.contact_name || m.client_name || 'WhatsApp';
            return {
              id: m.id + '_gotalk_toast_' + Date.now(),
              senderName: contactLabel,
              senderInitials: getInitials(contactLabel),
              body: m.body,
              createdAt: m.imported_at || m.sent_at || new Date().toISOString(),
              type: 'whatsapp' as MessageToastItem['type'],
              conversationId: m.client_id || undefined,
            };
          });
        if (toastItems.length > 0) {
          setGotalkToasts(prev => [...toastItems, ...prev].slice(0, 3));
        }
      }

      if (msgs.length > 0) {
        const latest = msgs.reduce((a, b) => {
          const ta = new Date(a.imported_at || a.sent_at || 0).getTime();
          const tb = new Date(b.imported_at || b.sent_at || 0).getTime();
          return ta > tb ? a : b;
        });
        const nextCursor = latest.imported_at || latest.sent_at;
        if (nextCursor && new Date(nextCursor).getTime() > new Date(lastImportedAtRef.current).getTime()) {
          lastImportedAtRef.current = nextCursor;
        }
      }

      initializedRef.current = true;
    } catch {}
  }, []); // stable — reads mutePrefs through isMutedRef

  // Carrega estado inicial uma única vez na montagem
  useEffect(() => {
    fetchUnread();
    fetchRecent();
  }, [fetchUnread, fetchRecent]);

  // ── Tempo real via Socket.io ──────────────────────────────────────────────
  // Substitui o setInterval de 30s. O servidor emite 'gotalk:new_message'
  // após receber NOTIFY do PostgreSQL quando o Worker salva nova mensagem.
  useEffect(() => {
    if (!socket) return;

    const handleNewMessage = () => {
      // Atualiza contagem e busca mensagens recentes sem polling
      fetchUnread();
      fetchRecent();
    };

    socket.on('gotalk:new_message', handleNewMessage);

    return () => {
      socket.off('gotalk:new_message', handleNewMessage);
    };
  }, [socket, fetchUnread, fetchRecent]);

  const refreshUnread = useCallback(() => {
    fetchUnread();
  }, [fetchUnread]);

  const clearPendingClient = useCallback(() => {
    setPendingClientId(null);
  }, []);

  const openClient = useCallback((clientId: string) => {
    setPendingClientId(clientId);
  }, []);

  const dismissNewMessages = useCallback(() => {
    setNewMessages([]);
  }, []);

  const clearConversasNav = useCallback(() => {
    setPendingConversasNav(false);
  }, []);

  const dismissGotalkToast = useCallback((id: string) => {
    setGotalkToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const handleViewGotalkToast = useCallback((_toast: MessageToastItem) => {
    setPendingConversasNav(true);
    setGotalkToasts([]);
  }, []);

  const handleMuteConversation = useCallback((conversationId: string) => {
    mutePrefs.muteConversation(conversationId);
    // Remove any existing toasts for this conversation
    setGotalkToasts(prev => prev.filter(t => t.conversationId !== conversationId));
  }, [mutePrefs]);

  const handleMuteGlobal = useCallback(() => {
    mutePrefs.muteGlobal();
    setGotalkToasts([]);
  }, [mutePrefs]);

  const contextValue = useMemo(() => ({
    whatsappUnreadCount,
    pendingClientId,
    clearPendingClient,
    openClient,
    refreshUnread,
    newMessages,
    dismissNewMessages,
    pendingConversasNav,
    clearConversasNav,
  }), [whatsappUnreadCount, pendingClientId, clearPendingClient, openClient, refreshUnread, newMessages, dismissNewMessages, pendingConversasNav, clearConversasNav]);

  return (
    <GotalkContext.Provider value={contextValue}>
      {children}
      <MessageToast
        toasts={gotalkToasts}
        onDismiss={dismissGotalkToast}
        onView={handleViewGotalkToast}
        onMuteConversation={handleMuteConversation}
        onMuteGlobal={handleMuteGlobal}
      />
    </GotalkContext.Provider>
  );
};

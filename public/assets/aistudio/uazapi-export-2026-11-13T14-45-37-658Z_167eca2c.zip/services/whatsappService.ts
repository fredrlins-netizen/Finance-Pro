
/**
 * TÍTULO: SERVIÇO DE NOTIFICAÇÃO WHATSAPP
 *
 * Envia mensagens através do endpoint do backend (/api/gotalk/send-text),
 * que autentica com o GoTalk usando credenciais armazenadas no servidor.
 * Nenhum token ou credencial de API é exposto no bundle do cliente.
 */

export const sendWhatsappNotification = async (
    phone: string,
    message: string
): Promise<boolean> => {
    const cleanPhone = phone.replace(/\D/g, '');

    if (cleanPhone.length < 10) {
        console.error('[WHATSAPP] Número de telefone inválido:', phone);
        return false;
    }

    const contactNumber = cleanPhone.startsWith('55') ? cleanPhone : `55${cleanPhone}`;

    try {
        const res = await fetch('/api/gotalk/send-text', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ contactNumber, message }),
        });

        if (!res.ok) {
            const data = await res.json().catch(() => ({}));
            console.error('[WHATSAPP] Falha ao enviar:', res.status, data);
            return false;
        }

        return true;
    } catch (err) {
        console.error('[WHATSAPP] Erro de rede:', err);
        return false;
    }
};

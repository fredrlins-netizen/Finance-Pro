import { expect, test } from '@playwright/test';
import {
  CUSTOM_PALETTES,
  expectAccessibleContrast,
  expectAccessibleContrastInState,
  expectNoPageClipping,
  closeHelpIfOpen,
  mockApplication,
  openMobileMenuIfNeeded,
  simulateOldBundleMissingChunk,
  stabilize,
  THEMES,
  VIEWPORTS,
} from './fixtures';

const CODE_COLUMN = /^(c[oó]d(?:igo)?\.?(?:\s+febraban)?)$/i;

async function expectGridWithoutCodeColumn(page: import('@playwright/test').Page) {
  const grid = page.locator('.operational-grid:visible').first();
  await expect(grid).toBeVisible();
  await expect(grid.getByRole('columnheader', { name: CODE_COLUMN })).toHaveCount(0);
  await expect(grid.locator('tbody tr').first()).toBeVisible();
  await expect(grid.locator('tbody')).not.toContainText(/(?:CLI|BANCO|DEP|PORT|ACCOUNT)-001/);
}

async function expectContrastRegressionDetected(
  root: import('@playwright/test').Locator,
  target: import('@playwright/test').Locator,
  expectedText: string,
) {
  const originalStyle = await target.getAttribute('style');
  await target.evaluate(element => {
    const htmlElement = element as HTMLElement;
    htmlElement.style.setProperty('color', '#223229', 'important');
    htmlElement.style.setProperty('background-color', '#223229', 'important');
  });
  let message = '';
  try {
    await expectAccessibleContrast(root, 'regressão controlada');
  } catch (error) {
    message = String(error);
  } finally {
    await target.evaluate((element, style) => {
      if (style === null) element.removeAttribute('style');
      else element.setAttribute('style', style);
    }, originalStyle);
  }
  expect(message).toContain(expectedText);
}

test('aplica limites distintos a texto visível e controles somente com ícone', async ({ page }) => {
  await page.setContent(`
    <main id="contrast-fixture" style="background: #fff; padding: 20px">
      <button id="icon-control" aria-label="Ação somente com ícone"
        style="color: #888; background: #fff; border: 0">
        <svg aria-hidden="true" width="20" height="20" viewBox="0 0 20 20">
          <rect width="20" height="20" fill="currentColor"></rect>
        </svg>
      </button>
      <button id="text-control"
        style="color: #888; background: #fff; border: 0">Ação com texto</button>
    </main>
  `);

  const fixture = page.locator('#contrast-fixture');
  await expectAccessibleContrast(page.locator('#icon-control'), 'controle somente com ícone');

  let message = '';
  try {
    await expectAccessibleContrast(fixture, 'controle com texto visível');
  } catch (error) {
    message = String(error);
  }
  expect(message).toContain('button "Ação com texto"');
  expect(message).toContain('< 4.5');
  expect(message).not.toContain('Ação somente com ícone');
});

test('mede fill e stroke próprios de SVG sem duplicar a mesma falha gráfica', async ({ page }) => {
  await page.setContent(`
    <main id="svg-contrast-fixture" style="background: #fff; padding: 20px">
      <button id="fill-control" aria-label="Ícone com preenchimento"
        style="color: #111; background: #fff; border: 0">
        <svg aria-hidden="true" width="20" height="20" viewBox="0 0 20 20">
          <rect width="20" height="20" fill="#aaa"></rect>
          <circle cx="10" cy="10" r="5" fill="#aaa"></circle>
        </svg>
      </button>
      <button id="stroke-control" aria-label="Ícone com contorno"
        style="color: #111; background: #fff; border: 0">
        <svg aria-hidden="true" width="20" height="20" viewBox="0 0 20 20">
          <path d="M2 10h16" fill="none" stroke="#aaa" stroke-width="2"></path>
        </svg>
      </button>
      <button id="current-color-fill" aria-label="CurrentColor local no fill"
        style="color: #111; background: #fff; border: 0">
        <svg aria-hidden="true" width="20" height="20" viewBox="0 0 20 20"
          style="color: #aaa">
          <rect width="20" height="20" fill="currentColor"></rect>
        </svg>
      </button>
      <button id="current-color-stroke" aria-label="CurrentColor local no stroke"
        style="color: #111; background: #fff; border: 0">
        <svg aria-hidden="true" width="20" height="20" viewBox="0 0 20 20">
          <path d="M2 10h16" fill="none" stroke="currentColor" stroke-width="2"
            style="color: #aaa"></path>
        </svg>
      </button>
      <button id="inherited-current-color" aria-label="CurrentColor herdado"
        style="color: #aaa; background: #fff; border: 0">
        <svg aria-hidden="true" width="20" height="20" viewBox="0 0 20 20">
          <rect width="20" height="20" fill="currentColor"></rect>
        </svg>
      </button>
    </main>
  `);

  let message = '';
  try {
    await expectAccessibleContrast(page.locator('#svg-contrast-fixture'), 'pinturas próprias de SVG');
  } catch (error) {
    message = String(error);
  }

  expect(message).toContain('svg fill "Ícone com preenchimento"');
  expect(message).toContain('svg stroke "Ícone com contorno"');
  expect(message).toContain('svg fill "CurrentColor local no fill"');
  expect(message).toContain('svg stroke "CurrentColor local no stroke"');
  expect(message.match(/svg fill "Ícone com preenchimento"/g)).toHaveLength(1);
  expect(message).toContain('button "CurrentColor herdado"');
  expect(message).not.toContain('svg fill "CurrentColor herdado"');
  expect(message).not.toContain('button "Ícone com preenchimento"');
  expect(message).not.toContain('button "Ícone com contorno"');
});

test('recupera uma tela após um chunk antigo ausente e não entra em loop de recarga', async ({ page }) => {
  test.skip(
    process.env.PLAYWRIGHT_PRODUCTION_PREVIEW !== '1',
    'A falha de chunk precisa do carregador real do build de produção.',
  );
  await page.setViewportSize({ width: 1366, height: 768 });
  await mockApplication(page, 'light');
  const {
    getStaleBundlesServed,
    getMissingChunkRequests,
  } = await simulateOldBundleMissingChunk(
    page,
    'components/acompanhamento-juridico/LegalTrackingPanel.tsx',
  );

  let recoveryReloads = 0;
  let initialPageReady = false;
  page.on('framenavigated', frame => {
    if (initialPageReady && frame === page.mainFrame()) recoveryReloads += 1;
  });

  await page.goto('/', { waitUntil: 'commit' });
  await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
  initialPageReady = true;
  expect(getStaleBundlesServed()).toBe(1);

  await page.getByRole('button', { name: 'Acompanhamento Jurídico', exact: true }).dispatchEvent('click');
  const dashboardItem = page.getByRole('button', { name: 'Dashboard', exact: true });
  await expect(dashboardItem).toBeVisible();

  const missingChunkResponse = page.waitForResponse(response => (
    response.status() === 404
    && response.url().includes('LegalTrackingPanel-previous-release.js')
  ));
  const recoveryNavigation = page.waitForEvent('framenavigated', frame => frame === page.mainFrame());
  await dashboardItem.dispatchEvent('click');
  const failedChunk = await missingChunkResponse;
  expect(failedChunk.status()).toBe(404);
  expect(new URL(failedChunk.url()).pathname).toBe('/assets/LegalTrackingPanel-previous-release.js');
  expect(failedChunk.headers()['content-type']).toMatch(/^text\/plain\b/);
  expect(getMissingChunkRequests()).toBe(1);

  await recoveryNavigation;
  await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
  expect(recoveryReloads).toBe(1);

  const currentChunkResponse = page.waitForResponse(response => (
    response.status() === 200
    && response.url().includes('/assets/LegalTrackingPanel-')
    && !response.url().includes('previous-release')
    && response.url().endsWith('.js')
  ));
  await navigateSidebarByClick(page, ['Acompanhamento Jurídico', 'Dashboard']);
  await expect(page.getByRole('heading', { name: 'Dashboard Jurídico' })).toBeVisible();
  expect((await currentChunkResponse).status()).toBe(200);
  expect(getMissingChunkRequests()).toBe(1);

  const repeatedErrorWasPrevented = await page.evaluate(() => {
    const errorEvent = new Event('vite:preloadError', { cancelable: true }) as Event & { payload?: Error };
    errorEvent.payload = new Error('Falha repetida de chunk');
    window.dispatchEvent(errorEvent);
    return errorEvent.defaultPrevented;
  });
  expect(repeatedErrorWasPrevented).toBe(false);
  await page.waitForTimeout(150);
  expect(recoveryReloads).toBe(1);
});

test('as quatro telas principais abrem sem erros de importação', async ({ page }) => {
  await page.setViewportSize({ width: 1366, height: 768 });
  await mockApplication(page, 'light');
  const pageErrors: string[] = [];
  const failedModules: string[] = [];
  page.on('pageerror', error => pageErrors.push(error.message));
  page.on('response', response => {
    if (response.status() < 400) return;
    if (/\.(?:m?js|[jt]sx?)(?:\?|$)/i.test(response.url())) {
      failedModules.push(`${response.status()} ${response.url()}`);
    }
  });

  await page.goto('/', { waitUntil: 'commit' });
  await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
  await closeHelpIfOpen(page);

  const destinations = [
    {
      path: ['Acompanhamento Jurídico', 'Dashboard'],
      heading: 'Dashboard Jurídico',
    },
    {
      path: ['Financeiro', 'Gerenciamento'],
      heading: 'Gerenciamento Financeiro',
    },
    {
      path: ['Cobrança', 'Coordenadores'],
      heading: 'Cobrança — Coordenadores',
    },
    {
      path: ['Negociação'],
      heading: 'Negociação Financeira',
    },
  ];

  for (const destination of destinations) {
    await navigateSidebarByClick(page, destination.path);
    await expect(page.getByRole('heading', { name: destination.heading })).toBeVisible();
  }

  expect(pageErrors, 'Erros não tratados do navegador').toEqual([]);
  expect(failedModules, 'Módulos JS/TSX com resposta de erro').toEqual([]);
});

async function navigateSidebarByClick(
  page: import('@playwright/test').Page,
  labels: string[],
) {
  const navigation = page.getByRole('navigation');
  for (const [index, label] of labels.entries()) {
    const nextLabel = labels[index + 1];
    if (nextLabel) {
      const nextItem = navigation.getByRole('button', { name: nextLabel, exact: true });
      if (await nextItem.isVisible()) continue;
    }
    const item = navigation.getByRole('button', { name: label, exact: true });
    await expect(item).toBeVisible();
    await item.click();
    if (nextLabel) {
      await expect(navigation.getByRole('button', { name: nextLabel, exact: true })).toBeVisible();
    }
  }
}

async function openSidebarPath(
  page: import('@playwright/test').Page,
  viewportWidth: number,
  labels: string[],
) {
  await openMobileMenuIfNeeded(page, viewportWidth);
  for (const [index, label] of labels.entries()) {
    const nextLabel = labels[index + 1];
    if (nextLabel && await page.getByRole('button', { name: nextLabel, exact: true }).isVisible()) {
      continue;
    }
    const item = page.getByRole('button', { name: label, exact: true });
    await expect(item).toBeVisible();
    await item.dispatchEvent('click');
  }
}

for (const viewport of VIEWPORTS) {
  for (const theme of THEMES) {
    const suffix = `${viewport.name}-${theme}`;

    test.describe(`${suffix}`, () => {
      test.use({ viewport: { width: viewport.width, height: viewport.height } });

      test(`login ${suffix}`, async ({ page }) => {
        await mockApplication(page, theme, false);
        await page.goto('/');
        await expect(page.getByPlaceholder('seu.nome@finance.com')).toBeVisible();
        await stabilize(page);
        await expectNoPageClipping(page);
        await expect(page).toHaveScreenshot(`login-${suffix}.png`);
      });

      test(`shell ${suffix}`, async ({ page }) => {
        await mockApplication(page, theme);
        await page.goto('/');
        await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
        await closeHelpIfOpen(page);
        await stabilize(page);
        await expectNoPageClipping(page);
        await expect(page).toHaveScreenshot(`shell-${suffix}.png`);
      });

      test(`formulario e tabela ${suffix}`, async ({ page }) => {
        await mockApplication(page, theme);
        await page.goto('/');
        await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
        await closeHelpIfOpen(page);
        await openMobileMenuIfNeeded(page, viewport.width);
        await page.getByRole('button', { name: 'Cadastros Comuns', exact: true }).click();
        await page.getByRole('button', { name: 'Clientes', exact: true }).click();
        await expect(page.getByRole('heading', { name: 'Cadastro de Clientes' })).toBeVisible();
        await stabilize(page);
        await expectNoPageClipping(page);
        await expect(page).toHaveScreenshot(`tabela-${suffix}.png`);

        await page.getByRole('button', { name: 'Novo Cliente' }).click();
        await expect(page.getByText('Novo Cliente', { exact: true })).toBeVisible();
        await expect(page.getByRole('button', { name: /salvar/i })).toBeVisible();
        await stabilize(page);
        await expectNoPageClipping(page);
        await expect(page).toHaveScreenshot(`formulario-${suffix}.png`);
      });

      test(`grades e impressão sem colunas de código ${suffix}`, async ({ page }) => {
        await mockApplication(page, theme);
        await page.goto('/');
        await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
        await closeHelpIfOpen(page);

        await openSidebarPath(page, viewport.width, ['Cadastros Comuns', 'Clientes']);
        await expect(page.getByRole('heading', { name: 'Cadastro de Clientes' })).toBeVisible();
        await expectGridWithoutCodeColumn(page);
        await expect(page.getByPlaceholder('Pesquisar por Nome, Código ou CPF/CNPJ...')).toBeVisible();
        await page.getByRole('button', { name: 'Novo Cliente' }).click();
        await expect(page.getByText('Cód.', { exact: true })).toBeVisible();

        await openSidebarPath(page, viewport.width, ['Cadastros Comuns', 'Bancos']);
        await expect(page.getByRole('heading', { name: 'Cadastro de Bancos' })).toBeVisible();
        await expectGridWithoutCodeColumn(page);
        await expect(page.getByPlaceholder('Pesquisar por Nome, Código ou Febraban...')).toBeVisible();
        await page.getByRole('button', { name: 'Novo Banco' }).click();
        await expect(page.getByText('04. Cód. Febraban', { exact: true })).toBeVisible();

        await openSidebarPath(page, viewport.width, ['Cadastros Comuns', 'Departamentos']);
        await expect(page.getByRole('heading', { name: 'Departamentos' })).toBeVisible();
        await expectGridWithoutCodeColumn(page);
        await page.getByRole('button', { name: 'Novo Departamento' }).click();
        await expect(page.getByText('Código', { exact: true })).toBeVisible();

        await openSidebarPath(page, viewport.width, ['Financeiro', 'Cadastros', 'Portador']);
        await expect(page.getByRole('heading', { name: 'Portadores' })).toBeVisible();
        await expectGridWithoutCodeColumn(page);
        await page.getByRole('button', { name: 'Novo Portador' }).click();
        await expect(page.getByText('Código', { exact: true })).toBeVisible();

        await openSidebarPath(page, viewport.width, ['Financeiro', 'Cadastros', 'Plano de Contas']);
        await expect(page.getByRole('heading', { name: 'Plano de Contas' })).toBeVisible();
        await expectGridWithoutCodeColumn(page);
        await page.getByRole('button', { name: 'Nova Conta' }).click();
        await expect(page.getByText('Código Estruturado', { exact: true })).toBeVisible();

        await openSidebarPath(page, viewport.width, ['Atendimento', 'Comercial', 'Admissão']);
        await expect(page.getByRole('heading', { name: 'Admissão de Processos' })).toBeVisible();
        const admissionGrid = page.locator('.compact-virtual-grid .grid-body-scroll');
        await expect(admissionGrid).toBeVisible();
        await expect(admissionGrid.getByRole('button', { name: /^Cliente/ })).toBeVisible();
        await expect(admissionGrid.getByText(CODE_COLUMN)).toHaveCount(0);
        await expect(admissionGrid).not.toContainText('ADM-CODE-001');
        await admissionGrid.getByRole('button', { name: 'Visualizar' }).click();

        await expect(page.getByRole('heading', { name: 'Visualização do Documento' })).toBeVisible();
        await expect(page.getByRole('button', { name: 'IMPRIMIR' })).toBeVisible();

        const printableDocument = page.locator('.printable-content:visible');
        await expect(printableDocument).toHaveCount(1);
        const itemTable = printableDocument.locator('table').filter({
          has: page.getByRole('columnheader', { name: 'Descrição', exact: true }),
        });
        await expect(itemTable).toBeVisible();
        await expect(itemTable.getByRole('columnheader', { name: CODE_COLUMN })).toHaveCount(0);
        await expect(itemTable.getByRole('columnheader')).toHaveCount(5);
        await expect(itemTable.locator('tbody tr').first().locator('td')).toHaveCount(5);
        await expect(itemTable.locator('tbody tr').first().locator('td').first()).toHaveText('UN');
        await expect(itemTable.locator('tbody tr').nth(1).locator('td').first()).not.toHaveText('2');
        await expect(itemTable.locator('tbody tr').nth(2).locator('td').first()).not.toHaveText('3');
      });

      test(`indicador padrão de grades ${suffix}`, async ({ page }) => {
        await mockApplication(page, theme);
        await page.goto('/');
        const shell = page.locator('.dashboard-shell');
        await expect(shell).toBeVisible();

        const indicators = await shell.evaluate(container => {
          return [undefined, 'instructional', 'semantic'].map(variant => {
            const table = document.createElement('table');
            if (variant) table.dataset.gridVariant = variant;
            table.innerHTML = '<tbody><tr><td>Linha de validação</td></tr></tbody>';
            container.appendChild(table);
            const boxShadow = getComputedStyle(table.querySelector('tr')!).boxShadow;
            table.remove();
            return boxShadow;
          });
        });

        expect(indicators[0]).not.toBe('none');
        expect(indicators.slice(1)).toEqual(['none', 'none']);
      });

      test(`conversa e modal ${suffix}`, async ({ page }) => {
        await mockApplication(page, theme);
        await page.goto('/');
        await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
        await closeHelpIfOpen(page);
        await openMobileMenuIfNeeded(page, viewport.width);
        await page.getByRole('button', { name: 'Conversas WhatsApp', exact: true }).click();
        await expect(page.getByRole('heading', { name: 'Conversas WhatsApp' })).toBeVisible();
        await stabilize(page);
        await expectNoPageClipping(page);
        await expect(page).toHaveScreenshot(`conversa-${suffix}.png`);

        const newMessage = page.getByRole('button', { name: 'Nova mensagem' });
        await expect(newMessage).toBeEnabled();
        await newMessage.click();
        await expect(page.getByText('Nova mensagem via uazapi')).toBeVisible();
        await expect(page.getByRole('button', { name: /enviar/i })).toBeVisible();
        await stabilize(page);
        await expectNoPageClipping(page);
        await expect(page).toHaveScreenshot(`modal-${suffix}.png`);
      });

      test(`prospecção e controles responsivos ${suffix}`, async ({ page }) => {
        await mockApplication(page, theme);
        await page.goto('/');
        await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
        await closeHelpIfOpen(page);
        await openMobileMenuIfNeeded(page, viewport.width);
        await page.getByRole('button', { name: 'Atendimento', exact: true }).click();
        await page.getByRole('button', { name: 'Comercial', exact: true }).click();
        await page.getByRole('button', { name: 'Prospecção', exact: true }).click();
        await expect(page.locator('[data-testid="prospeccao-panel"]')).toBeVisible();
        await expect(page.locator('[data-testid="prospeccao-contact-list"]')).toBeVisible();
        await expect(page.locator('[data-testid="prospeccao-pagination"]')).toBeVisible();
        await expect(page.getByPlaceholder('Buscar por nome ou telefone...')).toBeVisible();
        await page.getByRole('button', { name: 'Dashboard', exact: true }).click();
        await expect(page.locator('[data-testid="prospeccao-dashboard"]')).toBeVisible();
        await expect(page.locator('[data-testid="prospeccao-dashboard-filters"]')).toBeVisible();
        await expect(page.locator('[data-testid="prospeccao-report-panel"]')).toBeVisible();
        await stabilize(page);
        await expectNoPageClipping(page);
      });

      test(`conversas tabela e filtros acessíveis ${suffix}`, async ({ page }) => {
        await mockApplication(page, theme);
        await page.goto('/');
        await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
        await closeHelpIfOpen(page);
        await openMobileMenuIfNeeded(page, viewport.width);
        await page.getByRole('button', { name: 'Conversas WhatsApp', exact: true }).click();
        await expect(page.locator('[data-testid="conversas-panel"]')).toBeVisible();
        await expect(page.locator('[data-testid="conversas-filters"]')).toBeVisible();
        await expect(page.locator('[data-testid="conversas-table"]')).toBeVisible();
        await expect(page.locator('[data-testid="conversas-pagination"]')).toBeVisible();
        await expect(page.getByTitle('Limpar filtros')).toBeVisible();
        await stabilize(page);
        await expectNoPageClipping(page);
      });
    });
  }
}

test.describe('contraste das paletas personalizadas', () => {
  test.describe.configure({ retries: 1 });

  for (const theme of THEMES) {
    for (const palette of CUSTOM_PALETTES) {
      test(`contraste da conversa em modo ${theme === 'dark' ? 'escuro' : 'claro'} — ${palette}`, async ({ page }) => {
        await page.setViewportSize({ width: 1366, height: 768 });
        await mockApplication(page, theme, true, palette);
        await page.goto('/');
        await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
        await closeHelpIfOpen(page);
        await stabilize(page);
        const panel = page.getByTestId('conversas-panel');
        const conversationsButton = page.getByRole('button', { name: 'Conversas WhatsApp', exact: true });
        await conversationsButton.dispatchEvent('click');
        if (!await panel.isVisible({ timeout: 3_000 }).catch(() => false)) {
          await expect(conversationsButton).toBeVisible();
          await conversationsButton.dispatchEvent('click');
        }
        await expect(panel).toBeVisible();
        await expect(page.getByText('Segue o comprovante solicitado.')).toBeVisible();
        await stabilize(page);
        await expectAccessibleContrast(panel, `lista de conversas (${theme}, ${palette})`);
        const conversationRow = page.getByTestId('conversas-table').locator('tbody tr').filter({
          hasText: 'Cliente de Exemplo',
        }).first();
        await expectAccessibleContrastInState(
          panel,
          conversationRow,
          'hover',
          `linha da lista de conversas (${theme}, ${palette})`,
        );
        const newMessage = page.getByRole('button', { name: 'Nova mensagem' });
        await expectAccessibleContrastInState(
          panel,
          newMessage,
          'focus',
          `botão de nova mensagem (${theme}, ${palette})`,
        );
        if (palette === 'ocean') {
          await expectContrastRegressionDetected(
            panel,
            page.getByTestId('conversas-table').getByRole('columnheader', { name: 'Data/Hora' }),
            'Data/Hora',
          );
        }

        await conversationRow.dispatchEvent('click');
        await expect(page.locator('.conversation-bubble-in')).toHaveCount(3);
        await expect(page.locator('.conversation-bubble-out')).toHaveCount(3);
        await expect(page.getByText('comprovante.pdf')).toBeVisible();
        const image = page.getByRole('img', { name: 'atendimento.png' });
        const audio = page.locator('audio[controls]');
        const video = page.locator('video[controls]');
        await expect(image).toBeVisible();
        await expect(page.getByText('Imagem do atendimento')).toBeVisible();
        await expect(page.getByText('Vídeo de confirmação')).toBeVisible();
        await expect(page.getByText(/via \+55 \(11\) 4000-0000/).first()).toBeVisible();
        await expect(audio).toBeVisible();
        await expect(video).toBeVisible();
        const transcriptToggle = page.getByRole('button', { name: 'Transcrição' });
        const transcript = page.getByText('Olá, confirmo que o atendimento foi concluído com sucesso.');
        await expect(transcriptToggle).toBeVisible();
        await expect(transcriptToggle).toHaveAttribute('aria-expanded', 'false');
        await expect(transcript).toBeHidden();
        await transcriptToggle.click();
        await expect(transcriptToggle).toHaveAttribute('aria-expanded', 'true');
        await expect(transcript).toBeVisible();
        await expect.poll(() => image.evaluate(element => (element as HTMLImageElement).naturalWidth)).toBeGreaterThan(0);
        await expect.poll(() => audio.evaluate(element => (element as HTMLAudioElement).readyState)).toBeGreaterThan(0);
        await expect.poll(() => video.evaluate(element => (element as HTMLVideoElement).videoWidth)).toBeGreaterThan(0);
        await expect(page.getByTitle('Baixar arquivo')).toHaveCount(4);
        await expectAccessibleContrast(panel, `histórico preenchido (${theme}, ${palette})`);
        if (palette === 'ocean') {
          await expectContrastRegressionDetected(
            panel,
            page.locator('.conversation-date-pill').first(),
            '19/09/26',
          );
        }

        await newMessage.click();
        const dialog = page.getByRole('dialog');
        await expect(dialog).toBeVisible();
        const sendButton = dialog.getByRole('button', { name: /enviar/i });
        const messageField = dialog.getByPlaceholder('Digite a mensagem...');
        await expect(sendButton).toBeVisible();
        await expect(messageField).toBeVisible();
        await expectAccessibleContrast(dialog, `modal de nova mensagem (${theme}, ${palette})`);
        await expectAccessibleContrastInState(
          dialog,
          sendButton,
          'hover',
          `botão de envio do modal (${theme}, ${palette})`,
        );
        await expectAccessibleContrastInState(
          dialog,
          messageField,
          'focus',
          `campo de mensagem do modal (${theme}, ${palette})`,
        );
        if (palette === 'ocean' && theme === 'light') {
          await messageField.focus();
          await expectContrastRegressionDetected(dialog, messageField, 'Digite a mensagem...');
        }
      });
    }
  }
});

import { expect, test, Page } from '@playwright/test';
import { DEFAULT_PORTAL_CONFIG } from '../../constants';
import { closeHelpIfOpen, mockApplication, visualUser } from './fixtures';

const originalId = '10000000-0000-4000-8000-000000000001';
const createdId = '10000000-0000-4000-8000-000000000002';
const secondCreatedId = '10000000-0000-4000-8000-000000000003';
const validCnpj = '12.345.678/0001-95';
const originalUnit = {
  id: originalId,
  razaoSocial: 'Unidade Original Ltda.',
  nomeFantasia: 'Unidade Original',
  cnpj: validCnpj,
  telefone: '(11) 4000-0000',
  email: 'original@example.test',
  cep: '01001-000',
  endereco: 'Praça da Sé',
  numero: '1',
  complemento: '',
  bairro: 'Sé',
  cidade: 'São Paulo',
  estado: 'SP',
  taxaMinima: '10,00',
  whatsappNumber: '5511999990000',
  emailConfig: { senderName: 'Original' },
  googleIntegration: { connected: false },
};

type UnitWrite = { method: string; path: string; body?: Record<string, unknown> };

async function setupUnits(page: Page) {
  let rows = [{ ...originalUnit }];
  let nextId = createdId;
  let failNextPost = false;
  let configRefreshes = 0;
  let holdNextCredentialsRequest = false;
  let releaseCredentialsRequest = () => {};
  let credentialsRequestStarted = Promise.resolve();
  let signalCredentialsRequestStarted = () => {};
  const writes: UnitWrite[] = [];
  const integrationRequests: string[] = [];

  await mockApplication(page, 'light', true, 'institutional', { units: rows });
  await page.route('**/api/config', async route => {
    configRefreshes += 1;
    return route.fulfill({
      json: {
        data: {
          ...DEFAULT_PORTAL_CONFIG,
          units: rows,
          users: [visualUser('light')],
          auditLogs: [],
        },
      },
    });
  });
  await page.route('**/api/units**', async route => {
    const request = route.request();
    const path = new URL(request.url()).pathname;
    const method = request.method();

    if (path.endsWith('/uazapi-credentials')) {
      integrationRequests.push(path);
      if (holdNextCredentialsRequest) {
        holdNextCredentialsRequest = false;
        signalCredentialsRequestStarted();
        await new Promise<void>(resolve => { releaseCredentialsRequest = resolve; });
      }
      return route.fulfill({
        json: {
          instances: [{
            credId: 'credential-original',
            label: 'Instância da unidade original',
            uazapiInstanceId: 'original-instance',
            hasToken: true,
            uazapiServerUrl: 'centralhub.uazapi.com',
          }],
        },
      });
    }
    if (method === 'GET' && path === '/api/units') {
      return route.fulfill({ json: { data: rows, total: rows.length, page: 1, totalPages: 1 } });
    }
    if (method === 'POST') {
      const body = request.postDataJSON() as Record<string, unknown>;
      writes.push({ method, path, body });
      if (failNextPost) {
        failNextPost = false;
        return route.fulfill({ status: 400, json: { error: 'Falha simulada ao salvar.' } });
      }
      const record = { ...body, id: nextId };
      nextId = secondCreatedId;
      rows = [...rows, record];
      return route.fulfill({ status: 201, json: { data: record } });
    }
    if (method === 'PUT') {
      const body = request.postDataJSON() as Record<string, unknown>;
      writes.push({ method, path, body });
      const id = path.split('/').pop();
      rows = rows.map(row => row.id === id ? { ...row, ...body, id } : row);
      const record = rows.find(row => row.id === id);
      return route.fulfill({ json: { data: record } });
    }
    return route.fulfill({ json: { data: rows, total: rows.length } });
  });

  await page.setViewportSize({ width: 1366, height: 768 });
  await page.goto('/', { waitUntil: 'domcontentloaded' });
  await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
  await closeHelpIfOpen(page);
  await page.getByRole('button', { name: 'Configurações', exact: true }).click();
  await page.getByRole('button', { name: 'Unidades', exact: true }).click();
  await expect(page.getByText(originalUnit.razaoSocial, { exact: true })).toBeVisible();

  return {
    writes,
    rows: () => rows,
    integrationRequests,
    failNextPost: () => { failNextPost = true; },
    configRefreshes: () => configRefreshes,
    holdNextCredentialsRequest: () => {
      holdNextCredentialsRequest = true;
      credentialsRequestStarted = new Promise<void>(resolve => { signalCredentialsRequestStarted = resolve; });
      return {
        started: credentialsRequestStarted,
        release: () => releaseCredentialsRequest(),
      };
    },
  };
}

const originalRow = (page: Page) => page.locator('div.border.p-4.rounded-lg.mb-2').filter({ hasText: originalUnit.razaoSocial }).first();
const unitForm = (page: Page) => page.locator('[data-form-container="true"]');
const cnpjInput = (page: Page) => page.getByPlaceholder('00.000.000/0000-00');

test('duplicar cria por POST, preserva a unidade original e usa o ID retornado', async ({ page }) => {
  const state = await setupUnits(page);

  await originalRow(page).getByRole('button', { name: 'Editar', exact: true }).click();
  await expect(page.getByText('Instância da unidade original')).toBeVisible();
  await page.getByRole('button', { name: 'Cancelar', exact: true }).click();

  const integrationRequestCount = state.integrationRequests.length;
  await originalRow(page).getByRole('button', { name: 'Duplicar', exact: true }).click();
  await expect(unitForm(page)).toBeVisible();
  await expect(cnpjInput(page)).toHaveValue('');
  await expect(page.getByText('Instância da unidade original')).toHaveCount(0);
  expect(state.integrationRequests).toHaveLength(integrationRequestCount);
  expect(state.writes).toEqual([]);

  await cnpjInput(page).fill(validCnpj);
  const refreshesBeforeSave = state.configRefreshes();
  await page.getByRole('button', { name: 'Salvar', exact: true }).click();

  await expect(page.getByText('Cópia de Unidade Original Ltda.', { exact: true })).toBeVisible();
  await expect.poll(() => state.writes.filter(write => write.method === 'POST')).toHaveLength(1);
  expect(state.writes[0].path).toBe('/api/units');
  expect(state.writes[0].body).not.toHaveProperty('id');
  expect(state.writes.some(write => write.method === 'PUT')).toBe(false);
  expect(state.rows().find(row => row.id === originalId)).toMatchObject({
    razaoSocial: originalUnit.razaoSocial,
    cnpj: validCnpj,
  });
  expect(state.rows().find(row => row.id === createdId)).toMatchObject({
    razaoSocial: 'Cópia de Unidade Original Ltda.',
    cnpj: validCnpj,
  });
  expect(state.configRefreshes()).toBeGreaterThan(refreshesBeforeSave);
});

test('Nova Unidade cria sem ID e Editar atualiza somente a unidade escolhida', async ({ page }) => {
  const state = await setupUnits(page);

  await page.getByRole('button', { name: 'Nova Unidade', exact: true }).click();
  await unitForm(page).locator('input').nth(0).fill('Unidade Nova Ltda.');
  await cnpjInput(page).fill(validCnpj);
  await page.getByRole('button', { name: 'Salvar', exact: true }).click();

  await expect(page.getByText('Unidade Nova Ltda.', { exact: true })).toBeVisible();
  expect(state.writes[0].method).toBe('POST');
  expect(state.writes[0].body).not.toHaveProperty('id');
  expect(state.rows().some(row => row.id === createdId && row.razaoSocial === 'Unidade Nova Ltda.')).toBe(true);

  await originalRow(page).getByRole('button', { name: 'Editar', exact: true }).click();
  await unitForm(page).locator('input').nth(0).fill('Unidade Original Alterada Ltda.');
  await page.getByRole('button', { name: 'Salvar', exact: true }).click();

  await expect(page.getByText('Unidade Original Alterada Ltda.', { exact: true })).toBeVisible();
  expect(state.writes.at(-1)).toMatchObject({
    method: 'PUT',
    path: `/api/units/${originalId}`,
  });
  expect(state.rows().find(row => row.id === originalId)?.razaoSocial).toBe('Unidade Original Alterada Ltda.');
});

test('cancelar e falhar ao salvar uma cópia não adiciona unidades nem informa sucesso', async ({ page }) => {
  const state = await setupUnits(page);

  await originalRow(page).getByRole('button', { name: 'Duplicar', exact: true }).click();
  await page.getByRole('button', { name: 'Cancelar', exact: true }).click();
  await expect(page.getByText('Cópia de Unidade Original Ltda.', { exact: true })).toHaveCount(0);
  expect(state.rows()).toHaveLength(1);
  expect(state.writes).toEqual([]);

  state.failNextPost();
  await originalRow(page).getByRole('button', { name: 'Duplicar', exact: true }).click();
  await cnpjInput(page).fill(validCnpj);
  await page.getByRole('button', { name: 'Salvar', exact: true }).click();

  await expect(page.getByText('Falha simulada ao salvar.')).toBeVisible();
  await expect(page.getByText('Unidade salva com sucesso.')).toHaveCount(0);
  expect(state.rows()).toHaveLength(1);
  expect(state.rows()[0]).toMatchObject({ id: originalId, razaoSocial: originalUnit.razaoSocial });
  expect(state.writes).toHaveLength(1);
  expect(state.writes[0].method).toBe('POST');
});

test('uma resposta WhatsApp atrasada da unidade original não aparece na cópia', async ({ page }) => {
  const state = await setupUnits(page);
  const pendingCredentials = state.holdNextCredentialsRequest();

  await originalRow(page).getByRole('button', { name: 'Editar', exact: true }).click();
  await pendingCredentials.started;
  await page.getByRole('button', { name: 'Cancelar', exact: true }).click();
  await originalRow(page).getByRole('button', { name: 'Duplicar', exact: true }).click();
  expect(state.integrationRequests).toContain(`/api/units/${originalId}/uazapi-credentials`);

  const credentialsResponse = page.waitForResponse(response =>
    new URL(response.url()).pathname.endsWith('/uazapi-credentials'),
  );
  pendingCredentials.release();
  await credentialsResponse;
  await page.waitForTimeout(150);

  await expect(page.getByText('Instância da unidade original')).toHaveCount(0);
  await expect(cnpjInput(page)).toHaveValue('');
});

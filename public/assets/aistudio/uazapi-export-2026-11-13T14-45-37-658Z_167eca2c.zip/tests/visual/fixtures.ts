import { expect, Page } from '@playwright/test';
import { readFile } from 'node:fs/promises';

export const VIEWPORTS = [
  { name: '1920x1080', width: 1920, height: 1080 },
  { name: '1366x768', width: 1366, height: 768 },
  { name: '1024x768', width: 1024, height: 768 },
  { name: '768x1024', width: 768, height: 1024 },
  { name: '360x800', width: 360, height: 800 },
] as const;

export const RESPONSIVE_WIDTHS = [
  320, 360, 390, 412, 448, 640, 768, 899, 900, 1024, 1280, 1440, 1920,
] as const;

export const THEMES = ['light', 'dark'] as const;
export type VisualTheme = typeof THEMES[number];
export const CUSTOM_PALETTES = ['ocean', 'violet', 'amber'] as const;
export type VisualPalette = 'institutional' | typeof CUSTOM_PALETTES[number];

const unit = {
  id: '10000000-0000-4000-8000-000000000001',
  nomeFantasia: 'Unidade Visual',
  razaoSocial: 'Unidade Visual Ltda.',
  cnpj: '00.000.000/0001-00',
  telefone: '(11) 4000-0000',
  email: 'visual@example.test',
  cep: '01001-000',
  endereco: 'Praça da Sé',
  numero: '1',
  complemento: '',
  bairro: 'Sé',
  cidade: 'São Paulo',
  estado: 'SP',
  uazapiHasToken: true,
};

const clients = [
  {
    id: 'CLI-001',
    name: 'Cliente de Exemplo',
    type: 'FISICA',
    natureza: 'C',
    document: '123.456.789-00',
    phone: '(11) 99999-0001',
    city: 'São Paulo',
    state: 'SP',
  },
  {
    id: 'CLI-002',
    name: 'Empresa Demonstração',
    type: 'JURIDICA',
    natureza: 'F',
    document: '12.345.678/0001-90',
    phone: '(21) 98888-0002',
    city: 'Rio de Janeiro',
    state: 'RJ',
  },
];

const banks = [{
  id: 'BANK-001',
  code: 'BANCO-001',
  febrabanCode: '001',
  name: 'Banco Visual',
  status: 'ATIVO',
  services: [],
  contacts: [],
}];

const departments = [{
  id: 'DEP-001',
  code: 'DEP-001',
  name: 'Departamento Visual',
  managerName: 'Responsável Visual',
  status: 'ATIVO',
}];

const roles = Array.from({ length: 18 }, (_, index) => ({
  id: `ROLE-${String(index + 1).padStart(3, '0')}`,
  option_type: 'ROLE',
  value: JSON.stringify({ name: `Cargo operacional ${index + 1}`, participatesInScheduling: index % 2 === 0 }),
  sort_order: index,
}));

const bearers = [{
  id: 'BEARER-001',
  code: 'PORT-001',
  name: 'Portador Visual',
  type: 'CARTEIRA',
}];

const financialAccounts = [{
  id: 'ACCOUNT-001',
  code: '1.01.01',
  name: 'Conta Visual',
  type: 'RECEITA',
  isAnalytical: true,
}];

const admissions = [{
  id: 'ADM-001',
  code: 'ADM-CODE-001',
  date: '2026-09-19T12:00:00.000Z',
  contractNumber: 'CONTRATO-001',
  clientId: clients[0].id,
  clientName: clients[0].name,
  bankId: banks[0].id,
  unitId: unit.id,
  status: 'PENDENTE',
  originType: 'PROSPECÇÃO',
  indicationType: '',
  tipoCliente: 'RESPONSAVEL',
  recalcScenarios: [],
  attachments: [],
}];

// Profiles deliberately live only on clients, never on the admission snapshot.
// Return fresh objects so import tests can replace their server state in isolation.
export function importedAdmissionFixture() {
  const profiles = [
    {
      ...clients[0], id: '30000000-0000-4000-8000-000000000001',
      name: 'Responsável Sintético Importado', document: '000.000.000-01',
      rg: 'RG-TESTE-01', phone: '(11) 90000-0001',
      profession: 'Profissão Sintética Responsável', maritalStatus: 'SOLTEIRO',
      email: 'responsavel@example.test', address: 'Rua Sintética Responsável',
      number: '101', district: 'Bairro Teste',
    },
    {
      ...clients[0], id: '30000000-0000-4000-8000-000000000002',
      name: 'Titular Sintético Importado', document: '000.000.000-02',
      rg: 'RG-TESTE-02', phone: '(21) 90000-0002',
      profession: 'Profissão Sintética Titular', maritalStatus: 'CASADO',
      email: 'titular@example.test', address: 'Rua Sintética Titular',
      number: '202', district: 'Bairro Titular Teste', city: 'Rio de Janeiro', state: 'RJ',
    },
  ];
  return {
    clients: profiles,
    admissions: [{
      ...admissions[0],
      id: '40000000-0000-4000-8000-000000000001',
      contractNumber: 'CONTRATO-SINTETICO',
      clientId: profiles[0].id,
      // Deliberately stale: the form/preview must use the linked client's profile.
      clientName: 'Nome anterior à importação',
      titularClientId: profiles[1].id,
      tipoCliente: 'RESPONSÁVEL',
    }],
  };
}

export function visualUser(theme: VisualTheme, palette: VisualPalette = 'institutional') {
  return {
    id: '20000000-0000-4000-8000-000000000001',
    name: 'Usuário Visual',
    email: 'visual@example.test',
    role: 'ADMIN',
    status: 'ATIVO',
    allowedUnitIds: [unit.id],
    allowedUnits: [unit],
    currentUnitId: unit.id,
    groupIds: [],
    visualPreferences: { mode: theme.toUpperCase(), palette: palette.toUpperCase(), widthScale: 100, heightScale: 100 },
    canCustomizeColors: true,
  };
}

export async function mockApplication(
  page: Page,
  theme: VisualTheme,
  authenticated = true,
  palette: VisualPalette = 'institutional',
  configOverrides: Record<string, unknown> = {},
  options: { freezeDate?: boolean; preserveLocalStorage?: boolean } = {},
) {
  const user = visualUser(theme, palette);
  const visualMedia = new Map([
    ['timeline-4', { file: 'conversa-audio.wav', contentType: 'audio/wav' }],
    ['timeline-5', { file: 'conversa-imagem.png', contentType: 'image/png' }],
    ['timeline-6', { file: 'conversa-video.webm', contentType: 'video/webm' }],
  ]);

  await page.addInitScript(({ selectedTheme, selectedPalette, freezeDate, preserveLocalStorage }) => {
    const fixedNow = new Date('2026-09-19T14:30:00-03:00').valueOf();
    const NativeDate = Date;
    class FixedDate extends NativeDate {
      constructor(...args: ConstructorParameters<typeof Date>) {
        super(...(args.length ? args : [fixedNow]));
      }
      static now() { return fixedNow; }
    }
    if (freezeDate) Object.defineProperty(window, 'Date', { value: FixedDate });
    if (!preserveLocalStorage) localStorage.clear();
    const applyVisualPreferences = () => {
      const root = document.documentElement;
      if (!root) return false;
      root.dataset.mode = selectedTheme;
      root.dataset.palette = selectedPalette;
      return true;
    };
    if (!applyVisualPreferences()) {
      const observer = new MutationObserver(() => {
        if (applyVisualPreferences()) observer.disconnect();
      });
      observer.observe(document, { childList: true });
    }
  }, {
    selectedTheme: theme,
    selectedPalette: palette,
    freezeDate: options.freezeDate !== false,
    preserveLocalStorage: options.preserveLocalStorage === true,
  });

  await page.route('**/socket.io/**', route => route.abort());
  await page.route('**/api/**', async route => {
    const url = new URL(route.request().url());
    const path = url.pathname;

    if (path.startsWith('/api/gotalk/media/')) {
      const media = visualMedia.get(path.split('/').pop() || '');
      if (!media) return route.fulfill({ status: 404 });
      const body = await readFile(new URL(`./assets/${media.file}`, import.meta.url));
      return route.fulfill({ body, contentType: media.contentType });
    }
    if (path === '/api/health') return route.fulfill({ json: { database: 'connected' } });
    if (path === '/api/client-attachments/contracts/folders') return route.fulfill({ json: { folders: [], truncated: false } });
    if (path === '/api/client-attachments/contracts/lifecycle/jobs') return route.fulfill({ json: { jobs: [] } });
    if (path === '/api/auth/me') {
      return route.fulfill(authenticated
        ? { json: { user } }
        : { status: 401, json: { error: 'NAO_AUTENTICADO' } });
    }
    if (path === '/api/auth/challenge') {
      return route.fulfill({ json: {
        captchaToken: 'login-captcha-test',
        captchaA: 1,
        captchaB: 1,
        captchaOp: '+',
      } });
    }
    if (path === '/api/auth/login') {
      authenticated = true;
      return route.fulfill({ json: { mfaRequired: false, user } });
    }
    if (path === '/api/config') {
      return route.fulfill({ json: { data: {
        companyName: 'FinancePro Visual',
        units: [unit],
        users: [user],
        clients,
         banks,
         departments,
         bearers,
         financialAccounts,
         admissions,
         collaborators: [],
         series: [],
         modalities: [],
         auditLogs: [],
         admissionTemplates: [],
        userGroups: [],
        theme: {
          headerBgColor: '#31513b',
          headerTextColor: '#ffffff',
          sidebarBgColor: '#243b2c',
          sidebarTextColor: '#ffffff',
          mainContentBgColor: theme === 'dark' ? '#111827' : '#f3f4f6',
        },
        ...configOverrides,
      } } });
    }
    if (path === '/api/user-preferences') {
      if (route.request().method() === 'PUT') {
        const patch = route.request().postDataJSON() as Partial<typeof user.visualPreferences>;
        if (patch.widthScale === 115) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
        Object.assign(user.visualPreferences, patch);
      }
      return route.fulfill({ json: {
        preferences: user.visualPreferences,
        canCustomizeColors: true,
      } });
    }
    if (path === '/api/admission-clients') {
      if (url.searchParams.has('admissionId')) {
        const records = (configOverrides.admissions || admissions) as typeof admissions;
        const admission = records.find(a => a.id === url.searchParams.get('admissionId'));
        return route.fulfill({ json: { admission } });
      }
      const source = (configOverrides.clients || clients) as typeof clients;
      const ids = url.searchParams.get('ids')?.split(',');
      const search = url.searchParams.get('search')?.toLowerCase() || '';
      const data = source.filter(c => ids ? ids.includes(c.id)
        : [c.name, c.document, c.phone].some(v => v?.toLowerCase().includes(search)));
      return route.fulfill({ json: { data, nextCursor: null } });
    }
    if (path === '/api/clients') {
      const data = (configOverrides.clients || clients) as typeof clients;
      return route.fulfill({ json: { data, total: data.length, page: 1, totalPages: 1 } });
    }
     if (path === '/api/banks') {
       return route.fulfill({ json: { data: banks, total: banks.length, page: 1, totalPages: 1 } });
     }
     if (path === '/api/roles') {
       return route.fulfill({ json: { data: roles, total: roles.length, page: 1, totalPages: 1 } });
     }
     if (path === '/api/admissions') {
       const data = (configOverrides.admissions || admissions) as typeof admissions;
       return route.fulfill({ json: { data, total: data.length, page: 1, totalPages: 1 } });
     }
     if (/^\/api\/admissions\/[^/]+$/.test(path)) {
       const records = (configOverrides.admissions || admissions) as typeof admissions;
       const record = records.find(item => item.id === path.split('/').pop());
       if (record) {
         const profiles = (configOverrides.clients || clients) as typeof clients;
         return route.fulfill({ json: { data: {
           ...record,
           clientProfile: profiles.find(client => client.id === record.clientId) || null,
           titularProfile: profiles.find(client => client.id === (record as any).titularClientId) || null,
         } } });
       }
     }
     if (path === '/api/negotiations' || path === '/api/negotiation-goals') {
       return route.fulfill({ json: [] });
     }
    if (path === '/api/units') return route.fulfill({ json: { data: [unit], total: 1 } });
    if (path === '/api/uazapi/capable-units') {
      return route.fulfill({ json: { units: [{ unit_id: unit.id, unit_name: unit.nomeFantasia }] } });
    }
    if (path === '/api/gotalk/client-timeline') {
      return route.fulfill({ json: {
        messages: [
          {
            message_id: 'timeline-1',
            source: 'uazapi',
            body: 'Olá, preciso de ajuda com meu atendimento.',
            direction: 'IN',
            message_type: 'text',
            sent_at: '2026-09-19T16:20:00.000Z',
            uazapi_instance_id: 'visual-instance',
          },
          {
            message_id: 'timeline-2',
            source: 'uazapi',
            body: 'Recebi o documento e vou analisar agora.',
            direction: 'OUT',
            message_type: 'text',
            sent_at: '2026-09-19T16:22:00.000Z',
            operator_name: 'Operador Visual',
            ack_status: 3,
            uazapi_instance_id: 'visual-instance',
          },
          {
            message_id: 'timeline-3',
            source: 'uazapi',
            body: 'Segue o comprovante solicitado.',
            direction: 'IN',
            message_type: 'document',
            sent_at: '2026-09-19T16:24:00.000Z',
            attachment_url: 'https://example.test/comprovante.pdf',
            attachment_name: 'comprovante.pdf',
            attachment_mime_type: 'application/pdf',
            uazapi_instance_id: 'visual-instance',
          },
          ...(palette === 'institutional' ? [] : [
            {
              message_id: 'timeline-4',
              source: 'uazapi',
              body: null,
              direction: 'OUT',
              message_type: 'audio',
              sent_at: '2026-09-19T16:26:00.000Z',
              attachment_url: 'https://example.test/conversa-audio.wav',
              attachment_name: 'retorno.wav',
              attachment_mime_type: 'audio/wav',
              audio_transcript: 'Olá, confirmo que o atendimento foi concluído com sucesso.',
              operator_name: 'Operador Visual',
              ack_status: 3,
              uazapi_instance_id: 'visual-instance',
            },
            {
              message_id: 'timeline-5',
              source: 'uazapi',
              body: 'Imagem do atendimento',
              direction: 'IN',
              message_type: 'image',
              sent_at: '2026-09-19T16:28:00.000Z',
              attachment_url: 'https://example.test/conversa-imagem.png',
              attachment_name: 'atendimento.png',
              attachment_mime_type: 'image/png',
              uazapi_instance_id: 'visual-instance',
            },
            {
              message_id: 'timeline-6',
              source: 'uazapi',
              body: 'Vídeo de confirmação',
              direction: 'OUT',
              message_type: 'video',
              sent_at: '2026-09-19T16:30:00.000Z',
              attachment_url: 'https://example.test/conversa-video.webm',
              attachment_name: 'confirmacao.webm',
              attachment_mime_type: 'video/webm',
              operator_name: 'Operador Visual',
              ack_status: 3,
              uazapi_instance_id: 'visual-instance',
            },
          ]),
        ],
      } });
    }
    if (path.endsWith('/uazapi-send-capability')) {
      return route.fulfill({ json: { hasToken: true } });
    }
    if (path.endsWith('/uazapi-instances')) {
      return route.fulfill({ json: { instances: [{
        instanceId: 'visual-instance',
        phoneNumber: '551140000000',
        isConnected: true,
      }] } });
    }
    if (path === '/api/whatsapp/messages') {
      return route.fulfill({ json: {
        messages: [
          {
            id: 'msg-1',
            source: 'uazapi',
            unit_id: unit.id,
            unit_name: unit.nomeFantasia,
            phone_number: '5511999990001',
            client_name: 'Cliente de Exemplo',
            body: 'Olá, preciso de ajuda com meu atendimento.',
            direction: 'IN',
            message_type: 'text',
            sent_at: '2026-09-19T16:20:00.000Z',
            operator_name: null,
            attachment_name: null,
            ack_status: null,
          },
          ...(palette === 'institutional' ? [] : [{
            id: 'msg-2',
            source: 'uazapi',
            unit_id: unit.id,
            unit_name: unit.nomeFantasia,
            phone_number: '5511999990001',
            client_name: 'Cliente de Exemplo',
            body: 'Recebi o documento e vou analisar agora.',
            direction: 'OUT',
            message_type: 'text',
            sent_at: '2026-09-19T16:22:00.000Z',
            operator_name: 'Operador Visual',
            attachment_name: null,
            ack_status: 3,
          },
          {
            id: 'msg-3',
            source: 'uazapi',
            unit_id: unit.id,
            unit_name: unit.nomeFantasia,
            phone_number: '5511999990001',
            client_name: 'Cliente de Exemplo',
            body: 'Segue o comprovante solicitado.',
            direction: 'IN',
            message_type: 'document',
            sent_at: '2026-09-19T16:24:00.000Z',
            operator_name: null,
            attachment_url: 'https://example.test/comprovante.pdf',
            attachment_name: 'comprovante.pdf',
            attachment_mime_type: 'application/pdf',
            ack_status: null,
          }]),
        ],
        total: 51,
        page: 1,
        pages: 2,
      } });
    }
    if (path === '/api/prospection/filter-options') {
      return route.fulfill({ json: { operators: [], units: [{ id: unit.id, name: unit.nomeFantasia }] } });
    }
    if (path === '/api/prospection/contacts') {
      return route.fulfill({ json: {
        contacts: [{
          id: 'PROS-001',
          phone: '5511999990001',
          contact_name: 'Lead Visual',
          classification: 'LEAD',
          unit_id: unit.id,
          unit_name: unit.nomeFantasia,
          source: 'uazapi',
          last_message: 'Olá, gostaria de saber mais.',
          last_message_at: '2026-09-19T16:20:00.000Z',
        }],
        total: 51,
        page: 1,
        totalPages: 2,
      } });
    }
    if (path === '/api/prospection/dashboard') {
      return route.fulfill({ json: {
        kpi: {
          total_contacts: 12, total_leads: 8, total_recuperacoes: 4,
          total_conversations: 10, total_encerradas: 3, total_agendados: 2,
          interesse_alto: 4, interesse_medio: 3, interesse_baixo: 2, sem_interesse: 1,
        },
        byModalidade: [], byUnit: [], byOperator: [], timeSeries: [],
        groupBy: 'day',
      } });
    }
    if (path === '/api/prospection/dashboard/whatsapp-by-unit') {
      return route.fulfill({ json: { units: [] } });
    }
    if (path.includes('unread-count')) return route.fulfill({ json: { count: 0 } });
    if (path === '/api/messages') return route.fulfill({ json: { data: [], total: 0 } });
    if (path === '/api/audit-logs') return route.fulfill({ json: { data: [] } });
    return route.fulfill({ json: { data: [], count: 0, total: 0 } });
  });
}

export async function simulateOldBundleMissingChunk(page: Page, modulePath: string) {
  const moduleName = modulePath.split('/').pop()?.replace(/\.[^.]+$/, '');
  if (!moduleName) throw new Error(`Não foi possível extrair o nome do módulo: ${modulePath}`);

  const staleChunkName = `${moduleName}-previous-release.js`;
  const staleChunkPattern = new RegExp(`${moduleName}-[\\w-]+\\.js`, 'g');
  let staleBundlesServed = 0;
  let missingChunkRequests = 0;

  await page.route(url => (
    url.pathname.startsWith('/assets/DashboardLayout-')
    && url.pathname.endsWith('.js')
  ), async route => {
    const response = await route.fetch();
    const body = await response.text();
    const staleBody = body.replace(staleChunkPattern, staleChunkName);
    if (staleBody !== body && staleBundlesServed === 0) {
      staleBundlesServed += 1;
      await route.fulfill({
        response,
        body: staleBody,
        headers: { ...response.headers(), 'cache-control': 'no-store' },
      });
      return;
    }
    await route.fulfill({ response });
  });

  page.on('response', response => {
    if (new URL(response.url()).pathname === `/assets/${staleChunkName}`) {
      missingChunkRequests += 1;
    }
  });

  return {
    getStaleBundlesServed: () => staleBundlesServed,
    getMissingChunkRequests: () => missingChunkRequests,
  };
}

export async function stabilize(page: Page) {
  await page.addStyleTag({ content: `
    *, *::before, *::after {
      animation-duration: 0s !important;
      animation-delay: 0s !important;
      transition-duration: 0s !important;
      caret-color: transparent !important;
    }
  ` });
  await page.waitForLoadState('domcontentloaded');
  await expect(page.locator('body')).toBeVisible();
  await page.evaluate(() => document.fonts.ready);
}

export async function expectNoPageClipping(page: Page) {
  const metrics = await page.evaluate(() => ({
    viewport: window.innerWidth,
    page: document.documentElement.scrollWidth,
  }));
  expect(metrics.page, `A página excedeu a viewport em ${metrics.page - metrics.viewport}px`).toBeLessThanOrEqual(metrics.viewport + 1);
}

export async function expectAccessibleContrast(
  root: import('@playwright/test').Locator,
  context: string,
) {
  const failures = await root.evaluate(container => {
    const parseColor = (value: string) => {
      const match = value.match(/rgba?\(([\d.]+)[,\s]+([\d.]+)[,\s]+([\d.]+)(?:[,\s/]+([\d.]+))?\)/);
      return match
        ? [Number(match[1]), Number(match[2]), Number(match[3]), match[4] === undefined ? 1 : Number(match[4])]
        : null;
    };
    const blend = (front: number[], back: number[]) => {
      const alpha = front[3] + back[3] * (1 - front[3]);
      return [
        (front[0] * front[3] + back[0] * back[3] * (1 - front[3])) / alpha,
        (front[1] * front[3] + back[1] * back[3] * (1 - front[3])) / alpha,
        (front[2] * front[3] + back[2] * back[3] * (1 - front[3])) / alpha,
        alpha,
      ];
    };
    const backgroundFor = (element: Element) => {
      let result = [255, 255, 255, 1];
      const layers: number[][] = [];
      for (let current: Element | null = element; current; current = current.parentElement) {
        const color = parseColor(getComputedStyle(current).backgroundColor);
        if (color && color[3] > 0) layers.push(color);
      }
      for (const layer of layers.reverse()) result = blend(layer, result);
      return result;
    };
    const luminance = (color: number[]) => {
      const channels = color.slice(0, 3).map(channel => {
        const value = channel / 255;
        return value <= 0.04045 ? value / 12.92 : ((value + 0.055) / 1.055) ** 2.4;
      });
      return channels[0] * 0.2126 + channels[1] * 0.7152 + channels[2] * 0.0722;
    };
    const ratio = (first: number[], second: number[]) => {
      const lighter = Math.max(luminance(first), luminance(second));
      const darker = Math.min(luminance(first), luminance(second));
      return (lighter + 0.05) / (darker + 0.05);
    };
    const effectiveOpacity = (element: Element) => {
      let opacity = 1;
      for (let current: Element | null = element; current; current = current.parentElement) {
        const currentOpacity = Number.parseFloat(getComputedStyle(current).opacity);
        opacity *= Number.isNaN(currentOpacity) ? 1 : currentOpacity;
      }
      return opacity;
    };
    const elements = [container, ...Array.from(container.querySelectorAll('*'))];
    const textFailures = elements.flatMap(element => {
      const htmlElement = element as HTMLElement;
      const style = getComputedStyle(htmlElement);
      const rect = htmlElement.getBoundingClientRect();
      if (style.visibility === 'hidden' || style.display === 'none' || rect.width === 0 || rect.height === 0) return [];
      if ((element as HTMLButtonElement | HTMLInputElement | HTMLSelectElement).disabled) return [];
      const directText = Array.from(element.childNodes)
        .filter(node => node.nodeType === Node.TEXT_NODE)
        .map(node => node.textContent?.trim() || '')
        .filter(Boolean)
        .join(' ');
      const controlText = element.matches('button, a, label')
        ? htmlElement.innerText.trim()
        : '';
      const visibleText = directText
        || controlText
        || (element as HTMLInputElement).placeholder
        || (element as HTMLInputElement).value
        || '';
      const accessibleName = visibleText
        || element.getAttribute('aria-label')
        || element.getAttribute('title')
        || '';
      if (!visibleText && !accessibleName && !element.matches('button')) return [];
      const foreground = parseColor(style.color);
      if (!foreground) return [];
      const background = backgroundFor(element);
      foreground[3] *= effectiveOpacity(element);
      const actual = ratio(blend(foreground, background), background);
      const fontSize = Number.parseFloat(style.fontSize);
      const fontWeight = Number.parseInt(style.fontWeight, 10) || 400;
      const largeText = fontSize >= 24 || (fontSize >= 18.66 && fontWeight >= 700);
      const minimum = visibleText ? (largeText ? 3 : 4.5) : 3;
      return actual + 0.01 < minimum
        ? [`${element.tagName.toLowerCase()} "${accessibleName.slice(0, 60)}": ${actual.toFixed(2)} < ${minimum}`]
        : [];
    });
    const svgFailures = Array.from(container.matches('svg') ? [container] : container.querySelectorAll('svg'))
      .flatMap(svg => {
        const svgRect = svg.getBoundingClientRect();
        const svgStyle = getComputedStyle(svg);
        if (svgStyle.visibility === 'hidden' || svgStyle.display === 'none'
          || svgRect.width === 0 || svgRect.height === 0) return [];
        const control = svg.closest('button, a, [role="button"]');
        if ((control as HTMLButtonElement | null)?.disabled) return [];
        const accessibleName = svg.getAttribute('aria-label')
          || control?.getAttribute('aria-label')
          || control?.getAttribute('title')
          || (control as HTMLElement | null)?.innerText.trim()
          || 'ícone sem nome';
        const controlColor = parseColor(getComputedStyle(control || svg).color);
        const paints = new Map<string, { properties: Set<string>; actual: number }>();
        const paintedElements = [svg, ...Array.from(svg.querySelectorAll('*'))];
        for (const paintedElement of paintedElements) {
          const style = getComputedStyle(paintedElement);
          if (style.visibility === 'hidden' || style.display === 'none') continue;
          const background = backgroundFor(paintedElement);
          for (const property of ['fill', 'stroke'] as const) {
            if (property === 'stroke' && Number.parseFloat(style.strokeWidth) === 0) continue;
            const paint = parseColor(style[property]);
            if (!paint || paint[3] === 0 || (controlColor
              && paint.every((channel, index) => Math.abs(channel - controlColor[index]) < 0.01))) continue;
            paint[3] *= effectiveOpacity(paintedElement);
            const actual = ratio(blend(paint, background), background);
            if (actual + 0.01 >= 3) continue;
            const key = `${paint.map(value => value.toFixed(3)).join(',')}|${background.map(value => value.toFixed(3)).join(',')}`;
            const failure = paints.get(key) || { properties: new Set<string>(), actual };
            failure.properties.add(property);
            paints.set(key, failure);
          }
        }
        return Array.from(paints.values()).map(({ properties, actual }) => (
          `svg ${Array.from(properties).join('/')} "${accessibleName.slice(0, 60)}": ${actual.toFixed(2)} < 3`
        ));
      });
    return [...textFailures, ...svgFailures];
  });
  expect(failures, `Contraste insuficiente em ${context}:\n${failures.join('\n')}`).toEqual([]);
}

export async function expectAccessibleContrastInState(
  root: import('@playwright/test').Locator,
  target: import('@playwright/test').Locator,
  state: 'hover' | 'focus',
  context: string,
) {
  await expect(target).toBeVisible();
  if (state === 'hover') await target.hover();
  else await target.focus();
  await expect.poll(
    () => target.evaluate((element, expectedState) => (
      expectedState === 'hover'
        ? element.matches(':hover')
        : element.matches(':focus-visible')
    ), state),
    { message: `O controle não entrou no estado de ${state}` },
  ).toBe(true);
  await expectAccessibleContrast(root, `${context} em ${state}`);
}

export async function openMobileMenuIfNeeded(page: Page, width: number) {
  if (width < 900) {
    await page.getByTitle('Menu').click();
    await expect(page.locator('aside')).toBeInViewport();
  }
}

export async function closeHelpIfOpen(page: Page) {
  const close = page.locator('button[aria-label="Fechar"]:visible').first();
  if (await close.count()) await close.dispatchEvent('click');
}

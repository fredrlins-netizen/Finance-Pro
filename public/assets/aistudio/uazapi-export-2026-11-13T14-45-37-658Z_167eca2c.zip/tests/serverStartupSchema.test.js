import assert from 'node:assert/strict';
import { execFileSync, spawn } from 'node:child_process';
import { mkdtemp, readdir, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import test from 'node:test';
import pg from 'pg';
import { diffContracts, readCatalogSnapshot } from '../scripts/schema-contract.js';

const { Client: PgClient } = pg;
const projectRoot = path.resolve(new URL('..', import.meta.url).pathname);

async function schemaSignature(client) {
  const { rows } = await client.query(`
    SELECT md5(string_agg(signature, E'\n' ORDER BY signature)) AS signature
    FROM (
      SELECT 'column|' || table_name || '|' || column_name || '|' ||
             data_type || '|' || COALESCE(udt_name, '') || '|' ||
             is_nullable || '|' || COALESCE(column_default, '') AS signature
      FROM information_schema.columns
      WHERE table_schema = 'public'
      UNION ALL
      SELECT 'constraint|' || conrelid::regclass::text || '|' || conname || '|' ||
             pg_get_constraintdef(oid)
      FROM pg_constraint
      WHERE connamespace = 'public'::regnamespace
      UNION ALL
      SELECT 'index|' || schemaname || '|' || tablename || '|' || indexname || '|' || indexdef
      FROM pg_indexes
      WHERE schemaname = 'public'
      UNION ALL
      SELECT 'view|' || schemaname || '|' || viewname || '|' || definition
      FROM pg_views
      WHERE schemaname = 'public'
    ) schema_objects
  `);
  return rows[0].signature;
}

test('iniciar o servidor após as migrações não altera a assinatura do esquema', { timeout: 120_000 }, async t => {
  const postgresDir = await mkdtemp(path.join(tmpdir(), 'startup-schema-pg-'));
  const socketDir = path.join(postgresDir, 'socket');
  const dataDir = path.join(postgresDir, 'data');
  const port = 20_000 + Math.floor(Math.random() * 20_000);
  let postgresStarted = false;
  let server;
  const clients = [];

  t.after(async () => {
    if (server && server.exitCode === null) {
      server.kill('SIGTERM');
      await new Promise(resolve => server.once('exit', resolve));
    }
    await Promise.all(clients.map(client => client.end()));
    if (postgresStarted) {
      execFileSync('pg_ctl', ['-D', dataDir, '-m', 'immediate', '-w', 'stop'], { stdio: 'ignore' });
    }
    await rm(postgresDir, { recursive: true, force: true });
  });

  execFileSync('mkdir', ['-p', socketDir]);
  execFileSync('initdb', ['-D', dataDir, '-A', 'trust', '-U', 'postgres', '--no-locale'], { stdio: 'ignore' });
  execFileSync('pg_ctl', ['-D', dataDir, '-o', `-F -k ${socketDir} -p ${port}`, '-w', 'start'], { stdio: 'ignore' });
  postgresStarted = true;

  const admin = new PgClient({ host: socketDir, port, user: 'postgres', database: 'postgres' });
  clients.push(admin);
  await admin.connect();
  await admin.query('CREATE DATABASE startup_schema');
  const databaseUrl = `postgresql://postgres@localhost:${port}/startup_schema?host=${encodeURIComponent(socketDir)}`;

  const migrationNames = (await readdir(new URL('../migrations/', import.meta.url)))
    .filter(filename => filename.endsWith('.sql'))
    .sort();
  const database = new PgClient({ connectionString: databaseUrl });
  clients.push(database);
  await database.connect();
  await database.query(`
    CREATE TABLE migrations_log (
      id SERIAL PRIMARY KEY,
      filename VARCHAR(255) NOT NULL UNIQUE,
      applied_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
  for (const filename of migrationNames.filter(name => name < '051_startup_schema.sql')) {
    await database.query(await readFile(new URL(`../migrations/${filename}`, import.meta.url), 'utf8'));
    await database.query('INSERT INTO migrations_log(filename) VALUES ($1)', [filename]);
  }

  const clientId = '10000000-0000-4000-8000-000000000001';
  await database.query('INSERT INTO clients(id, name) VALUES ($1, $2)', [clientId, 'Preservado']);
  await database.query(`
    CREATE VIEW v_gotalk_client_timeline AS
    SELECT gm.id AS message_id,
           gm.gotalk_message_id,
           gm.phone_number,
           gm.direction,
           gm.body,
           gm.message_type,
           gm.attachment_url,
           gm.attachment_name,
           gm.attachment_mime_type,
           gm.audio_transcript,
           gm.ack_status,
           gm.operator_name AS message_operator_name,
           gm.department AS message_department,
           gm.sent_at,
           gm.client_id,
           NULL::UUID AS attendance_history_id
    FROM gotalk_messages gm
  `);
  const migration051 = await readFile(new URL('../migrations/051_startup_schema.sql', import.meta.url), 'utf8');
  await database.query('BEGIN');
  await database.query(migration051);
  await database.query("INSERT INTO migrations_log(filename) VALUES ('051_startup_schema.sql')");
  await database.query('COMMIT');
  for (const filename of migrationNames.filter(name => name > '051_startup_schema.sql')) {
    await database.query('BEGIN');
    await database.query(await readFile(new URL(`../migrations/${filename}`, import.meta.url), 'utf8'));
    await database.query('INSERT INTO migrations_log(filename) VALUES ($1)', [filename]);
    await database.query('COMMIT');
  }
  assert.equal((await database.query('SELECT name FROM clients WHERE id = $1', [clientId])).rows[0].name, 'Preservado');

  const requiredTables = await database.query(`
    SELECT table_name FROM information_schema.tables
    WHERE table_schema = 'public'
      AND table_name = ANY($1::text[])
  `, [['gotalk_operator_attendances', 'gotalk_attendance_history']]);
  assert.deepEqual(
    requiredTables.rows.map(row => row.table_name).sort(),
    ['gotalk_attendance_history', 'gotalk_operator_attendances'],
  );
  const requiredColumns = await database.query(`
    SELECT table_name, column_name
    FROM information_schema.columns
    WHERE table_schema = 'public'
      AND (table_name, column_name) IN (
        ('gotalk_messages', 'gotalk_attendance_id_ext'),
        ('gotalk_messages', 'attendance_id'),
        ('gotalk_messages', 'attendance_history_id'),
        ('gotalk_messages', 'idwpp'),
        ('gotalk_messages', 'uazapi_instance_id'),
        ('gotalk_messages', 'gotalk_channel_uuid'),
        ('gotalk_attendance_history', 'messages_last_fetched_at'),
        ('gotalk_attendance_history', 'gotalk_channel_uuid'),
        ('gotalk_operator_attendances', 'gotalk_channel_uuid'),
        ('background_jobs', 'lease_token')
      )
  `);
  assert.equal(requiredColumns.rows.length, 10);
  const requiredViews = await database.query(`
    SELECT viewname FROM pg_views
    WHERE schemaname = 'public'
      AND viewname = ANY($1::text[])
  `, [['v_gotalk_client_timeline', 'v_gotalk_attendance_summary']]);
  assert.deepEqual(
    requiredViews.rows.map(row => row.viewname).sort(),
    ['v_gotalk_attendance_summary', 'v_gotalk_client_timeline'],
  );

  const operatorId = '20000000-0000-4000-8000-000000000001';
  const attendanceId = '30000000-0000-4000-8000-000000000001';
  const messageId = '40000000-0000-4000-8000-000000000001';
  await database.query(
    `INSERT INTO gotalk_operators (id, gotalk_operator_id, name)
     VALUES ($1, 'startup-op', 'Startup Operator')`,
    [operatorId],
  );
  await database.query(
    `INSERT INTO gotalk_attendance_history
       (id, gotalk_attendance_id, operator_db_id, client_number, status)
     VALUES ($1, 'startup-attendance', $2, '5581999999999', 'in_attendance')`,
    [attendanceId, operatorId],
  );
  await database.query(
    `INSERT INTO gotalk_operator_attendances
       (gotalk_attendance_id, operator_db_id, client_number)
     VALUES ('startup-attendance', $1, '5581999999999')`,
    [operatorId],
  );
  await database.query(
    `INSERT INTO gotalk_messages
       (id, gotalk_message_id, client_id, phone_number, direction, body, message_type,
        attendance_history_id, idwpp)
     VALUES ($1, 'startup-message', $2, '5581999999999', 'IN', 'startup', 'TEXT', $3, 'wpp-startup')`,
    [messageId, clientId, attendanceId],
  );
  const joined = await database.query(`
    SELECT s.attendance_history_id, s.message_count, t.message_id
    FROM v_gotalk_attendance_summary s
    JOIN v_gotalk_client_timeline t ON t.attendance_history_id = s.attendance_history_id
    WHERE s.attendance_history_id = $1
  `, [attendanceId]);
  assert.equal(joined.rows[0].message_count, '1');
  assert.equal(joined.rows[0].message_id, messageId);

  // A clean install and a representative upgraded database must expose the
  // same complete PostgreSQL catalog, not only the same tables/columns.
  await admin.query('CREATE DATABASE startup_schema_fresh');
  const freshDatabaseUrl = `postgresql://postgres@localhost:${port}/startup_schema_fresh?host=${encodeURIComponent(socketDir)}`;
  const freshDatabase = new PgClient({ connectionString: freshDatabaseUrl });
  clients.push(freshDatabase);
  await freshDatabase.connect();
  await freshDatabase.query(`
    CREATE TABLE migrations_log (
      id SERIAL PRIMARY KEY,
      filename VARCHAR(255) NOT NULL UNIQUE,
      applied_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);
  for (const filename of migrationNames) {
    await freshDatabase.query('BEGIN');
    await freshDatabase.query(await readFile(new URL(`../migrations/${filename}`, import.meta.url), 'utf8'));
    await freshDatabase.query('INSERT INTO migrations_log(filename) VALUES ($1)', [filename]);
    await freshDatabase.query('COMMIT');
  }
  const parityDiff = diffContracts(
    await readCatalogSnapshot(freshDatabase),
    await readCatalogSnapshot(database),
  );
  assert.deepEqual(parityDiff, [], `fresh install e upgrade divergiram:\n${JSON.stringify(parityDiff, null, 2)}`);

  const before = await schemaSignature(database);
  const serverPort = 41_000 + Math.floor(Math.random() * 10_000);
  server = spawn(process.execPath, ['server/index.js'], {
    cwd: projectRoot,
    env: {
      ...process.env,
      DATABASE_URL: databaseUrl,
      NODE_ENV: 'test',
      PORT: String(serverPort),
      JWT_SECRET: 'startup-schema-test-secret',
      SESSION_SECRET: 'startup-schema-test-secret',
      ADMIN_RECOVERY_TOKEN: 'startup-schema-recovery-token',
      ENCRYPTION_KEY: '0123456789abcdef0123456789abcdef',
      GOTALK_LOGIN: '',
      GOTALK_PASSWORD: '',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let output = '';
  server.stdout.on('data', chunk => { output += chunk; });
  server.stderr.on('data', chunk => { output += chunk; });
  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(`servidor não iniciou:\n${output}`)), 30_000);
    const inspect = () => {
      if (output.includes('API server running')) {
        clearTimeout(timeout);
        resolve();
      }
    };
    server.stdout.on('data', inspect);
    server.stderr.on('data', inspect);
    server.once('exit', code => {
      clearTimeout(timeout);
      reject(new Error(`servidor encerrou com ${code}:\n${output}`));
    });
  });
  server.kill('SIGTERM');
  await new Promise(resolve => server.once('exit', resolve));

  const after = await schemaSignature(database);
  assert.equal(after, before, 'o boot alterou objetos do esquema public');

  await database.query('ALTER TABLE client_attachments RENAME COLUMN target_id TO target_id_missing');
  const productionPort = serverPort + 1;
  server = spawn(process.execPath, ['server/index.js'], {
    cwd: projectRoot,
    env: {
      ...process.env,
      DATABASE_URL: databaseUrl,
      APP_DB_USER: 'postgres',
      APP_DB_PASSWORD: 'startup-test-password',
      NODE_ENV: 'production',
      PORT: String(productionPort),
      JWT_SECRET: 'startup-schema-test-secret',
      SESSION_SECRET: 'startup-schema-test-secret',
      ADMIN_RECOVERY_TOKEN: 'startup-schema-recovery-token',
      ENCRYPTION_KEY: '0123456789abcdef0123456789abcdef',
      GOTALK_LOGIN: '',
      GOTALK_PASSWORD: '',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let productionOutput = '';
  server.stdout.on('data', chunk => { productionOutput += chunk; });
  server.stderr.on('data', chunk => { productionOutput += chunk; });
  await new Promise((resolve, reject) => {
    const timeout = setTimeout(resolve, 30_000);
    server.once('exit', code => {
      clearTimeout(timeout);
      assert.notEqual(code, 0, `servidor iniciou apesar de coluna obrigatória ausente:\n${productionOutput}`);
      assert.match(productionOutput, /Schema de produção incompatível/);
      resolve();
    });
  });
  await database.query('ALTER TABLE client_attachments RENAME COLUMN target_id_missing TO target_id');

  await database.query('ALTER TABLE background_jobs DROP COLUMN lease_token');
  const leaseSchemaPort = productionPort + 2;
  server = spawn(process.execPath, ['server/index.js'], {
    cwd: projectRoot,
    env: {
      ...process.env,
      DATABASE_URL: databaseUrl,
      APP_DB_USER: 'postgres',
      APP_DB_PASSWORD: 'startup-test-password',
      NODE_ENV: 'production',
      PORT: String(leaseSchemaPort),
      JWT_SECRET: 'startup-schema-test-secret',
      SESSION_SECRET: 'startup-schema-test-secret',
      ADMIN_RECOVERY_TOKEN: 'startup-recovery-token',
      ENCRYPTION_KEY: '0123456789abcdef0123456789abcdef',
      GOTALK_LOGIN: '',
      GOTALK_PASSWORD: '',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let leaseSchemaOutput = '';
  server.stdout.on('data', chunk => { leaseSchemaOutput += chunk; });
  server.stderr.on('data', chunk => { leaseSchemaOutput += chunk; });
  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(
      `worker iniciou sem lease_token:\n${leaseSchemaOutput}`,
    )), 30_000);
    server.once('exit', code => {
      clearTimeout(timeout);
      assert.notEqual(code, 0, 'servidor iniciou sem a coluna de proteção de lease');
      assert.match(leaseSchemaOutput, /background_jobs\.lease_token/);
      resolve();
    });
  });
  await database.query('ALTER TABLE background_jobs ADD COLUMN lease_token UUID');

  await database.query(`
    CREATE ROLE startup_app_user LOGIN NOSUPERUSER NOCREATEDB NOCREATEROLE NOINHERIT;
    GRANT CONNECT ON DATABASE startup_schema TO startup_app_user;
    GRANT USAGE ON SCHEMA public TO startup_app_user;
    GRANT SELECT ON ALL TABLES IN SCHEMA public TO startup_app_user;
    GRANT SELECT, INSERT, DELETE ON data_import_queue_events TO startup_app_user;
    GRANT SELECT, INSERT, DELETE ON data_import_queue_metric_failures TO startup_app_user;
    GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO startup_app_user;
  `).catch(async error => {
    if (error.code !== '42710') throw error;
  });
  const restrictedDatabaseUrl = databaseUrl.replace(
    'postgresql://postgres@',
    'postgresql://startup_app_user@',
  );
  // Reproduce Publish creating a table without the runtime role's grants.
  // Startup must fail closed, preserve its fatal diagnostic, and never repair
  // privileges itself. Restore only through the disposable admin test client.
  for (const table of ['data_import_queue_events', 'data_import_queue_metric_failures']) {
    await database.query(`REVOKE INSERT ON ${table} FROM startup_app_user`);
    server = spawn(process.execPath, ['server/index.js'], {
      cwd: projectRoot,
      env: {
        ...process.env,
        DATABASE_URL: databaseUrl,
        APP_DB_USER: 'startup_app_user',
        APP_DB_PASSWORD: 'startup-test-password',
        NODE_ENV: 'production',
        PORT: String(productionPort + 5),
        JWT_SECRET: 'startup-schema-test-secret',
        SESSION_SECRET: 'startup-schema-test-secret',
        ENCRYPTION_KEY: '0123456789abcdef0123456789abcdef',
        GOTALK_LOGIN: '',
        GOTALK_PASSWORD: '',
      },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    let output = '';
    server.stdout.on('data', chunk => { output += chunk; });
    server.stderr.on('data', chunk => { output += chunk; });
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        reject(new Error(`servidor não recusou permissões ausentes em ${table}:\n${output}`));
      }, 30_000);
      server.once('close', code => {
        clearTimeout(timeout);
        try {
          assert.equal(code, 1);
          assert.ok(output.includes(`permissões SELECT, INSERT e DELETE em public.${table}`), output);
          assert.ok(!output.includes('API server running'), output);
          resolve();
        } catch (error) {
          reject(error);
        }
      });
    });
    assert.equal(
      (await database.query(`SELECT has_table_privilege('startup_app_user', '${table}', 'INSERT') AS allowed`)).rows[0].allowed,
      false,
      'a inicialização não deve conceder permissões',
    );
    await database.query(`GRANT INSERT ON ${table} TO startup_app_user`);
  }
  const restrictedPort = productionPort + 1;
  server = spawn(process.execPath, ['server/index.js'], {
    cwd: projectRoot,
    env: {
      ...process.env,
      DATABASE_URL: databaseUrl,
      APP_DB_USER: 'startup_app_user',
      APP_DB_PASSWORD: 'startup-test-password',
      NODE_ENV: 'production',
      PORT: String(restrictedPort),
      JWT_SECRET: 'startup-schema-test-secret',
      SESSION_SECRET: 'startup-schema-test-secret',
      ADMIN_RECOVERY_TOKEN: 'startup-schema-recovery-token',
      ENCRYPTION_KEY: '0123456789abcdef0123456789abcdef',
      GOTALK_LOGIN: '',
      GOTALK_PASSWORD: '',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let restrictedOutput = '';
  server.stdout.on('data', chunk => { restrictedOutput += chunk; });
  server.stderr.on('data', chunk => { restrictedOutput += chunk; });
  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(`servidor restrito não iniciou:\n${restrictedOutput}`)), 30_000);
    const inspect = () => {
      if (restrictedOutput.includes('API server running')) {
        clearTimeout(timeout);
        resolve();
      }
    };
    server.stdout.on('data', inspect);
    server.stderr.on('data', inspect);
    server.once('exit', code => {
      clearTimeout(timeout);
      reject(new Error(`servidor restrito encerrou com ${code}:\n${restrictedOutput}`));
    });
  });
  // Startup must remain usable with the restricted role. Administrative
  // mutation calls are intentionally not part of the production boot path;
  // the migration log assertion below proves startup remained read-only.
  server.kill('SIGTERM');
  await new Promise(resolve => server.once('exit', resolve));
  assert.deepEqual(
    (await database.query(
      `SELECT filename FROM migrations_log
       WHERE filename = ANY($1::text[])`,
      [['050_client_attachment_text_target_id.sql', '051_startup_schema.sql']],
    )).rows.map(row => row.filename).sort(),
    ['050_client_attachment_text_target_id.sql', '051_startup_schema.sql'],
    'o boot de produção não deve alterar migrations_log',
  );

  const privilegedPort = restrictedPort + 1;
  server = spawn(process.execPath, ['server/index.js'], {
    cwd: projectRoot,
    env: {
      ...process.env,
      DATABASE_URL: databaseUrl,
      APP_DB_USER: 'postgres',
      APP_DB_PASSWORD: 'startup-test-password',
      NODE_ENV: 'production',
      PORT: String(privilegedPort),
      JWT_SECRET: 'startup-schema-test-secret',
      SESSION_SECRET: 'startup-schema-test-secret',
      ADMIN_RECOVERY_TOKEN: 'startup-schema-recovery-token',
      ENCRYPTION_KEY: '0123456789abcdef0123456789abcdef',
      GOTALK_LOGIN: '',
      GOTALK_PASSWORD: '',
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let privilegedOutput = '';
  server.stdout.on('data', chunk => { privilegedOutput += chunk; });
  server.stderr.on('data', chunk => { privilegedOutput += chunk; });
  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => reject(new Error(`role privilegiado não foi recusado:\n${privilegedOutput}`)), 30_000);
    server.once('exit', code => {
      clearTimeout(timeout);
      assert.notEqual(code, 0);
      assert.match(privilegedOutput, /role privilegiado/);
      resolve();
    });
  });
});
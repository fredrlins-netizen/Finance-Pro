import React, { useState, useEffect, useCallback, lazy, Suspense } from 'react';
import { DEFAULT_PORTAL_CONFIG, DEFAULT_AUDIT_CHECK_ITEMS } from './constants';
import { PortalConfig, User } from './types';
import MarketingPanel from './components/login/MarketingPanel';
import LoginForm from './components/login/LoginForm';
import { SecurityProvider, useSecurity } from './contexts/SecurityContext';
import { AuditProvider } from './contexts/AuditContext';
import { KeyboardShortcutProvider } from './contexts/KeyboardShortcutContext';
import { MessagingProvider } from './contexts/MessagingContext';
import { GotalkProvider } from './contexts/GotalkContext';
import { SocketProvider, useSocket } from './contexts/SocketContext';
import { VisualPreferencesProvider } from './contexts/VisualPreferencesContext';
import { SupabaseService } from './services/supabaseService';
import { logout as authLogout, restoreSession } from './services/authService';
import ServiceWorkerUpdater from './components/ui/ServiceWorkerUpdater';
import ErrorBoundary from './components/shared/ErrorBoundary';

const DashboardLayout = lazy(() => import('./components/layout/DashboardLayout'));

type BucketAdminCancellationNotice = {
  authorId: string;
  operationId: string;
  action: 'trash' | 'restore' | 'purge';
  processed: number;
  total: number;
  failureCount: number;
  cancelledByName?: string | null;
};

const bucketAdminActionLabels: Record<BucketAdminCancellationNotice['action'], string> = {
  trash: 'Mover para a lixeira',
  restore: 'Restaurar arquivos',
  purge: 'Excluir definitivamente',
};

function BucketAdminCancellationNotifications() {
  const { socket } = useSocket();
  const { currentUser, addToast } = useSecurity();

  useEffect(() => {
    if (!socket || !currentUser?.id) return;
    const onCancelled = (notice: BucketAdminCancellationNotice) => {
      if (notice.authorId !== currentUser.id) return;
      const actor = notice.cancelledByName ? ` por ${notice.cancelledByName}` : '';
      addToast(
        'warning',
        'Operação cancelada',
        `${bucketAdminActionLabels[notice.action] || 'Operação'} (ID ${notice.operationId}) foi cancelada${actor}. Progresso preservado: ${notice.processed}/${notice.total} arquivo(s), ${notice.failureCount} falha(s).`,
      );
    };
    socket.on('bucket-admin:operation-cancelled', onCancelled);
    return () => { socket.off('bucket-admin:operation-cancelled', onCancelled); };
  }, [socket, currentUser?.id, addToast]);

  return null;
}

function mergeConfigWithDefaults(raw: PortalConfig): PortalConfig {
  return {
    ...DEFAULT_PORTAL_CONFIG,
    ...raw,
    theme: { ...DEFAULT_PORTAL_CONFIG.theme, ...(raw.theme || {}) },
    users: raw.users ?? DEFAULT_PORTAL_CONFIG.users,
    userGroups: raw.userGroups ?? DEFAULT_PORTAL_CONFIG.userGroups,
    collaborators: raw.collaborators ?? DEFAULT_PORTAL_CONFIG.collaborators,
    banks: raw.banks ?? DEFAULT_PORTAL_CONFIG.banks,
    clients: raw.clients ?? DEFAULT_PORTAL_CONFIG.clients,
    roles: raw.roles ?? DEFAULT_PORTAL_CONFIG.roles,
    modalities: raw.modalities ?? DEFAULT_PORTAL_CONFIG.modalities,
    products: raw.products ?? DEFAULT_PORTAL_CONFIG.products,
    series: raw.series ?? DEFAULT_PORTAL_CONFIG.series,
    admissions: raw.admissions ?? DEFAULT_PORTAL_CONFIG.admissions,
    auditCheckItems: (raw.auditCheckItems && raw.auditCheckItems.length > 0)
      ? raw.auditCheckItems
      : DEFAULT_AUDIT_CHECK_ITEMS,
  };
}

// ── Domain-separated state slices ─────────────────────────────────────────
// Instead of a single monolithic appState, we hold each concern in its own
// useState so that a change in one slice (e.g. authentication flag) does NOT
// create new references for unrelated slices (config, currentUser).
// This prevents cascading re-renders across all context providers that receive
// config/currentUser as props, because their props remain referentially stable
// when only an unrelated slice changes.

const App: React.FC = () => {
  const [config, setConfig] = useState<PortalConfig>(DEFAULT_PORTAL_CONFIG);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [logoutReason, setLogoutReason] = useState<'idle' | 'manual' | 'schedule_end' | undefined>(undefined);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const init = async () => {
      const [connected, restoredUser] = await Promise.all([
        SupabaseService.isConnected(),
        restoreSession(),
      ]);

      if (restoredUser) {
        if (restoredUser.currentUnitId) {
          localStorage.setItem('finpro_unit', JSON.stringify(restoredUser.currentUnitId));
        }
        setCurrentUser(restoredUser);
        setIsAuthenticated(true);
        setLogoutReason(undefined);
      }

      if (connected) {
        const saved = await SupabaseService.loadConfig();
        if (saved) {
          setConfig(mergeConfigWithDefaults(saved));
        }
      }

      setIsLoading(false);
    };
    init();
  }, []);

  const handleLoginSuccess = useCallback((user: User) => {
    if (user.currentUnitId) {
      localStorage.setItem('finpro_unit', JSON.stringify(user.currentUnitId));
    } else {
      localStorage.removeItem('finpro_unit');
    }
    setCurrentUser(user);
    setIsAuthenticated(true);
    setLogoutReason(undefined);
    // Config loaded before login is partial (branding-only). Reload with auth
    // to get the full config (users, groups, collaborators, etc.) needed by the
    // dashboard. Using a short delay to let the auth cookie propagate.
    setTimeout(() => {
      SupabaseService.loadConfig().then(saved => {
        if (saved) setConfig(mergeConfigWithDefaults(saved));
      }).catch(() => {});
    }, 50);
  }, []);

  const handleLogout = useCallback((reason?: 'idle' | 'manual' | 'schedule_end') => {
    authLogout().catch(() => {});
    localStorage.removeItem('finpro_unit');
    localStorage.removeItem('invicta_default_series');
    localStorage.removeItem('financepro_training_progress');
    setCurrentUser(null);
    setIsAuthenticated(false);
    setLogoutReason(reason || 'manual');
  }, []);

  useEffect(() => {
    const logoUrl = config.logoUrl;
    let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
    if (!link) {
      link = document.createElement('link');
      link.rel = 'icon';
      document.head.appendChild(link);
    }
    if (logoUrl) {
      link.href = logoUrl;
    } else {
      link.href = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="6" fill="%234a7c59"/><text x="16" y="22" font-size="18" fill="white" text-anchor="middle" font-family="Arial" font-weight="bold">F</text></svg>';
    }
  }, [config.logoUrl]);

  const refreshConfig = useCallback(async () => {
    try {
      const fresh = await SupabaseService.loadConfig();
      if (fresh) setConfig(mergeConfigWithDefaults(fresh));
    } catch {
    }
  }, []);

  const handleAppendAuditLog = useCallback(() => {}, []);

  if (isLoading) {
    return (
      <>
        <ServiceWorkerUpdater />
        <div className="flex h-screen w-full items-center justify-center bg-gray-100">
          <div className="text-center">
            <div className="inline-block w-12 h-12 border-4 border-moss-200 border-t-moss-700 rounded-full animate-spin mb-4"></div>
            <p className="text-gray-600 font-medium">Carregando FinancePro...</p>
            <p className="text-gray-400 text-sm mt-1">Conectando ao banco de dados</p>
          </div>
        </div>
      </>
    );
  }

  if (isAuthenticated) {
    return (
      <VisualPreferencesProvider currentUser={currentUser}>
      <KeyboardShortcutProvider>
      <SecurityProvider currentUser={currentUser} config={config}>
      <SocketProvider>
        <BucketAdminCancellationNotifications />
        <MessagingProvider currentUser={currentUser} config={config}>
        <GotalkProvider>
        <AuditProvider currentUser={currentUser} config={config} onAppendAuditLog={handleAppendAuditLog}>
            <ErrorBoundary label="Dashboard">
            <Suspense fallback={<div className="flex h-screen w-full items-center justify-center bg-gray-100"><div className="text-center"><div className="inline-block w-12 h-12 border-4 border-moss-200 border-t-moss-700 rounded-full animate-spin mb-4"></div><p className="text-gray-600 font-medium">Carregando FinancePro...</p></div></div>}>
            <DashboardLayout 
              config={config} 
              currentUser={currentUser}
              onLogout={handleLogout}
              onRefresh={refreshConfig}
            />
            </Suspense>
            </ErrorBoundary>
        </AuditProvider>
        </GotalkProvider>
        </MessagingProvider>
      </SocketProvider>
      </SecurityProvider>
      </KeyboardShortcutProvider>
      </VisualPreferencesProvider>
    );
  }

  return (
    <>
      <ServiceWorkerUpdater />
      <div className="flex flex-col min-[900px]:flex-row w-full h-[100dvh] bg-gray-100 font-sans overflow-y-auto min-[900px]:overflow-hidden">
        <MarketingPanel config={config} />
        <LoginForm config={config} onLoginSuccess={handleLoginSuccess} logoutReason={logoutReason} />
      </div>
    </>
  );
};

export default App;

import React, { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { Client, Collaborator, Admission, AdmissionAttachment, AuditLog, FinancialRecord, TitleStatus, TitleType, SettlementHistory, UserGroup, Appointment, ClientFicha } from '../../types';
import AuditLogButton from '../ui/AuditLogButton';
import AdmissionViewerModal from '../ui/AdmissionViewerModal';
import ConfirmDeleteModal from '../ui/ConfirmDeleteModal';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { useMessaging } from '../../contexts/MessagingContext';
import { useSocket } from '../../contexts/SocketContext';
import { formatCurrencyBRL } from '../../utils/currencyUtils';
import BlockedClientBanner from '../ui/BlockedClientBanner';
import { api, ApiError } from '../../services/apiService';
import GotalkSendTemplateModal from '../gotalk/GotalkSendTemplateModal';
import ClientAttachmentsPanel from '../attachments/ClientAttachmentsPanel';
interface NoteAttachment {
    name: string;
    dataUrl: string;
    type: string;
}

interface CollectionNote {
    id: string;
    titleId: string;
    clientId: string;
    date: string;
    time: string;
    collaboratorId: string;
    collaboratorName: string;
    contactChannel: 'TELEFONE' | 'WHATSAPP' | 'EMAIL' | 'MENSAGEM';
    note: string;
    nextContactDate?: string;
    negotiationStatus: 'FECHADA' | 'AGUARDANDO_CONTATO' | 'ENCAMINHOU_BOLETO' | 'RECUSA_DIVIDA' | 'OUTROS' | 'SOLICITA_CANCELAMENTO';
    negotiationStatusOther?: string;
    debtSnapshot?: { original: number; interest: number; penalty: number; discount: number; balance: number };
    attachments?: NoteAttachment[];
    cancelRequest?: { admissionId: string; admissionContract: string; requestDate: string; notes: string };
}

type NoteFormState = {
    contactChannel: CollectionNote['contactChannel'];
    note: string;
    nextContactDate: string;
    negotiationStatus: CollectionNote['negotiationStatus'];
    negotiationStatusOther: string;
    interestSim: string;
    penaltySim: string;
    discountSim: string;
    attachments: NoteAttachment[];
};

interface CollectionOperationalPanelProps {
    titles: FinancialRecord[];
    collaborators: Collaborator[];
    currentUserId: string;
    currentCollaboratorId?: string;
    isAdmin?: boolean;
    clients: Client[];
    admissions: Admission[];
    auditLogs: AuditLog[];
    userGroups?: UserGroup[];
    onRefresh?: () => void;
    onBack?: () => void;
    onSearch?: (term: string) => void;
    GotalkChatPanel?: React.ComponentType<{ clientId: string; area: string; operatorName?: string }>;
    GotalkConversationsTab?: React.ComponentType<{ clientId: string }>;
}

// Task #302 — Aba WhatsApp unificada (GoTalk + uazapi por telefone) com append em tempo real via socket.
// Quando há telefone, usa /api/gotalk/client-timeline?phone= e composer /api/gotalk/send-text.
// Quando NÃO há telefone, faz fallback para o GotalkChatPanel (por clientId), preservando comportamento anterior.
interface TimelineMessage {
    message_id: string | number;
    gotalk_message_id?: string | null;
    idwpp?: string | null;
    phone_number: string;
    direction: 'IN' | 'OUT';
    body: string | null;
    message_type?: string | null;
    attachment_url?: string | null;
    attachment_name?: string | null;
    attachment_mime_type?: string | null;
    audio_transcript?: string | null;
    ack_status?: string | null;
    message_operator_name?: string | null;
    sent_at?: string | null;
    source?: 'gotalk' | 'uazapi' | string | null;
}
interface UnifiedWhatsappTabProps {
    phone: string | null;
    clientId: string;
    clientName?: string;
    operatorName?: string;
    socket: any;
    FallbackChatPanel?: React.ComponentType<{ clientId: string; area: string; operatorName?: string }>;
}
const UnifiedWhatsappTab: React.FC<UnifiedWhatsappTabProps> = ({ phone, clientId, clientName, operatorName, socket, FallbackChatPanel }) => {
    const normPhoneLast8 = useMemo(() => (phone ? String(phone).replace(/\D/g, '').slice(-8) : ''), [phone]);
    const phoneDigits = useMemo(() => (phone ? String(phone).replace(/\D/g, '') : ''), [phone]);
    const [messages, setMessages] = useState<TimelineMessage[]>([]);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [text, setText] = useState('');
    const [sending, setSending] = useState(false);
    const [hsmOpen, setHsmOpen] = useState(false);
    const scrollRef = useRef<HTMLDivElement>(null);

    // Fetch timeline
    useEffect(() => {
        if (!phoneDigits) return;
        let cancelled = false;
        setLoading(true); setError(null);
        api.get<{ messages: TimelineMessage[] }>(`/api/gotalk/client-timeline?phone=${encodeURIComponent(phoneDigits)}&limit=200`)
            .then(data => { if (!cancelled) setMessages(Array.isArray(data?.messages) ? data.messages : []); })
            .catch(err => { if (!cancelled) setError(err?.message || 'Falha ao carregar conversa.'); })
            .finally(() => { if (!cancelled) setLoading(false); });
        return () => { cancelled = true; };
    }, [phoneDigits]);

    // Real-time append on gotalk:new_message
    useEffect(() => {
        if (!socket || !normPhoneLast8) return;
        const onNew = (payload: any) => {
            const incPhone = String(payload?.phone || '').replace(/\D/g, '');
            if (!incPhone || incPhone.slice(-8) !== normPhoneLast8) return;
            const msg: TimelineMessage = {
                message_id: payload?.message_id ?? `live-${Date.now()}-${Math.random()}`,
                gotalk_message_id: payload?.gotalk_message_id ?? null,
                phone_number: incPhone,
                direction: (payload?.direction === 'OUT' ? 'OUT' : 'IN'),
                body: payload?.body ?? payload?.text ?? '',
                message_type: payload?.message_type ?? 'text',
                attachment_url: payload?.attachment_url ?? null,
                attachment_name: payload?.attachment_name ?? null,
                attachment_mime_type: payload?.attachment_mime_type ?? null,
                audio_transcript: payload?.audio_transcript ?? null,
                ack_status: payload?.ack_status ?? null,
                message_operator_name: payload?.operator_name ?? null,
                sent_at: payload?.sent_at ?? new Date().toISOString(),
                source: payload?.source ?? 'gotalk',
            };
            setMessages(prev => {
                // Deduplicate by gotalk_message_id when available
                if (msg.gotalk_message_id && prev.some(m => m.gotalk_message_id && m.gotalk_message_id === msg.gotalk_message_id)) return prev;
                return [...prev, msg];
            });
        };
        socket.on('gotalk:new_message', onNew);
        return () => { socket.off('gotalk:new_message', onNew); };
    }, [socket, normPhoneLast8]);

    // Auto-scroll on new messages
    useEffect(() => {
        const el = scrollRef.current;
        if (el) el.scrollTop = el.scrollHeight;
    }, [messages.length]);

    const handleSend = async () => {
        const body = text.trim();
        if (!body || !phoneDigits || sending) return;
        setSending(true);
        try {
            await api.post('/api/gotalk/send-text', { contactNumber: phoneDigits, message: body });
            // Optimistic append
            setMessages(prev => [...prev, {
                message_id: `local-${Date.now()}`,
                phone_number: phoneDigits,
                direction: 'OUT',
                body,
                message_type: 'text',
                sent_at: new Date().toISOString(),
                message_operator_name: operatorName || null,
                source: 'gotalk',
                ack_status: 'sent',
            } as TimelineMessage]);
            setText('');
        } catch (err: any) {
            alert(`Falha ao enviar: ${err?.message || 'erro desconhecido'}`);
        } finally {
            setSending(false);
        }
    };

    const fmtTime = (s?: string | null) => {
        if (!s) return '';
        try { return new Date(s).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' }); } catch { return ''; }
    };

    // Fallback: when there's no phone, use clientId-based chat panel if provided.
    if (!phoneDigits) {
        if (FallbackChatPanel) {
            return (
                <div className="flex-1 flex flex-col overflow-hidden min-h-0">
                    <FallbackChatPanel clientId={clientId} area="COBRANCA_OP" operatorName={operatorName} />
                </div>
            );
        }
        return (
            <div className="flex-1 flex items-center justify-center text-sm text-gray-400 p-6">
                Cliente sem telefone cadastrado — conversa do WhatsApp indisponível.
            </div>
        );
    }

    return (
        <div className="flex-1 flex flex-col overflow-hidden min-h-0 bg-[#efeae2]">
            <div className="px-4 py-2 bg-moss-700 text-white text-xs font-semibold shrink-0 flex items-center justify-between">
                <span>💬 WhatsApp · {clientName || phone}</span>
                {loading && <span className="text-[10px] opacity-80">carregando…</span>}
            </div>
            <div ref={scrollRef} className="flex-1 overflow-y-auto px-3 py-3 space-y-1.5">
                {error && <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded px-3 py-2">{error}</div>}
                {!loading && messages.length === 0 && !error && (
                    <div className="text-center text-xs text-gray-500 py-8">Nenhuma mensagem encontrada para este número.</div>
                )}
                {messages.map((m) => {
                    const isOut = m.direction === 'OUT';
                    return (
                        <div key={String(m.message_id)} className={`flex ${isOut ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-[75%] rounded-lg px-3 py-1.5 shadow-sm text-sm ${isOut ? 'bg-[#d9fdd3] text-gray-900' : 'bg-white text-gray-900'}`}>
                                {m.body && <div className="whitespace-pre-wrap break-words">{m.body}</div>}
                                {m.attachment_url && (
                                    <div className="mt-1">
                                        <a href={m.attachment_url} target="_blank" rel="noreferrer" className="text-xs text-moss-700 underline">
                                            📎 {m.attachment_name || 'Anexo'}
                                        </a>
                                    </div>
                                )}
                                {m.audio_transcript && (
                                    <div className="mt-1 text-[11px] italic text-gray-600 border-l-2 border-moss-300 pl-2">🎙️ {m.audio_transcript}</div>
                                )}
                                <div className="text-[10px] text-gray-500 mt-0.5 text-right">
                                    {fmtTime(m.sent_at)}
                                    {isOut && m.message_operator_name ? ` · ${m.message_operator_name}` : ''}
                                </div>
                            </div>
                        </div>
                    );
                })}
            </div>
            <div className="px-3 py-2 bg-white border-t border-gray-200 shrink-0 flex items-end gap-2">
                <button
                    type="button"
                    onClick={() => setHsmOpen(true)}
                    title="Disparar template HSM"
                    className="px-3 py-2 rounded-lg border border-green-600 text-green-700 text-xs font-semibold hover:bg-green-50 shrink-0"
                >
                    📋 HSM
                </button>
                <textarea
                    value={text}
                    onChange={e => setText(e.target.value)}
                    onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                    placeholder="Digite uma mensagem… (Enter envia, Shift+Enter quebra linha)"
                    rows={1}
                    className="flex-1 resize-none border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-moss-500 max-h-32"
                />
                <button
                    type="button"
                    onClick={handleSend}
                    disabled={sending || !text.trim()}
                    className="px-4 py-2 rounded-lg bg-moss-600 text-white text-sm font-semibold disabled:opacity-50 disabled:cursor-not-allowed hover:bg-moss-700"
                >
                    {sending ? 'Enviando…' : 'Enviar'}
                </button>
            </div>
            <GotalkSendTemplateModal
                isOpen={hsmOpen}
                onClose={() => setHsmOpen(false)}
                contactPhone={phoneDigits}
                contactName={clientName || ''}
            />
        </div>
    );
};

const statusLabel = (status: string) => {
    const labels: Record<string, string> = { 'ABERTO': 'Em Aberto', 'PAGO': 'Liquidado', 'PARCIAL': 'Parcial', 'CANCELADO': 'Cancelado', 'AGRUPADO': 'Fatura Gerada', 'ADIANTAMENTO': 'Adiantamento', 'ADIANTAMENTO_PARCIAL': 'Adiant. Parcial', 'DEVOLUCAO': 'Devolução', 'DEVOLUCAO_VINCULADA': 'Dev. Vinculada', 'DEVOLUCAO_PARCIAL': 'Dev. Parcial', 'PROTESTADO': 'Protestado', 'PROVISAO': 'Provisão' };
    return labels[status] || status;
};

const negotiationStatusLabel = (status: CollectionNote['negotiationStatus']) => {
    const labels: Record<string, string> = {
        'FECHADA': 'Negociação Fechada',
        'AGUARDANDO_CONTATO': 'Aguardando Contato',
        'ENCAMINHOU_BOLETO': 'Encaminhou Boleto/Pix',
        'RECUSA_DIVIDA': 'Recusa Dívida',
        'OUTROS': 'Outros',
        'SOLICITA_CANCELAMENTO': 'Solicitação de Cancelamento',
    };
    return labels[status] || status;
};

const negotiationStatusColor = (status: CollectionNote['negotiationStatus']) => {
    switch (status) {
        case 'FECHADA': return 'bg-green-100 text-green-800';
        case 'AGUARDANDO_CONTATO': return 'bg-yellow-100 text-yellow-800';
        case 'ENCAMINHOU_BOLETO': return 'bg-blue-100 text-blue-800';
        case 'RECUSA_DIVIDA': return 'bg-red-100 text-red-800';
        case 'OUTROS': return 'bg-gray-100 text-gray-700';
        case 'SOLICITA_CANCELAMENTO': return 'bg-orange-100 text-orange-800';
        default: return 'bg-gray-100 text-gray-700';
    }
};

const contactChannelIcon = (channel: CollectionNote['contactChannel']) => {
    switch (channel) {
        case 'WHATSAPP': return '💬';
        case 'TELEFONE': return '📞';
        case 'EMAIL': return '✉️';
        case 'MENSAGEM': return '📩';
        default: return '📌';
    }
};

const agingDays = (dueDate: string) => {
    const due = new Date(dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    due.setHours(0, 0, 0, 0);
    return Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
};

const agingBucket = (days: number): string => {
    if (days <= 0) return 'A Vencer';
    if (days <= 30) return '1-30 dias';
    if (days <= 60) return '31-60 dias';
    if (days <= 90) return '61-90 dias';
    return '90+ dias';
};

const agingBucketColor = (bucket: string): string => {
    switch (bucket) {
        case 'A Vencer': return 'bg-green-400';
        case '1-30 dias': return 'bg-yellow-400';
        case '31-60 dias': return 'bg-orange-400';
        case '61-90 dias': return 'bg-red-400';
        case '90+ dias': return 'bg-red-600';
        default: return 'bg-gray-400';
    }
};

const LEGACY_NOTES_KEY = 'collection_notes_v1';

const CollectionOperationalPanel: React.FC<CollectionOperationalPanelProps> = ({ titles, collaborators, currentUserId, currentCollaboratorId, isAdmin, clients, admissions, auditLogs, userGroups = [], onRefresh, onBack, onSearch, GotalkChatPanel, GotalkConversationsTab }) => {
    const { addToast, currentUser, temPermissao, validarPermissao } = useSecurity();
    const { logTransaction } = useAudit();
    const { sendMessage } = useMessaging();
    const { socket } = useSocket();
    const canExcluir = isAdmin || temPermissao('fin_cobranca_op:EXCLUIR');
    const handleOpenAdmissionModal = useCallback((adm: Admission | null) => {
        if (!adm) return;
        if (!isAdmin && !temPermissao('com_admissao:VISUALIZAR')) {
            addToast('error', 'Acesso negado', 'Sem permissão para visualizar a Ficha de Admissão.');
            return;
        }
        setViewingAdmission(adm);
    }, [addToast, isAdmin, temPermissao]);

    const [deleteModal, setDeleteModal] = useState<{ title: string; message: string; onConfirm: () => Promise<void> } | null>(null);
    const [deleteLoading, setDeleteLoading] = useState(false);

    const handleDeleteConfirmed = useCallback(async () => {
        if (!deleteModal) return;
        setDeleteLoading(true);
        try {
            await deleteModal.onConfirm();
        } catch {
            // error toast already shown inside onConfirm
        } finally {
            setDeleteLoading(false);
            setDeleteModal(null);
        }
    }, [deleteModal]);

    const [activeMode, setActiveMode] = useState<'CARTEIRA' | 'DASHBOARD'>('CARTEIRA');
    const [filterClient, setFilterClient] = useState('');
    const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    useEffect(() => {
        if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
        searchDebounceRef.current = setTimeout(() => { if (onSearch) onSearch(filterClient); }, 300);
        return () => { if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current); };
    }, [filterClient]);
    const [filterCollaborator, setFilterCollaborator] = useState('');
    const [filterDueDateStart, setFilterDueDateStart] = useState('');
    const [filterDueDateEnd, setFilterDueDateEnd] = useState('');
    const [filterStatus, setFilterStatus] = useState('');
    const [filterAging, setFilterAging] = useState('');
    const [showFilters, setShowFilters] = useState(false);
    const [sortColumn, setSortColumn] = useState<string>('dueDate');
    const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

    const [showClientPanel, setShowClientPanel] = useState(false);
    const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
    const [clientPanelTab, setClientPanelTab] = useState<'DADOS' | 'TITULOS' | 'ADMISSOES'>('DADOS');
    const [viewingAdmission, setViewingAdmission] = useState<Admission | null>(null);
    const [isFullscreen, setIsFullscreen] = useState(false);
    const [collectionSummary, setCollectionSummary] = useState<Record<string, { fichas: number; aditivos: number }>>({});
    const [clientFichas, setClientFichas] = useState<ClientFicha[]>([]);
    const [clientFichasLoading, setClientFichasLoading] = useState(false);
    const [showWhatsappOverlay, setShowWhatsappOverlay] = useState(false);
    // Task #302: aba "Registrar Contato" vs "WhatsApp" no painel de detalhe do título
    const [detailTab, setDetailTab] = useState<'FORM' | 'WHATSAPP'>('FORM');
    // Task #302: contagem de mensagens WhatsApp não lidas por telefone normalizado (últimos 10 dígitos)
    const [waUnreadByPhone, setWaUnreadByPhone] = useState<Record<string, number>>({});

    const [dashboardPeriodStart, setDashboardPeriodStart] = useState('');
    const [dashboardPeriodEnd, setDashboardPeriodEnd] = useState('');

    const [selectedCardBucket, setSelectedCardBucket] = useState<string | null>(null);

    const [activeTitle, setActiveTitle] = useState<FinancialRecord | null>(null);
    const [showCancelledTitles, setShowCancelledTitles] = useState(false);
    const [collectionNotes, setCollectionNotes] = useState<CollectionNote[]>([]);
    const [cancelNotesData, setCancelNotesData] = useState<CollectionNote[]>([]);
    const [isSavingNote, setIsSavingNote] = useState(false);
    const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
    const [editNoteText, setEditNoteText] = useState('');
    const [editNoteStatus, setEditNoteStatus] = useState<CollectionNote['negotiationStatus']>('AGUARDANDO_CONTATO');
    const [editNoteNextContact, setEditNoteNextContact] = useState('');
    const loadedClientIdsRef = useRef<Set<string>>(new Set());

    const loadClientNotes = useCallback(async (clientId: string) => {
        if (loadedClientIdsRef.current.has(clientId)) return;
        loadedClientIdsRef.current.add(clientId);
        try {
            const loaded: CollectionNote[] = await api.get(`/api/collection-notes?clientId=${clientId}`);
            setCollectionNotes(prev => [
                ...prev.filter(n => n.clientId !== clientId),
                ...loaded,
            ]);
        } catch {}
    }, []);

    const loadCancelNotes = useCallback(async (collaboratorId: string) => {
        try {
            const data = await api.get(`/api/collection-notes?collaboratorId=${collaboratorId}&negotiationStatus=SOLICITA_CANCELAMENTO`);
            setCancelNotesData(data);
        } catch {}
    }, []);

    const currentCollaborator = useMemo(() => {
        if (currentCollaboratorId) {
            return collaborators.find(c => c.id === currentCollaboratorId);
        }
        return collaborators.find(c => c.id === currentUserId || (c as any).userId === currentUserId);
    }, [collaborators, currentUserId, currentCollaboratorId]);

    React.useEffect(() => {
        const myId = currentCollaborator?.id || currentCollaboratorId || currentUserId;
        if (myId) loadCancelNotes(myId);
    }, [currentCollaborator?.id, currentCollaboratorId, currentUserId, loadCancelNotes]);

    React.useEffect(() => {
        if (activeTitle?.clientId) loadClientNotes(activeTitle.clientId);
    }, [activeTitle?.clientId, loadClientNotes]);

    React.useEffect(() => {
        try {
            const raw = localStorage.getItem(LEGACY_NOTES_KEY);
            if (!raw) return;
            const stored: CollectionNote[] = JSON.parse(raw);
            if (!Array.isArray(stored) || stored.length === 0) {
                localStorage.removeItem(LEGACY_NOTES_KEY);
                return;
            }
            api.post('/api/collection-notes/bulk', { notes: stored })
                .then((res) => {
                    const { failedIds = [] } = res as { failedIds?: string[] };
                    if (failedIds.length > 0) {
                        const failedSet = new Set(failedIds.filter(Boolean));
                        const remaining = stored.filter(n => failedSet.has(n.id));
                        try { localStorage.setItem(LEGACY_NOTES_KEY, JSON.stringify(remaining)); } catch {}
                    } else {
                        localStorage.removeItem(LEGACY_NOTES_KEY);
                    }
                    loadedClientIdsRef.current.clear();
                    if (activeTitle?.clientId) loadClientNotes(activeTitle.clientId);
                })
                .catch(() => {});
        } catch {}
    }, []);

    const emptyNoteForm: NoteFormState = { contactChannel: 'TELEFONE', note: '', nextContactDate: '', negotiationStatus: 'AGUARDANDO_CONTATO', negotiationStatusOther: '', interestSim: '', penaltySim: '', discountSim: '', attachments: [] };
    const [noteForm, setNoteForm] = useState<NoteFormState>(emptyNoteForm);

    const [contactModalTitle, setContactModalTitle] = useState<FinancialRecord | null>(null);

    React.useEffect(() => {
        if (contactModalTitle?.clientId) loadClientNotes(contactModalTitle.clientId);
    }, [contactModalTitle?.clientId, loadClientNotes]);

    // Task #302: ao fechar/abrir o modal de detalhe, sempre começar na aba do formulário
    React.useEffect(() => {
        setDetailTab('FORM');
    }, [contactModalTitle?.id]);

    // Task #302: helpers de normalização de telefone (últimos 10 dígitos = invariante BR)
    const normalizePhoneKey = useCallback((phone?: string | null): string => {
        if (!phone) return '';
        const d = String(phone).replace(/\D/g, '');
        return d.slice(-10);
    }, []);

    // Mapa clientId → chave de telefone (últimos 10 dígitos), para badges na carteira
    const clientPhoneKey = useMemo(() => {
        const map: Record<string, string> = {};
        for (const c of clients) {
            const k = normalizePhoneKey(c.phone || (c as any).phone1 || '');
            if (k) map[c.id] = k;
        }
        return map;
    }, [clients, normalizePhoneKey]);

    // Carrega contagens de não lidas (uma vez por montagem) — usa endpoint já existente do módulo Prospecção
    React.useEffect(() => {
        let cancelled = false;
        (async () => {
            try {
                const data = await api.get<{ counts: Record<string, { gotalk: number; uazapi: number }>; total: number }>(
                    '/api/prospection/unread-counts'
                );
                if (cancelled || !data?.counts) return;
                const flat: Record<string, number> = {};
                for (const [phone, c] of Object.entries(data.counts)) {
                    const k = String(phone).replace(/\D/g, '').slice(-10);
                    if (!k) continue;
                    flat[k] = (flat[k] || 0) + (c.gotalk || 0) + (c.uazapi || 0);
                }
                setWaUnreadByPhone(flat);
            } catch { /* silent: badge é opcional */ }
        })();
        return () => { cancelled = true; };
    }, []);

    // Subscreve socket gotalk:new_message — incrementa badge; se for telefone do título aberto na aba WhatsApp, zera
    React.useEffect(() => {
        if (!socket) return;
        const onNewMsg = (payload?: { phone?: string; direction?: 'IN' | 'OUT' }) => {
            if (!payload?.phone || payload.direction !== 'IN') return;
            const k = String(payload.phone).replace(/\D/g, '').slice(-10);
            if (!k) return;
            // Se o usuário está com o título desse telefone aberto na aba WhatsApp, considera "lido" — não incrementa
            const openKey = contactModalTitle ? clientPhoneKey[contactModalTitle.clientId] : '';
            if (openKey === k && detailTab === 'WHATSAPP') return;
            setWaUnreadByPhone(prev => ({ ...prev, [k]: (prev[k] || 0) + 1 }));
        };
        socket.on('gotalk:new_message', onNewMsg);
        return () => { socket.off('gotalk:new_message', onNewMsg); };
    }, [socket, contactModalTitle, detailTab, clientPhoneKey]);

    // Ao abrir a aba WhatsApp para um título, zera localmente o badge do telefone correspondente
    React.useEffect(() => {
        if (detailTab !== 'WHATSAPP' || !contactModalTitle) return;
        const k = clientPhoneKey[contactModalTitle.clientId];
        if (!k) return;
        setWaUnreadByPhone(prev => (prev[k] ? { ...prev, [k]: 0 } : prev));
    }, [detailTab, contactModalTitle, clientPhoneKey]);
    const [modalNoteForm, setModalNoteForm] = useState<NoteFormState>(emptyNoteForm);
    const [isSavingModalNote, setIsSavingModalNote] = useState(false);

    const emptyCancelReq = { admissionId: '', admissionContract: '', requestDate: new Date().toISOString().split('T')[0], notes: '' };
    const [cancelRequestModal, setCancelRequestModal] = useState<{ open: boolean; forTitle: FinancialRecord | null; form: typeof emptyCancelReq }>({ open: false, forTitle: null, form: emptyCancelReq });
    const [dashboardCancelFilter, setDashboardCancelFilter] = useState<'MY' | null>(null);

    const myTitles = useMemo(() => {
        if (isAdmin) {
            return titles.filter(t =>
                t.collectionStatus === 'COBRAR' &&
                t.type === 'PADRAO' &&
                !['CANCELADO', 'AGRUPADO', 'PAGO'].includes(t.status)
            );
        }
        if (!currentCollaborator) return [];
        return titles.filter(t =>
            t.assignedCollaboratorId === currentCollaborator.id &&
            t.collectionStatus === 'COBRAR' &&
            t.type === 'PADRAO' &&
            !['CANCELADO', 'AGRUPADO', 'PAGO'].includes(t.status)
        );
    }, [titles, currentCollaborator, isAdmin]);

    const filteredTitles = useMemo(() => {
        let data = [...myTitles];
        if (isAdmin && filterCollaborator) {
            data = data.filter(t => t.assignedCollaboratorId === filterCollaborator);
        }
        if (filterStatus) data = data.filter(t => t.status === filterStatus);
        if (filterDueDateStart) data = data.filter(t => t.dueDate >= filterDueDateStart);
        if (filterDueDateEnd) data = data.filter(t => t.dueDate <= filterDueDateEnd);
        if (filterAging || selectedCardBucket) {
            const bucket = filterAging || selectedCardBucket!;
            if (bucket === 'Vencidos') {
                data = data.filter(t => agingDays(t.dueDate) > 0);
            } else {
                data = data.filter(t => agingBucket(agingDays(t.dueDate)) === bucket);
            }
        }
        data.sort((a, b) => {
            let valA: any = (a as any)[sortColumn];
            let valB: any = (b as any)[sortColumn];
            if (sortColumn === 'currentBalance' || sortColumn === 'originalValue') {
                valA = Number(valA) || 0; valB = Number(valB) || 0;
            }
            if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
            if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
            return 0;
        });
        return data;
    }, [myTitles, filterCollaborator, filterStatus, filterDueDateStart, filterDueDateEnd, filterAging, selectedCardBucket, sortColumn, sortDirection, isAdmin]);

    const handleSort = (col: string) => {
        if (sortColumn === col) setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
        else { setSortColumn(col); setSortDirection('asc'); }
    };
    const sortIcon = (col: string) => sortColumn !== col ? '↕' : sortDirection === 'asc' ? '↑' : '↓';

    const calcFinancials = (arr: FinancialRecord[]) => {
        const totalOriginal = arr.reduce((s, t) => s + (Number(t.originalValue) || 0), 0);
        const totalInterest = arr.reduce((s, t) => s + (Number(t.interestValue) || 0), 0);
        const totalPenalty = arr.reduce((s, t) => s + (Number(t.penaltyValue) || 0), 0);
        const totalDiscount = arr.reduce((s, t) => s + (Number(t.discountValue) || 0), 0);
        const totalUpdated = totalOriginal + totalInterest + totalPenalty - totalDiscount;
        const totalBalance = arr.reduce((s, t) => s + (Number(t.currentBalance) || 0), 0);
        const totalPaid = arr.reduce((s, t) => s + ((t.settlements || []).reduce((ps, p) => ps + (Number(p.amount) || 0), 0)), 0);
        return { totalOriginal, totalInterest, totalPenalty, totalDiscount, totalUpdated, totalBalance, totalPaid };
    };

    const fin = calcFinancials(filteredTitles);
    const totalBalance = fin.totalBalance;
    const overdueTitles = filteredTitles.filter(t => agingDays(t.dueDate) > 0);
    const overdueCount = overdueTitles.length;
    const finOverdue = calcFinancials(overdueTitles);
    const overdueBalance = finOverdue.totalBalance;
    const aVencerTitles = filteredTitles.filter(t => agingDays(t.dueDate) <= 0);
    const finAVencer = calcFinancials(aVencerTitles);

    const handleOpenClientPanel = (clientId: string) => {
        setSelectedClientId(clientId);
        setClientPanelTab('DADOS');
        setShowClientPanel(true);
    };

    useEffect(() => {
        const uniqueClientIds = [...new Set(filteredTitles.map(t => t.clientId).filter(Boolean))];
        if (uniqueClientIds.length === 0) { setCollectionSummary({}); return; }
        let mounted = true;
        api.post<{ data: Record<string, { fichas: number; aditivos: number }> }>(
            '/api/admissions/collection-summary',
            { clientIds: uniqueClientIds }
        )
            .then(d => { if (mounted && d.data) setCollectionSummary(d.data); })
            .catch(() => {});
        return () => { mounted = false; };
    }, [filteredTitles]);

    useEffect(() => {
        if (!selectedClientId) { setClientFichas([]); return; }
        let mounted = true;
        setClientFichasLoading(true);
        api.get<{ data: ClientFicha[] }>(`/api/admissions/client-detail/${selectedClientId}`)
            .then(d => { if (mounted) setClientFichas(d.data || []); })
            .catch(() => { if (mounted) setClientFichas([]); })
            .finally(() => { if (mounted) setClientFichasLoading(false); });
        return () => { mounted = false; };
    }, [selectedClientId]);

    const selectedClient = useMemo(() => clients.find(c => c.id === selectedClientId), [clients, selectedClientId]);

    const clientApprovedAdmissions = useMemo(() => {
        if (!selectedClientId) return [];
        return admissions.filter(a => a.clientId === selectedClientId && ['APROVADA', 'FINALIZADA', 'CONCLUIDO', 'AUDITADA'].includes(a.status));
    }, [admissions, selectedClientId]);

    const allClientTitles = useMemo(() => {
        if (!selectedClientId) return [];
        return titles.filter(t => t.clientId === selectedClientId && t.type === 'PADRAO');
    }, [titles, selectedClientId]);

    const activeTitleClientTitles = useMemo(() => {
        if (!activeTitle) return [];
        const all = titles.filter(t => t.clientId === activeTitle.clientId && t.type === 'PADRAO');
        if (showCancelledTitles) return all;
        return all.filter(t => !['CANCELADO', 'AGRUPADO'].includes(t.status));
    }, [titles, activeTitle, showCancelledTitles]);

    const activeTitleNotes = useMemo(() => {
        if (!activeTitle) return [];
        return collectionNotes.filter(n => n.clientId === activeTitle.clientId).sort((a, b) => b.date.localeCompare(a.date) || b.time.localeCompare(a.time));
    }, [collectionNotes, activeTitle]);

    const activeTitleAdmission = useMemo(() => {
        if (!activeTitle) return null;
        return admissions.find(a => a.clientId === activeTitle.clientId && ['APROVADA', 'FINALIZADA', 'CONCLUIDO', 'AUDITADA'].includes(a.status)) || null;
    }, [admissions, activeTitle]);

    const saveNoteCore = useCallback(async (
        title: FinancialRecord,
        form: NoteFormState,
        setSaving: (v: boolean) => void,
        onSuccess: () => void,
    ) => {
        if (!form.note.trim()) {
            addToast('warning', 'Validação', 'Informe o texto da nota.');
            return;
        }
        if (form.negotiationStatus === 'OUTROS' && !form.negotiationStatusOther.trim()) {
            addToast('warning', 'Validação', 'Descreva o status "Outros".');
            return;
        }

        setSaving(true);
        try {
            const now = new Date();
            const origVal = Number(title.originalValue) || 0;
            const intVal = parseFloat(form.interestSim) || Number(title.interestValue) || 0;
            const penVal = parseFloat(form.penaltySim) || Number(title.penaltyValue) || 0;
            const discVal = parseFloat(form.discountSim) || Number(title.discountValue) || 0;
            const balVal = origVal + intVal + penVal - discVal;
            const newNote: CollectionNote = {
                id: `note_${Date.now()}`,
                titleId: title.id,
                clientId: title.clientId,
                date: now.toISOString().split('T')[0],
                time: now.toTimeString().slice(0, 5),
                collaboratorId: currentCollaborator?.id || currentUserId,
                collaboratorName: currentCollaborator?.name || currentUser?.name || 'Operador',
                contactChannel: form.contactChannel,
                note: form.note.trim(),
                nextContactDate: form.nextContactDate || undefined,
                negotiationStatus: form.negotiationStatus,
                negotiationStatusOther: form.negotiationStatus === 'OUTROS' ? form.negotiationStatusOther.trim() : undefined,
                debtSnapshot: { original: origVal, interest: intVal, penalty: penVal, discount: discVal, balance: balVal },
                attachments: form.attachments.length > 0 ? form.attachments : undefined,
                cancelRequest: (form as any).cancelRequest || undefined,
            };

            await api.post('/api/collection-notes', newNote);
            setCollectionNotes(prev => [newNote, ...prev.filter(n => n.id !== newNote.id)]);
            if (newNote.negotiationStatus === 'SOLICITA_CANCELAMENTO') {
                setCancelNotesData(prev => [newNote, ...prev.filter(n => n.id !== newNote.id)]);
            }
            logTransaction('NOTA_COBRANCA', newNote.id, null, newNote);

            const userGroupIds = currentUser?.groupIds || [];
            const hasNextDate = !!form.nextContactDate;
            const isCancelRequest = form.negotiationStatus === 'SOLICITA_CANCELAMENTO';

            if (isCancelRequest) {
                const cr = (form as any).cancelRequest as { admissionId: string; admissionContract: string; requestDate: string; notes: string } | undefined;
                const cancelMsgBody = `🚨 *Solicitação de Cancelamento* — ${title.clientName}\n` +
                    `Operador: ${newNote.collaboratorName}\n` +
                    `Contrato: ${cr?.admissionContract || '—'}\n` +
                    `Data da Solicitação: ${cr?.requestDate ? new Date(cr.requestDate + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}\n` +
                    `Anotações: ${cr?.notes || newNote.note}\n` +
                    `Título: ${title.documentNumber} | Saldo: ${formatCurrencyBRL(Number(title.currentBalance))}`;

                const targetGroupIds = [...new Set([
                    ...userGroupIds,
                    ...(userGroups || [])
                        .filter(g => {
                            const n = g.name.toLowerCase();
                            return n.includes('cobran') || n.includes('gerenci') || n.includes('diretor') || n.includes('coordena');
                        })
                        .map(g => g.id),
                ])];

                for (const gid of targetGroupIds) {
                    try { await sendMessage({ recipientType: 'GROUP', recipientId: gid, subject: `Solicitação de Cancelamento — ${title.clientName}`, body: cancelMsgBody }); } catch {}
                }
                addToast('success', 'Solicitação Registrada', 'Solicitação de cancelamento registrada e grupos notificados.');
            } else if (hasNextDate) {
                const nextDateStr = new Date(form.nextContactDate + 'T12:00:00').toLocaleDateString('pt-BR');
                const msgBody = `📋 *Registro de Contato* — ${title.clientName}\n` +
                    `Operador: ${newNote.collaboratorName}\n` +
                    `Canal: ${contactChannelIcon(newNote.contactChannel)} ${newNote.contactChannel}\n` +
                    `Status: ${negotiationStatusLabel(newNote.negotiationStatus)}\n` +
                    `Nota: ${newNote.note}\n` +
                    `Próximo Contato: ${nextDateStr}`;

                if (userGroupIds.length > 0) {
                    for (const gid of userGroupIds) {
                        try { await sendMessage({ recipientType: 'GROUP', recipientId: gid, subject: `Cobrança — ${title.clientName}`, body: msgBody }); } catch {}
                    }
                }

                try {
                    await api.post('/api/appointments', {
                        clientId: title.clientId,
                        clientName: title.clientName,
                        collaboratorId: currentCollaborator?.id || currentCollaboratorId || undefined,
                        serviceId: '',
                        date: form.nextContactDate,
                        startTime: '12:00',
                        endTime: '12:30',
                        status: 'AGENDADO',
                        notes: `[Cobrança] ${form.note.trim()} — Canal: ${newNote.contactChannel}`,
                        groupId: userGroupIds[0] || undefined,
                        modalidade: 'ONLINE',
                    });
                    if (onRefresh) onRefresh();
                } catch {}

                addToast('success', 'Nota Registrada', 'Nota salva. Agenda e mensagem de grupo atualizadas.');
            } else {
                addToast('success', 'Nota Registrada', 'Nota salva com sucesso.');
            }

            onSuccess();
        } catch {
            addToast('error', 'Erro', 'Não foi possível salvar a nota.');
        } finally {
            setSaving(false);
        }
    }, [currentCollaborator, currentCollaboratorId, currentUser, currentUserId, sendMessage, addToast, onRefresh]);

    const handleDeleteTitle = useCallback((title: FinancialRecord) => {
        if (!validarPermissao('fin_cobranca_op:EXCLUIR')) return;
        setDeleteModal({
            title: 'Excluir Título',
            message: `Excluir o título "${title.documentNumber}" de ${title.clientName}? Esta ação não pode ser desfeita.`,
            onConfirm: async () => {
                try {
                    await api.delete(`/api/financial-titles/${title.id}`);
                    logTransaction('CONTA_RECEBER', title.id, title, null);
                    if (onRefresh) onRefresh();
                    addToast('success', 'Excluído', 'Título removido com sucesso.');
                } catch (err) {
                    const msg = err instanceof Error ? err.message : 'Não foi possível excluir o título.';
                    const details = err instanceof ApiError ? err.details : undefined;
                    addToast('error', 'Erro ao excluir', details ? `${msg}: ${details}` : msg);
                }
            },
        });
    }, [addToast, validarPermissao, onRefresh, logTransaction]);

    const handleDeleteNote = useCallback((noteId: string) => {
        if (!validarPermissao('fin_cobranca_op:EXCLUIR')) return;
        const noteToDelete = collectionNotes.find(n => n.id === noteId);
        setDeleteModal({
            title: 'Excluir Nota de Cobrança',
            message: 'Excluir esta nota de cobrança? Esta ação não pode ser desfeita.',
            onConfirm: async () => {
                try {
                    await api.delete(`/api/collection-notes/${noteId}`);
                    logTransaction('NOTA_COBRANCA', noteId, noteToDelete || { id: noteId }, null);
                    setCollectionNotes(prev => prev.filter(n => n.id !== noteId));
                    setCancelNotesData(prev => prev.filter(n => n.id !== noteId));
                    addToast('success', 'Excluído', 'Nota excluída com sucesso.');
                } catch {
                    addToast('error', 'Erro', 'Não foi possível excluir a nota.');
                }
            },
        });
    }, [addToast, validarPermissao, collectionNotes, logTransaction]);

    const handleStartEditNote = useCallback((note: CollectionNote) => {
        setEditingNoteId(note.id);
        setEditNoteText(note.note);
        setEditNoteStatus(note.negotiationStatus);
        setEditNoteNextContact(note.nextContactDate || '');
    }, []);

    const handleSaveEditNote = useCallback(async () => {
        if (!editingNoteId) return;
        if (!editNoteText.trim()) {
            addToast('warning', 'Validação', 'O texto da nota não pode ser vazio.');
            return;
        }
        const originalNote = collectionNotes.find(n => n.id === editingNoteId);
        try {
            await api.put(`/api/collection-notes/${editingNoteId}`, {
                note: editNoteText.trim(),
                negotiationStatus: editNoteStatus,
                nextContactDate: editNoteNextContact || null,
            });
            const update = (n: CollectionNote) => n.id === editingNoteId
                ? { ...n, note: editNoteText.trim(), negotiationStatus: editNoteStatus, nextContactDate: editNoteNextContact || undefined }
                : n;
            setCollectionNotes(prev => prev.map(update));
            setCancelNotesData(prev => prev.map(update));

            if (originalNote) {
                const updatedNote = {
                    ...originalNote,
                    note: editNoteText.trim(),
                    negotiationStatus: editNoteStatus,
                    nextContactDate: editNoteNextContact || undefined,
                };
                logTransaction('NOTA_COBRANCA', editingNoteId, originalNote, updatedNote);
            }

            setEditingNoteId(null);
            setEditNoteText('');
            setEditNoteStatus('AGUARDANDO_CONTATO');
            setEditNoteNextContact('');
            addToast('success', 'Atualizado', 'Nota atualizada com sucesso.');
        } catch {
            addToast('error', 'Erro', 'Não foi possível atualizar a nota.');
        }
    }, [editingNoteId, editNoteText, editNoteStatus, editNoteNextContact, collectionNotes, logTransaction, addToast]);

    const handleSaveNote = useCallback(async () => {
        if (!activeTitle) return;
        await saveNoteCore(activeTitle, noteForm, setIsSavingNote, () => setNoteForm(emptyNoteForm));
    }, [activeTitle, noteForm, saveNoteCore]);

    const handleSaveModalNote = useCallback(async () => {
        if (!contactModalTitle) return;
        await saveNoteCore(contactModalTitle, modalNoteForm, setIsSavingModalNote, () => setModalNoteForm(emptyNoteForm));
    }, [contactModalTitle, modalNoteForm, saveNoteCore]);

    const handleCardClick = (bucket: string | null) => {
        setSelectedCardBucket(prev => prev === bucket ? null : bucket);
        setFilterAging('');
    };

    const dashboardData = useMemo(() => {
        const todayStr = new Date().toISOString().split('T')[0];

        let periodTitles = [...myTitles];
        if (dashboardPeriodStart) periodTitles = periodTitles.filter(t => t.dueDate >= dashboardPeriodStart);
        if (dashboardPeriodEnd) periodTitles = periodTitles.filter(t => t.dueDate <= dashboardPeriodEnd);

        const dueTodayCount = myTitles.filter(t => t.dueDate === todayStr).length;
        const dueTodayBalance = myTitles.filter(t => t.dueDate === todayStr).reduce((s, t) => s + (Number(t.currentBalance) || 0), 0);

        const overdueToday = myTitles.filter(t => agingDays(t.dueDate) > 0);
        const overdueTodayBalance = overdueToday.reduce((s, t) => s + (Number(t.currentBalance) || 0), 0);

        let settlementsToday = 0;
        let settledAmountToday = 0;
        myTitles.forEach(t => {
            if (t.settlements) {
                t.settlements.forEach(s => {
                    if (s.date === todayStr) {
                        settlementsToday++;
                        settledAmountToday += (Number(s.amount) || 0);
                    }
                });
            }
        });

        const allMyTitlesIncludingPaid = isAdmin
            ? titles.filter(t => t.type === 'PADRAO')
            : titles.filter(t => t.assignedCollaboratorId === currentCollaborator?.id && t.type === 'PADRAO');

        let periodAllTitles = [...allMyTitlesIncludingPaid];
        if (dashboardPeriodStart) periodAllTitles = periodAllTitles.filter(t => t.dueDate >= dashboardPeriodStart);
        if (dashboardPeriodEnd) periodAllTitles = periodAllTitles.filter(t => t.dueDate <= dashboardPeriodEnd);

        const totalAssigned = periodAllTitles.length;
        const totalAssignedValue = periodAllTitles.reduce((s, t) => s + (Number(t.originalValue) || 0), 0);
        const paidTitles = periodAllTitles.filter(t => t.status === 'PAGO');
        const recoveredValue = paidTitles.reduce((s, t) => s + (Number(t.originalValue) || 0), 0);
        const taxaRecuperacao = totalAssignedValue > 0 ? (recoveredValue / totalAssignedValue) * 100 : 0;

        const fpOrig = periodTitles.reduce((s, t) => s + (Number(t.originalValue) || 0), 0);
        const fpInterest = periodTitles.reduce((s, t) => s + (Number(t.interestValue) || 0), 0);
        const fpPenalty = periodTitles.reduce((s, t) => s + (Number(t.penaltyValue) || 0), 0);
        const fpDiscount = periodTitles.reduce((s, t) => s + (Number(t.discountValue) || 0), 0);
        const fpBalance = periodTitles.reduce((s, t) => s + (Number(t.currentBalance) || 0), 0);
        const fpUpdated = fpOrig + fpInterest + fpPenalty - fpDiscount;
        const fpPaid = periodTitles.reduce((s, t) => s + ((t.settlements || []).reduce((ps, p) => ps + (Number(p.amount) || 0), 0)), 0);
        const finPeriod = { totalOriginal: fpOrig, totalInterest: fpInterest, totalPenalty: fpPenalty, totalDiscount: fpDiscount, totalBalance: fpBalance, totalUpdated: fpUpdated, totalPaid: fpPaid };

        const openBalance = finPeriod.totalBalance;
        const overdueInPeriod = periodTitles.filter(t => agingDays(t.dueDate) > 0);
        const overdueBalancePeriod = overdueInPeriod.reduce((s, t) => s + (Number(t.currentBalance) || 0), 0);
        const taxaInadimplencia = periodTitles.length > 0 ? (overdueInPeriod.length / periodTitles.length) * 100 : 0;

        const avgBalance = periodTitles.length > 0 ? openBalance / periodTitles.length : 0;
        const dailyRecovery = recoveredValue > 0 ? recoveredValue / 30 : 1;
        const dso = dailyRecovery > 0 ? Math.round(avgBalance / dailyRecovery * 30) : 0;

        const agingBuckets: Record<string, { count: number; balance: number }> = {
            'A Vencer': { count: 0, balance: 0 },
            '1-30 dias': { count: 0, balance: 0 },
            '31-60 dias': { count: 0, balance: 0 },
            '61-90 dias': { count: 0, balance: 0 },
            '90+ dias': { count: 0, balance: 0 },
        };
        periodTitles.forEach(t => {
            const days = agingDays(t.dueDate);
            const bucket = agingBucket(days);
            if (agingBuckets[bucket]) {
                agingBuckets[bucket].count++;
                agingBuckets[bucket].balance += (Number(t.currentBalance) || 0);
            }
        });

        const dailyEvolution: { date: string; balance: number; count: number }[] = [];
        const dateMap = new Map<string, { balance: number; count: number }>();
        periodTitles.forEach(t => {
            const key = t.dueDate;
            const existing = dateMap.get(key) || { balance: 0, count: 0 };
            existing.balance += (Number(t.currentBalance) || 0);
            existing.count++;
            dateMap.set(key, existing);
        });
        const sortedDates = Array.from(dateMap.keys()).sort();
        let cumBalance = 0;
        sortedDates.forEach(date => {
            const entry = dateMap.get(date)!;
            cumBalance += entry.balance;
            dailyEvolution.push({ date, balance: cumBalance, count: entry.count });
        });

        return {
            dueTodayCount, dueTodayBalance,
            overdueTodayCount: overdueToday.length, overdueTodayBalance,
            settlementsToday, settledAmountToday,
            totalAssigned, totalAssignedValue,
            recoveredValue, taxaRecuperacao,
            openBalance, overdueBalancePeriod, taxaInadimplencia,
            dso, agingBuckets, dailyEvolution,
            paidCount: paidTitles.length, openCount: periodTitles.length,
            finPeriod,
        };
    }, [myTitles, titles, currentCollaborator, dashboardPeriodStart, dashboardPeriodEnd]);

    const maxBucketBalance = useMemo(() => Math.max(...Object.values(dashboardData.agingBuckets).map(b => b.balance), 1), [dashboardData]);

    const cancelNotes = cancelNotesData.filter(n => !!n.cancelRequest);
    const maxEvolutionBalance = useMemo(() => Math.max(...dashboardData.dailyEvolution.map(e => e.balance), 1), [dashboardData]);

    const fmtDate = (d?: string | null) => {
        if (!d) return '—';
        try { return new Date(d + (d.length === 10 ? 'T00:00:00' : '')).toLocaleDateString('pt-BR'); } catch { return d; }
    };

    return (
        <>
        <div className={isFullscreen ? "fixed inset-0 z-[9999] flex flex-col bg-white" : "h-full flex flex-col animate-fade-in"}>
            <div className="bg-moss-800 text-white px-8 py-5 flex items-center gap-4">
                {onBack && (
                    <button
                        onClick={onBack}
                        className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20 shrink-0"
                        title="Voltar"
                    >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                        Voltar
                    </button>
                )}
                <svg className="w-8 h-8 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
                <div>
                    <h2 className="text-xl font-bold tracking-wide">Cobrança — Operacional</h2>
                    <p className="text-moss-200 text-sm">
                        {isAdmin ? 'Visão administrativa — todos os títulos em cobrança' : `Títulos atribuídos a ${currentCollaborator?.name || 'você'}`}
                    </p>
                </div>
                {isAdmin && (
                    <span className="ml-auto bg-amber-400 text-amber-900 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                        Administrador
                    </span>
                )}
                <button
                    onClick={() => setIsFullscreen(f => !f)}
                    className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20 shrink-0"
                    title={isFullscreen ? 'Minimizar' : 'Expandir tela cheia'}
                >
                    {isFullscreen ? (
                        <>
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 9V4.5M9 9H4.5M9 9L3.75 3.75M9 15v4.5M9 15H4.5M9 15l-5.25 5.25M15 9h4.5M15 9V4.5M15 9l5.25-5.25M15 15h4.5M15 15v4.5m0-4.5l5.25 5.25" /></svg>
                            Minimizar
                        </>
                    ) : (
                        <>
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" /></svg>
                            Expandir
                        </>
                    )}
                </button>
            </div>

            <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center gap-4">
                <button onClick={() => setActiveMode('CARTEIRA')} className={`px-5 py-2 rounded-lg text-sm font-semibold transition-colors ${activeMode === 'CARTEIRA' ? 'bg-moss-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                    {isAdmin ? 'Todas as Carteiras' : 'Minha Carteira'}
                </button>
                <button onClick={() => setActiveMode('DASHBOARD')} className={`px-5 py-2 rounded-lg text-sm font-semibold transition-colors ${activeMode === 'DASHBOARD' ? 'bg-moss-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                    {isAdmin ? 'Resultados Gerais' : 'Meus Resultados'}
                </button>
            </div>

            {!isAdmin && !currentCollaborator && (
                <div className="bg-amber-50 border-b border-amber-200 px-6 py-4 flex items-center gap-3">
                    <svg className="w-6 h-6 text-amber-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
                    <div>
                        <p className="text-amber-800 font-semibold text-sm">Seu usuário não está vinculado a um colaborador.</p>
                        <p className="text-xs text-amber-600">Solicite ao administrador que vincule seu cadastro para visualizar os títulos.</p>
                    </div>
                </div>
            )}

            {activeMode === 'CARTEIRA' && (
                <>
                    <div className="bg-white border-b border-gray-200 px-6 pt-4 pb-3">
                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 mb-2">

                            {/* Card helper: equação sentença */}
                            {(() => {
                                const FinCard = ({ accent, icon, title, mainValue, mainLabel, fin: f, count, countLabel, clickable, active, onClick }: {
                                    accent: string; icon: React.ReactNode; title: string; mainValue: string; mainLabel?: string;
                                    fin: ReturnType<typeof calcFinancials>; count?: number; countLabel?: string;
                                    clickable?: boolean; active?: boolean; onClick?: () => void;
                                }) => (
                                    <div onClick={onClick} className={`bg-${accent}-50 rounded-lg px-3 py-2 border border-${accent}-100 ${clickable ? 'cursor-pointer transition-all hover:shadow-sm hover:border-' + accent + '-300' : ''} ${active ? 'ring-2 ring-' + accent + '-400 shadow-sm' : ''}`}>
                                        <div className="flex items-center justify-between gap-2">
                                            <div className="flex items-center gap-1.5 min-w-0">
                                                {icon}
                                                <span className={`text-[10px] text-${accent}-600 uppercase tracking-wider font-bold truncate`}>{title}{active ? ' ✓' : ''}</span>
                                            </div>
                                            <div className="flex items-baseline gap-1.5 shrink-0">
                                                {count !== undefined && <span className={`text-lg font-bold text-${accent}-800 leading-none`}>{count}<span className="text-[10px] font-medium ml-0.5">{countLabel}</span></span>}
                                                <span className={`text-sm font-bold text-${accent}-700 leading-none`}>{count !== undefined ? `Saldo ${mainValue}` : mainValue}</span>
                                            </div>
                                        </div>
                                        <div className="flex flex-wrap items-center gap-x-1 mt-1 text-[9px] leading-none">
                                            <span className="text-gray-500 font-semibold">{formatCurrencyBRL(f.totalOriginal)}</span>
                                            {f.totalInterest > 0 && <><span className="text-gray-300">+</span><span className="text-orange-500 font-semibold">{formatCurrencyBRL(f.totalInterest)}</span></>}
                                            {f.totalPenalty > 0 && <><span className="text-gray-300">+</span><span className="text-red-500 font-semibold">{formatCurrencyBRL(f.totalPenalty)}</span></>}
                                            {f.totalDiscount > 0 && <><span className="text-gray-300">−</span><span className="text-green-600 font-semibold">{formatCurrencyBRL(f.totalDiscount)}</span></>}
                                            <span className="text-gray-300">=</span>
                                            <span className={`text-${accent}-700 font-bold`}>{formatCurrencyBRL(f.totalUpdated)}</span>
                                            {f.totalPaid > 0 && <><span className="text-gray-300">−</span><span className="text-gray-400 font-semibold">{formatCurrencyBRL(f.totalPaid)}</span></>}
                                            <span className="text-gray-300">=</span>
                                            <span className={`text-${accent}-800 font-bold`}>{formatCurrencyBRL(f.totalBalance)}</span>
                                        </div>
                                    </div>
                                );

                                return (
                                    <>
                                        <FinCard
                                            accent="blue"
                                            icon={<svg className="w-4 h-4 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>}
                                            title="Total Títulos"
                                            mainValue={formatCurrencyBRL(fin.totalBalance)}
                                            count={filteredTitles.length}
                                            countLabel="título(s)"
                                            fin={fin}
                                        />
                                        <FinCard
                                            accent="green"
                                            icon={<svg className="w-4 h-4 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
                                            title="A Vencer"
                                            mainValue={formatCurrencyBRL(finAVencer.totalBalance)}
                                            count={aVencerTitles.length}
                                            countLabel="título(s)"
                                            fin={finAVencer}
                                            clickable
                                            active={selectedCardBucket === 'A Vencer'}
                                            onClick={() => handleCardClick('A Vencer')}
                                        />
                                        <FinCard
                                            accent="red"
                                            icon={<svg className="w-4 h-4 text-red-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>}
                                            title="Vencidos"
                                            mainValue={formatCurrencyBRL(finOverdue.totalBalance)}
                                            count={overdueCount}
                                            countLabel="título(s)"
                                            fin={finOverdue}
                                            clickable
                                            active={selectedCardBucket === 'Vencidos'}
                                            onClick={() => handleCardClick('Vencidos')}
                                        />
                                        <FinCard
                                            accent="purple"
                                            icon={<svg className="w-4 h-4 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>}
                                            title="Saldo Devedor Total"
                                            mainValue={formatCurrencyBRL(fin.totalBalance)}
                                            mainLabel="= Orig. + Encargos − Desc. − Recebido"
                                            fin={fin}
                                        />
                                    </>
                                );
                            })()}

                        </div>

                        {/* Cancel Request card row */}
                        {cancelNotes.length > 0 && (
                            <div className="mt-2">
                                <button onClick={() => setDashboardCancelFilter(prev => prev === 'MY' ? null : 'MY')}
                                    className={`w-full text-left border rounded-xl px-4 py-3 flex items-center justify-between transition-all ${dashboardCancelFilter === 'MY' ? 'bg-orange-100 border-orange-400 ring-2 ring-orange-300' : 'bg-orange-50 border-orange-200 hover:border-orange-400 hover:bg-orange-100'}`}>
                                    <div className="flex items-center gap-2">
                                        <svg className="w-5 h-5 text-orange-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>
                                        <div>
                                            <p className="text-xs font-bold text-orange-800 uppercase tracking-wider">Solicitações de Cancelamento</p>
                                            <p className="text-[11px] text-orange-600">Registradas por você — clique para ver</p>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <span className="text-2xl font-black text-orange-700">{cancelNotes.length}</span>
                                        <svg className={`w-4 h-4 text-orange-500 transition-transform ${dashboardCancelFilter === 'MY' ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7"/></svg>
                                    </div>
                                </button>

                                {dashboardCancelFilter === 'MY' && (
                                    <div className="mt-2 space-y-2 max-h-72 overflow-y-auto pr-1">
                                        {cancelNotes.map(n => {
                                            const relTitle = titles.find(t => t.id === n.titleId);
                                            return (
                                                <div key={n.id} className="bg-white border border-orange-200 rounded-xl p-3 shadow-sm flex items-start gap-3">
                                                    <div className="flex-1 min-w-0">
                                                        <div className="flex items-center gap-2 mb-1 flex-wrap">
                                                            <span className="text-xs font-bold text-gray-800">{relTitle?.clientName || n.clientId}</span>
                                                            {relTitle && <span className="text-[10px] text-gray-500 font-mono">{relTitle.documentNumber}</span>}
                                                            <span className="text-[10px] text-gray-400 ml-auto">{new Date(n.date + 'T00:00:00').toLocaleDateString('pt-BR')} {n.time}</span>
                                                        </div>
                                                        <div className="text-[11px] text-orange-700 space-y-0.5">
                                                            <div>Contrato: <span className="font-semibold">{n.cancelRequest!.admissionContract || '—'}</span></div>
                                                            {n.cancelRequest!.notes && <div className="italic text-gray-600">{n.cancelRequest!.notes}</div>}
                                                        </div>
                                                    </div>
                                                    {relTitle && (
                                                        <button onClick={() => setContactModalTitle(relTitle)}
                                                            className="shrink-0 text-[10px] font-semibold text-moss-700 hover:text-moss-900 bg-moss-50 hover:bg-moss-100 border border-moss-200 px-2 py-1 rounded-lg transition-colors">
                                                            Ver
                                                        </button>
                                                    )}
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </div>
                        )}

                        {selectedCardBucket && (
                            <div className="mt-1 flex items-center gap-2">
                                <span className="text-xs text-moss-700 bg-moss-50 border border-moss-200 px-3 py-1 rounded-full font-semibold">Filtro ativo: {selectedCardBucket}</span>
                                <button onClick={() => setSelectedCardBucket(null)} className="text-xs text-gray-500 hover:text-red-600 underline">Limpar</button>
                            </div>
                        )}
                    </div>

                    <div className="flex-1 bg-gray-50 overflow-hidden flex">
                        <div className={`flex flex-col transition-all duration-300 ${activeTitle ? 'w-1/2 border-r border-gray-200' : 'w-full'} overflow-auto p-6`}>
                            <div className="flex items-center justify-between mb-4 gap-4 flex-wrap">
                                <div className="flex items-center gap-3 flex-wrap">
                                    <input type="text" placeholder="Buscar cliente..." className="rounded-lg border border-gray-300 px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none w-52" value={filterClient} onChange={e => setFilterClient(e.target.value)} />
                                    <button onClick={() => setShowFilters(!showFilters)} className="px-4 py-2.5 text-sm rounded-lg border border-gray-300 bg-white hover:bg-gray-50 transition-colors flex items-center gap-2">
                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" /></svg>
                                        Filtros {showFilters ? '▲' : '▼'}
                                    </button>
                                </div>
                                <span className="text-xs text-gray-400">{filteredTitles.length} de {myTitles.length} título(s)</span>
                            </div>

                            {showFilters && (
                                <div className="bg-white rounded-xl border border-gray-200 p-5 mb-4 grid grid-cols-2 md:grid-cols-3 gap-4 shadow-sm">
                                    {isAdmin && (
                                        <div>
                                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Responsável</label>
                                            <select className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterCollaborator} onChange={e => setFilterCollaborator(e.target.value)}>
                                                <option value="">Todos</option>
                                                {collaborators.filter(c => myTitles.some(t => t.assignedCollaboratorId === c.id)).map(c => (
                                                    <option key={c.id} value={c.id}>{c.name}</option>
                                                ))}
                                            </select>
                                        </div>
                                    )}
                                    <div>
                                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Status</label>
                                        <select className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                                            <option value="">Todos</option>
                                            <option value="ABERTO">Em Aberto</option>
                                            <option value="PARCIAL">Parcial</option>
                                            <option value="PROTESTADO">Protestado</option>
                                            <option value="PROVISAO">Provisão</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Faixa de Atraso</label>
                                        <select className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterAging} onChange={e => { setFilterAging(e.target.value); setSelectedCardBucket(null); }}>
                                            <option value="">Todos</option>
                                            <option value="A Vencer">A Vencer</option>
                                            <option value="1-30 dias">1-30 dias</option>
                                            <option value="31-60 dias">31-60 dias</option>
                                            <option value="61-90 dias">61-90 dias</option>
                                            <option value="90+ dias">90+ dias</option>
                                        </select>
                                    </div>
                                    <div>
                                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Vencimento De</label>
                                        <input type="date" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterDueDateStart} onChange={e => setFilterDueDateStart(e.target.value)} />
                                    </div>
                                    <div>
                                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Vencimento Até</label>
                                        <input type="date" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterDueDateEnd} onChange={e => setFilterDueDateEnd(e.target.value)} />
                                    </div>
                                    <div className="flex items-end">
                                        <button onClick={() => { setFilterClient(''); setFilterCollaborator(''); setFilterStatus(''); setFilterDueDateStart(''); setFilterDueDateEnd(''); setFilterAging(''); setSelectedCardBucket(null); }} className="px-4 py-2.5 text-sm rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-600">Limpar Filtros</button>
                                    </div>
                                </div>
                            )}

                            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                <div className="overflow-x-auto">
                                    <table className="min-w-full text-sm data-grid-typography">
                                        <thead className="bg-gray-50 border-b border-gray-200">
                                            <tr>
                                                <th className="w-1"></th>
                                                <th className="px-3 py-3 text-left font-semibold text-gray-600 cursor-pointer select-none hover:text-moss-700" onClick={() => handleSort('clientName')}>Cliente {sortIcon('clientName')}</th>
                                                <th className="px-3 py-3 text-center font-semibold text-gray-600" title="Fichas de Admissão (AUDITADA/FINALIZADA)">Fichas</th>
                                                <th className="px-3 py-3 text-center font-semibold text-gray-600" title="Aditivos Contratuais">Aditivos</th>
                                                {isAdmin && <th className="px-3 py-3 text-left font-semibold text-gray-600">Responsável</th>}
                                                <th className="px-3 py-3 text-left font-semibold text-gray-600 cursor-pointer select-none hover:text-moss-700" onClick={() => handleSort('documentNumber')}>Documento {sortIcon('documentNumber')}</th>
                                                <th className="px-3 py-3 text-left font-semibold text-gray-600 cursor-pointer select-none hover:text-moss-700" onClick={() => handleSort('dueDate')}>Vencimento {sortIcon('dueDate')}</th>
                                                <th className="px-3 py-3 text-right font-semibold text-gray-600 cursor-pointer select-none hover:text-moss-700" onClick={() => handleSort('currentBalance')}>Saldo {sortIcon('currentBalance')}</th>
                                                <th className="px-3 py-3 text-center font-semibold text-gray-600">Atraso</th>
                                                <th className="px-3 py-3 text-center font-semibold text-gray-600">Status</th>
                                                <th className="px-3 py-3 text-center font-semibold text-gray-600">Próx. Contato</th>
                                                <th className="px-3 py-3 text-center font-semibold text-gray-600">Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-gray-100">
                                            {filteredTitles.length === 0 && (
                                                <tr><td colSpan={isAdmin ? 12 : 11} className="px-6 py-12 text-center text-gray-400">
                                                    <svg className="w-10 h-10 mx-auto mb-2 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                                                    {isAdmin ? 'Nenhum título em cobrança no momento.' : currentCollaborator ? 'Nenhum título atribuído a você no momento.' : 'Vincule seu usuário a um colaborador para ver os títulos.'}
                                                </td></tr>
                                            )}
                                            {filteredTitles.map(t => {
                                                const days = agingDays(t.dueDate);
                                                const isOverdue = days > 0;
                                                const bucket = agingBucket(days);
                                                const borderColor = bucket === 'A Vencer' ? 'bg-green-400' : bucket === '1-30 dias' ? 'bg-yellow-400' : bucket === '31-60 dias' ? 'bg-orange-400' : bucket === '61-90 dias' ? 'bg-red-400' : 'bg-red-600';
                                                const agingBadgeBg = bucket === 'A Vencer' ? 'bg-green-100 text-green-700' : bucket === '1-30 dias' ? 'bg-yellow-100 text-yellow-700' : bucket === '31-60 dias' ? 'bg-orange-100 text-orange-700' : bucket === '61-90 dias' ? 'bg-red-100 text-red-700' : 'bg-red-200 text-red-800';
                                                const isActive = activeTitle?.id === t.id;
                                                const titleNoteCount = collectionNotes.filter(n => n.clientId === t.clientId).length;
                                                return (
                                                    <tr
                                                        key={t.id}
                                                        className={`hover:bg-gray-50 transition-colors cursor-pointer ${isOverdue ? 'bg-red-50/20' : ''} ${isActive ? 'bg-moss-50 ring-1 ring-inset ring-moss-300' : ''}`}
                                                        onDoubleClick={() => setActiveTitle(prev => prev?.id === t.id ? null : t)}
                                                        title="Duplo clique para abrir gestão de cobrança"
                                                    >
                                                        <td className="w-1 p-0"><div className={`w-1 h-full min-h-[48px] ${borderColor}`}></div></td>
                                                        <td className="px-3 py-3 font-medium text-gray-800 max-w-[160px]">
                                                            <div className="flex items-center gap-1.5 max-w-full">
                                                                <span className="truncate">{t.clientName}</span>
                                                                {(() => {
                                                                    const phoneKey = clientPhoneKey[t.clientId];
                                                                    const unread = phoneKey ? (waUnreadByPhone[phoneKey] || 0) : 0;
                                                                    if (unread <= 0) return null;
                                                                    return (
                                                                        <span
                                                                            className="inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-red-600 text-white text-[10px] font-bold ring-2 ring-red-100 shrink-0"
                                                                            title={`${unread} mensagem(ns) WhatsApp não lida(s)`}
                                                                        >
                                                                            {unread > 99 ? '99+' : unread}
                                                                        </span>
                                                                    );
                                                                })()}
                                                            </div>
                                                            {titleNoteCount > 0 && <span className="text-[10px] text-moss-600 font-semibold">{titleNoteCount} nota(s)</span>}
                                                        </td>
                                                        <td className="px-3 py-3 text-center">
                                                            {collectionSummary[t.clientId]?.fichas != null ? (
                                                                <span className={`inline-block min-w-[20px] px-1.5 py-0.5 rounded-full text-[10px] font-bold ${collectionSummary[t.clientId].fichas > 0 ? 'bg-purple-100 text-purple-800' : 'bg-gray-100 text-gray-500'}`}>
                                                                    {collectionSummary[t.clientId].fichas}
                                                                </span>
                                                            ) : <span className="text-gray-300 text-xs">—</span>}
                                                        </td>
                                                        <td className="px-3 py-3 text-center">
                                                            {collectionSummary[t.clientId]?.aditivos != null ? (
                                                                <span className={`inline-block min-w-[20px] px-1.5 py-0.5 rounded-full text-[10px] font-bold ${collectionSummary[t.clientId].aditivos > 0 ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-500'}`}>
                                                                    {collectionSummary[t.clientId].aditivos}
                                                                </span>
                                                            ) : <span className="text-gray-300 text-xs">—</span>}
                                                        </td>
                                                        {isAdmin && (
                                                            <td className="px-3 py-3 text-gray-500 text-xs max-w-[120px] truncate">
                                                                {collaborators.find(c => c.id === t.assignedCollaboratorId)?.name || <span className="italic text-gray-300">—</span>}
                                                            </td>
                                                        )}
                                                        <td className="px-3 py-3 text-gray-600 font-mono text-xs">{t.documentNumber}</td>
                                                        <td className="px-3 py-3 text-gray-700 font-medium text-xs">{new Date(t.dueDate + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                                                        <td className="px-3 py-3 text-right font-bold text-blue-800">{formatCurrencyBRL(t.currentBalance)}</td>
                                                        <td className="px-3 py-3 text-center">
                                                            <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${agingBadgeBg}`}>
                                                                {isOverdue ? `${days}d` : 'Em dia'}
                                                            </span>
                                                        </td>
                                                        <td className="px-3 py-3 text-center">
                                                            <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${t.status === 'ABERTO' ? 'bg-blue-100 text-blue-700' : t.status === 'PARCIAL' ? 'bg-yellow-100 text-yellow-700' : t.status === 'PROTESTADO' ? 'bg-red-100 text-red-700' : t.status === 'PROVISAO' ? 'bg-amber-100 text-amber-700' : 'bg-gray-100 text-gray-600'}`}>
                                                                {statusLabel(t.status)}
                                                            </span>
                                                        </td>
                                                        <td className="px-3 py-3 text-center text-xs">
                                                            {(() => {
                                                                const latestNext = collectionNotes
                                                                    .filter(n => n.titleId === t.id && n.nextContactDate)
                                                                    .sort((a, b) => b.date.localeCompare(a.date))[0]?.nextContactDate;
                                                                if (!latestNext) return <span className="text-gray-300">—</span>;
                                                                const isPast = latestNext < new Date().toISOString().split('T')[0];
                                                                return (
                                                                    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full font-semibold ${isPast ? 'bg-red-100 text-red-700' : 'bg-moss-100 text-moss-700'}`}>
                                                                        <svg className="w-2.5 h-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                                                        {new Date(latestNext + 'T00:00:00').toLocaleDateString('pt-BR')}
                                                                    </span>
                                                                );
                                                            })()}
                                                        </td>
                                                        <td className="px-3 py-3 text-center">
                                                            <div className="flex justify-center items-center gap-1">
                                                                <button
                                                                    onClick={e => { e.stopPropagation(); setContactModalTitle(t); setModalNoteForm(emptyNoteForm); }}
                                                                    className="text-blue-600 hover:text-blue-800 transition-colors p-1.5 rounded hover:bg-blue-50 relative"
                                                                    title="Registrar / Ver Contatos"
                                                                >
                                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                                                                    {titleNoteCount > 0 && (
                                                                        <span className="absolute -top-0.5 -right-0.5 bg-blue-600 text-white text-[9px] font-bold rounded-full w-3.5 h-3.5 flex items-center justify-center">{titleNoteCount > 9 ? '9+' : titleNoteCount}</span>
                                                                    )}
                                                                </button>
                                                                <AuditLogButton entityId={t.id} entityName={t.clientName || t.documentNumber} logs={auditLogs} />
                                                                <button onClick={e => { e.stopPropagation(); handleOpenClientPanel(t.clientId); }} className="text-moss-600 hover:text-moss-800 transition-colors p-1.5 rounded hover:bg-moss-50" title="Dados do Cliente">
                                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                                                                </button>
                                                                {canExcluir && (
                                                                    <button onClick={e => { e.stopPropagation(); handleDeleteTitle(t); }} className="text-red-500 hover:text-red-700 transition-colors p-1.5 rounded hover:bg-red-50" title="Excluir Título">
                                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                                                    </button>
                                                                )}
                                                            </div>
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                        {filteredTitles.length > 0 && (
                                            <tfoot className="border-t-2 border-gray-200">
                                                <tr className="bg-gray-50">
                                                    <td className="w-1 p-0 bg-moss-600 rounded-bl"></td>
                                                    <td className="px-3 py-2 font-bold text-gray-700 text-xs" colSpan={isAdmin ? 6 : 5}>
                                                        <span className="text-moss-700">{filteredTitles.length} título(s)</span>
                                                        <span className="ml-2 text-[10px] font-normal text-red-500">{overdueCount} vencido(s)</span>
                                                    </td>
                                                    <td className="px-3 py-2 text-right">
                                                        <div className="text-[10px] text-gray-400">Saldo Devedor</div>
                                                        <div className="font-bold text-blue-800 text-sm">{formatCurrencyBRL(fin.totalBalance)}</div>
                                                    </td>
                                                    <td className="px-3 py-2 text-center">
                                                        <div className="text-[10px] text-gray-400 mb-0.5">Atraso</div>
                                                        <span className="text-[10px] text-red-600 font-bold">{overdueCount} venc.</span>
                                                    </td>
                                                    <td colSpan={3}></td>
                                                </tr>
                                                <tr className="bg-gradient-to-r from-moss-50 to-blue-50 border-t border-gray-200">
                                                    <td className="w-1 p-0 bg-moss-600"></td>
                                                    <td className="px-3 py-2.5 text-[10px] font-bold text-gray-500 uppercase tracking-wider" colSpan={isAdmin ? 11 : 10}>
                                                        <div className="flex flex-wrap items-center gap-x-4 gap-y-1">
                                                            <span className="text-gray-600">Recálculo Financeiro</span>
                                                            <span className="flex items-center gap-1">
                                                                <span className="text-gray-400">Valor Original:</span>
                                                                <span className="font-bold text-gray-700">{formatCurrencyBRL(fin.totalOriginal)}</span>
                                                            </span>
                                                            {fin.totalInterest > 0 && (
                                                                <span className="flex items-center gap-1">
                                                                    <span className="text-orange-400">+ Juros:</span>
                                                                    <span className="font-bold text-orange-600">{formatCurrencyBRL(fin.totalInterest)}</span>
                                                                </span>
                                                            )}
                                                            {fin.totalPenalty > 0 && (
                                                                <span className="flex items-center gap-1">
                                                                    <span className="text-red-400">+ Multa:</span>
                                                                    <span className="font-bold text-red-600">{formatCurrencyBRL(fin.totalPenalty)}</span>
                                                                </span>
                                                            )}
                                                            {fin.totalDiscount > 0 && (
                                                                <span className="flex items-center gap-1">
                                                                    <span className="text-green-500">− Desconto:</span>
                                                                    <span className="font-bold text-green-700">{formatCurrencyBRL(fin.totalDiscount)}</span>
                                                                </span>
                                                            )}
                                                            <span className="flex items-center gap-1 border-l border-gray-300 pl-3">
                                                                <span className="text-purple-500">= Valor Atualizado:</span>
                                                                <span className="font-bold text-purple-700">{formatCurrencyBRL(fin.totalUpdated)}</span>
                                                            </span>
                                                            {fin.totalPaid > 0 && (
                                                                <span className="flex items-center gap-1">
                                                                    <span className="text-gray-400">− Recebido:</span>
                                                                    <span className="font-bold text-gray-500">{formatCurrencyBRL(fin.totalPaid)}</span>
                                                                </span>
                                                            )}
                                                            <span className="flex items-center gap-1 border-l border-gray-300 pl-3">
                                                                <span className="text-blue-600 font-bold">= Saldo Devedor:</span>
                                                                <span className="font-bold text-blue-800 text-xs">{formatCurrencyBRL(fin.totalBalance)}</span>
                                                            </span>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </tfoot>
                                        )}
                                    </table>
                                </div>
                            </div>
                            {!activeTitle && filteredTitles.length > 0 && (
                                <p className="text-center text-xs text-gray-400 mt-3">Dê duplo clique em um título para abrir a gestão de cobrança</p>
                            )}
                        </div>

                        {activeTitle && (
                            <div className="w-1/2 flex flex-col overflow-hidden bg-white">
                                <div className="bg-moss-700 text-white px-5 py-3 flex items-center justify-between flex-shrink-0">
                                    <div>
                                        <h3 className="font-bold text-base">{activeTitle.clientName}</h3>
                                        <p className="text-moss-200 text-xs">Doc: {activeTitle.documentNumber} · Venc: {fmtDate(activeTitle.dueDate)} · Saldo: {formatCurrencyBRL(activeTitle.currentBalance)}</p>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <button
                                            onClick={() => handleOpenClientPanel(activeTitle.clientId)}
                                            className="flex items-center gap-1.5 text-xs font-semibold bg-white/15 hover:bg-white/25 text-white px-3 py-1.5 rounded-lg transition-colors"
                                            title="Ver Dados do Cliente"
                                        >
                                            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                                            Ver Cliente
                                        </button>
                                        <button onClick={() => setActiveTitle(null)} className="text-white/70 hover:text-white p-1 rounded">
                                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                                        </button>
                                    </div>
                                </div>

                                <div className="flex-1 overflow-y-auto">
                                    {activeTitleAdmission && (
                                        <div className="bg-moss-50 border-b border-moss-200 px-5 py-4">
                                            <div className="flex items-center justify-between mb-3">
                                                <h4 className="text-xs font-bold text-moss-700 uppercase tracking-wider flex items-center gap-2">
                                                    <div className="w-1.5 h-4 rounded-full bg-moss-500"></div>
                                                    Resumo da Ficha de Admissão
                                                </h4>
                                                <button onClick={() => handleOpenAdmissionModal(activeTitleAdmission)} className="text-xs text-moss-600 hover:text-moss-800 bg-white border border-moss-300 px-3 py-1 rounded-full font-semibold flex items-center gap-1 transition-colors hover:shadow-sm">
                                                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                                    Ver Ficha Completa
                                                </button>
                                            </div>
                                            <div className="grid grid-cols-2 gap-2 text-xs">
                                                {[
                                                    ['Contrato', `#${activeTitleAdmission.contractNumber || '—'}`],
                                                    ['Status', activeTitleAdmission.status],
                                                    ['Valor Financiado', `R$ ${activeTitleAdmission.financedAmount || '—'}`],
                                                    ['Parcela', `R$ ${activeTitleAdmission.installmentValue || '—'}`],
                                                    ['Parcelas', `${activeTitleAdmission.paidInstallments || 0}/${activeTitleAdmission.totalInstallments || 0} pagas`],
                                                    ['Em Atraso', `${activeTitleAdmission.overdueInstallments || 0} parcelas`],
                                                    ['Vencimento', `Dia ${activeTitleAdmission.dueDay || '—'}`],
                                                    ['Tipo Pgto', activeTitleAdmission.paymentType || '—'],
                                                ].map(([label, value]) => (
                                                    <div key={label} className="bg-white rounded-lg px-3 py-2 border border-moss-100">
                                                        <p className="text-[9px] text-moss-500 uppercase font-bold mb-0.5">{label}</p>
                                                        <p className="font-semibold text-gray-800 truncate">{value}</p>
                                                    </div>
                                                ))}
                                                {activeTitleAdmission.vehicleBrand && (
                                                    <div className="col-span-2 bg-purple-50 rounded-lg px-3 py-2 border border-purple-100">
                                                        <p className="text-[9px] text-purple-500 uppercase font-bold mb-0.5">Veículo</p>
                                                        <p className="font-semibold text-gray-800">{activeTitleAdmission.vehicleBrand} {activeTitleAdmission.vehicleModel} {activeTitleAdmission.vehicleYear} — {activeTitleAdmission.vehiclePlate || '—'}</p>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    )}

                                    <div className="px-5 py-4 border-b border-gray-200">
                                        <div className="flex items-center justify-between mb-3">
                                            <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider flex items-center gap-2">
                                                <div className="w-1.5 h-4 rounded-full bg-blue-500"></div>
                                                Títulos do Cliente ({activeTitleClientTitles.length})
                                            </h4>
                                            <button
                                                onClick={() => setShowCancelledTitles(p => !p)}
                                                className={`text-xs px-3 py-1 rounded-full font-semibold border transition-colors ${showCancelledTitles ? 'bg-gray-700 text-white border-gray-700' : 'bg-white text-gray-500 border-gray-300 hover:bg-gray-50'}`}
                                            >
                                                {showCancelledTitles ? 'Ocultar Cancelados' : 'Ver Cancelados'}
                                            </button>
                                        </div>
                                        <div className="space-y-1.5 max-h-48 overflow-y-auto">
                                            {activeTitleClientTitles.length === 0 && <p className="text-xs text-gray-400 text-center py-3">Nenhum título encontrado.</p>}
                                            {activeTitleClientTitles.map(t => {
                                                const d = agingDays(t.dueDate);
                                                const isSelected = t.id === activeTitle.id;
                                                return (
                                                    <div key={t.id} className={`flex items-center justify-between rounded-lg px-3 py-2 border text-xs ${isSelected ? 'bg-moss-50 border-moss-300 font-semibold' : 'bg-white border-gray-100'} ${t.status === 'CANCELADO' ? 'opacity-50' : ''}`}>
                                                        <div className="flex-1 min-w-0">
                                                            <span className="text-gray-500 font-mono">{t.documentNumber}</span>
                                                            <span className="mx-1 text-gray-300">·</span>
                                                            <span className="text-gray-600">{fmtDate(t.dueDate)}</span>
                                                        </div>
                                                        <div className="flex items-center gap-2 ml-2 flex-shrink-0">
                                                            <span className="font-bold text-blue-800">{formatCurrencyBRL(t.currentBalance)}</span>
                                                            <span className={`px-1.5 py-0.5 rounded text-[9px] font-bold ${t.status === 'PAGO' ? 'bg-green-100 text-green-700' : t.status === 'CANCELADO' ? 'bg-gray-100 text-gray-500' : d > 0 ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'}`}>
                                                                {t.status === 'PAGO' ? 'Pago' : t.status === 'CANCELADO' ? 'Canc.' : d > 0 ? `${d}d` : 'OK'}
                                                            </span>
                                                        </div>
                                                    </div>
                                                );
                                            })}
                                        </div>
                                    </div>

                                    <div className="px-5 py-4 border-b border-gray-200">
                                        <h4 className="text-xs font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-2">
                                            <div className="w-1.5 h-4 rounded-full bg-amber-500"></div>
                                            Linha do Tempo de Contatos
                                            {activeTitleNotes.length > 0 && (
                                                <span className="bg-amber-100 text-amber-700 text-[9px] font-bold px-2 py-0.5 rounded-full">{activeTitleNotes.length}</span>
                                            )}
                                        </h4>
                                        {activeTitleNotes.length === 0 ? (
                                            <div className="flex flex-col items-center justify-center py-5 text-gray-400">
                                                <svg className="w-8 h-8 mb-2 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                                                <p className="text-xs">Nenhum contato registrado ainda.</p>
                                            </div>
                                        ) : (
                                            <div className="relative max-h-52 overflow-y-auto pr-1">
                                                {/* linha vertical da timeline */}
                                                <div className="absolute left-3.5 top-0 bottom-0 w-px bg-gradient-to-b from-amber-300 via-amber-200 to-transparent"></div>
                                                <div className="space-y-3 pl-10">
                                                    {activeTitleNotes.map((note, idx) => {
                                                        const dotColor = note.negotiationStatus === 'FECHADA'
                                                            ? 'bg-green-500 ring-green-200'
                                                            : note.negotiationStatus === 'RECUSA_DIVIDA'
                                                            ? 'bg-red-500 ring-red-200'
                                                            : note.negotiationStatus === 'ENCAMINHOU_BOLETO'
                                                            ? 'bg-blue-500 ring-blue-200'
                                                            : 'bg-amber-400 ring-amber-200';
                                                        return (
                                                            <div key={note.id} className="relative">
                                                                {/* dot */}
                                                                <div className={`absolute -left-[27px] top-2 w-5 h-5 rounded-full ${dotColor} ring-2 flex items-center justify-center text-white shadow-sm z-10 shrink-0`}>
                                                                    <span className="text-[9px]">{contactChannelIcon(note.contactChannel)}</span>
                                                                </div>
                                                                {/* card */}
                                                                <div className={`bg-white rounded-xl border text-xs shadow-sm ${idx === 0 ? 'border-amber-200' : 'border-gray-200'}`}>
                                                                    {/* header */}
                                                                    <div className={`flex items-center justify-between gap-1 px-3 py-2 rounded-t-xl ${idx === 0 ? 'bg-amber-50' : 'bg-gray-50'} border-b border-gray-100`}>
                                                                        <div className="flex items-center gap-1.5 min-w-0">
                                                                            <span className="font-semibold text-gray-700 truncate">{note.collaboratorName}</span>
                                                                            <span className="text-gray-300">·</span>
                                                                            <span className="text-gray-400 whitespace-nowrap">{fmtDate(note.date)} {note.time}</span>
                                                                        </div>
                                                                        <div className="flex items-center gap-1.5 shrink-0">
                                                                            <span className={`px-1.5 py-0.5 rounded-full text-[9px] font-bold ${negotiationStatusColor(note.negotiationStatus)}`}>
                                                                                {negotiationStatusLabel(note.negotiationStatus)}
                                                                            </span>
                                                                            {canExcluir && (
                                                                                <>
                                                                                    <button onClick={() => handleStartEditNote(note)} className="text-blue-400 hover:text-blue-600 text-[9px] font-bold px-1.5 py-0.5 rounded hover:bg-blue-50 transition-colors">Editar</button>
                                                                                    <button onClick={() => handleDeleteNote(note.id)} className="text-red-400 hover:text-red-600 text-[9px] font-bold px-1.5 py-0.5 rounded hover:bg-red-50 transition-colors">Excluir</button>
                                                                                </>
                                                                            )}
                                                                        </div>
                                                                    </div>
                                                                    {/* body */}
                                                                    <div className="px-3 py-2">
                                                                        {editingNoteId === note.id ? (
                                                                            <div className="flex flex-col gap-1.5">
                                                                                <textarea className="w-full rounded-lg border border-blue-300 px-2 py-1.5 text-xs focus:ring-2 focus:ring-blue-400 outline-none resize-none" rows={3} value={editNoteText} onChange={e => setEditNoteText(e.target.value)} autoFocus />
                                                                                <div className="flex gap-1.5 justify-end">
                                                                                    <button onClick={() => { setEditingNoteId(null); setEditNoteText(''); }} className="px-3 py-1 text-[10px] font-semibold rounded bg-gray-100 hover:bg-gray-200 text-gray-600 transition-colors">Cancelar</button>
                                                                                    <button onClick={handleSaveEditNote} className="px-3 py-1 text-[10px] font-semibold rounded bg-blue-600 hover:bg-blue-700 text-white transition-colors">Salvar</button>
                                                                                </div>
                                                                            </div>
                                                                        ) : (
                                                                            <p className="text-gray-700 leading-relaxed">{note.note}</p>
                                                                        )}
                                                                        {note.negotiationStatusOther && (
                                                                            <p className="text-gray-400 italic mt-0.5 text-[10px]">› {note.negotiationStatusOther}</p>
                                                                        )}
                                                                        {note.nextContactDate && (
                                                                            <div className="mt-1.5 flex items-center gap-1 text-blue-600">
                                                                                <svg className="w-3 h-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                                                                <span className="font-semibold text-[10px]">Próx. Contato: {fmtDate(note.nextContactDate)}</span>
                                                                            </div>
                                                                        )}
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        );
                                                    })}
                                                </div>
                                            </div>
                                        )}
                                    </div>

                                    <div className="px-5 py-4">
                                        <h4 className="text-xs font-bold text-moss-700 uppercase tracking-wider mb-3 flex items-center gap-2">
                                            <div className="w-1.5 h-4 rounded-full bg-moss-500"></div>
                                            Registrar Contato
                                        </h4>
                                        <div className="space-y-3">
                                            <div>
                                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Forma de Contato</label>
                                                <div className="grid grid-cols-4 gap-2">
                                                    {([['TELEFONE', '📞', 'Telefone'], ['WHATSAPP', '💬', 'WhatsApp'], ['EMAIL', '✉️', 'E-mail'], ['MENSAGEM', '📩', 'Mensagem']] as const).map(([val, icon, label]) => (
                                                        <button
                                                            key={val}
                                                            onClick={() => setNoteForm(f => ({ ...f, contactChannel: val as CollectionNote['contactChannel'] }))}
                                                            className={`flex flex-col items-center px-2 py-2 rounded-lg border text-xs font-semibold transition-colors ${noteForm.contactChannel === val ? 'bg-moss-600 text-white border-moss-600' : 'bg-white text-gray-600 border-gray-300 hover:bg-gray-50'}`}
                                                        >
                                                            <span className="text-base">{icon}</span>
                                                            <span className="text-[9px] mt-0.5">{label}</span>
                                                        </button>
                                                    ))}
                                                </div>
                                            </div>

                                            <div>
                                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Nota / Observação <span className="text-red-500">*</span></label>
                                                <textarea
                                                    rows={3}
                                                    className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 outline-none resize-none"
                                                    placeholder="Descreva o contato, negociação ou observação..."
                                                    value={noteForm.note}
                                                    onChange={e => setNoteForm(f => ({ ...f, note: e.target.value }))}
                                                />
                                            </div>

                                            <div className="grid grid-cols-2 gap-3">
                                                <div>
                                                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Status Negociação <span className="text-red-500">*</span></label>
                                                    <select
                                                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 outline-none"
                                                        value={noteForm.negotiationStatus}
                                                        onChange={e => setNoteForm(f => ({ ...f, negotiationStatus: e.target.value as CollectionNote['negotiationStatus'] }))}
                                                    >
                                                        <option value="AGUARDANDO_CONTATO">Aguardando Contato</option>
                                                        <option value="ENCAMINHOU_BOLETO">Encaminhou Boleto/Pix</option>
                                                        <option value="FECHADA">Negociação Fechada</option>
                                                        <option value="RECUSA_DIVIDA">Recusa Dívida</option>
                                                        <option value="OUTROS">Outros</option>
                                                    </select>
                                                </div>
                                                <div>
                                                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Próximo Contato <span className="text-gray-400 font-normal">(opcional)</span></label>
                                                    <input
                                                        type="date"
                                                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 outline-none"
                                                        value={noteForm.nextContactDate}
                                                        onChange={e => setNoteForm(f => ({ ...f, nextContactDate: e.target.value }))}
                                                    />
                                                </div>
                                            </div>

                                            {noteForm.negotiationStatus === 'OUTROS' && (
                                                <div>
                                                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Detalhe — Outros <span className="text-red-500">*</span></label>
                                                    <input
                                                        type="text"
                                                        className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 outline-none"
                                                        placeholder="Descreva o motivo..."
                                                        value={noteForm.negotiationStatusOther}
                                                        onChange={e => setNoteForm(f => ({ ...f, negotiationStatusOther: e.target.value }))}
                                                    />
                                                </div>
                                            )}

                                            <div className="bg-blue-50 rounded-lg px-3 py-2 border border-blue-100 text-xs text-blue-700">
                                                Ao salvar, a data do próximo contato será incluída na <strong>Agenda</strong> e uma mensagem será enviada ao <strong>grupo de usuários</strong>.
                                            </div>

                                            <button
                                                onClick={handleSaveNote}
                                                disabled={isSavingNote}
                                                className="w-full px-4 py-2.5 bg-moss-700 text-white rounded-lg text-sm font-bold hover:bg-moss-800 transition-colors disabled:opacity-60 flex items-center justify-center gap-2"
                                            >
                                                {isSavingNote ? (
                                                    <><svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg>Salvando...</>
                                                ) : (
                                                    <><svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"/></svg>Registrar Nota</>
                                                )}
                                            </button>
                                        </div>
                                        <div className="px-5 pb-4">
                                            <ClientAttachmentsPanel
                                                clientId={activeTitle.clientId}
                                                module="COLLECTION_PROSPECTION"
                                                targetType="FINANCIAL_TITLE"
                                                targetId={activeTitle.id}
                                                compact
                                            />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        )}
                    </div>
                </>
            )}

            {activeMode === 'DASHBOARD' && (
                <div className="flex-1 bg-gray-50 p-6 overflow-auto">
                    <div className="flex items-center gap-4 mb-6 flex-wrap">
                        <div>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Período De</label>
                            <input type="date" className="rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={dashboardPeriodStart} onChange={e => setDashboardPeriodStart(e.target.value)} />
                        </div>
                        <div>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Período Até</label>
                            <input type="date" className="rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={dashboardPeriodEnd} onChange={e => setDashboardPeriodEnd(e.target.value)} />
                        </div>
                        <div className="flex items-end">
                            <button onClick={() => { setDashboardPeriodStart(''); setDashboardPeriodEnd(''); }} className="px-4 py-2 text-sm rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-600 mt-5">Limpar</button>
                        </div>
                    </div>

                    <div className="mb-6">
                        <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-2">
                            <div className="w-2 h-6 rounded-full bg-amber-500"></div>
                            Resultados do Dia
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                                <div className="flex items-center gap-3 mb-2">
                                    <div className="w-10 h-10 rounded-lg bg-amber-100 flex items-center justify-center">
                                        <svg className="w-5 h-5 text-amber-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Vencendo Hoje</p>
                                        <p className="text-2xl font-bold text-amber-700">{dashboardData.dueTodayCount}</p>
                                    </div>
                                </div>
                                <p className="text-xs text-gray-400">Saldo: {formatCurrencyBRL(dashboardData.dueTodayBalance)}</p>
                            </div>
                            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                                <div className="flex items-center gap-3 mb-2">
                                    <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                                        <svg className="w-5 h-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Vencidos Acum.</p>
                                        <p className="text-2xl font-bold text-red-700">{dashboardData.overdueTodayCount}</p>
                                    </div>
                                </div>
                                <p className="text-xs text-gray-400">Saldo vencido: {formatCurrencyBRL(dashboardData.overdueTodayBalance)}</p>
                            </div>
                            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                                <div className="flex items-center gap-3 mb-2">
                                    <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                                        <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Baixas Hoje</p>
                                        <p className="text-2xl font-bold text-green-700">{dashboardData.settlementsToday}</p>
                                    </div>
                                </div>
                                <p className="text-xs text-gray-400">Recebido: {formatCurrencyBRL(dashboardData.settledAmountToday)}</p>
                            </div>
                        </div>
                    </div>

                    <div className="mb-6">
                        <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-2">
                            <div className="w-2 h-6 rounded-full bg-moss-500"></div>
                            Resultados Acumulados
                        </h3>
                        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                                <div className="flex items-center gap-3 mb-2">
                                    <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                                        <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Carteira Total</p>
                                        <p className="text-xl font-bold text-blue-800">{dashboardData.totalAssigned} tít.</p>
                                    </div>
                                </div>
                                <p className="text-xs text-gray-400 mb-2">Abertos: {dashboardData.openCount} | Pagos: {dashboardData.paidCount}</p>
                            </div>
                            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                                <div className="flex items-center gap-3 mb-2">
                                    <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                                        <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" /></svg>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Taxa Recuperação</p>
                                        <p className="text-xl font-bold text-green-700">{dashboardData.taxaRecuperacao.toFixed(1)}%</p>
                                    </div>
                                </div>
                                <p className="text-xs text-gray-400">Recuperado: {formatCurrencyBRL(dashboardData.recoveredValue)}</p>
                            </div>
                            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                                <div className="flex items-center gap-3 mb-2">
                                    <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                                        <svg className="w-5 h-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Inadimplência</p>
                                        <p className="text-xl font-bold text-red-700">{dashboardData.taxaInadimplencia.toFixed(1)}%</p>
                                    </div>
                                </div>
                                <p className="text-xs text-gray-400">Vencido: {formatCurrencyBRL(dashboardData.overdueBalancePeriod)}</p>
                            </div>
                            <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                                <div className="flex items-center gap-3 mb-2">
                                    <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                                        <svg className="w-5 h-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                    </div>
                                    <div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">DSO (Dias)</p>
                                        <p className="text-xl font-bold text-purple-700">{dashboardData.dso}</p>
                                    </div>
                                </div>
                                <p className="text-xs text-gray-400">Saldo aberto: {formatCurrencyBRL(dashboardData.openBalance)}</p>
                            </div>
                        </div>

                        <div className="mt-4 bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                            <h4 className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-4 flex items-center gap-2">
                                <div className="w-1.5 h-4 rounded-full bg-purple-500"></div>
                                Recálculo Financeiro da Carteira — Período Selecionado
                            </h4>
                            {/* Sentença-equação visual */}
                            <div className="flex flex-wrap items-center gap-1.5 mb-4 p-3 bg-gray-50 rounded-xl border border-gray-100">
                                <div className="flex flex-col items-center px-2">
                                    <span className="text-sm font-bold text-gray-700">{formatCurrencyBRL(dashboardData.finPeriod.totalOriginal)}</span>
                                    <span className="text-[9px] text-gray-400 uppercase">Orig.</span>
                                </div>
                                {dashboardData.finPeriod.totalInterest > 0 && <>
                                    <span className="text-base text-gray-300 font-light">+</span>
                                    <div className="flex flex-col items-center px-2">
                                        <span className="text-sm font-bold text-orange-600">{formatCurrencyBRL(dashboardData.finPeriod.totalInterest)}</span>
                                        <span className="text-[9px] text-orange-400 uppercase">Juros</span>
                                    </div>
                                </>}
                                {dashboardData.finPeriod.totalPenalty > 0 && <>
                                    <span className="text-base text-gray-300 font-light">+</span>
                                    <div className="flex flex-col items-center px-2">
                                        <span className="text-sm font-bold text-red-600">{formatCurrencyBRL(dashboardData.finPeriod.totalPenalty)}</span>
                                        <span className="text-[9px] text-red-400 uppercase">Multa</span>
                                    </div>
                                </>}
                                {dashboardData.finPeriod.totalDiscount > 0 && <>
                                    <span className="text-base text-gray-300 font-light">−</span>
                                    <div className="flex flex-col items-center px-2">
                                        <span className="text-sm font-bold text-green-600">{formatCurrencyBRL(dashboardData.finPeriod.totalDiscount)}</span>
                                        <span className="text-[9px] text-green-500 uppercase">Desc.</span>
                                    </div>
                                </>}
                                <span className="text-base text-gray-300 font-light">=</span>
                                <div className="flex flex-col items-center px-2 bg-purple-50 rounded-lg py-1 border border-purple-100">
                                    <span className="text-sm font-bold text-purple-700">{formatCurrencyBRL(dashboardData.finPeriod.totalUpdated)}</span>
                                    <span className="text-[9px] text-purple-500 uppercase">Atualizado</span>
                                </div>
                                {dashboardData.finPeriod.totalPaid > 0 && <>
                                    <span className="text-base text-gray-300 font-light">−</span>
                                    <div className="flex flex-col items-center px-2">
                                        <span className="text-sm font-bold text-gray-500">{formatCurrencyBRL(dashboardData.finPeriod.totalPaid)}</span>
                                        <span className="text-[9px] text-gray-400 uppercase">Recebido</span>
                                    </div>
                                </>}
                                <span className="text-base text-gray-300 font-light">=</span>
                                <div className="flex flex-col items-center px-2 bg-blue-50 rounded-lg py-1 border border-blue-200">
                                    <span className="text-sm font-bold text-blue-800">{formatCurrencyBRL(dashboardData.finPeriod.totalBalance)}</span>
                                    <span className="text-[9px] text-blue-600 uppercase font-bold">Saldo Devedor</span>
                                </div>
                            </div>
                            {/* Células de detalhe */}
                            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
                                {[
                                    { label: 'Valor Original', value: dashboardData.finPeriod.totalOriginal, tc: 'text-gray-700', bg: 'bg-gray-50', border: 'border-gray-200' },
                                    { label: '+ Juros', value: dashboardData.finPeriod.totalInterest, tc: 'text-orange-700', bg: 'bg-orange-50', border: 'border-orange-100' },
                                    { label: '+ Multa', value: dashboardData.finPeriod.totalPenalty, tc: 'text-red-700', bg: 'bg-red-50', border: 'border-red-100' },
                                    { label: '− Desconto', value: dashboardData.finPeriod.totalDiscount, tc: 'text-green-700', bg: 'bg-green-50', border: 'border-green-100' },
                                    { label: '= Atualizado', value: dashboardData.finPeriod.totalUpdated, tc: 'text-purple-800', bg: 'bg-purple-50', border: 'border-purple-200' },
                                    { label: '− Recebido', value: dashboardData.finPeriod.totalPaid, tc: 'text-gray-500', bg: 'bg-gray-50', border: 'border-gray-200' },
                                    { label: '= Saldo Devedor', value: dashboardData.finPeriod.totalBalance, tc: 'text-blue-800', bg: 'bg-blue-50', border: 'border-blue-200' },
                                ].map(({ label, value, tc, bg, border }) => (
                                    <div key={label} className={`${bg} rounded-lg p-2.5 border ${border}`}>
                                        <p className={`text-[9px] uppercase font-bold mb-1 ${tc} opacity-70`}>{label}</p>
                                        <p className={`text-xs font-bold ${tc}`}>{formatCurrencyBRL(value)}</p>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                            <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                                <div className="w-2 h-6 rounded-full bg-amber-500"></div>
                                Carteira por Faixa de Atraso
                            </h3>
                            <div className="space-y-3">
                                {Object.entries(dashboardData.agingBuckets).map(([bucket, data]) => (
                                    <div key={bucket} className="flex items-center gap-3">
                                        <span className="text-xs text-gray-500 w-20 text-right font-medium">{bucket}</span>
                                        <div className="flex-1 bg-gray-100 rounded-full h-7 overflow-hidden relative">
                                            <div className={`h-full rounded-full transition-all ${agingBucketColor(bucket)}`} style={{ width: `${Math.max((data.balance / maxBucketBalance) * 100, 2)}%` }}></div>
                                            {data.count > 0 && (
                                                <span className="absolute inset-0 flex items-center justify-center text-xs font-semibold text-gray-700">{data.count} tít.</span>
                                            )}
                                        </div>
                                        <span className="text-xs text-gray-700 w-28 text-right font-semibold">{formatCurrencyBRL(data.balance)}</span>
                                    </div>
                                ))}
                            </div>
                            <div className="mt-4 pt-3 border-t border-gray-100 flex justify-between text-xs text-gray-500">
                                <span>Total: {Object.values(dashboardData.agingBuckets).reduce((s, b) => s + b.count, 0)} títulos</span>
                                <span className="font-semibold text-gray-700">{formatCurrencyBRL(Object.values(dashboardData.agingBuckets).reduce((s, b) => s + b.balance, 0))}</span>
                            </div>
                        </div>

                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                            <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                                <div className="w-2 h-6 rounded-full bg-blue-500"></div>
                                Evolução Diária — Saldo Acumulado
                            </h3>
                            {dashboardData.dailyEvolution.length === 0 ? (
                                <p className="text-sm text-gray-400 text-center py-8">Sem dados para o período selecionado.</p>
                            ) : (
                                <div className="relative">
                                    <div className="flex items-end gap-1 h-48">
                                        {dashboardData.dailyEvolution.map((entry, idx) => {
                                            const heightPct = Math.max((entry.balance / maxEvolutionBalance) * 100, 3);
                                            return (
                                                <div key={idx} className="flex-1 flex flex-col items-center justify-end group relative">
                                                    <div className="absolute bottom-full mb-1 hidden group-hover:block bg-gray-800 text-white text-xs rounded px-2 py-1 whitespace-nowrap z-10">
                                                        {new Date(entry.date + 'T00:00:00').toLocaleDateString('pt-BR')}<br/>
                                                        {formatCurrencyBRL(entry.balance)} ({entry.count} tít.)
                                                    </div>
                                                    <div className="w-full bg-blue-400 hover:bg-blue-500 rounded-t transition-all cursor-pointer" style={{ height: `${heightPct}%` }}></div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                    <div className="flex justify-between mt-2 text-xs text-gray-400">
                                        {dashboardData.dailyEvolution.length > 0 && (
                                            <>
                                                <span>{new Date(dashboardData.dailyEvolution[0].date + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}</span>
                                                {dashboardData.dailyEvolution.length > 1 && (
                                                    <span>{new Date(dashboardData.dailyEvolution[dashboardData.dailyEvolution.length - 1].date + 'T00:00:00').toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' })}</span>
                                                )}
                                            </>
                                        )}
                                    </div>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {showClientPanel && selectedClient && createPortal(
                <div className="fixed inset-0 z-[10001]">
                    <div className="bg-white w-full h-full overflow-hidden flex flex-col animate-fade-in">
                        <div className="bg-moss-800 text-white px-6 py-4 flex items-center justify-between flex-shrink-0">
                            <div className="flex items-center gap-3">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                                <div>
                                    <h3 className="font-bold text-lg">{selectedClient.name || 'Cliente'}</h3>
                                    <p className="text-moss-200 text-sm">Dados Completos — Somente Leitura</p>
                                </div>
                            </div>
                            <button onClick={() => setShowClientPanel(false)} className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20">
                                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                                Voltar
                            </button>
                        </div>

                        {selectedClient.blocked && <div className="px-6 pt-4 flex-shrink-0"><BlockedClientBanner client={selectedClient} /></div>}
                        <div className="flex border-b border-gray-200 bg-gray-50 flex-shrink-0 flex-wrap">
                            {(['DADOS', 'TITULOS', 'ADMISSOES'] as const).map(tab => (
                                <button key={tab} onClick={() => setClientPanelTab(tab)} className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors ${clientPanelTab === tab ? 'bg-white text-moss-700 border-b-2 border-moss-600' : 'text-gray-500 hover:text-gray-700'}`}>
                                    {tab === 'DADOS' ? 'Cadastro' : tab === 'TITULOS' ? `Títulos (${allClientTitles.length})` : `Admissões (${clientApprovedAdmissions.length})`}
                                </button>
                            ))}
                        </div>

                        <div className="flex-1 overflow-auto p-6">
                            {clientPanelTab === 'DADOS' && (
                                <div className="space-y-4">
                                    <div className="bg-gray-50 rounded-xl p-5 border border-gray-200">
                                        <h4 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-2">
                                            <div className="w-2 h-5 rounded-full bg-moss-500"></div>
                                            Dados Cadastrais
                                        </h4>
                                        <div className="grid grid-cols-2 gap-4 text-sm">
                                            <div><span className="text-gray-500">Nome/Razão:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.name || '—'}</span></div>
                                            <div><span className="text-gray-500">Tipo:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.type === 'FISICA' ? 'Pessoa Física' : 'Pessoa Jurídica'}</span></div>
                                            <div><span className="text-gray-500">CPF/CNPJ:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.document || '—'}</span></div>
                                            <div><span className="text-gray-500">RG:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.rg || '—'}</span></div>
                                            <div><span className="text-gray-500">Telefone:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.phone || '—'}</span></div>
                                            <div><span className="text-gray-500">Telefone 2:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.phone2 || '—'}</span></div>
                                            <div><span className="text-gray-500">E-mail:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.email || '—'}</span></div>
                                            <div><span className="text-gray-500">Profissão:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.profession || '—'}</span></div>
                                            <div><span className="text-gray-500">Estado Civil:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.maritalStatus || '—'}</span></div>
                                            <div><span className="text-gray-500">Nascimento:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.birthDate ? new Date(selectedClient.birthDate + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</span></div>
                                            <div className="col-span-2"><span className="text-gray-500">Endereço:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.address || '—'}, {selectedClient.number || ''} {selectedClient.complement || ''} — {selectedClient.district || ''}, {selectedClient.city || ''}/{selectedClient.state || ''} — CEP: {selectedClient.cep || '—'}</span></div>
                                            {selectedClient.notes && (
                                                <div className="col-span-2"><span className="text-gray-500">Observações:</span> <span className="font-medium text-gray-800 ml-1">{selectedClient.notes}</span></div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            )}

                            {clientPanelTab === 'TITULOS' && (
                                <div className="space-y-2">
                                    <div className="flex items-center gap-3 mb-3 flex-wrap">
                                        <div className="bg-gray-50 rounded-lg px-4 py-2 border border-gray-200 flex flex-col items-center min-w-[80px]">
                                            <span className="text-[10px] text-gray-500 uppercase font-semibold tracking-wide">Total</span>
                                            <span className="text-lg font-bold text-gray-800 leading-tight">{allClientTitles.length}</span>
                                        </div>
                                        <div className="bg-blue-50 rounded-lg px-4 py-2 border border-blue-100 flex flex-col items-center min-w-[80px]">
                                            <span className="text-[10px] text-blue-500 uppercase font-semibold tracking-wide">Em Aberto</span>
                                            <span className="text-lg font-bold text-blue-800 leading-tight">{allClientTitles.filter(t => !['PAGO', 'CANCELADO', 'AGRUPADO'].includes(t.status)).length}</span>
                                        </div>
                                        <div className="bg-green-50 rounded-lg px-4 py-2 border border-green-100 flex flex-col items-center min-w-[80px]">
                                            <span className="text-[10px] text-green-500 uppercase font-semibold tracking-wide">Liquidados</span>
                                            <span className="text-lg font-bold text-green-800 leading-tight">{allClientTitles.filter(t => t.status === 'PAGO').length}</span>
                                        </div>
                                        <div className="bg-purple-50 rounded-lg px-4 py-2 border border-purple-100 flex flex-col">
                                            <span className="text-[10px] text-purple-500 uppercase font-semibold tracking-wide">Saldo Devedor</span>
                                            <span className="text-sm font-bold text-purple-800 leading-tight">{formatCurrencyBRL(allClientTitles.filter(t => !['PAGO', 'CANCELADO', 'AGRUPADO'].includes(t.status)).reduce((s, t) => s + (Number(t.currentBalance) || 0), 0))}</span>
                                        </div>
                                        {clientFichasLoading && <span className="text-xs text-gray-400 italic">carregando fichas...</span>}
                                    </div>
                                    {allClientTitles.length === 0 && (
                                        <div className="text-center py-8 text-gray-400">Nenhum título encontrado.</div>
                                    )}
                                    {/* Grouped by ficha — uses parcelas returned by the API (source of truth) */}
                                    {clientFichas.length > 0 && clientFichas.map(ficha => {
                                        if (ficha.parcelas.length === 0) return null;
                                        return (
                                            <div key={ficha.id} className={`rounded-xl border overflow-hidden ${ficha.hasAddendum ? 'border-red-300' : 'border-gray-200'}`}>
                                                <div className={`px-4 py-2.5 flex items-center gap-2 flex-wrap ${ficha.hasAddendum ? 'bg-red-50' : 'bg-purple-50'}`}>
                                                    <div className="w-1.5 h-5 rounded-full bg-purple-400 flex-shrink-0"></div>
                                                    <span className="font-bold text-sm text-purple-900">Ficha: {ficha.contractNumber || 'Sem contrato'}</span>
                                                    <span className="text-xs text-gray-500">({ficha.parcelas.length} parcela{ficha.parcelas.length !== 1 ? 's' : ''})</span>
                                                    {ficha.hasAddendum && (
                                                        <span className="inline-flex items-center gap-1 bg-red-600 text-white text-xs font-bold px-2.5 py-0.5 rounded-full ml-1">
                                                            <svg className="w-3 h-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                                            Possui Aditivo Contratual{ficha.latestAddendumDate ? ` — ${new Date(ficha.latestAddendumDate + 'T00:00:00').toLocaleDateString('pt-BR')}` : ''}
                                                        </span>
                                                    )}
                                                </div>
                                                <table className="min-w-full text-sm bg-white data-grid-typography">
                                                    <thead className="bg-gray-50 border-b border-gray-100">
                                                        <tr>
                                                            <th className="px-4 py-2 text-left font-semibold text-gray-500 text-xs">Documento</th>
                                                            <th className="px-4 py-2 text-left font-semibold text-gray-500 text-xs">Descrição</th>
                                                            <th className="px-4 py-2 text-left font-semibold text-gray-500 text-xs">Vencimento</th>
                                                            <th className="px-4 py-2 text-right font-semibold text-gray-500 text-xs">Valor</th>
                                                            <th className="px-4 py-2 text-right font-semibold text-gray-500 text-xs">Saldo</th>
                                                            <th className="px-4 py-2 text-center font-semibold text-gray-500 text-xs">Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="divide-y divide-gray-100">
                                                        {ficha.parcelas.map(p => (
                                                            <tr key={p.id} className={`hover:bg-gray-50 ${p.status === 'PAGO' ? 'bg-green-50/30' : agingDays(p.dueDate) > 0 && !['PAGO', 'CANCELADO'].includes(p.status) ? 'bg-red-50/30' : ''}`}>
                                                                <td className="px-4 py-2 text-gray-700 font-medium text-xs">{p.documentNumber}</td>
                                                                <td className="px-4 py-2 text-gray-500 max-w-[140px] truncate text-xs">{p.description}</td>
                                                                <td className="px-4 py-2 text-gray-600 text-xs">{new Date(p.dueDate + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                                                                <td className="px-4 py-2 text-right text-blue-700 font-medium text-xs">{formatCurrencyBRL(p.originalValue)}</td>
                                                                <td className="px-4 py-2 text-right font-semibold text-blue-800 text-xs">{formatCurrencyBRL(p.currentBalance)}</td>
                                                                <td className="px-4 py-2 text-center">
                                                                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-semibold ${p.status === 'PAGO' ? 'bg-green-100 text-green-800' : p.status === 'ABERTO' ? 'bg-blue-100 text-blue-800' : p.status === 'PARCIAL' ? 'bg-yellow-100 text-yellow-800' : p.status === 'PROTESTADO' ? 'bg-red-100 text-red-800' : p.status === 'CANCELADO' ? 'bg-gray-100 text-gray-600' : 'bg-gray-100 text-gray-700'}`}>
                                                                        {statusLabel(p.status)}
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                        );
                                    })}
                                    {/* Ungrouped titles (no admissionId or no matching ficha) */}
                                    {(() => {
                                        const fichaIds = new Set(clientFichas.map(f => f.id));
                                        const ungrouped = allClientTitles.filter(t => !t.admissionId || !fichaIds.has(t.admissionId));
                                        if (ungrouped.length === 0) return null;
                                        return (
                                            <div className="rounded-xl border border-gray-200 overflow-hidden">
                                                <div className="px-4 py-2.5 flex items-center gap-2 bg-gray-50">
                                                    <div className="w-1.5 h-5 rounded-full bg-gray-400 flex-shrink-0"></div>
                                                    <span className="font-bold text-sm text-gray-700">Sem Ficha de Admissão</span>
                                                    <span className="text-xs text-gray-500">({ungrouped.length} parcela{ungrouped.length !== 1 ? 's' : ''})</span>
                                                </div>
                                                <table className="min-w-full text-sm bg-white data-grid-typography">
                                                    <thead className="bg-gray-50 border-b border-gray-100">
                                                        <tr>
                                                            <th className="px-4 py-2 text-left font-semibold text-gray-500 text-xs">Documento</th>
                                                            <th className="px-4 py-2 text-left font-semibold text-gray-500 text-xs">Descrição</th>
                                                            <th className="px-4 py-2 text-left font-semibold text-gray-500 text-xs">Vencimento</th>
                                                            <th className="px-4 py-2 text-right font-semibold text-gray-500 text-xs">Valor</th>
                                                            <th className="px-4 py-2 text-right font-semibold text-gray-500 text-xs">Saldo</th>
                                                            <th className="px-4 py-2 text-center font-semibold text-gray-500 text-xs">Status</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody className="divide-y divide-gray-100">
                                                        {ungrouped.map(t => (
                                                            <tr key={t.id} className={`hover:bg-gray-50 ${t.status === 'PAGO' ? 'bg-green-50/30' : agingDays(t.dueDate) > 0 && !['PAGO', 'CANCELADO'].includes(t.status) ? 'bg-red-50/30' : ''}`}>
                                                                <td className="px-4 py-2 text-gray-700 font-medium text-xs">{t.documentNumber}</td>
                                                                <td className="px-4 py-2 text-gray-500 max-w-[140px] truncate text-xs">{t.description}</td>
                                                                <td className="px-4 py-2 text-gray-600 text-xs">{new Date(t.dueDate + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                                                                <td className="px-4 py-2 text-right text-blue-700 font-medium text-xs">{formatCurrencyBRL(t.originalValue)}</td>
                                                                <td className="px-4 py-2 text-right font-semibold text-blue-800 text-xs">{formatCurrencyBRL(t.currentBalance)}</td>
                                                                <td className="px-4 py-2 text-center">
                                                                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-semibold ${t.status === 'PAGO' ? 'bg-green-100 text-green-800' : t.status === 'ABERTO' ? 'bg-blue-100 text-blue-800' : t.status === 'PARCIAL' ? 'bg-yellow-100 text-yellow-800' : t.status === 'PROTESTADO' ? 'bg-red-100 text-red-800' : t.status === 'CANCELADO' ? 'bg-gray-100 text-gray-600' : 'bg-gray-100 text-gray-700'}`}>
                                                                        {statusLabel(t.status)}
                                                                    </span>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                        );
                                    })()}
                                </div>
                            )}

                            {clientPanelTab === 'ADMISSOES' && (
                                <div className="space-y-4">
                                    {clientApprovedAdmissions.length === 0 && (
                                        <div className="text-center py-8 text-gray-400">
                                            <svg className="w-12 h-12 mx-auto mb-3 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                            <p>Nenhuma admissão aprovada encontrada para este cliente.</p>
                                        </div>
                                    )}
                                    {clientApprovedAdmissions.map(adm => (
                                        <div key={adm.id} className="bg-gray-50 rounded-xl border border-gray-200 overflow-hidden">
                                            <div className="bg-purple-50 px-5 py-3 border-b border-purple-100 flex items-center justify-between">
                                                <div className="flex items-center gap-2">
                                                    <div className="w-2 h-5 rounded-full bg-purple-500"></div>
                                                    <span className="font-bold text-sm text-purple-900">Contrato: {adm.contractNumber || '—'}</span>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <button onClick={() => handleOpenAdmissionModal(adm)} className="text-xs text-moss-600 hover:text-moss-800 bg-white hover:bg-moss-50 border border-moss-200 px-2.5 py-1 rounded-full font-semibold flex items-center gap-1 transition-colors">
                                                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                                                        Ver Ficha
                                                    </button>
                                                    <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${adm.status === 'APROVADA' || adm.status === 'FINALIZADA' || adm.status === 'CONCLUIDO' ? 'bg-green-100 text-green-800' : 'bg-blue-100 text-blue-800'}`}>{adm.status}</span>
                                                </div>
                                            </div>
                                            <div className="p-5 grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                                                <div><span className="text-xs text-gray-500 uppercase tracking-wider block">Data Admissão</span><span className="font-medium text-gray-800">{adm.date ? new Date(adm.date + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</span></div>
                                                <div><span className="text-xs text-gray-500 uppercase tracking-wider block">Parcelas</span><span className="font-medium text-gray-800">{adm.paidInstallments || 0} / {adm.totalInstallments || 0}</span></div>
                                                <div><span className="text-xs text-gray-500 uppercase tracking-wider block">Em Atraso</span><span className="font-medium text-red-700">{adm.overdueInstallments || 0}</span></div>
                                                <div><span className="text-xs text-gray-500 uppercase tracking-wider block">Valor Financiado</span><span className="font-medium text-blue-800">{adm.financedAmount || '—'}</span></div>
                                                <div><span className="text-xs text-gray-500 uppercase tracking-wider block">Valor Parcela</span><span className="font-medium text-gray-800">{adm.installmentValue || '—'}</span></div>
                                                <div><span className="text-xs text-gray-500 uppercase tracking-wider block">Dia Vencimento</span><span className="font-medium text-gray-800">{adm.dueDay || '—'}</span></div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            , document.body)}
        </div>

        {viewingAdmission && (
            <AdmissionViewerModal
                admission={viewingAdmission}
                clientName={clients.find(c => c.id === viewingAdmission.clientId)?.name || viewingAdmission.clientName || viewingAdmission.clientId}
                onClose={() => setViewingAdmission(null)}
            />
        )}

        {/* ─── Modal de Contato ─── */}
        {contactModalTitle && (() => {
            const ct = contactModalTitle;
            const modalNotes = collectionNotes.filter(n => n.titleId === ct.id);
            const ctClient = clients.find(c => c.id === ct.clientId);
            const latestNextContact = modalNotes
                .filter(n => n.nextContactDate)
                .sort((a, b) => b.date.localeCompare(a.date))[0]?.nextContactDate;

            const origVal = Number(ct.originalValue) || 0;
            const intSim = parseFloat(modalNoteForm.interestSim) || 0;
            const penSim = parseFloat(modalNoteForm.penaltySim) || 0;
            const discSim = parseFloat(modalNoteForm.discountSim) || 0;
            const intBase = Number(ct.interestValue) || 0;
            const penBase = Number(ct.penaltyValue) || 0;
            const discBase = Number(ct.discountValue) || 0;
            const simulatedBalance = origVal + (modalNoteForm.interestSim ? intSim : intBase) + (modalNoteForm.penaltySim ? penSim : penBase) - (modalNoteForm.discountSim ? discSim : discBase);

            return (
                <div className="fixed inset-0 z-[10000] flex bg-black/50 backdrop-blur-sm">
                    <div className="bg-white w-full h-full flex flex-col overflow-hidden">

                        {/* Header */}
                        <div className="bg-gradient-to-r from-moss-800 to-moss-700 px-5 py-3 flex items-center justify-between shrink-0 gap-4">
                            <div className="flex items-center gap-3 min-w-0">
                                <svg className="w-5 h-5 text-white/80 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                                <div className="min-w-0">
                                    <h2 className="text-white font-bold text-base leading-tight truncate">{ct.clientName}</h2>
                                    <p className="text-moss-200 text-[11px] mt-0.5">Doc: {ct.documentNumber} · Venc: {new Date(ct.dueDate + 'T00:00:00').toLocaleDateString('pt-BR')} · Saldo: {formatCurrencyBRL(ct.currentBalance)}</p>
                                </div>
                            </div>

                            {/* Next contact badge in header */}
                            {latestNextContact && (
                                <div className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 ${latestNextContact < new Date().toISOString().split('T')[0] ? 'bg-red-500/30 text-red-100' : 'bg-white/15 text-white'}`}>
                                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                    Próx. Contato: {new Date(latestNextContact + 'T00:00:00').toLocaleDateString('pt-BR')}
                                </div>
                            )}

                            <div className="flex items-center gap-2 shrink-0">
                                <button
                                    onClick={() => { setContactModalTitle(null); setShowWhatsappOverlay(false); }}
                                    className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20"
                                    title="Voltar à listagem"
                                >
                                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                                    Voltar
                                </button>
                                {GotalkConversationsTab && (
                                <button
                                    onClick={() => setShowWhatsappOverlay(true)}
                                    className="flex items-center gap-1.5 bg-green-600/80 hover:bg-green-600 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-green-400/40"
                                    title="Ver conversas WhatsApp deste cliente"
                                >
                                    <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                                    WhatsApp
                                </button>
                                )}
                                {/* Button: Open full client modal */}
                                <button
                                    onClick={() => { handleOpenClientPanel(ct.clientId); }}
                                    className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20"
                                    title="Abrir ficha completa do cliente"
                                >
                                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0M19 11a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
                                    Ficha do Cliente
                                </button>
                            </div>
                        </div>

                        {/* Body: three columns */}
                        <div className="flex flex-1 overflow-hidden min-h-0">

                            {/* Col 1 — Client data + Debt simulation */}
                            <div className="w-64 shrink-0 flex flex-col border-r border-gray-200 bg-slate-50 overflow-y-auto">
                                {/* Client data */}
                                <div className="px-4 pt-4 pb-2 shrink-0">
                                    <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                                        <svg className="w-3.5 h-3.5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0M12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
                                        Dados Cadastrais
                                    </h3>
                                    <div className="space-y-1.5 text-xs">
                                        {ctClient ? (
                                            <>
                                                <div className="bg-white rounded-lg border border-slate-200 p-2.5 space-y-1.5">
                                                    <div>
                                                        <div className="text-[9px] text-slate-400 uppercase font-semibold">Nome</div>
                                                        <div className="font-semibold text-slate-800 leading-tight">{ctClient.name}</div>
                                                    </div>
                                                    {ctClient.cpfCnpj && (
                                                        <div>
                                                            <div className="text-[9px] text-slate-400 uppercase font-semibold">CPF/CNPJ</div>
                                                            <div className="text-slate-700 font-mono">{ctClient.cpfCnpj}</div>
                                                        </div>
                                                    )}
                                                    {ctClient.phone && (
                                                        <div>
                                                            <div className="text-[9px] text-slate-400 uppercase font-semibold">Telefone</div>
                                                            <div className="text-slate-700">{ctClient.phone}</div>
                                                        </div>
                                                    )}
                                                    {(ctClient as any).cellPhone && (
                                                        <div>
                                                            <div className="text-[9px] text-slate-400 uppercase font-semibold">Celular</div>
                                                            <div className="text-slate-700">{(ctClient as any).cellPhone}</div>
                                                        </div>
                                                    )}
                                                    {ctClient.email && (
                                                        <div>
                                                            <div className="text-[9px] text-slate-400 uppercase font-semibold">E-mail</div>
                                                            <div className="text-slate-700 break-all">{ctClient.email}</div>
                                                        </div>
                                                    )}
                                                    {ctClient.address && (
                                                        <div>
                                                            <div className="text-[9px] text-slate-400 uppercase font-semibold">Endereço</div>
                                                            <div className="text-slate-700 leading-snug">{ctClient.address}{ctClient.city ? `, ${ctClient.city}` : ''}{(ctClient as any).state ? `/${(ctClient as any).state}` : ''}</div>
                                                        </div>
                                                    )}
                                                </div>
                                            </>
                                        ) : (
                                            <div className="text-slate-400 italic text-center py-4">Dados do cliente não encontrados.</div>
                                        )}
                                    </div>
                                </div>

                                {/* Debt simulation */}
                                <div className="px-4 py-3 shrink-0 border-t border-slate-200">
                                    <h3 className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                                        <svg className="w-3.5 h-3.5 text-slate-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
                                        Valores da Dívida
                                    </h3>
                                    <div className="bg-white rounded-lg border border-slate-200 p-2.5 space-y-1.5 text-xs mb-2">
                                        <div className="flex justify-between">
                                            <span className="text-slate-500">Valor Original</span>
                                            <span className="font-semibold text-slate-800">{formatCurrencyBRL(origVal)}</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-500">Juros (base)</span>
                                            <span className="text-orange-600">{formatCurrencyBRL(intBase)}</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-500">Multa (base)</span>
                                            <span className="text-red-600">{formatCurrencyBRL(penBase)}</span>
                                        </div>
                                        <div className="flex justify-between">
                                            <span className="text-slate-500">Desconto (base)</span>
                                            <span className="text-moss-600">-{formatCurrencyBRL(discBase)}</span>
                                        </div>
                                        <div className="flex justify-between border-t border-slate-100 pt-1.5 mt-1">
                                            <span className="font-semibold text-slate-600">Saldo Atual</span>
                                            <span className="font-bold text-blue-800">{formatCurrencyBRL(Number(ct.currentBalance))}</span>
                                        </div>
                                    </div>

                                    <p className="text-[9px] text-slate-400 uppercase font-semibold mb-1.5">Simulação para este contato</p>
                                    <div className="space-y-1.5">
                                        <div>
                                            <label className="text-[9px] text-slate-500 uppercase font-semibold block mb-0.5">Juros (R$)</label>
                                            <input type="number" min="0" step="0.01" value={modalNoteForm.interestSim} onChange={e => setModalNoteForm(f => ({ ...f, interestSim: e.target.value }))}
                                                placeholder={intBase.toFixed(2)} className="w-full border border-slate-300 rounded px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-moss-500" />
                                        </div>
                                        <div>
                                            <label className="text-[9px] text-slate-500 uppercase font-semibold block mb-0.5">Multa (R$)</label>
                                            <input type="number" min="0" step="0.01" value={modalNoteForm.penaltySim} onChange={e => setModalNoteForm(f => ({ ...f, penaltySim: e.target.value }))}
                                                placeholder={penBase.toFixed(2)} className="w-full border border-slate-300 rounded px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-moss-500" />
                                        </div>
                                        <div>
                                            <label className="text-[9px] text-slate-500 uppercase font-semibold block mb-0.5">Desconto (R$)</label>
                                            <input type="number" min="0" step="0.01" value={modalNoteForm.discountSim} onChange={e => setModalNoteForm(f => ({ ...f, discountSim: e.target.value }))}
                                                placeholder="0.00" className="w-full border border-slate-300 rounded px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-moss-500" />
                                        </div>
                                        <div className="bg-moss-50 border border-moss-200 rounded-lg p-2 mt-1">
                                            <div className="text-[9px] text-moss-600 uppercase font-bold mb-0.5">Saldo Simulado</div>
                                            <div className="text-base font-bold text-moss-800">{formatCurrencyBRL(simulatedBalance)}</div>
                                            <div className="text-[9px] text-slate-400 mt-0.5">Será registrado na nota do contato</div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            {/* Col 2 — Tabs: Registrar Contato | WhatsApp (Task #302) */}
                            <div className="flex-1 flex flex-col overflow-hidden border-r border-gray-200">
                                {(() => {
                                    const ctClient = ct ? clients.find(c => c.id === ct.clientId) : null;
                                    const phoneKey = ctClient ? clientPhoneKey[ctClient.id] : '';
                                    const unread = phoneKey ? (waUnreadByPhone[phoneKey] || 0) : 0;
                                    return (
                                        <div className="flex items-center border-b border-gray-200 bg-gray-50 shrink-0">
                                            <button
                                                onClick={() => setDetailTab('FORM')}
                                                className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors border-b-2 ${
                                                    detailTab === 'FORM'
                                                        ? 'border-moss-600 text-moss-800 bg-white'
                                                        : 'border-transparent text-gray-500 hover:text-moss-700 hover:bg-white/60'
                                                }`}
                                            >
                                                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                                                Registrar Contato
                                            </button>
                                            {GotalkChatPanel && (
                                                <button
                                                    onClick={() => setDetailTab('WHATSAPP')}
                                                    className={`flex items-center gap-2 px-4 py-2.5 text-xs font-bold uppercase tracking-wider transition-colors border-b-2 relative ${
                                                        detailTab === 'WHATSAPP'
                                                            ? 'border-green-600 text-green-800 bg-white'
                                                            : 'border-transparent text-gray-500 hover:text-green-700 hover:bg-white/60'
                                                    }`}
                                                >
                                                    <span>💬</span>
                                                    WhatsApp
                                                    {unread > 0 && (
                                                        <span className="ml-1 inline-flex items-center justify-center min-w-[20px] h-5 px-1.5 rounded-full bg-red-600 text-white text-[10px] font-bold ring-2 ring-red-100">
                                                            {unread > 99 ? '99+' : unread}
                                                        </span>
                                                    )}
                                                </button>
                                            )}
                                        </div>
                                    );
                                })()}

                                {detailTab === 'WHATSAPP' && (() => {
                                    const ctClient = ct ? clients.find(c => c.id === ct.clientId) : null;
                                    if (!ctClient) {
                                        return (
                                            <div className="flex-1 flex items-center justify-center text-sm text-gray-400 p-6">
                                                Cliente não encontrado.
                                            </div>
                                        );
                                    }
                                    const phoneStr = (ctClient.phone || (ctClient as any).phone1 || '') as string;
                                    return (
                                        <UnifiedWhatsappTab
                                            phone={phoneStr || null}
                                            clientId={ctClient.id}
                                            clientName={ctClient.name}
                                            operatorName={currentUser?.name}
                                            socket={socket}
                                            FallbackChatPanel={GotalkChatPanel}
                                        />
                                    );
                                })()}

                                <div className={`flex-1 flex flex-col overflow-y-auto ${detailTab === 'FORM' ? '' : 'hidden'}`}>
                                <div className="px-5 pt-4 pb-2 shrink-0 border-b border-gray-100">
                                    <h3 className="text-[10px] font-bold text-moss-800 uppercase tracking-wider flex items-center gap-1.5">
                                        <svg className="w-3.5 h-3.5 text-moss-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                                        Registrar Novo Contato
                                    </h3>
                                </div>
                                <div className="px-5 py-4 space-y-3 flex-1">
                                    {/* Canal + Status */}
                                    <div className="grid grid-cols-2 gap-3">
                                        <div>
                                            <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Canal</label>
                                            <select value={modalNoteForm.contactChannel} onChange={e => setModalNoteForm(f => ({ ...f, contactChannel: e.target.value as any }))}
                                                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-moss-500 bg-white">
                                                <option value="TELEFONE">📞 Telefone</option>
                                                <option value="WHATSAPP">💬 WhatsApp</option>
                                                <option value="EMAIL">📧 E-mail</option>
                                                <option value="MENSAGEM">✉️ Mensagem</option>
                                            </select>
                                        </div>
                                        <div>
                                            <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Status da Negociação</label>
                                            <select value={modalNoteForm.negotiationStatus} onChange={e => {
                                                const val = e.target.value as CollectionNote['negotiationStatus'];
                                                setModalNoteForm(f => ({ ...f, negotiationStatus: val }));
                                                if (val === 'SOLICITA_CANCELAMENTO' && ct) {
                                                    setCancelRequestModal({ open: true, forTitle: ct, form: { ...emptyCancelReq, requestDate: new Date().toISOString().split('T')[0] } });
                                                }
                                            }}
                                                className={`w-full border rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-moss-500 bg-white ${modalNoteForm.negotiationStatus === 'SOLICITA_CANCELAMENTO' ? 'border-orange-400 text-orange-700 font-semibold' : 'border-gray-300'}`}>
                                                <option value="AGUARDANDO_CONTATO">Aguardando Contato</option>
                                                <option value="ENCAMINHOU_BOLETO">Encaminhou Boleto</option>
                                                <option value="FECHADA">Negociação Fechada</option>
                                                <option value="RECUSA_DIVIDA">Recusa a Dívida</option>
                                                <option value="OUTROS">Outros</option>
                                                <option value="SOLICITA_CANCELAMENTO">⚠️ Solicitação de Cancelamento</option>
                                            </select>
                                        </div>
                                    </div>

                                    {modalNoteForm.negotiationStatus === 'OUTROS' && (
                                        <input value={modalNoteForm.negotiationStatusOther} onChange={e => setModalNoteForm(f => ({ ...f, negotiationStatusOther: e.target.value }))}
                                            placeholder="Descreva o status..." className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-moss-500" />
                                    )}

                                    {modalNoteForm.negotiationStatus === 'SOLICITA_CANCELAMENTO' && (() => {
                                        const cr = (modalNoteForm as any).cancelRequest as { admissionId: string; admissionContract: string; requestDate: string; notes: string } | undefined;
                                        return (
                                            <div className="bg-orange-50 border border-orange-200 rounded-lg p-3 flex items-start gap-2">
                                                <svg className="w-4 h-4 text-orange-500 mt-0.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z"/></svg>
                                                <div className="flex-1 min-w-0">
                                                    {cr?.admissionId ? (
                                                        <>
                                                            <p className="text-xs font-semibold text-orange-800">Solicitação vinculada</p>
                                                            <p className="text-[11px] text-orange-700">Contrato: {cr.admissionContract} · Data: {cr.requestDate ? new Date(cr.requestDate + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</p>
                                                            {cr.notes && <p className="text-[11px] text-orange-600 mt-0.5 italic">{cr.notes}</p>}
                                                        </>
                                                    ) : (
                                                        <p className="text-xs text-orange-700">Nenhum contrato selecionado ainda.</p>
                                                    )}
                                                </div>
                                                <button onClick={() => setCancelRequestModal({ open: true, forTitle: ct, form: cr ? { ...cr } : { ...emptyCancelReq, requestDate: new Date().toISOString().split('T')[0] } })}
                                                    className="text-xs text-orange-700 hover:text-orange-900 bg-orange-100 hover:bg-orange-200 border border-orange-300 px-2 py-1 rounded font-semibold transition-colors shrink-0">
                                                    {cr?.admissionId ? 'Editar' : 'Selecionar Contrato'}
                                                </button>
                                            </div>
                                        );
                                    })()}

                                    <div>
                                        <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Nota <span className="text-red-400">*</span></label>
                                        <textarea value={modalNoteForm.note} onChange={e => setModalNoteForm(f => ({ ...f, note: e.target.value }))}
                                            placeholder="Descreva o contato realizado..." rows={5}
                                            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-moss-500 resize-none" />
                                    </div>

                                    <div>
                                        <label className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1 block">
                                            Próximo Contato <span className="text-gray-400 font-normal">(opcional)</span>
                                        </label>
                                        <input type="date" value={modalNoteForm.nextContactDate} onChange={e => setModalNoteForm(f => ({ ...f, nextContactDate: e.target.value }))}
                                            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-moss-500" />
                                        <p className="text-[10px] text-gray-400 mt-1">Se preenchido, cria agendamento e notifica o grupo.</p>
                                    </div>

                                    {/* Attachments */}
                                    <div>
                                        <div className="text-[10px] font-semibold text-gray-500 uppercase tracking-wider mb-1 flex items-center gap-1">
                                            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg>
                                            Anexos
                                        </div>
                                        <label className="flex items-center gap-2 border border-dashed border-gray-300 rounded-lg px-3 py-2 cursor-pointer hover:border-moss-400 hover:bg-moss-50 transition-colors text-sm text-gray-500">
                                            <svg className="w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4"/></svg>
                                            Adicionar arquivo(s)
                                            <input type="file" multiple className="hidden" onChange={e => {
                                                const files = Array.from(e.target.files || []);
                                                files.forEach(file => {
                                                    const reader = new FileReader();
                                                    reader.onload = ev => {
                                                        const att: NoteAttachment = { name: file.name, dataUrl: ev.target?.result as string, type: file.type };
                                                        setModalNoteForm(f => ({ ...f, attachments: [...f.attachments, att] }));
                                                    };
                                                    reader.readAsDataURL(file);
                                                });
                                                e.target.value = '';
                                            }} />
                                        </label>
                                        {modalNoteForm.attachments.length > 0 && (
                                            <div className="mt-2 space-y-1">
                                                {modalNoteForm.attachments.map((att, i) => (
                                                    <div key={i} className="flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg px-3 py-1.5 text-xs">
                                                        <svg className="w-3 h-3 text-gray-400 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                                                        <span className="flex-1 truncate text-gray-700">{att.name}</span>
                                                        <button onClick={() => setModalNoteForm(f => ({ ...f, attachments: f.attachments.filter((_, j) => j !== i) }))} className="text-red-400 hover:text-red-600 ml-1">
                                                            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
                                                        </button>
                                                    </div>
                                                ))}
                                            </div>
                                        )}
                                    </div>

                                    <div className="flex justify-end pt-1">
                                        <button onClick={handleSaveModalNote} disabled={isSavingModalNote || !modalNoteForm.note.trim()}
                                            className="bg-moss-700 hover:bg-moss-800 disabled:opacity-50 text-white font-semibold px-6 py-2 rounded-xl text-sm transition-colors flex items-center gap-2">
                                            {isSavingModalNote ? (
                                                <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" /></svg>
                                            ) : (
                                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                                            )}
                                            Salvar Contato
                                        </button>
                                    </div>
                                </div>
                                </div>
                            </div>

                            {/* WhatsApp Chat Panel — shown when WHATSAPP channel selected and GotalkChatPanel is provided */}
                            {modalNoteForm.contactChannel === 'WHATSAPP' && GotalkChatPanel && (() => {
                                const ctClient = ct ? clients.find(c => c.id === ct.clientId) : null;
                                if (!ctClient) return null;
                                return (
                                    <div className="border-t border-gray-200 flex flex-col" style={{ minHeight: 360 }}>
                                        <div className="flex items-center gap-2 px-5 py-2 bg-green-50 border-b border-green-100 shrink-0">
                                            <svg className="w-4 h-4 text-green-600" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                                            <span className="text-xs font-bold text-green-800 uppercase tracking-wider">Conversa WhatsApp — {ctClient.name}</span>
                                        </div>
                                        <div className="flex-1">
                                            <GotalkChatPanel clientId={ctClient.id} area="COBRANCA_OP" operatorName={currentUser?.name} />
                                        </div>
                                    </div>
                                );
                            })()}

                            {/* Col 3 — Histórico de Contatos */}
                            <div className="w-[420px] shrink-0 flex flex-col bg-gray-50 overflow-hidden">
                                <div className="px-4 pt-4 pb-2 shrink-0 border-b border-gray-200">
                                    <h3 className="text-[10px] font-bold text-moss-800 uppercase tracking-wider flex items-center gap-1.5">
                                        <svg className="w-3.5 h-3.5 text-moss-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                                        Histórico de Contatos
                                        {modalNotes.length > 0 && <span className="bg-moss-100 text-moss-700 text-[10px] font-bold px-2 py-0.5 rounded-full ml-1">{modalNotes.length}</span>}
                                        <span className="ml-auto text-[9px] text-gray-400 font-normal normal-case">Duplo clique para editar</span>
                                    </h3>
                                </div>
                                <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
                                    {modalNotes.length === 0 ? (
                                        <div className="text-center py-8 text-gray-400 text-xs bg-white rounded-xl border border-dashed border-gray-200">
                                            Nenhum contato registrado.
                                        </div>
                                    ) : (
                                        modalNotes.map(n => (
                                            <div
                                                key={n.id}
                                                className={`bg-white border rounded-xl p-3 shadow-sm transition-all ${editingNoteId === n.id ? 'border-blue-400 ring-2 ring-blue-100' : 'border-gray-200 hover:border-gray-300 cursor-pointer'}`}
                                                onDoubleClick={() => editingNoteId !== n.id && handleStartEditNote(n)}
                                                title={editingNoteId !== n.id ? 'Duplo clique para editar' : undefined}
                                            >
                                                <div className="flex items-center gap-1.5 flex-wrap mb-1.5">
                                                    <span className="text-sm">{contactChannelIcon(n.contactChannel)}</span>
                                                    <span className="text-xs font-semibold text-gray-800">{n.collaboratorName}</span>
                                                    <span className="text-[10px] text-gray-400 ml-auto">{fmtDate(n.date)} {n.time}</span>
                                                    {canExcluir && (
                                                        <button onClick={() => handleDeleteNote(n.id)} className="text-red-400 hover:text-red-600 text-[9px] font-bold px-1.5 py-0.5 rounded hover:bg-red-50 transition-colors">Excluir</button>
                                                    )}
                                                </div>
                                                <span className={`inline-block text-[10px] font-bold px-2 py-0.5 rounded-full mb-1.5 ${n.negotiationStatus === 'FECHADA' ? 'bg-moss-100 text-moss-700' : n.negotiationStatus === 'RECUSA_DIVIDA' ? 'bg-red-100 text-red-700' : 'bg-amber-100 text-amber-700'}`}>
                                                    {negotiationStatusLabel(n.negotiationStatus)}
                                                </span>
                                                {editingNoteId === n.id ? (
                                                    <div className="flex flex-col gap-2 mb-1">
                                                        <div>
                                                            <label className="text-[9px] font-semibold text-gray-500 uppercase tracking-wide block mb-0.5">Nota</label>
                                                            <textarea className="w-full rounded-lg border border-blue-300 px-2 py-1.5 text-xs focus:ring-2 focus:ring-blue-400 outline-none resize-none" rows={3} value={editNoteText} onChange={e => setEditNoteText(e.target.value)} autoFocus />
                                                        </div>
                                                        <div>
                                                            <label className="text-[9px] font-semibold text-gray-500 uppercase tracking-wide block mb-0.5">Status da Negociação</label>
                                                            <select value={editNoteStatus} onChange={e => setEditNoteStatus(e.target.value as CollectionNote['negotiationStatus'])} className="w-full border border-blue-300 rounded-lg px-2 py-1.5 text-xs focus:ring-2 focus:ring-blue-400 outline-none bg-white">
                                                                <option value="AGUARDANDO_CONTATO">Aguardando Contato</option>
                                                                <option value="ENCAMINHOU_BOLETO">Encaminhou Boleto</option>
                                                                <option value="FECHADA">Negociação Fechada</option>
                                                                <option value="RECUSA_DIVIDA">Recusa a Dívida</option>
                                                                <option value="OUTROS">Outros</option>
                                                                <option value="SOLICITA_CANCELAMENTO">Solicitação de Cancelamento</option>
                                                            </select>
                                                        </div>
                                                        <div>
                                                            <label className="text-[9px] font-semibold text-gray-500 uppercase tracking-wide block mb-0.5">Próximo Contato</label>
                                                            <input type="date" value={editNoteNextContact} onChange={e => setEditNoteNextContact(e.target.value)} className="w-full border border-blue-300 rounded-lg px-2 py-1.5 text-xs focus:ring-2 focus:ring-blue-400 outline-none" />
                                                        </div>
                                                        <div className="flex gap-1.5 justify-end">
                                                            <button onClick={() => { setEditingNoteId(null); setEditNoteText(''); setEditNoteStatus('AGUARDANDO_CONTATO'); setEditNoteNextContact(''); }} className="px-3 py-1 text-[10px] font-semibold rounded bg-gray-100 hover:bg-gray-200 text-gray-600 transition-colors">Cancelar</button>
                                                            <button onClick={handleSaveEditNote} className="px-3 py-1 text-[10px] font-semibold rounded bg-blue-600 hover:bg-blue-700 text-white transition-colors">Salvar</button>
                                                        </div>
                                                    </div>
                                                ) : (
                                                    <p className="text-xs text-gray-700 leading-relaxed">{n.note}</p>
                                                )}
                                                {n.debtSnapshot && (
                                                    <div className="mt-1.5 bg-slate-50 rounded-lg p-1.5 text-[10px] text-slate-600 border border-slate-100 space-y-0.5">
                                                        <div className="font-semibold text-slate-500 uppercase tracking-wide mb-0.5">Snapshot da dívida</div>
                                                        <div className="flex justify-between"><span>Original:</span><span>{formatCurrencyBRL(n.debtSnapshot.original)}</span></div>
                                                        {n.debtSnapshot.interest > 0 && <div className="flex justify-between"><span className="text-orange-500">+ Juros:</span><span>{formatCurrencyBRL(n.debtSnapshot.interest)}</span></div>}
                                                        {n.debtSnapshot.penalty > 0 && <div className="flex justify-between"><span className="text-red-500">+ Multa:</span><span>{formatCurrencyBRL(n.debtSnapshot.penalty)}</span></div>}
                                                        {n.debtSnapshot.discount > 0 && <div className="flex justify-between"><span className="text-moss-600">- Desconto:</span><span>{formatCurrencyBRL(n.debtSnapshot.discount)}</span></div>}
                                                        <div className="flex justify-between font-bold border-t border-slate-200 pt-0.5 mt-0.5 text-blue-700"><span>Saldo:</span><span>{formatCurrencyBRL(n.debtSnapshot.balance)}</span></div>
                                                    </div>
                                                )}
                                                {n.nextContactDate && (
                                                    <p className="text-[10px] text-moss-700 font-semibold mt-1.5 flex items-center gap-1">
                                                        <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                                        Próx: {fmtDate(n.nextContactDate)}
                                                    </p>
                                                )}
                                                {n.cancelRequest && (
                                                    <div className="mt-1.5 bg-orange-50 border border-orange-200 rounded-lg p-1.5 text-[10px] text-orange-700 space-y-0.5">
                                                        <div className="font-bold text-orange-800 uppercase tracking-wide mb-0.5 flex items-center gap-1">
                                                            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>
                                                            Solicitação de Cancelamento
                                                        </div>
                                                        <div className="flex justify-between"><span>Contrato:</span><span className="font-semibold">{n.cancelRequest.admissionContract || '—'}</span></div>
                                                        <div className="flex justify-between"><span>Data:</span><span>{n.cancelRequest.requestDate ? new Date(n.cancelRequest.requestDate + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</span></div>
                                                        {n.cancelRequest.notes && <div className="italic text-orange-600">{n.cancelRequest.notes}</div>}
                                                    </div>
                                                )}
                                                {n.attachments && n.attachments.length > 0 && (
                                                    <div className="mt-1.5 flex flex-wrap gap-1">
                                                        {n.attachments.map((att, i) => (
                                                            <a key={i} href={att.dataUrl} download={att.name} className="flex items-center gap-1 bg-blue-50 border border-blue-100 text-blue-700 rounded px-1.5 py-0.5 text-[10px] hover:bg-blue-100 transition-colors" title={att.name}>
                                                                <svg className="w-2.5 h-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg>
                                                                <span className="truncate max-w-[80px]">{att.name}</span>
                                                            </a>
                                                        ))}
                                                    </div>
                                                )}
                                            </div>
                                        ))
                                    )}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            );
        })()}

        {/* ─── WhatsApp overlay (dentro do modal de contato) ─── */}
        {GotalkConversationsTab && showWhatsappOverlay && contactModalTitle && createPortal(
            <div className="fixed inset-0 z-[10001] flex flex-col bg-white">
                <div className="bg-gradient-to-r from-green-700 to-green-600 px-5 py-3 flex items-center gap-3 shrink-0">
                    <svg className="w-5 h-5 text-white/90 shrink-0" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                    <div className="min-w-0 flex-1">
                        <h2 className="text-white font-bold text-base leading-tight truncate">Conversas WhatsApp — {contactModalTitle.clientName}</h2>
                        <p className="text-green-200 text-[11px] mt-0.5">Histórico de mensagens GoTalk</p>
                    </div>
                    <button
                        onClick={() => setShowWhatsappOverlay(false)}
                        className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20 shrink-0"
                    >
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                        Voltar
                    </button>
                </div>
                <div className="flex-1 overflow-y-auto p-6">
                    <GotalkConversationsTab clientId={contactModalTitle.clientId} />
                </div>
            </div>
        , document.body)}

        {/* ─── Sub-modal: Solicitação de Cancelamento ─── */}
        {cancelRequestModal.open && cancelRequestModal.forTitle && (() => {
            const crTitle = cancelRequestModal.forTitle;
            const clientAdms = admissions.filter(a => a.clientId === crTitle.clientId);
            return (
                <div className="fixed inset-0 z-[10002] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg flex flex-col overflow-hidden">
                        <div className="bg-orange-600 px-5 py-4 flex items-center justify-between shrink-0">
                            <div className="flex items-center gap-2">
                                <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>
                                <div>
                                    <h3 className="text-white font-bold text-base">Solicitação de Cancelamento</h3>
                                    <p className="text-orange-200 text-xs">{crTitle.clientName}</p>
                                </div>
                            </div>
                            <button onClick={() => {
                                setCancelRequestModal(s => ({ ...s, open: false }));
                                setModalNoteForm(f => ({ ...f, negotiationStatus: 'AGUARDANDO_CONTATO' }));
                            }} className="text-white/70 hover:text-white p-1 rounded">
                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
                            </button>
                        </div>

                        <div className="p-5 space-y-4 overflow-y-auto max-h-[70vh]">
                            <div>
                                <label className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-2 block">Ficha de Admissão / Contrato a Cancelar</label>
                                {clientAdms.length === 0 ? (
                                    <div className="text-sm text-gray-400 italic border border-dashed border-gray-200 rounded-lg px-4 py-6 text-center">
                                        Nenhuma ficha de admissão encontrada para este cliente.
                                    </div>
                                ) : (
                                    <div className="space-y-2 max-h-48 overflow-y-auto">
                                        {clientAdms.map(adm => (
                                            <button key={adm.id} onClick={() => setCancelRequestModal(s => ({ ...s, form: { ...s.form, admissionId: adm.id, admissionContract: adm.contractNumber || adm.id } }))}
                                                className={`w-full text-left border rounded-xl px-4 py-3 transition-all ${cancelRequestModal.form.admissionId === adm.id ? 'border-orange-400 bg-orange-50 ring-2 ring-orange-300' : 'border-gray-200 bg-white hover:border-orange-300 hover:bg-orange-50/50'}`}>
                                                <div className="flex items-center justify-between">
                                                    <div>
                                                        <p className="text-sm font-semibold text-gray-800">Contrato: {adm.contractNumber || '—'}</p>
                                                        <p className="text-xs text-gray-500">{adm.date ? new Date(adm.date + 'T00:00:00').toLocaleDateString('pt-BR') : '—'} · {adm.paidInstallments || 0}/{adm.totalInstallments || 0} parc. · {adm.financedAmount ? `R$ ${adm.financedAmount}` : '—'}</p>
                                                    </div>
                                                    <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${adm.status === 'APROVADA' || adm.status === 'FINALIZADA' ? 'bg-green-100 text-green-700' : adm.status === 'REPROVADA' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'}`}>{adm.status}</span>
                                                </div>
                                            </button>
                                        ))}
                                    </div>
                                )}
                            </div>

                            <div>
                                <label className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-1 block">Data da Solicitação</label>
                                <input type="date" value={cancelRequestModal.form.requestDate}
                                    onChange={e => setCancelRequestModal(s => ({ ...s, form: { ...s.form, requestDate: e.target.value } }))}
                                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400" />
                            </div>

                            <div>
                                <label className="text-xs font-bold text-gray-600 uppercase tracking-wider mb-1 block">Anotações Gerais</label>
                                <textarea value={cancelRequestModal.form.notes}
                                    onChange={e => setCancelRequestModal(s => ({ ...s, form: { ...s.form, notes: e.target.value } }))}
                                    placeholder="Motivo, observações ou instruções para o cancelamento..."
                                    rows={4} className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-orange-400 resize-none" />
                            </div>
                        </div>

                        <div className="px-5 pb-5 flex justify-end gap-3">
                            <button onClick={() => {
                                setCancelRequestModal(s => ({ ...s, open: false }));
                                setModalNoteForm(f => ({ ...f, negotiationStatus: 'AGUARDANDO_CONTATO' }));
                            }} className="px-4 py-2 text-sm rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50 font-semibold">
                                Cancelar
                            </button>
                            <button
                                disabled={!cancelRequestModal.form.admissionId}
                                onClick={() => {
                                    const cr = { ...cancelRequestModal.form };
                                    setModalNoteForm(f => {
                                        const updated: any = { ...f, negotiationStatus: 'SOLICITA_CANCELAMENTO', cancelRequest: cr };
                                        if (!updated.note) updated.note = `Solicitação de cancelamento — Contrato: ${cr.admissionContract}`;
                                        return updated as NoteFormState;
                                    });
                                    setCancelRequestModal(s => ({ ...s, open: false }));
                                }}
                                className="px-5 py-2 text-sm rounded-lg bg-orange-600 hover:bg-orange-700 disabled:opacity-50 text-white font-bold flex items-center gap-2 transition-colors">
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7"/></svg>
                                Confirmar Solicitação
                            </button>
                        </div>
                    </div>
                </div>
            );
        })()}

        <ConfirmDeleteModal
            isOpen={!!deleteModal}
            title={deleteModal?.title ?? ''}
            message={deleteModal?.message ?? ''}
            isLoading={deleteLoading}
            onConfirm={handleDeleteConfirmed}
            onCancel={() => { if (!deleteLoading) setDeleteModal(null); }}
        />
        </>
    );
};

export default CollectionOperationalPanel;

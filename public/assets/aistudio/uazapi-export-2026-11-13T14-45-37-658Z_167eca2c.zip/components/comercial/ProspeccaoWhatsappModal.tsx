import React, { useState, useEffect, useRef } from 'react';

// Structurally identical to TimelineMsg in ProspeccaoPanel — using same shape
// avoids `as any` casts when passing messages back to the panel.
export interface TimelineMsg {
  id?: string;
  body: string | null;
  direction: 'IN' | 'OUT';
  message_type: string;
  sent_at?: string | null;
  attachment_url?: string | null;
  attachment_name?: string | null;
  attachment_mime_type?: string | null;
  operator_name?: string | null;
  source?: string;
  ack_status?: number | null;
}

interface InstanceOption {
  instanceId: string;
  label: string | null;
  unitId: string;
  unitName: string;
}

// Quick-text templates for prospect outreach — configurable list.
const QUICK_TEXTS: { label: string; text: string }[] = [
  { label: 'Apresentação', text: 'Olá! Aqui é da Invicta Assessoria. Entramos em contato para apresentar nossos serviços de negociação de dívidas e planejamento financeiro. Posso falar um minutinho?' },
  { label: 'Retorno de contato', text: 'Olá! Estamos retornando o contato. Você teria disponibilidade para conversarmos sobre sua situação financeira?' },
  { label: 'Proposta enviada', text: 'Olá! Identificamos uma oportunidade de negociação muito interessante para você. Posso te apresentar os detalhes?' },
  { label: 'Confirmação de interesse', text: 'Bom dia! Gostaríamos de confirmar seu interesse em nossos serviços. Alguma dúvida que possamos esclarecer?' },
  { label: 'Agendamento', text: 'Olá! Gostaria de agendar uma conversa para apresentar as melhores opções de negociação disponíveis para o seu perfil. Qual horário é melhor para você?' },
];

interface Props {
  initialPhone?: string;
  onClose: () => void;
  // phone is passed so the panel can decide whether to show the optimistic
  // message in the current contact's timeline or suppress it (new number).
  onOptimisticInsert: (msg: TimelineMsg, phone: string) => void;
  onSent: (msg: TimelineMsg, phone: string, unitId: string, optimisticId: string) => void;
  onSendFailed: (optimisticId: string) => void;
}

const ProspeccaoWhatsappModal: React.FC<Props> = ({
  initialPhone,
  onClose,
  onOptimisticInsert,
  onSent,
  onSendFailed,
}) => {
  const [phone, setPhone] = useState((initialPhone || '').replace(/\D/g, ''));
  const [selectedKey, setSelectedKey] = useState(''); // "unitId::instanceId"
  const [text, setText] = useState('');
  const [instances, setInstances] = useState<InstanceOption[]>([]);
  const [loadingInstances, setLoadingInstances] = useState(true);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showQuickTexts, setShowQuickTexts] = useState(false);
  const quickTextRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setLoadingInstances(true);
    fetch('/api/units/uazapi-instances-all')
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        const flat: InstanceOption[] = [];
        for (const unit of (d?.units || [])) {
          for (const inst of (unit.instances || [])) {
            flat.push({
              instanceId: inst.instanceId,
              label: inst.label || null,
              unitId: unit.unit_id,
              unitName: unit.unit_name || '',
            });
          }
        }
        setInstances(flat);
        if (flat.length === 1) setSelectedKey(`${flat[0].unitId}::${flat[0].instanceId}`);
      })
      .catch(() => {})
      .finally(() => setLoadingInstances(false));
  }, []);

  // Close quick-text dropdown on outside click
  useEffect(() => {
    if (!showQuickTexts) return;
    const handler = (e: MouseEvent) => {
      if (quickTextRef.current && !quickTextRef.current.contains(e.target as Node)) {
        setShowQuickTexts(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [showQuickTexts]);

  const selectedInstance = instances.find(i => `${i.unitId}::${i.instanceId}` === selectedKey) || null;

  const handleSend = async () => {
    const digits = phone.replace(/\D/g, '');
    if (!selectedInstance) { setError('Selecione o canal de envio.'); return; }
    if (digits.length < 8) { setError('Informe um número de telefone válido (mín. 8 dígitos).'); return; }
    if (!text.trim()) { setError('Digite uma mensagem.'); return; }

    setSending(true);
    setError(null);

    const optimisticId = `opt-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const optimisticMsg: TimelineMsg = {
      id: optimisticId,
      body: text.trim(),
      direction: 'OUT',
      message_type: 'TEXT',
      source: 'uazapi',
      sent_at: new Date().toISOString(),
      ack_status: null,
    };
    onOptimisticInsert(optimisticMsg, digits);

    try {
      const res = await fetch('/api/uazapi/send-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          unitId: selectedInstance.unitId,
          instanceId: selectedInstance.instanceId,
          phone: digits,
          text: text.trim(),
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        onSendFailed(optimisticId);
        setError(data?.error || `Erro ao enviar (HTTP ${res.status})`);
        return;
      }

      const waMessageId = data.message?.gotalk_message_id || data.message?.id || optimisticId;
      const realMsg: TimelineMsg = {
        id: waMessageId,
        gotalk_message_id: waMessageId,
        body: text.trim(),
        direction: 'OUT',
        message_type: 'TEXT',
        source: 'uazapi',
        sent_at: data.message?.sent_at || new Date().toISOString(),
        ack_status: data.message?.ack_status ?? 1,
      };
      onSent(realMsg, digits, selectedInstance.unitId, optimisticId);
    } catch {
      onSendFailed(optimisticId);
      setError('Erro de conexão. Tente novamente.');
    } finally {
      setSending(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Escape' && !sending) onClose();
  };

  const canSend = !sending && !loadingInstances && !!selectedKey && text.trim().length > 0 && phone.replace(/\D/g, '').length >= 8;

  // Group instances by unit for the dropdown display
  const unitGroups = instances.reduce<Record<string, { unitName: string; items: InstanceOption[] }>>((acc, inst) => {
    if (!acc[inst.unitId]) acc[inst.unitId] = { unitName: inst.unitName, items: [] };
    acc[inst.unitId].items.push(inst);
    return acc;
  }, {});
  const multiUnit = Object.keys(unitGroups).length > 1;

  return (
    <div
      className="fixed inset-0 z-[9999] flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm p-2 sm:p-4"
      onKeyDown={handleKeyDown}
    >
      <div role="dialog" aria-modal="true" className="whatsapp-theme responsive-modal-surface bg-white rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-sm overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between px-6 pt-5 pb-4 border-b border-gray-100">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-green-600 flex items-center justify-center flex-shrink-0">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
            </div>
            <h2 className="text-base font-bold text-gray-900">Nova mensagem WhatsApp</h2>
          </div>
          <button
            onClick={onClose}
            disabled={sending}
            className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors disabled:opacity-40"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="px-6 py-5 space-y-4">
          {/* Phone */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1.5">
              Telefone <span className="text-red-500">*</span>
            </label>
            <input
              type="tel"
              value={phone}
              onChange={e => { setPhone(e.target.value); setError(null); }}
              autoFocus={!initialPhone}
              placeholder="DDD + número (ex: 81999998888)"
              disabled={sending}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 font-mono disabled:opacity-60 disabled:bg-gray-50"
            />
          </div>

          {/* Channel / instance selector */}
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1.5">
              Canal de envio <span className="text-red-500">*</span>
            </label>
            {loadingInstances ? (
              <div className="flex items-center gap-2 text-xs text-gray-400 py-2">
                <svg className="w-3.5 h-3.5 animate-spin flex-shrink-0" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                </svg>
                Carregando canais...
              </div>
            ) : instances.length === 0 ? (
              <p className="text-xs text-orange-600 bg-orange-50 border border-orange-100 rounded-lg px-3 py-2">
                Nenhum canal uazapi configurado.
              </p>
            ) : (
              <select
                value={selectedKey}
                onChange={e => { setSelectedKey(e.target.value); setError(null); }}
                disabled={sending}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 bg-white disabled:opacity-60"
              >
                {instances.length > 1 && <option value="">Selecione o canal...</option>}
                {multiUnit
                  ? Object.entries(unitGroups).map(([uid, group]) => (
                      <optgroup key={uid} label={group.unitName}>
                        {group.items.map(inst => (
                          <option key={inst.instanceId} value={`${inst.unitId}::${inst.instanceId}`}>
                            {inst.label || inst.instanceId}
                          </option>
                        ))}
                      </optgroup>
                    ))
                  : instances.map(inst => (
                      <option key={inst.instanceId} value={`${inst.unitId}::${inst.instanceId}`}>
                        {inst.label || inst.instanceId}
                        {inst.unitName ? ` — ${inst.unitName}` : ''}
                      </option>
                    ))
                }
              </select>
            )}
          </div>

          {/* Message + Quick-text */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-gray-600">
                Mensagem <span className="text-red-500">*</span>
              </label>
              {/* Quick-text dropdown */}
              <div ref={quickTextRef} className="relative">
                <button
                  type="button"
                  onClick={() => setShowQuickTexts(v => !v)}
                  disabled={sending}
                  className="flex items-center gap-1 text-[10px] font-medium text-green-700 hover:text-green-800 border border-green-200 hover:border-green-400 rounded-md px-2 py-0.5 bg-green-50 hover:bg-green-100 transition-colors disabled:opacity-40"
                  title="Inserir texto rápido"
                >
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                  </svg>
                  Texto rápido
                </button>
                {showQuickTexts && (
                  <div className="absolute right-0 top-full mt-1 w-72 bg-white border border-gray-200 rounded-xl shadow-xl z-10 py-1 max-h-64 overflow-y-auto">
                    {QUICK_TEXTS.map((qt, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => {
                          setText(qt.text);
                          setShowQuickTexts(false);
                          setError(null);
                        }}
                        className="w-full text-left px-3 py-2.5 hover:bg-green-50 transition-colors"
                      >
                        <p className="text-xs font-semibold text-gray-700 mb-0.5">{qt.label}</p>
                        <p className="text-[10px] text-gray-500 line-clamp-2 leading-relaxed">{qt.text}</p>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <textarea
              value={text}
              onChange={e => { setText(e.target.value); setError(null); }}
              onKeyDown={e => {
                if (e.key === 'Enter' && e.ctrlKey) { e.preventDefault(); if (canSend) handleSend(); }
              }}
              rows={3}
              autoFocus={!!initialPhone}
              placeholder="Digite a mensagem..."
              disabled={sending}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 resize-none disabled:opacity-60 disabled:bg-gray-50"
            />
            <p className="text-[10px] text-gray-400 mt-1">Ctrl+Enter para enviar</p>
          </div>

          {/* Error */}
          {error && (
            <p className="text-xs text-red-600 bg-red-50 border border-red-100 rounded-lg px-3 py-2">
              {error}
            </p>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 pb-5 flex justify-end gap-3">
          <button
            onClick={onClose}
            disabled={sending}
            className="px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors disabled:opacity-60"
          >
            Cancelar
          </button>
          <button
            onClick={handleSend}
            disabled={!canSend}
            className="px-4 py-2 text-sm text-white rounded-lg transition-colors disabled:opacity-60 flex items-center gap-2"
            style={{ background: '#16a34a' }}
          >
            {sending && (
              <svg className="w-3.5 h-3.5 animate-spin flex-shrink-0" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
              </svg>
            )}
            {sending ? 'Enviando...' : 'Enviar'}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProspeccaoWhatsappModal;

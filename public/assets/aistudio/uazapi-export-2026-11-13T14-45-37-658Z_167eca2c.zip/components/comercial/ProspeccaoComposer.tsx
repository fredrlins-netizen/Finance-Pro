import React, { useEffect, useRef, useState } from 'react';
import { ConversationComposerSurface } from '../conversations/ConversationPrimitives';

// ── ProspeccaoComposer ────────────────────────────────────────────────────────
// Compositor compartilhado da Prospecção: texto + emoji + anexo (com preview) +
// gravação de áudio (MediaRecorder) + template HSM + envio.
//
// Roteamento por canal:
//  • uazapi  → suporta mídia binária (imagem/vídeo/áudio/documento) via onSendMedia
//  • GoTalk  → apenas texto e templates (anexo/áudio ocultos quando allowMedia=false)

export interface ProspeccaoComposerProps {
  source: 'gotalk' | 'uazapi';
  value: string;
  onChange: (v: string) => void;
  onSendText: () => void;
  // Retorna `false` (ou resolve para `false`) quando o envio falha — nesse caso
  // o anexo pendente e a legenda são preservados para nova tentativa.
  onSendMedia: (file: File, caption: string, asVoice?: boolean) => boolean | void | Promise<boolean | void>;
  onOpenTemplate?: () => void;
  disabled?: boolean;
  sendLoading?: boolean;
  placeholder?: string;
  allowMedia?: boolean;
  allowTemplate?: boolean;
  compact?: boolean;
}

// Lista enxuta de emojis frequentes — evita dependência externa.
const EMOJI_GROUPS: { label: string; emojis: string[] }[] = [
  {
    label: 'Sorrisos',
    emojis: ['😀', '😃', '😄', '😁', '😆', '😅', '😂', '🤣', '😊', '😇', '🙂', '😉', '😍', '🥰', '😘', '😋', '😎', '🤩', '🥳', '🤗', '🤔', '😴', '😢', '😭', '😡', '👍', '👏', '🙏', '💪', '🤝'],
  },
  {
    label: 'Símbolos',
    emojis: ['❤️', '🧡', '💛', '💚', '💙', '💜', '✅', '❌', '⚠️', '⭐', '🔥', '💯', '🎉', '🎁', '📌', '📎', '📞', '📲', '💰', '💵', '📅', '🕐', '✔️', '❗', '❓', '➡️', '⬅️', '🔔', '📝', '🤑'],
  },
];

function ProspeccaoComposer({
  source,
  value,
  onChange,
  onSendText,
  onSendMedia,
  onOpenTemplate,
  disabled = false,
  sendLoading = false,
  placeholder = 'Digite uma mensagem...',
  allowMedia = false,
  allowTemplate = false,
  compact = false,
}: ProspeccaoComposerProps) {
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const emojiBtnRef = useRef<HTMLDivElement>(null);

  const [emojiOpen, setEmojiOpen] = useState(false);
  const [pendingFile, setPendingFile] = useState<File | null>(null);
  const [pendingPreview, setPendingPreview] = useState<string | null>(null);
  const [pendingIsVoice, setPendingIsVoice] = useState(false);

  // Gravação de áudio
  const [recording, setRecording] = useState(false);
  const [recSeconds, setRecSeconds] = useState(0);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const recChunksRef = useRef<BlobPart[]>([]);
  const recTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const recStreamRef = useRef<MediaStream | null>(null);

  // Fecha popover de emoji ao clicar fora.
  useEffect(() => {
    if (!emojiOpen) return;
    const onDocClick = (e: MouseEvent) => {
      if (emojiBtnRef.current && !emojiBtnRef.current.contains(e.target as Node)) {
        setEmojiOpen(false);
      }
    };
    document.addEventListener('mousedown', onDocClick);
    return () => document.removeEventListener('mousedown', onDocClick);
  }, [emojiOpen]);

  // Libera object URL ao trocar/limpar o arquivo pendente.
  useEffect(() => {
    return () => {
      if (pendingPreview) URL.revokeObjectURL(pendingPreview);
    };
  }, [pendingPreview]);

  // Limpa recursos de gravação ao desmontar.
  useEffect(() => {
    return () => {
      if (recTimerRef.current) clearInterval(recTimerRef.current);
      recStreamRef.current?.getTracks().forEach(t => t.stop());
    };
  }, []);

  const clearPending = () => {
    if (pendingPreview) URL.revokeObjectURL(pendingPreview);
    setPendingFile(null);
    setPendingPreview(null);
    setPendingIsVoice(false);
  };

  const setPending = (file: File, isVoice = false) => {
    if (pendingPreview) URL.revokeObjectURL(pendingPreview);
    setPendingFile(file);
    setPendingPreview(URL.createObjectURL(file));
    setPendingIsVoice(isVoice);
  };

  const insertEmoji = (emoji: string) => {
    const el = textareaRef.current;
    if (!el) {
      onChange(value + emoji);
      return;
    }
    const start = el.selectionStart ?? value.length;
    const end = el.selectionEnd ?? value.length;
    const next = value.slice(0, start) + emoji + value.slice(end);
    onChange(next);
    // Reposiciona o cursor após o emoji inserido.
    requestAnimationFrame(() => {
      el.focus();
      const pos = start + emoji.length;
      el.setSelectionRange(pos, pos);
    });
  };

  const handleFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setPending(file, false);
    // Permite re-selecionar o mesmo arquivo depois.
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const doSend = async () => {
    if (sendLoading || disabled) return;
    if (pendingFile) {
      const ok = await onSendMedia(pendingFile, value.trim(), pendingIsVoice);
      // Preserva o anexo/legenda quando o envio falha (ok === false).
      if (ok === false) return;
      clearPending();
      onChange('');
      return;
    }
    if (value.trim()) onSendText();
  };

  // ── Gravação de áudio ───────────────────────────────────────────────────────
  const startRecording = async () => {
    if (recording) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      recStreamRef.current = stream;
      const mr = new MediaRecorder(stream);
      recChunksRef.current = [];
      mr.ondataavailable = ev => { if (ev.data.size > 0) recChunksRef.current.push(ev.data); };
      mr.onstop = () => {
        const mime = mr.mimeType || 'audio/webm';
        const ext = mime.includes('ogg') ? 'ogg' : mime.includes('mp4') ? 'm4a' : 'webm';
        const blob = new Blob(recChunksRef.current, { type: mime });
        const file = new File([blob], `audio-${Date.now()}.${ext}`, { type: mime });
        recStreamRef.current?.getTracks().forEach(t => t.stop());
        recStreamRef.current = null;
        if (blob.size > 0) setPending(file, true);
      };
      mediaRecorderRef.current = mr;
      mr.start();
      setRecording(true);
      setRecSeconds(0);
      recTimerRef.current = setInterval(() => setRecSeconds(s => s + 1), 1000);
    } catch {
      // Permissão negada ou sem microfone — falha silenciosa, botão volta ao normal.
      setRecording(false);
    }
  };

  const stopRecording = () => {
    if (recTimerRef.current) { clearInterval(recTimerRef.current); recTimerRef.current = null; }
    mediaRecorderRef.current?.stop();
    setRecording(false);
  };

  const cancelRecording = () => {
    if (recTimerRef.current) { clearInterval(recTimerRef.current); recTimerRef.current = null; }
    const mr = mediaRecorderRef.current;
    if (mr) {
      mr.onstop = () => {
        recStreamRef.current?.getTracks().forEach(t => t.stop());
        recStreamRef.current = null;
      };
      mr.stop();
    }
    setRecording(false);
    setRecSeconds(0);
  };

  const fmtRec = (s: number) => `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
  const px = compact ? 'px-3 py-2' : 'px-4 py-3';
  const canSend = !disabled && !sendLoading && (pendingFile != null || value.trim().length > 0);

  // Estado: gravando — mostra UI dedicada.
  if (recording) {
    return (
      <ConversationComposerSurface className={`border-t border-gray-200 bg-white ${px} flex items-center gap-3 flex-shrink-0`}>
        <span className="flex items-center gap-2 text-sm text-red-600 font-medium flex-1">
          <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-pulse" />
          Gravando… {fmtRec(recSeconds)}
        </span>
        <button
          onClick={cancelRecording}
          className="px-3 py-1.5 rounded-lg text-xs font-semibold text-gray-600 hover:bg-gray-100 transition-colors"
          title="Cancelar gravação"
        >
          Cancelar
        </button>
        <button
          onClick={stopRecording}
          className="w-9 h-9 rounded-full flex items-center justify-center text-white flex-shrink-0 transition-colors"
          style={{ background: '#16a34a' }}
          title="Concluir gravação"
        >
          <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2" /></svg>
        </button>
      </ConversationComposerSurface>
    );
  }

  return (
    <ConversationComposerSurface className={`border-t border-gray-200 bg-white ${px} flex-shrink-0`}>
      {/* Preview do anexo pendente */}
      {pendingFile && (
        <div className="mb-2 flex items-center gap-2 bg-gray-50 border border-gray-200 rounded-lg p-2">
          {pendingFile.type.startsWith('image/') ? (
            <img src={pendingPreview || ''} alt={pendingFile.name} className="w-12 h-12 object-cover rounded" />
          ) : pendingFile.type.startsWith('audio/') ? (
            <audio src={pendingPreview || ''} controls className="h-8 max-w-[200px]" />
          ) : pendingFile.type.startsWith('video/') ? (
            <video src={pendingPreview || ''} className="w-12 h-12 object-cover rounded" />
          ) : (
            <span className="text-2xl" aria-hidden="true">📎</span>
          )}
          <div className="flex flex-col min-w-0 flex-1">
            <span className="text-xs text-gray-700 truncate">{pendingIsVoice ? 'Mensagem de voz' : pendingFile.name}</span>
            <span className="text-[10px] text-gray-400">
              {(pendingFile.size / 1024).toFixed(0)} KB{pendingIsVoice ? '' : ' • adicione uma legenda (opcional)'}
            </span>
          </div>
          <button
            onClick={clearPending}
            className="text-gray-400 hover:text-red-500 transition-colors flex-shrink-0"
            title="Remover anexo"
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
      )}

      <div className="flex gap-1.5 items-end">
        {/* Emoji */}
        <div className="relative" ref={emojiBtnRef}>
          <button
            type="button"
            onClick={() => setEmojiOpen(o => !o)}
            disabled={disabled}
            className="w-9 h-9 rounded-full flex items-center justify-center text-gray-500 hover:bg-gray-100 transition-colors disabled:opacity-40 flex-shrink-0"
            title="Emojis"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </button>
          {emojiOpen && (
            <div className="absolute bottom-11 left-0 z-30 w-64 max-h-60 overflow-y-auto bg-white border border-gray-200 rounded-lg shadow-lg p-2">
              {EMOJI_GROUPS.map(group => (
                <div key={group.label} className="mb-1">
                  <p className="text-[10px] font-semibold text-gray-400 px-1 mb-1">{group.label}</p>
                  <div className="grid grid-cols-8 gap-0.5">
                    {group.emojis.map(em => (
                      <button
                        key={em}
                        type="button"
                        onClick={() => insertEmoji(em)}
                        className="text-lg leading-none p-1 rounded hover:bg-gray-100 transition-colors"
                      >
                        {em}
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Anexar (somente uazapi) */}
        {allowMedia && (
          <>
            <input
              ref={fileInputRef}
              type="file"
              className="hidden"
              accept="image/*,video/*,audio/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.csv,.zip"
              onChange={handleFilePicked}
            />
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={disabled}
              className="w-9 h-9 rounded-full flex items-center justify-center text-gray-500 hover:bg-gray-100 transition-colors disabled:opacity-40 flex-shrink-0"
              title="Anexar arquivo"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
              </svg>
            </button>
          </>
        )}

        {/* Template HSM */}
        {allowTemplate && onOpenTemplate && (
          <button
            type="button"
            onClick={onOpenTemplate}
            disabled={disabled}
            className="w-9 h-9 rounded-full flex items-center justify-center text-gray-500 hover:bg-gray-100 transition-colors disabled:opacity-40 flex-shrink-0"
            title="Enviar template HSM"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
          </button>
        )}

        {/* Texto */}
        <textarea
          ref={textareaRef}
          className="flex-1 border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-green-400 disabled:bg-gray-50 disabled:opacity-60"
          rows={2}
          placeholder={pendingFile ? 'Legenda (opcional)…' : placeholder}
          value={value}
          onChange={e => onChange(e.target.value)}
          onKeyDown={e => {
            if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); doSend(); }
          }}
          disabled={disabled}
        />

        {/* Gravar áudio (somente uazapi) — escondido quando há anexo pendente */}
        {allowMedia && !pendingFile && !value.trim() && (
          <button
            type="button"
            onClick={startRecording}
            disabled={disabled}
            className="w-9 h-9 rounded-full flex items-center justify-center text-gray-500 hover:bg-gray-100 transition-colors disabled:opacity-40 flex-shrink-0"
            title="Gravar áudio"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19 11a7 7 0 01-14 0m7 7v3m0-3a3 3 0 01-3-3V5a3 3 0 016 0v6a3 3 0 01-3 3z" />
            </svg>
          </button>
        )}

        {/* Enviar */}
        <button
          onClick={doSend}
          disabled={!canSend}
          className="w-9 h-9 rounded-full flex items-center justify-center text-white flex-shrink-0 transition-colors disabled:opacity-40"
          style={{ background: '#16a34a' }}
          title="Enviar"
        >
          {sendLoading ? (
            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
            </svg>
          ) : (
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
            </svg>
          )}
        </button>
      </div>
    </ConversationComposerSurface>
  );
}

export default ProspeccaoComposer;

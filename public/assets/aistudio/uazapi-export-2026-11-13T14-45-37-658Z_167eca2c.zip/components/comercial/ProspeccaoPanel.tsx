import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import GoTalkMediaRenderer from '../gotalk/GoTalkMediaRenderer';
import { useSocket } from '../../contexts/SocketContext';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { useMessaging } from '../../contexts/MessagingContext';
import ProspeccaoDashboard from './ProspeccaoDashboard';
import UazapiQrModal from '../settings/tabs/UazapiQrModal';
import ProspeccaoClientModal from './ProspeccaoClientModal';
import ProspeccaoAgendamentoModal from './ProspeccaoAgendamentoModal';
import ProspeccaoWhatsappModal from './ProspeccaoWhatsappModal';
import ProspeccaoComposer from './ProspeccaoComposer';
import GotalkSendTemplateModal from '../gotalk/GotalkSendTemplateModal';
import MessageToast, { MessageToastItem } from '../ui/MessageToast';
import ClientAttachmentsPanel from '../attachments/ClientAttachmentsPanel';
import {
  ConversationBubble,
  ConversationDateSeparator,
  ConversationSurface,
  ConversationTimeline,
} from '../conversations/ConversationPrimitives';

// ── ACK icon helper ────────────────────────────────────────────────────────────
// Mapping mirrors ConversasPanel.tsx: null/0=⏱ pending, 1=✓ sent, 2=✓✓ gray delivered, 3+=✓✓ blue read
function renderAckIcon(ackStatus?: number | null): React.ReactElement {
  if (ackStatus == null || ackStatus === 0) {
    return (
      <svg className="inline-block w-3 h-3 text-gray-400 flex-shrink-0" viewBox="0 0 16 16" fill="none" stroke="currentColor">
        <circle cx="8" cy="8" r="6" strokeWidth="1.5" className="opacity-60" />
        <path strokeLinecap="round" strokeWidth="1.5" d="M8 5v3.2l1.8 1" />
      </svg>
    );
  }
  if (ackStatus === 1) {
    return (
      <svg className="inline-block w-3.5 h-2.5 text-gray-400 flex-shrink-0" viewBox="0 0 14 9" fill="none">
        <path d="M1 4.5L4.5 8L13 1" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }
  if (ackStatus === 2) {
    return (
      <svg className="inline-block w-4 h-2.5 text-gray-400 flex-shrink-0" viewBox="0 0 18 9" fill="none">
        <path d="M1 4.5L4.5 8L13 1" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M5 4.5L8.5 8L17 1" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    );
  }
  return (
    <svg className="inline-block w-4 h-2.5 text-blue-500 flex-shrink-0" viewBox="0 0 18 9" fill="none">
      <path d="M1 4.5L4.5 8L13 1" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M5 4.5L8.5 8L17 1" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

// ── Types ─────────────────────────────────────────────────────────────────────

interface WaContactInfo {
  name?: string;
  pushname?: string;
  notifyName?: string;
  isBusiness?: boolean;
  isEnterprise?: boolean;
  verifiedName?: string | null;
  description?: string | null;
  about?: string | null;
  businessCategory?: string | null;
  businessDescription?: string | null;
}

interface ProspectionContact {
  id: string;
  phone: string;
  contact_name: string | null;
  classification: 'LEAD' | 'RECUPERACAO';
  total_contacts: number;
  first_contact_at: string;
  last_contact_at: string;
  unit_id: string | null;
  unit_name: string | null;
  operator_id: string | null;
  operator_name_linked: string | null;
  client_id: string | null;
  client_name_linked: string | null;
  source: string;
  uazapi_instance_id: string | null;
  last_source: string | null;
  uazapi_unit_id: string | null;
  // Task #294: instance that received the most recent inbound message.
  // Used by the composer to auto-follow replies to the originating instance.
  last_inbound_instance_id?: string | null;
  // Task #300: timestamp of most recent inbound + server-side unread count
  // (used for "pendentes primeiro" ordering on the contact list).
  last_inbound_at?: string | null;
  unread_count?: number;
}

interface GotalkChannel {
  id: string;
  name: string;
  phone_number: string | null;
  is_primary: boolean;
  is_active: boolean;
  unit_id: string | null;
  unit_name: string | null;
}

interface UazapiInstanceInfo {
  configured: boolean;
  isConnected: boolean;
  instanceId: string | null;
  label: string | null;
  phoneNumber: string | null;
  serverUrl: string | null;
  error: string | null;
}

interface ProspectionConversation {
  id: string;
  phone: string;
  classification: 'LEAD' | 'RECUPERACAO';
  start_at: string;
  end_at: string | null;
  outcome: string | null;
  summary_text: string | null;
  summary_data?: { nextStep?: string } | null;
  operator_name: string | null;
  unit_name: string | null;
  message_count: number | null;
}

interface ProspectionNote {
  id: string;
  user_id: string | null;
  user_name: string;
  note_text: string;
  attachments: { name: string; mimeType: string; data: string }[];
  created_at: string;
  updated_at: string;
}

interface InstanceStatus {
  unitId: string;
  unitName: string;
  instanceId: string;
  label: string | null;
  phoneNumber: string | null;
  isConnected: boolean;
  error: string | null;
}

interface TimelineMsg {
  id?: string;
  gotalk_message_id?: string | null;
  body: string | null;
  direction: 'IN' | 'OUT';
  message_type: string;
  sent_at?: string | null;
  attachment_url?: string | null;
  attachment_name?: string | null;
  attachment_mime_type?: string | null;
  operator_name?: string | null;
  source?: string;
  ack_status?: number | null;
  uazapi_instance_id?: string | null;
}

// Chave estável para deduplicar mensagens ao mesclar lotes (paginação de
// mensagens anteriores + atualizações em tempo real).
function timelineMsgKey(m: TimelineMsg): string {
  if (m.id) return `id:${m.id}`;
  if (m.gotalk_message_id) return `gt:${m.gotalk_message_id}`;
  // Fallback (sem id): combina vários campos para reduzir colisões falsas entre
  // mensagens distintas com mesmo horário/direção/texto.
  return [
    m.sent_at || '',
    m.direction || '',
    m.source || '',
    m.message_type || '',
    m.attachment_url || '',
    m.operator_name || '',
    m.body || '',
  ].join('|');
}

// Mescla lotes de mensagens removendo duplicatas. A ordenação final para exibição
// é feita por sent_at em sortedTimeline, então a ordem aqui não importa.
function mergeTimelineMsgs(a: TimelineMsg[], b: TimelineMsg[]): TimelineMsg[] {
  const map = new Map<string, TimelineMsg>();
  for (const m of a) map.set(timelineMsgKey(m), m);
  for (const m of b) map.set(timelineMsgKey(m), m);
  return Array.from(map.values());
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function formatPhone(p: string): string {
  const d = (p || '').replace(/\D/g, '');
  if (d.length === 13) return `+${d.slice(0, 2)} (${d.slice(2, 4)}) ${d.slice(4, 9)}-${d.slice(9)}`;
  if (d.length === 12) return `+${d.slice(0, 2)} (${d.slice(2, 4)}) ${d.slice(4, 8)}-${d.slice(8)}`;
  if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
  if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
  return p;
}

function formatDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' });
}

function formatDateTime(iso: string | null | undefined): string {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' })
    + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function formatTime(iso?: string | null): string {
  if (!iso) return '';
  return new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function formatDayLabel(iso?: string | null): string {
  if (!iso) return '';
  const d = new Date(iso);
  const today = new Date();
  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const sameDay = (a: Date, b: Date) =>
    a.getFullYear() === b.getFullYear() && a.getMonth() === b.getMonth() && a.getDate() === b.getDate();
  if (sameDay(d, today)) return 'Hoje';
  if (sameDay(d, yesterday)) return 'Ontem';
  return d.toLocaleDateString('pt-BR', { weekday: 'short', day: '2-digit', month: '2-digit' });
}

const OUTCOME_LABELS: Record<string, string> = {
  INTERESSE_ALTO: 'Interesse alto',
  INTERESSE_MEDIO: 'Interesse médio',
  INTERESSE_BAIXO: 'Interesse baixo',
  SEM_INTERESSE: 'Sem interesse',
  NAO_DEFINIDO: 'Não definido',
};

const OUTCOME_COLORS: Record<string, string> = {
  INTERESSE_ALTO: 'bg-green-100 text-green-800',
  INTERESSE_MEDIO: 'bg-blue-100 text-blue-800',
  INTERESSE_BAIXO: 'bg-yellow-100 text-yellow-800',
  SEM_INTERESSE: 'bg-red-100 text-red-800',
  NAO_DEFINIDO: 'bg-gray-100 text-gray-600',
};

// ── Badge components ─────────────────────────────────────────────────────────

const ClassBadge: React.FC<{ c: 'LEAD' | 'RECUPERACAO' }> = ({ c }) => (
  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold tracking-wide ${
    c === 'LEAD'
      ? 'bg-green-100 text-green-800'
      : 'bg-orange-100 text-orange-800'
  }`}>
    {c === 'LEAD' ? 'Lead' : 'Recuperação'}
  </span>
);

// ── ChannelBadge — indicador de canal/origem por mensagem (Tratativa 03) ──────
// Identifica visualmente a origem de cada mensagem na timeline:
//   • uazapi      → verde  + 📱
//   • GoTalk      → azul   + 💬
//   • desconhecido→ cinza  + ❓
// `source` pode chegar como 'uazapi', 'gotalk' ou prefixado (ex.: 'uazapi-instancia-1').
// Mensagens legadas sem `source` são tratadas como GoTalk, mantendo a mesma
// semântica do filtro de split-mode (gtMessages inclui mensagens sem source).
function resolveChannelBadge(source?: string | null): { label: string; cls: string; icon: string } {
  const s = (source || '').toLowerCase();
  if (s.startsWith('uazapi')) return { label: 'uazapi', cls: 'text-green-700 bg-green-50 border-green-200', icon: '📱' };
  if (s === '' || s.startsWith('gotalk')) return { label: 'GoTalk', cls: 'text-blue-700 bg-blue-50 border-blue-200', icon: '💬' };
  return { label: 'Desconhecido', cls: 'text-gray-500 bg-gray-100 border-gray-200', icon: '❓' };
}

const ChannelBadge: React.FC<{ source?: string | null; compact?: boolean; detail?: string | null }> = ({ source, compact = true, detail }) => {
  const b = resolveChannelBadge(source);
  return (
    <span
      className={`inline-flex items-center gap-0.5 rounded border font-bold ${b.cls} ${compact ? 'text-[9px] px-1 py-0' : 'text-[10px] px-1.5 py-0.5'}`}
      title={detail ? `Canal: ${b.label} · ${detail}` : `Canal: ${b.label}`}
    >
      <span aria-hidden>{b.icon}</span>
      <span>{b.label}</span>
      {detail && <span className="font-mono font-normal opacity-80">· {detail}</span>}
    </span>
  );
};

// ── Close conversation modal ──────────────────────────────────────────────────

interface CloseModalProps {
  conversationId: string;
  onClose: () => void;
  onConfirm: (data: { outcome: string; summaryText: string; nextStep: string }) => Promise<void>;
}

const CloseConversationModal: React.FC<CloseModalProps> = ({ conversationId, onClose, onConfirm }) => {
  const [outcome, setOutcome] = useState('NAO_DEFINIDO');
  const [summaryText, setSummaryText] = useState('');
  const [nextStep, setNextStep] = useState('');
  const [saving, setSaving] = useState(false);

  const handleConfirm = async () => {
    setSaving(true);
    try {
      await onConfirm({ outcome, summaryText, nextStep });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 overflow-hidden">
        <div className="bg-moss-800 px-6 py-4 flex items-center justify-between" style={{ background: '#2d4a3e' }}>
          <span className="text-white font-semibold">Encerrar conversa</span>
          <button onClick={onClose} className="text-white/70 hover:text-white transition-colors">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="p-6 space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Desfecho</label>
            <select
              value={outcome}
              onChange={e => setOutcome(e.target.value)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 bg-white"
            >
              <option value="NAO_DEFINIDO">Não definido</option>
              <option value="INTERESSE_ALTO">Interesse alto</option>
              <option value="INTERESSE_MEDIO">Interesse médio</option>
              <option value="INTERESSE_BAIXO">Interesse baixo</option>
              <option value="SEM_INTERESSE">Sem interesse</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Observações</label>
            <textarea
              value={summaryText}
              onChange={e => setSummaryText(e.target.value)}
              rows={3}
              placeholder="Resumo do que foi tratado..."
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 resize-none"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 mb-1">Próximo passo</label>
            <input
              type="text"
              value={nextStep}
              onChange={e => setNextStep(e.target.value)}
              placeholder="Ex: Enviar proposta na segunda-feira"
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
            />
          </div>
        </div>
        <div className="px-6 pb-5 flex justify-end gap-3">
          <button
            onClick={onClose}
            disabled={saving}
            className="px-4 py-2 text-sm text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleConfirm}
            disabled={saving}
            className="px-4 py-2 text-sm text-white rounded-lg transition-colors disabled:opacity-60"
            style={{ background: '#2d4a3e' }}
          >
            {saving ? 'Salvando...' : 'Confirmar'}
          </button>
        </div>
      </div>
    </div>
  );
};

// ── ProspeccaoChatColumn — split-mode sub-column ──────────────────────────────

interface ProspeccaoChatColumnProps {
  source: 'gotalk' | 'uazapi';
  messages: TimelineMsg[];
  channelLabel: string;
  waConnected?: boolean | null;
  isAvailable: boolean;
  unavailableReason: string;
  sendText: string;
  onSendTextChange: (text: string) => void;
  onSend: () => void;
  onSendMedia: (file: File, caption: string, asVoice?: boolean) => boolean | void | Promise<boolean | void>;
  onOpenTemplate: () => void;
  sendLoading: boolean;
  endRef: React.RefObject<HTMLDivElement>;
  onLoadOlder?: () => void;
  loadingOlder?: boolean;
  hasMoreOlder?: boolean;
  instancePhoneMap?: Map<string, string>;
}

const ProspeccaoChatColumn: React.FC<ProspeccaoChatColumnProps> = ({
  source,
  messages,
  channelLabel,
  waConnected,
  isAvailable,
  unavailableReason,
  sendText,
  onSendTextChange,
  onSend,
  onSendMedia,
  onOpenTemplate,
  sendLoading,
  endRef,
  onLoadOlder,
  loadingOlder,
  hasMoreOlder,
  instancePhoneMap,
}) => {
  // Restauração de rolagem por coluna (cada coluna tem seu próprio container).
  // Captura altura/posição ao clicar em "Carregar mais" e restaura após o prepend.
  const colScrollRef = React.useRef<HTMLDivElement>(null);
  const pendingScrollRef = React.useRef<{ height: number; top: number } | null>(null);
  const handleColLoadOlder = React.useCallback(() => {
    const el = colScrollRef.current;
    if (el) pendingScrollRef.current = { height: el.scrollHeight, top: el.scrollTop };
    onLoadOlder?.();
  }, [onLoadOlder]);
  React.useLayoutEffect(() => {
    const el = colScrollRef.current;
    if (pendingScrollRef.current && el) {
      el.scrollTop = el.scrollHeight - pendingScrollRef.current.height + pendingScrollRef.current.top;
      pendingScrollRef.current = null;
    }
  }, [messages]);

  const isGotalk = source === 'gotalk';
  const statusDot = !isGotalk
    ? waConnected === true
      ? <span className="w-2 h-2 rounded-full bg-green-500 flex-shrink-0" title="Conectado" />
      : waConnected === false
        ? <span className="w-2 h-2 rounded-full bg-orange-400 flex-shrink-0" title="Desconectado" />
        : <span className="w-2 h-2 rounded-full bg-gray-300 flex-shrink-0 animate-pulse" title="Verificando…" />
    : null;

  return (
    <ConversationSurface className="flex-1 flex flex-col overflow-hidden border-r border-gray-200 last:border-r-0 min-w-0">
      {/* Column header */}
      <div className={`flex items-center gap-2 px-3 py-2 border-b flex-shrink-0 ${isGotalk ? 'bg-blue-50 border-blue-100' : 'bg-green-50 border-green-100'}`}>
        {isGotalk ? (
          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-100 text-blue-700 border border-blue-200 flex-shrink-0">
            <svg className="w-2.5 h-2.5" viewBox="0 0 8 8" fill="currentColor"><circle cx="4" cy="4" r="4"/></svg>
            GoTalk
          </span>
        ) : (
          <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-100 text-green-700 border border-green-200 flex-shrink-0">
            {statusDot}
            uazapi
          </span>
        )}
        {channelLabel && (
          <span className="text-[10px] text-gray-500 truncate flex-1" title={channelLabel}>{channelLabel}</span>
        )}
      </div>

      {/* Unavailable banner */}
      {!isAvailable && (
        <div className="flex items-start gap-2 px-3 py-2 bg-yellow-50 border-b border-yellow-200 flex-shrink-0 text-xs text-yellow-800">
          <svg className="w-4 h-4 flex-shrink-0 mt-0.5 text-yellow-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
          </svg>
          <span>{unavailableReason}</span>
        </div>
      )}

      {/* Messages timeline */}
      <ConversationTimeline
        ref={colScrollRef}
        className="flex-1 overflow-y-auto p-3 space-y-1"
        style={{
          backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23e0e0e0' fill-opacity='0.25'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
          backgroundColor: '#f0f2f5',
        }}
      >
        {hasMoreOlder && onLoadOlder && (
          <div className="flex justify-center py-2">
            <button
              onClick={handleColLoadOlder}
              disabled={loadingOlder}
              className="px-3 py-1.5 text-[11px] font-semibold text-moss-700 bg-white border border-moss-200 rounded-full shadow-sm hover:bg-moss-50 transition-colors disabled:opacity-60"
            >
              {loadingOlder ? 'Carregando…' : 'Carregar mais 500 mensagens anteriores'}
            </button>
          </div>
        )}
        {messages.length === 0 ? (
          <div className="flex items-center justify-center h-full text-gray-400 text-xs">
            Nenhuma mensagem via {isGotalk ? 'GoTalk' : 'uazapi'}
          </div>
        ) : (
          (() => {
            let lastDay = '';
            return messages.map((msg, i) => {
              const day = msg.sent_at ? new Date(msg.sent_at).toDateString() : '';
              const showDay = day && day !== lastDay;
              if (showDay) lastDay = day;
              const isOut = msg.direction === 'OUT';
              return (
                <React.Fragment key={msg.id || i}>
                  {showDay && (
                    <ConversationDateSeparator className="bg-white text-gray-500 text-[10px] font-semibold px-3 py-1 rounded-full shadow-sm border border-gray-200">
                      {formatDayLabel(msg.sent_at)}
                    </ConversationDateSeparator>
                  )}
                  <div className={`flex ${isOut ? 'justify-end' : 'justify-start'}`}>
                    <ConversationBubble outgoing={isOut} className={`max-w-[80%] rounded-xl px-3 py-2 shadow-sm text-sm ${
                      isOut
                        ? 'bg-green-100 text-gray-800 rounded-br-none'
                        : 'bg-white text-gray-800 rounded-bl-none border border-gray-100'
                    }`}>
                      <GoTalkMediaRenderer
                        messageType={msg.message_type}
                        caption={msg.body}
                        attachmentUrl={msg.attachment_url}
                        attachmentName={msg.attachment_name}
                        attachmentMime={msg.attachment_mime_type}
                      />
                      <div className="flex items-center justify-end gap-1 mt-0.5">
                        {msg.operator_name && isOut && (
                          <span className="text-[9px] text-green-700 opacity-70">{msg.operator_name}</span>
                        )}
                        <span className="text-[10px] text-gray-400">{formatTime(msg.sent_at)}</span>
                        {source === 'uazapi' && msg.uazapi_instance_id && instancePhoneMap?.get(msg.uazapi_instance_id) && (
                          <span className="text-[9px] text-gray-400 font-mono">{formatPhone(instancePhoneMap.get(msg.uazapi_instance_id)!)}</span>
                        )}
                        {isOut && renderAckIcon(msg.ack_status)}
                      </div>
                    </ConversationBubble>
                  </div>
                </React.Fragment>
              );
            });
          })()
        )}
        <div ref={endRef} />
      </ConversationTimeline>

      {/* Composer */}
      <ProspeccaoComposer
        source={source}
        value={sendText}
        onChange={onSendTextChange}
        onSendText={onSend}
        onSendMedia={onSendMedia}
        onOpenTemplate={onOpenTemplate}
        disabled={!isAvailable || sendLoading}
        sendLoading={sendLoading}
        placeholder={isAvailable ? 'Digite uma mensagem...' : 'Canal não disponível'}
        allowMedia={source === 'uazapi'}
        allowTemplate
        compact
      />
    </ConversationSurface>
  );
};

// Task #308: short suffix that flags a uazapi instance whose inbound webhook has
// gone quiet. uazapi's SaaS can silently stop calling our webhook (replies then
// never reach the screen even though sending still works). Comparing "now" to the
// last inbound message gives operators a visible hint when picking a channel.
const formatInboundStale = (lastInboundAt?: string | null): string => {
  if (!lastInboundAt) return ' — sem recepção registrada';
  const ts = new Date(lastInboundAt).getTime();
  if (Number.isNaN(ts)) return '';
  const mins = Math.floor((Date.now() - ts) / 60000);
  if (mins < 60) return ''; // recente — sem alerta
  const hours = Math.floor(mins / 60);
  if (hours < 24) return ` — última recepção há ${hours}h`;
  const days = Math.floor(hours / 24);
  return ` — ⚠ sem recepção há ${days}d`;
};

// ── Main panel ────────────────────────────────────────────────────────────────

const ProspeccaoPanel: React.FC = () => {
  const { socket } = useSocket();
  const { addToast, currentUser: loggedUser } = useSecurity();
  const { incProspeccaoUnread, decProspeccaoUnread, markGotalkConversationRead } = useMessaging();
  const { logTransaction } = useAudit();

  // ── Tab ───────────────────────────────────────────────────────────────────
  const [activeTab, setActiveTab] = useState<'contacts' | 'dashboard'>('contacts');

  // ── Contact list state ────────────────────────────────────────────────────
  const [contacts, setContacts] = useState<ProspectionContact[]>([]);
  const [contactsTotal, setContactsTotal] = useState(0);
  const [contactsPage, setContactsPage] = useState(1);
  const [contactsTotalPages, setContactsTotalPages] = useState(1);
  const [loadingContacts, setLoadingContacts] = useState(false);

  // Filters
  const [search, setSearch] = useState('');
  const [fClassification, setFClassification] = useState('');
  const [fPeriod, setFPeriod] = useState('30d');
  const [fOperator, setFOperator] = useState('');
  const [fSource, setFSource] = useState('');
  const [fHasAppointment, setFHasAppointment] = useState(false);

  // Available units/operators for filter selects (populated once on mount)
  const [filterUnits, setFilterUnits] = useState<{ id: string; name: string }[]>([]);
  const [filterOperators, setFilterOperators] = useState<{ id: string; name: string }[]>([]);

  // GoTalk channels loaded on mount (for unit→channel mapping in cards + modal)
  const [gotalkChannels, setGotalkChannels] = useState<GotalkChannel[]>([]);
  const [gotalkChannelsError, setGotalkChannelsError] = useState(false);

  // Map: unit_id → GotalkChannel[] (active channels per unit)
  // Channels without unit_id are stored under the key "__unassigned" so they
  // can be used as a fallback when no unit-specific channels are found.
  const unitChannelMap = useMemo(() => {
    const map = new Map<string, GotalkChannel[]>();
    for (const ch of gotalkChannels) {
      const key = ch.unit_id || '__unassigned';
      const arr = map.get(key) || [];
      arr.push(ch);
      map.set(key, arr);
    }
    return map;
  }, [gotalkChannels]);

  // Fast ID→name lookup for collaborators (used in appointment cards)
  const collaboratorMap = useMemo(
    () => new Map(filterOperators.map(op => [op.id, op.name])),
    [filterOperators]
  );

  // Multi-unit selection: array of selected unit IDs (subset of filterUnits)
  // Initialized to all allowed units once filter-options loads.
  const [selectedUnitIds, setSelectedUnitIds] = useState<string[]>([]);
  const [unitDropdownOpen, setUnitDropdownOpen] = useState(false);
  const unitDropdownRef = useRef<HTMLDivElement>(null);

  // Selected contact
  const [selectedContact, setSelectedContact] = useState<ProspectionContact | null>(null);

  // ── Timeline / center column state ───────────────────────────────────────
  const [timelineMsgs, setTimelineMsgs] = useState<TimelineMsg[]>([]);
  const [loadingTimeline, setLoadingTimeline] = useState(false);
  // Paginação de mensagens anteriores: carregamos as 500 mais recentes primeiro
  // (order=desc) e mantemos o cursor da mensagem mais antiga já carregada.
  const [timelineTotal, setTimelineTotal] = useState(0);
  const [olderLoaded, setOlderLoaded] = useState(0);
  const [timelineNextCursor, setTimelineNextCursor] = useState<string | null>(null);
  const [loadingMoreTimeline, setLoadingMoreTimeline] = useState(false);
  const timelineScrollRef = useRef<HTMLDivElement>(null);
  const [history, setHistory] = useState<ProspectionConversation[]>([]);
  const [expandedHistory, setExpandedHistory] = useState<Record<string, boolean>>({});

  // Active conversation for close modal
  const [activeConvId, setActiveConvId] = useState<string | null>(null);
  const [showCloseModal, setShowCloseModal] = useState(false);

  // Operator assignment
  const [assigningOperator, setAssigningOperator] = useState(false);

  // Notes (anotações acumulativas)
  const [notes, setNotes] = useState<ProspectionNote[]>([]);
  const [loadingNotes, setLoadingNotes] = useState(false);
  const [newNoteText, setNewNoteText] = useState('');
  const [newNoteAttachments, setNewNoteAttachments] = useState<{ name: string; mimeType: string; data: string }[]>([]);
  const [savingNote, setSavingNote] = useState(false);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [editNoteText, setEditNoteText] = useState('');
  const noteFileRef = useRef<HTMLInputElement>(null);
  const editFileRef = useRef<HTMLInputElement>(null);

  // WhatsApp enrichment (uazapi)
  const [waInfo, setWaInfo] = useState<WaContactInfo | null>(null);
  const [waAvatar, setWaAvatar] = useState<string | null>(null);
  const [waOnWa, setWaOnWa] = useState<boolean | null>(null);
  const [waLoading, setWaLoading] = useState(false);

  // uazapi connection status (#189/#192)
  const [waConnected, setWaConnected] = useState<boolean | null>(null);
  const [waInstanceInfo, setWaInstanceInfo] = useState<UazapiInstanceInfo | null>(null);

  // Multi-instance selector — populated when the contact's unit has >1 uazapi instance
  interface UazapiInstanceOption { instanceId: string; label: string | null; isConnected: boolean | null; phoneNumber?: string | null; }
  const [unitUazapiInstances, setUnitUazapiInstances] = useState<UazapiInstanceOption[]>([]);

  // Unified QR modal target (used by both the left panel and the banner)
  const [qrModalTarget, setQrModalTarget] = useState<{ unitId: string; instanceId: string; label: string | null } | null>(null);

  // Left-panel WhatsApp instance statuses
  const [unitInstances, setUnitInstances] = useState<InstanceStatus[]>([]);
  const [instancesLoading, setInstancesLoading] = useState(false);
  const [instancesPanelOpen, setInstancesPanelOpen] = useState(false);

  // GoTalk profile enrichment (#191)
  const [gtProfile, setGtProfile] = useState<{ name?: string | null; pictureUrl?: string | null; channelName?: string | null; gotalkId?: string | null } | null>(null);

  // ── Quick client registration + scheduling (#198) ────────────────────────
  const [linkedClientId, setLinkedClientId] = useState<string | null>(null);
  const [linkedClientName, setLinkedClientName] = useState<string | null>(null);
  const [showClientModal, setShowClientModal] = useState(false);
  const [showAgendamentoModal, setShowAgendamentoModal] = useState(false);
  const [editingAppt, setEditingAppt] = useState<any | null>(null);
  const [cancellingApptId, setCancellingApptId] = useState<string | null>(null);
  const [cancellingApptLoading, setCancellingApptLoading] = useState(false);
  const [contactAppointments, setContactAppointments] = useState<any[]>([]);
  const [apptSectionOpen, setApptSectionOpen] = useState(false);
  const [loadingApptSection, setLoadingApptSection] = useState(false);

  // Typing indicator debounce (#190)
  const typingTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Send
  const [sendText, setSendText] = useState('');
  const [sendLoading, setSendLoading] = useState(false);
  const [hasToken, setHasToken] = useState(false);

  // "Nova mensagem WhatsApp" modal (Task #256)
  const [showWaModal, setShowWaModal] = useState(false);
  const [waModalPhone, setWaModalPhone] = useState('');

  // "Trocar canal" modal
  interface UazapiInstanceOpt { instanceId: string; label: string | null; lastInboundAt?: string | null; phoneNumber?: string | null; isConnected?: boolean | null; }
  interface UazapiUnitOpt { unit_id: string; unit_name: string | null; instances: UazapiInstanceOpt[]; is_current_unit?: boolean; }
  const [showCanalModal, setShowCanalModal] = useState(false);
  const [canalNewSource, setCanalNewSource] = useState<'gotalk' | 'uazapi'>('gotalk');
  const [canalNewInstanceId, setCanalNewInstanceId] = useState('');
  const [canalNewGotalkChannelId, setCanalNewGotalkChannelId] = useState('');
  const [canalInstances, setCanalInstances] = useState<UazapiInstanceOpt[]>([]);
  const [canalInstancesLoading, setCanalInstancesLoading] = useState(false);
  const [canalSaving, setCanalSaving] = useState(false);
  // uazapi — all units with credentials (multi-unit selection)
  const [canalUazapiUnits, setCanalUazapiUnits] = useState<UazapiUnitOpt[]>([]);
  const [canalNewUazapiUnitId, setCanalNewUazapiUnitId] = useState<string>('');

  // Task #311 — modal de template HSM acionável pelo compositor.
  // `templateMode` define o roteamento: 'gotalk' usa o disparo HSM nativo;
  // 'uazapi' renderiza o template e envia como texto via /api/uazapi/send-text.
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const [templateMode, setTemplateMode] = useState<'gotalk' | 'uazapi'>('gotalk');

  // Task #311 — objectURLs de fallback criados quando o backend não devolve
  // uma URL pública para a mídia enviada. São usados na timeline para preview
  // imediato; precisam ser revogados ao trocar de contato ou desmontar para
  // não acumular memória no navegador.
  const mediaObjectUrlsRef = useRef<Set<string>>(new Set());

  // Revoga os objectURLs de fallback ao trocar de contato (a timeline anterior
  // é totalmente substituída, então as URLs antigas deixam de ser referenciadas)
  // e ao desmontar o painel.
  useEffect(() => {
    const urls = mediaObjectUrlsRef.current;
    return () => {
      urls.forEach(u => URL.revokeObjectURL(u));
      urls.clear();
    };
  }, [selectedContact?.id]);

  // ── Explicit composer channel state ─────────────────────────────────────
  // Initialized from contact data when contact is selected. Drives all send
  // routing independently from the contact's persisted last_source field,
  // allowing operator to switch channels per-session without a DB write.
  interface ComposerChannel {
    source: 'gotalk' | 'uazapi';
    gotalkChannelId: string;   // GoTalk channel UUID (stored as uazapi_instance_id when source=gotalk)
    uazapiInstanceId: string;  // uazapi instanceId
    uazapiUnitId: string;      // uazapi unit ID
  }
  const [composerChannel, setComposerChannel] = useState<ComposerChannel | null>(null);

  // ── Split mode ────────────────────────────────────────────────────────────
  const [splitMode, setSplitMode] = useState<boolean>(false);
  const splitModeRef = useRef<boolean>(false);
  const [isSplitAvailable, setIsSplitAvailable] = useState<boolean>(false);
  const [splitGtText, setSplitGtText] = useState('');
  const [splitWaText, setSplitWaText] = useState('');
  const [splitGtLoading, setSplitGtLoading] = useState(false);
  const [splitWaLoading, setSplitWaLoading] = useState(false);
  const gtEndRef = useRef<HTMLDivElement>(null);
  const waEndRef = useRef<HTMLDivElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  const isGotalkContact = Boolean(
    selectedContact && (selectedContact.last_source ?? selectedContact.source) === 'gotalk'
  );

  const timelineEndRef = useRef<HTMLDivElement>(null);
  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Filter dropdown state
  const [filterDropdownOpen, setFilterDropdownOpen] = useState(false);
  const filterDropdownRef = useRef<HTMLDivElement>(null);

  // Count of active (non-default) filters for the badge
  const activeFilterCount = [
    fClassification !== '',
    fPeriod !== '30d',
    fOperator !== '',
    fSource !== '',
    fHasAppointment,
  ].filter(Boolean).length;

  // ── Restore persisted filter preferences on mount ────────────────────────
  useEffect(() => {
    try {
      const savedFSource = localStorage.getItem('prospeccao:fSource');
      if (savedFSource !== null) setFSource(savedFSource);
    } catch { /* localStorage unavailable */ }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── ResizeObserver: track panel width for split mode availability ─────────
  useEffect(() => {
    const el = panelRef.current;
    if (!el) return;
    const ro = new ResizeObserver(entries => {
      for (const entry of entries) {
        setIsSplitAvailable(entry.contentRect.width >= 1280);
      }
    });
    ro.observe(el);
    setIsSplitAvailable(el.getBoundingClientRect().width >= 1280);
    return () => ro.disconnect();
  }, []);

  // ── Load per-user split mode preference once logged in ───────────────────
  useEffect(() => {
    if (!loggedUser?.id) return;
    try {
      const saved = localStorage.getItem(`prospeccao:splitMode:${loggedUser.id}`);
      if (saved !== null) setSplitMode(saved === 'true');
    } catch {}
  }, [loggedUser?.id]);

  // ── Keep splitModeRef current so callbacks don't need splitMode in deps ──
  useEffect(() => { splitModeRef.current = splitMode; }, [splitMode]);

  // ── Fetch uazapi status when split mode turns ON with a contact already selected ──
  // Handles the case: GoTalk contact selected in unified mode → user toggles split.
  // selectContact already handles it when splitModeRef.current is true at selection time.
  useEffect(() => {
    if (!splitMode || !selectedContact) return;
    if (waConnected !== null) return; // already resolved
    const contactSrc = selectedContact.last_source ?? selectedContact.source;
    const unitId = contactSrc === 'uazapi'
      ? (selectedContact.uazapi_unit_id || selectedContact.unit_id)
      : selectedContact.unit_id;
    if (!unitId) return;
    // Use status-batch for consistent per-unit availability resolution (#286 split mode)
    fetch(`/api/uazapi/status-batch?unitIds=${encodeURIComponent(unitId)}`)
      .then(r => r.ok ? r.json() : null).catch(() => null)
      .then(d => {
        if (!d?.results?.length) return;
        const row = d.results[0];
        if (row.status === 'not_configured') return; // no token — leave hasToken=false
        setHasToken(true);
        const connected = row.status === 'connected';
        setWaConnected(connected);
        setWaInstanceInfo({
          configured: true,
          isConnected: connected,
          instanceId: row.instanceId || selectedContact.uazapi_instance_id || null,
          label: row.label || null,
          phoneNumber: row.phone || null,
          serverUrl: null,
          error: row.status === 'error' ? 'Erro ao verificar instância.' : null,
        });
      });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [splitMode, selectedContact]);

  // ── Close unit dropdown on outside click ─────────────────────────────────
  useEffect(() => {
    if (!unitDropdownOpen) return;
    const handler = (e: MouseEvent) => {
      if (unitDropdownRef.current && !unitDropdownRef.current.contains(e.target as Node)) {
        setUnitDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [unitDropdownOpen]);

  // ── Close filter dropdown on outside click ────────────────────────────────
  useEffect(() => {
    if (!filterDropdownOpen) return;
    const handler = (e: MouseEvent) => {
      if (filterDropdownRef.current && !filterDropdownRef.current.contains(e.target as Node)) {
        setFilterDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, [filterDropdownOpen]);

  // ── Init linked client state when selected contact changes (#198) ────────
  // Also fetch appointments by prospection_contact_id (primary) OR client_id (fallback).
  const fetchContactAppointments = useCallback((contactId: string, clientId: string | null) => {
    setLoadingApptSection(true);
    const qs = new URLSearchParams();
    qs.set('prospection_contact_id', contactId);
    if (clientId) qs.set('client_id', clientId);
    qs.set('limit', '20');
    fetch(`/api/appointments?${qs.toString()}`)
      .then(r => r.ok ? r.json() : null)
      .then(d => {
        if (d) {
          // Deduplicate by ID — prevents double-entries when optimistic update + re-fetch overlap
          const rows: any[] = d.data || [];
          const seen = new Set<string>();
          const unique = rows.filter(a => { if (seen.has(a.id)) return false; seen.add(a.id); return true; });
          setContactAppointments(unique);
        }
      })
      .catch(() => {})
      .finally(() => setLoadingApptSection(false));
  }, []);

  useEffect(() => {
    if (!selectedContact) {
      setLinkedClientId(null);
      setLinkedClientName(null);
      setContactAppointments([]);
      setApptSectionOpen(false);
      return;
    }
    const cid = selectedContact.client_id || null;
    const cname = selectedContact.client_name_linked || null;
    setLinkedClientId(cid);
    setLinkedClientName(cname);
    setContactAppointments([]);
    setApptSectionOpen(false);
    // Always fetch by prospection_contact_id so we find appointments even before client is linked
    setLoadingApptSection(true);
    fetchContactAppointments(selectedContact.id, cid);
  }, [selectedContact?.id, fetchContactAppointments]);

  // ── Handlers for quick client registration + scheduling (#198) ───────────
  const handleClientCreated = useCallback(async (clientId: string, name: string) => {
    setShowClientModal(false);
    if (selectedContact) {
      try {
        const patchRes = await fetch(`/api/prospection/contacts/${selectedContact.id}`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ client_id: clientId }),
        });
        if (!patchRes.ok) {
          const errData = await patchRes.json().catch(() => ({}));
          addToast('error', 'Erro ao vincular', errData?.error || `Falha ao salvar vínculo (HTTP ${patchRes.status})`);
          // Do NOT update local state — DB wasn't updated, re-fetch would revert anyway
          return;
        }
        // PATCH succeeded — commit local state so UI is immediately consistent
        setLinkedClientId(clientId);
        setLinkedClientName(name);
        const updated = { ...selectedContact, client_id: clientId, client_name_linked: name };
        setContacts(prev => prev.map(c => c.id === selectedContact.id ? updated : c));
        setSelectedContact(updated);
        // Re-fetch appointments from DB using both prospection_contact_id and new clientId
        fetchContactAppointments(selectedContact.id, clientId);
        addToast('success', 'Cliente vinculado', `${name} vinculado com sucesso.`);
      } catch (err: any) {
        addToast('error', 'Erro ao vincular', err?.message || 'Falha de rede ao salvar vínculo.');
      }
    }
  }, [selectedContact, addToast, fetchContactAppointments]);

  // ── Handlers "Trocar canal" (Task #240 + #243 + #248) ───────────────────
  const openCanalModal = useCallback(async () => {
    if (!selectedContact) return;
    const currentSource = (selectedContact.last_source ?? selectedContact.source) as 'gotalk' | 'uazapi';
    setCanalNewSource(currentSource);
    // uazapi_instance_id dual-purpose: only relevant as uazapi instance when source=uazapi
    setCanalNewInstanceId(selectedContact.last_source !== 'gotalk' ? (selectedContact.uazapi_instance_id || '') : '');
    setCanalInstances([]);
    setCanalUazapiUnits([]);
    setShowCanalModal(true);

    // Pre-select GoTalk channel: use saved channel UUID (stored in uazapi_instance_id when
    // last_source=gotalk), fall back to unit primary channel, then to any active channel.
    {
      const savedChId = selectedContact.last_source === 'gotalk'
        ? (selectedContact.uazapi_instance_id || '') : '';
      if (savedChId) {
        setCanalNewGotalkChannelId(savedChId);
      } else {
        const unitChs = selectedContact.unit_id
          ? (unitChannelMap.get(selectedContact.unit_id) || [])
          : [];
        const fallbackChs = unitChs.length > 0 ? unitChs : gotalkChannels;
        const primary = fallbackChs.find(c => c.is_primary) || fallbackChs[0] || null;
        setCanalNewGotalkChannelId(primary?.id || '');
      }
    }

    // Task #248: load ALL units with uazapi credentials (not just the contact's unit)
    // so the user can choose any unit when switching to uazapi.
    setCanalInstancesLoading(true);
    try {
      const r = await fetch('/api/units/uazapi-instances-all');
      if (r.ok) {
        const d = await r.json();
        const units: UazapiUnitOpt[] = d.units || [];
        setCanalUazapiUnits(units);

        // Pre-select priority (Task #251):
        // 1. Saved uazapi_unit_id on the contact (explicit DB preference)
        //    — contact.unit_id intentionally not used (it's the contact's assigned unit,
        //      not a channel preference, and must not override the user's own unit).
        // 2. Logged-in user's own unit — detected via:
        //    a. is_current_unit flag returned by backend (authoritative), OR
        //    b. loggedUser.currentUnitId match in frontend (secondary check)
        // 3. First unit in list — only for non-admin operators who have no matching unit
        // 4. null — admins without a saved preference see an empty dropdown
        const savedUazapiUnitId = selectedContact.uazapi_unit_id || '';
        const currentUserUnitId = loggedUser?.currentUnitId || '';
        const isAdmin = loggedUser?.role === 'ADMIN';
        const matchedUnit = (savedUazapiUnitId ? units.find(u => u.unit_id === savedUazapiUnitId) : null)
          || units.find(u => u.is_current_unit || (!!currentUserUnitId && u.unit_id === currentUserUnitId))
          || (!isAdmin ? (units[0] || null) : null);
        const selectedUnitId = matchedUnit?.unit_id || '';
        setCanalNewUazapiUnitId(selectedUnitId);

        // Pre-select instance within that unit
        const unitInsts = matchedUnit?.instances || [];
        setCanalInstances(unitInsts);
        const savedInst = selectedContact.last_source !== 'gotalk' ? (selectedContact.uazapi_instance_id || '') : '';
        const matchedInst = unitInsts.find(i => i.instanceId === savedInst)?.instanceId
          || unitInsts[0]?.instanceId || '';
        setCanalNewInstanceId(matchedInst);
      }
    } catch { /* ignore */ }
    setCanalInstancesLoading(false);
  }, [selectedContact, unitChannelMap, gotalkChannels, loggedUser]);

  const handleSaveCanalChange = useCallback(async () => {
    if (!selectedContact) return;
    setCanalSaving(true);
    try {
      // uazapi_instance_id dual-purpose: stores uazapi instance when source=uazapi,
      // or GoTalk channel UUID when source=gotalk (no schema change needed).
      const body: Record<string, string | null> = { last_source: canalNewSource };
      body.uazapi_instance_id = canalNewSource === 'uazapi'
        ? (canalNewInstanceId || null)
        : (canalNewSource === 'gotalk' ? (canalNewGotalkChannelId || null) : null);
      // Task #248: persist the uazapi unit used to contact this prospect
      body.uazapi_unit_id = canalNewSource === 'uazapi' ? (canalNewUazapiUnitId || null) : null;

      const r = await fetch(`/api/prospection/contacts/${encodeURIComponent(selectedContact.id)}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!r.ok) {
        const d = await r.json().catch(() => ({}));
        addToast('error', 'Erro ao trocar canal', d?.error || `HTTP ${r.status}`);
        return;
      }
      // uazapi_instance_id stores the relevant ID for the selected source:
      // uazapi → instance id; gotalk → channel UUID
      const newInstanceId = canalNewSource === 'uazapi'
        ? (canalNewInstanceId || null)
        : (canalNewSource === 'gotalk' ? (canalNewGotalkChannelId || null) : null);
      const newUazapiUnitId = canalNewSource === 'uazapi' ? (canalNewUazapiUnitId || null) : null;
      const updated: typeof selectedContact = {
        ...selectedContact,
        last_source: canalNewSource,
        uazapi_instance_id: newInstanceId,
        uazapi_unit_id: newUazapiUnitId,
      };
      setSelectedContact(updated);
      setContacts(prev => prev.map(c => c.id === selectedContact.id ? updated : c));
      const gtChannel = canalNewSource === 'gotalk' && canalNewGotalkChannelId
        ? gotalkChannels.find(c => c.id === canalNewGotalkChannelId) : null;
      const uazapiUnitName = canalNewSource === 'uazapi'
        ? (canalUazapiUnits.find(u => u.unit_id === canalNewUazapiUnitId)?.unit_name || 'WhatsApp (uazapi)')
        : '';
      const chanLabel = canalNewSource === 'uazapi'
        ? uazapiUnitName
        : gtChannel ? `GoTalk — ${gtChannel.name}` : 'GoTalk';
      addToast('success', 'Canal atualizado', `Canal alterado para ${chanLabel}.`);
      setShowCanalModal(false);

      // Sync composerChannel with the newly saved canal so send routing
      // uses the explicitly chosen channel immediately (no page reload needed)
      setComposerChannel({
        source: canalNewSource as 'gotalk' | 'uazapi',
        gotalkChannelId: canalNewSource === 'gotalk' ? (canalNewGotalkChannelId || '') : '',
        uazapiInstanceId: canalNewSource === 'uazapi' ? (newInstanceId || '') : '',
        uazapiUnitId: canalNewSource === 'uazapi' ? (newUazapiUnitId || '') : '',
      });

      // Re-check send capability and uazapi connection status so banners
      // and the composer reflect the new channel immediately (no reload needed).
      // Task #248: use the newly selected uazapi unit (not the contact's GoTalk unit_id).
      const effectiveUnitId = canalNewSource === 'uazapi'
        ? (newUazapiUnitId || selectedContact.unit_id)
        : selectedContact.unit_id;
      if (effectiveUnitId) {
        fetch(`/api/units/${encodeURIComponent(effectiveUnitId)}/uazapi-send-capability`)
          .then(r => r.ok ? r.json() : null).catch(() => null)
          .then(capData => {
            const hasTokenNow = Boolean(capData?.hasToken);
            setHasToken(hasTokenNow);
            if (hasTokenNow && canalNewSource === 'uazapi') {
              const statusUrl = `/api/uazapi/status?unitId=${encodeURIComponent(effectiveUnitId)}${newInstanceId ? `&instanceId=${encodeURIComponent(newInstanceId)}` : ''}`;
              fetch(statusUrl).then(r => r.ok ? r.json() : null).catch(() => null)
                .then(d => {
                  if (!d) return;
                  setWaConnected(Boolean(d.isConnected));
                  setWaInstanceInfo({
                    configured: d.configured ?? true,
                    isConnected: Boolean(d.isConnected),
                    instanceId: d.instanceId || newInstanceId || null,
                    label: d.label || null,
                    phoneNumber: d.phoneNumber || null,
                    serverUrl: d.serverUrl || null,
                    error: d.error || null,
                  });
                });
            } else if (canalNewSource === 'gotalk') {
              // Switch away from uazapi — clear uazapi-specific state
              setWaConnected(null);
              setWaInstanceInfo(null);
            }
          });
      }
    } catch (err: any) {
      addToast('error', 'Erro ao trocar canal', err?.message || 'Falha de rede.');
    } finally {
      setCanalSaving(false);
    }
  }, [selectedContact, canalNewSource, canalNewInstanceId, canalNewGotalkChannelId, canalNewUazapiUnitId, canalUazapiUnits, gotalkChannels, addToast]);

  // ── Instance selector: switch active uazapi instance in-session (Task #289) ─
  const handleSelectInstance = useCallback((instanceId: string) => {
    const unitId = composerChannel?.uazapiUnitId || '';
    setComposerChannel(prev => prev ? { ...prev, uazapiInstanceId: instanceId } : prev);
    const inst = unitUazapiInstances.find(i => i.instanceId === instanceId);
    if (inst?.isConnected !== null && inst?.isConnected !== undefined) {
      setWaConnected(inst.isConnected);
      setWaInstanceInfo(prev => ({
        configured: true,
        isConnected: inst.isConnected!,
        instanceId: instanceId,
        label: inst.label,
        phoneNumber: inst.phoneNumber ?? null,
        serverUrl: prev?.serverUrl || null,
        error: null,
      }));
    } else {
      setWaConnected(null);
      if (unitId) {
        fetch(`/api/uazapi/status?unitId=${encodeURIComponent(unitId)}&instanceId=${encodeURIComponent(instanceId)}`)
          .then(r => r.ok ? r.json() : null)
          .then(d => {
            if (!d) return;
            setWaConnected(Boolean(d.isConnected));
            setWaInstanceInfo({
              configured: d.configured ?? true,
              isConnected: Boolean(d.isConnected),
              instanceId: d.instanceId || instanceId,
              label: d.label || inst?.label || null,
              phoneNumber: d.phoneNumber || null,
              serverUrl: d.serverUrl || null,
              error: d.error || null,
            });
            setUnitUazapiInstances(prev =>
              prev.map(i => i.instanceId === instanceId ? { ...i, isConnected: Boolean(d.isConnected) } : i)
            );
          })
          .catch(() => setWaConnected(null));
      }
    }
  }, [composerChannel, unitUazapiInstances]);

  const handleAppointmentSaved = useCallback((appt: any) => {
    const wasEditing = Boolean(editingAppt);
    const before = wasEditing ? { ...editingAppt } : null;

    setShowAgendamentoModal(false);
    setEditingAppt(null);

    if (wasEditing) {
      // Update existing entry in the list
      setContactAppointments(prev => prev.map(a => a.id === appt.id ? { ...a, ...appt } : a));
      addToast('success', 'Agendamento alterado', 'As informações foram salvas com sucesso.');
      logTransaction('AGENDA', appt.id, before, appt);
    } else {
      // Prepend new entry
      setContactAppointments(prev => [appt, ...prev]);
      addToast('success', 'Agendado', 'Agendamento criado com sucesso.');
      logTransaction('AGENDA', appt.id, null, appt);
    }

    setApptSectionOpen(true);
    // Re-fetch from DB after a brief delay (allow server to commit)
    if (selectedContact) {
      setTimeout(() => fetchContactAppointments(selectedContact.id, selectedContact.client_id || null), 800);
    }
  }, [addToast, editingAppt, logTransaction, selectedContact, fetchContactAppointments]);

  const handleCancelAppointment = useCallback(async (appt: any) => {
    setCancellingApptLoading(true);
    const before = { ...appt };
    try {
      const res = await fetch(`/api/appointments/${appt.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...appt,
          status: 'CANCELADO_CLIENTE',
        }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData?.error || `Erro HTTP ${res.status}`);
      }
      const after = { ...appt, status: 'CANCELADO_CLIENTE' };
      setContactAppointments(prev => prev.map(a => a.id === appt.id ? after : a));
      setCancellingApptId(null);
      addToast('success', 'Agendamento cancelado', 'O status foi atualizado para Cancelado.');
      logTransaction('AGENDA', appt.id, before, after);
    } catch (err: any) {
      addToast('error', 'Erro ao cancelar', err?.message || 'Falha ao cancelar agendamento.');
    } finally {
      setCancellingApptLoading(false);
    }
  }, [addToast, logTransaction]);

  // ── Load filter options + GoTalk channels + GoTalk operators once on mount ─
  useEffect(() => {
    Promise.allSettled([
      fetch('/api/prospection/filter-options').then(r => r.ok ? r.json() : null),
      fetch('/api/gotalk/channels').then(r => r.ok ? r.json() : null),
      fetch('/api/gotalk/messages/operators').then(r => r.ok ? r.json() : null),
    ]).then(([filterRes, channelsRes, operatorsRes]) => {
      // Filter options (units + CRM collaborators)
      const filterData = filterRes.status === 'fulfilled' ? filterRes.value : null;
      if (filterData) {
        const units: { id: string; name: string }[] = filterData.units || [];
        setFilterUnits(units);
        // Task #312: restaura seleção de unidades persistida (interseção com as permitidas).
        let restored: string[] | null = null;
        try {
          const raw = localStorage.getItem('prospeccao:selectedUnitIds');
          if (raw) {
            const ids = JSON.parse(raw);
            if (Array.isArray(ids)) {
              const valid = ids.filter((id: string) => units.some(u => u.id === id));
              if (valid.length > 0) restored = valid;
            }
          }
        } catch { /* ignore corrupt value */ }
        setSelectedUnitIds(restored || units.map(u => u.id));

        // Merge CRM collaborators with GoTalk-only operator names
        const crmOperators: { id: string; name: string }[] = filterData.operators || [];
        const gotalkData = operatorsRes.status === 'fulfilled' ? operatorsRes.value : null;
        const gotalkNames: string[] = gotalkData?.data || [];
        const existingNames = new Set(crmOperators.map(op => op.name.toLowerCase()));
        const extraOperators = gotalkNames
          .filter(n => n && !existingNames.has(n.toLowerCase()))
          .map(n => ({ id: `gotalk:${n}`, name: n }));
        const merged = [...crmOperators, ...extraOperators]
          .sort((a, b) => a.name.localeCompare(b.name, 'pt-BR'));
        setFilterOperators(merged);
      }

      // GoTalk channels (active only) for unit→channel mapping
      const channelsData = channelsRes.status === 'fulfilled' ? channelsRes.value : null;
      if (channelsData?.channels) {
        setGotalkChannels((channelsData.channels as GotalkChannel[]).filter(c => c.is_active !== false));
        setGotalkChannelsError(false);
      } else if (channelsRes.status === 'rejected' || (channelsRes.status === 'fulfilled' && !channelsRes.value)) {
        setGotalkChannelsError(true);
      }
    });
  }, []);

  // ── Fetch uazapi instance statuses for all accessible units ──────────────
  const fetchUnitInstances = useCallback(async (units: { id: string; name: string }[]) => {
    if (units.length === 0) return;
    setInstancesLoading(true);
    try {
      const results = await Promise.allSettled(
        units.map(u =>
          fetch(`/api/uazapi/status?unitId=${encodeURIComponent(u.id)}`)
            .then(r => r.ok ? r.json() : null)
            .then(d => {
              if (!d) return [];
              // Single instance response vs multi-instance
              const list: InstanceStatus[] = [];
              const arr = Array.isArray(d.instances) ? d.instances : [d];
              for (const inst of arr) {
                if (!inst.instanceId) continue;
                list.push({
                  unitId: u.id,
                  unitName: u.name,
                  instanceId: inst.instanceId,
                  label: inst.label || null,
                  phoneNumber: inst.phoneNumber || null,
                  isConnected: Boolean(inst.isConnected),
                  error: inst.error || null,
                });
              }
              return list;
            })
            .catch(() => [] as InstanceStatus[])
        )
      );
      const all: InstanceStatus[] = results.flatMap(r => r.status === 'fulfilled' ? r.value : []);
      setUnitInstances(all);
    } finally {
      setInstancesLoading(false);
    }
  }, []);

  useEffect(() => {
    if (filterUnits.length > 0) fetchUnitInstances(filterUnits);
  }, [filterUnits, fetchUnitInstances]);

  // ── Reset selected contact when unit selection changes ────────────────────
  useEffect(() => {
    setSelectedContact(null);
    setTimelineMsgs([]);
    setHistory([]);
    setActiveConvId(null);
  }, [selectedUnitIds]);

  // Task #312: persiste a seleção de unidades (somente após o init popular filterUnits).
  useEffect(() => {
    if (filterUnits.length === 0) return;
    try {
      if (selectedUnitIds.length === filterUnits.length) {
        localStorage.removeItem('prospeccao:selectedUnitIds');
      } else {
        localStorage.setItem('prospeccao:selectedUnitIds', JSON.stringify(selectedUnitIds));
      }
    } catch { /* ignore quota errors */ }
  }, [selectedUnitIds, filterUnits.length]);

  // Task #312: mapa instanceId → número real, agregando todas as fontes carregadas,
  // para exibir o número usado em cada mensagem uazapi da timeline.
  const instancePhoneMap = useMemo(() => {
    const m = new Map<string, string>();
    for (const i of unitInstances) {
      if (i.instanceId && i.phoneNumber) m.set(i.instanceId, i.phoneNumber);
    }
    for (const i of unitUazapiInstances) {
      if (i.instanceId && i.phoneNumber) m.set(i.instanceId, i.phoneNumber);
    }
    if (waInstanceInfo?.instanceId && waInstanceInfo.phoneNumber) {
      m.set(waInstanceInfo.instanceId, waInstanceInfo.phoneNumber);
    }
    return m;
  }, [unitInstances, unitUazapiInstances, waInstanceInfo]);

  // ── Fetch contacts ────────────────────────────────────────────────────────
  const fetchContacts = useCallback(async (page: number) => {
    setLoadingContacts(true);
    try {
      const qs = new URLSearchParams();
      qs.set('page', String(page));
      qs.set('limit', '50');
      if (search.trim()) qs.set('search', search.trim());
      if (fClassification) qs.set('classification', fClassification);
      if (fPeriod) qs.set('period', fPeriod);
      // Multi-unit: only send unitIds if it's a partial selection (backend applies JWT filter otherwise)
      if (selectedUnitIds.length > 0 && selectedUnitIds.length < filterUnits.length) {
        qs.set('unitIds', selectedUnitIds.join(','));
      }
      if (fOperator) {
        if (fOperator.startsWith('gotalk:')) {
          // GoTalk-only operator: send name for ILIKE filter on operator_name_linked
          qs.set('operatorName', fOperator.slice('gotalk:'.length));
        } else {
          qs.set('operatorId', fOperator);
        }
      }
      if (fSource) qs.set('source', fSource);
      if (fHasAppointment) qs.set('hasAppointment', '1');
      const res = await fetch(`/api/prospection/contacts?${qs.toString()}`);
      if (!res.ok) return;
      const data = await res.json();
      const fetched: ProspectionContact[] = data.contacts || [];
      setContacts(fetched);
      setContactsTotal(data.total || 0);
      setContactsPage(data.page || page);
      setContactsTotalPages(data.totalPages || 1);
      // Task #300: ressincronizar waUnread com o estado autoritativo do servidor
      // a cada fetch (refresh manual, filtro, paginação) — corrige drift entre
      // contadores reais e estado local atualizado por socket. Preserva entradas
      // de telefones que não vieram na página atual (não derruba badges de
      // contatos fora do recorte) e zera apenas as que o servidor confirmou.
      setWaUnread(prev => {
        const next = { ...prev };
        for (const c of fetched) {
          const k = String(c.phone).replace(/\D/g, '');
          const serverTotal = c.unread_count || 0;
          const cur = next[k] || { gotalk: 0, uazapi: 0 };
          const localTotal = cur.gotalk + cur.uazapi;
          if (serverTotal !== localTotal) {
            // Reset preservando proporção quando possível; se total local era 0,
            // joga tudo em 'gotalk' (provedor majoritário no histórico).
            if (serverTotal === 0) {
              next[k] = { gotalk: 0, uazapi: 0 };
            } else if (localTotal > 0) {
              const ratioGt = cur.gotalk / localTotal;
              const gt = Math.round(serverTotal * ratioGt);
              next[k] = { gotalk: gt, uazapi: serverTotal - gt };
            } else {
              next[k] = { gotalk: serverTotal, uazapi: 0 };
            }
          }
        }
        return next;
      });
    } catch { /* silent */ }
    finally { setLoadingContacts(false); }
  }, [search, fClassification, fPeriod, selectedUnitIds, fOperator, fSource, fHasAppointment, filterUnits.length]);

  useEffect(() => {
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current);
    searchTimerRef.current = setTimeout(() => fetchContacts(1), 400);
    return () => { if (searchTimerRef.current) clearTimeout(searchTimerRef.current); };
  }, [search, fClassification, fPeriod, selectedUnitIds, fOperator, fSource, fHasAppointment]);

  // ── WhatsApp toast notifications and per-contact unread badge ────────────
  const [waToasts, setWaToasts] = useState<MessageToastItem[]>([]);
  // Per-provider unread: phone → { gotalk: n, uazapi: n }
  const [waUnread, setWaUnread] = useState<Record<string, { gotalk: number; uazapi: number }>>({});

  // ── Hydrate unread badges from DB on mount ────────────────────────────────
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/prospection/unread-counts');
        if (!res.ok || cancelled) return;
        const data: { counts: Record<string, { gotalk: number; uazapi: number }>; total: number } = await res.json();
        if (cancelled || data.total <= 0) return;
        setWaUnread(data.counts);
        incProspeccaoUnread(data.total);
      } catch { /* silent */ }
    })();
    return () => { cancelled = true; };
  }, [incProspeccaoUnread]);

  // ── Real-time updates via Socket.io ──────────────────────────────────────
  const refreshRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const ackRefreshRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const selectedContactRef = useRef<ProspectionContact | null>(null);
  const contactsRef = useRef<ProspectionContact[]>([]);
  useEffect(() => { selectedContactRef.current = selectedContact; }, [selectedContact]);
  useEffect(() => { contactsRef.current = contacts; }, [contacts]);

  const refreshTimeline = useCallback(async (phone: string) => {
    // Atualização em tempo real: busca as 500 mais recentes (order=desc) e mescla
    // com o que já está carregado, preservando lotes anteriores carregados pelo
    // botão "Carregar mais" e evitando duplicatas.
    const r = await fetch(`/api/gotalk/client-timeline?phone=${encodeURIComponent(phone)}&limit=500&order=desc`).catch(() => null);
    if (r?.ok) {
      const d = await r.json();
      const incoming: TimelineMsg[] = d.messages || [];
      setTimelineMsgs(prev => mergeTimelineMsgs(prev, incoming));
      if (typeof d.total === 'number') setTimelineTotal(d.total);
      setOlderLoaded(prev => Math.max(prev, incoming.length));
      // Não substitua timelineNextCursor: ele marca a fronteira mais antiga já
      // carregada, enquanto esta atualização busca somente as mensagens recentes.
      setTimeout(() => timelineEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
    }
  }, []);

  // Carrega o próximo lote de 500 mensagens ANTERIORES a partir do cursor estável,
  // mescla sem duplicar e preserva a posição de rolagem (mensagens entram no topo).
  const loadOlderTimeline = useCallback(async () => {
    const contact = selectedContactRef.current;
    if (!contact || !timelineNextCursor || loadingMoreTimeline) return;
    setLoadingMoreTimeline(true);
    const scroller = timelineScrollRef.current;
    const prevHeight = scroller?.scrollHeight ?? 0;
    const prevTop = scroller?.scrollTop ?? 0;
    try {
      const r = await fetch(
        `/api/gotalk/client-timeline?phone=${encodeURIComponent(contact.phone)}&limit=500&order=desc&direction=next&cursor=${encodeURIComponent(timelineNextCursor)}`
      ).catch(() => null);
      if (r?.ok) {
        const d = await r.json();
        const older: TimelineMsg[] = d.messages || [];
        setTimelineNextCursor(typeof d.next_cursor === 'string' ? d.next_cursor : null);
        if (older.length) {
          setTimelineMsgs(prev => mergeTimelineMsgs(prev, older));
          setOlderLoaded(prev => prev + older.length);
        }
        if (typeof d.total === 'number') setTimelineTotal(d.total);
        // Restaura a posição de rolagem após o prepend dos itens mais antigos.
        requestAnimationFrame(() => {
          if (scroller) scroller.scrollTop = scroller.scrollHeight - prevHeight + prevTop;
        });
      }
    } finally {
      setLoadingMoreTimeline(false);
    }
  }, [timelineNextCursor, loadingMoreTimeline]);

  const hasMoreOlderTimeline = Boolean(timelineNextCursor) && olderLoaded < timelineTotal;

  useEffect(() => {
    if (!socket) return;

    const onNewMsg = (payload?: { phone?: string; direction?: string; body?: string | null; source?: string; uazapiInstanceId?: string | null }) => {
      // Task #294 — Instance-lock: when an inbound uazapi reply arrives for the
      // open contact via a different instance than the composer is currently
      // pointing to, snap the composer to that instance so the next outbound
      // message goes back through the same WhatsApp number the user replied on.
      // Also persist last_inbound_instance_id to the DB so the lock survives
      // page reloads and is visible to other operators.
      if (
        payload?.source === 'uazapi' &&
        payload?.direction === 'IN' &&
        payload?.uazapiInstanceId
      ) {
        const cur = selectedContactRef.current;
        if (cur && payload.phone) {
          const a = String(cur.phone).replace(/\D/g, '').slice(-8);
          const b = String(payload.phone).replace(/\D/g, '').slice(-8);
          if (a && b && a === b) {
            const inboundInst = payload.uazapiInstanceId;
            setComposerChannel(prev => prev && prev.source === 'uazapi' && prev.uazapiInstanceId !== inboundInst
              ? { ...prev, uazapiInstanceId: inboundInst } : prev);
            setSelectedContact(prev => prev && prev.id === cur.id
              ? { ...prev, last_inbound_instance_id: inboundInst, uazapi_instance_id: inboundInst } : prev);
            setContacts(prev => prev.map(c => c.id === cur.id
              ? { ...c, last_inbound_instance_id: inboundInst, uazapi_instance_id: inboundInst } : c));
            // Persist server-side so the lock survives reloads / other sessions.
            // Fire-and-forget — the webhook already wrote it on the server; this
            // PATCH is mostly to keep last_inbound_instance_id explicit and audit-trackable.
            fetch(`/api/prospection/contacts/${encodeURIComponent(cur.id)}`, {
              method: 'PATCH',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ last_inbound_instance_id: inboundInst, uazapi_instance_id: inboundInst }),
            }).catch(() => {});
          }
        }
      }

      // Refresh contact list (debounced)
      if (refreshRef.current) clearTimeout(refreshRef.current);
      refreshRef.current = setTimeout(() => fetchContacts(1), 1000);

      const current = selectedContactRef.current;

      // Use last 8 digits for robust comparison — handles Brazilian "9th digit"
      // ambiguity where uazapi strips the 9 (e.g. 81981071630 → 8181071630).
      // Last 8 digits (local number without 9) are invariant across both formats.
      const msgPhone = payload?.phone ? String(payload.phone).replace(/\D/g, '') : '';
      const msgPhoneLast8 = msgPhone.slice(-8);

      if (current && msgPhoneLast8) {
        const selPhone = String(current.phone).replace(/\D/g, '');
        const selPhoneLast8 = selPhone.slice(-8);
        const isCurrentContact = msgPhoneLast8 === selPhoneLast8;
        if (isCurrentContact) {
          // Timeline is already open — refresh it so the new message appears immediately
          // (handles both IN from contact and OUT sent from the real phone app).
          // Skip toast and unread badge: the user is already watching this conversation.
          refreshTimeline(current.phone);
          return;
        }
      }

      // Defensive fallback: payload without phone (e.g. recovery job batch emit).
      // If a contact is currently selected, refresh its timeline — the batch may
      // have recovered messages for this exact contact.
      if (!msgPhoneLast8 && current) {
        refreshTimeline(current.phone);
        return;
      }

      // Unread badge + toast for confirmed inbound messages not currently open
      if (msgPhoneLast8 && payload?.direction === 'IN') {
        // Always increment global badge for any inbound message (even if contact is outside
        // current page/filter), so the sidebar count reflects all new messages.
        incProspeccaoUnread();

        const contactInList = contactsRef.current.find(c => {
          const p = String(c.phone).replace(/\D/g, '').slice(-8);
          return p === msgPhoneLast8;
        });
        if (contactInList) {
          // Use canonical contact phone as key so increment/decrement/render always match
          const canonicalPhone = String(contactInList.phone).replace(/\D/g, '');
          // Track unread count per provider so contact cards show separate badges
          const msgSrc: 'gotalk' | 'uazapi' = (payload as { source?: string })?.source === 'uazapi' ? 'uazapi' : 'gotalk';
          setWaUnread(prev => {
            const cur = prev[canonicalPhone] || { gotalk: 0, uazapi: 0 };
            return { ...prev, [canonicalPhone]: { ...cur, [msgSrc]: cur[msgSrc] + 1 } };
          });

          const name = contactInList.contact_name || contactInList.client_name_linked || contactInList.phone;
          const toastId = `wa-${Date.now()}-${Math.random().toString(36).slice(2)}`;

          // Use body from socket payload directly (included since the server fix).
          // Fall back to an HTTP fetch only when body is absent (older server version).
          const bodyFromPayload = payload?.body ? String(payload.body).slice(0, 80) : null;

          if (bodyFromPayload !== null) {
            setWaToasts(prev => [...prev.slice(-2), {
              id: toastId,
              senderName: name,
              senderInitials: (name[0] || '?').toUpperCase(),
              body: bodyFromPayload || 'Nova mensagem WhatsApp',
              createdAt: new Date().toISOString(),
              type: 'whatsapp',
              conversationId: contactInList.id,
            }]);
          } else {
            // Legacy fallback: fetch the most recent message body for the toast preview
            let preview = 'Nova mensagem WhatsApp';
            fetch(`/api/gotalk/client-timeline?phone=${encodeURIComponent(contactInList.phone)}&limit=1`)
              .then(r => r.ok ? r.json() : null)
              .then(d => {
                const lastBody = d?.messages?.[0]?.body;
                if (lastBody) preview = String(lastBody).slice(0, 80);
                setWaToasts(prev => [...prev.slice(-2), {
                  id: toastId,
                  senderName: name,
                  senderInitials: (name[0] || '?').toUpperCase(),
                  body: preview,
                  createdAt: new Date().toISOString(),
                  type: 'whatsapp',
                  conversationId: contactInList.id,
                }]);
              })
              .catch(() => {
                setWaToasts(prev => [...prev.slice(-2), {
                  id: toastId,
                  senderName: name,
                  senderInitials: (name[0] || '?').toUpperCase(),
                  body: preview,
                  createdAt: new Date().toISOString(),
                  type: 'whatsapp',
                  conversationId: contactInList.id,
                }]);
              });
          }
        }
      }
    };

    const onAckUpdate = (payload?: { messageId?: string; ack?: number; phone?: string }) => {
      if (!payload?.messageId || payload.ack === undefined) return;
      const current = selectedContactRef.current;
      if (!current) return;

      // Phone guard: only act if the ACK is for the currently-open conversation.
      // Accept even if payload.phone is absent (some uazapi versions omit it).
      if (payload.phone) {
        const msgPhone = String(payload.phone).replace(/\D/g, '');
        const selPhone = String(current.phone).replace(/\D/g, '');
        const msgLast8 = msgPhone.slice(-8);
        const selLast8 = selPhone.slice(-8);
        if (msgLast8 && selLast8 && msgLast8 !== selLast8) return;
      }

      // Surgical update: only mutate the single message that changed.
      // Source-safe: only GoTalk messages carry gotalk_message_id, so
      // uazapi messages are never mutated by this handler (split-mode safe).
      setTimelineMsgs(prev =>
        prev.map(m =>
          m.gotalk_message_id === payload.messageId
            ? { ...m, ack_status: payload.ack }
            : m
        )
      );
    };

    socket.on('gotalk:new_message', onNewMsg);
    socket.on('gotalk:ack_update', onAckUpdate);
    return () => {
      socket.off('gotalk:new_message', onNewMsg);
      socket.off('gotalk:ack_update', onAckUpdate);
      if (refreshRef.current) clearTimeout(refreshRef.current);
      if (ackRefreshRef.current) clearTimeout(ackRefreshRef.current);
    };
  }, [socket, fetchContacts, refreshTimeline, incProspeccaoUnread]);

  // ── Select contact: load timeline + history ──────────────────────────────
  // ── Fetch notes for a contact ────────────────────────────────────────────
  const fetchNotes = useCallback(async (contactId: string) => {
    setLoadingNotes(true);
    try {
      const r = await fetch(`/api/prospection/contacts/${contactId}/notes`);
      if (r.ok) {
        const d = await r.json();
        setNotes(d.notes || []);
      }
    } catch { /* silent */ }
    finally { setLoadingNotes(false); }
  }, []);

  const selectContact = useCallback(async (contact: ProspectionContact) => {
    // Clear per-contact chip and decrement global badge by that contact's unread count
    const contactPhone = String(contact.phone).replace(/\D/g, '');
    setWaUnread(prev => {
      const unreadData = prev[contactPhone];
      const contactCount = (unreadData?.gotalk ?? 0) + (unreadData?.uazapi ?? 0);
      if (contactCount > 0) decProspeccaoUnread(contactCount);
      const next = { ...prev };
      delete next[contactPhone];
      return next;
    });

    // Initialize explicit composer channel from contact's stored provider data
    const contactSrcForComposer = contact.last_source ?? contact.source;
    const compSrc = contactSrcForComposer === 'uazapi' ? 'uazapi' : 'gotalk';
    setComposerChannel({
      source: compSrc,
      gotalkChannelId: compSrc === 'gotalk' ? (contact.uazapi_instance_id || '') : '',
      // Task #294 — Instance-lock: prefer last_inbound_instance_id (instance that received
      // the most recent reply) so the next outbound goes back through that same number.
      uazapiInstanceId: compSrc === 'uazapi'
        ? (contact.last_inbound_instance_id || contact.uazapi_instance_id || '')
        : '',
      uazapiUnitId: compSrc === 'uazapi' ? (contact.uazapi_unit_id || contact.unit_id || '') : '',
    });
    // Mark messages as read in DB for both providers (gotalk_messages table)
    markGotalkConversationRead(contact.phone).catch(() => {});
    setSelectedContact(contact);
    setTimelineMsgs([]);
    setTimelineNextCursor(null);
    setHistory([]);
    setActiveConvId(null);
    setSendText('');
    setHasToken(false);
    setWaInfo(null);
    setWaAvatar(null);
    setWaOnWa(null);
    setWaConnected(null);
    setWaInstanceInfo(null);
    setUnitUazapiInstances([]);
    setGtProfile(null);
    setNotes([]);
    setNewNoteText('');
    setNewNoteAttachments([]);
    setEditingNoteId(null);
    fetchNotes(contact.id);
    setLoadingTimeline(true);

    // Fetch timeline + history + uazapi capability in parallel
    // Task #248: for uazapi contacts, use uazapi_unit_id (if set) instead of the GoTalk unit_id
    const contactSrc = contact.last_source ?? contact.source;
    const effectiveUazapiUnitId = contactSrc === 'uazapi'
      ? (contact.uazapi_unit_id || contact.unit_id)
      : contact.unit_id;

    // Task #272: Mini-sync de mensagens de hoje para contatos uazapi.
    // Fire-and-forget — o servidor processa em background via setImmediate e
    // emite gotalk:new_message via Socket.io se encontrar mensagens novas.
    // O painel já escuta esse evento e atualiza a timeline automaticamente.
    if (contactSrc === 'uazapi' && effectiveUazapiUnitId) {
      fetch('/api/uazapi/sync-contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone: contact.phone, unitId: effectiveUazapiUnitId }),
      }).catch(() => {});
    }

    const timelineP = fetch(`/api/gotalk/client-timeline?phone=${encodeURIComponent(contact.phone)}&limit=500&order=desc`)
      .then(r => r.ok ? r.json() : null).catch(() => null);

    const historyP = fetch(`/api/prospection/contacts/${encodeURIComponent(contact.phone)}/history`)
      .then(r => r.ok ? r.json() : null).catch(() => null);

    const capP = effectiveUazapiUnitId
      ? fetch(`/api/units/${encodeURIComponent(effectiveUazapiUnitId)}/uazapi-send-capability`)
          .then(r => r.ok ? r.json() : null).catch(() => null)
      : Promise.resolve(null);

    // Fetch all instances for multi-instance selector (uazapi contacts only)
    const instancesP = (contactSrc === 'uazapi' && effectiveUazapiUnitId)
      ? fetch(`/api/units/${encodeURIComponent(effectiveUazapiUnitId)}/uazapi-instances`)
          .then(r => r.ok ? r.json() : null)
          .then(d => (d?.instances as { instanceId: string; label: string | null }[]) || null)
          .catch(() => null)
      : Promise.resolve(null);

    try {
      const [timelineData, historyData, capData, instancesData] = await Promise.all([timelineP, historyP, capP, instancesP]);
      if (timelineData) {
        const msgs: TimelineMsg[] = timelineData.messages || [];
        setTimelineMsgs(msgs);
        setOlderLoaded(msgs.length);
        setTimelineNextCursor(typeof timelineData.next_cursor === 'string' ? timelineData.next_cursor : null);
        setTimelineTotal(typeof timelineData.total === 'number' ? timelineData.total : msgs.length);
      }
      if (historyData) {
        const convs: ProspectionConversation[] = historyData.conversations || [];
        setHistory(convs);
        // Use the most recent open conversation as active
        const openConv = convs.find(c => !c.end_at);
        if (openConv) {
          setActiveConvId(openConv.id);
        } else {
          // Create a new conversation record for this contact
          // Task #248: use effectiveUazapiUnitId so conversation unit matches the uazapi unit
          try {
            const newConvRes = await fetch('/api/prospection/conversations', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ phone: contact.phone, unitId: effectiveUazapiUnitId || contact.unit_id, source: contact.last_source ?? contact.source, instanceId: contact.uazapi_instance_id || undefined }),
            });
            if (newConvRes.ok) {
              const newConv = await newConvRes.json();
              setActiveConvId(newConv.conversation?.id || null);
            }
          } catch { /* best-effort */ }
        }
      }
      const hasTokenNow = Boolean(capData?.hasToken);
      if (capData) setHasToken(hasTokenNow);

      // Task #290: derive best-guess instance from most recent OUT uazapi message in timeline.
      // This is more accurate than prospection_contacts.uazapi_instance_id when an operator
      // switched instances mid-conversation — the last sent message is the source of truth.
      const allMsgs: TimelineMsg[] = timelineData?.messages || [];
      // Encontra a instância uazapi da última mensagem OUT. Ordena por sent_at desc
      // explicitamente para ser independente da ordem em que a API retornou.
      const lastOutUazapiInstanceId = [...allMsgs]
        .filter(m => m.source === 'uazapi' && m.direction === 'OUT' && m.uazapi_instance_id)
        .sort((a, b) => new Date(b.sent_at || 0).getTime() - new Date(a.sent_at || 0).getTime())[0]
        ?.uazapi_instance_id ?? null;

      // Multi-instance selector: populate when uazapi contact has >1 instance (Task #289)
      const rawInstances = instancesData || [];
      const contactId = contact.id;
      if (contactSrc === 'uazapi' && rawInstances.length > 1 && effectiveUazapiUnitId) {
        // Set initial list without status (filled in by single-call below)
        setUnitUazapiInstances(rawInstances.map(i => ({ instanceId: i.instanceId, label: i.label, isConnected: null, phoneNumber: i.phoneNumber ?? null })));
        // Auto-select: prefer instance of last OUT message (Task #290), then contact's stored
        // instance, then first in list. Validate the chosen id is still in the active list.
        const preferredRaw = lastOutUazapiInstanceId || contact.uazapi_instance_id;
        const preferredIsActive = Boolean(preferredRaw && rawInstances.some(i => i.instanceId === preferredRaw));
        const preferredId = (preferredIsActive ? preferredRaw! : null) || rawInstances[0].instanceId;
        setComposerChannel(prev => prev ? { ...prev, uazapiInstanceId: preferredId } : prev);
        // Single status call — /api/uazapi/status without instanceId returns { instances: [...] }
        // for all instances of the unit, avoiding N separate round-trips.
        const unitIdForStatus = effectiveUazapiUnitId;
        fetch(`/api/uazapi/status?unitId=${encodeURIComponent(unitIdForStatus)}`)
          .then(r => r.ok ? r.json() : null).catch(() => null)
          .then(d => {
            if (!d || selectedContactRef.current?.id !== contactId) return;
            // Server returns { instances: [...] } for multi-instance units
            type StatusEntry = { instanceId?: string; isConnected?: boolean; label?: string | null; phoneNumber?: string | null; error?: string | null };
            const statusList: StatusEntry[] = Array.isArray(d.instances) ? d.instances : [d];
            const withStatus: UazapiInstanceOption[] = rawInstances.map(inst => {
              const found = statusList.find(s => s.instanceId === inst.instanceId);
              return { instanceId: inst.instanceId, label: found?.label ?? inst.label, isConnected: found ? Boolean(found.isConnected) : null, phoneNumber: found?.phoneNumber ?? inst.phoneNumber ?? null };
            });
            setUnitUazapiInstances(withStatus);
            // Sync waConnected / waInstanceInfo for the selected (preferred) instance
            const preferredData = statusList.find(s => s.instanceId === preferredId);
            if (preferredData) {
              setWaConnected(Boolean(preferredData.isConnected));
              setWaInstanceInfo({
                configured: true,
                isConnected: Boolean(preferredData.isConnected),
                instanceId: preferredId,
                label: preferredData.label ?? null,
                phoneNumber: preferredData.phoneNumber ?? null,
                serverUrl: null,
                error: preferredData.error ?? null,
              });
            }
          });
      }

      // Check uazapi connection status (#189) — runs after we know hasToken
      // Task #248: use effectiveUazapiUnitId (uazapi_unit_id if set, else unit_id)
      // Task #286: also check when split mode is active (GoTalk contacts need uazapi status for the right column)
      // Task #289: skip individual status fetch when multi-instance batch above already handles it
      const alreadyHandledByMultiInstance = contactSrc === 'uazapi' && rawInstances.length > 1;
      if (!alreadyHandledByMultiInstance && hasTokenNow && effectiveUazapiUnitId && (contactSrc === 'uazapi' || splitModeRef.current)) {
        // Task #290: prefer last OUT message's instance over contact's stored value
        const instanceId = lastOutUazapiInstanceId || contact.uazapi_instance_id;
        // Update composer channel if the timeline-derived instance differs from the initial value
        if (contactSrc === 'uazapi' && instanceId && instanceId !== contact.uazapi_instance_id) {
          setComposerChannel(prev => prev ? { ...prev, uazapiInstanceId: instanceId } : prev);
        }
        const statusUrl = `/api/uazapi/status?unitId=${encodeURIComponent(effectiveUazapiUnitId)}${instanceId ? `&instanceId=${encodeURIComponent(instanceId)}` : ''}`;
        fetch(statusUrl).then(r => r.ok ? r.json() : null).then(d => {
          if (!d) return;
          const info: UazapiInstanceInfo = {
            configured: d.configured ?? true,
            isConnected: Boolean(d.isConnected),
            instanceId: d.instanceId || instanceId || null,
            label: d.label || null,
            phoneNumber: d.phoneNumber || null,
            serverUrl: d.serverUrl || null,
            error: d.error || null,
          };
          setWaConnected(info.isConnected);
          setWaInstanceInfo(info);
        }).catch(() => setWaConnected(null));
      }
    } catch { /* silent */ }
    finally { setLoadingTimeline(false); }

    // Enrich with WhatsApp contact data (only for uazapi contacts with a unit)
    // Task #248: use effectiveUazapiUnitId so enrichment uses the correct uazapi unit
    if (contactSrc === 'uazapi' && effectiveUazapiUnitId) {
      setWaLoading(true);
      const waHeaders = { 'Content-Type': 'application/json' };
      const waBody = JSON.stringify({ unitId: effectiveUazapiUnitId, phone: contact.phone });

      // Mark conversation as read (#190)
      const chatId = `${contact.phone.replace(/\D/g, '')}@s.whatsapp.net`;
      fetch(`/api/uazapi/chats/${encodeURIComponent(chatId)}/read?unitId=${encodeURIComponent(effectiveUazapiUnitId)}`, { method: 'POST', headers: waHeaders, body: '{}' }).catch(() => {});

      const [infoData, avatarData, checkData] = await Promise.all([
        fetch('/api/uazapi/contact/info',    { method: 'POST', headers: waHeaders, body: waBody }).then(r => r.ok ? r.json() : null).catch(() => null),
        fetch('/api/uazapi/contact/avatar',  { method: 'POST', headers: waHeaders, body: waBody }).then(r => r.ok ? r.json() : null).catch(() => null),
        fetch('/api/uazapi/contacts/check',  { method: 'POST', headers: waHeaders, body: waBody }).then(r => r.ok ? r.json() : null).catch(() => null),
      ]);
      if (infoData)   setWaInfo(infoData);
      if (avatarData?.url) setWaAvatar(avatarData.url);
      if (checkData)  setWaOnWa(Boolean(checkData.exists));
      setWaLoading(false);
    }

    // GoTalk profile enrichment (#191)
    if ((contact.last_source ?? contact.source) === 'gotalk') {

      fetch(`/api/gotalk/contact-profile?phone=${encodeURIComponent(contact.phone)}`)
        .then(r => r.ok ? r.json() : null)
        .then(d => {
          if (!d || !d.found) return;
          setGtProfile({ name: d.name, pictureUrl: d.pictureUrl, channelName: d.channelName, gotalkId: d.gotalkId });
          if (d.pictureUrl) setWaAvatar(d.pictureUrl);
          if (d.name) setWaInfo(prev => ({ ...prev, pushname: d.name } as WaContactInfo));
        })
        .catch(() => {});
    }
  }, [markGotalkConversationRead, decProspeccaoUnread]);

  // Scroll to bottom when timeline loads
  useEffect(() => {
    if (!loadingTimeline) {
      setTimeout(() => timelineEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 80);
    }
  }, [timelineMsgs, loadingTimeline]);

  // ── Notes handlers ───────────────────────────────────────────────────────
  const handleNoteFileChange = async (e: React.ChangeEvent<HTMLInputElement>, isEdit = false) => {
    const files = Array.from(e.target.files || []);
    if (!files.length) return;
    const MAX = 5 * 1024 * 1024;
    const results: { name: string; mimeType: string; data: string }[] = [];
    for (const f of files) {
      if (f.size > MAX) { addToast('error', 'Arquivo grande', `${f.name} excede 5MB.`); continue; }
      if (f.type === 'image/svg+xml' || f.name.endsWith('.svg')) { addToast('error', 'Tipo inválido', 'SVG não permitido.'); continue; }
      const data = await new Promise<string>((res, rej) => {
        const fr = new FileReader(); fr.onload = () => res(fr.result as string); fr.onerror = rej; fr.readAsDataURL(f);
      });
      results.push({ name: f.name, mimeType: f.type, data });
    }
    if (isEdit) {
      setNotes(prev => prev.map(n => n.id === editingNoteId ? { ...n, attachments: [...n.attachments, ...results] } : n));
    } else {
      setNewNoteAttachments(prev => [...prev, ...results]);
    }
    e.target.value = '';
  };

  const handleSaveNote = async () => {
    if (!selectedContact || (!newNoteText.trim() && newNoteAttachments.length === 0)) return;
    setSavingNote(true);
    try {
      const res = await fetch(`/api/prospection/contacts/${selectedContact.id}/notes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ noteText: newNoteText, attachments: newNoteAttachments }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotes(prev => [...prev, data.note]);
        setNewNoteText('');
        setNewNoteAttachments([]);
      } else {
        addToast('error', 'Erro', data.error || 'Não foi possível salvar a anotação.');
      }
    } catch { addToast('error', 'Erro', 'Erro de conexão.'); }
    finally { setSavingNote(false); }
  };

  const handleStartEditNote = (note: ProspectionNote) => {
    setEditingNoteId(note.id);
    setEditNoteText(note.note_text);
  };

  const handleSaveEditNote = async (noteId: string) => {
    const note = notes.find(n => n.id === noteId);
    if (!note) return;
    try {
      const res = await fetch(`/api/prospection/notes/${noteId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ noteText: editNoteText, attachments: note.attachments }),
      });
      const data = await res.json();
      if (res.ok) {
        setNotes(prev => prev.map(n => n.id === noteId ? data.note : n));
        setEditingNoteId(null);
      } else {
        addToast('error', 'Erro', data.error || 'Não foi possível salvar.');
      }
    } catch { addToast('error', 'Erro', 'Erro de conexão.'); }
  };

  const handleDeleteNoteAttachment = (noteId: string, attIdx: number, isNew = false) => {
    if (isNew) {
      setNewNoteAttachments(prev => prev.filter((_, i) => i !== attIdx));
    } else {
      setNotes(prev => prev.map(n => n.id === noteId
        ? { ...n, attachments: n.attachments.filter((_, i) => i !== attIdx) }
        : n));
    }
  };

  const handleDeleteNote = async (noteId: string) => {
    if (!confirm('Remover esta anotação?')) return;
    try {
      const res = await fetch(`/api/prospection/notes/${noteId}`, { method: 'DELETE' });
      if (res.ok) setNotes(prev => prev.filter(n => n.id !== noteId));
      else { const d = await res.json(); addToast('error', 'Erro', d.error || 'Não foi possível remover.'); }
    } catch { addToast('error', 'Erro', 'Erro de conexão.'); }
  };

  // ── Assign operator to contact ───────────────────────────────────────────
  const handleAssignOperator = async (contactId: string, operatorId: string) => {
    setAssigningOperator(true);
    try {
      const res = await fetch(`/api/prospection/contacts/${contactId}/operator`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ operatorId: operatorId || null }),
      });
      const data = await res.json();
      if (res.ok) {
        setSelectedContact(prev => prev ? {
          ...prev,
          operator_id: data.operatorId,
          operator_name_linked: data.operatorName,
        } : prev);
        setContacts(prev => prev.map(c => c.id === contactId ? {
          ...c,
          operator_id: data.operatorId,
          operator_name_linked: data.operatorName,
        } : c));
      }
    } catch { /* silent */ }
    finally { setAssigningOperator(false); }
  };

  // ── Typing indicator (#190) ───────────────────────────────────────────────
  const sendTypingPresence = useCallback((state: 'composing' | 'paused') => {
    if (!hasToken) return;
    // Task #248: use uazapi_unit_id when available for uazapi contacts
    const tSrc = selectedContact?.last_source ?? selectedContact?.source;
    const tUnitId = tSrc === 'uazapi'
      ? (selectedContact?.uazapi_unit_id || selectedContact?.unit_id)
      : selectedContact?.unit_id;
    if (!tUnitId) return;
    fetch('/api/uazapi/chats/presence', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        unitId: tUnitId,
        phone: selectedContact!.phone,
        state,
        // Prefer composer-selected instance (in-session switch) over contact's persisted value
        instanceId: composerChannel?.uazapiInstanceId || selectedContact?.uazapi_instance_id || undefined,
      }),
    }).catch(() => {});
  }, [selectedContact, hasToken, composerChannel]);

  const handleSendTextChange = useCallback((val: string) => {
    setSendText(val);
    if (val.trim().length > 0) {
      sendTypingPresence('composing');
      if (typingTimerRef.current) clearTimeout(typingTimerRef.current);
      typingTimerRef.current = setTimeout(() => sendTypingPresence('paused'), 10000);
    } else {
      sendTypingPresence('paused');
      if (typingTimerRef.current) { clearTimeout(typingTimerRef.current); typingTimerRef.current = null; }
    }
  }, [sendTypingPresence]);

  // ── Send message (#190) ───────────────────────────────────────────────────
  const handleSend = async () => {
    // Use composerChannel (explicit selection) as the source of truth for routing.
    // Fall back to contact's stored last_source only when composerChannel is not yet set.
    const src: string | null = composerChannel?.source
      ?? (selectedContact ? (selectedContact.last_source ?? selectedContact.source) : null);

    // Resolve the effective unit ID from composerChannel first, then fall back to contact data
    const effectiveSendUnitId = src === 'uazapi'
      ? (composerChannel?.uazapiUnitId || selectedContact?.uazapi_unit_id || selectedContact?.unit_id || null)
      : selectedContact?.unit_id || null;
    if (!sendText.trim() || !effectiveSendUnitId || sendLoading) return;
    // Stop typing indicator
    if (typingTimerRef.current) { clearTimeout(typingTimerRef.current); typingTimerRef.current = null; }
    sendTypingPresence('paused');
    setSendLoading(true);
    try {
      let res: Response;
      if (src === 'gotalk') {
        // Resolve GoTalk channel UUID: prefer composerChannel.gotalkChannelId (explicit selection),
        // then fall back to the contact's stored uazapi_instance_id field (legacy)
        const gotalkChannelUuid = composerChannel?.gotalkChannelId || selectedContact?.uazapi_instance_id || undefined;
        res = await fetch('/api/gotalk/send-text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contactNumber: selectedContact!.phone.replace(/\D/g, ''),
            message: sendText.trim(),
            ...(gotalkChannelUuid ? { channelUuid: gotalkChannelUuid } : {}),
          }),
        });
      } else {
        // uazapi: prefer composerChannel.uazapiInstanceId (explicit selection)
        const instanceId = composerChannel?.uazapiInstanceId || selectedContact?.uazapi_instance_id || undefined;
        res = await fetch('/api/uazapi/send-text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            unitId: effectiveSendUnitId,
            phone: selectedContact!.phone,
            text: sendText.trim(),
            instanceId,
          }),
        });
      }
      const data = await res.json();
      if (!res.ok) {
        addToast('error', 'Erro ao enviar', data.error || 'Não foi possível enviar a mensagem.');
      } else {
        setSendText('');
        if (data.message) {
          setTimelineMsgs(prev => [...prev, data.message]);
          setTimeout(() => timelineEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
        }
        // Fix #262: if the server resolved a specific instanceId (e.g. fallback to first instance
        // when contact had no instance stored), sync it back into local state so subsequent
        // sends and status checks use the correct instance without requiring a page reload.
        // Guard by contact ID to avoid overwriting a different contact if the user switched
        // contacts while this send request was in-flight.
        if (src !== 'gotalk' && data.message?.instance_id && selectedContact) {
          const resolvedInstanceId = data.message.instance_id as string;
          const contactId = selectedContact.id;
          if (resolvedInstanceId !== selectedContact.uazapi_instance_id) {
            if (import.meta.env.DEV) {
              console.debug('[ProspeccaoPanel] Syncing resolved uazapi instance:', resolvedInstanceId, '(was:', selectedContact.uazapi_instance_id ?? 'null', ')');
            }
            // Merge only the resolved field from prev to avoid stale-snapshot overwrites
            // in case other state changes fired while the send request was in-flight.
            setSelectedContact(prev => prev?.id === contactId ? { ...prev, uazapi_instance_id: resolvedInstanceId } : prev);
            setContacts(prev => prev.map(c => c.id === contactId ? { ...c, uazapi_instance_id: resolvedInstanceId } : c));
            // Re-check connection status for the newly resolved instance so the
            // send button and offline banner reflect the correct state immediately.
            // Guard by contactId via selectedContactRef to avoid applying stale
            // status to a different contact if the operator switched mid-fetch.
            const statusUrl = `/api/uazapi/status?unitId=${encodeURIComponent(effectiveSendUnitId)}&instanceId=${encodeURIComponent(resolvedInstanceId)}`;
            fetch(statusUrl).then(r => r.ok ? r.json() : null).then(d => {
              if (!d || selectedContactRef.current?.id !== contactId) return;
              setWaConnected(Boolean(d.isConnected));
              setWaInstanceInfo({
                configured: d.configured ?? true,
                isConnected: Boolean(d.isConnected),
                instanceId: d.instanceId || resolvedInstanceId,
                label: d.label || null,
                phoneNumber: d.phoneNumber || null,
                serverUrl: d.serverUrl || null,
                error: d.error || null,
              });
            }).catch(() => {});
          }
        }
      }
    } catch {
      addToast('error', 'Erro ao enviar', 'Erro de conexão.');
    } finally {
      setSendLoading(false);
    }
  };

  // ── Send message in split mode ─────────────────────────────────────────────
  const handleSplitSend = async (source: 'gotalk' | 'uazapi') => {
    if (!selectedContact) return;
    const text = source === 'gotalk' ? splitGtText.trim() : splitWaText.trim();
    if (!text) return;
    if (source === 'gotalk') {
      setSplitGtLoading(true);
      try {
        // Resolve GoTalk channel UUID strictly from composer or unit channels.
        // Never fall back to uazapi_instance_id (wrong ID type for GoTalk).
        const gotalkChannelUuid: string | undefined = (() => {
          if (composerChannel?.source === 'gotalk' && composerChannel.gotalkChannelId) {
            return composerChannel.gotalkChannelId;
          }
          const uid = selectedContact.unit_id;
          const uChs = uid ? (unitChannelMap.get(uid) || []) : [];
          return (uChs.find(c => c.is_primary && c.is_active) || uChs.find(c => c.is_active))?.id;
        })();
        const res = await fetch('/api/gotalk/send-text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contactNumber: selectedContact.phone.replace(/\D/g, ''),
            message: text,
            ...(gotalkChannelUuid ? { channelUuid: gotalkChannelUuid } : {}),
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          addToast('error', 'Erro ao enviar (GoTalk)', data.error || 'Não foi possível enviar a mensagem.');
        } else {
          setSplitGtText('');
          if (data.message) {
            setTimelineMsgs(prev => [...prev, data.message]);
            setTimeout(() => gtEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
          }
        }
      } catch {
        addToast('error', 'Erro ao enviar (GoTalk)', 'Erro de conexão.');
      } finally {
        setSplitGtLoading(false);
      }
    } else {
      setSplitWaLoading(true);
      try {
        const effectiveSendUnitId = composerChannel?.uazapiUnitId || selectedContact.uazapi_unit_id || selectedContact.unit_id || null;
        if (!effectiveSendUnitId) {
          addToast('error', 'Erro', 'Unidade não identificada para envio via uazapi.');
          setSplitWaLoading(false);
          return;
        }
        const instanceId = composerChannel?.uazapiInstanceId || selectedContact.uazapi_instance_id || undefined;
        const res = await fetch('/api/uazapi/send-text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            unitId: effectiveSendUnitId,
            phone: selectedContact.phone,
            text,
            instanceId,
          }),
        });
        const data = await res.json();
        if (!res.ok) {
          addToast('error', 'Erro ao enviar (uazapi)', data.error || 'Não foi possível enviar a mensagem.');
        } else {
          setSplitWaText('');
          if (data.message) {
            setTimelineMsgs(prev => [...prev, data.message]);
            setTimeout(() => waEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
          }
        }
      } catch {
        addToast('error', 'Erro ao enviar (uazapi)', 'Erro de conexão.');
      } finally {
        setSplitWaLoading(false);
      }
    }
  };

  // ── Envio de mídia (Task #311) ─────────────────────────────────────────────
  // Lê um File como data URL (base64). O backend aceita base64 ou URL pública.
  const fileToDataUrl = (file: File): Promise<string> =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ''));
      reader.onerror = () => reject(reader.error || new Error('Falha ao ler arquivo.'));
      reader.readAsDataURL(file);
    });

  // Mapeia o MIME do arquivo para o `type` esperado pela API uazapi.
  // `asVoice` (gravação de áudio) vira 'ptt' (push-to-talk).
  const mapFileToUazapiType = (file: File, asVoice?: boolean): string => {
    const mime = (file.type || '').toLowerCase();
    if (mime.startsWith('image/')) return 'image';
    if (mime.startsWith('video/')) return 'video';
    if (mime.startsWith('audio/')) return asVoice ? 'ptt' : 'audio';
    return 'document';
  };

  // Envia mídia respeitando o roteamento por canal:
  //  • GoTalk → mídia binária fora de escopo: orienta a usar texto/template.
  //  • uazapi → POST /api/uazapi/send-media (base64), insere a mensagem na timeline.
  const sendMediaForSource = async (
    source: 'gotalk' | 'uazapi',
    file: File,
    caption: string,
    asVoice?: boolean,
    endRef?: React.RefObject<HTMLDivElement>,
    setLoading?: (v: boolean) => void,
  ): Promise<boolean> => {
    if (!selectedContact) return false;
    if (source === 'gotalk') {
      addToast('info', 'Mídia indisponível no GoTalk', 'O canal GoTalk suporta apenas texto e templates. Use o canal uazapi para enviar arquivos.');
      return false;
    }
    const effectiveSendUnitId = composerChannel?.uazapiUnitId || selectedContact.uazapi_unit_id || selectedContact.unit_id || null;
    if (!effectiveSendUnitId) {
      addToast('error', 'Erro', 'Unidade não identificada para envio via uazapi.');
      return false;
    }
    const instanceId = composerChannel?.uazapiInstanceId || selectedContact.uazapi_instance_id || undefined;
    const scrollRef = endRef || timelineEndRef;
    setLoading?.(true);
    try {
      const dataUrl = await fileToDataUrl(file);
      const res = await fetch('/api/uazapi/send-media', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          unitId: effectiveSendUnitId,
          phone: selectedContact.phone,
          instanceId,
          type: mapFileToUazapiType(file, asVoice),
          file: dataUrl,
          fileName: file.name,
          mimeType: file.type || undefined,
          caption: caption || undefined,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        addToast('error', 'Erro ao enviar mídia', data.error || 'Não foi possível enviar o arquivo.');
        return false;
      }
      if (data.message) {
        // Fallback local: se o backend não retornou uma URL pública, usa um
        // objectURL para exibição imediata na timeline (a timeline renderiza a
        // mídia diretamente por attachment_url sem messageId). A URL é registrada
        // em mediaObjectUrlsRef para ser revogada na troca de contato/desmontagem.
        const msg = { ...data.message } as TimelineMsg;
        if (!msg.attachment_url) {
          const objUrl = URL.createObjectURL(file);
          mediaObjectUrlsRef.current.add(objUrl);
          msg.attachment_url = objUrl;
        }
        setTimelineMsgs(prev => [...prev, msg]);
        setTimeout(() => scrollRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
      }
      return true;
    } catch {
      addToast('error', 'Erro ao enviar mídia', 'Erro de conexão.');
      return false;
    } finally {
      setLoading?.(false);
    }
  };

  // Envia o corpo renderizado de um template HSM como texto via uazapi.
  // Lança erro em falha para que o modal exiba a mensagem.
  const sendTemplateAsUazapiText = async (renderedBody: string): Promise<void> => {
    if (!selectedContact) throw new Error('Nenhum contato selecionado.');
    const effectiveSendUnitId = composerChannel?.uazapiUnitId || selectedContact.uazapi_unit_id || selectedContact.unit_id || null;
    if (!effectiveSendUnitId) throw new Error('Unidade não identificada para envio via uazapi.');
    const instanceId = composerChannel?.uazapiInstanceId || selectedContact.uazapi_instance_id || undefined;
    const res = await fetch('/api/uazapi/send-text', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        unitId: effectiveSendUnitId,
        phone: selectedContact.phone,
        text: renderedBody,
        instanceId,
      }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Não foi possível enviar o template.');
    if (data.message) {
      setTimelineMsgs(prev => [...prev, data.message]);
      setTimeout(() => timelineEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
    }
  };

  // Abre o modal de template definindo o roteamento conforme o canal informado.
  const openTemplateModalForSource = (source: 'gotalk' | 'uazapi') => {
    setTemplateMode(source);
    setShowTemplateModal(true);
  };

  // ── Nova mensagem WhatsApp para número novo (Task #256) ───────────────────

  // Helper: check if `phone` (digits only) matches the currently selected contact.
  const phoneMatchesSelected = useCallback((phone: string): boolean => {
    if (!selectedContact) return false;
    const digits = phone.replace(/\D/g, '');
    const contactDigits = String(selectedContact.phone).replace(/\D/g, '');
    return contactDigits === digits
      || contactDigits.endsWith(digits)
      || digits.endsWith(contactDigits);
  }, [selectedContact]);

  // Step 1: Optimistic insert — only shows in the current timeline when the
  // target phone belongs to the selected contact. Suppresses insert for new
  // numbers to avoid timeline contamination (blocking issue from code review).
  const handleWaOptimisticInsert = useCallback((msg: TimelineMsg, phone: string) => {
    if (!phoneMatchesSelected(phone)) return; // different / new number — skip
    setTimelineMsgs(prev => [...prev, msg]);
    setTimeout(() => timelineEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
  }, [phoneMatchesSelected]);

  // Step 2a: API succeeded.
  //   • Same phone → replace optimistic entry; no list refresh needed.
  //   • Different/new phone → no optimistic was inserted; refresh contacts list
  //     so the newly created contact appears (auto-select is Task #257).
  const handleWaModalSent = useCallback((msg: TimelineMsg, phone: string, _unitId: string, optimisticId: string) => {
    if (phoneMatchesSelected(phone)) {
      setTimelineMsgs(prev =>
        prev.map(m => (m.id === optimisticId ? { ...msg } : m))
      );
      addToast('success', 'Mensagem enviada', 'Mensagem enviada com sucesso via WhatsApp.');
    } else {
      // New number: no optimistic was inserted; just refresh the contacts list.
      addToast('success', 'Mensagem enviada', 'Contato registrado e mensagem enviada via WhatsApp.');
      setTimeout(() => fetchContacts(1), 1500);
    }
    setShowWaModal(false);
    setWaModalPhone('');
  }, [phoneMatchesSelected, addToast, fetchContacts]);

  // Step 2b: API failed — remove optimistic message; modal stays open to show error
  const handleWaModalFailed = useCallback((optimisticId: string) => {
    setTimelineMsgs(prev => prev.filter(m => m.id !== optimisticId));
  }, []);

  // ── Close conversation ────────────────────────────────────────────────────
  const handleCloseConversation = async (data: { outcome: string; summaryText: string; nextStep: string }) => {
    if (!activeConvId) return;
    try {
      const res = await fetch(`/api/prospection/conversations/${activeConvId}/summary`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          outcome: data.outcome,
          summaryText: data.summaryText,
          summaryData: { nextStep: data.nextStep },
          messageCount: timelineMsgs.length,
        }),
      });
      if (res.ok) {
        addToast('success', 'Conversa encerrada', 'Resumo salvo com sucesso.');
        setShowCloseModal(false);
        setActiveConvId(null);
        // Refresh history for the contact
        if (selectedContact) {
          const histRes = await fetch(`/api/prospection/contacts/${encodeURIComponent(selectedContact.phone)}/history`);
          if (histRes.ok) {
            const histData = await histRes.json();
            setHistory(histData.conversations || []);
          }
        }
      } else {
        const err = await res.json();
        addToast('error', 'Erro', err.error || 'Não foi possível salvar o resumo.');
      }
    } catch {
      addToast('error', 'Erro de conexão', 'Tente novamente.');
    }
  };

  // ── Derived: group timeline by day ────────────────────────────────────────
  const sortedTimeline = useMemo(() => {
    return [...timelineMsgs].sort((a, b) =>
      new Date(a.sent_at || 0).getTime() - new Date(b.sent_at || 0).getTime()
    );
  }, [timelineMsgs]);

  // Most recent closed conversation
  const lastClosedConv = useMemo(() =>
    history.filter(c => c.end_at).sort((a, b) =>
      new Date(b.end_at!).getTime() - new Date(a.end_at!).getTime()
    )[0] ?? null
  , [history]);

  const closedHistory = useMemo(() => history.filter(c => c.end_at), [history]);

  // Split-mode filtered timelines (client-side filter by source field)
  const gtMessages = useMemo(() => sortedTimeline.filter(m => !m.source || m.source === 'gotalk'), [sortedTimeline]);
  const waMessages = useMemo(() => sortedTimeline.filter(m => m.source === 'uazapi'), [sortedTimeline]);

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div ref={panelRef} data-testid="prospeccao-panel" data-visual-panel="prospeccao" className="whatsapp-theme flex flex-col h-full min-w-0 overflow-hidden bg-gray-50">

      {/* ── Tab bar ───────────────────────────────────────────────────────── */}
      <div data-testid="prospeccao-tabs" className="flex-shrink-0 bg-white border-b border-gray-200 px-3 min-[1400px]:px-4 flex items-center gap-1 h-10">
        <button
          onClick={() => setActiveTab('contacts')}
          className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'contacts'
              ? 'text-white'
              : 'text-gray-500 hover:text-gray-800 hover:bg-gray-100'
          }`}
          style={activeTab === 'contacts' ? { background: '#2d4a3e' } : undefined}
        >
          Contatos
        </button>
        <button
          onClick={() => setActiveTab('dashboard')}
          className={`px-4 py-1.5 text-xs font-semibold rounded-lg transition-colors ${
            activeTab === 'dashboard'
              ? 'text-white'
              : 'text-gray-500 hover:text-gray-800 hover:bg-gray-100'
          }`}
          style={activeTab === 'dashboard' ? { background: '#2d4a3e' } : undefined}
        >
          Dashboard
        </button>
      </div>

      {/* ── Dashboard tab ─────────────────────────────────────────────────── */}
      {activeTab === 'dashboard' ? (
        <ProspeccaoDashboard filterUnits={filterUnits} selectedUnitIds={selectedUnitIds} />
      ) : (

      <div data-testid="prospeccao-contact-layout" className="flex flex-1 min-h-0 min-w-0 overflow-hidden">
      {/* ── Left column: contact list ──────────────────────────────────────── */}
      <div data-testid="prospeccao-contact-list" className={`w-64 min-[1400px]:w-72 max-[767px]:w-full flex-shrink-0 bg-white border-r border-gray-200 flex flex-col overflow-hidden ${selectedContact ? 'max-[767px]:hidden' : ''}`}>
        {/* Header */}
        <div className="px-4 py-4 border-b border-gray-100 flex-shrink-0">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: '#2d4a3e' }}>
              <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" />
              </svg>
            </div>
            <div>
              <p className="text-sm font-bold text-gray-900">Prospecção</p>
              <p className="text-[10px] text-gray-400">{contactsTotal.toLocaleString('pt-BR')} contatos</p>
            </div>
          </div>
          {/* Unit selector — multi-select for 2+ units, static label for 1, hidden for 0 — above search */}
          {filterUnits.length >= 2 ? (
            <div ref={unitDropdownRef} className="relative mb-1.5">
              <button
                onClick={() => setUnitDropdownOpen(o => !o)}
                className="w-full flex items-center justify-between px-2.5 py-1.5 text-xs border border-gray-300 rounded-lg bg-white hover:border-green-400 focus:outline-none focus:ring-2 focus:ring-green-500 transition-colors"
              >
                <span className="flex items-center gap-1.5 text-gray-700 font-medium min-w-0 truncate">
                  <svg className="w-3.5 h-3.5 text-green-600 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
                  </svg>
                  <span className="truncate">
                    {selectedUnitIds.length === filterUnits.length
                      ? 'Todas as unidades'
                      : selectedUnitIds.length === 1
                        ? filterUnits.find(u => u.id === selectedUnitIds[0])?.name || '1 unidade'
                        : `${selectedUnitIds.length} de ${filterUnits.length} unidades`}
                  </span>
                </span>
                <svg className={`w-3.5 h-3.5 text-gray-400 flex-shrink-0 transition-transform ${unitDropdownOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                </svg>
              </button>

              {unitDropdownOpen && (
                <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-20 overflow-hidden">
                  {/* Select all — no-op when already all selected to avoid accidental collapse */}
                  <button
                    onClick={() => {
                      if (selectedUnitIds.length < filterUnits.length) {
                        setSelectedUnitIds(filterUnits.map(u => u.id));
                      }
                    }}
                    className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-50 border-b border-gray-100 transition-colors"
                  >
                    <div className={`w-3.5 h-3.5 rounded border flex-shrink-0 flex items-center justify-center transition-colors ${selectedUnitIds.length === filterUnits.length ? 'bg-green-600 border-green-600' : 'border-gray-300'}`}>
                      {selectedUnitIds.length === filterUnits.length && (
                        <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                    Todas as unidades
                  </button>
                  {/* Individual units */}
                  <div className="max-h-48 overflow-y-auto">
                    {filterUnits.map(u => {
                      const checked = selectedUnitIds.includes(u.id);
                      const isLast = selectedUnitIds.length === 1 && checked;
                      return (
                        <button
                          key={u.id}
                          disabled={isLast}
                          onClick={() => {
                            if (isLast) return;
                            setSelectedUnitIds(prev =>
                              checked ? prev.filter(x => x !== u.id) : [...prev, u.id]
                            );
                          }}
                          className={`w-full flex items-center gap-2 px-3 py-2 text-xs text-left transition-colors ${isLast ? 'opacity-40 cursor-not-allowed' : 'hover:bg-gray-50'}`}
                        >
                          <div className={`w-3.5 h-3.5 rounded border flex-shrink-0 flex items-center justify-center transition-colors ${checked ? 'bg-green-600 border-green-600' : 'border-gray-300'}`}>
                            {checked && (
                              <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                              </svg>
                            )}
                          </div>
                          <span className="truncate text-gray-700">{u.name}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          ) : filterUnits.length === 1 ? (
            <div className="flex items-center gap-1.5 px-2 py-1.5 mb-1.5 bg-green-50 border border-green-100 rounded-lg">
              <svg className="w-3.5 h-3.5 text-green-600 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
              </svg>
              <span className="text-xs text-green-800 font-medium truncate">{filterUnits[0].name}</span>
            </div>
          ) : null}

          {/* ── Provider filter pills (top-level, persisted to localStorage) ── */}
          <div className="flex gap-1 mb-1.5">
            {([
              { val: '', label: 'Todos', activeClass: 'bg-gray-700 border-gray-700 text-white' },
              { val: 'gotalk', label: 'GoTalk', activeClass: 'bg-blue-600 border-blue-600 text-white' },
              { val: 'uazapi', label: 'uazapi', activeClass: 'bg-green-600 border-green-600 text-white' },
            ] as const).map(({ val, label, activeClass }) => (
              <button
                key={val}
                onClick={() => {
                  setFSource(val);
                  try { localStorage.setItem('prospeccao:fSource', val); } catch { /* ignore */ }
                }}
                className={`flex-1 py-0.5 text-[11px] font-semibold rounded-lg border transition-colors ${
                  fSource === val ? activeClass : 'bg-white border-gray-200 text-gray-600 hover:border-gray-400 hover:bg-gray-50'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* ── WhatsApp Instances Panel ─────────────────────────────────── */}
          {(instancesLoading || unitInstances.length > 0) && (
            <div className="mb-2 border border-gray-200 rounded-lg overflow-hidden">
              {/* Header */}
              <button
                onClick={() => setInstancesPanelOpen(o => !o)}
                aria-expanded={instancesPanelOpen}
                aria-controls="prospeccao-whatsapp-instances"
                className="w-full flex items-center justify-between px-2.5 py-1.5 bg-gray-50 hover:bg-gray-100 transition-colors"
              >
                <span className="flex items-center gap-1.5 text-[11px] font-semibold text-gray-600">
                  <svg className="w-3.5 h-3.5 text-green-600 flex-shrink-0" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                  </svg>
                  WhatsApp
                  {!instancesLoading && (
                    <span className={`ml-1 px-1 py-0.5 rounded text-[9px] font-bold ${
                      unitInstances.some(i => !i.isConnected)
                        ? 'bg-orange-100 text-orange-700'
                        : 'bg-green-100 text-green-700'
                    }`}>
                      {unitInstances.filter(i => i.isConnected).length}/{unitInstances.length}
                    </span>
                  )}
                </span>
                <div className="flex items-center gap-1">
                  {instancesLoading && (
                    <svg className="w-3 h-3 animate-spin text-gray-400" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/>
                    </svg>
                  )}
                  <button
                    onClick={(e) => { e.stopPropagation(); fetchUnitInstances(filterUnits); }}
                    className="p-0.5 text-gray-400 hover:text-gray-600 transition-colors"
                    title="Atualizar status"
                  >
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                  </button>
                  <svg className={`w-3 h-3 text-gray-400 transition-transform ${instancesPanelOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </div>
              </button>

              {/* Instance rows */}
              {instancesPanelOpen && !instancesLoading && (
                <div id="prospeccao-whatsapp-instances" className="divide-y divide-gray-100">
                  {unitInstances.map(inst => (
                    <div key={`${inst.unitId}-${inst.instanceId}`} className="flex items-center gap-2 px-2.5 py-1.5">
                      {/* Status dot */}
                      <span className={`flex-shrink-0 w-2 h-2 rounded-full ${inst.isConnected ? 'bg-green-500' : 'bg-orange-400'}`} />
                      {/* Labels */}
                      <div className="flex-1 min-w-0">
                        <p className="text-[11px] font-medium text-gray-800 truncate">
                          {inst.label || inst.instanceId}
                        </p>
                        {inst.phoneNumber && inst.phoneNumber !== inst.instanceId && (
                          <p className="text-[10px] text-gray-400 font-mono truncate">{inst.phoneNumber}</p>
                        )}
                        {filterUnits.length > 1 && (
                          <p className="text-[9px] text-gray-400 truncate">{inst.unitName}</p>
                        )}
                      </div>
                      {/* Reconnect button (only for disconnected) */}
                      {!inst.isConnected && (
                        <button
                          onClick={() => setQrModalTarget({ unitId: inst.unitId, instanceId: inst.instanceId, label: inst.label })}
                          className="flex-shrink-0 flex items-center gap-0.5 px-2 py-0.5 rounded bg-orange-500 hover:bg-orange-600 text-white text-[10px] font-semibold transition-colors"
                          title="Conectar via QR Code"
                        >
                          <svg className="w-2.5 h-2.5" fill="currentColor" viewBox="0 0 24 24">
                            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                          </svg>
                          QR
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Search + Filter button row */}
          <div className="flex gap-1.5 mb-0">
            <input
              type="text"
              placeholder="Buscar por nome ou telefone..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="flex-1 min-w-0 border border-gray-300 rounded-lg px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            {/* Task #300: Atualizar conversas — força refetch imediato sem aguardar debounce/socket */}
            <button
              onClick={() => {
                fetchContacts(1);
                if (selectedContact?.phone) refreshTimeline(selectedContact.phone);
              }}
              disabled={loadingContacts}
              className="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg bg-white border border-gray-300 text-gray-600 hover:border-green-400 hover:text-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              title="Atualizar conversas"
            >
              <svg className={`w-4 h-4 ${loadingContacts ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
            </button>
            {/* Nova mensagem WhatsApp (Task #256) */}
            <button
              onClick={() => {
                setWaModalPhone(selectedContact ? String(selectedContact.phone).replace(/\D/g, '') : '');
                setShowWaModal(true);
              }}
              className="flex-shrink-0 flex items-center justify-center w-8 h-8 rounded-lg bg-green-600 hover:bg-green-700 text-white transition-colors"
              title="Nova mensagem WhatsApp para número novo"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
            </button>
            {/* Filter button */}
            <div ref={filterDropdownRef} className="relative flex-shrink-0">
              <button
                onClick={() => setFilterDropdownOpen(o => !o)}
                className={`flex items-center gap-1.5 px-2.5 py-2 rounded-lg border text-xs font-medium transition-colors ${
                  activeFilterCount > 0
                    ? 'bg-green-600 border-green-600 text-white'
                    : filterDropdownOpen
                      ? 'bg-gray-100 border-gray-400 text-gray-700'
                      : 'bg-white border-gray-300 text-gray-600 hover:border-green-400 hover:text-green-700'
                }`}
                title="Filtros"
              >
                <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L13 13.414V19a1 1 0 01-.553.894l-4 2A1 1 0 017 21v-7.586L3.293 6.707A1 1 0 013 6V4z" />
                </svg>
                {activeFilterCount > 0 && (
                  <span className="w-4 h-4 rounded-full bg-white text-green-700 text-[10px] font-bold flex items-center justify-center leading-none">
                    {activeFilterCount}
                  </span>
                )}
              </button>

              {/* Filter dropdown panel */}
              {filterDropdownOpen && (
                <div className="absolute top-full right-0 mt-1 w-64 bg-white border border-gray-200 rounded-xl shadow-xl z-30 p-3 flex flex-col gap-2.5">
                  {/* Classification */}
                  <div>
                    <label className="block text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Classificação</label>
                    <select
                      value={fClassification}
                      onChange={e => setFClassification(e.target.value)}
                      className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-500"
                    >
                      <option value="">Todas</option>
                      <option value="LEAD">Lead</option>
                      <option value="RECUPERACAO">Recuperação</option>
                    </select>
                  </div>

                  {/* Period */}
                  <div>
                    <label className="block text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Período</label>
                    <select
                      value={fPeriod}
                      onChange={e => setFPeriod(e.target.value)}
                      className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-500"
                    >
                      <option value="">Todos</option>
                      <option value="today">Hoje</option>
                      <option value="7d">7 dias</option>
                      <option value="30d">30 dias</option>
                    </select>
                  </div>

                  {/* Operator */}
                  <div>
                    <label className="block text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Operador</label>
                    <select
                      value={fOperator}
                      onChange={e => setFOperator(e.target.value)}
                      className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-500"
                    >
                      <option value="">Todos</option>
                      {filterOperators.map(o => (
                        <option key={o.id} value={o.id}>{o.name}</option>
                      ))}
                    </select>
                  </div>

                  {/* Source / Provider */}
                  <div>
                    <label className="block text-[10px] font-semibold text-gray-400 uppercase tracking-wide mb-1">Provedor</label>
                    <select
                      value={fSource}
                      onChange={e => {
                        setFSource(e.target.value);
                        try { localStorage.setItem('prospeccao:fSource', e.target.value); } catch { /* ignore */ }
                      }}
                      className="w-full border border-gray-200 rounded-lg px-2.5 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-500"
                    >
                      <option value="">Todos</option>
                      <option value="gotalk">GoTalk</option>
                      <option value="uazapi">uazapi</option>
                    </select>
                  </div>

                  {/* Has appointment toggle */}
                  <button
                    onClick={() => setFHasAppointment(v => !v)}
                    className={`w-full flex items-center gap-2 px-2.5 py-1.5 rounded-lg border text-xs font-medium transition-colors ${
                      fHasAppointment
                        ? 'bg-purple-600 border-purple-600 text-white'
                        : 'bg-white border-gray-200 text-gray-600 hover:border-purple-400 hover:text-purple-700'
                    }`}
                  >
                    <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    {fHasAppointment ? 'Somente agendados' : 'Com e sem agendamento'}
                  </button>

                  {/* Clear all */}
                  {activeFilterCount > 0 && (
                    <button
                      onClick={() => {
                        setFClassification('');
                        setFPeriod('30d');
                        setFOperator('');
                        setFSource('');
                        try { localStorage.setItem('prospeccao:fSource', ''); } catch { /* ignore */ }
                        setFHasAppointment(false);
                      }}
                      className="w-full text-xs text-red-500 hover:text-red-700 border border-red-200 hover:border-red-400 rounded-lg py-1.5 transition-colors font-medium"
                    >
                      Limpar filtros
                    </button>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Contact list */}
        <div data-testid="prospeccao-contacts-scroll" className="flex-1 min-h-0 overflow-y-auto overflow-x-hidden">
          {loadingContacts ? (
            <div className="flex items-center justify-center h-24 text-gray-400 text-xs">Carregando...</div>
          ) : contacts.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-24 text-gray-400 gap-1">
              <svg className="w-8 h-8 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
              <p className="text-xs">Nenhum contato encontrado</p>
            </div>
          ) : (
            contacts.map(contact => {
              const isSelected = selectedContact?.id === contact.id;
              const avatarSrc = isSelected ? waAvatar : null;
              const isLinked = !!contact.client_id;
              const displayName = contact.contact_name || contact.client_name_linked || formatPhone(contact.phone);
              const initial = displayName[0]?.toUpperCase() || '?';
              const bgColor = contact.classification === 'LEAD' ? '#16a34a' : '#ea580c';
              const contactPhoneKey = String(contact.phone).replace(/\D/g, '');
              const unreadData = waUnread[contactPhoneKey];
              const gtUnread = unreadData?.gotalk ?? 0;
              const waUnreadCount = unreadData?.uazapi ?? 0;
              const unreadCount = gtUnread + waUnreadCount;
              return (
                <button
                  key={contact.id}
                  onClick={() => selectContact(contact)}
                  className={`w-full text-left px-3 py-3 border-b transition-colors hover:bg-gray-50 ${
                    isSelected
                      ? 'bg-green-50 border-l-4 border-l-green-600 border-b-gray-100'
                      : isLinked
                        ? 'bg-blue-50/40 border-l-2 border-l-blue-400 border-b-blue-100/60'
                        : 'border-b-gray-100'
                  }`}
                >
                  <div className="flex items-start gap-2.5">
                    {/* Avatar with linked-client badge overlay */}
                    <div className="relative flex-shrink-0">
                      <div className="w-8 h-8 rounded-full overflow-hidden flex items-center justify-center text-white text-xs font-bold" style={{ background: bgColor }}>
                        {avatarSrc ? (
                          <img src={avatarSrc} alt={displayName} className="w-full h-full object-cover" onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />
                        ) : initial}
                      </div>
                      {isLinked && (
                        <span
                          className="absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full bg-blue-500 border border-white flex items-center justify-center"
                          title={`Cliente cadastrado: ${contact.client_name_linked}`}
                        >
                          <svg className="w-2 h-2 text-white" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        </span>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-1 mb-0.5">
                        <p className="text-xs font-semibold text-gray-800 truncate flex-1">{displayName}</p>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          {/* Task #300: badge único vermelho agregando gotalk + uazapi pendentes */}
                          {unreadCount > 0 && (
                            <span
                              className="min-w-[20px] h-5 px-1.5 rounded-full bg-red-600 text-white text-[10px] font-bold flex items-center justify-center leading-none shadow-sm ring-2 ring-red-100"
                              title={`${unreadCount} mensagem(ns) pendente(s)${gtUnread > 0 ? ` — GoTalk: ${gtUnread}` : ''}${waUnreadCount > 0 ? ` — uazapi: ${waUnreadCount}` : ''}`}
                            >
                              {unreadCount > 99 ? '99+' : unreadCount}
                            </span>
                          )}
                          <ClassBadge c={contact.classification} />
                        </div>
                      </div>

                      {/* Client linked row — prominent when linked */}
                      {isLinked ? (
                        <div className="flex items-center gap-1 mb-0.5">
                          <svg className="w-2.5 h-2.5 text-blue-500 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                          </svg>
                          <p className="text-[10px] font-semibold text-blue-600 truncate">{contact.client_name_linked || 'Cliente vinculado'}</p>
                        </div>
                      ) : (
                        <p className="text-[10px] text-gray-400 italic mb-0.5">Sem cadastro</p>
                      )}

                      <p className="text-[10px] font-mono text-gray-500 mb-0.5">{formatPhone(contact.phone)}</p>

                      {/* Operator row */}
                      {contact.operator_name_linked && (
                        <div className="flex items-center gap-1 mb-0.5">
                          <svg className="w-2.5 h-2.5 text-gray-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                          </svg>
                          <p className="text-[10px] text-gray-500 truncate">{contact.operator_name_linked}</p>
                        </div>
                      )}

                      <div className="flex items-center justify-between gap-1">
                        <p className="text-[10px] text-gray-400 truncate">{contact.unit_name || '—'}</p>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          {(contact.last_source ?? contact.source) === 'uazapi' ? (
                            <span className="inline-flex items-center gap-0.5 px-1 py-0.5 rounded text-[8px] font-bold bg-green-50 text-green-700 border border-green-200" title="Último contato via uazapi (WhatsApp SaaS)">W</span>
                          ) : (() => {
                            const unitChs = contact.unit_id ? unitChannelMap.get(contact.unit_id) : undefined;
                            const gtCh = unitChs?.find(c => c.is_primary) || unitChs?.[0] || null;
                            const shortLabel = gtCh
                              ? (gtCh.name.split(' ').pop() || gtCh.name).slice(0, 6)
                              : null;
                            return (
                              <span
                                className="inline-flex items-center gap-0.5 px-1 py-0.5 rounded text-[8px] font-bold bg-blue-50 text-blue-700 border border-blue-200"
                                title={gtCh ? `Canal GoTalk: ${gtCh.name}` : 'Último contato via GoTalk'}
                              >
                                G{shortLabel ? <span className="font-normal opacity-75 ml-0.5">{shortLabel}</span> : null}
                              </span>
                            );
                          })()}
                          <p className="text-[10px] text-gray-400">{formatDate(contact.last_contact_at)}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>

        {/* Pagination */}
        {contactsTotalPages > 1 && (
          <div data-testid="prospeccao-pagination" aria-label="Paginação de contatos" className="border-t border-gray-100 px-3 py-2 flex items-center justify-between flex-shrink-0">
            <span className="text-[10px] text-gray-400">Pág. {contactsPage}/{contactsTotalPages}</span>
            <div className="flex gap-1">
              <button
                onClick={() => { if (contactsPage > 1) fetchContacts(contactsPage - 1); }}
                disabled={contactsPage <= 1}
                aria-label="Página anterior"
                className="px-2 py-0.5 text-xs border border-gray-300 rounded disabled:opacity-40 hover:bg-gray-50"
              >‹</button>
              <button
                onClick={() => { if (contactsPage < contactsTotalPages) fetchContacts(contactsPage + 1); }}
                disabled={contactsPage >= contactsTotalPages}
                aria-label="Próxima página"
                className="px-2 py-0.5 text-xs border border-gray-300 rounded disabled:opacity-40 hover:bg-gray-50"
              >›</button>
            </div>
          </div>
        )}
      </div>

      {/* ── Center column: chat timeline ──────────────────────────────────── */}
      <div className={`flex-1 flex flex-col overflow-hidden min-w-0 ${!selectedContact ? 'max-[767px]:hidden' : ''}`}>
        {!selectedContact ? (
          <div className="flex flex-col items-center justify-center h-full gap-4 text-gray-300">
            <svg className="w-16 h-16 opacity-40" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <p className="text-sm text-gray-400">Selecione um contato para ver a conversa</p>
          </div>
        ) : (
          <>
            {/* Chat header */}
            <div className="flex items-center gap-2 sm:gap-3 px-3 sm:px-5 py-3 bg-white border-b border-gray-200 flex-shrink-0">
              <button
                type="button"
                onClick={() => setSelectedContact(null)}
                className="hidden max-[767px]:inline-flex items-center justify-center w-8 h-8 rounded-lg text-gray-500 hover:bg-gray-100"
                aria-label="Voltar para contatos"
              >
                ←
              </button>
              <div className="w-9 h-9 rounded-full overflow-hidden flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                style={{ background: selectedContact.classification === 'LEAD' ? '#16a34a' : '#ea580c' }}>
                {waAvatar ? (
                  <img src={waAvatar} alt="avatar" className="w-full h-full object-cover" onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />
                ) : (selectedContact.contact_name || selectedContact.phone)[0].toUpperCase()}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <p className="font-semibold text-sm text-gray-900 truncate">
                    {selectedContact.contact_name || selectedContact.client_name_linked || formatPhone(selectedContact.phone)}
                  </p>
                  <ClassBadge c={selectedContact.classification} />
                </div>
                <p className="text-[11px] text-gray-400 font-mono">{formatPhone(selectedContact.phone)}</p>
              </div>
              {/* WhatsApp button in contact toolbar (Task #256) */}
              <button
                onClick={() => {
                  setWaModalPhone(String(selectedContact.phone).replace(/\D/g, ''));
                  setShowWaModal(true);
                }}
                className="flex items-center justify-center w-8 h-8 rounded-lg bg-green-600 hover:bg-green-700 text-white transition-colors flex-shrink-0"
                title="Enviar mensagem WhatsApp"
              >
                <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
              </button>
              {activeConvId && (
                <button
                  onClick={() => setShowCloseModal(true)}
                  className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-white rounded-lg transition-colors flex-shrink-0"
                  style={{ background: '#2d4a3e' }}
                >
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                  </svg>
                  Encerrar conversa
                </button>
              )}
              {/* Split mode toggle — only shown when panel width ≥ 1280px */}
              {isSplitAvailable && (
                <button
                  onClick={() => {
                    const next = !splitMode;
                    setSplitMode(next);
                    if (loggedUser?.id) {
                      try { localStorage.setItem(`prospeccao:splitMode:${loggedUser.id}`, String(next)); } catch {}
                    }
                  }}
                  className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-semibold border transition-colors flex-shrink-0 ${
                    splitMode
                      ? 'text-white border-transparent'
                      : 'text-gray-500 border-gray-300 hover:border-gray-400 hover:text-gray-700'
                  }`}
                  style={splitMode ? { background: '#2d4a3e' } : undefined}
                  title={splitMode ? 'Modo dividido ativo — clique para unificado' : 'Ativar modo dividido (GoTalk | uazapi)'}
                >
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17V7m0 10a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h2a2 2 0 012 2m0 10a2 2 0 002 2h2a2 2 0 002-2M9 7a2 2 0 012-2h2a2 2 0 012 2m0 10V7m0 10a2 2 0 002 2h2a2 2 0 002-2V7a2 2 0 00-2-2h-2a2 2 0 00-2 2" />
                  </svg>
                  Dividido
                </button>
              )}
            </div>
            {/* Small-screen notice: splitMode was active but panel is too narrow */}
            {splitMode && !isSplitAvailable && (
              <div className="flex items-center gap-2 px-4 py-2 bg-amber-50 border-b border-amber-200 flex-shrink-0 text-xs text-amber-700">
                <svg className="w-4 h-4 flex-shrink-0 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span>Modo dividido requer largura mínima de 1280 px. Exibindo modo unificado.</span>
              </div>
            )}

            {splitMode && isSplitAvailable ? (
              /* Split mode: two independent provider sub-columns */
              (() => {
                const resolvedGtChId = composerChannel?.gotalkChannelId || selectedContact?.uazapi_instance_id || '';
                const gtCh = resolvedGtChId ? gotalkChannels.find(c => c.id === resolvedGtChId) : null;
                const unitChs = selectedContact?.unit_id ? (unitChannelMap.get(selectedContact.unit_id) || []) : [];
                const splitGtChannelLabel = (gtCh || unitChs.find(c => c.is_primary) || unitChs[0])?.name ?? 'GoTalk';
                const splitWaChannelLabel = waInstanceInfo?.label || waInstanceInfo?.instanceId
                  || composerChannel?.uazapiInstanceId || selectedContact?.uazapi_instance_id || 'uazapi';
                // Strictly unit-scoped: GoTalk is unavailable if the contact's unit has no active channel
                const isGotalkAvailable = unitChs.some(c => c.is_active);
                const isUazapiAvailable = hasToken && waConnected === true;
                const uazapiUnavailableReason = !hasToken
                  ? 'Canal WhatsApp não configurado para esta unidade.'
                  : waConnected === null
                    ? 'Verificando conexão da instância WhatsApp…'
                    : `Instância desconectada${waInstanceInfo?.instanceId ? ` (${waInstanceInfo.instanceId})` : ''}.`;
                return (
                  <div className="flex flex-1 overflow-hidden">
                    <ProspeccaoChatColumn
                      source="gotalk"
                      messages={gtMessages}
                      channelLabel={splitGtChannelLabel}
                      isAvailable={isGotalkAvailable}
                      unavailableReason="Nenhum canal GoTalk ativo configurado."
                      sendText={splitGtText}
                      onSendTextChange={setSplitGtText}
                      onSend={() => handleSplitSend('gotalk')}
                      onSendMedia={(file, caption, asVoice) => sendMediaForSource('gotalk', file, caption, asVoice, gtEndRef, setSplitGtLoading)}
                      onOpenTemplate={() => openTemplateModalForSource('gotalk')}
                      sendLoading={splitGtLoading}
                      endRef={gtEndRef}
                      onLoadOlder={loadOlderTimeline}
                      loadingOlder={loadingMoreTimeline}
                      hasMoreOlder={hasMoreOlderTimeline}
                    />
                    <ProspeccaoChatColumn
                      source="uazapi"
                      messages={waMessages}
                      channelLabel={splitWaChannelLabel}
                      waConnected={waConnected}
                      isAvailable={isUazapiAvailable}
                      unavailableReason={uazapiUnavailableReason}
                      sendText={splitWaText}
                      onSendTextChange={setSplitWaText}
                      onSend={() => handleSplitSend('uazapi')}
                      onSendMedia={(file, caption, asVoice) => sendMediaForSource('uazapi', file, caption, asVoice, waEndRef, setSplitWaLoading)}
                      onOpenTemplate={() => openTemplateModalForSource('uazapi')}
                      sendLoading={splitWaLoading}
                      endRef={waEndRef}
                      onLoadOlder={loadOlderTimeline}
                      loadingOlder={loadingMoreTimeline}
                      hasMoreOlder={hasMoreOlderTimeline}
                      instancePhoneMap={instancePhoneMap}
                    />
                  </div>
                );
              })()
            ) : (
              /* Unified mode: single composer + timeline */
              <>
            {/* Composer — always visible; disabled when WA not available */}
            {(() => {
              const waAvailable = hasToken || isGotalkContact;
              const waOffline = !isGotalkContact && waConnected === false;
              const composerDisabled = sendLoading || !waAvailable || waOffline;
              const composerPlaceholder = !waAvailable
                ? 'WhatsApp não configurado para esta unidade'
                : waOffline
                  ? 'Instância desconectada…'
                  : 'Digite uma mensagem...';

              // Build channel indicator label — use composerChannel (explicit) as primary source
              // Falls back to contact data when composerChannel not yet initialized
              const activeSrc: 'gotalk' | 'uazapi' | null = composerChannel?.source
                ?? (selectedContact ? ((selectedContact.last_source ?? selectedContact.source) === 'uazapi' ? 'uazapi' : 'gotalk') : null);
              const isUazapi = activeSrc === 'uazapi';
              const isGotalk = activeSrc === 'gotalk';
              let channelLabel = '';
              if (isGotalk) {
                // Prefer explicit composerChannel.gotalkChannelId, fallback to contact's stored channel
                const resolvedChId = composerChannel?.gotalkChannelId || selectedContact?.uazapi_instance_id || '';
                const ch = resolvedChId ? gotalkChannels.find(c => c.id === resolvedChId) : null;
                const unitChs = selectedContact?.unit_id ? (unitChannelMap.get(selectedContact.unit_id) || []) : [];
                const gtCh = ch || unitChs.find(c => c.is_primary) || unitChs[0] || null;
                channelLabel = gtCh ? gtCh.name : 'GoTalk';
              } else if (isUazapi) {
                channelLabel = waInstanceInfo?.label || waInstanceInfo?.instanceId
                  || composerChannel?.uazapiInstanceId || selectedContact?.uazapi_instance_id || 'uazapi';
              }

              // Connection status dot (uazapi only)
              const statusDot = isUazapi
                ? waConnected === true
                  ? <span className="w-2 h-2 rounded-full bg-green-500 flex-shrink-0" title="Conectado" />
                  : waConnected === false
                    ? <span className="w-2 h-2 rounded-full bg-orange-400 flex-shrink-0" title="Desconectado" />
                    : <span className="w-2 h-2 rounded-full bg-gray-300 flex-shrink-0 animate-pulse" title="Verificando…" />
                : null;

              return (
                <div className="border-b border-gray-200 bg-white px-4 py-3 flex-shrink-0">
                  {/* Channel indicator row */}
                  {activeSrc && (
                    <div className="flex items-center gap-2 mb-2">
                      {isGotalk ? (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-700 border border-blue-200">
                          <svg className="w-2.5 h-2.5" viewBox="0 0 8 8" fill="currentColor"><circle cx="4" cy="4" r="4"/></svg>
                          GoTalk
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-50 text-green-700 border border-green-200">
                          {statusDot}
                          uazapi
                        </span>
                      )}
                      {channelLabel && (
                        <span className="text-[10px] text-gray-500 truncate max-w-[140px]" title={channelLabel}>{channelLabel}</span>
                      )}
                      {/* Task #294 — Instance-lock badge: shows the originating uazapi instance
                          when the conversation is "locked" to the number that received the last reply. */}
                      {activeSrc === 'uazapi' && selectedContact?.last_inbound_instance_id && (() => {
                        const lockedInst = selectedContact.last_inbound_instance_id;
                        const lockedLabel =
                          unitUazapiInstances.find(i => i.instanceId === lockedInst)?.label
                          || waInstanceInfo?.label
                          || (lockedInst ? lockedInst.slice(0, 8) : '');
                        return (
                          <span
                            className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-amber-50 text-amber-800 border border-amber-200"
                            title={`Respostas travadas na instância que recebeu a última mensagem: ${lockedLabel}`}
                          >
                            <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 11c-1.1 0-2 .9-2 2v3c0 1.1.9 2 2 2s2-.9 2-2v-3c0-1.1-.9-2-2-2zm6-4V6a6 6 0 10-12 0v1H4v14h16V7h-2zM8 6a4 4 0 118 0v1H8V6z"/>
                            </svg>
                            Travado em {lockedLabel}
                          </span>
                        );
                      })()}
                      <button
                        onClick={openCanalModal}
                        className="ml-auto flex-shrink-0 text-[10px] text-gray-400 hover:text-gray-600 underline transition-colors"
                        title="Trocar canal de envio"
                      >
                        Trocar canal
                      </button>
                    </div>
                  )}
                  {/* Multi-instance selector (Task #289) — uazapi only, 2+ instances */}
                  {activeSrc === 'uazapi' && unitUazapiInstances.length > 1 && (
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <span className="text-[10px] text-gray-500 flex-shrink-0">Enviar via:</span>
                      {unitUazapiInstances.map(inst => {
                        const isSelected = (composerChannel?.uazapiInstanceId || '') === inst.instanceId;
                        const dotClass = inst.isConnected === true
                          ? 'bg-green-500'
                          : inst.isConnected === false
                            ? 'bg-orange-400'
                            : 'bg-gray-300 animate-pulse';
                        return (
                          <button
                            key={inst.instanceId}
                            onClick={() => handleSelectInstance(inst.instanceId)}
                            className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-semibold border transition-all ${
                              isSelected
                                ? 'text-white border-transparent'
                                : 'bg-white text-gray-600 border-gray-300 hover:border-green-500 hover:text-green-700'
                            }`}
                            style={isSelected ? { background: '#2d4a3e' } : undefined}
                            title={inst.phoneNumber ? `${formatPhone(inst.phoneNumber)} · ${inst.label || inst.instanceId}` : inst.instanceId}
                          >
                            <span className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${dotClass}`} />
                            {inst.phoneNumber ? formatPhone(inst.phoneNumber) : (inst.label || inst.instanceId)}
                          </button>
                        );
                      })}
                    </div>
                  )}

                  {waAvailable && waOffline && (
                    <p className="text-[10px] text-orange-600 text-center mb-2">
                      Instância offline — mensagens desabilitadas até reconexão.
                    </p>
                  )}
                  <ProspeccaoComposer
                    source={isUazapi ? 'uazapi' : 'gotalk'}
                    value={sendText}
                    onChange={handleSendTextChange}
                    onSendText={handleSend}
                    onSendMedia={(file, caption, asVoice) =>
                      sendMediaForSource(isUazapi ? 'uazapi' : 'gotalk', file, caption, asVoice, timelineEndRef, setSendLoading)
                    }
                    onOpenTemplate={() => openTemplateModalForSource(isUazapi ? 'uazapi' : 'gotalk')}
                    disabled={composerDisabled}
                    sendLoading={sendLoading}
                    placeholder={composerPlaceholder}
                    allowMedia={isUazapi && !waOffline}
                    allowTemplate
                  />
                </div>
              );
            })()}

            {/* Connection status banner (#189) — only for uazapi contacts */}
            {(selectedContact.last_source ?? selectedContact.source) === 'uazapi' && hasToken && waConnected === false && (
              <div className="flex items-center gap-2 px-4 py-2.5 bg-orange-50 border-b border-orange-200 flex-shrink-0 text-xs text-orange-700">
                <svg className="w-4 h-4 flex-shrink-0 text-orange-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
                </svg>
                <span className="flex-1">
                  <strong>Instância desconectada</strong>
                  {waInstanceInfo?.instanceId && <span className="ml-1 opacity-70">({waInstanceInfo.instanceId})</span>}
                  {waInstanceInfo?.error && <span className="ml-1 opacity-70">— {waInstanceInfo.error}</span>}
                </span>
                {selectedContact.unit_id && waInstanceInfo?.instanceId && (
                  <button
                    onClick={() => setQrModalTarget({ unitId: selectedContact.unit_id!, instanceId: waInstanceInfo!.instanceId!, label: waInstanceInfo!.label })}
                    className="flex-shrink-0 flex items-center gap-1 px-2.5 py-1 rounded-lg bg-orange-600 hover:bg-orange-700 text-white font-semibold transition-colors text-[11px]"
                    title="Reconectar instância WhatsApp via QR Code"
                  >
                    <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                    </svg>
                    Conectar via QR
                  </button>
                )}
              </div>
            )}
            {(selectedContact.last_source ?? selectedContact.source) === 'uazapi' && hasToken && waConnected === null && (
              <div className="flex items-center gap-2 px-4 py-2 bg-gray-50 border-b border-gray-100 flex-shrink-0 text-xs text-gray-500">
                <svg className="w-3.5 h-3.5 animate-spin text-gray-400" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                </svg>
                Verificando conexão da instância...
              </div>
            )}

            {/* Messages area */}
            <ConversationTimeline
              ref={timelineScrollRef}
              className="flex-1 overflow-y-auto p-4 space-y-1"
              style={{
                backgroundImage: "url(\"data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23e0e0e0' fill-opacity='0.25'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E\")",
                backgroundColor: '#f0f2f5',
              }}
            >
              {loadingTimeline ? (
                <div className="flex items-center justify-center h-full text-gray-400 text-sm">
                  Carregando conversa...
                </div>
              ) : (
                <>
                  {hasMoreOlderTimeline && (
                    <div className="flex justify-center py-2">
                      <button
                        onClick={loadOlderTimeline}
                        disabled={loadingMoreTimeline}
                        className="px-3 py-1.5 text-[11px] font-semibold text-moss-700 bg-white border border-moss-200 rounded-full shadow-sm hover:bg-moss-50 transition-colors disabled:opacity-60"
                      >
                        {loadingMoreTimeline ? 'Carregando…' : 'Carregar mais 500 mensagens anteriores'}
                      </button>
                    </div>
                  )}
                  {/* Collapsible history for Recuperação */}
                  {selectedContact.classification === 'RECUPERACAO' && closedHistory.length > 0 && (
                    <div className="mb-3">
                      {closedHistory.map(conv => (
                        <div key={conv.id} className="mb-2">
                          <button
                            onClick={() => setExpandedHistory(prev => ({ ...prev, [conv.id]: !prev[conv.id] }))}
                            className="w-full flex items-center justify-between px-3 py-2 bg-orange-50 border border-orange-100 rounded-lg text-xs text-orange-700 hover:bg-orange-100 transition-colors"
                          >
                            <span className="font-semibold">
                              Conversa encerrada em {formatDate(conv.end_at)}
                              {conv.outcome && conv.outcome !== 'NAO_DEFINIDO' && (
                                <span className={`ml-2 px-1.5 py-0.5 rounded-full text-[10px] font-bold ${OUTCOME_COLORS[conv.outcome] || ''}`}>
                                  {OUTCOME_LABELS[conv.outcome] || conv.outcome}
                                </span>
                              )}
                            </span>
                            <svg
                              className={`w-3.5 h-3.5 transition-transform ${expandedHistory[conv.id] ? 'rotate-180' : ''}`}
                              fill="none" viewBox="0 0 24 24" stroke="currentColor"
                            >
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                            </svg>
                          </button>
                          {expandedHistory[conv.id] && conv.summary_text && (
                            <div className="mt-1 px-3 py-2 bg-white border border-orange-100 rounded-lg text-xs text-gray-600 leading-relaxed">
                              {conv.summary_text}
                              {conv.summary_data?.nextStep && (
                                <p className="mt-1 text-[10px] text-gray-400 italic">
                                  Próximo passo: {conv.summary_data.nextStep}
                                </p>
                              )}
                            </div>
                          )}
                        </div>
                      ))}
                      <div className="flex items-center gap-3 my-3">
                        <div className="flex-1 border-t border-gray-300" />
                        <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Conversa atual</span>
                        <div className="flex-1 border-t border-gray-300" />
                      </div>
                    </div>
                  )}

                  {/* Timeline messages */}
                  {sortedTimeline.length === 0 ? (
                    <div className="flex items-center justify-center h-32 text-gray-400 text-sm">
                      Nenhuma mensagem no histórico
                    </div>
                  ) : (
                    (() => {
                      let lastDay = '';
                      return sortedTimeline.map((msg, i) => {
                        const day = msg.sent_at ? new Date(msg.sent_at).toDateString() : '';
                        const showDay = day && day !== lastDay;
                        if (showDay) lastDay = day;
                        const isOut = msg.direction === 'OUT';
                        return (
                          <React.Fragment key={msg.id || i}>
                            {showDay && (
                              <ConversationDateSeparator className="bg-white text-gray-500 text-[10px] font-semibold px-3 py-1 rounded-full shadow-sm border border-gray-200">
                                {formatDayLabel(msg.sent_at)}
                              </ConversationDateSeparator>
                            )}
                            <div className={`flex ${isOut ? 'justify-end' : 'justify-start'}`}>
                              <ConversationBubble outgoing={isOut} className={`max-w-[75%] rounded-xl px-3 py-2 shadow-sm text-sm ${
                                isOut
                                  ? 'bg-green-100 text-gray-800 rounded-br-none'
                                  : 'bg-white text-gray-800 rounded-bl-none border border-gray-100'
                              }`}>
                                <GoTalkMediaRenderer
                                  messageType={msg.message_type}
                                  caption={msg.body}
                                  attachmentUrl={msg.attachment_url}
                                  attachmentName={msg.attachment_name}
                                  attachmentMime={msg.attachment_mime_type}
                                />
                                <div className="flex items-center justify-end gap-1 mt-0.5">
                                  {msg.operator_name && isOut && (
                                    <span className="text-[9px] text-green-700 opacity-70">{msg.operator_name}</span>
                                  )}
                                  <span className="text-[10px] text-gray-400">{formatTime(msg.sent_at)}</span>
                                  <ChannelBadge
                                    source={msg.source}
                                    detail={msg.source === 'uazapi' && msg.uazapi_instance_id
                                      ? (instancePhoneMap.get(msg.uazapi_instance_id) ? formatPhone(instancePhoneMap.get(msg.uazapi_instance_id)!) : null)
                                      : null}
                                  />
                                  {isOut && renderAckIcon(msg.ack_status)}
                                </div>
                              </ConversationBubble>
                            </div>
                          </React.Fragment>
                        );
                      });
                    })()
                  )}
                  <div ref={timelineEndRef} />
                </>
              )}
            </ConversationTimeline>
              </>
            )}

          </>
        )}
      </div>

      {/* ── Right column: contact card ────────────────────────────────────── */}
      <div className="w-72 flex-shrink-0 bg-white border-l border-gray-200 flex flex-col overflow-hidden">
        {!selectedContact ? (
          <div className="flex items-center justify-center h-full text-gray-300 text-xs p-6 text-center">
            Selecione um contato para ver os detalhes
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto">
            {/* Contact card */}
            <div className="p-5 border-b border-gray-100">
              <div className="flex items-center gap-3 mb-4">
                <div className="relative flex-shrink-0">
                  <div className="w-14 h-14 rounded-full overflow-hidden flex items-center justify-center text-white font-bold text-xl"
                    style={{ background: selectedContact.classification === 'LEAD' ? '#16a34a' : '#ea580c' }}>
                    {waAvatar ? (
                      <img src={waAvatar} alt="avatar" className="w-full h-full object-cover" onError={e => { (e.currentTarget as HTMLImageElement).style.display = 'none'; }} />
                    ) : (selectedContact.contact_name || selectedContact.phone)[0].toUpperCase()}
                  </div>
                  {waOnWa === true && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-green-500 border-2 border-white flex items-center justify-center" title="Ativo no WhatsApp">
                      <svg className="w-2 h-2 text-white" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" /></svg>
                    </span>
                  )}
                  {waOnWa === false && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-4 h-4 rounded-full bg-gray-400 border-2 border-white" title="Não encontrado no WhatsApp" />
                  )}
                </div>
                <div className="min-w-0 flex-1">
                  <p className="font-bold text-gray-900 text-sm truncate">
                    {(waInfo?.pushname || waInfo?.notifyName || waInfo?.name) || selectedContact.contact_name || selectedContact.client_name_linked || '—'}
                  </p>
                  {waInfo?.verifiedName && (
                    <p className="text-[10px] text-blue-600 flex items-center gap-1 font-medium">
                      <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" /></svg>
                      {waInfo.verifiedName}
                    </p>
                  )}
                  {/* Linked client name (#198) */}
                  {linkedClientName && (
                    <p className="text-[11px] text-green-700 font-semibold flex items-center gap-1 mt-0.5">
                      <svg className="w-3 h-3 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                      {linkedClientName}
                    </p>
                  )}
                  <div className="flex flex-wrap items-center gap-1 mt-1">
                    <ClassBadge c={selectedContact.classification} />
                    {waInfo?.isBusiness && (
                      <span className="inline-flex items-center px-1.5 py-0.5 rounded-full text-[9px] font-bold bg-teal-50 text-teal-700 uppercase tracking-wide">Empresa</span>
                    )}
                    {/* Action buttons (#198) */}
                    <button
                      onClick={() => setShowClientModal(true)}
                      title={linkedClientId ? 'Cliente já vinculado' : 'Cadastrar cliente'}
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wide transition-colors ${
                        linkedClientId
                          ? 'bg-green-100 text-green-700 cursor-default'
                          : 'bg-moss-800 text-white hover:opacity-90 cursor-pointer'
                      }`}
                      style={linkedClientId ? {} : { background: '#2d4a3e' }}
                    >
                      {linkedClientId ? (
                        <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg>
                      ) : (
                        <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg>
                      )}
                      {linkedClientId ? 'Cadastrado' : 'Cadastrar Cliente'}
                    </button>
                    <button
                      onClick={() => { if (linkedClientId) setShowAgendamentoModal(true); }}
                      disabled={!linkedClientId}
                      title={linkedClientId ? 'Agendar consulta' : 'Cadastre o cliente primeiro'}
                      className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[9px] font-bold uppercase tracking-wide transition-colors ${
                        linkedClientId
                          ? 'text-white hover:opacity-90 cursor-pointer'
                          : 'bg-gray-200 text-gray-400 cursor-not-allowed'
                      }`}
                      style={linkedClientId ? { background: '#3b82f6' } : {}}
                    >
                      <svg className="w-2.5 h-2.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                      Agendar
                    </button>
                  </div>
                </div>
              </div>

              {/* WhatsApp loading indicator */}
              {waLoading && (
                <div className="flex items-center gap-2 mb-3 text-[10px] text-gray-400">
                  <svg className="w-3 h-3 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/></svg>
                  Buscando dados do WhatsApp...
                </div>
              )}

              <div className="space-y-2.5 text-xs">
                <DetailRow label="Telefone" value={formatPhone(selectedContact.phone)} mono />
                {(linkedClientName || selectedContact.client_name_linked) && (
                  <DetailRow label="Cliente vinculado" value={linkedClientName || selectedContact.client_name_linked || ''} />
                )}
                <DetailRow label="Unidade" value={selectedContact.unit_name || '—'} />
                {/* Operator assign select */}
                <div className="flex flex-col gap-0.5">
                  <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Operador</span>
                  <select
                    value={selectedContact.operator_id || ''}
                    onChange={e => handleAssignOperator(selectedContact.id, e.target.value)}
                    disabled={assigningOperator}
                    className="w-full border border-gray-200 rounded-lg px-2 py-1 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-500 disabled:opacity-50"
                  >
                    <option value="">— Sem operador —</option>
                    {filterOperators.map(o => (
                      <option key={o.id} value={o.id}>{o.name}</option>
                    ))}
                  </select>
                </div>
                <DetailRow label="Primeiro contato" value={formatDateTime(selectedContact.first_contact_at)} />
                <DetailRow label="Último contato" value={formatDateTime(selectedContact.last_contact_at)} />
                <DetailRow label="Total de contatos" value={String(selectedContact.total_contacts)} />
                <div className="flex flex-col gap-0.5">
                  <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Provedor</span>
                  <div className="flex items-center gap-2">
                    <span className="text-gray-800">
                      {(selectedContact.last_source ?? selectedContact.source) === 'uazapi' ? 'WhatsApp (uazapi)' : 'GoTalk'}
                    </span>
                    <button
                      onClick={openCanalModal}
                      className="flex items-center gap-1 text-[11px] text-moss-700 hover:text-moss-900 border border-moss-300 hover:border-moss-500 rounded px-1.5 py-0.5 transition-colors"
                      title="Trocar canal de envio"
                    >
                      <svg xmlns="http://www.w3.org/2000/svg" className="w-3 h-3" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="M7 16V4m0 0L3 8m4-4l4 4"/>
                        <path d="M17 8v12m0 0l4-4m-4 4l-4-4"/>
                      </svg>
                      Trocar canal
                    </button>
                  </div>
                </div>
              </div>
              {selectedContact.client_id && selectedContact.id && (
                <div className="px-5 pb-4">
                  <ClientAttachmentsPanel
                    clientId={selectedContact.client_id}
                    module="COLLECTION_PROSPECTION"
                    targetType="PROSPECTION_CONTACT"
                    targetId={selectedContact.id}
                    compact
                  />
                </div>
              )}
            </div>

            {/* uazapi instance info card (#192) */}
            {(selectedContact.last_source ?? selectedContact.source) === 'uazapi' && waInstanceInfo && (
              <div className="p-5 border-b border-gray-100">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                  <span className={`inline-block w-2 h-2 rounded-full ${waInstanceInfo.isConnected ? 'bg-green-500' : 'bg-orange-400'}`} />
                  Instância uazapi
                </p>
                <div className="space-y-1.5 text-xs">
                  {waInstanceInfo.instanceId && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">ID</span>
                      <span className="text-gray-700 font-mono text-[10px] break-all">{waInstanceInfo.instanceId}</span>
                    </div>
                  )}
                  {waInstanceInfo.label && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Rótulo</span>
                      <span className="text-gray-700">{waInstanceInfo.label}</span>
                    </div>
                  )}
                  {waInstanceInfo.phoneNumber && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Número</span>
                      <span className="text-gray-700 font-mono">{waInstanceInfo.phoneNumber}</span>
                    </div>
                  )}
                  <div className="flex flex-col gap-0.5">
                    <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Status</span>
                    <span className={`font-semibold ${waInstanceInfo.isConnected ? 'text-green-600' : 'text-orange-500'}`}>
                      {waInstanceInfo.isConnected ? 'Conectado' : 'Desconectado'}
                    </span>
                  </div>
                  {waInstanceInfo.error && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Detalhe</span>
                      <span className="text-orange-600 text-[11px]">{waInstanceInfo.error}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* GoTalk profile section (#191) */}
            {(selectedContact.last_source ?? selectedContact.source) === 'gotalk' && gtProfile && (
              <div className="p-5 border-b border-gray-100">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                  <span className="inline-flex items-center justify-center w-3.5 h-3.5 rounded-full bg-green-100 text-green-700 font-bold text-[8px]">G</span>
                  GoTalk
                </p>
                <div className="space-y-1.5 text-xs">
                  {gtProfile.name && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Nome no GoTalk</span>
                      <span className="text-gray-700">{gtProfile.name}</span>
                    </div>
                  )}
                  {gtProfile.channelName && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Canal</span>
                      <span className="text-gray-700">{gtProfile.channelName}</span>
                    </div>
                  )}
                  {gtProfile.gotalkId && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">ID GoTalk</span>
                      <span className="text-gray-500 font-mono text-[10px] break-all">{gtProfile.gotalkId}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* WhatsApp info section */}
            {waInfo && (waInfo.about || waInfo.description || waInfo.businessCategory || waInfo.businessDescription) && (
              <div className="p-5 border-b border-gray-100">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3 flex items-center gap-1.5">
                  <svg className="w-3.5 h-3.5 text-green-500" viewBox="0 0 24 24" fill="currentColor">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                  WhatsApp
                </p>
                <div className="space-y-2 text-xs">
                  {(waInfo.about || waInfo.description) && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Sobre</span>
                      <span className="text-gray-700 leading-relaxed">{waInfo.about || waInfo.description}</span>
                    </div>
                  )}
                  {waInfo.businessCategory && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Categoria</span>
                      <span className="text-gray-700">{waInfo.businessCategory}</span>
                    </div>
                  )}
                  {waInfo.businessDescription && (
                    <div className="flex flex-col gap-0.5">
                      <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Descrição empresarial</span>
                      <span className="text-gray-700 leading-relaxed">{waInfo.businessDescription}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Last closed conversation summary */}
            {lastClosedConv && (
              <div className="p-5">
                <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Último resumo</p>
                <div className="bg-gray-50 rounded-lg p-3 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-gray-400">{formatDate(lastClosedConv.end_at)}</span>
                    {lastClosedConv.outcome && (
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${OUTCOME_COLORS[lastClosedConv.outcome] || 'bg-gray-100 text-gray-600'}`}>
                        {OUTCOME_LABELS[lastClosedConv.outcome] || lastClosedConv.outcome}
                      </span>
                    )}
                  </div>
                  {lastClosedConv.summary_text && (
                    <p className="text-xs text-gray-700 leading-relaxed">{lastClosedConv.summary_text}</p>
                  )}
                  {lastClosedConv.summary_data?.nextStep && (
                    <p className="text-[11px] text-gray-500 italic border-t border-gray-200 pt-2">
                      <span className="font-semibold not-italic text-gray-600">Próx. passo:</span>{' '}
                      {lastClosedConv.summary_data.nextStep}
                    </p>
                  )}
                </div>
              </div>
            )}

            {/* Active conversation info */}
            {activeConvId && (
              <div className="px-5 pb-2">
                <div className="flex items-center gap-2 text-[10px] text-green-700 bg-green-50 border border-green-100 rounded-lg px-3 py-2">
                  <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse flex-shrink-0" />
                  Conversa ativa em andamento
                </div>
              </div>
            )}

            {/* ── Agendamentos (#198) ──────────────────────────────────── */}
            {linkedClientId && (
              <div className="px-5 pb-3 pt-3 border-t-2 border-indigo-100 mt-2">
                {/* Vivid header */}
                <button
                  onClick={() => setApptSectionOpen(o => !o)}
                  className="w-full flex items-center justify-between mb-0 group"
                >
                  <span className="flex items-center gap-2">
                    <span className="flex items-center justify-center w-6 h-6 rounded-lg bg-indigo-600 shadow-sm">
                      <svg className="w-3.5 h-3.5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                      </svg>
                    </span>
                    <span className="text-[11px] font-extrabold text-indigo-700 uppercase tracking-widest group-hover:text-indigo-900 transition-colors">
                      Agendamentos
                    </span>
                    {contactAppointments.length > 0 && (
                      <span className="bg-indigo-600 text-white text-[9px] font-bold px-1.5 py-0.5 rounded-full shadow-sm">
                        {contactAppointments.length}
                      </span>
                    )}
                  </span>
                  <svg
                    className={`w-3.5 h-3.5 text-indigo-400 transition-transform ${apptSectionOpen ? 'rotate-180' : ''}`}
                    fill="none" stroke="currentColor" viewBox="0 0 24 24"
                  >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                  </svg>
                </button>

                {apptSectionOpen && (
                  <div className="mt-3">
                    {loadingApptSection ? (
                      <div className="flex items-center gap-2 text-[10px] text-gray-400">
                        <svg className="w-3 h-3 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/></svg>
                        Carregando...
                      </div>
                    ) : contactAppointments.length === 0 ? (
                      <p className="text-[11px] text-gray-400 italic">Nenhum agendamento encontrado.</p>
                    ) : (
                      <div className="space-y-2">
                        {contactAppointments.map((appt: any) => {
                          const statusColors: Record<string, string> = {
                            AGENDADO: 'bg-blue-100 text-blue-700',
                            AGUARDANDO: 'bg-amber-100 text-amber-700',
                            CONFIRMADO: 'bg-green-100 text-green-700',
                            CANCELADO_CLIENTE: 'bg-red-100 text-red-700',
                            CANCELADO_CONSULTOR: 'bg-gray-100 text-gray-600',
                            NAO_COMPARECEU: 'bg-red-200 text-red-800',
                          };
                          const statusLabels: Record<string, string> = {
                            AGENDADO: 'Agendado', AGUARDANDO: 'Aguardando', CONFIRMADO: 'Confirmado',
                            CANCELADO_CLIENTE: 'Cancelado', CANCELADO_CONSULTOR: 'Canc. consultor',
                            NAO_COMPARECEU: 'Não compareceu',
                          };
                          const modalidadeCfg: Record<string, { label: string; style: React.CSSProperties }> = {
                            PRESENCIAL: { label: 'Presencial', style: { background: '#fff7ed', color: '#ea580c', border: '1px solid #fed7aa' } },
                            ONLINE:     { label: 'Online',     style: { background: '#eff6ff', color: '#2563eb', border: '1px solid #bfdbfe' } },
                          };
                          // Normalize date: handle both 'YYYY-MM-DD' and ISO strings
                          const rawDate = (appt.date || '').substring(0, 10);
                          const [y, m, d] = rawDate.split('-');
                          const dateStr = rawDate.length === 10 ? `${d}/${m}/${y}` : '—';
                          const timeRange = (appt.start_time && appt.end_time) ? `${appt.start_time}–${appt.end_time}` : '';
                          const modCfg = appt.modalidade ? modalidadeCfg[appt.modalidade] : null;
                          const isCancelled = ['CANCELADO_CLIENTE', 'CANCELADO_CONSULTOR'].includes(appt.status);
                          const isShowingCancel = cancellingApptId === appt.id;
                          return (
                            <div key={appt.id} className="rounded-xl border border-indigo-100 bg-indigo-50 px-3 py-2.5">
                              {/* Date + time row */}
                              <div className="flex items-center justify-between mb-1">
                                <p className="text-[11px] font-bold text-indigo-800">
                                  {dateStr}{timeRange ? ` · ${timeRange}` : ''}
                                </p>
                                <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ml-2 flex-shrink-0 ${statusColors[appt.status] || 'bg-gray-100 text-gray-600'}`}>
                                  {statusLabels[appt.status] || appt.status}
                                </span>
                              </div>
                              {/* Collaborator + modalidade row */}
                              <div className="flex items-center gap-1.5 flex-wrap">
                                {(() => {
                                  const collabName = appt.collaborator_name || (appt.collaborator_id ? collaboratorMap.get(appt.collaborator_id) : null);
                                  return collabName ? (
                                    <span className="flex items-center gap-1 text-[10px] text-gray-600">
                                      <svg className="w-2.5 h-2.5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                      </svg>
                                      {collabName}
                                    </span>
                                  ) : null;
                                })()}
                                {modCfg && (
                                  <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full" style={modCfg.style}>
                                    {modCfg.label}
                                  </span>
                                )}
                              </div>
                              {appt.notes && (
                                <p className="text-[10px] text-gray-500 truncate mt-1">{appt.notes}</p>
                              )}
                              {/* Action buttons — only for non-cancelled appointments */}
                              {!isCancelled && (
                                <div className="mt-2 pt-2 border-t border-indigo-100">
                                  {isShowingCancel ? (
                                    /* Inline cancel confirmation */
                                    <div className="flex items-center gap-1.5">
                                      <p className="text-[10px] text-red-600 font-medium flex-1">Confirmar cancelamento?</p>
                                      <button
                                        disabled={cancellingApptLoading}
                                        onClick={() => handleCancelAppointment(appt)}
                                        className="text-[9px] font-bold px-2 py-1 rounded bg-red-500 text-white hover:bg-red-600 transition-colors disabled:opacity-50"
                                      >
                                        {cancellingApptLoading ? '...' : 'Sim'}
                                      </button>
                                      <button
                                        disabled={cancellingApptLoading}
                                        onClick={() => setCancellingApptId(null)}
                                        className="text-[9px] font-bold px-2 py-1 rounded bg-gray-200 text-gray-700 hover:bg-gray-300 transition-colors disabled:opacity-50"
                                      >
                                        Não
                                      </button>
                                    </div>
                                  ) : (
                                    /* Alterar / Cancelar buttons */
                                    <div className="flex items-center gap-1.5">
                                      <button
                                        onClick={() => { setEditingAppt(appt); setShowAgendamentoModal(true); }}
                                        className="flex items-center gap-1 text-[10px] font-semibold px-2 py-1 rounded-lg bg-indigo-100 text-indigo-700 hover:bg-indigo-200 transition-colors"
                                      >
                                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                                        </svg>
                                        Alterar
                                      </button>
                                      <button
                                        onClick={() => setCancellingApptId(appt.id)}
                                        className="flex items-center gap-1 text-[10px] font-semibold px-2 py-1 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-colors"
                                      >
                                        <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                        </svg>
                                        Cancelar
                                      </button>
                                    </div>
                                  )}
                                </div>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* ── Anotações acumulativas ─────────────────────────────────── */}
            <div className="px-5 pb-5 pt-3 border-t border-gray-100 mt-2">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-3">Anotações</p>

              {/* Existing notes */}
              {loadingNotes ? (
                <div className="flex items-center gap-2 text-[10px] text-gray-400 mb-3">
                  <svg className="w-3 h-3 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/></svg>
                  Carregando...
                </div>
              ) : (
                <div className="space-y-3 mb-4">
                  {notes.length === 0 && (
                    <p className="text-[11px] text-gray-400 italic">Nenhuma anotação ainda.</p>
                  )}
                  {notes.map(note => (
                    <div key={note.id} className="bg-amber-50 border border-amber-100 rounded-lg p-3 text-xs">
                      {/* Note header */}
                      <div className="flex items-start justify-between gap-1 mb-1.5">
                        <div>
                          <span className="font-semibold text-gray-700">{note.user_name}</span>
                          <span className="text-[10px] text-gray-400 ml-2">{formatDateTime(note.created_at)}</span>
                          {note.updated_at !== note.created_at && (
                            <span className="text-[10px] text-gray-400 ml-1">(editado)</span>
                          )}
                        </div>
                        <div className="flex items-center gap-1 flex-shrink-0">
                          {(loggedUser?.role === 'ADMIN' || loggedUser?.id === note.user_id) && editingNoteId !== note.id && (
                            <>
                              <button
                                onClick={() => handleStartEditNote(note)}
                                className="p-1 rounded hover:bg-amber-200 text-gray-500 hover:text-gray-700 transition-colors"
                                title="Editar"
                              >
                                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                              </button>
                              <button
                                onClick={() => handleDeleteNote(note.id)}
                                className="p-1 rounded hover:bg-red-100 text-gray-400 hover:text-red-600 transition-colors"
                                title="Remover"
                              >
                                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                              </button>
                            </>
                          )}
                        </div>
                      </div>

                      {/* Note body — view or edit */}
                      {editingNoteId === note.id ? (
                        <div className="space-y-2">
                          <textarea
                            value={editNoteText}
                            onChange={e => setEditNoteText(e.target.value)}
                            rows={3}
                            className="w-full border border-amber-300 rounded-lg px-2 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-amber-400 resize-none"
                          />
                          {/* Edit attachments */}
                          {note.attachments.map((att, i) => (
                            <div key={i} className="flex items-center gap-1 bg-white border border-gray-200 rounded px-2 py-1">
                              <svg className="w-3 h-3 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                              <span className="text-[10px] text-gray-600 flex-1 truncate">{att.name}</span>
                              <button onClick={() => handleDeleteNoteAttachment(note.id, i)} className="text-gray-400 hover:text-red-500 ml-1">
                                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                              </button>
                            </div>
                          ))}
                          <div className="flex items-center gap-2">
                            <button
                              onClick={() => editFileRef.current?.click()}
                              className="text-[10px] text-gray-500 hover:text-gray-700 flex items-center gap-1 underline"
                            >
                              <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                              Anexar arquivo
                            </button>
                            <input ref={editFileRef} type="file" multiple className="hidden" onChange={e => handleNoteFileChange(e, true)} />
                          </div>
                          <div className="flex gap-2 pt-1">
                            <button
                              onClick={() => handleSaveEditNote(note.id)}
                              className="flex-1 bg-amber-500 hover:bg-amber-600 text-white rounded-lg px-3 py-1 text-[11px] font-semibold transition-colors"
                            >
                              Salvar
                            </button>
                            <button
                              onClick={() => setEditingNoteId(null)}
                              className="flex-1 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-lg px-3 py-1 text-[11px] font-semibold transition-colors"
                            >
                              Cancelar
                            </button>
                          </div>
                        </div>
                      ) : (
                        <>
                          {note.note_text && (
                            <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">{note.note_text}</p>
                          )}
                          {note.attachments.length > 0 && (
                            <div className="mt-2 space-y-1">
                              {note.attachments.map((att, i) => (
                                <a
                                  key={i}
                                  href={att.data}
                                  download={att.name}
                                  className="flex items-center gap-1 bg-white border border-gray-200 rounded px-2 py-1 hover:bg-gray-50 transition-colors"
                                >
                                  <svg className="w-3 h-3 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                                  <span className="text-[10px] text-blue-600 hover:underline truncate">{att.name}</span>
                                </a>
                              ))}
                            </div>
                          )}
                        </>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* New note form */}
              <div className="space-y-2">
                <textarea
                  value={newNoteText}
                  onChange={e => setNewNoteText(e.target.value)}
                  placeholder="Nova anotação..."
                  rows={3}
                  className="w-full border border-gray-200 rounded-lg px-2.5 py-2 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-amber-400 resize-none placeholder-gray-400"
                />
                {/* New attachments preview */}
                {newNoteAttachments.length > 0 && (
                  <div className="space-y-1">
                    {newNoteAttachments.map((att, i) => (
                      <div key={i} className="flex items-center gap-1 bg-gray-50 border border-gray-200 rounded px-2 py-1">
                        <svg className="w-3 h-3 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                        <span className="text-[10px] text-gray-600 flex-1 truncate">{att.name}</span>
                        <button onClick={() => handleDeleteNoteAttachment('', i, true)} className="text-gray-400 hover:text-red-500 ml-1">
                          <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => noteFileRef.current?.click()}
                    className="text-[10px] text-gray-500 hover:text-gray-700 flex items-center gap-1 underline"
                  >
                    <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                    Anexar arquivo
                  </button>
                  <input ref={noteFileRef} type="file" multiple className="hidden" onChange={e => handleNoteFileChange(e, false)} />
                  <button
                    onClick={handleSaveNote}
                    disabled={savingNote || (!newNoteText.trim() && newNoteAttachments.length === 0)}
                    className="ml-auto bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white rounded-lg px-3 py-1 text-[11px] font-semibold transition-colors flex items-center gap-1"
                  >
                    {savingNote ? (
                      <svg className="w-3 h-3 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z"/></svg>
                    ) : (
                      <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                    )}
                    Adicionar
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* ── Close conversation modal ──────────────────────────────────────── */}
      {showCloseModal && activeConvId && (
        <CloseConversationModal
          conversationId={activeConvId}
          onClose={() => setShowCloseModal(false)}
          onConfirm={handleCloseConversation}
        />
      )}

      {/* ── Quick client registration modal (#198) ────────────────────────── */}
      {showClientModal && selectedContact && (
        <ProspeccaoClientModal
          phone={selectedContact.phone}
          contactName={selectedContact.contact_name || (waInfo?.pushname || waInfo?.notifyName || waInfo?.name) || undefined}
          onClose={() => setShowClientModal(false)}
          onCreated={handleClientCreated}
        />
      )}

      {/* ── Quick scheduling / edit modal ────────────────────────────────── */}
      {showAgendamentoModal && selectedContact && linkedClientId && linkedClientName && (
        <ProspeccaoAgendamentoModal
          contactId={selectedContact.id}
          clientId={linkedClientId}
          clientName={linkedClientName}
          unitId={selectedContact.unit_id}
          unitName={selectedContact.unit_name}
          onClose={() => { setShowAgendamentoModal(false); setEditingAppt(null); }}
          onSaved={handleAppointmentSaved}
          initialAppointment={editingAppt ?? undefined}
        />
      )}

      {/* ── QR Code reconnect modal (unified) ───────────────────────────── */}
      {qrModalTarget && (
        <UazapiQrModal
          unitId={qrModalTarget.unitId}
          instanceId={qrModalTarget.instanceId}
          instanceLabel={qrModalTarget.label}
          onClose={() => setQrModalTarget(null)}
          onConnected={(_phone) => {
            // Update left-panel instance list
            setUnitInstances(prev => prev.map(inst =>
              inst.unitId === qrModalTarget.unitId && inst.instanceId === qrModalTarget.instanceId
                ? { ...inst, isConnected: true, error: null }
                : inst
            ));
            // Update right-panel banner (if the connected instance matches the selected contact)
            if (selectedContact?.unit_id === qrModalTarget.unitId && waInstanceInfo?.instanceId === qrModalTarget.instanceId) {
              setWaConnected(true);
              setWaInstanceInfo(prev => prev ? { ...prev, isConnected: true, error: null } : prev);
            }
            setQrModalTarget(null);
          }}
        />
      )}
      </div>
      )}

      {/* ── Modal "Trocar canal" (Task #240) ─────────────────────────────── */}
      {showCanalModal && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/40" onClick={() => !canalSaving && setShowCanalModal(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 p-6" onClick={e => e.stopPropagation()}>
            <h3 className="text-base font-bold text-gray-800 mb-4">Trocar canal de envio</h3>

            {/* Source select */}
            <div className="mb-4">
              <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Provedor</label>
              <div className="flex gap-2">
                {(['gotalk', 'uazapi'] as const).map(src => (
                  <button
                    key={src}
                    onClick={() => {
                      setCanalNewSource(src);
                      if (src === 'uazapi' && canalInstances.length > 0 && !canalNewInstanceId) {
                        setCanalNewInstanceId(canalInstances[0].instanceId);
                      }
                    }}
                    className={`flex-1 py-2 rounded-lg border text-sm font-medium transition-colors ${
                      canalNewSource === src
                        ? 'bg-moss-700 text-white border-moss-700'
                        : 'bg-gray-50 text-gray-700 border-gray-200 hover:border-moss-400'
                    }`}
                  >
                    {src === 'uazapi' ? 'WhatsApp (uazapi)' : 'GoTalk'}
                  </button>
                ))}
              </div>
            </div>

            {/* GoTalk channel select (only when gotalk) */}
            {canalNewSource === 'gotalk' && (() => {
              const unitChs = selectedContact?.unit_id
                ? (unitChannelMap.get(selectedContact.unit_id) || [])
                : [];
              const usingFallback = unitChs.length === 0 && gotalkChannels.length > 0;
              const displayChs = usingFallback ? gotalkChannels : unitChs;
              return (
                <div className="mb-4">
                  <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Canal GoTalk</label>
                  {gotalkChannelsError ? (
                    <p className="text-xs text-red-600 py-1">
                      Erro ao carregar canais GoTalk. Recarregue a página e tente novamente.
                    </p>
                  ) : displayChs.length === 0 ? (
                    <p className="text-xs text-amber-600 py-1">
                      Nenhum canal GoTalk ativo encontrado. Verifique a configuração em Configurações → Mensagens GoTalk.
                    </p>
                  ) : (
                    <>
                      {usingFallback && (
                        <p className="text-xs text-blue-600 bg-blue-50 rounded px-2 py-1 mb-2">
                          Exibindo todos os canais ativos — nenhum canal específico para esta unidade.
                        </p>
                      )}
                      <select
                        value={canalNewGotalkChannelId}
                        onChange={e => setCanalNewGotalkChannelId(e.target.value)}
                        className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-800 bg-white focus:outline-none focus:ring-2 focus:ring-moss-400"
                      >
                        <option value="">— selecione —</option>
                        {displayChs.map(ch => (
                          <option key={ch.id} value={ch.id}>
                            {ch.name}{ch.phone_number ? ` (${ch.phone_number})` : ''}{ch.is_primary ? ' ★' : ''}{ch.unit_name && usingFallback ? ` [${ch.unit_name}]` : ''}
                          </option>
                        ))}
                      </select>
                    </>
                  )}
                </div>
              );
            })()}

            {/* Unit + Instance selects (only when uazapi) — Task #248 */}
            {canalNewSource === 'uazapi' && (
              <>
                {canalInstancesLoading ? (
                  <div className="mb-4">
                    <p className="text-xs text-gray-400 py-1">Carregando unidades e instâncias…</p>
                  </div>
                ) : canalUazapiUnits.length === 0 ? (
                  <div className="mb-4">
                    <p className="text-xs text-amber-600 py-1">
                      Nenhum token uazapi configurado em nenhuma unidade. Configure as credenciais em Cadastros → Unidades antes de usar este canal.
                    </p>
                  </div>
                ) : (
                  <>
                    {/* Unit picker */}
                    <div className="mb-3">
                      <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Unidade</label>
                      <select
                        value={canalNewUazapiUnitId}
                        onChange={e => {
                          const uid = e.target.value;
                          setCanalNewUazapiUnitId(uid);
                          const unit = canalUazapiUnits.find(u => u.unit_id === uid);
                          const insts = unit?.instances || [];
                          setCanalInstances(insts);
                          setCanalNewInstanceId(insts[0]?.instanceId || '');
                        }}
                        className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-800 bg-white focus:outline-none focus:ring-2 focus:ring-moss-400"
                      >
                        <option value="">— selecione a unidade —</option>
                        {canalUazapiUnits.map(u => (
                          <option key={u.unit_id} value={u.unit_id}>
                            {u.is_current_unit ? '★ ' : ''}{u.unit_name || u.unit_id}
                          </option>
                        ))}
                      </select>
                    </div>
                    {/* Instance picker */}
                    {canalInstances.length > 0 && (
                      <div className="mb-4">
                        <label className="block text-xs font-semibold text-gray-500 uppercase tracking-wide mb-1.5">Instância uazapi</label>
                        <select
                          value={canalNewInstanceId}
                          onChange={e => setCanalNewInstanceId(e.target.value)}
                          className="w-full border border-gray-200 rounded-lg px-3 py-2 text-sm text-gray-800 bg-white focus:outline-none focus:ring-2 focus:ring-moss-400"
                        >
                          <option value="">— selecione —</option>
                          {canalInstances.map(inst => {
                            const num = inst.phoneNumber ? formatPhone(inst.phoneNumber) : null;
                            const base = num
                              ? (inst.label ? `${num} — ${inst.label}` : num)
                              : (inst.label ? `${inst.label} (${inst.instanceId})` : inst.instanceId);
                            return (
                              <option key={inst.instanceId} value={inst.instanceId}>
                                {base}{formatInboundStale(inst.lastInboundAt)}
                              </option>
                            );
                          })}
                        </select>
                      </div>
                    )}
                  </>
                )}
              </>
            )}

            <div className="flex justify-end gap-2 mt-2">
              <button
                onClick={() => setShowCanalModal(false)}
                disabled={canalSaving}
                className="px-4 py-2 rounded-lg text-sm text-gray-600 border border-gray-200 hover:bg-gray-50 transition-colors disabled:opacity-50"
              >
                Cancelar
              </button>
              <button
                onClick={handleSaveCanalChange}
                disabled={
                  canalSaving ||
                  (canalNewSource === 'uazapi' && (!canalNewUazapiUnitId || !canalNewInstanceId)) ||
                  (canalNewSource === 'gotalk' && !canalNewGotalkChannelId &&
                    Boolean(selectedContact?.unit_id && unitChannelMap.get(selectedContact.unit_id)?.length))
                }
                className="px-4 py-2 rounded-lg text-sm font-semibold bg-moss-700 text-white hover:bg-moss-800 transition-colors disabled:opacity-50"
              >
                {canalSaving ? 'Salvando…' : 'Confirmar'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Nova mensagem WhatsApp modal (Task #256) */}
      {showWaModal && (
        <ProspeccaoWhatsappModal
          initialPhone={waModalPhone}
          onClose={() => { setShowWaModal(false); setWaModalPhone(''); }}
          onOptimisticInsert={handleWaOptimisticInsert}
          onSent={handleWaModalSent}
          onSendFailed={handleWaModalFailed}
        />
      )}

      {/* Template HSM modal (Task #311) — acionável pelo compositor */}
      {showTemplateModal && selectedContact && (
        <GotalkSendTemplateModal
          isOpen={showTemplateModal}
          onClose={() => setShowTemplateModal(false)}
          contactPhone={selectedContact.phone}
          contactName={selectedContact.contact_name || 'Contato'}
          mode={templateMode}
          onUazapiSend={async (renderedBody) => { await sendTemplateAsUazapiText(renderedBody); }}
          onSuccess={() => addToast('success', 'Template enviado', 'Template enviado com sucesso.')}
          onError={(msg) => addToast('error', 'Erro no template', msg)}
        />
      )}

      {/* WhatsApp inbound toast notifications */}
      <MessageToast
        toasts={waToasts}
        onDismiss={(id) => setWaToasts(prev => prev.filter(t => t.id !== id))}
        onView={(toast) => {
          if (toast.conversationId) {
            const contact = contactsRef.current.find(c => c.id === toast.conversationId);
            if (contact) selectContact(contact);
          }
          setWaToasts(prev => prev.filter(t => t.id !== toast.id));
        }}
      />
    </div>
  );
};

// ── Detail row helper ──────────────────────────────────────────────────────────

const DetailRow: React.FC<{ label: string; value: string; mono?: boolean }> = ({ label, value, mono }) => (
  <div className="flex flex-col gap-0.5">
    <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">{label}</span>
    <span className={`text-gray-800 ${mono ? 'font-mono' : ''}`}>{value}</span>
  </div>
);

export default ProspeccaoPanel;

import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  LineElement,
  PointElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Bar, Line } from 'react-chartjs-2';
import { useDashboardInvalidation } from '../../contexts/useDashboardInvalidation';

ChartJS.register(
  CategoryScale, LinearScale, BarElement, LineElement,
  PointElement, Title, Tooltip, Legend, Filler
);

// ── Types ──────────────────────────────────────────────────────────────────────

interface DashboardKpi {
  total_contacts: string;
  total_leads: string;
  total_recuperacoes: string;
  total_conversations: string;
  total_encerradas: string;
  interesse_alto: string;
  interesse_medio: string;
  interesse_baixo: string;
  sem_interesse: string;
  total_agendados: string;
}

interface ByUnitRow {
  unit_name: string;
  total: string;
  leads: string;
  recuperacoes: string;
}

interface ByOperatorRow {
  operator_name: string;
  unit_name: string;
  total_conversations: string;
  leads: string;
  recuperacoes: string;
  interesse_alto: string;
  encerradas: string;
}

interface TimeSeriesRow {
  bucket: string;
  leads: string;
  recuperacoes: string;
}

interface ByModalidadeRow {
  modalidade: string;
  total: string;
  agendados: string;
  cancelados: string;
}

interface GotalkChannel {
  id: string;
  name: string;
  phone_number: string;
  is_active: boolean;
  is_primary: boolean;
}

interface WaUnitRow {
  unit_id: string;
  unit_name: string;
  messages_in: number;
  messages_out: number;
  active_phones: number;
  leads: number;
  recuperacoes: number;
  gotalk_active_channels: number;
  gotalk_total_channels: number;
  gotalk_channels: GotalkChannel[];
  uazapi_instances: number;
  uazapi_status: 'connected' | 'disconnected' | 'not_configured' | 'error' | 'unknown';
}

interface DashboardData {
  kpi: DashboardKpi;
  byUnit: ByUnitRow[];
  byOperator: ByOperatorRow[];
  timeSeries: TimeSeriesRow[];
  byModalidade: ByModalidadeRow[];
  groupBy: string;
}

interface ReportRow {
  [key: string]: string | number | null;
}

// ── Constants ──────────────────────────────────────────────────────────────────

const MOSS = '#2d4a3e';
const LEAD_COLOR = 'rgba(22,163,74,0.75)';
const LEAD_BORDER = '#16a34a';
const REC_COLOR = 'rgba(234,88,12,0.75)';
const REC_BORDER = '#ea580c';

const OUTCOME_LABELS: Record<string, string> = {
  INTERESSE_ALTO: 'Interesse Alto',
  INTERESSE_MEDIO: 'Interesse Médio',
  INTERESSE_BAIXO: 'Interesse Baixo',
  SEM_INTERESSE: 'Sem Interesse',
  NAO_DEFINIDO: 'Não Definido',
};

const MODALIDADE_CONFIG: Record<string, { label: string; color: string; bg: string; icon: string }> = {
  PRESENCIAL: { label: 'Presencial', color: '#1d4ed8', bg: '#eff6ff', icon: '🏢' },
  ONLINE:     { label: 'Online',     color: '#7c3aed', bg: '#f5f3ff', icon: '💻' },
  SEM_MODALIDADE: { label: 'Sem Modalidade', color: '#6b7280', bg: '#f9fafb', icon: '❓' },
};

const REPORT_COLUMNS: Record<string, { key: string; label: string }[]> = {
  leads: [
    { key: 'nome', label: 'Nome' },
    { key: 'telefone', label: 'Telefone' },
    { key: 'unidade', label: 'Unidade' },
    { key: 'operador', label: 'Operador' },
    { key: 'canal', label: 'Canal' },
    { key: 'primeiro_contato', label: 'Primeiro Contato' },
    { key: 'ultimo_contato', label: 'Último Contato' },
  ],
  recuperacoes: [
    { key: 'nome', label: 'Nome' },
    { key: 'telefone', label: 'Telefone' },
    { key: 'unidade', label: 'Unidade' },
    { key: 'operador', label: 'Operador' },
    { key: 'canal', label: 'Canal' },
    { key: 'primeiro_contato', label: 'Primeiro Contato' },
    { key: 'ultimo_contato', label: 'Último Contato' },
  ],
  agendados: [
    { key: 'cliente', label: 'Cliente' },
    { key: 'data', label: 'Data' },
    { key: 'hora_inicio', label: 'Hora' },
    { key: 'modalidade', label: 'Modalidade' },
    { key: 'status', label: 'Status' },
    { key: 'consultor', label: 'Consultor' },
    { key: 'unidade', label: 'Unidade' },
    { key: 'telefone', label: 'Telefone' },
  ],
  cancelados: [
    { key: 'cliente', label: 'Cliente' },
    { key: 'data', label: 'Data' },
    { key: 'hora_inicio', label: 'Hora' },
    { key: 'modalidade', label: 'Modalidade' },
    { key: 'status', label: 'Motivo' },
    { key: 'consultor', label: 'Consultor' },
    { key: 'unidade', label: 'Unidade' },
    { key: 'telefone', label: 'Telefone' },
  ],
  encerramento: [
    { key: 'desfecho', label: 'Desfecho' },
    { key: 'operador', label: 'Operador' },
    { key: 'unidade', label: 'Unidade' },
    { key: 'tipo_contato', label: 'Tipo Contato' },
    { key: 'canal', label: 'Canal' },
    { key: 'inicio', label: 'Início' },
    { key: 'encerramento', label: 'Encerrado em' },
  ],
  modalidade: [
    { key: 'cliente', label: 'Cliente' },
    { key: 'data', label: 'Data' },
    { key: 'hora_inicio', label: 'Hora' },
    { key: 'modalidade', label: 'Modalidade' },
    { key: 'status', label: 'Status' },
    { key: 'consultor', label: 'Consultor' },
    { key: 'unidade', label: 'Unidade' },
    { key: 'telefone', label: 'Telefone' },
  ],
};

const REPORT_TABS = [
  { key: 'leads',         label: 'Leads',              color: '#16a34a' },
  { key: 'recuperacoes',  label: 'Recuperações',        color: '#ea580c' },
  { key: 'agendados',     label: 'Agendamentos',        color: '#7c3aed' },
  { key: 'cancelados',    label: 'Cancelados',          color: '#ef4444' },
  { key: 'encerramento',  label: 'Encerramento por Tipo', color: '#6b7280' },
];

const BAR_OPTIONS = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { position: 'top' as const, labels: { font: { size: 11 }, boxWidth: 14 } },
    tooltip: { mode: 'index' as const, intersect: false },
  },
  scales: {
    x: { ticks: { font: { size: 11 } }, grid: { display: false } },
    y: { ticks: { font: { size: 11 } }, beginAtZero: true, grid: { color: '#f0f0f0' } },
  },
};

const LINE_OPTIONS = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: { position: 'top' as const, labels: { font: { size: 11 }, boxWidth: 14 } },
    tooltip: { mode: 'index' as const, intersect: false },
  },
  scales: {
    x: { ticks: { font: { size: 11 }, maxRotation: 45 }, grid: { display: false } },
    y: { ticks: { font: { size: 11 } }, beginAtZero: true, grid: { color: '#f0f0f0' } },
  },
};

// ── Helpers ────────────────────────────────────────────────────────────────────

function n(v: string | number | undefined): number {
  return Number(v) || 0;
}

function fmtBucket(bucket: string, groupBy: string): string {
  if (!bucket) return '';
  const d = new Date(bucket);
  if (groupBy === 'month') return d.toLocaleDateString('pt-BR', { month: 'short', year: '2-digit' });
  if (groupBy === 'week') return `Sem. ${d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' })}`;
  return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit' });
}

function fmtDate(val: string | null | undefined): string {
  if (!val) return '—';
  try {
    const d = new Date(val);
    return d.toLocaleDateString('pt-BR');
  } catch { return val; }
}

function fmtDateTime(val: string | null | undefined): string {
  if (!val) return '—';
  try {
    const d = new Date(val);
    return d.toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' });
  } catch { return val; }
}

function fmtCellValue(key: string, val: string | number | null): string {
  if (val === null || val === undefined) return '—';
  const strVal = String(val);
  if (!strVal) return '—';
  if (['primeiro_contato', 'ultimo_contato', 'inicio', 'encerramento'].includes(key)) return fmtDateTime(strVal);
  if (key === 'data') return fmtDate(strVal);
  if (key === 'desfecho') return OUTCOME_LABELS[strVal] || strVal;
  return strVal;
}

function periodLabel(period: string, dateFrom: string, dateTo: string): string {
  if (period === 'today') return 'Hoje';
  if (period === '7d') return 'Últimos 7 dias';
  if (period === '30d') return 'Últimos 30 dias';
  if (period === 'custom') {
    const from = dateFrom ? fmtDate(dateFrom) : '?';
    const to = dateTo ? fmtDate(dateTo) : '?';
    return `${from} a ${to}`;
  }
  return period;
}

// ── Export utilities ───────────────────────────────────────────────────────────

async function exportToExcel(sheets: { name: string; rows: ReportRow[]; columns: { key: string; label: string }[] }[], filename: string) {
  const XLSX = await import('xlsx');
  const wb = XLSX.utils.book_new();
  for (const sheet of sheets) {
    const wsData = [
      sheet.columns.map(c => c.label),
      ...sheet.rows.map(row =>
        sheet.columns.map(c => {
          const v = row[c.key];
          return fmtCellValue(c.key, v as string | number | null);
        })
      ),
    ];
    const ws = XLSX.utils.aoa_to_sheet(wsData);
    // Auto column widths
    ws['!cols'] = sheet.columns.map(c => ({ wch: Math.max(c.label.length, 14) }));
    XLSX.utils.book_append_sheet(wb, ws, sheet.name.slice(0, 31));
  }
  XLSX.writeFile(wb, filename);
}

function exportToWord(htmlContent: string, filename: string) {
  const fullHtml = `
    <html xmlns:w="urn:schemas-microsoft-com:office:word">
    <head>
      <meta charset="utf-8">
      <style>
        body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; margin: 2cm; }
        h1 { font-size: 16pt; color: #2d4a3e; margin-bottom: 4pt; }
        h2 { font-size: 13pt; color: #2d4a3e; margin-top: 16pt; margin-bottom: 4pt; border-bottom: 1px solid #ccc; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 16pt; }
        th { background: #2d4a3e; color: white; padding: 5pt 8pt; font-size: 9pt; text-align: left; }
        td { border: 1px solid #ddd; padding: 4pt 8pt; font-size: 9pt; }
        tr:nth-child(even) td { background: #f5f5f5; }
        .kpi-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 8pt; margin-bottom: 16pt; }
        .kpi-card { border: 1px solid #ddd; padding: 8pt; border-radius: 4pt; }
        .kpi-label { font-size: 8pt; color: #666; text-transform: uppercase; }
        .kpi-value { font-size: 18pt; font-weight: bold; color: #2d4a3e; }
      </style>
    </head>
    <body>${htmlContent}</body>
    </html>
  `;
  const blob = new Blob([fullHtml], { type: 'application/msword' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function exportToPdf(htmlContent: string, title: string) {
  const printWin = window.open('', '_blank', 'width=900,height=700');
  if (!printWin) return;
  printWin.document.write(`
    <html>
    <head>
      <title>${title}</title>
      <style>
        body { font-family: Arial, sans-serif; font-size: 10pt; margin: 1.5cm; }
        h1 { font-size: 15pt; color: #2d4a3e; margin-bottom: 3pt; }
        h2 { font-size: 12pt; color: #2d4a3e; margin-top: 14pt; margin-bottom: 3pt; border-bottom: 1px solid #bbb; padding-bottom: 2pt; }
        .meta { font-size: 9pt; color: #666; margin-bottom: 12pt; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 14pt; }
        th { background: #2d4a3e; color: white; padding: 4pt 7pt; font-size: 8pt; text-align: left; }
        td { border: 1px solid #ddd; padding: 3pt 7pt; font-size: 8pt; }
        tr:nth-child(even) td { background: #f7f7f7; }
        .kpi-row { display: flex; flex-wrap: wrap; gap: 8pt; margin-bottom: 12pt; }
        .kpi-card { border: 1px solid #ddd; padding: 6pt 10pt; border-radius: 3pt; min-width: 100pt; }
        .kpi-label { font-size: 7pt; color: #666; text-transform: uppercase; letter-spacing: 0.5pt; }
        .kpi-value { font-size: 16pt; font-weight: bold; color: #2d4a3e; }
        @media print { .no-print { display: none; } }
      </style>
    </head>
    <body>
      <div class="no-print" style="margin-bottom:12pt;">
        <button onclick="window.print()" style="padding:6px 16px;background:#2d4a3e;color:white;border:none;border-radius:4px;cursor:pointer;font-size:12px;">
          Imprimir / Salvar como PDF
        </button>
      </div>
      ${htmlContent}
    </body>
    </html>
  `);
  printWin.document.close();
  printWin.focus();
}

function handlePrint(contentRef: React.RefObject<HTMLDivElement>) {
  const content = contentRef.current?.innerHTML;
  if (!content) return;
  const printWin = window.open('', '_blank', 'width=900,height=700');
  if (!printWin) return;
  printWin.document.write(`
    <html>
    <head>
      <title>Dashboard Prospecção</title>
      <style>
        body { font-family: Arial, sans-serif; font-size: 10pt; margin: 1cm; }
        table { border-collapse: collapse; width: 100%; margin-bottom: 12pt; }
        th { background: #2d4a3e; color: white; padding: 4pt 7pt; font-size: 8pt; }
        td { border: 1px solid #ddd; padding: 3pt 7pt; font-size: 8pt; }
        tr:nth-child(even) td { background: #f7f7f7; }
        h3 { font-size: 11pt; color: #2d4a3e; border-bottom: 1px solid #ccc; }
        .kpi-grid { display: flex; flex-wrap: wrap; gap: 8pt; margin-bottom: 12pt; }
        .kpi-card { border: 1px solid #ddd; padding: 6pt 10pt; border-radius: 3pt; }
        canvas { max-width: 100%; }
      </style>
    </head>
    <body>${content}</body>
    </html>
  `);
  printWin.document.close();
  printWin.focus();
  setTimeout(() => printWin.print(), 500);
}

// Build full HTML report for export (Word/PDF)
function buildReportHtml(
  data: DashboardData | null,
  reportRows: ReportRow[],
  activeReportTab: string,
  periodLabel: string,
  unitName: string
): string {
  const kpi = data?.kpi;
  const cols = REPORT_COLUMNS[activeReportTab] || [];
  const tabLabel = REPORT_TABS.find(t => t.key === activeReportTab)?.label || activeReportTab;

  const kpiHtml = `
    <h1>Dashboard de Prospecção</h1>
    <p class="meta">Período: ${periodLabel} ${unitName ? `| Unidade: ${unitName}` : ''} | Gerado em: ${new Date().toLocaleString('pt-BR')}</p>
    <h2>Indicadores Gerais</h2>
    <div class="kpi-row">
      <div class="kpi-card"><div class="kpi-label">Total Contatos</div><div class="kpi-value">${n(kpi?.total_contacts)}</div></div>
      <div class="kpi-card"><div class="kpi-label">Leads</div><div class="kpi-value" style="color:#16a34a">${n(kpi?.total_leads)}</div></div>
      <div class="kpi-card"><div class="kpi-label">Recuperações</div><div class="kpi-value" style="color:#ea580c">${n(kpi?.total_recuperacoes)}</div></div>
      <div class="kpi-card"><div class="kpi-label">Conversas</div><div class="kpi-value">${n(kpi?.total_conversations)}</div></div>
      <div class="kpi-card"><div class="kpi-label">Encerradas</div><div class="kpi-value">${n(kpi?.total_encerradas)}</div></div>
      <div class="kpi-card"><div class="kpi-label">Agendados</div><div class="kpi-value" style="color:#7c3aed">${n(kpi?.total_agendados)}</div></div>
    </div>
    <h2>Desfechos</h2>
    <div class="kpi-row">
      <div class="kpi-card"><div class="kpi-label">Interesse Alto</div><div class="kpi-value" style="color:#16a34a">${n(kpi?.interesse_alto)}</div></div>
      <div class="kpi-card"><div class="kpi-label">Interesse Médio</div><div class="kpi-value" style="color:#3b82f6">${n(kpi?.interesse_medio)}</div></div>
      <div class="kpi-card"><div class="kpi-label">Interesse Baixo</div><div class="kpi-value" style="color:#f59e0b">${n(kpi?.interesse_baixo)}</div></div>
      <div class="kpi-card"><div class="kpi-label">Sem Interesse</div><div class="kpi-value" style="color:#ef4444">${n(kpi?.sem_interesse)}</div></div>
    </div>
  `;

  const modalidadeHtml = data?.byModalidade?.length ? `
    <h2>Agendamentos por Modalidade</h2>
    <table>
      <thead><tr><th>Modalidade</th><th>Total</th><th>Realizados</th><th>Cancelados</th></tr></thead>
      <tbody>
        ${data.byModalidade.map(m => `
          <tr>
            <td>${MODALIDADE_CONFIG[m.modalidade]?.label || m.modalidade}</td>
            <td>${n(m.total)}</td>
            <td>${n(m.agendados)}</td>
            <td>${n(m.cancelados)}</td>
          </tr>
        `).join('')}
      </tbody>
    </table>
  ` : '';

  const tableHtml = reportRows.length ? `
    <h2>${tabLabel} (${reportRows.length} registros)</h2>
    <table>
      <thead><tr>${cols.map(c => `<th>${c.label}</th>`).join('')}</tr></thead>
      <tbody>
        ${reportRows.map(row => `
          <tr>${cols.map(c => `<td>${fmtCellValue(c.key, row[c.key] as string | number | null)}</td>`).join('')}</tr>
        `).join('')}
      </tbody>
    </table>
  ` : `<h2>${tabLabel}</h2><p>Sem registros no período.</p>`;

  return kpiHtml + modalidadeHtml + tableHtml;
}

// ── KPI Card (clickable) ───────────────────────────────────────────────────────

interface KpiCardProps {
  label: string;
  value: number;
  color?: string;
  sub?: string;
  active?: boolean;
  onClick?: () => void;
}

const KpiCard: React.FC<KpiCardProps> = ({ label, value, color = MOSS, sub, active, onClick }) => (
  <div
    onClick={onClick}
    className={`bg-white rounded-xl shadow-sm border p-4 flex flex-col gap-1 transition-all ${
      onClick ? 'cursor-pointer hover:shadow-md hover:-translate-y-0.5' : ''
    } ${active ? 'ring-2 shadow-md -translate-y-0.5' : 'border-gray-100'}`}
    style={active ? { ringColor: color, borderColor: color } as React.CSSProperties : undefined}
  >
    <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-widest">{label}</span>
    <span className="text-2xl font-bold text-gray-900" style={{ color }}>{value.toLocaleString('pt-BR')}</span>
    {sub && <span className="text-[10px] text-gray-400">{sub}</span>}
    {onClick && (
      <span className="text-[9px] text-gray-300 mt-0.5">{active ? '▼ ver detalhes' : '▶ clique para detalhes'}</span>
    )}
  </div>
);

// ── Modalidade Card ────────────────────────────────────────────────────────────

const ModalidadeCard: React.FC<{
  row: ByModalidadeRow;
  active: boolean;
  onClick: () => void;
}> = ({ row, active, onClick }) => {
  const cfg = MODALIDADE_CONFIG[row.modalidade] || MODALIDADE_CONFIG.SEM_MODALIDADE;
  return (
    <div
      onClick={onClick}
      className={`rounded-xl border p-4 flex flex-col gap-2 cursor-pointer transition-all hover:shadow-md hover:-translate-y-0.5 ${
        active ? 'ring-2 shadow-md -translate-y-0.5' : ''
      }`}
      style={{
        background: cfg.bg,
        borderColor: active ? cfg.color : '#e5e7eb',
        ringColor: cfg.color,
      }}
    >
      <div className="flex items-center gap-2">
        <span className="text-xl">{cfg.icon}</span>
        <span className="text-[10px] font-semibold uppercase tracking-widest" style={{ color: cfg.color }}>{cfg.label}</span>
      </div>
      <span className="text-3xl font-bold" style={{ color: cfg.color }}>{n(row.total).toLocaleString('pt-BR')}</span>
      <div className="flex gap-3 text-[10px]">
        <span className="text-green-700 font-semibold">✓ {n(row.agendados)} realizado{n(row.agendados) !== 1 ? 's' : ''}</span>
        <span className="text-red-500 font-semibold">✗ {n(row.cancelados)} cancelado{n(row.cancelados) !== 1 ? 's' : ''}</span>
      </div>
      <span className="text-[9px] text-gray-400">{active ? '▼ ver detalhes' : '▶ clique para detalhes'}</span>
    </div>
  );
};

// ── Sortable operator table ────────────────────────────────────────────────────

type SortKey = 'operator_name' | 'unit_name' | 'total_conversations' | 'leads' | 'recuperacoes' | 'interesse_alto' | 'pct_alto';

const OperatorTable: React.FC<{ rows: ByOperatorRow[] }> = ({ rows }) => {
  const [sortKey, setSortKey] = useState<SortKey>('total_conversations');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const sorted = useMemo(() => {
    return [...rows].sort((a, b) => {
      let av: number | string;
      let bv: number | string;
      if (sortKey === 'pct_alto') {
        av = n(a.encerradas) > 0 ? n(a.interesse_alto) / n(a.encerradas) : 0;
        bv = n(b.encerradas) > 0 ? n(b.interesse_alto) / n(b.encerradas) : 0;
      } else if (sortKey === 'operator_name' || sortKey === 'unit_name') {
        av = (a[sortKey] || '').toLowerCase();
        bv = (b[sortKey] || '').toLowerCase();
      } else {
        av = n(a[sortKey as keyof ByOperatorRow]);
        bv = n(b[sortKey as keyof ByOperatorRow]);
      }
      if (av < bv) return sortDir === 'asc' ? -1 : 1;
      if (av > bv) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
  }, [rows, sortKey, sortDir]);

  const toggle = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('desc'); }
  };

  const Th: React.FC<{ label: string; k: SortKey }> = ({ label, k }) => (
    <th
      onClick={() => toggle(k)}
      className="px-3 py-2.5 text-left text-[10px] font-bold text-gray-500 uppercase tracking-wide cursor-pointer hover:text-gray-800 select-none whitespace-nowrap"
    >
      {label}
      {sortKey === k && <span className="ml-1 text-[10px]">{sortDir === 'asc' ? '▲' : '▼'}</span>}
    </th>
  );

  if (rows.length === 0) {
    return <div className="text-center py-8 text-gray-400 text-sm">Sem dados de operadores no período selecionado.</div>;
  }

  return (
    <div className="overflow-x-auto rounded-xl border border-gray-100">
      <table className="w-full text-xs operational-grid">
        <thead className="bg-gray-50 border-b border-gray-100">
          <tr>
            <Th label="Operador" k="operator_name" />
            <Th label="Unidade" k="unit_name" />
            <Th label="Conversas" k="total_conversations" />
            <Th label="Leads" k="leads" />
            <Th label="Recuperações" k="recuperacoes" />
            <Th label="Interesse alto" k="interesse_alto" />
            <Th label="% Interesse alto" k="pct_alto" />
          </tr>
        </thead>
        <tbody>
          {sorted.map((row, i) => {
            const pct = n(row.encerradas) > 0 ? Math.round((n(row.interesse_alto) / n(row.encerradas)) * 100) : 0;
            return (
              <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                <td className="px-3 py-2.5 font-medium text-gray-800">{row.operator_name}</td>
                <td className="px-3 py-2.5 text-gray-500 text-[11px]">{row.unit_name || '—'}</td>
                <td className="px-3 py-2.5 text-gray-600">{n(row.total_conversations).toLocaleString('pt-BR')}</td>
                <td className="px-3 py-2.5">
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded-full bg-green-50 text-green-700 text-[10px] font-bold">
                    {n(row.leads).toLocaleString('pt-BR')}
                  </span>
                </td>
                <td className="px-3 py-2.5">
                  <span className="inline-flex items-center px-1.5 py-0.5 rounded-full bg-orange-50 text-orange-700 text-[10px] font-bold">
                    {n(row.recuperacoes).toLocaleString('pt-BR')}
                  </span>
                </td>
                <td className="px-3 py-2.5 text-gray-600">{n(row.interesse_alto).toLocaleString('pt-BR')}</td>
                <td className="px-3 py-2.5">
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-gray-200 rounded-full h-1.5 min-w-[40px]">
                      <div className="h-1.5 rounded-full" style={{ width: `${Math.min(pct, 100)}%`, background: MOSS }} />
                    </div>
                    <span className="text-gray-700 font-semibold text-[10px] w-8 text-right">{pct}%</span>
                  </div>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

// ── Drill-down / Report Table ──────────────────────────────────────────────────

const DrillDownTable: React.FC<{
  rows: ReportRow[];
  type: string;
  loading: boolean;
  title: string;
  onClose: () => void;
}> = ({ rows, type, loading, title, onClose }) => {
  const cols = REPORT_COLUMNS[type] || [];
  if (loading) {
    return (
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm p-6 flex items-center justify-center gap-2 text-gray-400 text-sm">
        <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
        </svg>
        Carregando registros...
      </div>
    );
  }
  return (
    <div className="bg-white rounded-xl border-2 shadow-md" style={{ borderColor: MOSS }}>
      <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100">
        <span className="text-sm font-bold text-gray-800">{title} — {rows.length} registro{rows.length !== 1 ? 's' : ''}</span>
        <button onClick={onClose} className="text-gray-400 hover:text-gray-700 transition-colors text-xs px-2 py-1 rounded hover:bg-gray-100">
          ✕ Fechar
        </button>
      </div>
      {rows.length === 0 ? (
        <div className="py-8 text-center text-gray-400 text-sm">Nenhum registro encontrado para o período e filtros selecionados.</div>
      ) : (
        <div className="overflow-x-auto max-h-72">
          <table className="w-full text-xs operational-grid">
            <thead className="bg-gray-50 sticky top-0">
              <tr>
                {cols.map(c => (
                  <th key={c.key} className="px-3 py-2.5 text-left text-[10px] font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap">
                    {c.label}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((row, i) => (
                <tr key={i} className="border-b border-gray-50 hover:bg-gray-50">
                  {cols.map(c => (
                    <td key={c.key} className="px-3 py-2 text-gray-700 whitespace-nowrap">
                      {fmtCellValue(c.key, row[c.key] as string | number | null)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// ── Export Toolbar ─────────────────────────────────────────────────────────────

const ExportToolbar: React.FC<{
  onExcelAll: () => void;
  onWordAll: () => void;
  onPdfAll: () => void;
  onPrint: () => void;
  loading?: boolean;
}> = ({ onExcelAll, onWordAll, onPdfAll, onPrint, loading }) => (
  <div className="flex items-center gap-1.5">
    <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide mr-1">Exportar:</span>
    <button
      onClick={onExcelAll}
      disabled={loading}
      title="Exportar para Excel (.xlsx)"
      className="flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold rounded-lg border border-green-200 bg-green-50 text-green-700 hover:bg-green-100 transition-colors disabled:opacity-50"
    >
      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
      Excel
    </button>
    <button
      onClick={onPdfAll}
      disabled={loading}
      title="Exportar para PDF"
      className="flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold rounded-lg border border-red-200 bg-red-50 text-red-700 hover:bg-red-100 transition-colors disabled:opacity-50"
    >
      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
      </svg>
      PDF
    </button>
    <button
      onClick={onWordAll}
      disabled={loading}
      title="Exportar para Word (.doc)"
      className="flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold rounded-lg border border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100 transition-colors disabled:opacity-50"
    >
      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
      </svg>
      Word
    </button>
    <button
      onClick={onPrint}
      disabled={loading}
      title="Imprimir"
      className="flex items-center gap-1 px-2.5 py-1.5 text-[11px] font-semibold rounded-lg border border-gray-200 bg-gray-50 text-gray-600 hover:bg-gray-100 transition-colors disabled:opacity-50"
    >
      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" />
      </svg>
      Imprimir
    </button>
  </div>
);

// ── Empty chart ────────────────────────────────────────────────────────────────

const EmptyChart: React.FC = () => (
  <div className="flex items-center justify-center h-32 text-gray-300 text-xs">
    Sem dados para o período selecionado
  </div>
);

// ── WhatsApp por Unidade ────────────────────────────────────────────────────────

const UazapiStatusBadge: React.FC<{ status: WaUnitRow['uazapi_status']; instances: number }> = ({ status, instances }) => {
  if (instances === 0) {
    return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-gray-100 text-gray-400 text-[10px] font-semibold">Não configurado</span>;
  }
  if (status === 'connected') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-50 text-green-700 text-[10px] font-semibold">
        <span className="w-1.5 h-1.5 rounded-full bg-green-500 inline-block" />
        Conectado
      </span>
    );
  }
  if (status === 'disconnected') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-orange-50 text-orange-600 text-[10px] font-semibold">
        <span className="w-1.5 h-1.5 rounded-full bg-orange-500 inline-block" />
        Desconectado
      </span>
    );
  }
  if (status === 'error') {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-yellow-50 text-yellow-700 text-[10px] font-semibold">
        <span className="w-1.5 h-1.5 rounded-full bg-yellow-400 inline-block" />
        Erro
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-gray-100 text-gray-500 text-[10px] font-semibold">
      <span className="w-1.5 h-1.5 rounded-full bg-gray-400 inline-block animate-pulse" />
      Verificando…
    </span>
  );
};

const GotalkStatusBadge: React.FC<{ active: number; total: number }> = ({ active, total }) => {
  if (total === 0) {
    return <span className="inline-flex items-center px-2 py-0.5 rounded-full bg-gray-100 text-gray-400 text-[10px] font-semibold">Sem canal</span>;
  }
  if (active > 0) {
    return (
      <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 text-[10px] font-semibold">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 inline-block" />
        {active}/{total} ativo{active !== 1 ? 's' : ''}
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-orange-50 text-orange-600 text-[10px] font-semibold">
      <span className="w-1.5 h-1.5 rounded-full bg-orange-400 inline-block" />
      {total} inativo{total !== 1 ? 's' : ''}
    </span>
  );
};

const WhatsappByUnitSection: React.FC<{
  units: WaUnitRow[];
  loading: boolean;
  onRefresh: () => void;
  open: boolean;
  onToggle: () => void;
}> = ({ units, loading, onRefresh, open, onToggle }) => {
  const totalIn   = units.reduce((s, u) => s + u.messages_in, 0);
  const totalOut  = units.reduce((s, u) => s + u.messages_out, 0);
  const totalLeads = units.reduce((s, u) => s + u.leads, 0);
  const totalRec   = units.reduce((s, u) => s + u.recuperacoes, 0);

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100">
      {/* Header — not a button to avoid nesting interactive elements */}
      <div className="flex items-center justify-between px-5 py-4">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-green-50 flex items-center justify-center text-green-600 text-base flex-shrink-0">
            <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347z"/>
              <path d="M12.013 2C6.494 2 2.013 6.481 2.013 12c0 1.944.523 3.754 1.427 5.32L2 22l4.82-1.413A9.963 9.963 0 0012.013 22C17.532 22 22 17.519 22 12c0-5.519-4.468-10-9.987-10zm0 18.182a8.176 8.176 0 01-4.434-1.302l-.316-.189-3.28.962.958-3.214-.207-.326A8.162 8.162 0 013.831 12c0-4.519 3.68-8.182 8.182-8.182 4.52 0 8.182 3.663 8.182 8.182 0 4.52-3.662 8.182-8.182 8.182z"/>
            </svg>
          </div>
          <div className="text-left min-w-0">
            <h3 className="text-sm font-bold text-gray-800">WhatsApp por Unidade</h3>
            {!loading && units.length > 0 && (
              <p className="text-[10px] text-gray-400 mt-0.5">
                {(totalIn + totalOut).toLocaleString('pt-BR')} msgs • {totalLeads.toLocaleString('pt-BR')} leads • {totalRec.toLocaleString('pt-BR')} recuperações
              </p>
            )}
          </div>
        </div>
        <div className="flex items-center gap-1 flex-shrink-0">
          {loading && (
            <svg className="w-3.5 h-3.5 text-gray-400 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
            </svg>
          )}
          <button
            onClick={onRefresh}
            disabled={loading}
            title="Atualizar"
            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors disabled:opacity-50"
          >
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          </button>
          <button
            onClick={onToggle}
            title={open ? 'Recolher' : 'Expandir'}
            className="p-1.5 rounded-lg text-gray-400 hover:text-gray-700 hover:bg-gray-100 transition-colors"
          >
            <svg
              className={`w-4 h-4 transition-transform duration-200 ${open ? 'rotate-180' : ''}`}
              fill="none" viewBox="0 0 24 24" stroke="currentColor"
            >
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-gray-100">
          {loading ? (
            <div className="flex items-center justify-center gap-2 py-10 text-gray-400 text-sm">
              <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
              </svg>
              Carregando dados de WhatsApp…
            </div>
          ) : units.length === 0 ? (
            <div className="py-10 text-center text-gray-400 text-sm">
              Nenhuma unidade encontrada para os filtros selecionados.
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-xs operational-grid">
                <thead className="bg-gray-50 border-b border-gray-100">
                  <tr>
                    <th className="px-4 py-2.5 text-left text-[10px] font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap">Unidade</th>
                    <th className="px-4 py-2.5 text-center text-[10px] font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap" colSpan={2}>Mensagens (período)</th>
                    <th className="px-4 py-2.5 text-center text-[10px] font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap" colSpan={3}>Contatos (período)</th>
                    <th className="px-4 py-2.5 text-center text-[10px] font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap">GoTalk</th>
                    <th className="px-4 py-2.5 text-center text-[10px] font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap">uazapi</th>
                  </tr>
                  <tr className="border-b border-gray-100">
                    <th className="px-4 pb-2" />
                    <th className="px-3 pb-2 text-[10px] font-medium text-gray-400 text-center">Recebidas</th>
                    <th className="px-3 pb-2 text-[10px] font-medium text-gray-400 text-center">Enviadas</th>
                    <th className="px-3 pb-2 text-[10px] font-medium text-gray-400 text-center">Leads</th>
                    <th className="px-3 pb-2 text-[10px] font-medium text-gray-400 text-center">Recuperações</th>
                    <th className="px-3 pb-2 text-[10px] font-medium text-gray-400 text-center">Total ativos</th>
                    <th className="px-3 pb-2 text-[10px] font-medium text-gray-400 text-center">Canais</th>
                    <th className="px-3 pb-2 text-[10px] font-medium text-gray-400 text-center">Conexão</th>
                  </tr>
                </thead>
                <tbody>
                  {units.map((u, i) => (
                    <tr key={u.unit_id} className={`border-b border-gray-50 hover:bg-gray-50 transition-colors ${i % 2 === 0 ? '' : 'bg-gray-50/30'}`}>
                      <td className="px-4 py-2.5 font-semibold text-gray-800 whitespace-nowrap">{u.unit_name}</td>
                      <td className="px-3 py-2.5 text-center text-blue-600 font-semibold">{u.messages_in.toLocaleString('pt-BR')}</td>
                      <td className="px-3 py-2.5 text-center text-indigo-600 font-semibold">{u.messages_out.toLocaleString('pt-BR')}</td>
                      <td className="px-3 py-2.5 text-center">
                        <span className="inline-flex items-center px-1.5 py-0.5 rounded-full bg-green-50 text-green-700 text-[10px] font-bold">
                          {u.leads.toLocaleString('pt-BR')}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        <span className="inline-flex items-center px-1.5 py-0.5 rounded-full bg-orange-50 text-orange-700 text-[10px] font-bold">
                          {u.recuperacoes.toLocaleString('pt-BR')}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-center text-gray-600 font-semibold">
                        {(u.leads + u.recuperacoes).toLocaleString('pt-BR')}
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        <GotalkStatusBadge active={u.gotalk_active_channels} total={u.gotalk_total_channels} />
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        <UazapiStatusBadge status={u.uazapi_status} instances={u.uazapi_instances} />
                      </td>
                    </tr>
                  ))}
                </tbody>
                {units.length > 1 && (
                  <tfoot className="border-t-2 border-gray-200 bg-gray-50">
                    <tr>
                      <td className="px-4 py-2.5 text-[10px] font-bold text-gray-500 uppercase tracking-wide">Total</td>
                      <td className="px-3 py-2.5 text-center text-blue-700 font-bold text-[11px]">{totalIn.toLocaleString('pt-BR')}</td>
                      <td className="px-3 py-2.5 text-center text-indigo-700 font-bold text-[11px]">{totalOut.toLocaleString('pt-BR')}</td>
                      <td className="px-3 py-2.5 text-center">
                        <span className="inline-flex items-center px-1.5 py-0.5 rounded-full bg-green-100 text-green-800 text-[10px] font-bold">
                          {totalLeads.toLocaleString('pt-BR')}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-center">
                        <span className="inline-flex items-center px-1.5 py-0.5 rounded-full bg-orange-100 text-orange-800 text-[10px] font-bold">
                          {totalRec.toLocaleString('pt-BR')}
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-center text-gray-700 font-bold text-[11px]">
                        {(totalLeads + totalRec).toLocaleString('pt-BR')}
                      </td>
                      <td className="px-3 py-2.5 text-center text-gray-400 text-[10px]">
                        {units.reduce((s, u) => s + u.gotalk_active_channels, 0)}/{units.reduce((s, u) => s + u.gotalk_total_channels, 0)} ativos
                      </td>
                      <td className="px-3 py-2.5 text-center text-gray-400 text-[10px]">
                        {units.filter(u => u.uazapi_status === 'connected').length} conectado{units.filter(u => u.uazapi_status === 'connected').length !== 1 ? 's' : ''}
                      </td>
                    </tr>
                  </tfoot>
                )}
              </table>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// ── Main Dashboard component ──────────────────────────────────────────────────

interface ProspeccaoDashboardProps {
  filterUnits: { id: string; name: string }[];
  selectedUnitIds?: string[];
}

const ProspeccaoDashboard: React.FC<ProspeccaoDashboardProps> = ({ filterUnits, selectedUnitIds = [] }) => {
  const [period, setPeriod] = useState('30d');
  const [groupBy, setGroupBy] = useState('day');
  const [unitId, setUnitId] = useState('');
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [data, setData] = useState<DashboardData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Drill-down state
  const [activeCard, setActiveCard] = useState<{ type: string; modalidade?: string; label: string } | null>(null);
  const [drillRows, setDrillRows] = useState<ReportRow[]>([]);
  const [drillLoading, setDrillLoading] = useState(false);
  const drillRef = useRef<HTMLDivElement>(null);

  // Report tables state
  const [activeReportTab, setActiveReportTab] = useState('leads');
  const [reportRows, setReportRows] = useState<ReportRow[]>([]);
  const [reportLoading, setReportLoading] = useState(false);
  const [reportFetched, setReportFetched] = useState(false);

  // Print ref
  const printRef = useRef<HTMLDivElement>(null);

  // WhatsApp by unit state
  const [waData, setWaData] = useState<WaUnitRow[]>([]);
  const [waLoading, setWaLoading] = useState(false);
  const [waOpen, setWaOpen] = useState(true);

  // ── Current filters as query params ───────────────────────────────────────
  const buildQs = useCallback((extra: Record<string, string> = {}) => {
    const qs = new URLSearchParams({ period, groupBy });
    if (unitId) {
      qs.set('unitId', unitId);
    } else if (selectedUnitIds.length > 0 && selectedUnitIds.length < filterUnits.length) {
      qs.set('unitIds', selectedUnitIds.join(','));
    }
    if (period === 'custom' && dateFrom) qs.set('dateFrom', dateFrom);
    if (period === 'custom' && dateTo) qs.set('dateTo', dateTo);
    Object.entries(extra).forEach(([k, v]) => qs.set(k, v));
    return qs.toString();
  }, [period, groupBy, unitId, dateFrom, dateTo, selectedUnitIds, filterUnits.length]);

  // ── Dashboard fetch ────────────────────────────────────────────────────────
  const fetchDashboard = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/prospection/dashboard?${buildQs()}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setData(await res.json());
      setActiveCard(null);
      setDrillRows([]);
      setReportFetched(false);
      setReportRows([]);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : 'Erro ao carregar dashboard');
    } finally {
      setLoading(false);
    }
  }, [buildQs]);

  // ── WhatsApp by unit fetch ─────────────────────────────────────────────────
  const fetchWaByUnit = useCallback(async () => {
    setWaLoading(true);
    try {
      const res = await fetch(`/api/prospection/dashboard/whatsapp-by-unit?${buildQs()}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setWaData(json.units || []);
    } catch {
      setWaData([]);
    } finally {
      setWaLoading(false);
    }
  }, [buildQs]);

  useEffect(() => { fetchDashboard(); fetchWaByUnit(); }, [fetchDashboard, fetchWaByUnit]);
  const refreshDashboardData = useCallback(
    () => Promise.all([fetchDashboard(), fetchWaByUnit()]),
    [fetchDashboard, fetchWaByUnit],
  );
  useDashboardInvalidation('prospection', refreshDashboardData);

  // Reset single-unit drill-down if it falls outside the current selectedUnitIds
  useEffect(() => {
    if (unitId && selectedUnitIds.length > 0 && !selectedUnitIds.includes(unitId)) {
      setUnitId('');
    }
  }, [selectedUnitIds, unitId]);

  // ── Drill-down fetch ───────────────────────────────────────────────────────
  const fetchDrillDown = useCallback(async (type: string, modalidade?: string) => {
    setDrillLoading(true);
    setDrillRows([]);
    try {
      const extra: Record<string, string> = { type };
      if (modalidade) extra.modalidade = modalidade;
      const res = await fetch(`/api/prospection/dashboard/report?${buildQs(extra)}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setDrillRows(json.rows || []);
    } catch {
      setDrillRows([]);
    } finally {
      setDrillLoading(false);
      setTimeout(() => drillRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 100);
    }
  }, [buildQs]);

  // ── Card click handler ────────────────────────────────────────────────────
  const handleCardClick = useCallback((type: string, label: string, modalidade?: string) => {
    if (activeCard?.type === type && activeCard?.modalidade === modalidade) {
      setActiveCard(null);
      setDrillRows([]);
      return;
    }
    const card = { type, label, modalidade };
    setActiveCard(card);
    fetchDrillDown(type, modalidade);
  }, [activeCard, fetchDrillDown]);

  // ── Report tables fetch ────────────────────────────────────────────────────
  const fetchReport = useCallback(async (tabKey: string) => {
    setReportLoading(true);
    setReportRows([]);
    setReportFetched(false);
    try {
      const res = await fetch(`/api/prospection/dashboard/report?${buildQs({ type: tabKey })}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      setReportRows(json.rows || []);
      setReportFetched(true);
    } catch {
      setReportRows([]);
      setReportFetched(true);
    } finally {
      setReportLoading(false);
    }
  }, [buildQs]);

  const handleReportTab = (key: string) => {
    setActiveReportTab(key);
    fetchReport(key);
  };

  // ── Labels for export ──────────────────────────────────────────────────────
  const currentPeriodLabel = periodLabel(period, dateFrom, dateTo);
  const currentUnitName = unitId ? (filterUnits.find(u => u.id === unitId)?.name || '') : '';

  // ── Export handlers ────────────────────────────────────────────────────────
  const handleExcelAll = async () => {
    const sheets = [];

    // KPI summary sheet
    const kpi = data?.kpi;
    const kpiRows: ReportRow[] = kpi ? [
      { indicador: 'Total de Contatos', valor: n(kpi.total_contacts) },
      { indicador: 'Novos Leads', valor: n(kpi.total_leads) },
      { indicador: 'Recuperações', valor: n(kpi.total_recuperacoes) },
      { indicador: 'Total de Conversas', valor: n(kpi.total_conversations) },
      { indicador: 'Conversas Encerradas', valor: n(kpi.total_encerradas) },
      { indicador: 'Agendamentos', valor: n(kpi.total_agendados) },
      { indicador: 'Interesse Alto', valor: n(kpi.interesse_alto) },
      { indicador: 'Interesse Médio', valor: n(kpi.interesse_medio) },
      { indicador: 'Interesse Baixo', valor: n(kpi.interesse_baixo) },
      { indicador: 'Sem Interesse', valor: n(kpi.sem_interesse) },
    ] : [];
    sheets.push({
      name: 'Resumo KPI',
      rows: kpiRows,
      columns: [{ key: 'indicador', label: 'Indicador' }, { key: 'valor', label: 'Valor' }],
    });

    // Modalidades sheet
    if (data?.byModalidade?.length) {
      sheets.push({
        name: 'Por Modalidade',
        rows: data.byModalidade.map(m => ({
          modalidade: MODALIDADE_CONFIG[m.modalidade]?.label || m.modalidade,
          total: n(m.total),
          agendados: n(m.agendados),
          cancelados: n(m.cancelados),
        })),
        columns: [
          { key: 'modalidade', label: 'Modalidade' },
          { key: 'total', label: 'Total' },
          { key: 'agendados', label: 'Realizados' },
          { key: 'cancelados', label: 'Cancelados' },
        ],
      });
    }

    // By Unit
    if (data?.byUnit?.length) {
      sheets.push({
        name: 'Por Unidade',
        rows: data.byUnit,
        columns: [
          { key: 'unit_name', label: 'Unidade' },
          { key: 'total', label: 'Total' },
          { key: 'leads', label: 'Leads' },
          { key: 'recuperacoes', label: 'Recuperações' },
        ],
      });
    }

    // By Operator
    if (data?.byOperator?.length) {
      sheets.push({
        name: 'Por Operador',
        rows: data.byOperator,
        columns: [
          { key: 'operator_name', label: 'Operador' },
          { key: 'unit_name', label: 'Unidade' },
          { key: 'total_conversations', label: 'Conversas' },
          { key: 'leads', label: 'Leads' },
          { key: 'recuperacoes', label: 'Recuperações' },
          { key: 'interesse_alto', label: 'Interesse Alto' },
        ],
      });
    }

    // Fetch all report types and add as sheets
    const reportTypes: { key: string; label: string }[] = [
      { key: 'leads', label: 'Leads' },
      { key: 'recuperacoes', label: 'Recuperações' },
      { key: 'agendados', label: 'Agendamentos' },
      { key: 'cancelados', label: 'Cancelados' },
      { key: 'encerramento', label: 'Encerramento' },
    ];

    for (const rt of reportTypes) {
      try {
        const res = await fetch(`/api/prospection/dashboard/report?${buildQs({ type: rt.key })}`);
        if (res.ok) {
          const json = await res.json();
          if (json.rows?.length) {
            sheets.push({
              name: rt.label,
              rows: json.rows,
              columns: REPORT_COLUMNS[rt.key] || [],
            });
          }
        }
      } catch { /* skip */ }
    }

    const filename = `prospecao_dashboard_${currentPeriodLabel.replace(/\s+/g, '_')}.xlsx`;
    await exportToExcel(sheets, filename);
  };

  const handleWordAll = async () => {
    let allRows = reportRows;
    if (!reportFetched || allRows.length === 0) {
      try {
        const res = await fetch(`/api/prospection/dashboard/report?${buildQs({ type: activeReportTab })}`);
        if (res.ok) { const j = await res.json(); allRows = j.rows || []; }
      } catch { /* skip */ }
    }
    const html = buildReportHtml(data, allRows, activeReportTab, currentPeriodLabel, currentUnitName);
    exportToWord(html, `prospecao_dashboard_${currentPeriodLabel.replace(/\s+/g, '_')}.doc`);
  };

  const handlePdfAll = async () => {
    let allRows = reportRows;
    if (!reportFetched || allRows.length === 0) {
      try {
        const res = await fetch(`/api/prospection/dashboard/report?${buildQs({ type: activeReportTab })}`);
        if (res.ok) { const j = await res.json(); allRows = j.rows || []; }
      } catch { /* skip */ }
    }
    const html = buildReportHtml(data, allRows, activeReportTab, currentPeriodLabel, currentUnitName);
    exportToPdf(html, `Prospecção — Dashboard (${currentPeriodLabel})`);
  };

  const handlePrintAll = () => handlePrint(printRef);

  // ── Chart data ────────────────────────────────────────────────────────────

  const byUnitChartData = useMemo(() => {
    if (!data?.byUnit?.length) return null;
    const labels = data.byUnit.map(r => r.unit_name);
    return {
      labels,
      datasets: [
        { label: 'Leads', data: data.byUnit.map(r => n(r.leads)), backgroundColor: LEAD_COLOR, borderColor: LEAD_BORDER, borderWidth: 1, borderRadius: 4 },
        { label: 'Recuperações', data: data.byUnit.map(r => n(r.recuperacoes)), backgroundColor: REC_COLOR, borderColor: REC_BORDER, borderWidth: 1, borderRadius: 4 },
      ],
    };
  }, [data]);

  const byOperatorChartData = useMemo(() => {
    if (!data?.byOperator?.length) return null;
    const top10 = data.byOperator.slice(0, 10);
    return {
      labels: top10.map(r => r.operator_name),
      datasets: [{
        label: 'Conversas',
        data: top10.map(r => n(r.total_conversations)),
        backgroundColor: `rgba(45,74,62,0.75)`,
        borderColor: MOSS,
        borderWidth: 1,
        borderRadius: 4,
      }],
    };
  }, [data]);

  const timeSeriesChartData = useMemo(() => {
    if (!data?.timeSeries?.length) return null;
    const labels = data.timeSeries.map(r => fmtBucket(r.bucket, data.groupBy));
    return {
      labels,
      datasets: [
        { label: 'Leads', data: data.timeSeries.map(r => n(r.leads)), borderColor: LEAD_BORDER, backgroundColor: 'rgba(22,163,74,0.12)', fill: true, tension: 0.3, pointRadius: 3, borderWidth: 2 },
        { label: 'Recuperações', data: data.timeSeries.map(r => n(r.recuperacoes)), borderColor: REC_BORDER, backgroundColor: 'rgba(234,88,12,0.10)', fill: true, tension: 0.3, pointRadius: 3, borderWidth: 2 },
      ],
    };
  }, [data]);

  const kpi = data?.kpi;

  // ── Render ────────────────────────────────────────────────────────────────

  return (
    <div data-testid="prospeccao-dashboard" data-visual-panel="prospeccao-dashboard" className="flex-1 min-w-0 min-h-0 overflow-y-auto overflow-x-hidden bg-gray-50">
      {/* Filter bar */}
      <div data-testid="prospeccao-dashboard-filters" className="sticky top-0 z-10 bg-white border-b border-gray-200 px-4 min-[1400px]:px-6 py-2.5 min-[1400px]:py-3 flex flex-wrap items-end gap-2 min-[1400px]:gap-3">
        <div className="flex flex-col gap-0.5">
          <label className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Período</label>
          <select
            value={period}
            onChange={e => setPeriod(e.target.value)}
            className="border border-gray-300 rounded-lg px-2 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="today">Hoje</option>
            <option value="7d">Últimos 7 dias</option>
            <option value="30d">Últimos 30 dias</option>
            <option value="custom">Personalizado</option>
          </select>
        </div>

        {period === 'custom' && (
          <>
            <div className="flex flex-col gap-0.5">
              <label className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">De</label>
              <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)}
                className="border border-gray-300 rounded-lg px-2 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-500" />
            </div>
            <div className="flex flex-col gap-0.5">
              <label className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Até</label>
              <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)}
                className="border border-gray-300 rounded-lg px-2 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-500" />
            </div>
          </>
        )}

        <div className="flex flex-col gap-0.5">
          <label className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Unidade</label>
          <select
            value={unitId}
            onChange={e => setUnitId(e.target.value)}
            className="border border-gray-300 rounded-lg px-2 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="">Todas as unidades</option>
            {filterUnits.map(u => <option key={u.id} value={u.id}>{u.name}</option>)}
          </select>
        </div>

        <div className="flex flex-col gap-0.5">
          <label className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Granularidade</label>
          <select
            value={groupBy}
            onChange={e => setGroupBy(e.target.value)}
            className="border border-gray-300 rounded-lg px-2 py-1.5 text-xs bg-white focus:outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="day">Diário</option>
            <option value="week">Semanal</option>
            <option value="month">Mensal</option>
          </select>
        </div>

        <button
          onClick={() => { fetchDashboard(); fetchWaByUnit(); }}
          disabled={loading}
          className="flex items-center gap-1.5 px-3 py-1.5 text-xs text-white rounded-lg disabled:opacity-60 transition-colors"
          style={{ background: MOSS }}
        >
          {loading ? (
            <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
            </svg>
          ) : (
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            </svg>
          )}
          Atualizar
        </button>

        {/* Export toolbar */}
        <div className="ml-auto max-[1399px]:w-full max-[1399px]:flex max-[1399px]:justify-end">
          <ExportToolbar
            onExcelAll={handleExcelAll}
            onWordAll={handleWordAll}
            onPdfAll={handlePdfAll}
            onPrint={handlePrintAll}
            loading={loading}
          />
        </div>
      </div>

      {/* Error */}
      {error && (
        <div className="mx-6 mt-4 px-4 py-3 bg-red-50 border border-red-200 rounded-lg text-xs text-red-700">
          Erro ao carregar dados: {error}
        </div>
      )}

      {/* Content */}
      {loading && !data ? (
        <div className="flex items-center justify-center h-64 text-gray-400 text-sm">
          Carregando indicadores...
        </div>
      ) : data ? (
        <div data-testid="prospeccao-dashboard-content" className="p-4 min-[1400px]:p-6 space-y-4 min-[1400px]:space-y-6" ref={printRef}>

          {/* KPI cards row 1 — totals */}
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Visão geral <span className="text-gray-400 font-normal normal-case">— clique em um card para ver os registros</span></h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
              <KpiCard label="Total de contatos" value={n(kpi?.total_contacts)} />
              <KpiCard
                label="Novos Leads" value={n(kpi?.total_leads)} color={LEAD_BORDER}
                active={activeCard?.type === 'leads'}
                onClick={() => handleCardClick('leads', 'Novos Leads')}
              />
              <KpiCard
                label="Recuperações" value={n(kpi?.total_recuperacoes)} color={REC_BORDER}
                active={activeCard?.type === 'recuperacoes'}
                onClick={() => handleCardClick('recuperacoes', 'Recuperações')}
              />
              <KpiCard label="Conversas" value={n(kpi?.total_conversations)} />
              <KpiCard
                label="Encerradas" value={n(kpi?.total_encerradas)} color="#6b7280"
                active={activeCard?.type === 'encerramento'}
                onClick={() => handleCardClick('encerramento', 'Conversas Encerradas')}
              />
              <KpiCard
                label="Agendados" value={n(kpi?.total_agendados)} color="#7c3aed"
                sub="clientes com agendamento no período"
                active={activeCard?.type === 'agendados'}
                onClick={() => handleCardClick('agendados', 'Agendamentos')}
              />
            </div>
          </div>

          {/* KPI cards row 2 — outcomes */}
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">Desfechos das conversas</h3>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <KpiCard
                label="Interesse alto" value={n(kpi?.interesse_alto)} color="#16a34a"
                sub={n(kpi?.total_encerradas) > 0 ? `${Math.round((n(kpi?.interesse_alto) / n(kpi?.total_encerradas)) * 100)}% das encerradas` : undefined}
              />
              <KpiCard
                label="Interesse médio" value={n(kpi?.interesse_medio)} color="#3b82f6"
                sub={n(kpi?.total_encerradas) > 0 ? `${Math.round((n(kpi?.interesse_medio) / n(kpi?.total_encerradas)) * 100)}% das encerradas` : undefined}
              />
              <KpiCard
                label="Interesse baixo" value={n(kpi?.interesse_baixo)} color="#f59e0b"
                sub={n(kpi?.total_encerradas) > 0 ? `${Math.round((n(kpi?.interesse_baixo) / n(kpi?.total_encerradas)) * 100)}% das encerradas` : undefined}
              />
              <KpiCard
                label="Sem interesse" value={n(kpi?.sem_interesse)} color="#ef4444"
                sub={n(kpi?.total_encerradas) > 0 ? `${Math.round((n(kpi?.sem_interesse) / n(kpi?.total_encerradas)) * 100)}% das encerradas` : undefined}
              />
            </div>
          </div>

          {/* ── Modalidade cards (01) — always shown when there are appointments ── */}
          <div>
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest mb-3">
              Agendamentos por Modalidade
              <span className="text-gray-400 font-normal normal-case ml-1">— clique para ver os registros detalhados</span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {(['PRESENCIAL', 'ONLINE', 'SEM_MODALIDADE'] as const).map(mod => {
                const row = (data.byModalidade || []).find(r => r.modalidade === mod) || {
                  modalidade: mod, total: '0', agendados: '0', cancelados: '0',
                };
                return (
                  <ModalidadeCard
                    key={mod}
                    row={row}
                    active={activeCard?.type === 'modalidade' && activeCard?.modalidade === mod}
                    onClick={() => handleCardClick('modalidade', MODALIDADE_CONFIG[mod].label, mod)}
                  />
                );
              })}
            </div>

            {/* Summary cards: total agendados + total cancelados */}
            <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div
                onClick={() => handleCardClick('agendados', 'Todos os Agendamentos')}
                className={`rounded-xl border p-4 flex items-center gap-4 cursor-pointer transition-all hover:shadow-md ${activeCard?.type === 'agendados' && !activeCard?.modalidade ? 'ring-2 border-purple-500 -translate-y-0.5 shadow-md' : 'border-gray-100 bg-white'}`}
              >
                <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center text-purple-600 text-lg flex-shrink-0">📅</div>
                <div>
                  <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Total Agendados (período)</div>
                  <div className="text-2xl font-bold text-purple-700">{n(kpi?.total_agendados).toLocaleString('pt-BR')}</div>
                  <div className="text-[9px] text-gray-300">{activeCard?.type === 'agendados' && !activeCard?.modalidade ? '▼ ver detalhes' : '▶ clique para ver detalhes'}</div>
                </div>
              </div>
              <div
                onClick={() => handleCardClick('cancelados', 'Agendamentos Cancelados')}
                className={`rounded-xl border p-4 flex items-center gap-4 cursor-pointer transition-all hover:shadow-md ${activeCard?.type === 'cancelados' ? 'ring-2 border-red-400 -translate-y-0.5 shadow-md' : 'border-gray-100 bg-white'}`}
              >
                <div className="w-10 h-10 rounded-full bg-red-100 flex items-center justify-center text-red-500 text-lg flex-shrink-0">❌</div>
                <div>
                  <div className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Cancelados (período)</div>
                  <div className="text-2xl font-bold text-red-600">
                    {(data.byModalidade || []).reduce((acc, m) => acc + n(m.cancelados), 0).toLocaleString('pt-BR')}
                  </div>
                  <div className="text-[9px] text-gray-300">{activeCard?.type === 'cancelados' ? '▼ ver detalhes' : '▶ clique para ver detalhes'}</div>
                </div>
              </div>
            </div>
          </div>

          {/* ── Drill-down panel (02) ── */}
          {activeCard && (
            <div ref={drillRef}>
              <DrillDownTable
                rows={drillRows}
                type={activeCard.type}
                loading={drillLoading}
                title={activeCard.label}
                onClose={() => { setActiveCard(null); setDrillRows([]); }}
              />
            </div>
          )}

          {/* Charts row */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
              <h3 className="text-xs font-bold text-gray-700 mb-4">Leads vs Recuperações por Unidade</h3>
              {byUnitChartData ? <div style={{ height: 240 }}><Bar data={byUnitChartData} options={BAR_OPTIONS} /></div> : <EmptyChart />}
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
              <h3 className="text-xs font-bold text-gray-700 mb-4">Volume por Operador (top 10)</h3>
              {byOperatorChartData ? <div style={{ height: 240 }}><Bar data={byOperatorChartData} options={BAR_OPTIONS} /></div> : <EmptyChart />}
            </div>
          </div>

          {/* Time series */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
            <h3 className="text-xs font-bold text-gray-700 mb-4">Evolução de Leads e Recuperações no período</h3>
            {timeSeriesChartData ? <div style={{ height: 240 }}><Line data={timeSeriesChartData} options={LINE_OPTIONS} /></div> : <EmptyChart />}
          </div>

          {/* Operator ranking table */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-5">
            <h3 className="text-xs font-bold text-gray-700 mb-4">Ranking de Operadores</h3>
            <OperatorTable rows={data.byOperator} />
          </div>

          {/* ── WhatsApp por Unidade ── only shown when the user has accessible units */}
          {filterUnits.length > 0 && (
            <WhatsappByUnitSection
              units={waData}
              loading={waLoading}
              onRefresh={fetchWaByUnit}
              open={waOpen}
              onToggle={() => setWaOpen(o => !o)}
            />
          )}

          {/* ── Relatório Detalhado (04) ── */}
          <div data-testid="prospeccao-report-panel" className="bg-white rounded-xl shadow-sm border border-gray-100 min-w-0">
            <div className="px-5 pt-5 pb-3 border-b border-gray-100">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-xs font-bold text-gray-700">Relatório Detalhado</h3>
                  <p className="text-[10px] text-gray-400 mt-0.5">Dados completos por categoria — use as abas para navegar e os botões para exportar</p>
                </div>
                {/* Per-table export toolbar */}
                {reportFetched && (
                  <ExportToolbar
                    onExcelAll={async () => {
                      const cols = REPORT_COLUMNS[activeReportTab] || [];
                      await exportToExcel([{ name: REPORT_TABS.find(t => t.key === activeReportTab)?.label || activeReportTab, rows: reportRows, columns: cols }],
                        `prospecao_${activeReportTab}_${currentPeriodLabel.replace(/\s+/g, '_')}.xlsx`);
                    }}
                    onWordAll={() => {
                      const html = buildReportHtml(null, reportRows, activeReportTab, currentPeriodLabel, currentUnitName);
                      exportToWord(html, `prospecao_${activeReportTab}_${currentPeriodLabel.replace(/\s+/g, '_')}.doc`);
                    }}
                    onPdfAll={() => {
                      const html = buildReportHtml(null, reportRows, activeReportTab, currentPeriodLabel, currentUnitName);
                      exportToPdf(html, `Prospecção — ${REPORT_TABS.find(t => t.key === activeReportTab)?.label}`);
                    }}
                    onPrint={() => {
                      const cols = REPORT_COLUMNS[activeReportTab] || [];
                      const tabLabel = REPORT_TABS.find(t => t.key === activeReportTab)?.label || activeReportTab;
                      const html = `
                        <h2>${tabLabel} — ${reportRows.length} registros</h2>
                        <p>Período: ${currentPeriodLabel}${currentUnitName ? ` | Unidade: ${currentUnitName}` : ''}</p>
                        <table>
                          <thead><tr>${cols.map(c => `<th>${c.label}</th>`).join('')}</tr></thead>
                          <tbody>
                            ${reportRows.map(row => `<tr>${cols.map(c => `<td>${fmtCellValue(c.key, row[c.key] as string|number|null)}</td>`).join('')}</tr>`).join('')}
                          </tbody>
                        </table>
                      `;
                      const pw = window.open('', '_blank', 'width=900,height=700');
                      if (!pw) return;
                      pw.document.write(`<html><head><title>${tabLabel}</title><style>body{font-family:Arial;font-size:10pt;margin:1cm}table{border-collapse:collapse;width:100%}th{background:#2d4a3e;color:white;padding:4pt 6pt;font-size:8pt}td{border:1px solid #ddd;padding:3pt 6pt;font-size:8pt}tr:nth-child(even)td{background:#f7f7f7}</style></head><body>${html}</body></html>`);
                      pw.document.close(); pw.focus(); setTimeout(() => pw.print(), 400);
                    }}
                  />
                )}
              </div>
            </div>

            {/* Tab navigation */}
            <div className="flex overflow-x-auto border-b border-gray-100 px-5">
              {REPORT_TABS.map(tab => (
                <button
                  key={tab.key}
                  onClick={() => handleReportTab(tab.key)}
                  className={`px-4 py-2.5 text-xs font-semibold whitespace-nowrap border-b-2 transition-all ${
                    activeReportTab === tab.key
                      ? 'border-b-2 text-gray-800'
                      : 'border-transparent text-gray-400 hover:text-gray-600'
                  }`}
                  style={activeReportTab === tab.key ? { borderBottomColor: tab.color, color: tab.color } : undefined}
                >
                  {tab.label}
                  {activeReportTab === tab.key && reportFetched && (
                    <span className="ml-1.5 px-1.5 py-0.5 rounded-full text-[9px] font-bold text-white" style={{ background: tab.color }}>
                      {reportRows.length}
                    </span>
                  )}
                </button>
              ))}
            </div>

            {/* Report table content */}
            <div className="p-4 min-[1400px]:p-5">
              {!reportFetched && !reportLoading ? (
                <div className="text-center py-10">
                  <p className="text-gray-400 text-sm mb-3">Selecione uma aba acima para carregar os dados detalhados</p>
                  <button
                    onClick={() => handleReportTab(activeReportTab)}
                    className="px-4 py-2 text-xs text-white rounded-lg transition-colors"
                    style={{ background: MOSS }}
                  >
                    Carregar relatório
                  </button>
                </div>
              ) : reportLoading ? (
                <div className="flex items-center justify-center gap-2 py-10 text-gray-400 text-sm">
                  <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                  </svg>
                  Carregando dados...
                </div>
              ) : reportRows.length === 0 ? (
                <div className="text-center py-8 text-gray-400 text-sm">
                  Nenhum registro encontrado para o período e filtros selecionados.
                </div>
              ) : (
                <div data-testid="prospeccao-report-table" className="overflow-x-auto max-w-full">
                  <table aria-label="Relatório detalhado de prospecção" className="w-full min-w-[680px] text-xs operational-grid" data-grid-typography="preserve">
                    <thead className="bg-gray-50 border-b border-gray-100">
                      <tr>
                        {(REPORT_COLUMNS[activeReportTab] || []).map(c => (
                          <th key={c.key} className="px-3 py-2.5 text-left text-[10px] font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap">
                            {c.label}
                          </th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {reportRows.map((row, i) => (
                        <tr key={i} className="border-b border-gray-50 hover:bg-gray-50 transition-colors">
                          {(REPORT_COLUMNS[activeReportTab] || []).map(c => (
                            <td key={c.key} className="px-3 py-2 text-gray-700 whitespace-nowrap max-w-[200px] truncate">
                              {activeReportTab === 'encerramento' && c.key === 'desfecho' ? (
                                <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                  row.desfecho === 'INTERESSE_ALTO' ? 'bg-green-50 text-green-700' :
                                  row.desfecho === 'INTERESSE_MEDIO' ? 'bg-blue-50 text-blue-700' :
                                  row.desfecho === 'INTERESSE_BAIXO' ? 'bg-yellow-50 text-yellow-700' :
                                  row.desfecho === 'SEM_INTERESSE' ? 'bg-red-50 text-red-700' :
                                  'bg-gray-50 text-gray-600'
                                }`}>
                                  {OUTCOME_LABELS[row.desfecho as string] || row.desfecho || '—'}
                                </span>
                              ) : activeReportTab === 'encerramento' && c.key === 'tipo_contato' ? (
                                <span className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold ${row.tipo_contato === 'LEAD' ? 'bg-green-50 text-green-700' : 'bg-orange-50 text-orange-700'}`}>
                                  {row.tipo_contato || '—'}
                                </span>
                              ) : (activeReportTab === 'agendados' || activeReportTab === 'cancelados' || activeReportTab === 'modalidade') && c.key === 'status' ? (
                                <span className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-[10px] font-bold ${
                                  String(row.status).includes('CANCELADO') ? 'bg-red-50 text-red-700' :
                                  row.status === 'CONFIRMADO' ? 'bg-green-50 text-green-700' :
                                  'bg-gray-50 text-gray-600'
                                }`}>
                                  {String(row.status || '—').replace('_', ' ')}
                                </span>
                              ) : (
                                fmtCellValue(c.key, row[c.key] as string | number | null)
                              )}
                            </td>
                          ))}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>

        </div>
      ) : null}
    </div>
  );
};

export default ProspeccaoDashboard;

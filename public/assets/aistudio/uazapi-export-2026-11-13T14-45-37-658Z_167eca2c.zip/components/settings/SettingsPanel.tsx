/**
 * TÍTULO: PAINEL DE CONFIGURAÇÕES GERAIS
 * 
 * Este módulo gerencia todas as configurações administrativas da aplicação.
 * 
 * Funcionalidades principais:
 * 1. Configuração do Portal (Personalização de Cores, Texto, Logo).
 * 2. Gestão de Unidades (CRUD completo com DataGrid).
 * 3. Gestão de Usuários e Grupos (CRUD completo com permissões e vínculos).
 * 4. Gestão de E-mails (Configuração SMTP por unidade, Integração Google e Modelos).
 * 5. Integração com API (CRUD completo, Autenticação, Headers e Sandbox de Teste).
 * 
 * ATUALIZAÇÃO DE SEGURANÇA & AUDITORIA:
 * - Implementação do hook `useSecurity` para validar ações.
 * - Implementação do hook `useAudit` para registrar alterações globais e específicas.
 * - Implementação de navegação por Enter (handleEnterPress).
 * - VALIDAÇÃO E MÁSCARAS: CNPJ, Telefone, CEP e E-mail nas Unidades.
 */

import React, { lazy, Suspense, useState, useEffect, useRef, useCallback } from 'react';
import { sanitizeHtml } from '../../utils/sanitizeHtml';
import { PortalConfig, CompanyInfo, UserGroup, User, UserPermission, UserRole, UserStatus, MenuItem, EmailConfig, EmailTemplate, GoogleIntegrationConfig, ApiIntegration, ApiMethod, ApiAuthType, ApiHeader, HelpTopic, AuditCheckItem, EscalaDeTrabalho } from '../../types';
import { EscalaDeTrabalhoPanel } from './EscalaDeTrabalhoPanel';
const GotalkMessagesTab = lazy(() => import('./tabs/GotalkMessagesTab'));
const UazapiHistoryTab = lazy(() => import('./tabs/UazapiHistoryTab'));
const LeoKnowledgePanel = lazy(() => import('./LeoKnowledgePanel'));
import UazapiQrModal from './tabs/UazapiQrModal';
const ImportWizardTab = lazy(() => import('./tabs/ImportWizardTab'));
const QueueHealthTab = lazy(() => import('./tabs/QueueHealthTab'));
const HistoricalAuditUnitReview = lazy(() => import('./HistoricalAuditUnitReview'));
import { DEFAULT_HELP_TOPICS } from '../help/HelpContentData';
import { APP_MENU_STRUCTURE } from '../../constants';
import Button from '../ui/Button';
import Input from '../ui/Input';
import FormActions from '../ui/FormActions';
import { DEFAULT_PORTAL_CONFIG } from '../../constants';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { checkDependencies, formatDependencyMessage } from '../../utils/dependencyCheck';
import CameraCapture from '../ui/CameraCapture';
import { formatCurrencyBRL } from '../../utils/currencyUtils';
import AuditLogButton from '../ui/AuditLogButton';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';
import { api } from '../../services/apiService';
import {
  adminResetMfa,
  setupMfa,
  confirmMfaSetup,
  disableMfa,
  loadMfaDisableChallenge,
  type PhotoChallengeData,
} from '../../services/authService';
import PhotoChallenge from '../ui/PhotoChallenge';

interface SettingsPanelProps {
  config: PortalConfig;
  onClose: () => void;
  currentUser?: User | null;
  onRefresh?: () => void;
}

type TabType = 'PORTAL' | 'UNIDADES' | 'USUARIOS' | 'ESCALA' | 'EMAILS' | 'API' | 'AUDITORIA' | 'AJUDA' | 'SQL' | 'GOTALK_MSGS' | 'LEO_KNOWLEDGE' | 'UAZAPI_MSGS' | 'IMPORT' | 'QUEUE_HEALTH';
type PortalSubTab = 'LOGIN' | 'PRINCIPAL';
type UserSubTab = 'GRUPOS' | 'CADASTRO';
type EmailSubTab = 'SMTP' | 'GOOGLE' | 'MODELOS';
type ApiSubTab = 'GERAL' | 'AUTH' | 'HEADERS' | 'BODY' | 'TESTE';

// Definição das 7 ações solicitadas para a matriz de permissão
const PERMISSION_ACTIONS = [
  { id: 'VISUALIZAR', label: 'Ver', short: 'V', color: 'text-blue-600' },
  { id: 'INCLUIR', label: 'Incluir', short: 'I', color: 'text-green-600' },
  { id: 'ALTERAR', label: 'Alterar', short: 'A', color: 'text-yellow-600' },
  { id: 'EXCLUIR', label: 'Excluir', short: 'E', color: 'text-red-600' },
  { id: 'CANCELAR', label: 'Cancelar', short: 'C', color: 'text-orange-600' },
  { id: 'INATIVAR', label: 'Inativar', short: 'X', color: 'text-gray-600' },
  { id: 'IMPRIMIR', label: 'Imprimir', short: 'P', color: 'text-purple-600' },
];

// --- HELPER COMPONENT FOR COLOR PICKER (MOVED OUTSIDE TO FIX FOCUS ISSUE) ---
const ColorPickerItem = ({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) => (
    <div>
        <label className="block text-xs font-bold text-gray-500 mb-1 uppercase">{label}</label>
        <div className="flex items-center gap-2">
            <div className="relative h-10 w-10 overflow-hidden rounded border border-gray-300 shadow-sm flex-shrink-0">
                <input 
                    type="color" 
                    value={value} 
                    onChange={e => onChange(e.target.value)} 
                    className="absolute -top-2 -left-2 w-16 h-16 cursor-pointer p-0 m-0" 
                />
            </div>
            <input 
                type="text" 
                value={value} 
                onChange={e => onChange(e.target.value)} 
                className="flex-1 border border-gray-300 rounded-md px-3 py-2 text-sm font-mono uppercase focus:ring-2 focus:ring-moss-500 outline-none" 
                maxLength={7} 
            />
        </div>
    </div>
);

const SettingsPanel: React.FC<SettingsPanelProps> = ({ config, onClose, currentUser: loggedUser, onRefresh }) => {
  const updateSection = async (key: string, value: any) => {
    try {
      const res = await fetch('/api/settings/section', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key, value }) });
      if (res.ok && onRefresh) onRefresh();
    } catch (e) { console.error('updateSection error:', e); }
  };

  const saveSectionOrThrow = async (key: string, value: any) => {
    const res = await fetch('/api/settings/section', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key, value }) });
    if (!res.ok) throw new Error(`Falha ao salvar (HTTP ${res.status}).`);
    if (onRefresh) onRefresh();
  };
  const updateThemeSettings = async (data: Record<string, any>) => {
    try {
      const res = await fetch('/api/settings/theme', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
      if (res.ok && onRefresh) onRefresh();
    } catch (e) { console.error('updateThemeSettings error:', e); }
  };
  const { validarPermissao, temPermissao, addToast } = useSecurity();
  const { logTransaction } = useAudit();

  const isLoggedAdmin = loggedUser?.role === 'ADMIN';

  const { create: apiCreateUnit, update: apiUpdateUnit, remove: apiRemoveUnit } = useEntityCRUD<any>('units', { autoLoad: false });
  const { create: apiCreateGroup, update: apiUpdateGroup, remove: apiRemoveGroup } = useEntityCRUD<any>('user-groups', { autoLoad: false });
  const { create: apiCreateUser, update: apiUpdateUser, remove: apiRemoveUser } = useEntityCRUD<any>('users', { autoLoad: false });

  const [activeTab, setActiveTab] = useState<TabType>('PORTAL');
  const [sqlQuery, setSqlQuery] = useState('SELECT * FROM app_data LIMIT 10;');
  const [sqlResult, setSqlResult] = useState<{ rows: any[]; fields: { name: string }[]; rowCount: number | null; duration: number; truncated?: boolean; command?: string | null } | null>(null);
  const [sqlError, setSqlError] = useState<string | null>(null);
  const [sqlLoading, setSqlLoading] = useState(false);
  const [sqlHistory, setSqlHistory] = useState<string[]>([]);
  const [sqlDestructiveConfirm, setSqlDestructiveConfirm] = useState(false);
  const [portalSubTab, setPortalSubTab] = useState<PortalSubTab>('LOGIN');
  const [userSubTab, setUserSubTab] = useState<UserSubTab>('CADASTRO');
  const [emailSubTab, setEmailSubTab] = useState<EmailSubTab>('SMTP');
  
  // API Tab States
  const [isEditingApi, setIsEditingApi] = useState(false);
  const [currentApi, setCurrentApi] = useState<ApiIntegration | null>(null);
  const [originalApi, setOriginalApi] = useState<ApiIntegration | null>(null); // SNAPSHOT FOR API
  const [apiSubTab, setApiSubTab] = useState<ApiSubTab>('GERAL');
  const [apiTestResult, setApiTestResult] = useState<{status: number; body: string; time: number} | null>(null);
  const [isTestingApi, setIsTestingApi] = useState(false);

  // GoTalk Webhook card states
  const [webhookStatus, setWebhookStatus] = useState<{webhookUrl: string; secretConfigured: boolean; totalMessages: number; lastWebhookAt: string | null} | null>(null);
  const [webhookSecretInput, setWebhookSecretInput] = useState('');
  const [webhookSecretSaving, setWebhookSecretSaving] = useState(false);
  const [webhookSecretMsg, setWebhookSecretMsg] = useState<string | null>(null);
  const [webhookUrlCopied, setWebhookUrlCopied] = useState(false);
  const [uazapiWebhookUrlCopied, setUazapiWebhookUrlCopied] = useState(false);
  const [webhookRotating, setWebhookRotating] = useState(false);
  const [generatedSecret, setGeneratedSecret] = useState<string | null>(null);
  const [generatedSecretCopied, setGeneratedSecretCopied] = useState(false);

  const [isLoadingCep, setIsLoadingCep] = useState(false);
  const [showCamera, setShowCamera] = useState(false);
  
  // Local state to manage form changes before saving
  const [localConfig, setLocalConfig] = useState<PortalConfig>(config);

  // --- CRUD STATES ---
  const [isEditingUnit, setIsEditingUnit] = useState(false);
  const [currentUnit, setCurrentUnit] = useState<CompanyInfo | null>(null);
  const [originalUnit, setOriginalUnit] = useState<CompanyInfo | null>(null); // SNAPSHOT
  const [unitValidationErrors, setUnitValidationErrors] = useState<{ cnpj?: string, email?: string }>({}); // UNIT VALIDATION
  const [isSavingUnit, setIsSavingUnit] = useState(false);

  // ── Multi-instance WhatsApp / uazapi state ──────────────────────────────
  type UazapiInstanceStatus = {
    configured: boolean; isConnected: boolean; connectedAt: string | null;
    phoneNumber: string | null; serverUrl: string | null; error?: string | null;
  };
  type UazapiInstance = {
    credId?: string;
    label: string;
    instanceId: string;
    serverUrl: string;
    hasToken: boolean;
    // per-instance transient UI state
    token: string;
    status: UazapiInstanceStatus | null;
    expanded: boolean;
    loading: boolean;
    showDisconnectConfirm: boolean;
  };
  const [uazapiInstances, setUazapiInstances] = useState<UazapiInstance[]>([]);
  const [uazapiLoading, setUazapiLoading] = useState(false);
  const uazapiLoadGenerationRef = useRef(0);
  const [showNewInstanceForm, setShowNewInstanceForm] = useState(false);
  const [spQrModal, setSpQrModal] = useState<{ instanceId: string; unitId: string; label?: string } | null>(null);
  const [newInstanceForm, setNewInstanceForm] = useState({
    label: '', instanceId: '', serverUrl: 'centralhub.uazapi.com', token: '', phoneNumber: '',
  });
  const [newInstanceConnecting, setNewInstanceConnecting] = useState(false);

  const [isEditingGroup, setIsEditingGroup] = useState(false);
  const [currentGroup, setCurrentGroup] = useState<UserGroup | null>(null);
  const [originalGroup, setOriginalGroup] = useState<UserGroup | null>(null); // SNAPSHOT

  const [isEditingUser, setIsEditingUser] = useState(false);
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [originalUser, setOriginalUser] = useState<User | null>(null); // SNAPSHOT
  const [userPassword, setUserPassword] = useState(''); // Estado separado para senha (só altera se preenchido)
  const [isSavingUser, setIsSavingUser] = useState(false);
  const [mfaResetLoading, setMfaResetLoading] = useState(false);
  const [mfaSetupStep, setMfaSetupStep] = useState<null | 'LOADING' | 'QR' | 'BACKUP' | 'CONFIRM_DISABLE'>(null);
  const [mfaSetupData, setMfaSetupData] = useState<{ secret: string; qrCodeDataUrl: string; backupCodes?: string[] } | null>(null);
  const [mfaConfirmCode, setMfaConfirmCode] = useState('');
  const [mfaSetupLoading, setMfaSetupLoading] = useState(false);
  const [mfaDisablePassword, setMfaDisablePassword] = useState('');
  const [mfaDisableChallenge, setMfaDisableChallenge] = useState<PhotoChallengeData | null>(null);
  const [mfaDisableSelectedIds, setMfaDisableSelectedIds] = useState<string[]>([]);
  const [mfaDisableVerified, setMfaDisableVerified] = useState(false);
  const [collapsedGroups, setCollapsedGroups] = useState<Set<string>>(new Set());
  const toggleGroupCollapse = (id: string) =>
    setCollapsedGroups(prev => { const next = new Set(prev); next.has(id) ? next.delete(id) : next.add(id); return next; });

  const closeUserEditor = useCallback(() => {
    setIsEditingUser(false);
    setCurrentUser(null);
    setOriginalUser(null);
    setUserPassword('');
    setShowCamera(false);
    setMfaSetupStep(null);
    setMfaSetupData(null);
    setMfaConfirmCode('');
    setMfaDisablePassword('');
    setMfaDisableChallenge(null);
    setMfaDisableSelectedIds([]);
    setMfaDisableVerified(false);
  }, []);

  useEffect(() => {
    if (!isEditingUser) return;
    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape' && !isSavingUser && !mfaSetupLoading) closeUserEditor();
    };
    window.addEventListener('keydown', handleEscape);
    return () => window.removeEventListener('keydown', handleEscape);
  }, [isEditingUser, isSavingUser, mfaSetupLoading, closeUserEditor]);

  // --- EMAIL TAB STATES ---
  const [selectedUnitIdForSmtp, setSelectedUnitIdForSmtp] = useState<string>('');
  const [testEmailTarget, setTestEmailTarget] = useState('');
  const [isTestingEmail, setIsTestingEmail] = useState(false);
  const [showTestEmailModal, setShowTestEmailModal] = useState(false);
  
  // Templates State
  const [isEditingTemplate, setIsEditingTemplate] = useState(false);
  const [currentTemplate, setCurrentTemplate] = useState<EmailTemplate | null>(null);
  const [originalTemplate, setOriginalTemplate] = useState<EmailTemplate | null>(null); // SNAPSHOT

  // --- REFS FOR NAVIGATION ---
  const enderecoRef = useRef<HTMLInputElement>(null);
  const numeroRef = useRef<HTMLInputElement>(null);
  const userPhotoRef = useRef<HTMLInputElement>(null); // Ref para o input de arquivo do usuário
  const logoInputRef = useRef<HTMLInputElement>(null); // Ref para o input de logo da empresa
  const bgImageInputRef = useRef<HTMLInputElement>(null); // Ref para background login

  const [helpTopics, setHelpTopics] = useState<HelpTopic[]>(config.helpTopics || DEFAULT_HELP_TOPICS);
  const [editingTopicId, setEditingTopicId] = useState<string | null>(null);
  const [editingTopic, setEditingTopic] = useState<HelpTopic | null>(null);
  const [helpSearchTerm, setHelpSearchTerm] = useState('');
  const [isCreatingTopic, setIsCreatingTopic] = useState(false);

  const [isEditingAuditItem, setIsEditingAuditItem] = useState(false);
  const [currentAuditItem, setCurrentAuditItem] = useState<AuditCheckItem | null>(null);
  const [originalAuditItem, setOriginalAuditItem] = useState<AuditCheckItem | null>(null);
  const [showInactiveAuditItems, setShowInactiveAuditItems] = useState(false);
  const [auditMigrateModal, setAuditMigrateModal] = useState<{ type: 'swap' | 'overwrite' | 'duplicate'; sourceId: string } | null>(null);
  const [auditMigrateTargetId, setAuditMigrateTargetId] = useState('');

  // Definition of tabs and their permissions
  const TABS_CONFIG: { id: TabType; label: string; permission: string }[] = [
    { id: 'PORTAL', label: 'Portal', permission: 'settings_portal' },
    { id: 'UNIDADES', label: 'Unidades', permission: 'settings_units' },
    { id: 'USUARIOS', label: 'Usuários', permission: 'settings_users' },
    { id: 'ESCALA', label: 'Escala de Trabalho', permission: 'settings_users' },
    { id: 'AUDITORIA', label: 'Auditoria', permission: 'settings_audit' },
    { id: 'EMAILS', label: 'E-mails', permission: 'settings_emails' },
    { id: 'API', label: 'API\'s', permission: 'settings_api' },
    { id: 'GOTALK_MSGS', label: 'Mensagens GoTalk', permission: 'settings_api' },
    { id: 'UAZAPI_MSGS', label: 'Histórico uazapi', permission: 'settings_api' },
    { id: 'IMPORT', label: 'Importação Excel', permission: 'settings_import' },
    { id: 'AJUDA', label: 'Central de Ajuda', permission: 'settings_help' },
  ];

  // Sync local state if parent config changes
  useEffect(() => {
    setLocalConfig(config);
    if (config.units.length > 0 && !selectedUnitIdForSmtp) {
        setSelectedUnitIdForSmtp(config.units[0].id || '');
    }
  }, [config]);

  // Initial tab selection
  useEffect(() => {
    const currentTabAllowed = TABS_CONFIG.find(t => t.id === activeTab && temPermissao(t.permission));
    if (!currentTabAllowed) {
        const firstAllowed = TABS_CONFIG.find(t => temPermissao(t.permission));
        if (firstAllowed) setActiveTab(firstAllowed.id);
    }
  }, []);

  // Load GoTalk webhook status when API tab is active
  useEffect(() => {
    if (activeTab !== 'API') return;
    fetch('/api/gotalk/webhook-status')
      .then(r => r.ok ? r.json() : null)
      .then(d => { if (d) setWebhookStatus(d); })
      .catch(() => {});
  }, [activeTab]);

  const updateConfig = (field: keyof PortalConfig, value: any) => {
    setLocalConfig(prev => ({ ...prev, [field]: value }));
  };

  const updateTheme = (field: keyof PortalConfig['theme'], value: string) => {
    setLocalConfig(prev => ({ ...prev, theme: { ...prev.theme, [field]: value } }));
  };

  // Helper para atualizar cores da marca em todos os lugares (Login, Sidebar, Header)
  const updateBrandColors = (type: 'bg' | 'text', value: string) => {
      setLocalConfig(prev => ({
          ...prev,
          theme: {
              ...prev.theme,
              // Aplica no Login Esquerdo (Identidade)
              [type === 'bg' ? 'loginLeftBgColor' : 'loginLeftTextColor']: value,
              // Aplica no Menu Lateral (Sidebar)
              [type === 'bg' ? 'sidebarBgColor' : 'sidebarTextColor']: value,
              // Aplica no Cabeçalho (Header)
              [type === 'bg' ? 'headerBgColor' : 'headerTextColor']: value,
          }
      }));
  };

  const handleTabChange = (tab: TabType) => {
    setActiveTab(tab);
    setIsEditingUnit(false); setCurrentUnit(null); setUnitValidationErrors({});
    setIsEditingGroup(false); setCurrentGroup(null);
    closeUserEditor();
    setIsEditingApi(false); setCurrentApi(null);
    setIsEditingTemplate(false); setCurrentTemplate(null);
  };

  const isDestructiveQuery = (q: string): boolean => {
    const normalized = q.replace(/--.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').trim().toUpperCase();
    return /\b(DELETE|TRUNCATE|DROP|ALTER|INSERT|UPDATE|CREATE|GRANT|REVOKE)\b/.test(normalized);
  };

  const executeSql = async (q: string) => {
    setSqlDestructiveConfirm(false);
    setSqlLoading(true);
    setSqlError(null);
    setSqlResult(null);
    try {
      const data = await api.post('/api/sql', { query: q });
      setSqlResult(data);
      setSqlHistory(prev => {
        const next = [q, ...prev.filter(h => h !== q)].slice(0, 10);
        return next;
      });
    } catch (e: any) {
      setSqlError(e?.message || 'Falha na requisição ao servidor.');
    } finally {
      setSqlLoading(false);
    }
  };

  const handleRunSql = () => {
    const q = sqlQuery.trim();
    if (!q) return;
    if (isDestructiveQuery(q) && !sqlDestructiveConfirm) {
      setSqlDestructiveConfirm(true);
      return;
    }
    executeSql(q);
  };

  // --- FOCUS MANAGEMENT VIA ENTER ---
  const handleEnterPress = (e: React.KeyboardEvent<HTMLElement>) => {
    if (e.ctrlKey && e.key === 'Enter') {
        e.preventDefault();
        if (isEditingUnit) { handleSaveUnit(); return; }
        return;
    }
    if (e.key === 'Enter') {
        e.preventDefault(); 
        const form = e.currentTarget.closest('div[data-form-container="true"]');
        if (!form) return;

        const focusableElements = form.querySelectorAll<HTMLElement>(
            'input:not([disabled]):not([type="hidden"]):not([readonly]), select:not([disabled]), textarea:not([disabled]), button:not([disabled])'
        );
        
        const focusableArray = Array.from(focusableElements) as HTMLElement[];
        const index = focusableArray.indexOf(e.currentTarget as HTMLElement);
        
        if (index > -1 && index < focusableArray.length - 1) {
            focusableArray[index + 1].focus();
        }
    }
  };

  // --- GOTALK WEBHOOK SECRET HANDLER ---
  const handleSaveWebhookSecret = async () => {
    setWebhookSecretSaving(true);
    setWebhookSecretMsg(null);
    try {
      const res = await fetch('/api/gotalk/webhook-secret', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ secret: webhookSecretInput }),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        setWebhookSecretMsg(data.message);
        setWebhookSecretInput('');
        const r2 = await fetch('/api/gotalk/webhook-status');
        if (r2.ok) setWebhookStatus(await r2.json());
      } else {
        setWebhookSecretMsg(data.error || 'Erro ao salvar.');
      }
    } catch {
      setWebhookSecretMsg('Erro de conexão.');
    } finally {
      setWebhookSecretSaving(false);
    }
  };

  // --- GOTALK ROTATE WEBHOOK SECRET HANDLER ---
  const handleRotateWebhookSecret = async () => {
    setWebhookRotating(true);
    setGeneratedSecret(null);
    setGeneratedSecretCopied(false);
    setWebhookSecretMsg(null);
    try {
      const res = await fetch('/api/gotalk/rotate-webhook-secret', { method: 'POST' });
      const data = await res.json();
      if (res.ok && data.success) {
        setGeneratedSecret(data.secret);
        const r2 = await fetch('/api/gotalk/webhook-status');
        if (r2.ok) setWebhookStatus(await r2.json());
      } else {
        setWebhookSecretMsg(data.error || 'Erro ao gerar secret.');
      }
    } catch {
      setWebhookSecretMsg('Erro de conexão.');
    } finally {
      setWebhookRotating(false);
    }
  };

  // --- API INTEGRATION HANDLERS ---
  const handleNewApi = () => { 
      if (!validarPermissao('INCLUIR')) return; 
      const newApi: ApiIntegration = { 
          id: '', 
          name: 'Nova Integração', 
          description: '',
          baseUrl: 'https://api.exemplo.com/v1', 
          method: 'GET', 
          authType: 'NONE', 
          headers: [{key: 'Content-Type', value: 'application/json'}], 
          bodyTemplate: '{\n  "chave": "valor"\n}' 
      };
      setCurrentApi(newApi);
      setOriginalApi(null); // CREATE MODE
      setApiSubTab('GERAL'); 
      setApiTestResult(null); 
      setIsEditingApi(true); 
  };

  const handleEditApi = (api: ApiIntegration) => { 
      if (!validarPermissao('ALTERAR')) return; 
      setCurrentApi({ ...api });
      setOriginalApi({ ...api }); // EDIT MODE 
      setApiSubTab('GERAL'); 
      setApiTestResult(null); 
      setIsEditingApi(true); 
  };

  const handleDeleteApi = async (id: string) => { 
      if (!validarPermissao('EXCLUIR')) return; 
      if (!window.confirm('Excluir esta integração?')) return;
      const apiToDelete = localConfig.apiIntegrations.find(a => a.id === id);
      const updatedApis = (localConfig.apiIntegrations || []).filter(a => a.id !== id); 
      try {
          await saveSectionOrThrow('apiIntegrations', updatedApis);
          logTransaction('CONFIG', id, apiToDelete, null);
          addToast('success', 'Sucesso', 'Integração excluída.'); 
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível excluir a integração.');
      }
  };

  const handleSaveApi = async () => { 
      if (!currentApi?.name || !currentApi?.baseUrl) {
          addToast('warning', 'Validação', 'Nome e URL são obrigatórios.');
          return;
      }
      const apis = [...(localConfig.apiIntegrations || [])];
      let apiToSave = { ...currentApi };

      if (apiToSave.id) { 
          const idx = apis.findIndex(a => a.id === apiToSave.id); 
          if (idx !== -1) apis[idx] = apiToSave; else apis.push(apiToSave);
      } else { 
          apiToSave.id = 'api-' + Date.now();
          apis.push(apiToSave); 
      }
      try {
          await saveSectionOrThrow('apiIntegrations', apis);
          logTransaction('CONFIG', apiToSave.id, originalApi, apiToSave);
          setIsEditingApi(false);
          addToast('success', 'Salvo', 'Integração salva com sucesso.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível salvar a integração.');
      }
  };

  const addApiHeader = () => { 
      if(currentApi) setCurrentApi({...currentApi, headers: [...currentApi.headers, {key:'', value:''}]}); 
  };

  const updateApiHeader = (idx: number, field: 'key'|'value', value: string) => { 
      if(currentApi) { 
          const h = [...currentApi.headers]; 
          h[idx][field] = value; 
          setCurrentApi({...currentApi, headers: h}); 
      }
  };

  const removeApiHeader = (idx: number) => { 
      if(currentApi) setCurrentApi({...currentApi, headers: currentApi.headers.filter((_, i) => i !== idx)}); 
  };

  const executeApiTest = async () => { 
      setIsTestingApi(true); 
      // Simulação de Request
      setTimeout(() => { 
          setApiTestResult({
              status: 200, 
              body: currentApi?.method === 'GET' ? '{\n  "success": true,\n  "data": [\n    { "id": 1, "name": "Item A" },\n    { "id": 2, "name": "Item B" }\n  ]\n}' : '{\n  "success": true,\n  "message": "Operação realizada com sucesso",\n  "timestamp": "' + new Date().toISOString() + '"\n}', 
              time: Math.floor(Math.random() * 200) + 50
          }); 
          setIsTestingApi(false); 
      }, 1000); 
  };

  // --- EMAIL & TEMPLATE HANDLERS ---
  const getSelectedUnit = () => localConfig.units.find(u => u.id === selectedUnitIdForSmtp);
  
  const updateUnitEmailConfig = (field: keyof EmailConfig, value: string) => {
    const unit = getSelectedUnit();
    if (!unit) return;
    const newEmailConfig: EmailConfig = {
        host: '', port: '', user: '', password: '', senderName: '', security: 'TLS', 
        ...(unit.emailConfig || {}), // Preserve existing or default
        [field]: value
    };
    const updatedUnits = localConfig.units.map(u => 
        u.id === selectedUnitIdForSmtp ? { ...u, emailConfig: newEmailConfig } : u
    );
    updateConfig('units', updatedUnits);
  };

  const handleGoogleConnect = () => {
      const unit = getSelectedUnit();
      if (!unit) return;
      const newGoogleConfig: GoogleIntegrationConfig = {
          isConnected: true,
          accountEmail: 'financeiro@' + (unit.email?.split('@')[1] || 'gmail.com'),
          lastSync: new Date().toISOString(),
          accessToken: 'mock-token-123'
      };
      const updatedUnits = localConfig.units.map(u => 
        u.id === selectedUnitIdForSmtp ? { ...u, googleIntegration: newGoogleConfig } : u
      );
      updateConfig('units', updatedUnits);
      logTransaction('CONFIG', unit.id || 'SMTP', null, newGoogleConfig); // Audit
      addToast('success', 'Conectado', 'Conta Google vinculada com sucesso.');
  };

  const handleGoogleDisconnect = () => {
      const unit = getSelectedUnit();
      const updatedUnits = localConfig.units.map(u => 
        u.id === selectedUnitIdForSmtp ? { ...u, googleIntegration: { isConnected: false } } : u
      );
      updateConfig('units', updatedUnits);
      if(unit) logTransaction('CONFIG', unit.id, unit.googleIntegration, {isConnected: false}); // Audit
      addToast('info', 'Desconectado', 'Vínculo com Google removido.');
  };

  const handleSaveTemplate = async () => {
      if (!validarPermissao(currentTemplate?.id ? 'ALTERAR' : 'INCLUIR')) return;
      if (!currentTemplate?.title || !currentTemplate?.subject) {
          addToast('warning', 'Validação', 'Título e Assunto são obrigatórios.');
          return;
      }
      const templates = [...localConfig.emailTemplates];
      let tplToSave = { ...currentTemplate };

      if (tplToSave.id) {
          const idx = templates.findIndex(t => t.id === tplToSave.id);
          if (idx !== -1) templates[idx] = tplToSave; else templates.push(tplToSave);
      } else {
          tplToSave.id = 'tpl-' + Date.now();
          templates.push(tplToSave);
      }
      try {
          await saveSectionOrThrow('emailTemplates', templates);
          logTransaction('CONFIG', tplToSave.id, originalTemplate, tplToSave);
          setIsEditingTemplate(false);
          setCurrentTemplate(null);
          setOriginalTemplate(null);
          addToast('success', 'Salvo', 'Modelo de e-mail salvo.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível salvar o modelo.');
      }
  };

  const handleDeleteTemplate = async (id: string) => {
      if (!validarPermissao('EXCLUIR')) return;
      if (!window.confirm('Excluir este modelo?')) return;
      const tplToDelete = localConfig.emailTemplates.find(t => t.id === id);
      const templates = localConfig.emailTemplates.filter(t => t.id !== id);
      try {
          await saveSectionOrThrow('emailTemplates', templates);
          logTransaction('CONFIG', id, tplToDelete, null);
          addToast('success', 'Excluído', 'Modelo removido.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível excluir o modelo.');
      }
  };

  // --- USER & GROUP HANDLERS ---
  const toggleGroupPermission = (permId: UserPermission) => {
    if (!currentGroup) return;
    const hasPerm = currentGroup.permissions.includes(permId);
    let newPerms = [...currentGroup.permissions];
    if (hasPerm) {
      newPerms = newPerms.filter(p => p !== permId);
      if (!permId.includes(':')) { newPerms = newPerms.filter(p => !p.startsWith(`${permId}:`)); }
    } else {
      newPerms.push(permId);
      if (permId.includes(':')) {
        const baseMenuId = permId.split(':')[0];
        if (!newPerms.includes(baseMenuId)) { newPerms.push(baseMenuId); }
      }
    }
    setCurrentGroup({ ...currentGroup, permissions: newPerms });
  };

  const fmtServerUrl = (raw: string) => {
    const s = (raw || '').trim();
    if (!s) return '';
    if (s.startsWith('http://') || s.startsWith('https://')) return s;
    return `https://${s}`;
  };

  const resetUazapiState = () => {
    uazapiLoadGenerationRef.current += 1;
    setUazapiInstances([]);
    setUazapiLoading(false);
    setShowNewInstanceForm(false);
    setSpQrModal(null);
    setNewInstanceForm({ label: '', instanceId: '', serverUrl: 'centralhub.uazapi.com', token: '', phoneNumber: '' });
    setNewInstanceConnecting(false);
  };

  const loadUazapiInstances = async (unitId: string) => {
    if (!unitId) return;
    const loadGeneration = ++uazapiLoadGenerationRef.current;
    setUazapiLoading(true);
    const [credResult, statusResult] = await Promise.allSettled([
      fetch(`/api/units/${unitId}/uazapi-credentials`),
      fetch(`/api/uazapi/status?unitId=${unitId}`),
    ]);

    let credInstances: { credId?: string; label: string; instanceId: string; serverUrl: string; hasToken: boolean }[] = [];
    try {
      if (credResult.status === 'fulfilled' && credResult.value.ok) {
        const data = await credResult.value.json();
        credInstances = (data.instances || []).map((inst: any) => ({
          credId: inst.credId,
          label: inst.label || '',
          instanceId: inst.uazapiInstanceId || '',
          serverUrl: (inst.uazapiServerUrl || 'centralhub.uazapi.com').replace(/^https?:\/\//, ''),
          hasToken: Boolean(inst.hasToken),
        }));
      }
    } catch { /* ignore */ }

    let statusMap: Record<string, any> = {};
    try {
      if (statusResult.status === 'fulfilled' && statusResult.value.ok) {
        const data = await statusResult.value.json();
        if (Array.isArray(data.instances)) {
          data.instances.forEach((s: any) => { if (s.instanceId) statusMap[s.instanceId] = s; });
        }
      }
    } catch { /* ignore */ }

    const merged: UazapiInstance[] = credInstances.map(ci => ({
      ...ci,
      token: '',
      status: statusMap[ci.instanceId] || null,
      expanded: false,
      loading: false,
      showDisconnectConfirm: false,
    }));
    if (loadGeneration !== uazapiLoadGenerationRef.current) return;
    setUazapiInstances(merged);
    setUazapiLoading(false);
  };

  const updateInstance = (instanceId: string, patch: Partial<UazapiInstance>) => {
    setUazapiInstances(prev => prev.map(inst => inst.instanceId === instanceId ? { ...inst, ...patch } : inst));
  };

  const handleReconnectInstance = async (inst: UazapiInstance) => {
    if (!currentUnit?.id) return;
    updateInstance(inst.instanceId, { loading: true });
    try {
      const res = await fetch('/api/uazapi/reconnect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          unitId: currentUnit.id,
          instanceId: inst.instanceId,
          label: inst.label || undefined,
          serverUrl: fmtServerUrl(inst.serverUrl) || undefined,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        addToast('success', 'Reconectado', data.isConnected ? 'Conexão verificada.' : 'Credenciais ok, mas instância offline.');
        await loadUazapiInstances(currentUnit.id);
      } else {
        addToast('error', 'Erro ao reconectar', data.error || 'Erro desconhecido.');
      }
    } catch { addToast('error', 'Erro', 'Não foi possível reconectar.'); }
    finally { updateInstance(inst.instanceId, { loading: false }); }
  };

  const handleConnectNewTokenInstance = async (inst: UazapiInstance) => {
    if (!currentUnit?.id) return;
    updateInstance(inst.instanceId, { loading: true });
    try {
      const tokenVal = inst.token.trim();
      let res: Response;
      if (tokenVal) {
        // Full connect/update with new token
        res = await fetch('/api/uazapi/connect', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            unitId: currentUnit.id,
            instanceId: inst.instanceId,
            serverUrl: fmtServerUrl(inst.serverUrl),
            instanceToken: tokenVal,
            phoneNumber: (currentUnit.whatsappNumber || inst.instanceId || '').replace(/\D/g, '') || inst.instanceId,
            label: inst.label || undefined,
          }),
        });
      } else {
        // Metadata-only update: label + serverUrl (no token change)
        res = await fetch(`/api/units/${currentUnit.id}/uazapi-credentials`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            uazapiInstanceId: inst.instanceId,
            uazapiServerUrl: fmtServerUrl(inst.serverUrl),
            label: inst.label || undefined,
          }),
        });
      }
      const data = await res.json();
      if (res.ok) {
        addToast('success', tokenVal ? 'Conectado' : 'Atualizado', tokenVal && data.webhookRegistered ? 'Conectado. Webhook registrado!' : tokenVal ? 'Conectado com sucesso.' : 'Rótulo e servidor atualizados.');
        await loadUazapiInstances(currentUnit.id);
      } else {
        addToast('error', 'Erro ao conectar', data.error || 'Erro desconhecido.');
        updateInstance(inst.instanceId, { loading: false });
      }
    } catch {
      addToast('error', 'Erro', 'Não foi possível conectar.');
      updateInstance(inst.instanceId, { loading: false });
    }
  };

  const handleQuickQrConnect = async (u: { id?: string; razaoSocial?: string; nomeFantasia?: string }) => {
    if (!u.id) return;
    try {
      // Fetch live status of all instances for this unit in one call
      const sr = await fetch(`/api/uazapi/status?${new URLSearchParams({ unitId: u.id })}`);
      if (!sr.ok) {
        addToast('error', 'Erro', 'Não foi possível verificar as instâncias WhatsApp.');
        return;
      }
      const sd = await sr.json();
      const instances: any[] = sd?.instances || (sd?.instanceId ? [sd] : []);

      if (instances.length === 0) {
        addToast('warning', 'Sem instância configurada', 'Configure uma instância WhatsApp em Editar → WhatsApp / uazapi.');
        return;
      }

      // Separate instances by status
      const connected     = instances.filter((i: any) => i.isConnected);
      const invalidToken  = instances.filter((i: any) => i.tokenInvalid);
      const disconnected  = instances.filter((i: any) => i.configured !== false && !i.isConnected && !i.tokenInvalid);

      if (disconnected.length === 0) {
        if (connected.length > 0) {
          // All valid instances are connected
          const phones = connected.map((i: any) => i.phoneNumber || i.label || i.instanceId).join(', ');
          addToast('success', 'WhatsApp já conectado', phones ? `Número(s): ${phones}` : 'Todas as instâncias estão ativas.');
        } else if (invalidToken.length > 0) {
          // Only invalid-token instances — user needs to update credentials
          const names = invalidToken.map((i: any) => i.label || i.instanceId).join(', ');
          addToast('error', 'Token inválido', `Atualize o token das instâncias: ${names}. Acesse Editar → WhatsApp / uazapi.`);
        } else {
          addToast('warning', 'Sem instância configurada', 'Configure uma instância WhatsApp em Editar → WhatsApp / uazapi.');
        }
        return;
      }

      // Open QR modal for the first disconnected instance with a valid token
      const target = disconnected[0];
      const label = target.phoneNumber && target.phoneNumber !== target.instanceId
        ? `${target.label || target.instanceId} · ${target.phoneNumber}`
        : (target.label || target.instanceId);

      setSpQrModal({ instanceId: target.instanceId, unitId: u.id, label });
    } catch {
      addToast('error', 'Erro', 'Não foi possível verificar as instâncias WhatsApp.');
    }
  };

  const handleDisconnectInstance = async (inst: UazapiInstance, force = false) => {
    if (!currentUnit?.id) return;
    updateInstance(inst.instanceId, { loading: true, showDisconnectConfirm: false });
    try {
      const res = await fetch('/api/uazapi/disconnect', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ unitId: currentUnit.id, instanceId: inst.instanceId, force }),
      });
      const data = await res.json();
      if (data.success) {
        if (data.uazapiDisconnected) {
          addToast('success', 'Desconectado', 'Sessão encerrada no servidor e credenciais removidas.');
        } else {
          addToast('warning', 'Credenciais removidas', 'Credenciais locais removidas. A sessão pode continuar ativa no servidor uazapi até expirar.');
        }
        setUazapiInstances(prev => prev.filter(i => i.instanceId !== inst.instanceId));
      } else if (res.status === 422 && !force) {
        // Upstream failed — offer force removal
        updateInstance(inst.instanceId, { loading: false });
        addToast('warning', 'Falha ao desconectar no servidor', `${data.error || 'Erro desconhecido.'} Clique em "Remover" novamente para forçar a remoção local.`);
        // Re-show the disconnect confirm so user can trigger force
        setTimeout(() => updateInstance(inst.instanceId, { showDisconnectConfirm: true }), 100);
      } else {
        addToast('error', 'Erro ao desconectar', data.error || 'Erro desconhecido.');
        updateInstance(inst.instanceId, { loading: false });
      }
    } catch {
      addToast('error', 'Erro', 'Não foi possível contactar o servidor.');
      updateInstance(inst.instanceId, { loading: false });
    }
  };

  const handleConnectNewInstance = async () => {
    if (!currentUnit?.id) return;
    const { label, instanceId, serverUrl, token, phoneNumber } = newInstanceForm;
    if (!instanceId.trim()) { addToast('warning', 'Atenção', 'Informe o ID da Instância.'); return; }
    if (!token.trim()) { addToast('warning', 'Atenção', 'Informe o Token uazapi.'); return; }
    const phone = (phoneNumber || currentUnit.whatsappNumber || '').replace(/\D/g, '');
    if (!phone) { addToast('warning', 'Atenção', 'Informe o Número WhatsApp.'); return; }
    setNewInstanceConnecting(true);
    try {
      const res = await fetch('/api/uazapi/connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          unitId: currentUnit.id,
          instanceId: instanceId.trim(),
          serverUrl: fmtServerUrl(serverUrl),
          instanceToken: token.trim(),
          phoneNumber: phone,
          label: label.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        const msg = data.webhookRegistered ? 'Credenciais salvas. Webhook registrado!' : 'Credenciais salvas com sucesso.';
        addToast('success', 'Instância configurada', msg);
        if (data.warning) addToast('warning', 'Aviso do servidor', data.warning);
        setShowNewInstanceForm(false);
        setNewInstanceForm({ label: '', instanceId: '', serverUrl: 'centralhub.uazapi.com', token: '', phoneNumber: '' });
        await loadUazapiInstances(currentUnit.id);
      } else {
        addToast('error', 'Erro ao conectar', data.error || 'Erro desconhecido.');
      }
    } catch { addToast('error', 'Erro', 'Não foi possível conectar ao servidor uazapi.'); }
    finally { setNewInstanceConnecting(false); }
  };

  const handleSaveUnit = async () => {
    if (unitValidationErrors.cnpj || unitValidationErrors.email) {
      addToast('error', 'Erro', 'Corrija os erros de validação antes de salvar.');
      return;
    }
    if (!currentUnit!.cnpj) {
      addToast('warning', 'Validação', 'CNPJ é obrigatório.');
      return;
    }
    const isEditing = !!currentUnit!.id;
    setIsSavingUnit(true);
    try {
      const apiPayload = { ...currentUnit! };
      let saved: any;
      if (isEditing) {
        saved = await apiUpdateUnit(currentUnit!.id!, apiPayload);
      } else {
        delete apiPayload.id;
        saved = await apiCreateUnit(apiPayload);
        if (!saved?.id) {
          throw new Error('O servidor não retornou o ID da unidade criada.');
        }
      }
      const savedId = saved?.id || currentUnit!.id;
      const savedUnit = { ...currentUnit!, id: savedId };

      logTransaction('CONFIG', savedId, originalUnit, savedUnit);
      setLocalConfig(prev => ({
        ...prev,
        units: isEditing
          ? prev.units.map(u => u.id === savedId ? savedUnit : u)
          : [...prev.units, savedUnit],
      }));
      setIsEditingUnit(false);
      setCurrentUnit(null);
      resetUazapiState();
      addToast('success', 'Salvo', 'Unidade salva com sucesso.');
      if (onRefresh) onRefresh();
    } catch (err: any) {
      const msg = err?.response?.data?.error || err?.message || 'Não foi possível salvar a unidade.';
      addToast('error', 'Erro', msg);
    } finally {
      setIsSavingUnit(false);
    }
  };

  const handleDeleteUnit = async (id: string) => {
    if (!validarPermissao('EXCLUIR')) return;
    const depResult = checkDependencies('unit', id, localConfig);
    if (!depResult.canDelete) {
      const u = localConfig.units.find(u => u.id === id);
      const unitName = u?.nomeFantasia || u?.razaoSocial || id;
      addToast('warning', 'Exclusão Bloqueada', formatDependencyMessage(`a unidade "${unitName}"`, depResult.dependencies));
      return;
    }
    if (!window.confirm('Excluir esta unidade? Esta ação não pode ser desfeita.')) return;
    const unitToDelete = localConfig.units.find(u => u.id === id);
    try {
      await apiRemoveUnit(id);
    } catch (err: any) {
      const msg = err?.response?.data?.error || err?.message || 'Não foi possível excluir a unidade.';
      addToast('error', 'Erro', msg);
      return;
    }
    logTransaction('CONFIG', id, unitToDelete, null);
    addToast('success', 'Excluído', 'Unidade removida com sucesso.');
    if (onRefresh) onRefresh();
  };

  const handleSaveGroup = async () => {
      const isEditing = originalGroup !== null;
      const permRequired = isEditing ? 'ALTERAR' : 'INCLUIR';
      if (!validarPermissao(permRequired)) return;
      if (!currentGroup?.name) { addToast('warning', 'Validação', 'Nome do grupo obrigatório.'); return; }
      const duplicateName = localConfig.userGroups.some(g => g.id !== currentGroup.id && g.name.toLowerCase().trim() === currentGroup.name.toLowerCase().trim());
      if (duplicateName) { addToast('warning', 'Validação', 'Já existe um grupo com este nome.'); return; }

      let grpToSave = { ...currentGroup };
      const apiPayload = { name: grpToSave.name, permissions: grpToSave.permissions };

      try {
          if (isEditing) {
              const updated = await apiUpdateGroup(currentGroup.id, apiPayload);
              grpToSave = { ...grpToSave, ...updated };
          } else {
              const created = await apiCreateGroup(apiPayload);
              grpToSave = { ...grpToSave, ...created };
          }
      } catch {
          addToast('error', 'Erro', 'Falha ao salvar grupo. Tente novamente.');
          return;
      }

      logTransaction('CONFIG', grpToSave.id || '(novo)', originalGroup, grpToSave);

      setIsEditingGroup(false); setCurrentGroup(null); setOriginalGroup(null);
      addToast('success', 'Sucesso', 'Grupo salvo com sucesso.');
      if (onRefresh) onRefresh();
  };

  const handleDeleteGroup = async (id: string) => {
      if (!validarPermissao('EXCLUIR')) return;
      const result = checkDependencies('userGroup', id, localConfig);
      if (!result.canDelete) {
          const grpName = localConfig.userGroups.find(g => g.id === id)?.name || id;
          addToast('warning', 'Exclusão Bloqueada', formatDependencyMessage(`o grupo "${grpName}"`, result.dependencies));
          return;
      }
      if (window.confirm('Tem certeza que deseja excluir este grupo?')) {
          const grpToDelete = localConfig.userGroups.find(g => g.id === id);
          try {
              await apiRemoveGroup(id);
          } catch {
              addToast('error', 'Erro', 'Falha ao excluir grupo. Tente novamente.');
              return;
          }
          logTransaction('CONFIG', id, grpToDelete, null);
          addToast('success', 'Sucesso', 'Grupo excluído.');
          if (onRefresh) onRefresh();
      }
  };

  const handleSaveUser = async () => {
      const isEditing = originalUser !== null;
      const permRequired = isEditing ? 'ALTERAR' : 'INCLUIR';
      if (!validarPermissao(permRequired)) return;
      if (!currentUser?.name || !currentUser?.email) { addToast('warning', 'Validação', 'Nome e E-mail obrigatórios.'); return; }
      const groupIds = Array.isArray(currentUser.groupIds) ? currentUser.groupIds : [];
      if (groupIds.length === 0) { addToast('warning', 'Validação', 'Selecione ao menos um grupo.'); return; }

      let userToSave = {
          ...currentUser,
          groupIds,
          allowedUnitIds: Array.isArray(currentUser.allowedUnitIds) ? currentUser.allowedUnitIds : [],
      };
      if (userPassword) { userToSave.initialPassword = userPassword; userToSave.forceChangePassword = true; }
      userToSave.forceReset = userToSave.forceChangePassword || false;

      setIsSavingUser(true);
      try {
          const apiPayload: Record<string, any> = {
              name: userToSave.name,
              email: userToSave.email,
              role: userToSave.role,
              status: userToSave.status || 'ATIVO',
              groupIds: userToSave.groupIds,
              allowedUnitIds: userToSave.allowedUnitIds,
              force_change_password: userToSave.forceChangePassword || false,
              photo_url: userToSave.photoUrl || '',
              collaborator_id: userToSave.collaboratorId || null,
          };
          if (userPassword) apiPayload.initial_password = userPassword;

          let savedUser: any;
          if (isEditing) {
              savedUser = await apiUpdateUser(userToSave.id, apiPayload);
          } else {
              savedUser = await apiCreateUser(apiPayload);
          }
          const savedId = savedUser?.id || userToSave.id;
          const confirmedUser = { ...userToSave, ...(savedUser || {}), id: savedId };
          if (isEditing) {
              setLocalConfig(prev => ({
                  ...prev,
                  users: (prev.users || []).map(user => user.id === savedId ? confirmedUser : user),
              }));
          } else {
              setLocalConfig(prev => ({ ...prev, users: [...(prev.users || []), confirmedUser] }));
          }
          logTransaction('USUARIO', savedId, originalUser, confirmedUser);
          setIsEditingUser(false); setCurrentUser(null); setOriginalUser(null); setUserPassword('');
          addToast('success', 'Sucesso', 'Usuário salvo com sucesso.');
          if (onRefresh) onRefresh();
      } catch (err: any) {
          const msg = err?.response?.data?.error || err?.message || 'Erro ao salvar usuário.';
          addToast('error', 'Erro', msg);
      } finally {
          setIsSavingUser(false);
      }
  };

  const handleDeleteUser = async (id: string) => {
      if (!validarPermissao('EXCLUIR')) return;
      const result = checkDependencies('user', id, localConfig);
      if (!result.canDelete) {
          const userName = localConfig.users.find(u => u.id === id)?.name || id;
          addToast('warning', 'Exclusão Bloqueada', formatDependencyMessage(`o usuário "${userName}"`, result.dependencies));
          return;
      }
      if (!window.confirm('Excluir usuário?')) return;
      const userToDelete = localConfig.users.find(u => u.id === id);
      try {
          await apiRemoveUser(id);
      } catch (err: any) {
          const msg = err?.response?.data?.error || err?.message || 'Não foi possível excluir o usuário.';
          addToast('error', 'Erro', msg);
          return;
      }
      logTransaction('USUARIO', id, userToDelete, null);
      addToast('success', 'Sucesso', 'Usuário excluído.');
      if (onRefresh) onRefresh();
  };

  const toggleUserGroup = (groupId: string) => {
      if (!currentUser) return;
      const existing = currentUser.groupIds || [];
      const groups = existing.includes(groupId)
          ? existing.filter(id => id !== groupId)
          : [...existing, groupId];
      setCurrentUser({ ...currentUser, groupIds: groups });
  };

  const toggleUserUnit = (unitId: string) => {
      if (!currentUser) return;
      const existing = currentUser.allowedUnitIds || [];
      const units = existing.includes(unitId)
          ? existing.filter(id => id !== unitId)
          : [...existing, unitId];
      setCurrentUser({ ...currentUser, allowedUnitIds: units });
  };

  // --- GENERAL HANDLERS ---
  const handleCepSearch = async () => {
    const contextData = isEditingUnit ? currentUnit : localConfig.companyInfo;
    const cep = contextData?.cep?.replace(/\D/g, '');
    if (cep?.length === 8) {
        setIsLoadingCep(true);
        try {
            const r = await fetch(`/api/cep/${cep}`);
            const d = await r.json();
            if (!d.erro) {
                const n = { endereco: d.logradouro||'', bairro: d.bairro||'', cidade: d.localidade||'', estado: d.uf||'', complemento: contextData?.complemento||d.complemento||'' };
                if (isEditingUnit) setCurrentUnit(p => p?({...p, ...n}):null);
                else setLocalConfig(p => ({...p, companyInfo: {...p.companyInfo, ...n}}));
                setTimeout(() => { if (d.logradouro) numeroRef.current?.focus(); else enderecoRef.current?.focus(); }, 100);
            } else addToast('error', 'Erro', 'CEP não encontrado.');
        } catch { addToast('error', 'Erro', 'Erro conexão.'); } finally { setIsLoadingCep(false); }
    } else addToast('warning', 'Atenção', 'CEP inválido.');
  };
  
  const updateCurrentUnitField = (f: keyof CompanyInfo, v: string) => {
     if(!currentUnit)return;
     setCurrentUnit(prev => prev ? ({...prev, [f]: v}) : null);
  };

  // --- MASK & VALIDATION FUNCTIONS (UNITS) ---
  const formatCNPJ = (value: string) => {
      let r = value.replace(/\D/g, "");
      r = r.substring(0, 14);
      r = r.replace(/^(\d{2})(\d)/, "$1.$2");
      r = r.replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3");
      r = r.replace(/\.(\d{3})(\d)/, ".$1/$2");
      r = r.replace(/(\d{4})(\d)/, "$1-$2");
      return r;
    };

  const validateCNPJ = (cnpj: string): boolean => {
    cnpj = cnpj.replace(/[^\d]+/g, '');
    if (cnpj === '' || cnpj.length !== 14 || /^(\d)\1+$/.test(cnpj)) return false;
    
    let size = cnpj.length - 2;
    let numbers = cnpj.substring(0, size);
    const digits = cnpj.substring(size);
    let sum = 0;
    let pos = size - 7;
    
    for (let i = size; i >= 1; i--) {
      sum += parseInt(numbers.charAt(size - i)) * pos--;
      if (pos < 2) pos = 9;
    }
    
    let result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
    if (result !== parseInt(digits.charAt(0))) return false;
    
    size = size + 1;
    numbers = cnpj.substring(0, size);
    sum = 0;
    pos = size - 7;
    
    for (let i = size; i >= 1; i--) {
      sum += parseInt(numbers.charAt(size - i)) * pos--;
      if (pos < 2) pos = 9;
    }
    
    result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
    if (result !== parseInt(digits.charAt(1))) return false;
    
    return true;
  };

  const formatPhone = (value: string) => {
      let r = value.replace(/\D/g, "");
      r = r.substring(0, 11);
      if (r.length > 10) {
        r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
      } else if (r.length > 5) {
        r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, "($1) $2-$3");
      } else if (r.length > 2) {
        r = r.replace(/^(\d\d)(\d{0,5})/, "($1) $2");
      } else {
        r = r.replace(/^(\d*)/, "($1");
      }
      return r;
  };

  const formatCEP = (value: string) => {
      let r = value.replace(/\D/g, "");
      r = r.substring(0, 8);
      if (r.length > 5) {
          r = r.replace(/^(\d{5})(\d{1,3}).*/, "$1-$2");
      }
      return r;
  };

  const validateEmailFormat = (email: string): boolean => {
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return re.test(email);
  };

  // --- UNIT FIELD HANDLERS ---
  const handleUnitCnpjChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if(!currentUnit) return;
      const formatted = formatCNPJ(e.target.value);
      updateCurrentUnitField('cnpj', formatted);
      
      const clean = formatted.replace(/\D/g, '');
      if (clean.length === 14) {
          if (!validateCNPJ(clean)) {
              setUnitValidationErrors(p => ({...p, cnpj: 'CNPJ inválido.'}));
          } else {
              setUnitValidationErrors(p => ({...p, cnpj: undefined}));
          }
      } else {
          setUnitValidationErrors(p => ({...p, cnpj: undefined}));
      }
  };

  const handleUnitEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if(!currentUnit) return;
      const val = e.target.value.trim();
      updateCurrentUnitField('email', val);
      
      if (val && !validateEmailFormat(val)) {
          setUnitValidationErrors(p => ({...p, email: 'E-mail inválido.'}));
      } else {
          setUnitValidationErrors(p => ({...p, email: undefined}));
      }
  };

  // --- FIX: USER PHOTO & CAMERA HANDLERS ---
  const handleCameraCapture = (base64: string) => {
    if (isEditingUser) {
        setCurrentUser(prev => prev ? ({ ...prev, photoUrl: base64 }) : null);
        addToast('success', 'Captura', 'Foto atualizada.');
    }
    setShowCamera(false);
  };
  
  const handleUserPhotoFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => { 
            const base64String = reader.result as string;
            setCurrentUser(prev => prev ? ({ ...prev, photoUrl: base64String }) : null);
            addToast('success', 'Upload', 'Foto carregada.');
        };
        reader.readAsDataURL(file);
    }
    if (e.target) e.target.value = '';
  };

  const handleRemovePhoto = () => {
      if (isEditingUser && window.confirm('Remover a foto do usuário?')) {
          setCurrentUser(prev => prev ? ({ ...prev, photoUrl: '' }) : null);
      }
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => {
          const newLogoUrl = reader.result as string;
          setLocalConfig(prev => ({ ...prev, logoUrl: newLogoUrl }));
          updateThemeSettings({ logoUrl: newLogoUrl });
        };
        reader.readAsDataURL(file);
        e.target.value = '';
    }
  };

  // Handler for Background Image Upload (Left Side)
  const handleBgImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => { updateTheme('loginLeftBgImage', reader.result as string); };
        reader.readAsDataURL(file);
        e.target.value = '';
    }
  };
  
  // --- RESET HANDLERS ---
  const handleResetIdentity = () => {
      setLocalConfig(prev => ({
          ...prev,
          companyName: DEFAULT_PORTAL_CONFIG.companyName,
          logoUrl: DEFAULT_PORTAL_CONFIG.logoUrl,
          theme: {
              ...prev.theme,
              loginLeftBgColor: DEFAULT_PORTAL_CONFIG.theme.loginLeftBgColor,
              loginLeftTextColor: DEFAULT_PORTAL_CONFIG.theme.loginLeftTextColor,
              sidebarBgColor: DEFAULT_PORTAL_CONFIG.theme.sidebarBgColor,
              sidebarTextColor: DEFAULT_PORTAL_CONFIG.theme.sidebarTextColor,
              headerBgColor: DEFAULT_PORTAL_CONFIG.theme.headerBgColor,
              headerTextColor: DEFAULT_PORTAL_CONFIG.theme.headerTextColor
          }
      }));
      addToast('info', 'Padrão', 'Identidade visual restaurada.');
  };

  const handleResetMarketing = () => {
      setLocalConfig(prev => ({
          ...prev,
          marketingTitle: DEFAULT_PORTAL_CONFIG.marketingTitle,
          marketingText: DEFAULT_PORTAL_CONFIG.marketingText
      }));
      addToast('info', 'Padrão', 'Texto de marketing restaurado.');
  };

  const handleResetStyle = () => {
      setLocalConfig(prev => ({
          ...prev,
          theme: {
              ...prev.theme,
              loginLeftBgColor: DEFAULT_PORTAL_CONFIG.theme.loginLeftBgColor,
              loginLeftTextColor: DEFAULT_PORTAL_CONFIG.theme.loginLeftTextColor,
              loginLeftBgImage: DEFAULT_PORTAL_CONFIG.theme.loginLeftBgImage,
              loginRightBgColor: DEFAULT_PORTAL_CONFIG.theme.loginRightBgColor,
              loginRightTextColor: DEFAULT_PORTAL_CONFIG.theme.loginRightTextColor
          }
      }));
      addToast('info', 'Padrão', 'Estilos restaurados.');
  };
  
  const handleSaveGlobal = () => { 
      if(validarPermissao('ALTERAR')) { 
          // AUDIT GLOBAL
          logTransaction('CONFIG', 'GLOBAL', config, localConfig); // Audit differences between prop and local state
          
          updateThemeSettings({ companyName: localConfig.companyName, logoUrl: localConfig.logoUrl, marketingTitle: localConfig.marketingTitle, marketingText: localConfig.marketingText, theme: localConfig.theme }); 
          addToast('success', 'Salvo', 'Configurações salvas.'); 
      }
  };
  const handleCancelGlobal = () => { if(window.confirm('Descartar alterações?')) setLocalConfig(config); };

  const handleSendTestEmail = async () => {
    if (!testEmailTarget) { addToast('warning', 'Validação', 'Informe o e-mail de destino.'); return; }
    setIsTestingEmail(true);
    try {
      await new Promise((resolve) => setTimeout(resolve, 2000));
      addToast('success', 'Sucesso', `E-mail de teste enviado para ${testEmailTarget}.`);
      setShowTestEmailModal(false);
      setTestEmailTarget('');
    } catch (err) { addToast('error', 'Erro', 'Falha ao enviar e-mail.'); } finally { setIsTestingEmail(false); }
  };

  // --- RENDER HELPERS ---
  const renderPermissionOptions = (items: MenuItem[], level = 0) => {
    return items.map(item => {
        if(item.hidden && item.id !== 'settings' && !item.id.startsWith('settings_')) return null;
        return (
            <div key={item.id} className="border-b border-gray-100 last:border-0">
                <div className={`flex items-center justify-between py-3 hover:bg-gray-50 transition-colors ${level > 0 ? 'pl-' + (level * 6) : ''}`}>
                    <div className={`flex items-center min-w-[250px] ${level > 0 ? 'ml-6' : ''}`}>
                        <label className="flex items-center space-x-3 cursor-pointer select-none">
                            <input type="checkbox" className="h-5 w-5 text-moss-600 focus:ring-moss-500 border-gray-300 rounded" checked={currentGroup?.permissions.includes(item.id) || false} onChange={() => toggleGroupPermission(item.id)} />
                            <span className={`text-sm text-gray-800 ${level === 0 ? 'font-bold' : ''}`}>{item.label}</span>
                        </label>
                    </div>
                    <div className="flex gap-2 flex-wrap justify-end">
                        {PERMISSION_ACTIONS.map(action => {
                            const permId = `${item.id}:${action.id}`;
                            const isChecked = currentGroup?.permissions.includes(permId);
                            const isMenuSelected = currentGroup?.permissions.includes(item.id);
                            return (
                                <label key={action.id} className={`flex flex-col items-center justify-center w-10 h-10 rounded border transition-all cursor-pointer ${isChecked ? 'bg-gray-100 border-moss-300 shadow-inner' : 'border-transparent hover:bg-gray-50'} ${!isMenuSelected ? 'opacity-40 grayscale cursor-not-allowed' : ''}`} title={action.label}>
                                    <input type="checkbox" className="hidden" checked={isChecked || false} onChange={() => isMenuSelected && toggleGroupPermission(permId)} disabled={!isMenuSelected} />
                                    <span className={`text-xs font-bold ${action.color}`}>{action.short}</span>
                                </label>
                            );
                        })}
                    </div>
                </div>
                {item.subItems && (<div className="bg-gray-50/50">{renderPermissionOptions(item.subItems, level + 1)}</div>)}
            </div>
        );
    });
  };

  const handleEditTopic = (topic: HelpTopic) => {
      setEditingTopicId(topic.id);
      setEditingTopic({ ...topic });
      setIsCreatingTopic(false);
  };

  const handleNewTopic = () => {
      if (!validarPermissao('settings_help:INCLUIR')) return;
      const newTopic: HelpTopic = {
          id: 'help_' + Date.now(),
          menuPath: '',
          title: '',
          summary: '',
          content: '',
          keywords: []
      };
      setEditingTopic(newTopic);
      setEditingTopicId(null);
      setIsCreatingTopic(true);
  };

  const handleSaveTopic = async () => {
      if (!editingTopic) return;
      if (!editingTopic.title || !editingTopic.menuPath) {
          addToast('warning', 'Atenção', 'Preencha o título e o caminho do menu.');
          return;
      }
      const updatedTopics: HelpTopic[] = isCreatingTopic
          ? [...helpTopics, editingTopic]
          : helpTopics.map(t => t.id === editingTopicId ? editingTopic : t);
      try {
          await saveSectionOrThrow('helpTopics', updatedTopics);
          setHelpTopics(updatedTopics);
          setEditingTopic(null);
          setEditingTopicId(null);
          setIsCreatingTopic(false);
          addToast('success', 'Sucesso', isCreatingTopic ? 'Tópico de ajuda criado com sucesso.' : 'Tópico de ajuda atualizado com sucesso.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível salvar o tópico.');
      }
  };

  const handleDeleteTopic = async (topicId: string) => {
      if (!validarPermissao('settings_help:EXCLUIR')) return;
      const updatedTopics = helpTopics.filter(t => t.id !== topicId);
      try {
          await saveSectionOrThrow('helpTopics', updatedTopics);
          setHelpTopics(updatedTopics);
          addToast('success', 'Sucesso', 'Tópico removido.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível excluir o tópico.');
      }
  };

  const handleResetHelpTopics = async () => {
      try {
          await saveSectionOrThrow('helpTopics', DEFAULT_HELP_TOPICS);
          setHelpTopics(DEFAULT_HELP_TOPICS);
          addToast('info', 'Restaurado', 'Conteúdo de ajuda restaurado para o padrão do sistema.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível restaurar os tópicos.');
      }
  };

  const filteredHelpTopics = helpSearchTerm
      ? helpTopics.filter(t => 
          t.title.toLowerCase().includes(helpSearchTerm.toLowerCase()) ||
          t.menuPath.toLowerCase().includes(helpSearchTerm.toLowerCase()) ||
          t.summary.toLowerCase().includes(helpSearchTerm.toLowerCase())
        )
      : helpTopics;

  const auditItems = localConfig.auditCheckItems || [];
  const displayedAuditItems = showInactiveAuditItems ? auditItems : auditItems.filter(i => i.status === 'ATIVO');
  const sortedAuditItems = [...displayedAuditItems].sort((a, b) => a.order - b.order);

  const handleNewAuditItem = () => {
      if (!validarPermissao('INCLUIR')) return;
      const maxOrder = auditItems.length > 0 ? Math.max(...auditItems.map(i => i.order)) : 0;
      setCurrentAuditItem({
          id: '', order: maxOrder + 1, label: '', description: '', status: 'ATIVO'
      });
      setOriginalAuditItem(null);
      setIsEditingAuditItem(true);
  };

  const handleEditAuditItem = (item: AuditCheckItem) => {
      if (!validarPermissao('ALTERAR')) return;
      setCurrentAuditItem({ ...item });
      setOriginalAuditItem({ ...item });
      setIsEditingAuditItem(true);
  };

  const handleSaveAuditItem = async () => {
      if (!currentAuditItem?.label) {
          addToast('warning', 'Validação', 'O Título é obrigatório.');
          return;
      }
      let updated: AuditCheckItem[];
      let savedId = currentAuditItem.id;
      if (currentAuditItem.id) {
          updated = auditItems.map(i => i.id === currentAuditItem.id ? currentAuditItem : i);
      } else {
          const newItem = { ...currentAuditItem, id: `aci_${Date.now()}` };
          savedId = newItem.id;
          updated = [...auditItems, newItem];
      }
      try {
          await saveSectionOrThrow('auditCheckItems', updated);
          setLocalConfig({ ...localConfig, auditCheckItems: updated });
          logTransaction('AUDIT_CHECK_ITEM', savedId || 'new', originalAuditItem, currentAuditItem);
          setIsEditingAuditItem(false);
          setCurrentAuditItem(null);
          setOriginalAuditItem(null);
          addToast('success', 'Sucesso', 'Item de auditoria salvo.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível salvar o item.');
      }
  };

  const handleToggleAuditItemStatus = async (id: string) => {
      if (!validarPermissao('INATIVAR')) return;
      const item = auditItems.find(i => i.id === id);
      if (!item) return;
      const newStatus = item.status === 'ATIVO' ? 'INATIVO' : 'ATIVO';
      if (newStatus === 'INATIVO' && !window.confirm(`Inativar o item "${item.label}"?`)) return;
      const updated = auditItems.map(i => i.id === id ? { ...i, status: newStatus as 'ATIVO' | 'INATIVO' } : i);
      try {
          await saveSectionOrThrow('auditCheckItems', updated);
          setLocalConfig({ ...localConfig, auditCheckItems: updated });
          logTransaction('AUDIT_CHECK_ITEM', id, item, { ...item, status: newStatus });
          addToast('success', 'Sucesso', `Item ${newStatus === 'ATIVO' ? 'ativado' : 'inativado'}.`);
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível alterar o status.');
      }
  };

  const handleMoveAuditItem = async (id: string, direction: 'up' | 'down') => {
      const sorted = [...auditItems].sort((a, b) => a.order - b.order);
      const idx = sorted.findIndex(i => i.id === id);
      if (idx < 0) return;
      if (direction === 'up' && idx === 0) return;
      if (direction === 'down' && idx === sorted.length - 1) return;
      const swapIdx = direction === 'up' ? idx - 1 : idx + 1;
      const tempOrder = sorted[idx].order;
      sorted[idx] = { ...sorted[idx], order: sorted[swapIdx].order };
      sorted[swapIdx] = { ...sorted[swapIdx], order: tempOrder };
      try {
          await saveSectionOrThrow('auditCheckItems', sorted);
          setLocalConfig({ ...localConfig, auditCheckItems: sorted });
          addToast('info', 'Reordenado', 'Ordem dos itens atualizada.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível reordenar.');
      }
  };

  const handleAuditMigrateAction = () => {
      if (!auditMigrateModal) return;
      if (auditMigrateModal.type !== 'duplicate' && !auditMigrateTargetId) {
          addToast('warning', 'Validação', 'Selecione um item de destino.');
          return;
      }
      const source = auditItems.find(i => i.id === auditMigrateModal.sourceId);
      const target = auditMigrateModal.type === 'duplicate' ? source : auditItems.find(i => i.id === auditMigrateTargetId);
      if (!source || !target) return;

      let updated = [...auditItems];

      if (auditMigrateModal.type === 'swap') {
          updated = updated.map(i => {
              if (i.id === source.id) return { ...i, order: target.order };
              if (i.id === target.id) return { ...i, order: source.order };
              return i;
          });
          addToast('success', 'Migrado', `Posições de "${source.label}" e "${target.label}" trocadas.`);
      } else if (auditMigrateModal.type === 'overwrite') {
          updated = updated.map(i => {
              if (i.id === target.id) return { ...i, label: source.label, description: source.description, conditionField: source.conditionField };
              return i;
          });
          addToast('success', 'Sobrescrito', `Dados de "${source.label}" copiados para a posição de "${target.label}".`);
      } else if (auditMigrateModal.type === 'duplicate') {
          const maxOrder = Math.max(...auditItems.map(i => i.order));
          const newItem: AuditCheckItem = {
              id: `aci_${Date.now()}`,
              order: maxOrder + 1,
              label: `${source.label} (Cópia)`,
              description: source.description,
              status: 'ATIVO',
              conditionField: source.conditionField,
          };
          updated = [...updated, newItem];
          addToast('success', 'Duplicado', `Item "${source.label}" duplicado com sucesso.`);
      }

      const newConfig = { ...localConfig, auditCheckItems: updated };
      setLocalConfig(newConfig);
      updateSection('auditCheckItems', updated);
      logTransaction('AUDIT_CHECK_ITEM', auditMigrateModal.sourceId, null, { action: auditMigrateModal.type, targetId: auditMigrateTargetId });
      setAuditMigrateModal(null);
      setAuditMigrateTargetId('');
  };

  return (
     <div className="bg-white rounded-lg shadow-sm border border-gray-200 min-h-[min(600px,calc(100vh-2rem))] flex flex-col min-w-0 overflow-hidden">
       <div className="flex border-b border-gray-200 overflow-x-auto overscroll-x-contain scrollbar-thin">
        {TABS_CONFIG.map(tab => {
            if (!temPermissao(tab.permission)) return null;
            return (
                <button key={tab.id} onClick={() => handleTabChange(tab.id)} className={`px-3 sm:px-6 py-3 sm:py-4 font-medium text-xs sm:text-sm focus:outline-none transition-colors whitespace-nowrap ${activeTab === tab.id ? 'border-b-2 border-moss-600 text-moss-700 bg-gray-50' : 'text-gray-500 hover:text-gray-700'}`}>
                    {tab.label}
                </button>
            );
        })}
        {isLoggedAdmin && (
          <button onClick={() => handleTabChange('QUEUE_HEALTH')} className={`px-3 sm:px-6 py-3 sm:py-4 font-medium text-xs sm:text-sm focus:outline-none transition-colors whitespace-nowrap ${activeTab === 'QUEUE_HEALTH' ? 'border-b-2 border-moss-600 text-moss-700 bg-gray-50' : 'text-gray-500 hover:text-gray-700'}`}>
            Fila de importação
          </button>
        )}
        {isLoggedAdmin && (
          <button onClick={() => handleTabChange('LEO_KNOWLEDGE')} className={`px-6 py-4 font-medium text-sm focus:outline-none transition-colors whitespace-nowrap flex items-center gap-1.5 ${activeTab === 'LEO_KNOWLEDGE' ? 'border-b-2 border-moss-600 text-moss-700 bg-gray-50' : 'text-gray-500 hover:text-gray-700'}`}>
            🧠 Base de Conhecimento IA
          </button>
        )}
        {isLoggedAdmin && (
          <button onClick={() => handleTabChange('SQL')} className={`px-6 py-4 font-medium text-sm focus:outline-none transition-colors whitespace-nowrap flex items-center gap-1.5 ${activeTab === 'SQL' ? 'border-b-2 border-orange-500 text-orange-700 bg-gray-50' : 'text-gray-500 hover:text-gray-700'}`}>
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 9l3 3-3 3m5 0h3M5 20h14a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
            Console SQL
          </button>
        )}
      </div>

      <div className="p-3 sm:p-6 flex-1 min-h-0 overflow-y-auto">
        {/* ... (OTHER TABS HIDDEN FOR BREVITY - KEEPING THEM) ... */}
        {activeTab === 'PORTAL' && temPermissao('settings_portal') && (
          <div className="flex flex-col h-full animate-fade-in" data-form-container="true">
              <div className="flex space-x-2 mb-6 border-b overflow-x-auto overscroll-x-contain">
                <button onClick={() => setPortalSubTab('LOGIN')} className={`px-4 py-2 border-b-2 font-medium text-sm ${portalSubTab === 'LOGIN' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Login & Identidade</button>
                <button onClick={() => setPortalSubTab('PRINCIPAL')} className={`px-4 py-2 border-b-2 font-medium text-sm ${portalSubTab === 'PRINCIPAL' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Layout Interno (Dashboard)</button>
             </div>
             {portalSubTab === 'LOGIN' && (
                 <div className="space-y-8 animate-fade-in">
                     {/* ... (LOGIN CONTENT) ... */}
                     <div className="bg-gray-50 p-5 rounded-lg border border-gray-200 relative group">
                         <div className="flex justify-between items-start mb-4">
                            <h3 className="font-bold text-gray-800 flex items-center gap-2"><span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-xs">1</span> Identidade Visual</h3>
                            <Button variant="ghost" className="!w-auto !py-1 !text-xs text-gray-400 hover:text-gray-600" onClick={handleResetIdentity}>Restaurar Padrão</Button>
                         </div>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div className="space-y-4">
                                <Input label="Nome da Empresa (Título)" value={localConfig.companyName} onChange={(e) => updateConfig('companyName', e.target.value)} onKeyDown={handleEnterPress} />
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                    <ColorPickerItem label="Cor Principal (Fundo)" value={localConfig.theme.sidebarBgColor} onChange={(v) => updateBrandColors('bg', v)} />
                                    <ColorPickerItem label="Cor do Texto" value={localConfig.theme.sidebarTextColor} onChange={(v) => updateBrandColors('text', v)} />
                                </div>
                                <p className="text-xs text-gray-500 mt-1">* As cores selecionadas serão aplicadas ao Menu Lateral, Cabeçalho e Tela de Login.</p>
                            </div>
                            <div className="flex flex-col gap-2">
                                <span className="block text-sm font-medium text-gray-700 mb-1">Logotipo da Empresa</span>
                                <input type="file" ref={logoInputRef} className="hidden" accept="image/*" onChange={handleLogoUpload} />
                                <div className="flex items-center gap-4 border border-gray-300 rounded-lg p-3 bg-white h-full">
                                    <div className="h-16 w-16 flex-shrink-0 bg-gray-100 rounded border flex items-center justify-center overflow-hidden">{localConfig.logoUrl ? (<img src={localConfig.logoUrl} alt="Logo" className="w-full h-full object-contain" />) : (<span className="text-xs text-gray-400">Sem Logo</span>)}</div>
                                    <div className="flex flex-col gap-2 flex-1">
                                        <div className="flex gap-2">
                                            <Button variant="secondary" className="!py-1 !text-xs !w-auto" onClick={() => logoInputRef.current?.click()}>{localConfig.logoUrl ? 'Trocar Imagem' : 'Carregar Imagem'}</Button>
                                            {localConfig.logoUrl && (<Button variant="ghost" className="!py-1 !text-xs !w-auto text-red-600 hover:bg-red-50" onClick={() => { setLocalConfig(prev => ({ ...prev, logoUrl: '' })); updateThemeSettings({ logoUrl: '' }); }}>Remover</Button>)}
                                        </div>
                                        <p className="text-xs text-gray-500">Recomendado: PNG com fundo transparente.</p>
                                    </div>
                                </div>
                            </div>
                         </div>
                     </div>
                     {/* ... (OTHER PORTAL SECTIONS) ... */}
                     <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
                         <div className="flex justify-between items-start mb-4">
                            <h3 className="font-bold text-gray-800 flex items-center gap-2"><span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-xs">2</span> Conteúdo de Marketing</h3>
                            <Button variant="ghost" className="!w-auto !py-1 !text-xs text-gray-400 hover:text-gray-600" onClick={handleResetMarketing}>Restaurar Padrão</Button>
                         </div>
                         <div className="space-y-4">
                             <Input label="Título de Destaque" value={localConfig.marketingTitle} onChange={(e) => updateConfig('marketingTitle', e.target.value)} onKeyDown={handleEnterPress} />
                             <div><label className="block text-sm font-medium text-gray-700 mb-1">Texto Promocional</label><textarea className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-moss-500 outline-none" rows={3} value={localConfig.marketingText} onChange={(e) => updateConfig('marketingText', e.target.value)} onKeyDown={handleEnterPress as any} /></div>
                         </div>
                     </div>
                     <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
                         <div className="flex justify-between items-start mb-4">
                            <h3 className="font-bold text-gray-800 flex items-center gap-2"><span className="bg-blue-100 text-blue-800 px-2 py-0.5 rounded text-xs">3</span> Personalização de Estilo</h3>
                            <Button variant="ghost" className="!w-auto !py-1 !text-xs text-gray-400 hover:text-gray-600" onClick={handleResetStyle}>Restaurar Padrão</Button>
                         </div>
                         <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                             <div className="border-r pr-0 lg:pr-8 border-gray-200">
                                 <h4 className="font-bold text-sm text-gray-600 mb-4 uppercase tracking-wider">Lado Esquerdo (Login)</h4>
                                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-4">
                                     <ColorPickerItem label="Fundo" value={localConfig.theme.loginLeftBgColor} onChange={(v) => updateTheme('loginLeftBgColor', v)} />
                                     <ColorPickerItem label="Texto" value={localConfig.theme.loginLeftTextColor} onChange={(v) => updateTheme('loginLeftTextColor', v)} />
                                 </div>
                                 <div className="flex flex-col gap-2">
                                     <span className="block text-sm font-medium text-gray-700 mb-1">Imagem de Fundo</span>
                                     <input type="file" ref={bgImageInputRef} className="hidden" accept="image/*" onChange={handleBgImageUpload} />
                                     <div className="flex gap-2 items-center">
                                         <Input label="" value={localConfig.theme.loginLeftBgImage || ''} onChange={(e) => updateTheme('loginLeftBgImage', e.target.value)} placeholder="https://..." containerClassName="!mb-0 flex-1" onKeyDown={handleEnterPress} />
                                         <Button variant="secondary" className="!w-auto !h-[50px] !mb-0" onClick={() => bgImageInputRef.current?.click()} title="Upload">⬆️</Button>
                                     </div>
                                     {localConfig.theme.loginLeftBgImage && (
                                         <div className="relative mt-2">
                                            <div className="h-24 w-full rounded bg-gray-200 bg-cover bg-center border border-gray-300" style={{ backgroundImage: `url(${localConfig.theme.loginLeftBgImage})` }}></div>
                                            <button onClick={() => updateTheme('loginLeftBgImage', '')} className="absolute top-1 right-1 bg-red-600 text-white rounded-full p-1 shadow-sm hover:bg-red-700">
                                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                                            </button>
                                         </div>
                                     )}
                                 </div>
                             </div>
                             <div>
                                 <h4 className="font-bold text-sm text-gray-600 mb-4 uppercase tracking-wider">Lado Direito (Formulário)</h4>
                                 <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                     <ColorPickerItem label="Fundo" value={localConfig.theme.loginRightBgColor} onChange={(v) => updateTheme('loginRightBgColor', v)} />
                                     <ColorPickerItem label="Texto" value={localConfig.theme.loginRightTextColor} onChange={(v) => updateTheme('loginRightTextColor', v)} />
                                 </div>
                             </div>
                         </div>
                     </div>
                     <FormActions onSave={handleSaveGlobal} onCancel={handleCancelGlobal} onClose={onClose} />
                 </div>
             )}
             {portalSubTab === 'PRINCIPAL' && (
                 <div className="space-y-8 animate-fade-in">
                     <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
                            <h3 className="font-bold text-gray-800 mb-4">Menu Lateral</h3>
                            <div className="space-y-4">
                                <ColorPickerItem label="Cor de Fundo" value={localConfig.theme.sidebarBgColor} onChange={(v) => updateTheme('sidebarBgColor', v)} />
                                <ColorPickerItem label="Cor do Texto" value={localConfig.theme.sidebarTextColor || '#ffffff'} onChange={(v) => updateTheme('sidebarTextColor', v)} />
                            </div>
                        </div>
                        <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
                            <h3 className="font-bold text-gray-800 mb-4">Cabeçalho</h3>
                            <div className="space-y-4">
                                <ColorPickerItem label="Cor de Fundo" value={localConfig.theme.headerBgColor} onChange={(v) => updateTheme('headerBgColor', v)} />
                                <ColorPickerItem label="Cor do Texto" value={localConfig.theme.headerTextColor || '#ffffff'} onChange={(v) => updateTheme('headerTextColor', v)} />
                            </div>
                        </div>
                        <div className="bg-gray-50 p-5 rounded-lg border border-gray-200">
                            <h3 className="font-bold text-gray-800 mb-4">Área de Conteúdo</h3>
                            <div className="space-y-4">
                                <ColorPickerItem label="Cor de Fundo" value={localConfig.theme.mainContentBgColor} onChange={(v) => updateTheme('mainContentBgColor', v)} />
                                <Input label="Imagem de Fundo (URL Opcional)" value={localConfig.theme.mainContentBgImage || ''} onChange={(e) => updateTheme('mainContentBgImage', e.target.value)} containerClassName="!mb-0" onKeyDown={handleEnterPress} />
                            </div>
                        </div>
                     </div>
                     <FormActions onSave={handleSaveGlobal} onCancel={handleCancelGlobal} onClose={onClose} />
                 </div>
             )}
          </div>
        )}

        {/* === UNIDADES TAB === */}
        {activeTab === 'UNIDADES' && temPermissao('settings_units') && (
          <div className="animate-fade-in flex flex-col h-full">
            {/* ... (UNITS CONTENT) ... */}
            {!isEditingUnit ? (
                <div className="space-y-4">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-lg font-bold text-gray-800">Unidades</h3>
                        <Button variant="new" className="!w-auto" onClick={() => { 
                            setCurrentUnit({id: '', razaoSocial: '', nomeFantasia: '', cnpj: '', telefone: '', email: '', cep: '', endereco: '', numero: '', complemento: '', bairro: '', cidade: '', estado: '', taxaMinima: '', whatsappNumber: ''}); 
                            setOriginalUnit(null); 
                            setUnitValidationErrors({});
                            resetUazapiState();
                            setIsEditingUnit(true); 
                        }}>Nova Unidade</Button>
                    </div>
                    {(localConfig.units || []).map(u => {
                        const enderecoPartes = [
                            u.endereco && u.numero ? `${u.endereco}, ${u.numero}` : u.endereco,
                            u.complemento,
                            u.bairro,
                            u.cidade && u.estado ? `${u.cidade} – ${u.estado}` : (u.cidade || u.estado),
                            u.cep,
                        ].filter(Boolean).join(' • ');
                        return (
                            <div key={u.id} className="border p-4 rounded-lg mb-2 flex justify-between items-start bg-white hover:bg-gray-50 transition-colors">
                                <div className="flex-1 min-w-0 pr-4 space-y-1">
                                    <p className="font-bold text-gray-900">{u.razaoSocial}</p>
                                    {u.nomeFantasia && <p className="text-sm font-medium text-moss-700">{u.nomeFantasia}</p>}
                                    {u.cnpj && <p className="text-xs text-gray-400">CNPJ: {u.cnpj}</p>}
                                    {(u.telefone || u.email || u.whatsappNumber) && (
                                        <div className="flex flex-wrap gap-3 text-xs text-gray-600">
                                            {u.telefone && <span className="flex items-center gap-1"><span>📞</span>{u.telefone}</span>}
                                            {u.email && <span className="flex items-center gap-1"><span>📧</span>{u.email}</span>}
                                            {u.whatsappNumber && <span className="flex items-center gap-1"><span>💬</span>{u.whatsappNumber}</span>}
                                        </div>
                                    )}
                                    {enderecoPartes && (
                                        <p className="text-xs text-gray-500 flex items-start gap-1">
                                            <span className="flex-shrink-0">📍</span>
                                            <span>{enderecoPartes}</span>
                                        </p>
                                    )}
                                </div>
                                <div className="flex items-center gap-2 flex-shrink-0">
                                    <AuditLogButton entityId={u.id!} entityName={u.nomeFantasia || u.razaoSocial} logs={localConfig.auditLogs || []} />
                                    {u.id && (
                                        <button
                                            title="Conectar WhatsApp via QR Code"
                                            className="flex items-center gap-1 px-2 py-1 rounded-lg bg-green-50 border border-green-200 text-green-700 text-xs font-medium hover:bg-green-100 transition-colors"
                                            onClick={() => handleQuickQrConnect(u)}
                                        >
                                            📱 WhatsApp
                                        </button>
                                    )}
                                    <Button variant="ghost" className="!w-auto" onClick={() => { 
                                        setCurrentUnit({...u}); 
                                        setOriginalUnit({...u});
                                        setUnitValidationErrors({});
                                        resetUazapiState();
                                        setIsEditingUnit(true);
                                        if (u.id) loadUazapiInstances(u.id);
                                    }}>Editar</Button>
                                    <Button variant="ghost" className="!w-auto !text-amber-600 hover:!text-amber-800" onClick={() => {
                                        setCurrentUnit({ ...u, id: '', cnpj: '', razaoSocial: 'Cópia de ' + u.razaoSocial, nomeFantasia: u.nomeFantasia ? 'Cópia de ' + u.nomeFantasia : '', taxaMinima: u.taxaMinima || '', emailConfig: u.emailConfig ? { ...u.emailConfig } : undefined, googleIntegration: u.googleIntegration ? { ...u.googleIntegration } : undefined });
                                        setOriginalUnit(null);
                                        setUnitValidationErrors({});
                                        resetUazapiState();
                                        setIsEditingUnit(true);
                                    }}>Duplicar</Button>
                                    <Button variant="ghost" className="!w-auto !text-red-600 hover:!text-red-800" onClick={() => handleDeleteUnit(u.id!)}>Excluir</Button>
                                </div>
                            </div>
                        );
                    })}
                </div>
            ) : (
                <div className="animate-fade-in" data-form-container="true">
                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <Input label="Razão Social" value={currentUnit!.razaoSocial} onChange={(e) => updateCurrentUnitField('razaoSocial', e.target.value)} onKeyDown={handleEnterPress} />
                        <Input label="Nome Fantasia" value={currentUnit!.nomeFantasia || ''} onChange={(e) => updateCurrentUnitField('nomeFantasia', e.target.value)} onKeyDown={handleEnterPress} />
                        <Input 
                            label="CNPJ" 
                            value={currentUnit!.cnpj} 
                            onChange={handleUnitCnpjChange} 
                            onKeyDown={handleEnterPress} 
                            maxLength={18}
                            placeholder="00.000.000/0000-00"
                            error={unitValidationErrors.cnpj}
                        />
                        <div className="col-span-2 flex gap-2 items-end">
                            <Input 
                                label="CEP" 
                                containerClassName="w-40 !mb-0" 
                                value={currentUnit!.cep} 
                                onChange={(e) => updateCurrentUnitField('cep', formatCEP(e.target.value))} 
                                onKeyDown={handleEnterPress} 
                                maxLength={9}
                                placeholder="00000-000"
                            />
                            <Button className="!w-12 !h-[50px]" onClick={handleCepSearch} isLoading={isLoadingCep}>🔎</Button>
                            <Input label="Endereço" containerClassName="flex-1 !mb-0" value={currentUnit!.endereco} onChange={(e) => updateCurrentUnitField('endereco', e.target.value)} onKeyDown={handleEnterPress} />
                        </div>
                        <div className="col-span-2 flex gap-4">
                            <Input 
                                label="Número" 
                                value={currentUnit!.numero} 
                                ref={numeroRef} 
                                onChange={(e) => updateCurrentUnitField('numero', e.target.value)} 
                                onKeyDown={handleEnterPress}
                                containerClassName="w-32"
                            />
                            <Input 
                                label="Complemento" 
                                value={currentUnit!.complemento} 
                                onChange={(e) => updateCurrentUnitField('complemento', e.target.value)} 
                                onKeyDown={handleEnterPress}
                                containerClassName="flex-1"
                            />
                            <Input 
                                label="Bairro" 
                                value={currentUnit!.bairro} 
                                onChange={(e) => updateCurrentUnitField('bairro', e.target.value)} 
                                onKeyDown={handleEnterPress}
                                containerClassName="flex-1"
                            />
                        </div>
                        <Input label="Cidade" value={currentUnit!.cidade} onChange={(e) => updateCurrentUnitField('cidade', e.target.value)} onKeyDown={handleEnterPress} />
                        <Input label="Estado" value={currentUnit!.estado} onChange={(e) => updateCurrentUnitField('estado', e.target.value)} onKeyDown={handleEnterPress} />
                        <Input 
                            label="E-mail" 
                            value={currentUnit!.email || ''} 
                            onChange={handleUnitEmailChange} 
                            onKeyDown={handleEnterPress} 
                            error={unitValidationErrors.email}
                        />
                        <Input 
                            label="Telefone" 
                            value={currentUnit!.telefone} 
                            onChange={(e) => updateCurrentUnitField('telefone', formatPhone(e.target.value))} 
                            onKeyDown={handleEnterPress} 
                            maxLength={15}
                            placeholder="(00) 00000-0000"
                        />
                        <Input 
                            label="Taxa Mínima" 
                            mask="currency"
                            value={currentUnit!.taxaMinima || ''} 
                            onChange={(e) => updateCurrentUnitField('taxaMinima', e.target.value)} 
                            onKeyDown={handleEnterPress} 
                            placeholder="0,00"
                        />
                    </div>
                    {/* ── Seção WhatsApp / uazapi — card grid multi-instância ── */}
                    <div className="border-t pt-4 mt-2">
                        <div className="flex items-center justify-between mb-3">
                            <p className="text-sm font-semibold text-gray-700">💬 WhatsApp / uazapi</p>
                            {currentUnit!.id && uazapiLoading && (
                                <span className="text-xs text-gray-400 animate-pulse">Carregando instâncias…</span>
                            )}
                        </div>

                        {/* Número WhatsApp da unidade (campo da unidade) */}
                        <div className="mb-4">
                            <Input
                                label="Número WhatsApp padrão da unidade (com DDI e DDD)"
                                value={currentUnit!.whatsappNumber || ''}
                                onChange={(e) => updateCurrentUnitField('whatsappNumber', formatPhone(e.target.value))}
                                onKeyDown={handleEnterPress}
                                maxLength={20}
                                placeholder="55 (11) 99999-9999"
                            />
                        </div>

                        {currentUnit!.id ? (
                            <div className="space-y-3">
                                {/* Cards das instâncias existentes */}
                                {uazapiInstances.map((inst) => {
                                    const st = inst.status;
                                    const isConnected = st?.isConnected;
                                    const hasError = st?.configured && st?.error;
                                    const isConfigured = st?.configured;
                                    return (
                                        <div key={inst.instanceId} className={`rounded-xl border-2 transition-all ${isConnected ? 'border-green-300 bg-green-50' : hasError ? 'border-red-300 bg-red-50' : isConfigured ? 'border-yellow-300 bg-yellow-50' : 'border-gray-200 bg-white'}`}>
                                            {/* Card header — click to expand/collapse */}
                                            <div className="flex items-center justify-between px-4 py-3 cursor-pointer select-none" onClick={() => updateInstance(inst.instanceId, { expanded: !inst.expanded })}>
                                                <div className="flex items-center gap-2 min-w-0">
                                                    <span className={`w-2 h-2 rounded-full flex-shrink-0 ${isConnected ? 'bg-green-500' : hasError ? 'bg-red-500' : isConfigured ? 'bg-yellow-400' : 'bg-gray-300'}`} />
                                                    <div className="min-w-0">
                                                        <span className="font-medium text-sm text-gray-800 truncate block">
                                                            {inst.label || inst.instanceId}
                                                        </span>
                                                        <span className="text-xs text-gray-400 font-mono block">
                                                            {inst.label ? inst.instanceId : null}
                                                            {inst.label && (st?.phoneNumber) ? ' · ' : null}
                                                            {st?.phoneNumber ? st.phoneNumber : null}
                                                        </span>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-2 flex-shrink-0 ml-2">
                                                    {isConnected && !inst.expanded && (
                                                        <span className="text-xs text-green-700 font-medium hidden sm:inline">Conectado</span>
                                                    )}
                                                    {hasError && !inst.expanded && (
                                                        <span className="text-xs text-red-600 hidden sm:inline" title={st?.error ?? undefined}>Erro</span>
                                                    )}
                                                    {isConfigured && !isConnected && !hasError && !inst.expanded && (
                                                        <span className="text-xs text-yellow-700 hidden sm:inline">Desconectado</span>
                                                    )}
                                                    {/* Quick actions in compact state */}
                                                    {!inst.expanded && (isConfigured || inst.hasToken) && (
                                                        <button
                                                            type="button"
                                                            className="text-xs text-blue-500 hover:text-blue-700 px-1"
                                                            title="Reconectar"
                                                            onClick={(e) => { e.stopPropagation(); handleReconnectInstance(inst); }}
                                                            disabled={inst.loading}
                                                        >↺</button>
                                                    )}
                                                    {!inst.expanded && (
                                                        <button
                                                            type="button"
                                                            className="text-xs text-red-400 hover:text-red-600 px-1"
                                                            title="Remover instância"
                                                            onClick={(e) => { e.stopPropagation(); updateInstance(inst.instanceId, { expanded: true, showDisconnectConfirm: true }); }}
                                                            disabled={inst.loading}
                                                        >✕</button>
                                                    )}
                                                    <span className="text-gray-400 text-xs">{inst.expanded ? '▲' : '▼'}</span>
                                                </div>
                                            </div>

                                            {/* Expanded body */}
                                            {inst.expanded && (
                                                <div className="px-4 pb-4 border-t border-gray-200 pt-3 space-y-3">
                                                    {/* Status detail */}
                                                    {st?.error && (
                                                        <p className="text-xs text-red-600 bg-red-50 rounded p-2"><span className="font-medium">Erro:</span> {st.error}</p>
                                                    )}
                                                    {st?.connectedAt && (
                                                        <p className="text-xs text-gray-500">Conectado em: {new Date(st.connectedAt).toLocaleString('pt-BR')}</p>
                                                    )}

                                                    {/* Editable label and serverUrl */}
                                                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                                        <Input
                                                            label="Rótulo"
                                                            value={inst.label}
                                                            onChange={(e) => updateInstance(inst.instanceId, { label: e.target.value })}
                                                            placeholder="ex: Atendimento, Vendas…"
                                                        />
                                                        <Input
                                                            label="URL do servidor uazapi"
                                                            value={inst.serverUrl}
                                                            onChange={(e) => updateInstance(inst.instanceId, { serverUrl: e.target.value.trim() })}
                                                            placeholder="centralhub.uazapi.com"
                                                        />
                                                    </div>

                                                    {/* Token update field */}
                                                    <div>
                                                        <Input
                                                            label={inst.hasToken ? 'Novo token (deixe em branco para manter)' : 'Token uazapi'}
                                                            type="password"
                                                            value={inst.token}
                                                            onChange={(e) => updateInstance(inst.instanceId, { token: e.target.value })}
                                                            placeholder={inst.hasToken ? '••••••••••••••••' : 'Cole o token da instância'}
                                                            autoComplete="new-password"
                                                        />
                                                        {inst.hasToken && !inst.token && (
                                                            <p className="text-xs text-green-600 mt-1">✓ Token salvo. Preencha só para substituir.</p>
                                                        )}
                                                    </div>

                                                    {/* Action buttons */}
                                                    {inst.showDisconnectConfirm ? (
                                                        <div className="bg-red-100 border border-red-300 rounded-lg p-3 flex items-center justify-between gap-2">
                                                            <p className="text-sm text-red-700">Remover esta instância permanentemente?</p>
                                                            <div className="flex gap-2 flex-shrink-0">
                                                                <Button variant="outline" className="!w-auto !text-xs !py-1" onClick={() => updateInstance(inst.instanceId, { showDisconnectConfirm: false })}>Cancelar</Button>
                                                                <Button className="!w-auto !text-xs !py-1 !bg-red-600 hover:!bg-red-700" onClick={() => handleDisconnectInstance(inst)} isLoading={inst.loading}>Confirmar</Button>
                                                            </div>
                                                        </div>
                                                    ) : (
                                                        <div className="flex flex-wrap gap-2">
                                                            {inst.hasToken && currentUnit?.id && (
                                                                <Button
                                                                    className={`!w-auto !text-xs !py-1 ${isConnected ? '!bg-blue-600 hover:!bg-blue-700' : '!bg-green-600 hover:!bg-green-700'}`}
                                                                    onClick={() => setSpQrModal({ instanceId: inst.instanceId, unitId: currentUnit.id!, label: inst.label || undefined })}
                                                                    disabled={inst.loading}
                                                                >
                                                                    {isConnected ? '🔄 Reconectar via QR' : '📱 Conectar via QR Code'}
                                                                </Button>
                                                            )}
                                                            {(isConfigured || inst.hasToken) && (
                                                                <Button variant="outline" className="!w-auto !text-xs !py-1" onClick={() => handleReconnectInstance(inst)} isLoading={inst.loading && !inst.token}>
                                                                    Verificar conexão
                                                                </Button>
                                                            )}
                                                            {/* Always show "Salvar" for existing instances (saves label+serverUrl, optionally new token) */}
                                                            {inst.hasToken && (
                                                                <Button className="!w-auto !text-xs !py-1" onClick={() => handleConnectNewTokenInstance(inst)} isLoading={inst.loading}>
                                                                    {inst.token.trim() ? 'Atualizar credenciais' : 'Salvar alterações'}
                                                                </Button>
                                                            )}
                                                            {!inst.hasToken && inst.token.trim() && (
                                                                <Button className="!w-auto !text-xs !py-1" onClick={() => handleConnectNewTokenInstance(inst)} isLoading={inst.loading}>
                                                                    Conectar
                                                                </Button>
                                                            )}
                                                            {!inst.hasToken && !inst.token.trim() && (
                                                                <span className="text-xs text-gray-400 italic self-center">← preencha o token para conectar</span>
                                                            )}
                                                            <Button variant="outline" className="!w-auto !text-xs !py-1 !text-red-600 !border-red-300 hover:!bg-red-50 ml-auto" onClick={() => updateInstance(inst.instanceId, { showDisconnectConfirm: true })} disabled={inst.loading}>
                                                                Remover
                                                            </Button>
                                                        </div>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}

                                {/* Add new instance */}
                                {showNewInstanceForm ? (
                                    <div className="rounded-xl border-2 border-dashed border-blue-300 bg-blue-50 p-4 space-y-3">
                                        <p className="text-sm font-semibold text-blue-800">Nova Instância WhatsApp</p>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                                            <Input
                                                label="Rótulo (opcional)"
                                                value={newInstanceForm.label}
                                                onChange={(e) => setNewInstanceForm(f => ({ ...f, label: e.target.value }))}
                                                placeholder="ex: Atendimento, Vendas…"
                                            />
                                            <Input
                                                label="ID da Instância *"
                                                value={newInstanceForm.instanceId}
                                                onChange={(e) => setNewInstanceForm(f => ({ ...f, instanceId: e.target.value.trim() }))}
                                                placeholder="ex: empresa1"
                                            />
                                            <Input
                                                label="URL do servidor uazapi *"
                                                value={newInstanceForm.serverUrl}
                                                onChange={(e) => setNewInstanceForm(f => ({ ...f, serverUrl: e.target.value.trim() }))}
                                                placeholder="centralhub.uazapi.com"
                                            />
                                            <Input
                                                label="Número WhatsApp (com DDI) *"
                                                value={newInstanceForm.phoneNumber}
                                                onChange={(e) => setNewInstanceForm(f => ({ ...f, phoneNumber: e.target.value }))}
                                                placeholder={currentUnit!.whatsappNumber || '5511999999999'}
                                            />
                                            <div className="sm:col-span-2">
                                                <Input
                                                    label="Token uazapi *"
                                                    type="password"
                                                    value={newInstanceForm.token}
                                                    onChange={(e) => setNewInstanceForm(f => ({ ...f, token: e.target.value }))}
                                                    placeholder="Cole o token da instância uazapi"
                                                    autoComplete="new-password"
                                                />
                                            </div>
                                        </div>
                                        <div className="flex gap-2 justify-end">
                                            <Button variant="outline" className="!w-auto !text-xs !py-1" onClick={() => { setShowNewInstanceForm(false); setNewInstanceForm({ label: '', instanceId: '', serverUrl: 'centralhub.uazapi.com', token: '', phoneNumber: '' }); }}>Cancelar</Button>
                                            <Button className="!w-auto !text-xs !py-1" onClick={handleConnectNewInstance} isLoading={newInstanceConnecting}>Conectar instância</Button>
                                        </div>
                                    </div>
                                ) : (
                                    <button
                                        type="button"
                                        className="w-full rounded-xl border-2 border-dashed border-gray-300 hover:border-blue-400 hover:bg-blue-50 text-gray-400 hover:text-blue-600 text-sm py-3 transition-all flex items-center justify-center gap-2"
                                        onClick={() => setShowNewInstanceForm(true)}
                                    >
                                        <span className="text-lg">+</span> Adicionar instância WhatsApp
                                    </button>
                                )}
                            </div>
                        ) : (
                            <p className="text-xs text-gray-400 mt-1 italic">Salve a unidade primeiro para configurar a conexão WhatsApp.</p>
                        )}
                    </div>
                    <div className="flex justify-end gap-2 mt-4">
                        <Button variant="outline" className="!w-auto" onClick={() => { setIsEditingUnit(false); resetUazapiState(); }}>Cancelar</Button>
                        <Button className="!w-auto" onClick={handleSaveUnit} isLoading={isSavingUnit}>Salvar</Button>
                    </div>
                </div>
            )}

            {/* QR Code modal — list and edit view */}
            {spQrModal && (
                <UazapiQrModal
                    unitId={spQrModal.unitId}
                    instanceId={spQrModal.instanceId}
                    instanceLabel={spQrModal.label}
                    onClose={() => setSpQrModal(null)}
                    onConnected={(phone) => {
                        setSpQrModal(null);
                        if (currentUnit?.id === spQrModal?.unitId) loadUazapiInstances(currentUnit.id);
                        if (phone) addToast('success', 'WhatsApp conectado', `Número ${phone} vinculado com sucesso.`);
                    }}
                />
            )}
          </div>
        )}

        {/* === USUÁRIOS TAB === */}
        {activeTab === 'USUARIOS' && temPermissao('settings_users') && (
            <div className="flex flex-col h-full animate-fade-in">
                <div className="flex space-x-2 mb-6 border-b">
                    <button onClick={() => { setUserSubTab('CADASTRO'); setIsEditingUser(false); }} className={`px-4 py-2 border-b-2 font-medium text-sm ${userSubTab === 'CADASTRO' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Cadastro de Usuários</button>
                    <button onClick={() => { setUserSubTab('GRUPOS'); setIsEditingGroup(false); }} className={`px-4 py-2 border-b-2 font-medium text-sm ${userSubTab === 'GRUPOS' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Grupos de Acesso</button>
                </div>

                {userSubTab === 'GRUPOS' && (
                    <div className="h-full">
                        {!isEditingGroup ? (
                            <div className="space-y-4">
                                <div className="flex justify-between items-center">
                                    <h3 className="font-bold text-gray-700">Grupos Cadastrados</h3>
                                    <Button variant="new" className="!w-auto" onClick={() => { 
                                        setCurrentGroup({ id: '', name: '', permissions: [] }); 
                                        setOriginalGroup(null);
                                        setIsEditingGroup(true); 
                                    }}>Novo Grupo</Button>
                                </div>
                                {(localConfig.userGroups || []).map(group => (
                                    <div key={group.id} className="border p-4 rounded flex justify-between items-center hover:bg-gray-50">
                                        <div><p className="font-bold">{group.name}</p><p className="text-xs text-gray-500">{group.permissions.length} permissões ativas</p></div>
                                        <div className="flex items-center gap-2">
                                            <AuditLogButton entityId={group.id} entityName={group.name} logs={localConfig.auditLogs || []} />
                                            <Button variant="ghost" className="!w-auto" onClick={() => { 
                                                setCurrentGroup({ ...group }); 
                                                setOriginalGroup({ ...group });
                                                setIsEditingGroup(true); 
                                            }}>Editar</Button>
                                            <Button variant="ghost" className="!w-auto !text-amber-600 hover:!text-amber-800" onClick={() => {
                                                if (!validarPermissao('INCLUIR')) return;
                                                setCurrentGroup({ ...group, id: 'grp-' + Date.now(), name: 'Cópia de ' + group.name, permissions: [...group.permissions], agendaUnitIds: group.agendaUnitIds ? [...group.agendaUnitIds] : [] });
                                                setOriginalGroup(null);
                                                setIsEditingGroup(true);
                                            }}>Duplicar</Button>
                                            <Button variant="ghost" className="!w-auto text-red-600" onClick={() => handleDeleteGroup(group.id)}>Excluir</Button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        ) : (
                            <div className="animate-fade-in flex flex-col h-full" data-form-container="true">
                                <div className="mb-4"><Input label="Nome do Grupo" value={currentGroup?.name || ''} onChange={(e) => setCurrentGroup(prev => prev ? ({ ...prev, name: e.target.value }) : null)} onKeyDown={handleEnterPress} /></div>
                                <div className="flex-1 overflow-y-auto flex flex-col gap-4 pr-1">
                                    <div className="border rounded-lg p-4 bg-white">
                                        <h4 className="font-bold text-gray-700 mb-4 border-b pb-2">Matriz de Permissões</h4>
                                        {renderPermissionOptions(APP_MENU_STRUCTURE)}
                                    </div>
                                    <div className="border rounded-lg p-4 bg-white">
                                        <h4 className="font-bold text-gray-700 mb-1 border-b pb-2">Acesso à Agenda por Unidade</h4>
                                        <p className="text-xs text-gray-500 mb-3">Defina quais unidades este grupo pode visualizar e gerenciar na Agenda. Se nenhuma for marcada, o grupo verá apenas a unidade em que o usuário estiver logado.</p>
                                        {(localConfig.units || []).length === 0 ? (
                                            <p className="text-sm text-gray-400 italic">Nenhuma unidade cadastrada.</p>
                                        ) : (
                                            <div className="space-y-1">
                                                {(localConfig.units || []).map(unit => (
                                                    <label key={unit.id} className="flex items-center gap-3 py-2 px-2 hover:bg-gray-50 rounded cursor-pointer">
                                                        <input
                                                            type="checkbox"
                                                            checked={(currentGroup?.agendaUnitIds || []).includes(unit.id)}
                                                            onChange={() => {
                                                                const current = currentGroup?.agendaUnitIds || [];
                                                                const updated = current.includes(unit.id)
                                                                    ? current.filter(id => id !== unit.id)
                                                                    : [...current, unit.id];
                                                                setCurrentGroup(prev => prev ? { ...prev, agendaUnitIds: updated } : null);
                                                            }}
                                                            className="rounded text-moss-600 focus:ring-moss-500"
                                                        />
                                                        <span className="text-sm text-gray-700 font-medium">{unit.nomeFantasia || unit.razaoSocial}</span>
                                                        {unit.cnpj && <span className="text-xs text-gray-400 ml-auto">{unit.cnpj}</span>}
                                                    </label>
                                                ))}
                                            </div>
                                        )}
                                    </div>
                                </div>
                                <FormActions onSave={handleSaveGroup} onCancel={() => setIsEditingGroup(false)} />
                            </div>
                        )}
                    </div>
                )}

                {userSubTab === 'CADASTRO' && (
                    <div className="h-full">
                        {!isEditingUser ? (
                            <div className="space-y-4">
                                <div className="flex justify-between items-center">
                                    <h3 className="font-bold text-gray-700">Usuários Ativos</h3>
                                    <Button variant="new" className="!w-auto" onClick={() => { 
                                        setCurrentUser({ id: '', name: '', email: '', role: UserRole.USER, status: 'ATIVO', groupIds: [], allowedUnitIds: [], photoUrl: '', collaboratorId: '' }); 
                                        setOriginalUser(null);
                                        setUserPassword(''); 
                                        setIsEditingUser(true); 
                                    }}>Novo Usuário</Button>
                                </div>
                                {(() => {
                                    const allUsers  = localConfig.users || [];
                                    const allGroups = localConfig.userGroups || [];
                                    const allUnits  = localConfig.units || [];

                                    const renderUserCard = (user: User) => (
                                        <div key={user.id} className="flex items-center gap-4 px-5 py-3 hover:bg-gray-50 transition-colors">
                                            <div className="flex-shrink-0 h-10 w-10">
                                                {user.photoUrl
                                                    ? <img className="h-10 w-10 rounded-full object-cover" src={user.photoUrl} alt="" />
                                                    : <div className="h-10 w-10 rounded-full bg-gray-200 flex items-center justify-center text-gray-500 font-bold text-lg">{user.name.charAt(0)}</div>
                                                }
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <div className="text-sm font-semibold text-gray-900 truncate">{user.name}</div>
                                                <div className="text-xs text-gray-500 truncate">{user.email}</div>
                                                <div className="flex flex-wrap gap-1 mt-1">
                                                    {(user.allowedUnitIds || []).length > 0
                                                        ? (user.allowedUnitIds || []).map(uid => {
                                                            const unit = allUnits.find(u => u.id === uid);
                                                            return unit ? (
                                                                <span key={uid} className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-teal-100 text-teal-800">
                                                                    {unit.nomeFantasia || unit.razaoSocial}
                                                                </span>
                                                            ) : null;
                                                        })
                                                        : <span className="text-[10px] text-gray-400 italic">Sem unidade</span>
                                                    }
                                                </div>
                                            </div>
                                            <div className="flex flex-col items-end gap-1 flex-shrink-0">
                                                <span className={`px-2 py-0.5 text-[10px] font-semibold rounded-full ${user.status === 'ATIVO' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{user.status}</span>
                                                {user.forceChangePassword && <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-amber-100 text-amber-800">Troca senha</span>}
                                                {!!user.lockedAt && <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-red-200 text-red-900">Bloqueado</span>}
                                                {user.mfaEnabled && <span className="px-2 py-0.5 text-[10px] font-semibold rounded-full bg-indigo-100 text-indigo-800">2FA</span>}
                                            </div>
                                            <div className="flex items-center gap-2 flex-shrink-0">
                                                {!!user.lockedAt && (
                                                    <button onClick={async () => {
                                                        if (!window.confirm(`Desbloquear a conta de ${user.name}?`)) return;
                                                        try {
                                                            const res = await fetch(`/api/users/${user.id}/unlock`, { method: 'POST' });
                                                            if (!res.ok) {
                                                                const err = await res.json().catch(() => ({}));
                                                                addToast('error', 'Erro', err.error || 'Não foi possível desbloquear a conta.');
                                                                return;
                                                            }
                                                            const updatedUsers = localConfig.users.map(u => u.id === user.id ? { ...u, failedAttempts: 0, lockedAt: undefined } : u);
                                                            setLocalConfig(prev => ({ ...prev, users: updatedUsers }));
                                                            addToast('success', 'Conta desbloqueada', `${user.name} pode fazer login novamente.`);
                                                        } catch {
                                                            addToast('error', 'Erro', 'Falha na comunicação com o servidor.');
                                                        }
                                                    }} className="text-green-600 hover:text-green-800 transition-colors" title="Desbloquear Conta">
                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 11V7a4 4 0 118 0m-4 8v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2z" /></svg>
                                                    </button>
                                                )}
                                                {isLoggedAdmin && user.mfaEnabled && (
                                                    <button onClick={async () => {
                                                        if (!window.confirm(`Desabilitar o 2FA de ${user.name}?\n\nO usuário precisará configurar novamente se quiser usar autenticação em dois fatores.`)) return;
                                                        try {
                                                            await adminResetMfa(user.id);
                                                            const updatedUsers = localConfig.users.map(u => u.id === user.id ? { ...u, mfaEnabled: false } : u);
                                                            setLocalConfig(prev => ({ ...prev, users: updatedUsers }));
                                                            addToast('success', '2FA desabilitado', `O 2FA de ${user.name} foi removido com sucesso.`);
                                                        } catch (err: any) {
                                                            addToast('error', 'Erro', err?.message || 'Não foi possível desabilitar o 2FA.');
                                                        }
                                                    }} className="text-indigo-600 hover:text-indigo-800 transition-colors" title="Desabilitar 2FA">
                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.875 18.825A10.05 10.05 0 0112 19c-4.478 0-8.268-2.943-9.543-7a9.97 9.97 0 011.563-3.029m5.858.908a3 3 0 114.243 4.243M9.878 9.878l4.242 4.242M9.88 9.88l-3.29-3.29m7.532 7.532l3.29 3.29M3 3l3.59 3.59m0 0A9.953 9.953 0 0112 5c4.478 0 8.268 2.943 9.543 7a10.025 10.025 0 01-4.132 5.411m0 0L21 21" /></svg>
                                                    </button>
                                                )}
                                                <AuditLogButton entityId={user.id} entityName={user.name} logs={localConfig.auditLogs || []} />
                                                <button type="button" onClick={() => {
                                                    const editableUser = {
                                                        ...user,
                                                        groupIds: Array.isArray(user.groupIds) ? [...user.groupIds] : [],
                                                        allowedUnitIds: Array.isArray(user.allowedUnitIds) ? [...user.allowedUnitIds] : [],
                                                    };
                                                    setCurrentUser(editableUser);
                                                    setOriginalUser({ ...editableUser });
                                                    setUserPassword('');
                                                    setMfaSetupStep(null);
                                                    setMfaSetupData(null);
                                                    setMfaConfirmCode('');
                                                    setMfaDisablePassword('');
                                                    setMfaDisableChallenge(null);
                                                    setMfaDisableSelectedIds([]);
                                                    setMfaDisableVerified(false);
                                                    setIsEditingUser(true);
                                                }} className="text-indigo-600 hover:text-indigo-900 transition-colors" title="Editar" aria-label={`Editar usuário ${user.name}`}>
                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                                                </button>
                                                <button onClick={() => { if (!validarPermissao('INCLUIR')) return; setCurrentUser({ ...user, id: 'usr-' + Date.now(), name: 'Cópia de ' + user.name, email: '', photoUrl: '', forceChangePassword: true, forceReset: true, allowedUnitIds: [...(user.allowedUnitIds || [])], groupIds: [...(user.groupIds || [])], failedAttempts: 0, lockedAt: undefined }); setOriginalUser(null); setUserPassword(''); setIsEditingUser(true); }} className="text-amber-600 hover:text-amber-800 transition-colors" title="Duplicar">
                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg>
                                                </button>
                                                <button onClick={() => handleDeleteUser(user.id)} className="text-red-600 hover:text-red-900 transition-colors" title="Excluir">
                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                                </button>
                                            </div>
                                        </div>
                                    );

                                    const renderGroupBlock = (groupId: string, groupName: string, groupUsers: User[], headerClass: string) => {
                                        if (groupUsers.length === 0) return null;
                                        const collapsed = collapsedGroups.has(groupId);
                                        return (
                                            <div key={groupId} className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                                                <button onClick={() => toggleGroupCollapse(groupId)} className={`w-full flex items-center justify-between px-4 py-2.5 ${headerClass} transition-colors`}>
                                                    <div className="flex items-center gap-3">
                                                        <svg className={`w-4 h-4 transition-transform ${collapsed ? '-rotate-90' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                                                        <span className="font-semibold text-sm uppercase tracking-wide">{groupName}</span>
                                                        <span className="bg-white/25 text-xs px-2 py-0.5 rounded-full font-bold">{groupUsers.length}</span>
                                                    </div>
                                                </button>
                                                {!collapsed && (
                                                    <div className="divide-y divide-gray-100 bg-white">
                                                        {groupUsers.map(u => renderUserCard(u))}
                                                    </div>
                                                )}
                                            </div>
                                        );
                                    };

                                    const noGroupUsers = allUsers.filter(u => !u.groupIds || u.groupIds.length === 0);

                                    return (
                                        <div className="space-y-3">
                                            {allGroups.map(group => {
                                                const groupUsers = allUsers.filter(u => (u.groupIds || []).includes(group.id));
                                                return renderGroupBlock(group.id, group.name, groupUsers, 'bg-moss-800 hover:bg-moss-700 text-white');
                                            })}
                                            {renderGroupBlock('__NO_GROUP__', 'Sem Grupo', noGroupUsers, 'bg-gray-400 hover:bg-gray-500 text-white')}
                                        </div>
                                    );
                                })()}
                            </div>
                        ) : (
                            <div
                                className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/60 p-3 backdrop-blur-sm sm:p-6"
                                role="presentation"
                                onMouseDown={event => {
                                    if (event.target === event.currentTarget && !isSavingUser && !mfaSetupLoading) closeUserEditor();
                                }}
                            >
                              <section
                                role="dialog"
                                aria-modal="true"
                                aria-labelledby="user-editor-title"
                                data-form-container="true"
                                className="animate-fade-in flex max-h-[95vh] w-full max-w-6xl flex-col overflow-hidden rounded-xl bg-white shadow-2xl"
                              >
                                <div className="flex shrink-0 items-center justify-between border-b border-gray-200 px-5 py-3">
                                    <h2 id="user-editor-title" className="text-lg font-bold text-gray-800">
                                        {originalUser ? 'Editar usuário' : currentUser?.id ? 'Duplicar usuário' : 'Novo usuário'}
                                    </h2>
                                    <button
                                        type="button"
                                        aria-label="Fechar edição de usuário"
                                        disabled={isSavingUser || mfaSetupLoading}
                                        onClick={closeUserEditor}
                                        className="rounded p-2 text-gray-500 hover:bg-gray-100 hover:text-gray-800 disabled:opacity-50"
                                    >
                                        <span aria-hidden="true" className="text-2xl leading-none">×</span>
                                    </button>
                                </div>
                                <div className="min-h-0 flex-1 overflow-y-auto p-4 sm:p-6">
                                <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
                                    <div className="space-y-4">
                                        <div className="flex flex-col items-center p-4 border rounded-lg bg-gray-50">
                                            <div className="h-32 w-32 rounded-full bg-gray-200 overflow-hidden border-4 border-white shadow-md mb-4 relative group">
                                                {currentUser?.photoUrl ? (<img src={currentUser.photoUrl} alt="Preview" className="w-full h-full object-cover" />) : (<div className="w-full h-full flex items-center justify-center text-gray-400">Sem Foto</div>)}
                                                <button onClick={() => setShowCamera(true)} className="absolute inset-0 bg-black/50 text-white opacity-0 group-hover:opacity-100 flex items-center justify-center transition-opacity"><svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg></button>
                                            </div>
                                            <input type="file" ref={userPhotoRef} className="hidden" accept="image/*" onChange={handleUserPhotoFile} />
                                            <div className="flex flex-col w-full gap-2">
                                                <div className="flex gap-2 w-full">
                                                    <Button variant="secondary" className="!w-auto !text-xs flex-1 !py-1" onClick={() => setShowCamera(true)}>📷 Câmera</Button>
                                                    <Button variant="outline" className="!w-auto !text-xs flex-1 !py-1" onClick={() => userPhotoRef.current?.click()}>📁 Arquivo</Button>
                                                </div>
                                                {currentUser?.photoUrl && (
                                                    <button 
                                                        onClick={handleRemovePhoto} 
                                                        className="text-xs text-red-500 hover:text-red-700 underline text-center w-full"
                                                    >
                                                        Remover Foto
                                                    </button>
                                                )}
                                            </div>
                                        </div>
                                        <div className="border p-4 rounded-lg">
                                            <label className="block text-sm font-medium text-gray-700 mb-2">Status do Usuário</label>
                                            <div className="flex gap-2">
                                                <button onClick={() => setCurrentUser(prev => prev ? ({ ...prev, status: 'ATIVO' }) : null)} className={`flex-1 py-2 rounded text-sm font-bold ${currentUser?.status === 'ATIVO' ? 'bg-green-600 text-white' : 'bg-gray-100 text-gray-500'}`}>ATIVO</button>
                                                <button onClick={() => setCurrentUser(prev => prev ? ({ ...prev, status: 'INATIVO' }) : null)} className={`flex-1 py-2 rounded text-sm font-bold ${currentUser?.status === 'INATIVO' ? 'bg-red-600 text-white' : 'bg-gray-100 text-gray-500'}`}>INATIVO</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="col-span-2 space-y-4">
                                        <Input label="Nome Completo" value={currentUser?.name || ''} onChange={(e) => setCurrentUser(prev => prev ? ({ ...prev, name: e.target.value }) : null)} onKeyDown={handleEnterPress} />
                                        <Input label="E-mail de Acesso" type="email" value={currentUser?.email || ''} onChange={(e) => setCurrentUser(prev => prev ? ({ ...prev, email: e.target.value }) : null)} onKeyDown={handleEnterPress} />
                                        <Input label={currentUser?.id ? "Alterar Senha (Opcional)" : "Senha Inicial"} type="password" placeholder={currentUser?.id ? "••••••••" : "Senha segura"} value={userPassword} onChange={(e) => setUserPassword(e.target.value)} onKeyDown={handleEnterPress} />
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 mb-1">Colaborador Associado</label>
                                            <select
                                                className="w-full rounded-lg border border-gray-300 px-4 py-3 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none bg-white"
                                                value={currentUser?.collaboratorId || ''}
                                                onChange={(e) => setCurrentUser(prev => prev ? ({ ...prev, collaboratorId: e.target.value || undefined }) : null)}
                                            >
                                                <option value="">— Nenhum —</option>
                                                {(localConfig.collaborators || []).filter(col => col.active !== false).map(col => (
                                                    <option key={col.id} value={col.id}>{col.name}{col.jobTitle ? ` (${col.jobTitle})` : ''}</option>
                                                ))}
                                            </select>
                                            <p className="text-xs text-gray-400 mt-1">Vincule este usuário a um colaborador para acesso ao painel operacional de cobrança.</p>
                                        </div>
                                        <div className="border border-amber-200 bg-amber-50 rounded-lg p-4 mt-2">
                                            <label className="flex items-start gap-3 cursor-pointer">
                                                <input
                                                    type="checkbox"
                                                    checked={currentUser?.forceChangePassword || false}
                                                    onChange={(e) => setCurrentUser(prev => prev ? ({ ...prev, forceChangePassword: e.target.checked }) : null)}
                                                    className="w-5 h-5 rounded text-amber-600 focus:ring-amber-500 mt-0.5"
                                                />
                                                <div>
                                                    <span className="text-sm font-bold text-amber-800">Solicitar troca de senha no próximo login</span>
                                                    <p className="text-xs text-amber-600 mt-0.5">Ao marcar esta opção, o usuário será obrigado a criar uma nova senha forte na próxima vez que acessar o sistema.</p>
                                                </div>
                                            </label>
                                        </div>
                                        {currentUser?.id && (
                                            <div className="border border-indigo-200 bg-indigo-50 rounded-lg p-4 mt-2">
                                                <div className="flex items-center justify-between mb-3">
                                                    <span className="text-sm font-bold text-indigo-800 flex items-center gap-2">
                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                                                        Autenticação em Dois Fatores (2FA)
                                                    </span>
                                                    {currentUser.mfaEnabled
                                                        ? <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-green-100 text-green-800">ATIVO</span>
                                                        : <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-gray-200 text-gray-600">INATIVO</span>
                                                    }
                                                </div>

                                                {/* ── SELF-SERVICE: própria conta ── */}
                                                {currentUser.id === loggedUser?.id && (<>
                                                    {!currentUser.mfaEnabled && mfaSetupStep === null && (
                                                        <div>
                                                            <p className="text-xs text-indigo-600 mb-3">Ative a verificação em dois fatores. No login e nas confirmações protegidas, você validará um desafio de fotos.</p>
                                                            <button type="button" onClick={async () => {
                                                                setMfaSetupStep('LOADING');
                                                                try {
                                                                    const data = await setupMfa();
                                                                    setMfaSetupData(data);
                                                                    setMfaConfirmCode('');
                                                                    setMfaSetupStep('QR');
                                                                } catch (err: any) {
                                                                    addToast('error', 'Erro', err?.message || 'Não foi possível iniciar a configuração do 2FA.');
                                                                    setMfaSetupStep(null);
                                                                }
                                                            }} className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors">
                                                                Habilitar 2FA
                                                            </button>
                                                        </div>
                                                    )}
                                                    {mfaSetupStep === 'LOADING' && (
                                                        <p className="text-xs text-indigo-500 animate-pulse">Gerando configuração, aguarde…</p>
                                                    )}
                                                    {mfaSetupStep === 'QR' && mfaSetupData && (
                                                        <div className="space-y-3">
                                                            <p className="text-xs text-indigo-700 font-semibold">1. Escaneie o QR Code abaixo com seu aplicativo autenticador:</p>
                                                            <div className="flex justify-center">
                                                                <img src={mfaSetupData.qrCodeDataUrl} alt="QR Code 2FA" className="w-40 h-40 border rounded-lg bg-white p-1" />
                                                            </div>
                                                            <p className="text-[10px] text-indigo-500 text-center break-all">Chave manual: <span className="font-mono font-bold">{mfaSetupData.secret}</span></p>
                                                            <p className="text-xs text-indigo-700 font-semibold">2. Digite o código de 6 dígitos gerado pelo aplicativo para confirmar:</p>
                                                            <div className="flex gap-2">
                                                                <input type="text" inputMode="numeric" maxLength={6} placeholder="000000" value={mfaConfirmCode} onChange={(e) => setMfaConfirmCode(e.target.value.replace(/\D/g, '').slice(0, 6))} className="flex-1 border rounded-lg px-3 py-2 text-sm text-center font-mono tracking-widest focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 outline-none" />
                                                                <button type="button" disabled={mfaSetupLoading || mfaConfirmCode.length !== 6} onClick={async () => {
                                                                    setMfaSetupLoading(true);
                                                                    try {
                                                                        const backupCodes = await confirmMfaSetup(mfaSetupData.secret, mfaConfirmCode);
                                                                        setMfaSetupData(prev => prev ? { ...prev, backupCodes } : null);
                                                                        setMfaSetupStep('BACKUP');
                                                                        setCurrentUser(prev => prev ? { ...prev, mfaEnabled: true } : null);
                                                                        addToast('success', '2FA Habilitado!', 'Autenticação em dois fatores ativa com sucesso.');
                                                                    } catch (err: any) {
                                                                        addToast('error', 'Código inválido', err?.message || 'Verifique o código e tente novamente.');
                                                                    } finally {
                                                                        setMfaSetupLoading(false);
                                                                    }
                                                                }} className="px-4 py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg disabled:opacity-50 transition-colors">
                                                                    {mfaSetupLoading ? '…' : 'Confirmar'}
                                                                </button>
                                                            </div>
                                                            <button type="button" onClick={() => { setMfaSetupStep(null); setMfaSetupData(null); setMfaConfirmCode(''); }} className="text-xs text-indigo-400 hover:text-indigo-600 underline">Cancelar</button>
                                                        </div>
                                                    )}
                                                    {mfaSetupStep === 'BACKUP' && mfaSetupData?.backupCodes && (
                                                        <div className="space-y-3">
                                                            <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
                                                                <p className="text-xs font-bold text-amber-800 mb-2">Guarde seus códigos de recuperação em um lugar seguro. Cada código só pode ser usado uma vez.</p>
                                                                <div className="grid grid-cols-2 gap-1">
                                                                    {mfaSetupData.backupCodes.map((code, i) => (
                                                                        <span key={i} className="font-mono text-xs bg-white border rounded px-2 py-1 text-center text-gray-800">{code}</span>
                                                                    ))}
                                                                </div>
                                                            </div>
                                                            <button type="button" onClick={() => { setMfaSetupStep(null); setMfaSetupData(null); setMfaConfirmCode(''); }} className="w-full py-2 text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg transition-colors">Entendi, fechar</button>
                                                        </div>
                                                    )}
                                                    {currentUser.mfaEnabled && mfaSetupStep === null && (
                                                        <div>
                                                            <p className="text-xs text-indigo-600 mb-3">Seu 2FA está ativo. No login, confirme sua identidade selecionando as fotos solicitadas.</p>
                                                            <button type="button" onClick={async () => {
                                                                setMfaSetupStep('CONFIRM_DISABLE');
                                                                setMfaDisablePassword('');
                                                                setMfaDisableChallenge(null);
                                                                setMfaDisableSelectedIds([]);
                                                                setMfaDisableVerified(false);
                                                                try {
                                                                    setMfaDisableChallenge(await loadMfaDisableChallenge());
                                                                } catch (err: any) {
                                                                    setMfaSetupStep(null);
                                                                    addToast('error', 'Erro', err?.message || 'Não foi possível carregar o desafio de fotos.');
                                                                }
                                                            }} className="px-4 py-2 text-sm font-semibold text-red-600 border border-red-300 hover:bg-red-50 rounded-lg transition-colors">
                                                                Desativar 2FA
                                                            </button>
                                                        </div>
                                                    )}
                                                    {mfaSetupStep === 'CONFIRM_DISABLE' && (
                                                        <div className="space-y-3">
                                                            <p className="text-xs font-semibold text-red-700">{mfaDisableVerified ? 'Verificação concluída. O 2FA foi desativado.' : 'Confirme sua identidade para desativar o 2FA:'}</p>
                                                            <input type="password" placeholder="Senha atual" value={mfaDisablePassword} disabled={mfaDisableVerified || mfaSetupLoading} onChange={(e) => setMfaDisablePassword(e.target.value)} className="w-full border rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-red-400 focus:border-red-400 outline-none" />
                                                            {mfaDisableChallenge ? (
                                                                <PhotoChallenge
                                                                    label="Desafio de fotos para desativar a autenticação em dois fatores"
                                                                    instruction={mfaDisableChallenge.instruction}
                                                                    images={mfaDisableChallenge.images}
                                                                    selectedIds={mfaDisableSelectedIds}
                                                                    compact
                                                                    verified={mfaDisableVerified}
                                                                    disabled={mfaSetupLoading || mfaDisableVerified}
                                                                    onToggle={id => setMfaDisableSelectedIds(current =>
                                                                        current.includes(id) ? current.filter(item => item !== id) : [...current, id]
                                                                    )}
                                                                />
                                                            ) : (
                                                                <p className="text-xs text-gray-500">Carregando desafio de fotos…</p>
                                                            )}
                                                            <div className="flex gap-2">
                                                                {!mfaDisableVerified && <button type="button" disabled={mfaSetupLoading || !mfaDisablePassword || !mfaDisableChallenge || mfaDisableSelectedIds.length === 0} onClick={async () => {
                                                                    setMfaSetupLoading(true);
                                                                    try {
                                                                        await disableMfa(mfaDisablePassword, mfaDisableChallenge!.id, mfaDisableSelectedIds);
                                                                        setMfaDisableVerified(true);
                                                                        setCurrentUser(prev => prev ? { ...prev, mfaEnabled: false } : null);
                                                                        addToast('success', '2FA Desativado', 'A autenticação em dois fatores foi removida.');
                                                                    } catch (err: any) {
                                                                        addToast('error', 'Erro', err?.message || 'Senha ou seleção de fotos inválida.');
                                                                        setMfaDisableVerified(false);
                                                                        setMfaDisableSelectedIds([]);
                                                                        try {
                                                                            setMfaDisableChallenge(await loadMfaDisableChallenge());
                                                                        } catch {
                                                                            setMfaDisableChallenge(null);
                                                                        }
                                                                    } finally {
                                                                        setMfaSetupLoading(false);
                                                                    }
                                                                }} className="flex-1 py-2 text-sm font-semibold text-white bg-red-600 hover:bg-red-700 rounded-lg disabled:opacity-50 transition-colors">
                                                                    {mfaSetupLoading ? 'Aguarde…' : 'Confirmar Desativação'}
                                                                </button>}
                                                                <button type="button" disabled={mfaSetupLoading} onClick={() => {
                                                                    setMfaSetupStep(null);
                                                                    setMfaDisablePassword('');
                                                                    setMfaDisableChallenge(null);
                                                                    setMfaDisableSelectedIds([]);
                                                                    setMfaDisableVerified(false);
                                                                }} className="px-4 py-2 text-sm text-gray-500 hover:text-gray-700 rounded-lg border transition-colors">{mfaDisableVerified ? 'Fechar' : 'Cancelar'}</button>
                                                            </div>
                                                        </div>
                                                    )}
                                                </>)}

                                                {/* ── ADMIN: editando outro usuário ── */}
                                                {isLoggedAdmin && currentUser.id !== loggedUser?.id && (<>
                                                    {!currentUser.mfaEnabled && (
                                                        <p className="text-xs text-indigo-500">Este usuário ainda não configurou o 2FA. Ele poderá habilitá-lo acessando as próprias configurações de conta.</p>
                                                    )}
                                                    {currentUser.mfaEnabled && mfaSetupStep === null && (
                                                        <div className="space-y-3">
                                                            <p className="text-xs text-indigo-700">Este usuário possui a verificação por desafio de fotos ativa no login.</p>
                                                            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
                                                                <p className="text-xs font-bold text-red-800 mb-1 flex items-center gap-1.5">
                                                                    <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                                                                    Atenção — Consequências da desabilitação:
                                                                </p>
                                                                <ul className="text-xs text-red-700 space-y-0.5 list-disc list-inside">
                                                                    <li>O usuário perderá a proteção extra no login</li>
                                                                    <li>Todos os códigos de backup serão excluídos permanentemente</li>
                                                                    <li>O app autenticador vinculado ficará sem efeito</li>
                                                                    <li>A conta ficará protegida <strong>apenas</strong> pela senha</li>
                                                                </ul>
                                                            </div>
                                                            <button
                                                                type="button"
                                                                disabled={mfaResetLoading}
                                                                onClick={async () => {
                                                                    if (!window.confirm(`Desabilitar o 2FA de ${currentUser.name}?\n\nEsta ação removerá a proteção em dois fatores da conta. O usuário ficará protegido apenas por senha até reconfigurar o 2FA.`)) return;
                                                                    setMfaResetLoading(true);
                                                                    try {
                                                                        await adminResetMfa(currentUser.id);
                                                                        const updatedUsers = localConfig.users.map(u => u.id === currentUser.id ? { ...u, mfaEnabled: false } : u);
                                                                        setLocalConfig(prev => ({ ...prev, users: updatedUsers }));
                                                                        setCurrentUser(prev => prev ? { ...prev, mfaEnabled: false } : null);
                                                                        setOriginalUser(prev => prev ? { ...prev, mfaEnabled: false } : null);
                                                                        addToast('success', '2FA desabilitado', `O 2FA de ${currentUser.name} foi removido com sucesso.`);
                                                                    } catch (err: any) {
                                                                        addToast('error', 'Erro', err?.message || 'Não foi possível desabilitar o 2FA.');
                                                                    } finally {
                                                                        setMfaResetLoading(false);
                                                                    }
                                                                }}
                                                                className="w-full py-2 text-sm font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg disabled:opacity-50 transition-colors flex items-center justify-center gap-2"
                                                            >
                                                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" /></svg>
                                                                {mfaResetLoading ? 'Aguarde…' : 'Desabilitar 2FA'}
                                                            </button>
                                                        </div>
                                                    )}
                                                </>)}
                                            </div>
                                        )}
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                                            <div className="border rounded-lg p-3">
                                                <label className="block text-sm font-bold text-gray-700 mb-2">Unidades Permitidas</label>
                                                <div className="space-y-2 max-h-40 overflow-y-auto">
                                                    {(localConfig.units || []).map(u => (
                                                        <label key={u.id} className="flex items-center space-x-2 text-sm cursor-pointer">
                                                            <input type="checkbox" checked={currentUser?.allowedUnitIds?.includes(u.id!) || false} onChange={() => toggleUserUnit(u.id!)} className="rounded text-moss-600 focus:ring-moss-500" />
                                                            <span>{u.nomeFantasia || u.razaoSocial}</span>
                                                        </label>
                                                    ))}
                                                </div>
                                            </div>
                                            <div className="border rounded-lg p-3">
                                                <label className="block text-sm font-bold text-gray-700 mb-2">Grupos de Acesso</label>
                                                <div className="space-y-2 max-h-40 overflow-y-auto">
                                                    {(localConfig.userGroups || []).map(g => (
                                                        <label key={g.id} className="flex items-center space-x-2 text-sm cursor-pointer">
                                                            <input type="checkbox" checked={currentUser?.groupIds?.includes(g.id) || false} onChange={() => toggleUserGroup(g.id)} className="rounded text-moss-600 focus:ring-moss-500" />
                                                            <span>{g.name}</span>
                                                        </label>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <FormActions onSave={handleSaveUser} onCancel={closeUserEditor} isSaving={isSavingUser} />
                                </div>
                                {showCamera && <CameraCapture onCapture={handleCameraCapture} onClose={() => setShowCamera(false)} />}
                              </section>
                            </div>
                        )}
                    </div>
                )}
            </div>
        )}

        {/* ... (REMAINING TABS) ... */}
        {activeTab === 'ESCALA' && temPermissao('settings_users') && (
            <div className="flex flex-col h-full animate-fade-in overflow-hidden">
                <EscalaDeTrabalhoPanel
                    config={localConfig}
                    currentUser={loggedUser!}
                    onSave={(escalas: EscalaDeTrabalho[]) => {
                        const updated = { ...localConfig, escalas };
                        setLocalConfig(updated);
                        updateSection('escalas', escalas);
                    }}
                />
            </div>
        )}

        {activeTab === 'EMAILS' && temPermissao('settings_emails') && (
            <div className="flex flex-col h-full animate-fade-in">
                {/* ... (EMAILS CONTENT) ... */}
                <div className="flex space-x-2 mb-6 border-b">
                     <button onClick={() => setEmailSubTab('SMTP')} className={`px-4 py-2 border-b-2 font-medium text-sm ${emailSubTab === 'SMTP' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Configuração SMTP</button>
                     <button onClick={() => setEmailSubTab('GOOGLE')} className={`px-4 py-2 border-b-2 font-medium text-sm ${emailSubTab === 'GOOGLE' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Integração Google</button>
                     <button onClick={() => setEmailSubTab('MODELOS')} className={`px-4 py-2 border-b-2 font-medium text-sm ${emailSubTab === 'MODELOS' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Modelos de Mensagem</button>
                </div>
                {emailSubTab === 'SMTP' && (
                    <div className="space-y-4 animate-fade-in" data-form-container="true">
                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-100 mb-4">
                            <p className="text-sm text-blue-800">Selecione a unidade abaixo para configurar o servidor de e-mail (SMTP) que será utilizado para envio de notificações e senhas.</p>
                        </div>
                        <div className="flex flex-col md:flex-row gap-6 mb-6">
                            <div className="w-full md:w-1/3">
                                <label className="block text-sm font-medium text-gray-700 mb-2">Unidade</label>
                                <select className="w-full border rounded-lg p-3 bg-white" value={selectedUnitIdForSmtp} onChange={(e) => setSelectedUnitIdForSmtp(e.target.value)}>
                                    {config.units.map(u => <option key={u.id} value={u.id}>{u.nomeFantasia || u.razaoSocial}</option>)}
                                </select>
                            </div>
                            <div className="flex items-end">
                                 <Button variant="secondary" onClick={() => setShowTestEmailModal(true)} className="!w-auto">Testar Conexão</Button>
                            </div>
                        </div>
                         <div className="grid grid-cols-1 md:grid-cols-2 gap-4 border p-6 rounded-lg bg-gray-50">
                             <h4 className="col-span-1 md:col-span-2 font-bold text-gray-700 mb-2 border-b pb-2">Credenciais do Servidor</h4>
                             <Input label="Nome do Remetente" placeholder="Ex: FinancePro Notificações" value={getSelectedUnit()?.emailConfig?.senderName || ''} onChange={(e) => updateUnitEmailConfig('senderName', e.target.value)} onKeyDown={handleEnterPress} />
                             <Input label="Host SMTP" placeholder="smtp.office365.com" value={getSelectedUnit()?.emailConfig?.host || ''} onChange={(e) => updateUnitEmailConfig('host', e.target.value)} onKeyDown={handleEnterPress} />
                             <Input label="Porta" placeholder="587" value={getSelectedUnit()?.emailConfig?.port || ''} onChange={(e) => updateUnitEmailConfig('port', e.target.value)} onKeyDown={handleEnterPress} />
                             <Input label="Usuário / E-mail" placeholder="contato@empresa.com" value={getSelectedUnit()?.emailConfig?.user || ''} onChange={(e) => updateUnitEmailConfig('user', e.target.value)} onKeyDown={handleEnterPress} />
                             <Input label="Senha" type="password" placeholder="••••••" value={getSelectedUnit()?.emailConfig?.password || ''} onChange={(e) => updateUnitEmailConfig('password', e.target.value)} onKeyDown={handleEnterPress} />
                             <div className="col-span-1 md:col-span-2 mt-2">
                                <label className="flex items-center space-x-2 cursor-pointer">
                                    <input type="checkbox" className="rounded text-moss-600 focus:ring-moss-500 h-5 w-5" checked={getSelectedUnit()?.emailConfig?.security === 'TLS'} onChange={(e) => updateUnitEmailConfig('security', e.target.checked ? 'TLS' : 'NONE')} />
                                    <span className="text-sm font-medium text-gray-700">Utilizar conexão segura (TLS/SSL)</span>
                                </label>
                             </div>
                         </div>
                         <FormActions onSave={handleSaveGlobal} />
                    </div>
                )}
                {/* ... (GOOGLE & TEMPLATE TABS REMAIN SAME) ... */}
                {emailSubTab === 'GOOGLE' && (
                    <div className="space-y-6 animate-fade-in">
                        {/* ... (GOOGLE CONTENT) ... */}
                        <div className="flex flex-col md:flex-row gap-6 items-start">
                             <div className="w-full md:w-1/3">
                                <label className="block text-sm font-medium text-gray-700 mb-2">Selecionar Unidade</label>
                                <select className="w-full border rounded-lg p-3 bg-white" value={selectedUnitIdForSmtp} onChange={(e) => setSelectedUnitIdForSmtp(e.target.value)}>
                                    {config.units.map(u => <option key={u.id} value={u.id}>{u.nomeFantasia || u.razaoSocial}</option>)}
                                </select>
                            </div>
                        </div>
                        {getSelectedUnit()?.googleIntegration?.isConnected ? (
                            <div className="bg-white border border-green-200 rounded-lg p-6 shadow-sm max-w-2xl">
                                <div className="flex items-center gap-4 mb-4">
                                    <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-600">
                                        <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>
                                    </div>
                                    <div><h3 className="text-lg font-bold text-gray-800">Conta Conectada</h3><p className="text-sm text-gray-500">Sua integração com o Google Workspace está ativa.</p></div>
                                </div>
                                <div className="space-y-2 mb-6">
                                    <div className="flex justify-between text-sm border-b py-2"><span className="text-gray-500">E-mail Vinculado:</span><span className="font-medium">{getSelectedUnit()?.googleIntegration?.accountEmail}</span></div>
                                    <div className="flex justify-between text-sm border-b py-2"><span className="text-gray-500">Última Sincronização:</span><span className="font-medium">{new Date(getSelectedUnit()?.googleIntegration?.lastSync || '').toLocaleString()}</span></div>
                                    <div className="flex justify-between text-sm py-2"><span className="text-gray-500">Status:</span><span className="px-2 py-0.5 rounded bg-green-100 text-green-800 text-xs font-bold">ATIVO</span></div>
                                </div>
                                <Button variant="outline" onClick={handleGoogleDisconnect} className="!w-auto border-red-200 text-red-600 hover:bg-red-50">Desconectar Conta</Button>
                            </div>
                        ) : (
                            <div className="bg-white border border-gray-200 rounded-lg p-8 shadow-sm max-w-2xl flex flex-col items-center text-center">
                                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center text-gray-400 mb-4">
                                    <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M12.545,10.239v3.821h5.445c-0.712,2.315-2.647,3.972-5.445,3.972c-3.332,0-6.033-2.701-6.033-6.032s2.701-6.032,6.033-6.032c1.498,0,2.866,0.549,3.921,1.453l2.814-2.814C17.503,2.988,15.139,2,12.545,2C7.021,2,2.543,6.477,2.543,12s4.478,10,10.002,10c8.396,0,10.249-7.85,9.426-11.748L12.545,10.239z"/></svg>
                                </div>
                                <h3 className="text-xl font-bold text-gray-800 mb-2">Conectar com Google</h3>
                                <p className="text-gray-500 mb-6 max-w-md">Vincule sua conta corporativa do Google para sincronizar e-mails enviados e utilizar a infraestrutura de alta entregabilidade do Gmail.</p>
                                <Button variant="primary" onClick={handleGoogleConnect} className="!w-auto">Autenticar com Google</Button>
                            </div>
                        )}
                    </div>
                )}
                {emailSubTab === 'MODELOS' && (
                    <div className="h-full">
                         {!isEditingTemplate ? (
                             <div className="space-y-4 animate-fade-in">
                                 {/* ... (TEMPLATES LIST) ... */}
                                 <div className="flex justify-between items-center mb-4">
                                     <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 flex-1 mr-4">
                                         <p className="text-sm text-blue-800">Crie modelos de e-mail padronizados para agilizar a comunicação com seus clientes.</p>
                                     </div>
                                     <Button variant="new" className="!w-auto" onClick={() => { 
                                         setCurrentTemplate({ id: '', title: '', subject: '', body: '' }); 
                                         setOriginalTemplate(null);
                                         setIsEditingTemplate(true); 
                                     }}>Novo Modelo</Button>
                                 </div>
                                 <div className="grid gap-4">
                                     {(localConfig.emailTemplates || []).length === 0 && (
                                         <p className="text-center text-gray-400 py-10">Nenhum modelo cadastrado.</p>
                                     )}
                                     {(localConfig.emailTemplates || []).map(tpl => (
                                         <div key={tpl.id} className="bg-white border p-4 rounded-lg flex justify-between items-center hover:shadow-md transition-shadow">
                                             <div><h4 className="font-bold text-gray-800">{tpl.title}</h4><p className="text-sm text-gray-500">Assunto: {tpl.subject}</p></div>
                                             <div className="flex gap-2">
                                                 <Button variant="ghost" className="!w-auto" onClick={() => { 
                                                     setCurrentTemplate({ ...tpl }); 
                                                     setOriginalTemplate({ ...tpl });
                                                     setIsEditingTemplate(true); 
                                                 }}>Editar</Button>
                                                 <Button variant="ghost" className="!w-auto text-red-600 hover:bg-red-50" onClick={() => handleDeleteTemplate(tpl.id)}>Excluir</Button>
                                             </div>
                                         </div>
                                     ))}
                                 </div>
                             </div>
                         ) : (
                             <div className="flex h-full gap-6 animate-fade-in" data-form-container="true">
                                 {/* ... (TEMPLATE EDITOR) ... */}
                                 <div className="flex-1 flex flex-col space-y-4">
                                     <Input label="Nome do Modelo (Interno)" value={currentTemplate?.title || ''} onChange={(e) => setCurrentTemplate(prev => prev ? ({...prev, title: e.target.value}) : null)} placeholder="Ex: Boas-vindas ao Cliente" onKeyDown={handleEnterPress} />
                                     <Input label="Assunto do E-mail" value={currentTemplate?.subject || ''} onChange={(e) => setCurrentTemplate(prev => prev ? ({...prev, subject: e.target.value}) : null)} placeholder="Ex: Bem-vindo à FinancePro" onKeyDown={handleEnterPress} />
                                     <div className="flex-1 flex flex-col">
                                         <label className="block text-sm font-medium text-gray-700 mb-1">Conteúdo (HTML)</label>
                                         <textarea className="w-full flex-1 border rounded-lg p-4 font-mono text-sm focus:ring-2 focus:ring-moss-500 outline-none resize-none" value={currentTemplate?.body || ''} onChange={(e) => setCurrentTemplate(prev => prev ? ({...prev, body: e.target.value}) : null)} placeholder="<p>Olá {{cliente_nome}}, ...</p>" />
                                     </div>
                                     <FormActions onSave={handleSaveTemplate} onCancel={() => setIsEditingTemplate(false)} />
                                 </div>
                                 <div className="w-64 bg-gray-50 border-l p-4 flex flex-col">
                                     <h5 className="font-bold text-gray-700 mb-3 text-sm uppercase">Variáveis Disponíveis</h5>
                                     <p className="text-xs text-gray-500 mb-4">Clique para copiar</p>
                                     <div className="space-y-2 overflow-y-auto">
                                         {['{{cliente_nome}}', '{{cliente_email}}', '{{empresa_nome}}', '{{link_pagamento}}', '{{data_vencimento}}', '{{protocolo}}'].map(v => (
                                             <button key={v} onClick={() => { navigator.clipboard.writeText(v); addToast('info', 'Copiado', `Variável ${v} copiada.`); }} className="w-full text-left px-3 py-2 bg-white border rounded text-xs font-mono text-gray-600 hover:bg-blue-50 hover:border-blue-200 hover:text-blue-700 transition-colors">
                                                 {v}
                                             </button>
                                         ))}
                                     </div>
                                 </div>
                             </div>
                         )}
                    </div>
                )}
            </div>
        )}

        {/* === API TAB === */}
        {activeTab === 'API' && temPermissao('settings_api') && (
          <div className="flex flex-col h-full animate-fade-in">
             {/* ... (API CONTENT - UNCHANGED) ... */}
             {!isEditingApi ? (
               <div className="space-y-4">

                 {/* ── GoTalk Webhook Card ───────────────────────────────────── */}
                 <div className="bg-white border border-green-200 rounded-xl p-5 shadow-sm">
                   <div className="flex items-center gap-3 mb-4">
                     <div className="w-9 h-9 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
                       <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 24 24">
                         <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                       </svg>
                     </div>
                     <div className="flex-1 min-w-0">
                       <div className="flex items-center gap-2">
                         <h4 className="font-bold text-gray-800 text-sm">GoTalk Webhook</h4>
                         {webhookStatus && (
                           <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${webhookStatus.secretConfigured ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                             {webhookStatus.secretConfigured ? '✓ Secret configurado' : '⚠ Sem secret'}
                           </span>
                         )}
                       </div>
                       <p className="text-xs text-gray-500">Receba mensagens WhatsApp em tempo real</p>
                     </div>
                     {webhookStatus && (
                       <div className="text-right flex-shrink-0">
                         <p className="text-xs text-gray-500">{webhookStatus.totalMessages} mensagens</p>
                         {webhookStatus.lastWebhookAt && (
                           <p className="text-[10px] text-gray-400">
                             Último evento: {new Date(webhookStatus.lastWebhookAt).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' })}
                           </p>
                         )}
                         {!webhookStatus.lastWebhookAt && <p className="text-[10px] text-gray-400">Nenhum evento ainda</p>}
                       </div>
                     )}
                   </div>

                   {/* Webhook URL */}
                   <div className="mb-3">
                     <label className="block text-xs font-medium text-gray-600 mb-1">URL do Webhook</label>
                     <div className="flex items-center gap-2">
                       <code className="flex-1 text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-gray-700 truncate font-mono select-all">
                         {webhookStatus?.webhookUrl || 'Carregando...'}
                       </code>
                       <button
                         type="button"
                         title="Copiar URL"
                         onClick={() => {
                           if (webhookStatus?.webhookUrl) {
                             navigator.clipboard.writeText(webhookStatus.webhookUrl);
                             setWebhookUrlCopied(true);
                             setTimeout(() => setWebhookUrlCopied(false), 2000);
                           }
                         }}
                         className="flex-shrink-0 flex items-center gap-1 px-3 py-2 rounded-lg border border-gray-200 hover:bg-gray-50 text-gray-500 hover:text-gray-700 transition-colors text-xs"
                       >
                         {webhookUrlCopied ? (
                           <><svg className="w-3.5 h-3.5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg><span className="text-green-600">Copiado</span></>
                         ) : (
                           <><svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg><span>Copiar</span></>
                         )}
                       </button>
                     </div>
                     <p className="text-[10px] text-gray-400 mt-1">Cole esta URL no campo Webhook do painel GoTalk para receber eventos em tempo real.</p>
                   </div>

                   {/* Webhook Secret */}
                   <div>
                     <label className="block text-xs font-medium text-gray-600 mb-1">
                       Webhook Secret <span className="text-gray-400 font-normal">(token de segurança configurado no GoTalk)</span>
                     </label>
                     <div className="flex items-center gap-2">
                       <input
                         type="password"
                         placeholder={webhookStatus?.secretConfigured ? '••••••••  (já configurado — preencha para alterar)' : 'Cole aqui o secret do GoTalk...'}
                         value={webhookSecretInput}
                         onChange={e => setWebhookSecretInput(e.target.value)}
                         className="flex-1 text-sm border border-gray-200 rounded-lg px-3 py-2 focus:ring-2 focus:ring-green-500 focus:border-transparent outline-none"
                       />
                       <button
                         type="button"
                         onClick={handleSaveWebhookSecret}
                         disabled={webhookSecretSaving}
                         className="flex-shrink-0 px-4 py-2 bg-green-600 hover:bg-green-700 disabled:opacity-50 text-white text-sm font-medium rounded-lg transition-colors"
                       >
                         {webhookSecretSaving ? 'Salvando...' : 'Salvar'}
                       </button>
                       <button
                         type="button"
                         onClick={handleRotateWebhookSecret}
                         disabled={webhookRotating}
                         title="Gerar um secret criptograficamente seguro automaticamente"
                         className="flex-shrink-0 px-3 py-2 bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-white text-sm font-medium rounded-lg transition-colors whitespace-nowrap"
                       >
                         {webhookRotating ? 'Gerando...' : '⟳ Gerar novo'}
                       </button>
                     </div>
                     {generatedSecret && (
                       <div className="mt-2 p-3 bg-amber-50 border border-amber-200 rounded-lg">
                         <p className="text-xs font-semibold text-amber-800 mb-1">Novo secret gerado — copie e configure no GoTalk Web:</p>
                         <div className="flex items-center gap-2">
                           <code className="flex-1 text-xs font-mono bg-white border border-amber-200 rounded px-2 py-1.5 text-amber-900 break-all select-all">
                             {generatedSecret}
                           </code>
                           <button
                             type="button"
                             onClick={() => {
                               navigator.clipboard.writeText(generatedSecret);
                               setGeneratedSecretCopied(true);
                               setTimeout(() => setGeneratedSecretCopied(false), 2500);
                             }}
                             className="flex-shrink-0 px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white text-xs font-medium rounded-lg transition-colors"
                           >
                             {generatedSecretCopied ? '✓ Copiado' : 'Copiar'}
                           </button>
                         </div>
                         <p className="text-[10px] text-amber-700 mt-1.5">O secret já está ativo no servidor. Configure este valor no painel do GoTalk Web para que os eventos continuem sendo entregues.</p>
                       </div>
                     )}
                     {webhookSecretMsg && !generatedSecret && (
                       <p className={`text-xs mt-1.5 px-2 py-1 rounded ${webhookSecretMsg.includes('sucesso') || webhookSecretMsg.includes('aplicado') ? 'bg-green-50 text-green-700' : webhookSecretMsg.includes('removido') ? 'bg-gray-50 text-gray-600' : 'bg-red-50 text-red-700'}`}>
                         {webhookSecretMsg}
                       </p>
                     )}
                     <p className="text-[10px] text-gray-400 mt-1">O secret é validado em cada requisição recebida do GoTalk. Sem ele, o endpoint aceita chamadas de qualquer origem (apenas com aviso no log) — configure um secret para proteger contra payloads falsos.</p>
                   </div>

                   {/* ── Endpoint + Polling info ── */}
                   <div className="mt-4 pt-4 border-t border-gray-100 space-y-3">
                     <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Detalhes da Integração</p>

                     <div className="flex flex-col gap-1">
                       <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Endpoint da API GoTalk</span>
                       <code className="text-xs font-mono bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-gray-700 select-all">https://app.gotalk.digital</code>
                       <p className="text-[10px] text-gray-400">Todas as chamadas ao GoTalk (autenticação, atendimentos, contatos, mensagens) são feitas pelo Worker para este host.</p>
                     </div>

                     <div className="flex flex-col gap-1">
                       <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Ciclos de Polling — Worker</span>
                       <div className="rounded-lg border border-gray-200 overflow-hidden">
                         <table className="w-full text-[10px]">
                           <thead>
                             <tr className="bg-gray-50 border-b border-gray-200">
                               <th className="px-2.5 py-2 text-left font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap">Ciclo</th>
                               <th className="px-2.5 py-2 text-center font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap">Intervalo</th>
                               <th className="px-2.5 py-2 text-left font-bold text-gray-500 uppercase tracking-wide">O que sincroniza</th>
                             </tr>
                           </thead>
                           <tbody>
                             {([
                               { label: 'Alta — atendimentos', interval: '30 s',  desc: 'Atualiza lista de atendimentos abertos por operador' },
                               { label: 'Reconciliação — msgs', interval: '5 min', desc: 'Fallback: captura msgs que não chegaram via webhook' },
                               { label: 'Média — histórico + ACK', interval: '2 min', desc: 'Histórico de conversas encerradas e status de leitura' },
                               { label: 'Baixa — contatos / ops', interval: '10 min', desc: 'Contatos, operadores e templates HSM (todos os canais)' },
                               { label: 'Sync de canais', interval: '24 h',  desc: 'Re-descobre canais secundários sem reiniciar o Worker' },
                             ] as { label: string; interval: string; desc: string }[]).map((row, i) => (
                               <tr key={i} className={`border-b border-gray-100 last:border-0 ${i % 2 === 0 ? 'bg-white' : 'bg-gray-50/60'}`}>
                                 <td className="px-2.5 py-2 font-semibold text-gray-700 whitespace-nowrap">{row.label}</td>
                                 <td className="px-2.5 py-2 text-center font-mono font-bold text-green-700 whitespace-nowrap">{row.interval}</td>
                                 <td className="px-2.5 py-2 text-gray-500">{row.desc}</td>
                               </tr>
                             ))}
                           </tbody>
                         </table>
                       </div>
                       <p className="text-[10px] text-gray-400">Mensagens chegam primariamente via webhook em tempo real — o polling é fallback de reconciliação. O Worker roda em projeto Replit separado.</p>
                     </div>
                   </div>
                 </div>
                 {/* ── End GoTalk Webhook Card ──────────────────────────────── */}

                 {/* ── uazapi Webhook Card ───────────────────────────────────── */}
                 <div className="bg-white border border-teal-200 rounded-xl p-5 shadow-sm">
                   <div className="flex items-start gap-3 mb-4">
                     <div className="w-9 h-9 bg-teal-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                       <svg className="w-5 h-5 text-teal-600" fill="currentColor" viewBox="0 0 24 24">
                         <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                       </svg>
                     </div>
                     <div className="flex-1 min-w-0">
                       <h4 className="font-bold text-gray-800 text-sm">uazapi Webhook</h4>
                       <p className="text-xs text-gray-500">Receba mensagens WhatsApp via uazapi em tempo real</p>
                     </div>
                   </div>

                   <div className="mb-3">
                     <label className="block text-xs font-medium text-gray-600 mb-1">URL do Webhook</label>
                     <div className="flex items-center gap-2">
                       <code className="flex-1 text-xs bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-gray-700 truncate font-mono select-all">
                         {`${window.location.origin}/api/uazapi/webhook`}
                       </code>
                       <button
                         type="button"
                         title="Copiar URL"
                         onClick={() => {
                           navigator.clipboard.writeText(`${window.location.origin}/api/uazapi/webhook`);
                           setUazapiWebhookUrlCopied(true);
                           setTimeout(() => setUazapiWebhookUrlCopied(false), 2000);
                         }}
                         className="flex-shrink-0 flex items-center gap-1 px-3 py-2 rounded-lg border border-gray-200 hover:bg-gray-50 text-gray-500 hover:text-gray-700 transition-colors text-xs"
                       >
                         {uazapiWebhookUrlCopied ? (
                           <><svg className="w-3.5 h-3.5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" /></svg><span className="text-green-600">Copiado</span></>
                         ) : (
                           <><svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" /></svg><span>Copiar</span></>
                         )}
                       </button>
                     </div>
                     <p className="text-[10px] text-gray-400 mt-1">Cole esta URL no painel uazapi para receber eventos de mensagens.</p>
                   </div>

                   <div className="mb-3">
                     <label className="block text-xs font-medium text-gray-600 mb-1">URL com token <span className="text-gray-400 font-normal">(quando token estiver configurado na unidade)</span></label>
                     <code className="block text-xs bg-amber-50 border border-amber-200 rounded-lg px-3 py-2 text-amber-900 font-mono break-all">
                       {`${window.location.origin}/api/uazapi/webhook?token=SEU_TOKEN_UAZAPI`}
                     </code>
                     <p className="text-[10px] text-amber-700 mt-1 font-medium">⚠ Se a unidade tiver token configurado (Configurações → Unidades), substitua <code className="bg-amber-100 px-1 rounded">SEU_TOKEN_UAZAPI</code> pelo token exato cadastrado. O sistema rejeita requisições sem o token correto quando um token está configurado.</p>
                   </div>

                   <div className="bg-teal-50 border border-teal-100 rounded-lg p-3">
                     <p className="text-xs font-semibold text-teal-800 mb-1">Como configurar</p>
                     <ol className="text-[11px] text-teal-700 space-y-0.5 list-decimal list-inside">
                       <li>Em <strong>Configurações → Unidades</strong>, preencha o <strong>ID da Instância uazapi</strong> e o <strong>Token uazapi</strong>.</li>
                       <li>No painel uazapi, configure o webhook com a URL base (sem token) — ou com <code className="bg-teal-100 px-1 rounded">?token=SEU_TOKEN</code> se token estiver configurado.</li>
                       <li>O sistema identifica a unidade pelo campo <strong>instance</strong> recebido no evento.</li>
                     </ol>
                   </div>

                   {/* ── uazapi Endpoint + Architecture info ── */}
                   <div className="mt-4 pt-4 border-t border-teal-100 space-y-3">
                     <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Detalhes da Integração</p>

                     <div className="flex flex-col gap-1">
                       <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Endpoint Padrão</span>
                       <code className="text-xs font-mono bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-gray-700 select-all">https://free.uazapi.com</code>
                       <p className="text-[10px] text-gray-400">Configurável por unidade em Configurações → Unidades. Instâncias self-hosted devem apontar para a URL do próprio servidor uazapi.</p>
                     </div>

                     <div className="flex flex-col gap-1">
                       <span className="text-[10px] font-semibold text-gray-400 uppercase tracking-wide">Endpoint de Envio</span>
                       <code className="text-xs font-mono bg-gray-50 border border-gray-200 rounded-lg px-3 py-2 text-gray-700 select-all">{'{servidor}'}/send/text</code>
                       <p className="text-[10px] text-gray-400">Método: <strong className="font-semibold text-gray-600">POST</strong> — campos obrigatórios: <code className="bg-gray-100 px-1 rounded">number</code> (somente dígitos, sem sufixo) e <code className="bg-gray-100 px-1 rounded">text</code>. Autenticação via header <code className="bg-gray-100 px-1 rounded">token</code>.</p>
                     </div>

                     <div className="bg-teal-50 border border-teal-100 rounded-lg p-3">
                       <p className="text-[10px] font-semibold text-teal-800 mb-1">Arquitetura orientada a webhook</p>
                       <p className="text-[10px] text-teal-700">Não há polling ativo — todas as mensagens recebidas chegam via webhook em tempo real. O Worker GoTalk não faz polling de conversas uazapi. Confirmações de entrega e leitura também chegam por evento.</p>
                     </div>
                   </div>
                 </div>
                 {/* ── End uazapi Webhook Card ────────────────────────────────── */}

                 <div className="flex justify-between items-center mb-2">
                   <h3 className="text-lg font-bold text-gray-800">Integrações API</h3>
                   <Button variant="new" className="!w-auto" onClick={handleNewApi}>Nova Integração</Button>
                 </div>
                 
                 {(localConfig.apiIntegrations || []).length === 0 && (
                     <div className="text-center py-12 text-gray-400 bg-gray-50 rounded-lg border border-dashed border-gray-300">
                         Nenhuma integração configurada. Clique em "Nova Integração" para começar.
                     </div>
                 )}

                 {(localConfig.apiIntegrations || []).map(api => (
                   <div key={api.id} className="bg-white p-5 rounded-lg border shadow-sm flex flex-col md:flex-row justify-between items-center hover:shadow-md transition-shadow">
                     <div className="flex items-center gap-4 mb-3 md:mb-0 w-full md:w-auto">
                        <span className={`px-2 py-1 rounded text-xs font-bold w-16 text-center
                            ${api.method === 'GET' ? 'bg-blue-100 text-blue-800' : 
                              api.method === 'POST' ? 'bg-green-100 text-green-800' : 
                              api.method === 'DELETE' ? 'bg-red-100 text-red-800' : 
                              'bg-orange-100 text-orange-800'}`}>
                            {api.method}
                        </span>
                        <div>
                            <span className="font-bold text-gray-800 block">{api.name}</span>
                            <span className="text-xs text-gray-500 font-mono">{api.baseUrl}</span>
                            {api.description && <span className="text-xs text-gray-400 italic">{api.description}</span>}
                        </div>
                     </div>
                     <div className="flex gap-2 items-center">
                        <AuditLogButton entityId={api.id} entityName={api.name} logs={localConfig.auditLogs || []} />
                        <button onClick={() => { handleEditApi(api); setApiSubTab('TESTE'); }} className="text-green-600 text-xs font-bold uppercase px-3 py-2 rounded hover:bg-green-50 border border-transparent hover:border-green-200 transition-colors">Testar</button>
                        <button onClick={() => handleEditApi(api)} className="text-indigo-600 p-2 hover:bg-indigo-50 rounded transition-colors" title="Editar"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg></button>
                        <button onClick={() => handleDeleteApi(api.id)} className="text-red-600 p-2 hover:bg-red-50 rounded transition-colors" title="Excluir"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
                     </div>
                   </div>
                 ))}
               </div>
             ) : (
               <div className="flex flex-col h-full animate-fade-in" data-form-container="true">
                   {/* API Editing Form */}
                   <div className="flex space-x-2 mb-6 border-b">
                        <button onClick={() => setApiSubTab('GERAL')} className={`px-4 py-2 border-b-2 font-medium text-sm ${apiSubTab === 'GERAL' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Geral</button>
                        <button onClick={() => setApiSubTab('AUTH')} className={`px-4 py-2 border-b-2 font-medium text-sm ${apiSubTab === 'AUTH' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Autenticação</button>
                        <button onClick={() => setApiSubTab('HEADERS')} className={`px-4 py-2 border-b-2 font-medium text-sm ${apiSubTab === 'HEADERS' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Headers</button>
                        <button onClick={() => setApiSubTab('BODY')} className={`px-4 py-2 border-b-2 font-medium text-sm ${apiSubTab === 'BODY' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Body (JSON)</button>
                        <button onClick={() => setApiSubTab('TESTE')} className={`px-4 py-2 border-b-2 font-medium text-sm ${apiSubTab === 'TESTE' ? 'border-moss-600 text-moss-800' : 'border-transparent text-gray-500'}`}>Testar</button>
                   </div>

                   <div className="flex-1 overflow-y-auto p-1">
                       {/* ... (API FORM FIELDS) ... */}
                       {apiSubTab === 'GERAL' && currentApi && (
                           <div className="space-y-4">
                               <Input label="Nome da Integração" value={currentApi.name} onChange={e => setCurrentApi({...currentApi, name: e.target.value})} onKeyDown={handleEnterPress} />
                               <Input label="URL Base (Endpoint)" value={currentApi.baseUrl} onChange={e => setCurrentApi({...currentApi, baseUrl: e.target.value})} onKeyDown={handleEnterPress} />
                               <div>
                                   <label className="block text-sm font-medium text-gray-700 mb-1">Método HTTP</label>
                                   <select className="w-full border rounded-lg p-3 bg-white" value={currentApi.method} onChange={e => setCurrentApi({...currentApi, method: e.target.value as ApiMethod})} onKeyDown={handleEnterPress}>
                                       <option value="GET">GET</option>
                                       <option value="POST">POST</option>
                                       <option value="PUT">PUT</option>
                                       <option value="DELETE">DELETE</option>
                                       <option value="PATCH">PATCH</option>
                                   </select>
                               </div>
                               <div>
                                   <label className="block text-sm font-medium text-gray-700 mb-1">Descrição (opcional)</label>
                                   <textarea
                                       className="w-full border rounded-lg p-3 text-sm resize-none focus:ring-2 focus:ring-moss-500 outline-none"
                                       rows={2}
                                       placeholder="Descreva o propósito desta integração..."
                                       value={currentApi.description || ''}
                                       onChange={e => setCurrentApi({...currentApi, description: e.target.value})}
                                   />
                               </div>
                           </div>
                       )}

                       {apiSubTab === 'AUTH' && currentApi && (
                           <div className="space-y-4">
                               <div>
                                   <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Autenticação</label>
                                   <select className="w-full border rounded-lg p-3 bg-white" value={currentApi.authType} onChange={e => setCurrentApi({...currentApi, authType: e.target.value as ApiAuthType})} onKeyDown={handleEnterPress}>
                                       <option value="NONE">Nenhuma</option>
                                       <option value="BEARER">Bearer Token</option>
                                       <option value="BASIC">Basic Auth</option>
                                       <option value="HEADER_KEY">API Key (Header)</option>
                                   </select>
                               </div>
                               {currentApi.authType === 'BEARER' && (
                                   <Input label="Token (Bearer)" value={currentApi.authToken || ''} onChange={e => setCurrentApi({...currentApi, authToken: e.target.value})} onKeyDown={handleEnterPress} />
                               )}
                               {currentApi.authType === 'BASIC' && (
                                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                       <Input label="Usuário" value={currentApi.authUsername || ''} onChange={e => setCurrentApi({...currentApi, authUsername: e.target.value})} onKeyDown={handleEnterPress} />
                                       <Input label="Senha" type="password" value={currentApi.authPassword || ''} onChange={e => setCurrentApi({...currentApi, authPassword: e.target.value})} onKeyDown={handleEnterPress} />
                                   </div>
                               )}
                               {currentApi.authType === 'HEADER_KEY' && (
                                   <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                       <Input label="Nome do Header (Chave)" value={currentApi.authHeaderKey || 'X-API-KEY'} onChange={e => setCurrentApi({...currentApi, authHeaderKey: e.target.value})} onKeyDown={handleEnterPress} />
                                       <Input label="Valor da Chave" value={currentApi.authToken || ''} onChange={e => setCurrentApi({...currentApi, authToken: e.target.value})} onKeyDown={handleEnterPress} />
                                   </div>
                               )}
                           </div>
                       )}

                       {apiSubTab === 'HEADERS' && currentApi && (
                           <div className="space-y-4">
                               <div className="flex justify-between items-center mb-2">
                                   <label className="block text-sm font-medium text-gray-700">Headers Personalizados</label>
                                   <Button variant="secondary" className="!w-auto !py-1 !text-xs" onClick={addApiHeader}>+ Adicionar Header</Button>
                               </div>
                               {currentApi.headers.map((header, idx) => (
                                   <div key={idx} className="flex gap-2 mb-2">
                                       <Input label="" placeholder="Key" value={header.key} onChange={e => updateApiHeader(idx, 'key', e.target.value)} containerClassName="flex-1 !mb-0" onKeyDown={handleEnterPress} />
                                       <Input label="" placeholder="Value" value={header.value} onChange={e => updateApiHeader(idx, 'value', e.target.value)} containerClassName="flex-1 !mb-0" onKeyDown={handleEnterPress} />
                                       <button onClick={() => removeApiHeader(idx)} className="text-red-500 p-2 hover:bg-red-50 rounded"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg></button>
                                   </div>
                               ))}
                               {currentApi.headers.length === 0 && <p className="text-gray-400 text-sm">Nenhum header adicional.</p>}
                           </div>
                       )}

                       {apiSubTab === 'BODY' && currentApi && (
                           <div className="h-full flex flex-col">
                               <label className="block text-sm font-medium text-gray-700 mb-2">Template do Corpo (JSON)</label>
                               <textarea 
                                   className="flex-1 w-full border border-gray-300 rounded-lg p-4 font-mono text-sm focus:ring-2 focus:ring-moss-500 outline-none resize-none" 
                                   value={currentApi.bodyTemplate || ''} 
                                   onChange={e => setCurrentApi({...currentApi, bodyTemplate: e.target.value})}
                                   placeholder="{ ... }"
                               />
                           </div>
                       )}

                       {apiSubTab === 'TESTE' && (
                           <div className="space-y-4">
                               <div className="bg-gray-50 p-4 rounded border">
                                   <h4 className="font-bold text-gray-700 mb-2">Simulação de Requisição</h4>
                                   <p className="text-sm text-gray-600 mb-4">Esta ação irá disparar uma requisição de teste para o endpoint configurado utilizando as credenciais salvas temporariamente.</p>
                                   <Button variant="primary" className="!w-auto" onClick={executeApiTest} isLoading={isTestingApi}>Executar Teste</Button>
                               </div>
                               {apiTestResult && (
                                   <div className={`border rounded-lg p-4 ${apiTestResult.status >= 200 && apiTestResult.status < 300 ? 'bg-green-50 border-green-200' : 'bg-red-50 border-red-200'}`}>
                                       <div className="flex justify-between items-center mb-2">
                                           <span className={`font-bold ${apiTestResult.status >= 200 && apiTestResult.status < 300 ? 'text-green-800' : 'text-red-800'}`}>Status: {apiTestResult.status}</span>
                                           <span className="text-xs text-gray-500">Tempo: {apiTestResult.time}ms</span>
                                       </div>
                                       <pre className="bg-white p-3 rounded border text-xs overflow-auto max-h-60">{apiTestResult.body}</pre>
                                   </div>
                               )}
                           </div>
                       )}
                   </div>
                   
                   <FormActions onSave={handleSaveApi} onCancel={() => setIsEditingApi(false)} />
               </div>
             )}
          </div>
        )}

        {activeTab === 'AUDITORIA' && temPermissao('settings_audit') && (
            <div className="space-y-6 animate-fade-in">
                {isLoggedAdmin && (
                    <Suspense fallback={<div className="p-6 text-sm text-gray-500">Carregando auditorias históricas...</div>}>
                        <HistoricalAuditUnitReview />
                    </Suspense>
                )}
                {auditMigrateModal && (
                    <div className="fixed inset-0 z-[100] bg-black/50 flex items-center justify-center p-4 backdrop-blur-sm animate-fade-in">
                        <div className="bg-white rounded-xl shadow-2xl w-full max-w-md max-h-[calc(100vh-2rem)] overflow-y-auto p-4 sm:p-6 space-y-4">
                            <h3 className="text-lg font-bold text-gray-800">
                                {auditMigrateModal.type === 'swap' ? 'Trocar Posição' : auditMigrateModal.type === 'overwrite' ? 'Sobrescrever Dados' : 'Duplicar Item'}
                            </h3>
                            <p className="text-sm text-gray-500">
                                {auditMigrateModal.type === 'swap' && `Trocar a posição/ordem de "${auditItems.find(i => i.id === auditMigrateModal.sourceId)?.label}" com outro item.`}
                                {auditMigrateModal.type === 'overwrite' && `Copiar o conteúdo de "${auditItems.find(i => i.id === auditMigrateModal.sourceId)?.label}" para outro item, substituindo seus dados.`}
                                {auditMigrateModal.type === 'duplicate' && `Criar uma cópia exata de "${auditItems.find(i => i.id === auditMigrateModal.sourceId)?.label}" como novo item na sequência.`}
                            </p>
                            {auditMigrateModal.type !== 'duplicate' && (
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Item de Destino</label>
                                    <select
                                        value={auditMigrateTargetId}
                                        onChange={e => setAuditMigrateTargetId(e.target.value)}
                                        className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none"
                                    >
                                        <option value="">Selecione...</option>
                                        {auditItems.filter(i => i.id !== auditMigrateModal.sourceId).sort((a, b) => a.order - b.order).map(i => (
                                            <option key={i.id} value={i.id}>{String(i.order).padStart(2, '0')}. {i.label}</option>
                                        ))}
                                    </select>
                                </div>
                            )}
                            <div className="flex flex-col-reverse sm:flex-row justify-end gap-2 sm:gap-3 pt-2">
                                <button onClick={() => { setAuditMigrateModal(null); setAuditMigrateTargetId(''); }} className="w-full sm:w-auto px-4 py-2 text-sm border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 transition-colors">Cancelar</button>
                                <button
                                    onClick={handleAuditMigrateAction}
                                    disabled={auditMigrateModal.type !== 'duplicate' && !auditMigrateTargetId}
                                    className="w-full sm:w-auto px-4 py-2 text-sm bg-moss-700 text-white rounded-lg hover:bg-moss-800 transition-colors font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
                                >
                                    Confirmar
                                </button>
                            </div>
                        </div>
                    </div>
                )}

                {!isEditingAuditItem ? (
                    <>
                        <div className="flex items-center justify-between flex-wrap gap-4">
                            <div>
                                <h3 className="text-lg font-bold text-gray-800">Cards de Auditoria de Processo</h3>
                                <p className="text-sm text-gray-500 mt-1">Gerencie os itens do checklist exibidos no formulário de Auditoria de Processo.</p>
                            </div>
                            <div className="flex gap-2 items-center">
                                <label className="flex items-center gap-2 text-xs text-gray-500 cursor-pointer select-none">
                                    <input type="checkbox" checked={showInactiveAuditItems} onChange={e => setShowInactiveAuditItems(e.target.checked)} className="rounded border-gray-300 text-moss-600 focus:ring-moss-500" />
                                    Mostrar inativos
                                </label>
                                <button onClick={handleNewAuditItem} className="px-4 py-2 text-sm bg-moss-700 text-white rounded-lg hover:bg-moss-800 transition-colors font-semibold">+ Novo Item</button>
                            </div>
                        </div>

                        <div className="text-xs text-gray-400 font-semibold uppercase tracking-widest">{sortedAuditItems.length} item(ns) {showInactiveAuditItems ? '(incluindo inativos)' : 'ativo(s)'}</div>

                        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                            {sortedAuditItems.map((item, idx) => (
                                <div key={item.id} className={`flex items-center gap-3 bg-white border rounded-lg px-4 py-3 hover:shadow-sm transition-shadow group ${item.status === 'INATIVO' ? 'border-red-200 bg-red-50/30 opacity-60' : 'border-gray-200'}`}>
                                    <div className="flex flex-col gap-0.5">
                                        <button onClick={() => handleMoveAuditItem(item.id, 'up')} disabled={idx === 0} className="text-gray-400 hover:text-moss-600 disabled:opacity-20 disabled:cursor-not-allowed p-0.5" title="Subir">
                                            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 15l7-7 7 7" /></svg>
                                        </button>
                                        <button onClick={() => handleMoveAuditItem(item.id, 'down')} disabled={idx === sortedAuditItems.length - 1} className="text-gray-400 hover:text-moss-600 disabled:opacity-20 disabled:cursor-not-allowed p-0.5" title="Descer">
                                            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                                        </button>
                                    </div>
                                    <span className="text-xs font-mono font-bold text-moss-700 bg-moss-50 border border-moss-200 rounded px-2 py-1 min-w-[32px] text-center">{String(item.order).padStart(2, '0')}</span>
                                    <div className="flex-1 min-w-0 mr-4">
                                        <div className="text-sm font-bold text-gray-800 truncate">{item.label}</div>
                                        <div className="text-xs text-gray-400 truncate">{item.description}</div>
                                        {item.conditionField && <span className="text-[9px] font-bold text-purple-600 bg-purple-50 border border-purple-200 rounded px-1.5 py-0.5 mt-1 inline-block">Condição: {item.conditionField}</span>}
                                    </div>
                                    <span className={`text-[10px] font-bold uppercase px-2 py-1 rounded ${item.status === 'ATIVO' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{item.status}</span>
                                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <AuditLogButton entityId={item.id} entityName={item.label} logs={localConfig.auditLogs || []} />
                                        <button onClick={() => handleEditAuditItem(item)} className="text-blue-600 text-xs font-bold px-2 py-1.5 rounded hover:bg-blue-50 transition-colors" title="Editar">
                                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                                        </button>
                                        <button onClick={() => handleToggleAuditItemStatus(item.id)} className={`text-xs font-bold px-2 py-1.5 rounded transition-colors ${item.status === 'ATIVO' ? 'text-orange-600 hover:bg-orange-50' : 'text-green-600 hover:bg-green-50'}`} title={item.status === 'ATIVO' ? 'Inativar' : 'Ativar'}>
                                            {item.status === 'ATIVO' ? (
                                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" /></svg>
                                            ) : (
                                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                            )}
                                        </button>
                                        <div className="relative group/migrate">
                                            <button className="text-gray-500 text-xs font-bold px-2 py-1.5 rounded hover:bg-gray-100 transition-colors" title="Migrar / Duplicar">
                                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                                            </button>
                                            <div className="absolute right-0 top-full mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-20 w-48 py-1 hidden group-hover/migrate:block">
                                                <button onClick={() => { setAuditMigrateModal({ type: 'swap', sourceId: item.id }); setAuditMigrateTargetId(''); }} className="w-full text-left px-4 py-2 text-xs hover:bg-gray-50 text-gray-700 font-medium">Trocar Posição</button>
                                                <button onClick={() => { setAuditMigrateModal({ type: 'overwrite', sourceId: item.id }); setAuditMigrateTargetId(''); }} className="w-full text-left px-4 py-2 text-xs hover:bg-gray-50 text-gray-700 font-medium">Sobrescrever em Outro</button>
                                                <button onClick={() => { setAuditMigrateModal({ type: 'duplicate', sourceId: item.id }); setAuditMigrateTargetId(item.id); }} className="w-full text-left px-4 py-2 text-xs hover:bg-gray-50 text-gray-700 font-medium">Duplicar Item</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            ))}
                            {sortedAuditItems.length === 0 && (
                                <div className="text-center py-10 text-gray-400 text-sm">Nenhum item de auditoria encontrado.</div>
                            )}
                        </div>
                    </>
                ) : (
                    <div className="space-y-5 animate-fade-in" data-form-container="true">
                        <div className="flex items-center justify-between">
                            <h3 className="text-lg font-bold text-gray-800">{currentAuditItem?.id ? 'Editar Item de Auditoria' : 'Novo Item de Auditoria'}</h3>
                            <button onClick={() => { setIsEditingAuditItem(false); setCurrentAuditItem(null); setOriginalAuditItem(null); }} className="text-gray-400 hover:text-gray-600 text-sm font-bold">Cancelar</button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Nº Ordem</label>
                                <input type="number" min={1} value={currentAuditItem?.order || 1} onChange={e => currentAuditItem && setCurrentAuditItem({ ...currentAuditItem, order: parseInt(e.target.value) || 1 })} className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Status</label>
                                <select value={currentAuditItem?.status || 'ATIVO'} onChange={e => currentAuditItem && setCurrentAuditItem({ ...currentAuditItem, status: e.target.value as 'ATIVO' | 'INATIVO' })} className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none">
                                    <option value="ATIVO">Ativo</option>
                                    <option value="INATIVO">Inativo</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Título <span className="text-red-500">*</span></label>
                            <input type="text" value={currentAuditItem?.label || ''} onChange={e => currentAuditItem && setCurrentAuditItem({ ...currentAuditItem, label: e.target.value })} className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" placeholder="Ex: Validação de Prazo (15 Dias)" />
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Descrição</label>
                            <textarea value={currentAuditItem?.description || ''} onChange={e => currentAuditItem && setCurrentAuditItem({ ...currentAuditItem, description: e.target.value })} className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm focus:ring-2 focus:ring-moss-500 outline-none resize-y" rows={3} placeholder="Descrição detalhada do item de verificação..." />
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Condição de Exibição (Tipo de Modalidade)</label>
                            <select value={currentAuditItem?.conditionField || ''} onChange={e => currentAuditItem && setCurrentAuditItem({ ...currentAuditItem, conditionField: e.target.value || undefined })} className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none">
                                <option value="">Sempre visível (sem condição)</option>
                                {(localConfig.modalityTypes || []).map(mt => (
                                    <option key={mt} value={mt}>{mt}</option>
                                ))}
                            </select>
                            <p className="text-[10px] text-gray-400 mt-1">Se preenchido, este item só aparecerá quando a modalidade da admissão for do tipo selecionado.</p>
                        </div>

                        <FormActions onSave={handleSaveAuditItem} onCancel={() => { setIsEditingAuditItem(false); setCurrentAuditItem(null); setOriginalAuditItem(null); }} />
                    </div>
                )}
            </div>
        )}

        {activeTab === 'AJUDA' && temPermissao('settings_help') && (
            <div className="space-y-6 animate-fade-in">
                {!editingTopic ? (
                    <>
                        <div className="flex items-center justify-between flex-wrap gap-4">
                            <div>
                                <h3 className="text-lg font-bold text-gray-800">Gerenciamento de Conteúdo de Ajuda</h3>
                                <p className="text-sm text-gray-500 mt-1">Edite, adicione ou remova tópicos da Central de Ajuda do sistema.</p>
                            </div>
                            <div className="flex gap-2">
                                <button onClick={handleResetHelpTopics} className="px-4 py-2 text-sm border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-50 transition-colors">Restaurar Padrão</button>
                                <button onClick={handleNewTopic} className="px-4 py-2 text-sm bg-moss-700 text-white rounded-lg hover:bg-moss-800 transition-colors font-semibold">+ Novo Tópico</button>
                            </div>
                        </div>

                        <div className="relative">
                            <input
                                type="text"
                                placeholder="Buscar tópico por título, menu ou resumo..."
                                value={helpSearchTerm}
                                onChange={e => setHelpSearchTerm(e.target.value)}
                                className="w-full border border-gray-300 rounded-lg px-4 py-3 pl-10 text-sm focus:ring-2 focus:ring-moss-500 outline-none"
                            />
                            <svg className="w-4 h-4 text-gray-400 absolute left-3 top-1/2 -translate-y-1/2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
                        </div>

                        <div className="text-xs text-gray-400 font-semibold uppercase tracking-widest">{filteredHelpTopics.length} tópico(s) encontrado(s)</div>

                        <div className="space-y-2 max-h-[60vh] overflow-y-auto">
                            {filteredHelpTopics.map(topic => (
                                <div key={topic.id} className="flex items-center justify-between bg-white border border-gray-200 rounded-lg px-4 py-3 hover:shadow-sm transition-shadow group">
                                    <div className="flex-1 min-w-0 mr-4">
                                        <div className="text-xs text-moss-600 font-semibold uppercase tracking-wide">{topic.menuPath}</div>
                                        <div className="text-sm font-bold text-gray-800 truncate">{topic.title}</div>
                                        <div className="text-xs text-gray-400 truncate">{topic.summary}</div>
                                    </div>
                                    <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <AuditLogButton entityId={topic.id} entityName={topic.title} logs={localConfig.auditLogs || []} />
                                        <button onClick={() => handleEditTopic(topic)} className="text-blue-600 text-xs font-bold uppercase px-3 py-2 rounded hover:bg-blue-50 border border-transparent hover:border-blue-200 transition-colors">Editar</button>
                                        <button onClick={() => handleDeleteTopic(topic.id)} className="text-red-500 text-xs font-bold uppercase px-3 py-2 rounded hover:bg-red-50 border border-transparent hover:border-red-200 transition-colors">Excluir</button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </>
                ) : (
                    <div className="space-y-5 animate-fade-in" data-form-container="true">
                        <div className="flex items-center justify-between">
                            <h3 className="text-lg font-bold text-gray-800">{isCreatingTopic ? 'Novo Tópico de Ajuda' : 'Editar Tópico de Ajuda'}</h3>
                            <button onClick={() => { setEditingTopic(null); setIsCreatingTopic(false); }} className="text-gray-400 hover:text-gray-600 text-sm">✕ Cancelar</button>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">ID do Tópico</label>
                                <input type="text" value={editingTopic.id} onChange={e => setEditingTopic({...editingTopic, id: e.target.value})} className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" placeholder="ex: fin_receber" disabled={!isCreatingTopic} onKeyDown={handleEnterPress} />
                            </div>
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Caminho do Menu</label>
                                <input type="text" value={editingTopic.menuPath} onChange={e => setEditingTopic({...editingTopic, menuPath: e.target.value})} className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" placeholder="ex: Financeiro > Contas a Receber" onKeyDown={handleEnterPress} />
                            </div>
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Título</label>
                            <input type="text" value={editingTopic.title} onChange={e => setEditingTopic({...editingTopic, title: e.target.value})} className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" placeholder="Título visível para o usuário" onKeyDown={handleEnterPress} />
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Resumo</label>
                            <input type="text" value={editingTopic.summary} onChange={e => setEditingTopic({...editingTopic, summary: e.target.value})} className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" placeholder="Breve descrição (1-2 frases)" onKeyDown={handleEnterPress} />
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Palavras-chave (separadas por vírgula)</label>
                            <input type="text" value={editingTopic.keywords.join(', ')} onChange={e => setEditingTopic({...editingTopic, keywords: e.target.value.split(',').map(k => k.trim()).filter(Boolean)})} className="w-full border border-gray-300 rounded-lg px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" placeholder="ex: receber, título, baixa, liquidação" onKeyDown={handleEnterPress} />
                        </div>

                        <div>
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Conteúdo (HTML)</label>
                            <textarea
                                value={editingTopic.content}
                                onChange={e => setEditingTopic({...editingTopic, content: e.target.value})}
                                className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm font-mono focus:ring-2 focus:ring-moss-500 outline-none resize-y"
                                rows={12}
                                placeholder="<h3>Título da Seção</h3><p>Texto explicativo...</p>"
                            />
                        </div>

                        {editingTopic.content && (
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5">Pré-visualização</label>
                                <div className="border border-gray-200 rounded-lg p-5 bg-gray-50 prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: sanitizeHtml(editingTopic.content) }} />
                            </div>
                        )}

                        <FormActions onSave={handleSaveTopic} onCancel={() => { setEditingTopic(null); setIsCreatingTopic(false); }} />
                    </div>
                )}
            </div>
        )}

        <Suspense fallback={<div className="p-8 text-center text-sm text-gray-500">Carregando módulo...</div>}>
          {activeTab === 'GOTALK_MSGS' && temPermissao('settings_api') && <GotalkMessagesTab />}
          {activeTab === 'UAZAPI_MSGS' && temPermissao('settings_api') && <UazapiHistoryTab />}
          {activeTab === 'IMPORT' && temPermissao('settings_import') && <ImportWizardTab config={config} onRefresh={onRefresh} />}
          {activeTab === 'QUEUE_HEALTH' && isLoggedAdmin && <QueueHealthTab />}
          {activeTab === 'LEO_KNOWLEDGE' && isLoggedAdmin && <LeoKnowledgePanel />}
        </Suspense>

        {activeTab === 'SQL' && isLoggedAdmin && (
          <div className="flex flex-col gap-5 animate-fade-in h-full">
            <div className="flex items-start gap-3 p-4 bg-orange-50 border border-orange-200 rounded-lg">
              <svg className="w-5 h-5 text-orange-500 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
              <div>
                <p className="text-sm font-bold text-orange-800">Atenção: Console de Acesso Direto ao Banco de Dados</p>
                <p className="text-xs text-orange-700 mt-0.5">Todas as operações são executadas diretamente na base de dados conectada. Use com responsabilidade. Não há confirmação ou reversão automática.</p>
              </div>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex items-center justify-between">
                <label className="text-xs font-bold text-gray-600 uppercase tracking-wide">Query SQL</label>
                {sqlHistory.length > 0 && (
                  <select
                    className="text-xs border border-gray-200 rounded px-2 py-1 text-gray-600 bg-white focus:outline-none focus:ring-1 focus:ring-orange-300"
                    onChange={e => { if (e.target.value) setSqlQuery(e.target.value); e.target.value = ''; }}
                    defaultValue=""
                  >
                    <option value="" disabled>Histórico ({sqlHistory.length})</option>
                    {sqlHistory.map((h, i) => (
                      <option key={i} value={h}>{h.length > 60 ? h.slice(0, 60) + '…' : h}</option>
                    ))}
                  </select>
                )}
              </div>
              <textarea
                value={sqlQuery}
                onChange={e => { setSqlQuery(e.target.value); if (sqlDestructiveConfirm) setSqlDestructiveConfirm(false); }}
                onKeyDown={e => { if (e.ctrlKey && e.key === 'Enter') { e.preventDefault(); handleRunSql(); } }}
                rows={7}
                className="w-full font-mono text-sm border border-gray-300 rounded-lg p-3 focus:outline-none focus:ring-2 focus:ring-orange-300 bg-gray-900 text-green-400 resize-y"
                placeholder="SELECT * FROM app_data LIMIT 10;"
                spellCheck={false}
              />
              {sqlDestructiveConfirm && (
                <div className="flex items-start gap-3 p-3 bg-red-50 border border-red-300 rounded-lg">
                  <svg className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" /></svg>
                  <div className="flex-1">
                    <p className="text-sm font-bold text-red-700">Atenção — Operação destrutiva detectada</p>
                    <p className="text-xs text-red-600 mt-0.5">Este comando pode modificar ou apagar dados permanentemente. Deseja prosseguir mesmo assim?</p>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                    <button onClick={() => setSqlDestructiveConfirm(false)} className="px-3 py-1.5 text-xs font-bold bg-white border border-gray-300 text-gray-600 rounded hover:bg-gray-50 transition-colors">Cancelar</button>
                    <button onClick={() => executeSql(sqlQuery.trim())} className="px-3 py-1.5 text-xs font-bold bg-red-600 hover:bg-red-700 text-white rounded transition-colors">Confirmar e Executar</button>
                  </div>
                </div>
              )}
              <div className="flex items-center gap-3">
                <button
                  onClick={handleRunSql}
                  disabled={sqlLoading || !sqlQuery.trim()}
                  className="flex items-center gap-2 px-5 py-2 bg-orange-500 hover:bg-orange-600 disabled:bg-gray-300 text-white text-sm font-bold rounded-lg transition-colors"
                >
                  {sqlLoading ? (
                    <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z" /></svg>
                  ) : (
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                  )}
                  {sqlLoading ? 'Executando…' : 'Executar'}
                </button>
                <span className="text-xs text-gray-400">Ctrl + Enter para executar</span>
                {(sqlResult || sqlError) && (
                  <button onClick={() => { setSqlResult(null); setSqlError(null); }} className="text-xs text-gray-400 hover:text-gray-600 ml-auto">Limpar resultado</button>
                )}
              </div>
            </div>

            {sqlError && (
              <div className="flex items-start gap-3 p-4 bg-red-50 border border-red-200 rounded-lg">
                <svg className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2m7-2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                <div>
                  <p className="text-sm font-bold text-red-700">Erro na execução</p>
                  <pre className="text-xs text-red-600 mt-1 whitespace-pre-wrap font-mono">{sqlError}</pre>
                </div>
              </div>
            )}

            {sqlResult && (
              <div className="flex flex-col gap-2">
                <div className="flex items-center gap-4 text-xs text-gray-500">
                  <span className="font-bold text-gray-700">{sqlResult.rowCount ?? sqlResult.rows.length} linha(s) {sqlResult.command && sqlResult.command !== 'SELECT' ? 'afetada(s)' : 'retornada(s)'}</span>
                  <span>·</span>
                  <span>{sqlResult.duration}ms</span>
                  {sqlResult.truncated && <span className="text-orange-600 font-bold">· Limitado a 500 linhas</span>}
                </div>
                {sqlResult.rows.length > 0 ? (
                  <div className="overflow-auto border border-gray-200 rounded-lg max-h-[400px]">
                    <table className="min-w-full text-xs data-grid-typography">
                      <thead className="bg-gray-100 sticky top-0">
                        <tr>
                          {sqlResult.fields.map(f => (
                            <th key={f.name} className="px-3 py-2 text-left font-bold text-gray-700 border-r border-gray-200 last:border-0 whitespace-nowrap">{f.name}</th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {sqlResult.rows.map((row, ri) => (
                          <tr key={ri} className={ri % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                            {sqlResult.fields.map(f => {
                              const val = row[f.name];
                              const display = val === null ? <span className="text-gray-400 italic">null</span> : typeof val === 'object' ? JSON.stringify(val).slice(0, 200) : String(val);
                              return (
                                <td key={f.name} className="px-3 py-1.5 border-r border-gray-100 last:border-0 max-w-[300px] truncate align-top">{display}</td>
                              );
                            })}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-400 text-sm border border-dashed border-gray-200 rounded-lg">Consulta executada — nenhuma linha retornada.</div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SettingsPanel;
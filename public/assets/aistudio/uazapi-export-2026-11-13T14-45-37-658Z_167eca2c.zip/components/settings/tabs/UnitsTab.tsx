import React, { useState, useRef, useEffect, useCallback } from 'react';
import { CompanyInfo } from '../../../types';
import Button from '../../ui/Button';
import Input from '../../ui/Input';
import AuditLogButton from '../../ui/AuditLogButton';
import UazapiQrModal from './UazapiQrModal';

interface UazapiCredentialsPayload {
  uazapiInstanceId: string;
  uazapiToken?: string;
  uazapiServerUrl?: string;
}

interface UazapiInstance {
  credId: string;
  label: string | null;
  uazapiInstanceId: string | null;
  hasToken: boolean;
  uazapiServerUrl: string | null;
  webhookUrl: string | null;
  webhookRegisteredAt: string | null;
  webhookLastError: string | null;
  /** Live status loaded after panel opens */
  isConnected?: boolean;
  connectedPhone?: string | null;
  statusLoading?: boolean;
}

type UnitWaStatus = 'loading' | 'connected' | 'disconnected' | 'not_configured' | 'error';
interface UnitRowStatus {
  status: UnitWaStatus;
  instanceId?: string | null;
  phone?: string | null;
  label?: string | null;
}

interface CreateUnitResponse {
  id?: string;
}

interface UnitsTabProps {
  units: CompanyInfo[];
  auditLogs: any[];
  updateSection: (key: string, value: any) => Promise<void>;
  apiUpdateUnit: (id: string, data: any) => Promise<any>;
  apiCreateUnit: (data: any) => Promise<any>;
  apiRemoveUnit: (id: string) => Promise<any>;
  addToast: (type: 'success' | 'error' | 'warning' | 'info', title: string, msg: string) => void;
  logTransaction: (...args: any[]) => void;
  temPermissao: (p: string) => boolean;
  validarPermissao: (action: string) => boolean;
  onRefresh?: () => void;
}

function formatCNPJ(value: string) {
  let r = value.replace(/\D/g, '').substring(0, 14);
  r = r.replace(/^(\d{2})(\d)/, '$1.$2');
  r = r.replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3');
  r = r.replace(/\.(\d{3})(\d)/, '.$1/$2');
  r = r.replace(/(\d{4})(\d)/, '$1-$2');
  return r;
}

function validateCNPJ(cnpj: string): boolean {
  cnpj = cnpj.replace(/[^\d]+/g, '');
  if (!cnpj || cnpj.length !== 14 || /^(\d)\1+$/.test(cnpj)) return false;
  let size = cnpj.length - 2;
  let numbers = cnpj.substring(0, size);
  const digits = cnpj.substring(size);
  let sum = 0; let pos = size - 7;
  for (let i = size; i >= 1; i--) { sum += parseInt(numbers.charAt(size - i)) * pos--; if (pos < 2) pos = 9; }
  let result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
  if (result !== parseInt(digits.charAt(0))) return false;
  size++; numbers = cnpj.substring(0, size); sum = 0; pos = size - 7;
  for (let i = size; i >= 1; i--) { sum += parseInt(numbers.charAt(size - i)) * pos--; if (pos < 2) pos = 9; }
  result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
  return result === parseInt(digits.charAt(1));
}

function formatPhone(value: string) {
  let r = value.replace(/\D/g, '').substring(0, 11);
  if (r.length > 10) r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, '($1) $2-$3');
  else if (r.length > 5) r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, '($1) $2-$3');
  else if (r.length > 2) r = r.replace(/^(\d\d)(\d{0,5})/, '($1) $2');
  else r = r.replace(/^(\d*)/, '($1');
  return r;
}

function formatCEP(value: string) {
  let r = value.replace(/\D/g, '').substring(0, 8);
  if (r.length > 5) r = r.replace(/^(\d{5})(\d{1,3}).*/, '$1-$2');
  return r;
}

function formatCurrencyBRL(value: string) {
  const nums = value.replace(/\D/g, '');
  if (!nums) return '';
  const n = parseInt(nums, 10) / 100;
  return n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function validateEmailFormat(email: string) {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

const BLANK_UNIT: CompanyInfo = {
  id: '', razaoSocial: '', nomeFantasia: '', cnpj: '', telefone: '',
  email: '', cep: '', endereco: '', numero: '', complemento: '', bairro: '', cidade: '', estado: '', taxaMinima: '',
  whatsappNumber: '', uazapiInstanceId: '', uazapiHasToken: false, uazapiServerUrl: '',
};

const UnitsTab: React.FC<UnitsTabProps> = ({
  units, auditLogs, updateSection, apiUpdateUnit, apiCreateUnit, apiRemoveUnit,
  addToast, logTransaction, temPermissao, validarPermissao, onRefresh,
}) => {
  const [isEditing, setIsEditing] = useState(false);
  const [current, setCurrent] = useState<CompanyInfo | null>(null);
  const [original, setOriginal] = useState<CompanyInfo | null>(null);
  const [errors, setErrors] = useState<{ cnpj?: string; email?: string }>({});
  const [isLoadingCep, setIsLoadingCep] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [uazapiToken, setUazapiToken] = useState('');
  const [isLoadingCreds, setIsLoadingCreds] = useState(false);
  const [uazapiWebhookUrl, setUazapiWebhookUrl] = useState<string | null>(null);
  const [isReregisteringWebhook, setIsReregisteringWebhook] = useState(false);
  const [webhookReregisterResult, setWebhookReregisterResult] = useState<{ ok: boolean; msg: string } | null>(null);
  const [webhookRegisteredAt, setWebhookRegisteredAt] = useState<string | null>(null);
  const [webhookLastError, setWebhookLastError] = useState<string | null>(null);
  const [showWebhookLog, setShowWebhookLog] = useState(false);
  const [webhookLogData, setWebhookLogData] = useState<{ ts: string; event: string; instance: string; unitId: string; dataKeys: string; dataPreview: string }[]>([]);
  const [webhookLogLoading, setWebhookLogLoading] = useState(false);

  const [isSyncingFromProd, setIsSyncingFromProd] = useState(false);
  const [syncFromProdResult, setSyncFromProdResult] = useState<{ ok: boolean; msg: string } | null>(null);

  // ── Right-side WhatsApp panel (list view) ──
  const [selectedUnit, setSelectedUnit] = useState<CompanyInfo | null>(null);
  const [panelInstances, setPanelInstances] = useState<UazapiInstance[]>([]);
  const [panelLoading, setPanelLoading] = useState(false);
  const [copiedUrl, setCopiedUrl] = useState<string | null>(null);

  // ── Per-row WhatsApp status badges (list view) ──
  const [unitStatusMap, setUnitStatusMap] = useState<Map<string, UnitRowStatus>>(new Map());

  // ── QR code modal ──
  const [qrModal, setQrModal] = useState<{
    unitId: string;
    instanceId: string;
    label?: string | null;
  } | null>(null);

  // ── Disconnect modal ──
  const [disconnectModal, setDisconnectModal] = useState<{
    inst: UazapiInstance;
    unitId: string;
    phase: 'confirm' | 'loading' | 'force-confirm';
    serverError?: string;
  } | null>(null);

  const enderecoRef = useRef<HTMLInputElement>(null);
  const numeroRef = useRef<HTMLInputElement>(null);

  const update = (f: keyof CompanyInfo, v: string | boolean | undefined) =>
    setCurrent(p => p ? { ...p, [f]: v } : null);

  const handleCnpjChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const formatted = formatCNPJ(e.target.value);
    update('cnpj', formatted);
    const clean = formatted.replace(/\D/g, '');
    if (clean.length === 14 && !validateCNPJ(clean)) {
      setErrors(p => ({ ...p, cnpj: 'CNPJ inválido.' }));
    } else {
      setErrors(p => ({ ...p, cnpj: undefined }));
    }
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.trim();
    update('email', val);
    if (val && !validateEmailFormat(val)) setErrors(p => ({ ...p, email: 'E-mail inválido.' }));
    else setErrors(p => ({ ...p, email: undefined }));
  };

  const handleCepSearch = async () => {
    const cep = (current?.cep || '').replace(/\D/g, '');
    if (cep.length !== 8) { addToast('warning', 'Atenção', 'CEP inválido.'); return; }
    setIsLoadingCep(true);
    try {
      const r = await fetch(`/api/cep/${cep}`);
      const d = await r.json();
      if (!d.erro) {
        setCurrent(p => p ? {
          ...p,
          endereco: d.logradouro || '', bairro: d.bairro || '',
          cidade: d.localidade || '', estado: d.uf || '',
          complemento: p.complemento || d.complemento || '',
        } : null);
        setTimeout(() => { if (d.logradouro) numeroRef.current?.focus(); else enderecoRef.current?.focus(); }, 100);
      } else addToast('error', 'Erro', 'CEP não encontrado.');
    } catch { addToast('error', 'Erro', 'Erro de conexão.'); }
    finally { setIsLoadingCep(false); }
  };

  const loadUazapiCredentials = async (unitId: string) => {
    if (!unitId) return;
    setIsLoadingCreds(true);
    try {
      const r = await fetch(`/api/units/${unitId}/uazapi-credentials`);
      if (r.ok) {
        const data = await r.json();
        const instances: UazapiInstance[] = Array.isArray(data.instances) ? data.instances : [];
        // Mark tokenized instances as status-loading
        setPanelInstances(instances.map(i => ({ ...i, statusLoading: Boolean(i.hasToken && i.uazapiInstanceId) })));
        const first = instances[0] ?? null;
        if (first) {
          setCurrent(p => p ? {
            ...p,
            uazapiInstanceId: first.uazapiInstanceId || '',
            uazapiHasToken: Boolean(first.hasToken),
            uazapiServerUrl: first.uazapiServerUrl || '',
          } : null);
          setUazapiWebhookUrl(first.webhookUrl || null);
          setWebhookRegisteredAt(first.webhookRegisteredAt || null);
          setWebhookLastError(first.webhookLastError || null);
        }

        // Fetch live status for each tokenized instance (parallel, non-blocking)
        const statusFetches = instances
          .filter(i => i.hasToken && i.uazapiInstanceId)
          .map(async (inst) => {
            try {
              const params = new URLSearchParams({ unitId, instanceId: inst.uazapiInstanceId! });
              const sr = await fetch(`/api/uazapi/instance-qr-status?${params}`);
              if (!sr.ok) return { instanceId: inst.uazapiInstanceId, isConnected: false, connectedPhone: null };
              const sd = await sr.json();
              return { instanceId: inst.uazapiInstanceId, isConnected: Boolean(sd.isConnected), connectedPhone: sd.phone || null };
            } catch {
              return { instanceId: inst.uazapiInstanceId, isConnected: false, connectedPhone: null };
            }
          });
        const statuses = await Promise.all(statusFetches);
        setPanelInstances(prev => prev.map(inst => {
          const s = statuses.find(x => x.instanceId === inst.uazapiInstanceId);
          if (!s) return { ...inst, statusLoading: false };
          return { ...inst, isConnected: s.isConnected, connectedPhone: s.connectedPhone, statusLoading: false };
        }));
      }
    } catch {
    } finally {
      setIsLoadingCreds(false);
    }
  };

  const handleOpenWebhookLog = async () => {
    setShowWebhookLog(true);
    setWebhookLogLoading(true);
    try {
      const r = await fetch('/api/uazapi/webhook-log');
      if (r.ok) {
        const d = await r.json();
        setWebhookLogData(d.events || []);
      }
    } catch { /* silent */ }
    finally { setWebhookLogLoading(false); }
  };

  const handleReregisterWebhook = async () => {
    const unitId = current?.id;
    const instanceId = (current?.uazapiInstanceId || '').trim();
    if (!unitId || !instanceId) return;
    setIsReregisteringWebhook(true);
    setWebhookReregisterResult(null);
    try {
      const r = await fetch(`/api/units/${unitId}/uazapi-credentials/reregister-webhook`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ instanceId }),
      });
      const data = await r.json();
      if (data.webhookUrl) setUazapiWebhookUrl(data.webhookUrl);
      if (data.registered) {
        setWebhookRegisteredAt(new Date().toISOString());
        setWebhookLastError(null);
        setWebhookReregisterResult({ ok: true, msg: 'Webhook registrado com sucesso no servidor uazapi.' });
        addToast('success', 'Webhook registrado', 'URL de webhook configurada no servidor uazapi.');
      } else {
        setWebhookLastError(data.error || 'Falha ao registrar webhook.');
        setWebhookReregisterResult({ ok: false, msg: data.error || 'Falha ao registrar webhook.' });
        addToast('warning', 'Webhook não registrado', data.error || 'Falha ao registrar. Copie a URL e configure manualmente no painel uazapi.');
      }
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Erro de rede';
      setWebhookReregisterResult({ ok: false, msg });
      addToast('error', 'Erro', msg);
    } finally {
      setIsReregisteringWebhook(false);
    }
  };

  const handleSyncFromProd = async () => {
    setIsSyncingFromProd(true);
    setSyncFromProdResult(null);
    try {
      const r = await fetch('/api/admin/sync-uazapi-creds-from-prod', { method: 'POST' });
      const d = await r.json();
      if (r.ok && d.ok) {
        setSyncFromProdResult({ ok: true, msg: d.message || `${d.copied} credencial(is) copiada(s).` });
        addToast('success', 'Credenciais sincronizadas', d.message || 'Credenciais copiadas de produção.');
        if (selectedUnit) loadPanelInstances(selectedUnit);
      } else {
        const msg = d.error || 'Falha ao sincronizar credenciais.';
        setSyncFromProdResult({ ok: false, msg });
        addToast('error', 'Erro na sincronização', msg);
      }
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : 'Erro de rede';
      setSyncFromProdResult({ ok: false, msg });
      addToast('error', 'Erro', msg);
    } finally {
      setIsSyncingFromProd(false);
    }
  };

  const handleSave = async () => {
    if (!current) return;
    if (errors.cnpj || errors.email) {
      addToast('error', 'Erro', 'Corrija os erros de validação antes de salvar.');
      return;
    }

    setIsSaving(true);
    try {
      const unitToSave = { ...current };
      let savedId = unitToSave.id;

      if (unitToSave.id) {
        await apiUpdateUnit(unitToSave.id, unitToSave);
      } else {
        const created = await apiCreateUnit(unitToSave);
        savedId = (created as CreateUnitResponse)?.id || savedId;
      }

      // Salvar credenciais uazapi separadamente (apenas se instance ID foi preenchido)
      if (savedId) {
        const instanceId = (current.uazapiInstanceId || '').trim();
        if (instanceId) {
          const body: UazapiCredentialsPayload = { uazapiInstanceId: instanceId };
          if (uazapiToken.trim()) body.uazapiToken = uazapiToken.trim();
          if ((current.uazapiServerUrl || '').trim()) body.uazapiServerUrl = (current.uazapiServerUrl || '').trim();

          const credRes = await fetch(`/api/units/${savedId}/uazapi-credentials`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
          });
          if (!credRes.ok) {
            addToast('warning', 'Atenção', 'Unidade salva, mas houve erro ao salvar credenciais uazapi.');
          } else {
            const credData = await credRes.json().catch(() => ({}));
            if (credData.webhookUrl) setUazapiWebhookUrl(credData.webhookUrl);
            if (credData.webhookRegistered) {
              addToast('success', 'Webhook configurado', 'Webhook uazapi configurado com sucesso no uazapi.');
            } else if (credData.webhookError) {
              addToast('warning', 'Webhook não registrado', `Credenciais salvas, mas o webhook precisará ser configurado manualmente.`);
            }
          }
        }
      }

      const unitWithRealId = { ...unitToSave, id: savedId };
      const updatedUnits = unitToSave.id
        ? units.map(u => u.id === unitToSave.id ? unitWithRealId : u)
        : [...units, unitWithRealId];

      await updateSection('units', updatedUnits);

      logTransaction('CONFIG', savedId!, original, unitWithRealId);
      addToast('success', 'Salvo', 'Unidade salva com sucesso.');
      setIsEditing(false);
      setCurrent(null);
      setUazapiToken('');
    } catch {
      addToast('error', 'Erro', 'Não foi possível salvar a unidade. Tente novamente.');
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!validarPermissao('EXCLUIR')) return;
    if (!window.confirm('Excluir esta unidade? Esta ação não pode ser desfeita.')) return;
    try {
      await apiRemoveUnit(id);
      const updatedUnits = units.filter(u => u.id !== id);
      await updateSection('units', updatedUnits);
      addToast('success', 'Excluído', 'Unidade removida.');
    } catch {
      addToast('error', 'Erro', 'Não foi possível excluir a unidade.');
    }
  };

  const resetWebhookState = () => {
    setUazapiWebhookUrl(null);
    setWebhookReregisterResult(null);
    setWebhookRegisteredAt(null);
    setWebhookLastError(null);
  };

  const fetchAllUnitStatuses = useCallback(async (unitList: CompanyInfo[]) => {
    const ids = unitList.map(u => u.id).filter(Boolean) as string[];
    if (ids.length === 0) return;
    setUnitStatusMap(prev => {
      const next = new Map(prev);
      ids.forEach(id => next.set(id, { status: 'loading' }));
      return next;
    });
    try {
      const res = await fetch(`/api/uazapi/status-batch?unitIds=${ids.join(',')}`);
      if (!res.ok) {
        setUnitStatusMap(prev => {
          const next = new Map(prev);
          ids.forEach(id => { if (next.get(id)?.status === 'loading') next.set(id, { status: 'error' }); });
          return next;
        });
        return;
      }
      const data = await res.json();
      const items: Array<{ unitId: string; status: string; instanceId?: string; phone?: string; label?: string }> = data.results || [];
      setUnitStatusMap(prev => {
        const next = new Map(prev);
        items.forEach(item => {
          next.set(item.unitId, {
            status: item.status as UnitWaStatus,
            instanceId: item.instanceId || null,
            phone: item.phone || null,
            label: item.label || null,
          });
        });
        // Any requested ID not returned by the endpoint → mark as error to avoid infinite spinner
        ids.forEach(id => { if (next.get(id)?.status === 'loading') next.set(id, { status: 'error' }); });
        return next;
      });
    } catch {
      setUnitStatusMap(prev => {
        const next = new Map(prev);
        ids.forEach(id => { if (next.get(id)?.status === 'loading') next.set(id, { status: 'error' }); });
        return next;
      });
    }
  }, []);

  useEffect(() => {
    if (!isEditing && units.length > 0) {
      fetchAllUnitStatuses(units);
    }
  }, [isEditing, units, fetchAllUnitStatuses]);

  const loadPanelInstances = useCallback(async (unit: CompanyInfo) => {
    setSelectedUnit(unit);
    if (!unit.id) { setPanelInstances([]); return; }
    setPanelLoading(true);
    try {
      const r = await fetch(`/api/units/${unit.id}/uazapi-credentials`);
      if (!r.ok) { setPanelInstances([]); return; }
      const data = await r.json();
      const instances: UazapiInstance[] = Array.isArray(data.instances) ? data.instances : [];
      // Mark all tokenized instances as status-loading before parallel fetches
      setPanelInstances(instances.map(i => ({ ...i, statusLoading: Boolean(i.hasToken && i.uazapiInstanceId) })));

      // Fetch live status for each instance that has a token (parallel, non-blocking)
      const statusFetches = instances
        .filter(i => i.hasToken && i.uazapiInstanceId)
        .map(async (inst) => {
          try {
            const params = new URLSearchParams({ unitId: unit.id!, instanceId: inst.uazapiInstanceId! });
            const sr = await fetch(`/api/uazapi/instance-qr-status?${params}`);
            if (!sr.ok) return { instanceId: inst.uazapiInstanceId, isConnected: false, connectedPhone: null };
            const sd = await sr.json();
            return { instanceId: inst.uazapiInstanceId, isConnected: Boolean(sd.isConnected), connectedPhone: sd.phone || null };
          } catch {
            return { instanceId: inst.uazapiInstanceId, isConnected: false, connectedPhone: null };
          }
        });

      const statuses = await Promise.all(statusFetches);
      setPanelInstances(prev => prev.map(inst => {
        const s = statuses.find(x => x.instanceId === inst.uazapiInstanceId);
        if (!s) return { ...inst, statusLoading: false };
        return { ...inst, isConnected: s.isConnected, connectedPhone: s.connectedPhone, statusLoading: false };
      }));
    } catch { setPanelInstances([]); }
    finally { setPanelLoading(false); }
  }, []);

  const handleDisconnect = async (force = false) => {
    if (!disconnectModal) return;
    const { inst, unitId } = disconnectModal;
    setDisconnectModal(m => m ? { ...m, phase: 'loading' } : null);
    try {
      const r = await fetch('/api/uazapi/disconnect', {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ unitId, instanceId: inst.uazapiInstanceId, force }),
      });
      const d = await r.json().catch(() => ({}));

      if (d.success) {
        setDisconnectModal(null);
        // Remove instance from list
        setPanelInstances(prev => prev.filter(i => i.uazapiInstanceId !== inst.uazapiInstanceId));
        const label = inst.label || inst.uazapiInstanceId || 'instância';
        if (d.uazapiDisconnected) {
          addToast('success', 'Desconectado', `Sessão de "${label}" encerrada no servidor e credenciais removidas.`);
        } else {
          addToast('warning', 'Credenciais removidas', `Credenciais locais de "${label}" removidas. A sessão pode continuar ativa no servidor uazapi até expirar.`);
        }
        return;
      }

      // 422 = upstream disconnect failed explicitly; only offer force-remove on first attempt
      if (r.status === 422 && !force) {
        setDisconnectModal(m => m ? { ...m, phase: 'force-confirm', serverError: d.error || 'Erro desconhecido.' } : null);
        return;
      }

      // Any other error (500, 401, etc.) — terminal toast, close modal
      setDisconnectModal(null);
      addToast('error', 'Erro ao desconectar', d.error || `Erro ${r.status} ao processar desconexão.`);
    } catch (err) {
      // Network / fetch error
      if (!force) {
        // First attempt — server may be temporarily unreachable; offer force removal
        setDisconnectModal(m => m ? { ...m, phase: 'force-confirm', serverError: 'Não foi possível contatar o servidor.' } : null);
      } else {
        // Force attempt also failed — terminal toast to avoid a retry loop
        setDisconnectModal(null);
        addToast('error', 'Erro ao forçar remoção', 'Não foi possível contatar o servidor. Tente novamente mais tarde.');
      }
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text).then(() => {
      setCopiedUrl(text);
      setTimeout(() => setCopiedUrl(null), 2000);
    });
  };

  // Auto-select first unit on mount / when units change
  useEffect(() => {
    if (!isEditing && units.length > 0 && !selectedUnit) {
      loadPanelInstances(units[0]);
    }
  }, [units, isEditing, selectedUnit, loadPanelInstances]);

  const openEdit = (u: CompanyInfo) => {
    setCurrent({ ...u });
    setOriginal({ ...u });
    setErrors({});
    setUazapiToken('');
    resetWebhookState();
    setIsEditing(true);
    if (u.id) loadUazapiCredentials(u.id);
  };

  const openNew = () => {
    setCurrent({ ...BLANK_UNIT });
    setOriginal(null);
    setErrors({});
    setUazapiToken('');
    resetWebhookState();
    setIsEditing(true);
  };

  const openDuplicate = (u: CompanyInfo) => {
    if (!validarPermissao('INCLUIR')) return;
    setCurrent({
      ...u, id: '', cnpj: '',
      razaoSocial: 'Cópia de ' + u.razaoSocial,
      nomeFantasia: u.nomeFantasia ? 'Cópia de ' + u.nomeFantasia : '',
      uazapiInstanceId: '',
      uazapiHasToken: false,
      uazapiServerUrl: '',
    });
    setOriginal(null);
    setErrors({});
    setUazapiToken('');
    resetWebhookState();
    setIsEditing(true);
  };

  const handleEnterPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      const form = (e.target as HTMLElement).closest('[data-form-container]');
      if (!form) return;
      const inputs = Array.from(form.querySelectorAll<HTMLElement>('input:not([type="hidden"]):not([type="checkbox"]),select,textarea'));
      const idx = inputs.indexOf(e.target as HTMLElement);
      if (idx >= 0 && idx < inputs.length - 1) inputs[idx + 1].focus();
    }
  };

  if (!isEditing) {
    return (
      <div className="animate-fade-in flex flex-col h-full">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-lg font-bold text-gray-800">Unidades</h3>
          <Button variant="new" className="!w-auto" onClick={openNew}>Nova Unidade</Button>
        </div>

        {units.length === 0 && (
          <p className="text-center text-gray-400 py-10">Nenhuma unidade cadastrada.</p>
        )}

        {units.length > 0 && (
          <div className="flex gap-4 flex-1 min-h-0">

            {/* ── Lista de unidades (esquerda) ── */}
            <div className="flex-1 min-w-0 space-y-2 overflow-y-auto pr-1">
              {units.map(u => {
                const isSelected = selectedUnit?.id === u.id;
                const enderecoPartes = [
                  u.endereco && u.numero ? `${u.endereco}, ${u.numero}` : u.endereco,
                  u.complemento, u.bairro,
                  u.cidade && u.estado ? `${u.cidade} – ${u.estado}` : (u.cidade || u.estado),
                  u.cep,
                ].filter(Boolean).join(' • ');
                return (
                  <div
                    key={u.id}
                    onClick={() => loadPanelInstances(u)}
                    className={`border rounded-lg p-4 cursor-pointer transition-all ${isSelected ? 'border-moss-500 bg-moss-50 shadow-sm' : 'border-gray-200 bg-white hover:bg-gray-50'}`}
                  >
                    <div className="flex justify-between items-start gap-2">
                      <div className="flex-1 min-w-0 space-y-1">
                        <p className="font-bold text-gray-900">{u.razaoSocial}</p>
                        {u.nomeFantasia && <p className="text-sm font-medium text-moss-700">{u.nomeFantasia}</p>}
                        {u.cnpj && <p className="text-xs text-gray-400">CNPJ: {u.cnpj}</p>}
                        <div className="flex flex-wrap gap-3 text-xs text-gray-600">
                          {u.telefone && <span>📞 {u.telefone}</span>}
                          {u.email && <span>📧 {u.email}</span>}
                          {u.whatsappNumber && (
                            <span className="text-green-700 font-medium">💬 {u.whatsappNumber}</span>
                          )}
                        </div>
                        {enderecoPartes && <p className="text-xs text-gray-500">📍 {enderecoPartes}</p>}
                        {/* WhatsApp connection status badge */}
                        {(() => {
                          const ws = u.id ? unitStatusMap.get(u.id) : undefined;
                          if (!ws || ws.status === 'loading') {
                            return (
                              <div className="flex items-center gap-1 mt-0.5">
                                <svg className="animate-spin w-3 h-3 text-gray-400" fill="none" viewBox="0 0 24 24">
                                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                                </svg>
                                <span className="text-[10px] text-gray-400">WhatsApp…</span>
                              </div>
                            );
                          }
                          if (ws.status === 'not_configured') {
                            return (
                              <button
                                onClick={e => { e.stopPropagation(); openEdit(u); }}
                                className="inline-flex items-center gap-1 text-[10px] font-medium text-gray-500 bg-gray-100 hover:bg-gray-200 rounded-full px-2 py-0.5 mt-0.5 transition-colors cursor-pointer"
                                title="Clique para configurar o WhatsApp desta unidade"
                              >
                                <span className="w-1.5 h-1.5 rounded-full bg-gray-300 flex-shrink-0" />
                                WA não configurado — configurar →
                              </button>
                            );
                          }
                          if (ws.status === 'error') {
                            return (
                              <span className="inline-flex items-center gap-1 text-[10px] font-medium text-red-400 bg-red-50 rounded-full px-2 py-0.5 mt-0.5" title="Não foi possível verificar o status do WhatsApp">
                                <span className="w-1.5 h-1.5 rounded-full bg-red-300 flex-shrink-0" />
                                WA indisponível
                              </span>
                            );
                          }
                          if (ws.status === 'connected') {
                            return (
                              <span className="inline-flex items-center gap-1 text-[10px] font-semibold text-green-700 bg-green-50 rounded-full px-2 py-0.5 mt-0.5">
                                <span className="w-1.5 h-1.5 rounded-full bg-green-500 flex-shrink-0" />
                                Conectado{ws.phone && <span className="font-mono opacity-80 ml-0.5">{ws.phone}</span>}
                              </span>
                            );
                          }
                          if (ws.status === 'disconnected') {
                            return (
                              <button
                                onClick={e => {
                                  e.stopPropagation();
                                  if (u.id && ws.instanceId) setQrModal({ unitId: u.id, instanceId: ws.instanceId, label: ws.label });
                                }}
                                className={`inline-flex items-center gap-1 text-[10px] font-semibold text-orange-700 bg-orange-50 border border-orange-200 rounded-full px-2 py-0.5 mt-0.5 transition-colors hover:bg-orange-100 ${!ws.instanceId ? 'cursor-default' : 'cursor-pointer'}`}
                                title={ws.instanceId ? 'Clique para reconectar via QR Code' : 'Instância desconectada'}
                              >
                                <span className="w-1.5 h-1.5 rounded-full bg-orange-400 flex-shrink-0" />
                                Desconectado{ws.instanceId && <span className="ml-0.5 opacity-60">— clique para conectar</span>}
                              </button>
                            );
                          }
                          return null;
                        })()}
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0" onClick={e => e.stopPropagation()}>
                        <AuditLogButton entityId={u.id!} entityName={u.nomeFantasia || u.razaoSocial} logs={auditLogs} />
                        <Button variant="ghost" className="!w-auto !text-xs !px-2 !py-1" onClick={() => openEdit(u)}>Editar</Button>
                        <Button variant="ghost" className="!w-auto !text-xs !px-2 !py-1 !text-amber-600 hover:!text-amber-800" onClick={() => openDuplicate(u)}>Duplicar</Button>
                        <Button variant="ghost" className="!w-auto !text-xs !px-2 !py-1 !text-red-600 hover:!text-red-800" onClick={() => handleDelete(u.id!)}>Excluir</Button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* ── Painel WhatsApp / uazapi (direita) ── */}
            <div className="w-80 flex-shrink-0 flex flex-col gap-3 overflow-y-auto">
              {/* Header */}
              <div className="bg-white border border-gray-200 rounded-xl p-4 flex-shrink-0">
                <div className="flex items-center gap-2 mb-1">
                  <div className="w-7 h-7 rounded-lg bg-green-500 flex items-center justify-center flex-shrink-0">
                    <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                    </svg>
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-800">WhatsApp / uazapi</p>
                    <p className="text-xs text-gray-500">
                      {selectedUnit ? (selectedUnit.nomeFantasia || selectedUnit.razaoSocial) : 'Selecione uma unidade'}
                    </p>
                  </div>
                </div>

                {/* WhatsApp number from unit */}
                {selectedUnit?.whatsappNumber && (
                  <div className="mt-2 flex items-center gap-2 bg-green-50 border border-green-200 rounded-lg px-3 py-2">
                    <span className="text-green-700 text-xs font-semibold">Número principal:</span>
                    <span className="text-green-800 text-xs font-mono font-bold">{selectedUnit.whatsappNumber}</span>
                  </div>
                )}
              </div>

              {/* Instances */}
              <div className="flex flex-col gap-2">
                {panelLoading ? (
                  <div className="bg-white border border-gray-200 rounded-xl p-6 flex items-center justify-center gap-2 text-gray-400 text-sm">
                    <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    Carregando instâncias…
                  </div>
                ) : !selectedUnit ? (
                  <div className="bg-white border border-dashed border-gray-300 rounded-xl p-6 text-center text-gray-400 text-xs">
                    Clique em uma unidade para ver os detalhes WhatsApp.
                  </div>
                ) : panelInstances.length === 0 ? (
                  <div className="bg-white border border-dashed border-gray-300 rounded-xl p-6 text-center">
                    <p className="text-gray-400 text-xs">Nenhuma instância uazapi configurada.</p>
                    <button
                      className="mt-2 text-xs text-moss-600 hover:text-moss-800 underline font-medium"
                      onClick={() => openEdit(selectedUnit)}
                    >
                      Configurar agora →
                    </button>
                  </div>
                ) : (
                  panelInstances.map((inst, idx) => {
                    const webhookOk = !!inst.webhookRegisteredAt && !inst.webhookLastError;
                    const webhookErr = inst.webhookLastError;
                    const webhookAt = inst.webhookRegisteredAt;
                    return (
                      <div key={inst.credId || idx} className="bg-white border border-gray-200 rounded-xl p-4 space-y-3">
                        {/* Instance header */}
                        <div className="flex items-start justify-between gap-2">
                          <div className="flex-1 min-w-0">
                            <p className="text-xs font-bold text-gray-800 truncate">
                              {inst.label || inst.uazapiInstanceId || `Instância ${idx + 1}`}
                            </p>
                            {inst.label && inst.uazapiInstanceId && (
                              <p className="text-[10px] text-gray-400 font-mono truncate">{inst.uazapiInstanceId}</p>
                            )}
                          </div>
                          <div className={`flex-shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full ${inst.hasToken ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                            {inst.hasToken ? '✓ Token' : 'Sem token'}
                          </div>
                        </div>

                        {/* Server URL */}
                        {inst.uazapiServerUrl && (
                          <div className="text-[10px] text-gray-500 font-mono bg-gray-50 rounded px-2 py-1 truncate" title={inst.uazapiServerUrl}>
                            🖥 {inst.uazapiServerUrl}
                          </div>
                        )}

                        {/* Webhook URL */}
                        {inst.webhookUrl && (
                          <div className="space-y-1">
                            <p className="text-[10px] font-semibold text-blue-700 uppercase tracking-wide">Webhook URL</p>
                            <div className="flex gap-1 items-center">
                              <input
                                type="text"
                                readOnly
                                value={inst.webhookUrl}
                                className="flex-1 text-[10px] font-mono bg-gray-50 border border-gray-200 rounded px-2 py-1 text-gray-600 min-w-0"
                                onClick={e => (e.target as HTMLInputElement).select()}
                              />
                              <button
                                title="Copiar"
                                className={`flex-shrink-0 px-2 py-1 rounded text-[10px] border transition-colors ${copiedUrl === inst.webhookUrl ? 'bg-green-100 border-green-300 text-green-700' : 'bg-white border-gray-300 text-gray-600 hover:bg-gray-50'}`}
                                onClick={() => copyToClipboard(inst.webhookUrl!)}
                              >
                                {copiedUrl === inst.webhookUrl ? '✓' : 'Copiar'}
                              </button>
                            </div>
                          </div>
                        )}

                        {/* Webhook status */}
                        <div className={`flex items-start gap-1.5 rounded-lg px-2 py-1.5 text-[10px] ${webhookOk ? 'bg-green-50 text-green-700' : webhookErr ? 'bg-amber-50 text-amber-700' : 'bg-gray-50 text-gray-500'}`}>
                          <span className="flex-shrink-0 mt-px">{webhookOk ? '✓' : webhookErr ? '⚠' : '○'}</span>
                          <span className="min-w-0">
                            {webhookOk
                              ? `Webhook registrado em ${new Date(webhookAt).toLocaleString('pt-BR')}`
                              : webhookErr
                              ? `Erro: ${webhookErr}`
                              : 'Webhook não registrado'}
                          </span>
                        </div>

                        {/* Live connection status */}
                        {inst.hasToken && inst.uazapiInstanceId && (
                          <div className="flex items-center gap-1.5">
                            {inst.statusLoading ? (
                              <span className="text-[10px] text-gray-400 italic">Verificando…</span>
                            ) : inst.isConnected ? (
                              <>
                                <span className="w-2 h-2 rounded-full bg-green-500 flex-shrink-0" />
                                <span className="text-[10px] font-semibold text-green-700">Conectado</span>
                                {inst.connectedPhone && (
                                  <span className="text-[10px] text-green-600 font-mono">{inst.connectedPhone}</span>
                                )}
                              </>
                            ) : (
                              <>
                                <span className="w-2 h-2 rounded-full bg-red-400 flex-shrink-0" />
                                <span className="text-[10px] font-semibold text-red-600">Desconectado</span>
                              </>
                            )}
                          </div>
                        )}

                        {/* Actions */}
                        <div className="flex flex-wrap gap-1.5">
                          {inst.hasToken && inst.uazapiInstanceId && (
                            <button
                              className="flex-1 text-[10px] font-semibold py-1.5 rounded-lg bg-green-600 text-white hover:bg-green-700 transition-colors"
                              onClick={() => setQrModal({
                                unitId: selectedUnit!.id!,
                                instanceId: inst.uazapiInstanceId!,
                                label: inst.label,
                              })}
                            >
                              {inst.isConnected ? '🔄 Reconectar' : '📱 Conectar via QR'}
                            </button>
                          )}
                          <button
                            className="flex-1 text-[10px] text-center text-moss-600 hover:text-moss-800 font-medium underline py-1.5"
                            onClick={() => openEdit(selectedUnit!)}
                          >
                            Editar →
                          </button>
                          {inst.hasToken && inst.uazapiInstanceId && (
                            <button
                              className="w-full text-[10px] font-semibold py-1.5 rounded-lg border border-red-300 text-red-600 hover:bg-red-50 transition-colors"
                              onClick={() => setDisconnectModal({
                                inst,
                                unitId: selectedUnit!.id!,
                                phase: 'confirm',
                              })}
                            >
                              🔌 Desconectar
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}

                {/* Add instance shortcut */}
                {selectedUnit && !panelLoading && (
                  <button
                    onClick={() => openEdit(selectedUnit)}
                    className="w-full border-2 border-dashed border-gray-200 rounded-xl py-3 text-xs text-gray-400 hover:border-moss-400 hover:text-moss-600 transition-colors"
                  >
                    + Adicionar / editar instância
                  </button>
                )}

                {/* DEV-only: sync credentials from production DB (hidden in production builds) */}
                {import.meta.env.DEV && temPermissao('ADMIN') && (
                  <div className="rounded-xl border border-amber-200 bg-amber-50 p-3 space-y-2">
                    <p className="text-[10px] font-bold text-amber-800 uppercase tracking-wide">🔧 Sincronizar credenciais (DEV)</p>
                    <p className="text-[10px] text-amber-700 leading-relaxed">
                      Copia as credenciais uazapi do banco de produção para este ambiente DEV.
                      Requer a variável <code className="bg-amber-100 rounded px-1">PROD_DATABASE_URL</code> configurada.
                    </p>
                    {syncFromProdResult && (
                      <div className={`text-[10px] rounded px-2 py-1 ${syncFromProdResult.ok ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                        {syncFromProdResult.ok ? '✓ ' : '✗ '}{syncFromProdResult.msg}
                      </div>
                    )}
                    <button
                      type="button"
                      disabled={isSyncingFromProd}
                      onClick={handleSyncFromProd}
                      className="w-full text-[10px] font-semibold py-1.5 rounded-lg border border-amber-400 bg-amber-100 text-amber-800 hover:bg-amber-200 disabled:opacity-50 transition-colors"
                    >
                      {isSyncingFromProd ? 'Sincronizando…' : 'Copiar credenciais de Produção → DEV'}
                    </button>
                  </div>
                )}
              </div>
            </div>

          </div>
        )}

        {/* QR Code modal — list view */}
        {qrModal && (
          <UazapiQrModal
            unitId={qrModal.unitId}
            instanceId={qrModal.instanceId}
            instanceLabel={qrModal.label}
            onClose={() => setQrModal(null)}
            onConnected={(phone) => {
              setQrModal(null);
              if (selectedUnit) loadPanelInstances(selectedUnit);
              if (phone) addToast('success', 'WhatsApp conectado', `Número ${phone} vinculado com sucesso.`);
            }}
          />
        )}

        {/* Disconnect confirmation modal */}
        {disconnectModal && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
            <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 overflow-hidden">
              {/* Header */}
              <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100">
                <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center flex-shrink-0">
                  <span className="text-base">🔌</span>
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-gray-900">
                    {disconnectModal.phase === 'force-confirm' ? 'Falha ao desconectar no servidor' : 'Desconectar instância'}
                  </p>
                  <p className="text-xs text-gray-500 truncate">
                    {disconnectModal.inst.label || disconnectModal.inst.uazapiInstanceId}
                  </p>
                </div>
                {disconnectModal.phase !== 'loading' && (
                  <button onClick={() => setDisconnectModal(null)} className="text-gray-400 hover:text-gray-600 p-1 rounded-lg hover:bg-gray-100">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                  </button>
                )}
              </div>

              {/* Body */}
              <div className="px-5 py-5">
                {disconnectModal.phase === 'loading' && (
                  <div className="flex flex-col items-center gap-4 py-6">
                    <svg className="animate-spin w-10 h-10 text-red-500" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    <p className="text-sm text-gray-500">Encerrando sessão no servidor…</p>
                  </div>
                )}

                {disconnectModal.phase === 'confirm' && (
                  <div className="space-y-4">
                    <p className="text-sm text-gray-700">
                      Esta ação irá encerrar a sessão do WhatsApp no servidor uazapi e remover as credenciais locais da instância{' '}
                      <strong>{disconnectModal.inst.label || disconnectModal.inst.uazapiInstanceId}</strong>.
                    </p>
                    <p className="text-xs text-amber-700 bg-amber-50 rounded-lg px-3 py-2">
                      ⚠ O número vinculado perderá acesso ao CRM até ser reconectado via QR Code.
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setDisconnectModal(null)}
                        className="flex-1 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors"
                      >
                        Cancelar
                      </button>
                      <button
                        onClick={() => handleDisconnect(false)}
                        className="flex-1 py-2 rounded-xl bg-red-600 text-white text-sm font-bold hover:bg-red-700 transition-colors"
                      >
                        Desconectar
                      </button>
                    </div>
                  </div>
                )}

                {disconnectModal.phase === 'force-confirm' && (
                  <div className="space-y-4">
                    <div className="rounded-lg bg-red-50 border border-red-200 px-3 py-2 space-y-1">
                      <p className="text-xs font-bold text-red-700">Não foi possível encerrar a sessão no servidor uazapi:</p>
                      <p className="text-xs text-red-600">{disconnectModal.serverError}</p>
                    </div>
                    <p className="text-sm text-gray-700">
                      Deseja forçar a remoção das credenciais locais mesmo assim? A sessão pode continuar ativa no servidor uazapi até expirar.
                    </p>
                    <div className="flex gap-2">
                      <button
                        onClick={() => setDisconnectModal(null)}
                        className="flex-1 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors"
                      >
                        Cancelar
                      </button>
                      <button
                        onClick={() => handleDisconnect(true)}
                        className="flex-1 py-2 rounded-xl bg-red-600 text-white text-sm font-bold hover:bg-red-700 transition-colors"
                      >
                        Forçar remoção
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  const instanceId = (current?.uazapiInstanceId || '').trim();

  return (
    <div className="animate-fade-in" data-form-container="true">
      <div className="flex gap-6 items-start">

        {/* ── Coluna esquerda: dados da unidade ── */}
        <div className="flex-1 min-w-0">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <Input label="Razão Social" value={current!.razaoSocial} onChange={(e) => update('razaoSocial', e.target.value)} onKeyDown={handleEnterPress} />
            <Input label="Nome Fantasia" value={current!.nomeFantasia || ''} onChange={(e) => update('nomeFantasia', e.target.value)} onKeyDown={handleEnterPress} />
            <Input
              label="CNPJ"
              value={current!.cnpj}
              onChange={handleCnpjChange}
              onKeyDown={handleEnterPress}
              maxLength={18}
              placeholder="00.000.000/0000-00"
              error={errors.cnpj}
            />
            <div className="col-span-2 flex gap-2 items-end">
              <Input
                label="CEP"
                containerClassName="w-40 !mb-0"
                value={current!.cep}
                onChange={(e) => update('cep', formatCEP(e.target.value))}
                onKeyDown={handleEnterPress}
                maxLength={9}
                placeholder="00000-000"
              />
              <Button className="!w-12 !h-[50px]" onClick={handleCepSearch} isLoading={isLoadingCep}>🔎</Button>
              <Input label="Endereço" containerClassName="flex-1 !mb-0" value={current!.endereco} onChange={(e) => update('endereco', e.target.value)} onKeyDown={handleEnterPress} />
            </div>
            <div className="col-span-2 flex gap-4">
              <Input label="Número" containerClassName="w-32 !mb-0" value={current!.numero} onChange={(e) => update('numero', e.target.value)} onKeyDown={handleEnterPress} />
              <Input label="Complemento" containerClassName="flex-1 !mb-0" value={current!.complemento} onChange={(e) => update('complemento', e.target.value)} onKeyDown={handleEnterPress} />
              <Input label="Bairro" containerClassName="flex-1 !mb-0" value={current!.bairro} onChange={(e) => update('bairro', e.target.value)} onKeyDown={handleEnterPress} />
            </div>
            <Input label="Cidade" value={current!.cidade} onChange={(e) => update('cidade', e.target.value)} onKeyDown={handleEnterPress} />
            <Input label="Estado (UF)" value={current!.estado} onChange={(e) => update('estado', e.target.value.toUpperCase().slice(0, 2))} onKeyDown={handleEnterPress} maxLength={2} />
            <Input
              label="Telefone"
              value={current!.telefone}
              onChange={(e) => update('telefone', formatPhone(e.target.value))}
              onKeyDown={handleEnterPress}
              maxLength={15}
              placeholder="(00) 00000-0000"
            />
            <Input
              label="E-mail"
              value={current!.email}
              onChange={handleEmailChange}
              onKeyDown={handleEnterPress}
              placeholder="contato@empresa.com"
              error={errors.email}
            />
            <Input
              label="Taxa Mínima / Taxa Administrativa (R$)"
              value={current!.taxaMinima || ''}
              onChange={(e) => update('taxaMinima', formatCurrencyBRL(e.target.value))}
              onKeyDown={handleEnterPress}
              placeholder="0,00"
            />
          </div>

          <div className="flex justify-end gap-2 mt-6">
            <Button variant="outline" className="!w-auto" onClick={() => { setIsEditing(false); setUazapiToken(''); resetWebhookState(); setPanelInstances([]); }}>Cancelar</Button>
            <Button className="!w-auto" onClick={handleSave} isLoading={isSaving}>Salvar</Button>
          </div>
        </div>

        {/* ── Coluna direita: WhatsApp / uazapi ── */}
        <div className="w-80 flex-shrink-0 flex flex-col gap-3">

          {/* Header do painel */}
          <div className="bg-green-50 border border-green-200 rounded-xl px-4 py-3 flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-green-500 flex items-center justify-center flex-shrink-0">
              <svg className="w-4 h-4 text-white" fill="currentColor" viewBox="0 0 24 24">
                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
              </svg>
            </div>
            <div>
              <p className="text-sm font-bold text-green-900">WhatsApp / uazapi</p>
              <p className="text-[10px] text-green-700">Instâncias desta unidade</p>
            </div>
          </div>

          {/* Número WhatsApp principal */}
          <div className="bg-white border border-gray-200 rounded-xl px-4 py-3 space-y-1">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">Número Principal</p>
            <Input
              label=""
              value={current!.whatsappNumber || ''}
              onChange={(e) => update('whatsappNumber', formatPhone(e.target.value))}
              onKeyDown={handleEnterPress}
              maxLength={15}
              placeholder="(00) 00000-0000"
              containerClassName="!mb-0"
            />
          </div>

          {/* Instâncias existentes */}
          {isLoadingCreds ? (
            <div className="bg-white border border-gray-200 rounded-xl p-4 flex items-center justify-center gap-2 text-gray-400 text-xs">
              <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Carregando instâncias…
            </div>
          ) : panelInstances.length > 0 && (
            <div className="space-y-2">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wide px-1">Instâncias cadastradas</p>
              {panelInstances.map((inst, idx) => {
                const wOk = !!inst.webhookRegisteredAt && !inst.webhookLastError;
                return (
                  <div key={inst.credId || idx} className="bg-white border border-gray-200 rounded-xl p-3 space-y-2">
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex-1 min-w-0">
                        <p className="text-xs font-bold text-gray-800 truncate">{inst.label || inst.uazapiInstanceId || `Instância ${idx + 1}`}</p>
                        {inst.label && inst.uazapiInstanceId && (
                          <p className="text-[10px] text-gray-400 font-mono truncate">{inst.uazapiInstanceId}</p>
                        )}
                      </div>
                      <span className={`flex-shrink-0 text-[10px] font-bold px-2 py-0.5 rounded-full ${inst.hasToken ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                        {inst.hasToken ? '✓ Token' : 'Sem token'}
                      </span>
                    </div>
                    {inst.uazapiServerUrl && (
                      <p className="text-[10px] text-gray-500 font-mono bg-gray-50 rounded px-2 py-1 truncate" title={inst.uazapiServerUrl}>🖥 {inst.uazapiServerUrl}</p>
                    )}
                    {inst.webhookUrl && (
                      <div className="flex gap-1 items-center">
                        <input type="text" readOnly value={inst.webhookUrl}
                          className="flex-1 text-[10px] font-mono bg-gray-50 border border-gray-200 rounded px-2 py-1 text-gray-600 min-w-0"
                          onClick={e => (e.target as HTMLInputElement).select()} />
                        <button title="Copiar"
                          className={`flex-shrink-0 px-2 py-1 rounded text-[10px] border transition-colors ${copiedUrl === inst.webhookUrl ? 'bg-green-100 border-green-300 text-green-700' : 'bg-white border-gray-300 text-gray-600 hover:bg-gray-50'}`}
                          onClick={() => copyToClipboard(inst.webhookUrl!)}>
                          {copiedUrl === inst.webhookUrl ? '✓' : 'Copiar'}
                        </button>
                      </div>
                    )}
                    <div className={`flex items-start gap-1 rounded px-2 py-1 text-[10px] ${wOk ? 'bg-green-50 text-green-700' : inst.webhookLastError ? 'bg-amber-50 text-amber-700' : 'bg-gray-50 text-gray-500'}`}>
                      <span>{wOk ? '✓' : inst.webhookLastError ? '⚠' : '○'}</span>
                      <span className="min-w-0">
                        {wOk
                          ? `Registrado em ${new Date(inst.webhookRegisteredAt!).toLocaleString('pt-BR')}`
                          : inst.webhookLastError ? `Erro: ${inst.webhookLastError}` : 'Webhook não registrado'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Formulário de nova instância / edição */}
          <div className="bg-white border border-gray-200 rounded-xl p-4 space-y-3">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-wide">
              {panelInstances.length > 0 ? 'Editar / Nova Instância' : 'Configurar Instância uazapi'}
            </p>
            <div>
              <Input
                label="Nome da Instância uazapi"
                value={current!.uazapiInstanceId || ''}
                onChange={(e) => update('uazapiInstanceId', e.target.value.trim())}
                onKeyDown={handleEnterPress}
                placeholder="ex: MinhaEmpresa01"
                disabled={isLoadingCreds}
                containerClassName="!mb-0"
              />
              <p className="text-[10px] text-gray-400 mt-1">
                Nome exato criado no painel uazapi (não o UUID/token).
              </p>
            </div>
            {instanceId && (
              <>
                <div>
                  <Input
                    label={current!.uazapiHasToken ? 'Token (deixe em branco para manter)' : 'Token uazapi'}
                    type="password"
                    value={uazapiToken}
                    onChange={(e) => setUazapiToken(e.target.value)}
                    onKeyDown={handleEnterPress}
                    placeholder={current!.uazapiHasToken ? '••••••••••••••••' : 'Cole o token UUID'}
                    autoComplete="new-password"
                    containerClassName="!mb-0"
                  />
                  {current!.uazapiHasToken && (
                    <p className="text-[10px] text-green-600 mt-1">✓ Token salvo — preencha para substituir.</p>
                  )}
                </div>
                <div>
                  <Input
                    label="URL do Servidor uazapi (opcional)"
                    value={current!.uazapiServerUrl || ''}
                    onChange={(e) => update('uazapiServerUrl', e.target.value.trim())}
                    onKeyDown={handleEnterPress}
                    placeholder="https://free.uazapi.com"
                    containerClassName="!mb-0"
                  />
                  <p className="text-[10px] text-gray-400 mt-1">
                    Deixe em branco para usar <code>free.uazapi.com</code>.
                  </p>
                </div>

                {/* QR Code connect button */}
                {current?.id && current?.uazapiHasToken && instanceId && (() => {
                  const editInst = panelInstances.find(i => i.uazapiInstanceId === instanceId);
                  return (
                    <div className="space-y-1">
                      {editInst && !editInst.statusLoading && (
                        <div className="flex items-center gap-1.5">
                          <span className={`w-2 h-2 rounded-full flex-shrink-0 ${editInst.isConnected ? 'bg-green-500' : 'bg-red-400'}`} />
                          <span className={`text-[10px] font-semibold ${editInst.isConnected ? 'text-green-700' : 'text-red-600'}`}>
                            {editInst.isConnected ? `Conectado${editInst.connectedPhone ? ` · ${editInst.connectedPhone}` : ''}` : 'Desconectado'}
                          </span>
                        </div>
                      )}
                      <button
                        type="button"
                        className="w-full py-2 rounded-lg bg-green-600 text-white text-xs font-bold hover:bg-green-700 transition-colors flex items-center justify-center gap-1.5"
                        onClick={() => setQrModal({
                          unitId: current.id!,
                          instanceId,
                          label: editInst?.label ?? null,
                        })}
                      >
                        {editInst?.isConnected ? '🔄 Reconectar (novo QR Code)' : '📱 Conectar via QR Code'}
                      </button>
                    </div>
                  );
                })()}

                {/* Webhook status */}
                <div className="space-y-1.5">
                  {uazapiWebhookUrl ? (
                    <div className="rounded-lg border border-blue-200 bg-blue-50 px-3 py-2 space-y-2">
                      <p className="text-[10px] font-bold text-blue-800 uppercase tracking-wide">Webhook URL</p>
                      <div className="flex gap-1.5 items-center">
                        <input type="text" readOnly value={uazapiWebhookUrl}
                          className="flex-1 text-[10px] font-mono bg-white border border-blue-200 rounded px-2 py-1 text-gray-700 min-w-0"
                          onClick={e => (e.target as HTMLInputElement).select()} />
                        <button type="button" title="Copiar URL"
                          className="shrink-0 px-2 py-1 rounded border border-blue-300 bg-white text-blue-600 hover:bg-blue-100 text-[10px] transition-colors"
                          onClick={() => { navigator.clipboard.writeText(uazapiWebhookUrl); addToast('info', 'Copiado', 'URL do webhook copiada.'); }}>
                          Copiar
                        </button>
                      </div>
                      {!webhookReregisterResult && (webhookRegisteredAt || webhookLastError) && (
                        <div className={`text-[10px] rounded px-2 py-1 ${webhookRegisteredAt && !webhookLastError ? 'bg-green-50 text-green-700' : 'bg-amber-50 text-amber-700'}`}>
                          {webhookRegisteredAt && !webhookLastError
                            ? `✓ Registrado em ${new Date(webhookRegisteredAt).toLocaleString('pt-BR')}`
                            : `⚠ Último erro: ${webhookLastError}`}
                        </div>
                      )}
                      {webhookReregisterResult && (
                        <div className={`text-[10px] rounded px-2 py-1 ${webhookReregisterResult.ok ? 'bg-green-100 text-green-700' : 'bg-amber-100 text-amber-700'}`}>
                          {webhookReregisterResult.ok ? '✓ ' : '⚠ '}{webhookReregisterResult.msg}
                        </div>
                      )}
                      {current?.id && instanceId && (
                        <div className="flex gap-1.5">
                          <button type="button" disabled={isReregisteringWebhook}
                            className="text-[10px] px-3 py-1.5 rounded bg-blue-600 text-white hover:bg-blue-700 disabled:opacity-50 transition-colors font-medium flex-1"
                            onClick={handleReregisterWebhook}>
                            {isReregisteringWebhook ? 'Registrando…' : 'Re-registrar webhook'}
                          </button>
                          <button type="button"
                            className="text-[10px] px-3 py-1.5 rounded border border-blue-300 bg-white text-blue-700 hover:bg-blue-50 transition-colors font-medium"
                            title="Ver os últimos eventos recebidos pelo webhook"
                            onClick={handleOpenWebhookLog}>
                            Ver log
                          </button>
                        </div>
                      )}
                    </div>
                  ) : (
                    <p className="text-[10px] text-green-700 bg-green-50 rounded px-3 py-2">
                      ✓ Webhook configurado automaticamente ao salvar.
                    </p>
                  )}
                </div>
              </>
            )}
          </div>
        </div>

      </div>

      {/* Webhook event log modal */}
      {showWebhookLog && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/40 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl mx-4 overflow-hidden flex flex-col max-h-[80vh]">
            <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 flex-shrink-0">
              <div>
                <p className="font-bold text-gray-900 text-sm">Log de eventos do webhook uazapi</p>
                <p className="text-[10px] text-gray-500 mt-0.5">Últimos {webhookLogData.length} evento(s) recebidos nesta sessão do servidor</p>
              </div>
              <div className="flex gap-2 items-center">
                <button type="button"
                  className="text-[10px] px-2 py-1 rounded border border-gray-200 hover:bg-gray-50 text-gray-600"
                  onClick={handleOpenWebhookLog} disabled={webhookLogLoading}>
                  {webhookLogLoading ? 'Carregando…' : 'Atualizar'}
                </button>
                <button type="button" onClick={() => setShowWebhookLog(false)}
                  className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-400 hover:text-gray-600">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
            <div className="overflow-y-auto flex-1 p-4">
              {webhookLogLoading ? (
                <div className="flex justify-center py-8 text-gray-400 text-sm">Carregando…</div>
              ) : webhookLogData.length === 0 ? (
                <div className="text-center py-8 text-gray-500 text-sm space-y-2">
                  <p className="font-semibold">Nenhum evento recebido nesta sessão.</p>
                  <p className="text-xs text-gray-400">
                    Isso indica que o uazapi SaaS ainda não chamou o endpoint de webhook.<br/>
                    Verifique se a URL do webhook está configurada corretamente no painel uazapi.
                  </p>
                </div>
              ) : (
                <div className="space-y-2">
                  {webhookLogData.map((ev, i) => (
                    <div key={i} className={`rounded-lg border px-3 py-2 text-[11px] space-y-1 ${
                      ev.event === 'messages' || ev.event === 'message' ? 'border-green-200 bg-green-50' :
                      ev.event === 'messages_update' || ev.event === 'status' ? 'border-blue-200 bg-blue-50' :
                      'border-gray-200 bg-gray-50'
                    }`}>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className={`inline-flex px-1.5 py-0.5 rounded font-bold text-[10px] uppercase ${
                          ev.event === 'messages' || ev.event === 'message' ? 'bg-green-200 text-green-800' :
                          ev.event === 'messages_update' || ev.event === 'status' ? 'bg-blue-200 text-blue-800' :
                          'bg-gray-200 text-gray-700'
                        }`}>{ev.event || '(sem event)'}</span>
                        <span className="font-mono text-gray-600">{ev.instance}</span>
                        <span className="text-gray-400 ml-auto">{new Date(ev.ts).toLocaleTimeString('pt-BR')}</span>
                      </div>
                      <div className="text-gray-500">
                        <span className="font-medium">campos: </span>{ev.dataKeys}
                      </div>
                      <div className="font-mono text-gray-600 bg-white/60 rounded px-2 py-1 break-all leading-relaxed">
                        {ev.dataPreview}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            <div className="px-5 py-3 border-t border-gray-100 flex-shrink-0 bg-gray-50">
              <p className="text-[10px] text-gray-500">
                <strong>Eventos esperados:</strong> <code className="bg-gray-200 rounded px-1">messages</code> (nova mensagem) e <code className="bg-gray-200 rounded px-1">messages_update</code> (confirmação de entrega).
                Se a lista estiver vazia, configure a URL do webhook no painel uazapi.com apontando para este servidor.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* QR Code modal — edit view */}
      {qrModal && (
        <UazapiQrModal
          unitId={qrModal.unitId}
          instanceId={qrModal.instanceId}
          instanceLabel={qrModal.label}
          onClose={() => setQrModal(null)}
          onConnected={(phone) => {
            setQrModal(null);
            if (current?.id) loadUazapiCredentials(current.id);
            if (phone) addToast('success', 'WhatsApp conectado', `Número ${phone} vinculado com sucesso.`);
          }}
        />
      )}
    </div>
  );
};

export default UnitsTab;



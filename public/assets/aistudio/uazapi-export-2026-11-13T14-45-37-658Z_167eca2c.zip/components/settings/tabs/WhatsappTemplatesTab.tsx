import React, { useState, useEffect, useCallback } from 'react';
import { api } from '../../../services/apiService';
import Button from '../../ui/Button';
import Input from '../../ui/Input';

// ─── Shared types ────────────────────────────────────────────────────────────

interface WhatsappTemplate {
  id: string;
  name: string;
  area: string;
  templateText: string;
  variables: string[];
  active: boolean;
  createdAt?: string;
  updatedAt?: string;
}

// ─── Constants ───────────────────────────────────────────────────────────────

const AREAS: { value: string; label: string; color: string }[] = [
  { value: 'COBRANCA_COORD', label: 'Cobrança - Coordenador', color: 'bg-red-100 text-red-800 border-red-200' },
  { value: 'COBRANCA_OP',   label: 'Cobrança - Operacional', color: 'bg-orange-100 text-orange-800 border-orange-200' },
  { value: 'ADMISSAO',      label: 'Admissão',               color: 'bg-blue-100 text-blue-800 border-blue-200' },
  { value: 'JURIDICO',      label: 'Jurídico',               color: 'bg-purple-100 text-purple-800 border-purple-200' },
  { value: 'NEGOCIACAO',    label: 'Negociação',             color: 'bg-green-100 text-green-800 border-green-200' },
];

const AREA_VARIABLES: Record<string, string[]> = {
  COBRANCA_COORD: ['{{nome_cliente}}', '{{numero_contrato}}', '{{valor_divida}}', '{{data}}', '{{status}}'],
  COBRANCA_OP:   ['{{nome_cliente}}', '{{numero_contrato}}', '{{valor_divida}}', '{{data}}', '{{status}}'],
  ADMISSAO:      ['{{nome_cliente}}', '{{numero_contrato}}', '{{banco}}', '{{data}}', '{{status}}'],
  JURIDICO:      ['{{nome_cliente}}', '{{numero_processo}}', '{{tribunal}}', '{{data}}', '{{status}}'],
  NEGOCIACAO:    ['{{nome_cliente}}', '{{numero_contrato}}', '{{proposta}}', '{{data}}', '{{status}}'],
};

const BLANK_TEMPLATE: Omit<WhatsappTemplate, 'id' | 'createdAt' | 'updatedAt'> = {
  name: '',
  area: 'COBRANCA_COORD',
  templateText: '',
  variables: [],
  active: true,
};

// ─── Shared helpers ──────────────────────────────────────────────────────────

function getAreaColor(value: string) {
  return AREAS.find(a => a.value === value)?.color || 'bg-gray-100 text-gray-800 border-gray-200';
}

function VariablePreview({ text }: { text: string }) {
  if (!text) return <span className="text-gray-400 italic">Nenhum texto digitado ainda...</span>;
  const parts = text.split(/({{[^}]+}})/g);
  return (
    <span>
      {parts.map((part, i) =>
        /^{{[^}]+}}$/.test(part)
          ? <mark key={i} className="bg-yellow-200 text-yellow-900 rounded px-0.5 font-mono text-sm not-italic">{part}</mark>
          : <span key={i}>{part}</span>
      )}
    </span>
  );
}

// ─── Props ───────────────────────────────────────────────────────────────────

interface WhatsappTemplatesTabProps {
  addToast: (type: 'success' | 'error' | 'warning' | 'info', title: string, msg: string) => void;
}

// ─── Sub-tab: Internos ───────────────────────────────────────────────────────

const InternosTab: React.FC<WhatsappTemplatesTabProps> = ({ addToast }) => {
  const [templates, setTemplates] = useState<WhatsappTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [current, setCurrent] = useState<Partial<WhatsappTemplate> | null>(null);
  const [isNew, setIsNew] = useState(false);
  const [saving, setSaving] = useState(false);
  const [filterArea, setFilterArea] = useState<string>('ALL');

  const load = async () => {
    setLoading(true);
    try {
      const res = await api.get<{ data: WhatsappTemplate[] }>('/api/whatsapp-templates?limit=500&sortField=area&sortOrder=ASC');
      setTemplates(res.data || []);
    } catch {
      addToast('error', 'Erro', 'Não foi possível carregar os templates.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleNew = () => {
    setCurrent({ ...BLANK_TEMPLATE });
    setIsNew(true);
    setIsEditing(true);
  };

  const handleEdit = (tpl: WhatsappTemplate) => {
    setCurrent({ ...tpl });
    setIsNew(false);
    setIsEditing(true);
  };

  const handleCancel = () => {
    setIsEditing(false);
    setCurrent(null);
  };

  const handleSave = async () => {
    if (!current?.name?.trim() || !current?.area || !current?.templateText?.trim()) {
      addToast('warning', 'Validação', 'Nome, área e texto são obrigatórios.');
      return;
    }
    setSaving(true);
    try {
      const parsedVariables = Array.from(
        new Set((current.templateText || '').match(/{{[^}]+}}/g) || [])
      );
      const payload = {
        name: current.name,
        area: current.area,
        template_text: current.templateText,
        variables: parsedVariables,
        active: current.active !== false,
      };
      if (isNew) {
        const res = await api.post<{ data: WhatsappTemplate }>('/api/whatsapp-templates', payload);
        setTemplates(prev => [...prev, res.data]);
        addToast('success', 'Criado', 'Template criado com sucesso.');
      } else {
        const res = await api.put<{ data: WhatsappTemplate }>(`/api/whatsapp-templates/${current.id}`, payload);
        setTemplates(prev => prev.map(t => t.id === res.data.id ? res.data : t));
        addToast('success', 'Salvo', 'Template atualizado com sucesso.');
      }
      setIsEditing(false);
      setCurrent(null);
    } catch {
      addToast('error', 'Erro', 'Não foi possível salvar o template.');
    } finally {
      setSaving(false);
    }
  };

  const handleToggleActive = async (tpl: WhatsappTemplate) => {
    try {
      const res = await api.put<{ data: WhatsappTemplate }>(`/api/whatsapp-templates/${tpl.id}`, { active: !tpl.active });
      setTemplates(prev => prev.map(t => t.id === res.data.id ? res.data : t));
    } catch {
      addToast('error', 'Erro', 'Não foi possível atualizar o status.');
    }
  };

  const handleDelete = async (tpl: WhatsappTemplate) => {
    if (!window.confirm(`Excluir o template "${tpl.name}"?`)) return;
    try {
      await api.delete(`/api/whatsapp-templates/${tpl.id}`);
      setTemplates(prev => prev.filter(t => t.id !== tpl.id));
      addToast('success', 'Excluído', 'Template removido.');
    } catch {
      addToast('error', 'Erro', 'Não foi possível excluir o template.');
    }
  };

  const insertVariable = (variable: string) => {
    setCurrent(prev => prev ? { ...prev, templateText: (prev.templateText || '') + variable } : prev);
  };

  const filteredTemplates = filterArea === 'ALL'
    ? templates
    : templates.filter(t => t.area === filterArea);

  const groupedByArea = AREAS.map(area => ({
    ...area,
    items: filteredTemplates.filter(t => t.area === area.value),
  })).filter(group => group.items.length > 0);

  if (isEditing && current) {
    const suggestedVars = AREA_VARIABLES[current.area || 'COBRANCA_COORD'] || [];
    return (
      <div className="animate-fade-in flex flex-col gap-5 h-full" data-form-container="true">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-gray-800 text-lg">{isNew ? 'Novo Template' : 'Editar Template'}</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <Input
            label="Nome do Template"
            value={current.name || ''}
            onChange={e => setCurrent(p => p ? { ...p, name: e.target.value } : p)}
            placeholder="Ex: Lembrete de Vencimento"
          />
          <div>
            <label className="block text-xs font-bold text-gray-500 mb-1 uppercase">Área</label>
            <select
              value={current.area || 'COBRANCA_COORD'}
              onChange={e => setCurrent(p => p ? { ...p, area: e.target.value } : p)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none"
            >
              {AREAS.map(a => <option key={a.value} value={a.value}>{a.label}</option>)}
            </select>
          </div>
        </div>

        <div>
          <div
            onClick={() => setCurrent(p => p ? { ...p, active: !p.active } : p)}
            className="flex items-center gap-2 cursor-pointer select-none w-fit"
          >
            <div className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${current.active ? 'bg-moss-600' : 'bg-gray-300'}`}>
              <span className={`inline-block h-4 w-4 transform rounded-full bg-white shadow transition-transform ${current.active ? 'translate-x-6' : 'translate-x-1'}`} />
            </div>
            <span className="text-sm font-medium text-gray-700">{current.active ? 'Ativo' : 'Inativo'}</span>
          </div>
        </div>

        <div className="flex flex-col gap-2">
          <label className="block text-xs font-bold text-gray-500 uppercase">Variáveis disponíveis para esta área</label>
          <div className="flex flex-wrap gap-2">
            {suggestedVars.map(v => (
              <button
                key={v}
                onClick={() => insertVariable(v)}
                className="px-2 py-1 text-xs bg-yellow-100 text-yellow-900 border border-yellow-300 rounded hover:bg-yellow-200 font-mono transition-colors"
                title={`Clique para inserir ${v} no texto`}
              >
                {v}
              </button>
            ))}
          </div>
          <p className="text-xs text-gray-400">Clique em uma variável para inseri-la no texto.</p>
        </div>

        <div className="flex flex-col gap-2">
          <label className="block text-xs font-bold text-gray-500 uppercase">Texto do Template</label>
          <textarea
            value={current.templateText || ''}
            onChange={e => setCurrent(p => p ? { ...p, templateText: e.target.value } : p)}
            rows={5}
            placeholder="Ex: Olá {{nome_cliente}}, seu contrato {{numero_contrato}} está em aberto..."
            className="w-full border border-gray-300 rounded-lg px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none resize-y font-mono"
          />
        </div>

        <div className="bg-gray-50 border border-gray-200 rounded-lg p-4">
          <p className="text-xs font-bold text-gray-500 uppercase mb-2">Pré-visualização</p>
          <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">
            <VariablePreview text={current.templateText || ''} />
          </p>
        </div>

        <div className="flex justify-end gap-2 mt-auto pt-2">
          <Button variant="outline" className="!w-auto" onClick={handleCancel} disabled={saving}>Cancelar</Button>
          <Button className="!w-auto" onClick={handleSave} disabled={saving}>
            {saving ? 'Salvando...' : 'Salvar Template'}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5 animate-fade-in">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <p className="text-sm text-gray-500">Mensagens-modelo por área, com variáveis dinâmicas.</p>
        <Button variant="new" className="!w-auto" onClick={handleNew}>+ Novo Template</Button>
      </div>

      <div className="flex gap-2 flex-wrap border-b pb-3">
        <button
          onClick={() => setFilterArea('ALL')}
          className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors ${filterArea === 'ALL' ? 'bg-moss-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
        >
          Todas
        </button>
        {AREAS.map(a => (
          <button
            key={a.value}
            onClick={() => setFilterArea(a.value)}
            className={`px-3 py-1.5 rounded-full text-xs font-semibold transition-colors border ${filterArea === a.value ? a.color + ' border-current' : 'bg-gray-100 text-gray-600 border-transparent hover:bg-gray-200'}`}
          >
            {a.label}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="text-center py-12 text-gray-400">Carregando templates...</div>
      ) : filteredTemplates.length === 0 ? (
        <div className="text-center py-12 border border-dashed border-gray-200 rounded-lg">
          <p className="text-gray-400 text-sm">Nenhum template cadastrado.</p>
          <button onClick={handleNew} className="mt-3 text-sm text-moss-600 hover:text-moss-800 font-medium">Criar primeiro template</button>
        </div>
      ) : (
        <div className="space-y-6">
          {groupedByArea.map(group => (
            <div key={group.value}>
              <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-bold border mb-3 ${group.color}`}>
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                </svg>
                {group.label} ({group.items.length})
              </div>
              <div className="space-y-2">
                {group.items.map(tpl => (
                  <div key={tpl.id} className={`border rounded-lg p-4 transition-all hover:shadow-sm ${tpl.active ? 'border-gray-200 bg-white' : 'border-gray-100 bg-gray-50 opacity-60'}`}>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-semibold text-sm text-gray-900">{tpl.name}</span>
                          {!tpl.active && (
                            <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-gray-200 text-gray-600">Inativo</span>
                          )}
                        </div>
                        <p className="text-xs text-gray-500 leading-relaxed line-clamp-2 font-mono">
                          <VariablePreview text={tpl.templateText} />
                        </p>
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <button
                          onClick={() => handleToggleActive(tpl)}
                          title={tpl.active ? 'Desativar' : 'Ativar'}
                          className={`w-8 h-8 rounded-full flex items-center justify-center transition-colors ${tpl.active ? 'text-green-600 hover:bg-green-50' : 'text-gray-400 hover:bg-gray-100'}`}
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            {tpl.active
                              ? <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                              : <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 9v6m4-6v6m7-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                            }
                          </svg>
                        </button>
                        <button
                          onClick={() => handleEdit(tpl)}
                          title="Editar"
                          className="w-8 h-8 rounded-full flex items-center justify-center text-indigo-600 hover:bg-indigo-50 transition-colors"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                          </svg>
                        </button>
                        <button
                          onClick={() => handleDelete(tpl)}
                          title="Excluir"
                          className="w-8 h-8 rounded-full flex items-center justify-center text-red-600 hover:bg-red-50 transition-colors"
                        >
                          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                          </svg>
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

// ─── Sub-tab: Operadores GoTalk ──────────────────────────────────────────────

interface GotalkOperator {
  id: string;
  gotalk_operator_id: string;
  name: string;
  email: string | null;
  phone: string | null;
  active: boolean;
  collaborator_id: string | null;
  collaborator_name: string | null;
}

interface Collaborator {
  id: string;
  name: string;
}

const OperatorsTab: React.FC<WhatsappTemplatesTabProps> = ({ addToast }) => {
  const [operators, setOperators] = useState<GotalkOperator[]>([]);
  const [collaborators, setCollaborators] = useState<Collaborator[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [linkingId, setLinkingId] = useState<string | null>(null);
  const [selectedCollabMap, setSelectedCollabMap] = useState<Record<string, string>>({});

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [opRes, collabRes] = await Promise.all([
        api.get('/gotalk/operators'),
        api.get('/collaborators?limit=500'),
      ]);
      setOperators(opRes?.data || []);
      setCollaborators(Array.isArray(collabRes) ? collabRes : (collabRes?.data || []));
      const map: Record<string, string> = {};
      (opRes?.data || []).forEach((op: GotalkOperator) => {
        if (op.collaborator_id) map[op.id] = op.collaborator_id;
      });
      setSelectedCollabMap(map);
    } catch {
      addToast('error', 'Erro', 'Não foi possível carregar os operadores.');
    } finally {
      setLoading(false);
    }
  }, [addToast]);

  useEffect(() => { load(); }, [load]);

  const handleLink = async (operatorId: string) => {
    const collaboratorId = selectedCollabMap[operatorId];
    if (!collaboratorId) return;
    setSaving(operatorId);
    try {
      await api.post(`/gotalk/operators/${operatorId}/link-collaborator`, { collaboratorId });
      addToast('success', 'Vinculado', 'Operador vinculado ao colaborador com sucesso.');
      await load();
    } catch {
      addToast('error', 'Erro', 'Não foi possível vincular o operador.');
    } finally {
      setSaving(null);
      setLinkingId(null);
    }
  };

  const handleUnlink = async (operatorId: string) => {
    setSaving(operatorId);
    try {
      await api.post(`/gotalk/operators/${operatorId}/unlink-collaborator`, {});
      addToast('success', 'Desvinculado', 'Operador desvinculado com sucesso.');
      setSelectedCollabMap(prev => { const next = { ...prev }; delete next[operatorId]; return next; });
      await load();
    } catch {
      addToast('error', 'Erro', 'Não foi possível desvincular o operador.');
    } finally {
      setSaving(null);
    }
  };

  if (loading) return <div className="text-center py-12 text-gray-400">Carregando operadores...</div>;

  return (
    <div className="flex flex-col gap-5 animate-fade-in">
      <div className="flex items-start gap-3 bg-blue-50 border border-blue-200 rounded-lg p-4">
        <svg className="w-5 h-5 text-blue-500 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <p className="text-sm text-blue-700">
          Vincule os operadores do GoTalk aos colaboradores do CRM para que os atendimentos sejam filtráveis por atendente. Os operadores são sincronizados automaticamente a cada 30 minutos.
        </p>
      </div>

      {operators.length === 0 ? (
        <div className="text-center py-12 border border-dashed border-gray-200 rounded-lg">
          <p className="text-gray-400 text-sm">Nenhum operador GoTalk encontrado. Aguarde a sincronização automática.</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-lg border border-gray-200">
          <table className="min-w-full divide-y divide-gray-200 text-sm data-grid-typography">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Operador GoTalk</th>
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">E-mail / Telefone</th>
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Colaborador CRM</th>
                <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {operators.map(op => (
                <tr key={op.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-4 py-3 font-medium text-gray-900">{op.name || <span className="text-gray-400 italic">Sem nome</span>}</td>
                  <td className="px-4 py-3 text-gray-500">
                    {op.email && <div>{op.email}</div>}
                    {op.phone && <div className="text-xs">{op.phone}</div>}
                    {!op.email && !op.phone && <span className="text-gray-400">—</span>}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full border ${op.active ? 'bg-green-100 text-green-700 border-green-200' : 'bg-gray-100 text-gray-500 border-gray-200'}`}>
                      {op.active ? 'Ativo' : 'Inativo'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    {op.collaborator_id && linkingId !== op.id ? (
                      <span className="text-green-700 font-medium">{op.collaborator_name || op.collaborator_id}</span>
                    ) : (
                      <select
                        className="text-xs border border-gray-300 rounded px-2 py-1 focus:ring-1 focus:ring-moss-500 outline-none bg-white"
                        value={selectedCollabMap[op.id] || ''}
                        onChange={e => { setSelectedCollabMap(prev => ({ ...prev, [op.id]: e.target.value })); setLinkingId(op.id); }}
                      >
                        <option value="">— Selecionar colaborador —</option>
                        {collaborators.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                      </select>
                    )}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      {(!op.collaborator_id || linkingId === op.id) && selectedCollabMap[op.id] && (
                        <button
                          onClick={() => handleLink(op.id)}
                          disabled={saving === op.id}
                          className="text-xs px-2.5 py-1 bg-moss-600 text-white rounded hover:bg-moss-700 disabled:opacity-60 transition-colors"
                        >
                          {saving === op.id ? '...' : 'Vincular'}
                        </button>
                      )}
                      {op.collaborator_id && linkingId !== op.id && (
                        <>
                          <button
                            onClick={() => setLinkingId(op.id)}
                            className="text-xs px-2.5 py-1 bg-blue-50 text-blue-700 border border-blue-200 rounded hover:bg-blue-100 transition-colors"
                          >
                            Alterar
                          </button>
                          <button
                            onClick={() => handleUnlink(op.id)}
                            disabled={saving === op.id}
                            className="text-xs px-2.5 py-1 bg-red-50 text-red-600 border border-red-200 rounded hover:bg-red-100 disabled:opacity-60 transition-colors"
                          >
                            {saving === op.id ? '...' : 'Desvincular'}
                          </button>
                        </>
                      )}
                      {op.collaborator_id && linkingId === op.id && (
                        <button
                          onClick={() => setLinkingId(null)}
                          className="text-xs px-2.5 py-1 bg-gray-50 text-gray-600 border border-gray-200 rounded hover:bg-gray-100 transition-colors"
                        >
                          Cancelar
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

// ─── Main component ───────────────────────────────────────────────────────────

const WhatsappTemplatesTab: React.FC<WhatsappTemplatesTabProps> = ({ addToast }) => {
  const [activeTab, setActiveTab] = useState<'internos' | 'operadores'>('internos');

  return (
    <div className="flex flex-col gap-5 animate-fade-in">
      {/* Título + sub-tabs */}
      <div>
        <h3 className="text-lg font-bold text-gray-800">Templates WhatsApp</h3>

        <div className="flex gap-1 mt-3 border-b border-gray-200">
          <button
            onClick={() => setActiveTab('internos')}
            className={`px-4 py-2 text-sm font-semibold border-b-2 transition-colors -mb-px ${
              activeTab === 'internos'
                ? 'border-moss-600 text-moss-700'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Internos
          </button>
          <button
            onClick={() => setActiveTab('operadores')}
            className={`px-4 py-2 text-sm font-semibold border-b-2 transition-colors -mb-px ${
              activeTab === 'operadores'
                ? 'border-moss-600 text-moss-700'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Operadores
          </button>
        </div>
      </div>

      {/* Conteúdo */}
      {activeTab === 'internos' ? (
        <InternosTab addToast={addToast} />
      ) : (
        <OperatorsTab addToast={addToast} />
      )}
    </div>
  );
};

export default WhatsappTemplatesTab;

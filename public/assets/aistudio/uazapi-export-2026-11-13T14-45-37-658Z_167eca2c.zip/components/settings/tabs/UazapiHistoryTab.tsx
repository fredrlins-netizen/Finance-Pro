import React, { useState, useEffect, useCallback, useRef } from 'react';

interface UazapiMessage {
  id: string;
  message_id: string;
  instance_id: string | null;
  unit_id: string | null;
  unit_name: string | null;
  phone_number: string | null;
  direction: 'IN' | 'OUT';
  body: string | null;
  message_type: string;
  attachment_url: string | null;
  attachment_name: string | null;
  attachment_mime: string | null;
  ack_status: number | null;
  is_starred: boolean;
  is_forwarded: boolean;
  quoted_body: string | null;
  reaction: string | null;
  sent_at: string | null;
  imported_at: string;
}

interface ImportStatus {
  running: boolean;
  startedAt?: string;
  totalChats?: number;
  processedChats?: number;
  inserted?: number;
  lastError?: string | null;
}

const PAGE_SIZE = 50;

function fmtDate(iso: string | null): string {
  if (!iso) return '—';
  const d = new Date(iso);
  return d.toLocaleDateString('pt-BR') + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function msgTypeIcon(t: string) {
  const map: Record<string, string> = {
    IMAGE: '🖼️', VIDEO: '🎥', AUDIO: '🎵', DOCUMENT: '📄', STICKER: '🎭',
  };
  return map[String(t).toUpperCase()] || '💬';
}

const UazapiHistoryTab: React.FC = () => {
  const [messages, setMessages] = useState<UazapiMessage[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(0);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [filterPhone, setFilterPhone] = useState('');
  const [filterDirection, setFilterDirection] = useState('');
  const [filterInstance, setFilterInstance] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');

  const [importStatus, setImportStatus] = useState<ImportStatus>({ running: false });
  const [importError, setImportError] = useState<string | null>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchMessages = useCallback(async (pg = 1) => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({ page: String(pg), limit: String(PAGE_SIZE) });
      if (filterPhone.trim()) params.set('phone', filterPhone.trim());
      if (filterDirection) params.set('direction', filterDirection);
      if (filterInstance.trim()) params.set('instanceId', filterInstance.trim());
      if (filterDateFrom) params.set('dateFrom', filterDateFrom);
      if (filterDateTo) params.set('dateTo', filterDateTo);
      const res = await fetch(`/api/uazapi/messages?${params}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setMessages(data.messages || []);
      setTotal(data.total || 0);
      setPages(data.pages || 0);
      setPage(pg);
    } catch (e: any) {
      setError(e.message || 'Erro ao carregar mensagens.');
    } finally {
      setLoading(false);
    }
  }, [filterPhone, filterDirection, filterInstance, filterDateFrom, filterDateTo]);

  const fetchImportStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/uazapi/import-status');
      if (!res.ok) return;
      const data: ImportStatus = await res.json();
      setImportStatus(data);
      if (!data.running && pollRef.current) {
        clearInterval(pollRef.current);
        pollRef.current = null;
        fetchMessages(1);
      }
    } catch { /* non-fatal */ }
  }, [fetchMessages]);

  useEffect(() => {
    fetchMessages(1);
    fetchImportStatus();
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, []);

  const startImport = async () => {
    setImportError(null);
    try {
      const res = await fetch('/api/uazapi/import-all', { method: 'POST', headers: { 'Content-Type': 'application/json' } });
      const data = await res.json();
      if (!res.ok) {
        if (res.status === 409) {
          setImportStatus(data.status || { running: true });
        } else {
          setImportError(data.error || 'Erro ao iniciar importação.');
          return;
        }
      } else {
        setImportStatus(data.status || { running: true });
      }
      if (pollRef.current) clearInterval(pollRef.current);
      pollRef.current = setInterval(fetchImportStatus, 2000);
    } catch (e: any) {
      setImportError(e.message || 'Erro ao iniciar importação.');
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    fetchMessages(1);
  };

  const progressPct = importStatus.totalChats && importStatus.totalChats > 0
    ? Math.round((importStatus.processedChats || 0) / importStatus.totalChats * 100)
    : null;

  return (
    <div className="flex flex-col gap-5 animate-fade-in">
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h2 className="text-base font-semibold text-gray-800">Histórico de Mensagens uazapi</h2>
          <p className="text-xs text-gray-500 mt-0.5">
            Tabela dedicada com todo o histórico importado da instância uazapi.
            Use o botão abaixo para importar todo o histórico disponível.
          </p>
        </div>
        <div className="flex flex-col items-end gap-2">
          <button
            onClick={startImport}
            disabled={importStatus.running}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
              importStatus.running
                ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                : 'bg-moss-700 hover:bg-moss-800 text-white'
            }`}
          >
            {importStatus.running ? (
              <>
                <svg className="w-4 h-4 animate-spin" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Importando...
              </>
            ) : (
              <>
                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                </svg>
                Importar Histórico Completo
              </>
            )}
          </button>
          {importError && <p className="text-xs text-red-600">{importError}</p>}
        </div>
      </div>

      {importStatus.running && (
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium text-blue-800">Importação em andamento</span>
            <span className="text-xs text-blue-600">
              {importStatus.processedChats ?? 0} / {importStatus.totalChats ?? '?'} chats
              {' · '}
              {importStatus.inserted ?? 0} mensagens inseridas
            </span>
          </div>
          {progressPct !== null && (
            <div className="w-full bg-blue-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all"
                style={{ width: `${progressPct}%` }}
              />
            </div>
          )}
          {importStatus.lastError && (
            <p className="text-xs text-red-600 mt-1">{importStatus.lastError}</p>
          )}
        </div>
      )}

      {!importStatus.running && importStatus.startedAt && importStatus.inserted !== undefined && (
        <div className="p-3 bg-green-50 border border-green-200 rounded-lg flex items-center justify-between">
          <span className="text-sm text-green-800">
            Última importação concluída em {fmtDate(importStatus.startedAt)} — {importStatus.inserted} mensagens inseridas
          </span>
          {importStatus.lastError && (
            <span className="text-xs text-orange-600 ml-2">Aviso: {importStatus.lastError}</span>
          )}
        </div>
      )}

      <form onSubmit={handleSearch} className="p-4 bg-gray-50 border border-gray-200 rounded-lg grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-600">Número</label>
          <input
            type="text"
            value={filterPhone}
            onChange={e => setFilterPhone(e.target.value)}
            placeholder="Ex: 11999..."
            className="border border-gray-300 rounded px-3 py-1.5 text-sm focus:ring-1 focus:ring-moss-500 outline-none"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-600">Direção</label>
          <select
            value={filterDirection}
            onChange={e => setFilterDirection(e.target.value)}
            className="border border-gray-300 rounded px-3 py-1.5 text-sm focus:ring-1 focus:ring-moss-500 outline-none bg-white"
          >
            <option value="">Todas</option>
            <option value="IN">Recebidas</option>
            <option value="OUT">Enviadas</option>
          </select>
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-600">Instância</label>
          <input
            type="text"
            value={filterInstance}
            onChange={e => setFilterInstance(e.target.value)}
            placeholder="ID da instância"
            className="border border-gray-300 rounded px-3 py-1.5 text-sm focus:ring-1 focus:ring-moss-500 outline-none"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-600">De</label>
          <input
            type="date"
            value={filterDateFrom}
            onChange={e => setFilterDateFrom(e.target.value)}
            className="border border-gray-300 rounded px-3 py-1.5 text-sm focus:ring-1 focus:ring-moss-500 outline-none"
          />
        </div>
        <div className="flex flex-col gap-1">
          <label className="text-xs font-medium text-gray-600">Até</label>
          <input
            type="date"
            value={filterDateTo}
            onChange={e => setFilterDateTo(e.target.value)}
            className="border border-gray-300 rounded px-3 py-1.5 text-sm focus:ring-1 focus:ring-moss-500 outline-none"
          />
        </div>
        <div className="flex items-end gap-2 col-span-2 md:col-span-3 lg:col-span-5">
          <button
            type="submit"
            className="px-4 py-1.5 bg-moss-700 hover:bg-moss-800 text-white rounded text-sm font-medium transition-colors"
          >
            Filtrar
          </button>
          <button
            type="button"
            onClick={() => {
              setFilterPhone('');
              setFilterDirection('');
              setFilterInstance('');
              setFilterDateFrom('');
              setFilterDateTo('');
              setTimeout(() => fetchMessages(1), 0);
            }}
            className="px-4 py-1.5 bg-gray-200 hover:bg-gray-300 text-gray-700 rounded text-sm font-medium transition-colors"
          >
            Limpar
          </button>
          {total > 0 && (
            <span className="ml-auto text-xs text-gray-500 self-end">
              {total.toLocaleString('pt-BR')} mensagem{total !== 1 ? 's' : ''} encontrada{total !== 1 ? 's' : ''}
            </span>
          )}
        </div>
      </form>

      {error && (
        <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">{error}</div>
      )}

      <div className="border border-gray-200 rounded-lg overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm data-grid-typography">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase">Data/Hora</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase">Número</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase">Dir.</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase">Tipo</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase min-w-[200px]">Mensagem</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase">Unidade</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase">Instância</th>
                <th className="px-3 py-2.5 text-left text-xs font-semibold text-gray-600 uppercase">Importado em</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {loading && (
                <tr>
                  <td colSpan={8} className="px-4 py-8 text-center text-gray-400 text-sm">
                    <svg className="w-5 h-5 animate-spin mx-auto mb-2" viewBox="0 0 24 24" fill="none" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                    </svg>
                    Carregando...
                  </td>
                </tr>
              )}
              {!loading && messages.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-10 text-center text-gray-400 text-sm">
                    <p className="font-medium">Nenhuma mensagem encontrada</p>
                    <p className="text-xs mt-1">Clique em "Importar Histórico Completo" para carregar as mensagens da uazapi.</p>
                  </td>
                </tr>
              )}
              {!loading && messages.map(msg => (
                <tr key={msg.id} className="hover:bg-gray-50 transition-colors">
                  <td className="px-3 py-2 text-xs text-gray-600 whitespace-nowrap">{fmtDate(msg.sent_at)}</td>
                  <td className="px-3 py-2 text-xs font-mono text-gray-800">{msg.phone_number || '—'}</td>
                  <td className="px-3 py-2">
                    <span className={`inline-flex items-center px-1.5 py-0.5 rounded text-xs font-medium ${
                      msg.direction === 'IN'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-blue-100 text-blue-700'
                    }`}>
                      {msg.direction === 'IN' ? '↓ Rec.' : '↑ Env.'}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-sm" title={msg.message_type}>
                    {msgTypeIcon(msg.message_type)}
                  </td>
                  <td className="px-3 py-2 max-w-xs">
                    {msg.body ? (
                      <p className="text-xs text-gray-700 truncate" title={msg.body}>{msg.body}</p>
                    ) : msg.attachment_name ? (
                      <p className="text-xs text-gray-500 italic truncate">{msg.attachment_name}</p>
                    ) : (
                      <span className="text-xs text-gray-400">—</span>
                    )}
                    {msg.is_forwarded && <span className="ml-1 text-xs text-orange-500" title="Encaminhada">↪</span>}
                    {msg.is_starred && <span className="ml-1 text-xs text-yellow-500" title="Com estrela">★</span>}
                    {msg.reaction && <span className="ml-1 text-xs" title={`Reação: ${msg.reaction}`}>{msg.reaction}</span>}
                  </td>
                  <td className="px-3 py-2 text-xs text-gray-600 truncate max-w-[130px]" title={msg.unit_name || msg.unit_id || ''}>
                    {msg.unit_name || '—'}
                  </td>
                  <td className="px-3 py-2 text-xs text-gray-500 truncate max-w-[120px]" title={msg.instance_id || ''}>
                    {msg.instance_id || '—'}
                  </td>
                  <td className="px-3 py-2 text-xs text-gray-400 whitespace-nowrap">{fmtDate(msg.imported_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {pages > 1 && (
        <div className="flex items-center justify-between">
          <button
            onClick={() => fetchMessages(page - 1)}
            disabled={page <= 1 || loading}
            className="px-3 py-1.5 text-sm border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            ← Anterior
          </button>
          <span className="text-xs text-gray-500">
            Página {page} de {pages}
          </span>
          <button
            onClick={() => fetchMessages(page + 1)}
            disabled={page >= pages || loading}
            className="px-3 py-1.5 text-sm border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
          >
            Próxima →
          </button>
        </div>
      )}
    </div>
  );
};

export default UazapiHistoryTab;

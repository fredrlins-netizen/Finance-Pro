import React, { useEffect, useRef, useState, useCallback } from 'react';

interface UazapiQrModalProps {
  unitId: string;
  instanceId: string;
  instanceLabel?: string | null;
  onClose: () => void;
  onConnected: (phone: string | null) => void;
}

type ModalState = 'loading' | 'qr' | 'connected' | 'error';

const POLL_INTERVAL_MS = 5000;

const UazapiQrModal: React.FC<UazapiQrModalProps> = ({
  unitId,
  instanceId,
  instanceLabel,
  onClose,
  onConnected,
}) => {
  const [modalState, setModalState] = useState<ModalState>('loading');
  const [qrDataUrl, setQrDataUrl] = useState<string | null>(null);
  const [pairingCode, setPairingCode] = useState<string | null>(null);
  const [connectedPhone, setConnectedPhone] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [secondsLeft, setSecondsLeft] = useState(POLL_INTERVAL_MS / 1000);

  const pollTimerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const isMounted = useRef(true);

  const clearTimers = () => {
    if (pollTimerRef.current) clearInterval(pollTimerRef.current);
    if (countdownRef.current) clearInterval(countdownRef.current);
  };

  const buildQrDataUrl = useCallback(async (qrString: string): Promise<string | null> => {
    try {
      const QRCode = (await import('qrcode')).default;
      return await QRCode.toDataURL(qrString, {
        width: 260,
        margin: 2,
        color: { dark: '#000000', light: '#ffffff' },
      });
    } catch {
      return null;
    }
  }, []);

  const resolveQr = useCallback(async (qrString: string | null, qrBase64: string | null) => {
    if (qrBase64) {
      const src = qrBase64.startsWith('data:') ? qrBase64 : `data:image/png;base64,${qrBase64}`;
      setQrDataUrl(src);
      return;
    }
    if (qrString) {
      const url = await buildQrDataUrl(qrString);
      setQrDataUrl(url);
    }
  }, [buildQrDataUrl]);

  const startPolling = useCallback(() => {
    clearTimers();
    setSecondsLeft(POLL_INTERVAL_MS / 1000);

    const poll = async () => {
      if (!isMounted.current) return;
      try {
        const params = new URLSearchParams({ unitId, instanceId });
        const r = await fetch(`/api/uazapi/instance-qr-status?${params}`);
        const d = await r.json().catch(() => ({}));

        if (!isMounted.current) return;

        if (d.isConnected) {
          clearTimers();
          const phone = d.phone || null;
          setConnectedPhone(phone);
          setModalState('connected');
          // Auto-close after 1.5 s — user sees brief success confirmation
          setTimeout(() => {
            if (isMounted.current) {
              onConnected(phone);
              onClose();
            }
          }, 1500);
          return;
        }

        if (d.qrString || d.qrBase64) {
          await resolveQr(d.qrString, d.qrBase64);
        }
      } catch { /* silent — keep polling */ }
    };

    pollTimerRef.current = setInterval(poll, POLL_INTERVAL_MS);

    countdownRef.current = setInterval(() => {
      if (!isMounted.current) return;
      setSecondsLeft(s => {
        if (s <= 1) return POLL_INTERVAL_MS / 1000;
        return s - 1;
      });
    }, 1000);
  }, [unitId, instanceId, resolveQr]);

  const initConnect = useCallback(async () => {
    if (!isMounted.current) return;
    setModalState('loading');
    setQrDataUrl(null);
    setPairingCode(null);
    setErrorMsg(null);

    try {
      const r = await fetch('/api/uazapi/instance-connect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ unitId, instanceId }),
      });
      const d = await r.json().catch(() => ({}));

      if (!isMounted.current) return;

      if (!r.ok) {
        setErrorMsg(d.error || `Erro ${r.status} ao iniciar conexão.`);
        setModalState('error');
        return;
      }

      // Instance already connected — show success immediately
      if (d.alreadyConnected) {
        const phone = d.phone || null;
        setConnectedPhone(phone);
        setModalState('connected');
        setTimeout(() => {
          if (isMounted.current) {
            onConnected(phone);
            onClose();
          }
        }, 2000);
        return;
      }

      if (d.pairingCode) setPairingCode(d.pairingCode);

      if (d.qrString || d.qrBase64) {
        await resolveQr(d.qrString, d.qrBase64);
        setModalState('qr');
      } else {
        setModalState('qr');
      }

      startPolling();
    } catch (err) {
      if (!isMounted.current) return;
      setErrorMsg(err instanceof Error ? err.message : 'Erro de rede.');
      setModalState('error');
    }
  }, [unitId, instanceId, resolveQr, startPolling]);

  useEffect(() => {
    isMounted.current = true;
    initConnect();
    return () => {
      isMounted.current = false;
      clearTimers();
    };
  }, [initConnect]);

  const handleConnectedClose = () => {
    onConnected(connectedPhone);
    onClose();
  };

  const displayName = instanceLabel || instanceId;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm mx-4 overflow-hidden">

        {/* Header */}
        <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100">
          <div className="w-8 h-8 rounded-lg bg-green-500 flex items-center justify-center flex-shrink-0">
            <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
            </svg>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-bold text-gray-900">Conectar ao WhatsApp</p>
            <p className="text-xs text-gray-500 truncate">{displayName}</p>
          </div>
          {modalState !== 'connected' && (
            <button
              onClick={onClose}
              className="text-gray-400 hover:text-gray-600 transition-colors p-1 rounded-lg hover:bg-gray-100"
              title="Fechar"
            >
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          )}
        </div>

        {/* Body */}
        <div className="px-5 py-5">

          {/* LOADING */}
          {modalState === 'loading' && (
            <div className="flex flex-col items-center gap-4 py-6">
              <svg className="animate-spin w-10 h-10 text-green-500" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              <p className="text-sm text-gray-500">Gerando QR code…</p>
            </div>
          )}

          {/* QR CODE */}
          {modalState === 'qr' && (
            <div className="flex flex-col items-center gap-4">
              {/* Instance being connected */}
              <div className="w-full rounded-lg bg-amber-50 border border-amber-200 px-3 py-2 text-center">
                <p className="text-[10px] text-amber-600 font-semibold uppercase tracking-wide mb-0.5">Instância a conectar</p>
                <p className="text-sm font-bold text-amber-900 truncate">{displayName}</p>
              </div>
              <p className="text-xs text-center text-gray-500 leading-relaxed">
                Abra o <strong>WhatsApp</strong> no celular, vá em{' '}
                <strong>Dispositivos Vinculados → Vincular Dispositivo</strong> e escaneie o código abaixo.
              </p>

              {/* QR image area */}
              <div className="relative w-[200px] h-[200px] flex items-center justify-center bg-gray-50 rounded-xl border-2 border-gray-200">
                {qrDataUrl ? (
                  <img
                    src={qrDataUrl}
                    alt="QR Code WhatsApp"
                    className="w-full h-full rounded-xl object-contain"
                  />
                ) : (
                  <div className="flex flex-col items-center gap-2 text-gray-400">
                    <svg className="animate-spin w-6 h-6" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                    </svg>
                    <p className="text-[10px]">Aguardando QR…</p>
                  </div>
                )}
              </div>

              {/* Pairing code (alternative) */}
              {pairingCode && (
                <div className="w-full rounded-lg bg-blue-50 border border-blue-200 px-3 py-2 text-center">
                  <p className="text-[10px] text-blue-600 font-semibold uppercase tracking-wide mb-1">Código de Pareamento</p>
                  <p className="text-lg font-mono font-bold text-blue-800 tracking-widest">{pairingCode}</p>
                </div>
              )}

              {/* Poll countdown */}
              <div className="flex items-center gap-2 text-[11px] text-gray-400">
                <svg className="animate-spin w-3 h-3" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
                Verificando conexão em {secondsLeft}s…
              </div>

              {/* Retry button */}
              <button
                onClick={initConnect}
                className="text-[11px] text-moss-600 hover:text-moss-800 underline font-medium"
              >
                Gerar novo QR code
              </button>
            </div>
          )}

          {/* CONNECTED */}
          {modalState === 'connected' && (
            <div className="flex flex-col items-center gap-4 py-4">
              <div className="w-16 h-16 rounded-full bg-green-100 flex items-center justify-center">
                <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <div className="text-center space-y-1">
                <p className="text-base font-bold text-gray-900">WhatsApp conectado!</p>
                {connectedPhone && (
                  <p className="text-sm text-green-700 font-semibold font-mono">{connectedPhone}</p>
                )}
                <p className="text-xs text-gray-500">
                  O webhook foi registrado automaticamente. Esta instância está pronta para enviar e receber mensagens.
                </p>
              </div>
              <button
                onClick={handleConnectedClose}
                className="w-full py-2.5 rounded-xl bg-green-600 text-white text-sm font-bold hover:bg-green-700 transition-colors"
              >
                Concluir
              </button>
            </div>
          )}

          {/* ERROR */}
          {modalState === 'error' && (
            <div className="flex flex-col items-center gap-4 py-4">
              <div className="w-14 h-14 rounded-full bg-red-100 flex items-center justify-center">
                <svg className="w-7 h-7 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </div>
              <div className="text-center space-y-1">
                <p className="text-sm font-bold text-gray-800">Não foi possível conectar</p>
                <p className="text-xs text-red-600">{errorMsg || 'Erro desconhecido.'}</p>
                {(errorMsg?.toLowerCase().includes('token') || errorMsg?.toLowerCase().includes('invalid')) ? (
                  <p className="text-xs text-gray-500 mt-1">
                    Token inválido ou expirado. Acesse <strong>Editar → WhatsApp / uazapi</strong> para atualizar as credenciais desta instância.
                  </p>
                ) : (
                  <p className="text-xs text-gray-400">Verifique se o token e o servidor uazapi estão corretos.</p>
                )}
              </div>
              <div className="flex gap-2 w-full">
                <button
                  onClick={onClose}
                  className="flex-1 py-2 rounded-xl border border-gray-200 text-sm text-gray-600 hover:bg-gray-50 transition-colors"
                >
                  Fechar
                </button>
                <button
                  onClick={initConnect}
                  className="flex-1 py-2 rounded-xl bg-green-600 text-white text-sm font-bold hover:bg-green-700 transition-colors"
                >
                  Tentar novamente
                </button>
              </div>
            </div>
          )}

        </div>
      </div>
    </div>
  );
};

export default UazapiQrModal;

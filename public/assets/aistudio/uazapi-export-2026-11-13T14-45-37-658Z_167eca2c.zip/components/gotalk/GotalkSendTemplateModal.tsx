import React, { useState, useEffect, useCallback, useRef } from 'react';

interface Channel {
  id: string;
  name: string;
  phone_number: string | null;
  is_primary: boolean;
  is_active: boolean;
}

interface Template {
  id: string;
  template_name: string;
  gotalk_template_id: string;
  category: string | null;
  language: string | null;
  status: string | null;
  body_text: string | null;
  header_text: string | null;
  footer_text: string | null;
  gotalk_channel_uuid: string | null;
}

interface Props {
  isOpen: boolean;
  onClose: () => void;
  contactPhone: string;
  contactName: string;
  onSuccess?: () => void;
  onError?: (msg: string) => void;
  // Task #311: quando 'uazapi', o template é renderizado e enviado como TEXTO
  // via uazapi (onUazapiSend) em vez do disparo nativo HSM do GoTalk.
  mode?: 'gotalk' | 'uazapi';
  onUazapiSend?: (renderedBody: string, templateName: string) => Promise<void>;
}

function parseVariables(text: string | null | undefined): number[] {
  if (!text) return [];
  const matches = text.match(/\{\{(\d+)\}\}/g) || [];
  const nums = matches.map(m => parseInt(m.replace(/\{\{|\}\}/g, ''), 10));
  return Array.from(new Set(nums)).sort((a, b) => a - b);
}

function applyVariables(text: string | null | undefined, vars: Record<number, string>): string {
  if (!text) return '';
  return text.replace(/\{\{(\d+)\}\}/g, (_, n) => vars[parseInt(n, 10)] || `{{${n}}}`);
}

const GotalkSendTemplateModal: React.FC<Props> = ({ isOpen, onClose, contactPhone, contactName, onSuccess, onError, mode = 'gotalk', onUazapiSend }) => {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedChannelUuid, setSelectedChannelUuid] = useState<string>('');
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [variables, setVariables] = useState<Record<number, string>>({});
  const [loadingChannels, setLoadingChannels] = useState(false);
  const [loadingTemplates, setLoadingTemplates] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  const fetchChannels = useCallback(async () => {
    setLoadingChannels(true);
    try {
      const res = await fetch('/api/gotalk/channels');
      if (!res.ok) return;
      const data = await res.json();
      const active = (data.channels || []).filter((c: Channel) => c.is_active);
      setChannels(active);
      const primary = active.find((c: Channel) => c.is_primary);
      if (primary) setSelectedChannelUuid(primary.id);
      else if (active.length > 0) setSelectedChannelUuid(active[0].id);
    } catch {}
    finally { setLoadingChannels(false); }
  }, []);

  const fetchTemplates = useCallback(async (channelUuid: string) => {
    if (!channelUuid) { setTemplates([]); return; }
    setLoadingTemplates(true);
    setSelectedTemplate(null);
    setVariables({});
    try {
      const res = await fetch(`/api/gotalk/hsm-templates?channelUuid=${encodeURIComponent(channelUuid)}`);
      if (!res.ok) return;
      const data = await res.json();
      const approved = (data.templates || []).filter((t: Template) => !t.status || t.status.toLowerCase() === 'approved' || t.status.toLowerCase() === 'ativo' || t.status.toLowerCase() === 'active');
      setTemplates(approved.length > 0 ? approved : (data.templates || []));
    } catch {}
    finally { setLoadingTemplates(false); }
  }, []);

  useEffect(() => {
    if (isOpen) {
      setError('');
      setSuccess(false);
      setSending(false);
      fetchChannels();
    }
  }, [isOpen, fetchChannels]);

  useEffect(() => {
    if (selectedChannelUuid) fetchTemplates(selectedChannelUuid);
  }, [selectedChannelUuid, fetchTemplates]);

  const handleSelectTemplate = (t: Template) => {
    setSelectedTemplate(t);
    setVariables({});
    setError('');
  };

  const varNums = parseVariables(selectedTemplate?.body_text);
  const hasVariables = varNums.length > 0;

  const canSend = !!selectedChannelUuid && !!selectedTemplate && (!hasVariables || varNums.every(n => (variables[n] || '').trim().length > 0));

  const handleSend = async () => {
    if (!canSend || sending || success) return;
    setSending(true);
    setError('');
    try {
      // Task #311 — canal uazapi: renderiza o template e envia como texto puro.
      if (mode === 'uazapi') {
        const parts = [
          applyVariables(selectedTemplate!.header_text, variables),
          applyVariables(selectedTemplate!.body_text, variables),
          selectedTemplate!.footer_text || '',
        ].filter(p => p && p.trim().length > 0);
        const renderedBody = parts.join('\n\n');
        if (!onUazapiSend) throw new Error('Envio via uazapi indisponível.');
        await onUazapiSend(renderedBody, selectedTemplate!.template_name);
        setSuccess(true);
        onSuccess?.();
        setTimeout(() => { setSuccess(false); onClose(); }, 2000);
        return;
      }

      const tag: Record<string, string> = {};
      varNums.forEach(n => { tag[String(n)] = variables[n] || ''; });

      const body: Record<string, unknown> = {
        channelUuid: selectedChannelUuid,
        phone: contactPhone,
        contactName: contactName || 'Contato',
        templateId: selectedTemplate!.gotalk_template_id,
      };
      if (Object.keys(tag).length > 0) body.tag = tag;

      const res = await fetch('/api/gotalk/send-active-notification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      const data = await res.json();
      if (!res.ok) {
        const errMsg = data.error || data.message || 'Erro ao enviar template.';
        setError(errMsg);
        onError?.(errMsg);
        return;
      }
      setSuccess(true);
      onSuccess?.();
      setTimeout(() => {
        setSuccess(false);
        onClose();
      }, 2000);
    } catch (e: unknown) {
      const errMsg = e instanceof Error ? e.message : 'Erro de conexão.';
      setError(errMsg);
      onError?.(errMsg);
    } finally {
      setSending(false);
    }
  };

  // Atalho Ctrl/⌘+Enter. Usa um ref para sempre chamar a versão atual de
  // handleSend (que já valida canSend/sending/success), evitando closure stale
  // sem precisar recriar o listener a cada render.
  const handleSendRef = useRef(handleSend);
  handleSendRef.current = handleSend;
  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        handleSendRef.current();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen]);

  if (!isOpen) return null;

  const preview = selectedTemplate
    ? {
        header: applyVariables(selectedTemplate.header_text, variables),
        body: applyVariables(selectedTemplate.body_text, variables),
        footer: selectedTemplate.footer_text || '',
      }
    : null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div
        className="bg-white rounded-2xl shadow-2xl w-full max-w-lg max-h-[90vh] flex flex-col overflow-hidden"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center justify-between px-5 py-4 bg-green-700 text-white flex-shrink-0">
          <div>
            <h3 className="font-bold text-sm">Enviar Template HSM</h3>
            <p className="text-[11px] text-green-100 mt-0.5 truncate">
              Para: {contactName || 'Contato'} · {contactPhone}
            </p>
          </div>
          <button onClick={onClose} className="text-white/70 hover:text-white transition-colors">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {success ? (
            <div className="flex flex-col items-center justify-center py-10 text-center">
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-3">
                <svg className="w-6 h-6 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <p className="text-sm font-semibold text-gray-800">Template enviado com sucesso!</p>
              <p className="text-xs text-gray-500 mt-1">A janela fechará automaticamente.</p>
            </div>
          ) : (
            <>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Canal WhatsApp</label>
                {loadingChannels ? (
                  <div className="h-9 bg-gray-100 rounded-lg animate-pulse" />
                ) : channels.length === 0 ? (
                  <p className="text-xs text-red-500">Nenhum canal ativo encontrado. Configure um canal GoTalk primeiro.</p>
                ) : (
                  <select
                    value={selectedChannelUuid}
                    onChange={e => setSelectedChannelUuid(e.target.value)}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                  >
                    <option value="">Selecionar canal...</option>
                    {channels.map(c => (
                      <option key={c.id} value={c.id}>
                        {c.name}{c.phone_number ? ` (${c.phone_number})` : ''}{c.is_primary ? ' ★' : ''}
                      </option>
                    ))}
                  </select>
                )}
              </div>

              {selectedChannelUuid && (
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Template</label>
                  {loadingTemplates ? (
                    <div className="h-9 bg-gray-100 rounded-lg animate-pulse" />
                  ) : templates.length === 0 ? (
                    <p className="text-xs text-amber-600">Nenhum template encontrado para este canal. Sincronize os templates primeiro.</p>
                  ) : (
                    <select
                      value={selectedTemplate?.id || ''}
                      onChange={e => {
                        const t = templates.find(t => t.id === e.target.value) || null;
                        if (t) handleSelectTemplate(t);
                      }}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                    >
                      <option value="">Selecionar template...</option>
                      {templates.map(t => (
                        <option key={t.id} value={t.id}>
                          {t.template_name}{t.category ? ` · ${t.category}` : ''}{t.language ? ` [${t.language}]` : ''}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
              )}

              {selectedTemplate && hasVariables && (
                <div className="space-y-2">
                  <label className="block text-xs font-semibold text-gray-700">Variáveis do template</label>
                  {varNums.map(n => (
                    <div key={n} className="flex items-center gap-2">
                      <span className="text-xs text-gray-500 w-8 text-right flex-shrink-0">{`{{${n}}}`}</span>
                      <input
                        type="text"
                        value={variables[n] || ''}
                        onChange={e => setVariables(prev => ({ ...prev, [n]: e.target.value }))}
                        placeholder={`Valor para {{${n}}}`}
                        className="flex-1 border border-gray-300 rounded-lg px-3 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                      />
                    </div>
                  ))}
                </div>
              )}

              {preview && (
                <div>
                  <label className="block text-xs font-semibold text-gray-700 mb-1">Prévia</label>
                  <div className="rounded-xl border border-green-200 bg-[#ECE5DD] p-3">
                    <div className="inline-block bg-white rounded-xl px-3 py-2 max-w-full shadow-sm text-sm text-gray-800 leading-relaxed">
                      {preview.header && (
                        <p className="font-bold text-xs text-gray-600 mb-1 uppercase tracking-wide">{preview.header}</p>
                      )}
                      <p className="whitespace-pre-wrap text-[13px]">{preview.body || <span className="text-gray-400 italic">Selecione um template</span>}</p>
                      {preview.footer && (
                        <p className="text-[10px] text-gray-400 mt-1 italic">{preview.footer}</p>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {error && (
                <div className="flex items-start gap-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2 text-xs text-red-700">
                  <svg className="w-3.5 h-3.5 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  {error}
                </div>
              )}
            </>
          )}
        </div>

        {!success && (
          <div className="flex items-center justify-end gap-2 px-5 py-3 border-t border-gray-200 bg-gray-50 flex-shrink-0">
            <button
              onClick={onClose}
              className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 transition-colors"
            >
              Cancelar
            </button>
            <button
              onClick={handleSend}
              disabled={!canSend || sending}
              className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {sending ? (
                <span className="flex items-center gap-2">
                  <span className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Enviando...
                </span>
              ) : 'Disparar Template'}
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default GotalkSendTemplateModal;

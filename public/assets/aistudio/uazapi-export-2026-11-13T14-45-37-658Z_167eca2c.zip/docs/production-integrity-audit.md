# Auditoria de integridade de produção

## Inventário de mutações

| Superfície | Classificação | Proteção |
|---|---|---|
| Replit Publish / `migrations/` | Schema | Fonte estrutural; publicação revisada, forward-only |
| `scripts/migrate.js` | Schema DEV | Runner transacional; não é fluxo de produção |
| `scripts/migrate-prod.js` | Operacional | Fail-closed, sem conexão |
| `backfills/` + `scripts/backfill.js` | Dados | Lotes idempotentes, cursor, advisory lock e auditoria; produção exige backup/restauração |
| `scripts/seed.js` / `runProductionSeed` | Seed destrutivo | Produção bloqueada; somente DEV/homologação |
| `scripts/db-clean.js` | Limpeza destrutiva | Confirmação exata, destino explícito, backup/restauração e transação |
| Retenção, sync de configuração e dados padrão | Manutenção/seed | Desativados no startup de produção; execução exige fluxo operacional explícito |
| Jobs de mensagens, anexos, Datajud e uazapi | Comportamento normal | Iniciam somente após preflight; concorrência multi-instância permanece coberta por tarefas específicas |
| APIs administrativas | Operação | Tokens e autorização da aplicação; endpoints destrutivos não são fluxo de produção |

## Fluxo aprovado

1. Criar migration somente estrutural e validar em instalação limpa e upgrade.
2. Publicar pelo Replit Publish, sem sobrescrever dados.
3. Gerar/revisar `schema-contract.json` em desenvolvimento e executar
   `npm run schema:contract` com `NODE_ENV=production` e `PROD_DATABASE_URL`
   antes e depois do Publish. Qualquer diferença interrompe o fluxo.
4. Para dados, obter backup e teste de restauração; executar backfill explicitamente
   com ambiente, identidade `<host/banco>`, confirmação `<id>:production` e
   evidência anexada.
5. Conferir `data_backfill_runs`/`data_backfill_attempts`, rejeições e contagens
   antes/depois. Rejeições impedem conclusão.

## Riscos residuais

- O inventário de jobs de manutenção deve continuar sendo validado para execução
  única entre réplicas.
- O preflight cobre catálogo, privilégios e RLS, mas sua execução contra produção
  continua sendo uma aprovação operacional somente leitura; esta auditoria não
  executa DDL nem acessa dados de negócio em produção.
- Migrations históricas com transformações legadas permanecem imutáveis e devem
  ser mantidas no registro de exceções.
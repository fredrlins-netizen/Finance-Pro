# Módulos Mensagens (Chat Interno) e WhatsApp (Conversas)

> Segue o [`PADRAO-DE-SAIDA.md`](./PADRAO-DE-SAIDA.md). Termos do negócio em [`glossario.md`](./glossario.md).

## Conceito dos módulos

- **Mensagens (Chat Interno):** comunicação entre os colaboradores da empresa, no estilo
  WhatsApp. Funciona em **tempo real** (via SSE), com **entrega/lido**, **anexos** e **grupos**.
- **Conversas (WhatsApp / GoTalk + uazapi):** o atendimento ao cliente por WhatsApp, com
  múltiplos canais/números, envio de mensagens e modelos (templates HSM), e histórico das
  conversas. As credenciais técnicas dos canais ficam em **Configurações**.

## Mapa de prints

| Tela | Slug | Caminho |
|---|---|---|
| Central de Mensagens (interno) | `mensagens` | `public/help-screenshots/mensagens.jpg` |
| Mensagens GoTalk (Configurações) | `settings-gotalk` | `public/help-screenshots/settings-gotalk.jpg` |

> **Conversas (WhatsApp):** ainda sem print dedicado em `public/help-screenshots/`. Capturar
> `conversas.jpg` (lista de conversas + janela de mensagem + seleção de canal) ao documentar em detalhe.

---

## Parte A — Artigos da Base de Conhecimento IA

### Artigo 1

- **title:** Mensagens internas: conversar com a equipe, anexos e grupos
- **category:** Mensagens
- **termos de busca:** mensagem, chat interno, equipe, grupo, anexo, conversa, enviar, entregue, lido
- **active:** true

#### content (HTML)

```html
<h3>O que é o Chat Interno</h3>
<p>É a comunicação entre os colaboradores da empresa, parecida com o WhatsApp. As mensagens
chegam em <strong>tempo real</strong> e mostram status de <strong>entregue</strong> e <strong>lido</strong>.</p>
<h3>Como usar</h3>
<ol>
  <li>Abra <strong>Mensagens</strong>.</li>
  <li>Escolha um colega ou crie um <strong>grupo</strong> na lista de conversas.</li>
  <li>Escreva a mensagem; use o clipe para enviar <strong>anexos</strong> (arquivos/imagens).</li>
  <li>Envie. O status muda para entregue e depois lido.</li>
</ol>
<h3>Dica</h3>
<p>Grupos são úteis para equipes (ex.: Cobrança, Comercial) alinharem o atendimento.</p>
```

### Artigo 2

- **title:** Conversas WhatsApp: atender clientes, escolher canal e enviar modelos
- **category:** WhatsApp
- **termos de busca:** WhatsApp, conversa, atendimento, canal, número, template, HSM, GoTalk, uazapi, enviar mensagem
- **active:** true

#### content (HTML)

```html
<h3>O que é</h3>
<p>A tela de Conversas concentra o atendimento por WhatsApp. Você vê as conversas com os
clientes, responde e pode usar <strong>modelos (templates)</strong> aprovados.</p>
<h3>Como atender</h3>
<ol>
  <li>Abra <strong>Conversas</strong> e selecione a conversa na lista.</li>
  <li>Leia o histórico e responda na caixa de mensagem (texto, anexos, áudio).</li>
  <li>Se a empresa tiver mais de um número, <strong>escolha o canal</strong> correto antes de enviar.</li>
  <li>Para iniciar contato fora da janela de 24h, use um <strong>modelo (HSM)</strong> aprovado.</li>
</ol>
<h3>O que observar</h3>
<ul>
  <li><strong>Canal/Número:</strong> de qual número da empresa a mensagem sai.</li>
  <li><strong>Status de entrega:</strong> enviado, entregue, lido.</li>
  <li><strong>Unidade:</strong> a conversa fica vinculada à unidade do atendimento.</li>
</ul>
<h3>Observação</h3>
<p>A configuração técnica dos canais (login, número, webhook) fica em
<strong>Configurações &gt; Mensagens GoTalk</strong>.</p>
```

---

## Parte B — Tópicos da Central de Ajuda

| id | Tela |
|---|---|
| `mensagens` | Central de Mensagens (chat interno) |
| `settings_gotalk` | Mensagens GoTalk (Configurações) |

> **Lacuna:** não há tópico dedicado da tela de **Conversas (WhatsApp)** em `HelpContentData.ts`.
> Criar `conversas` (menuPath `Conversas`) ao capturar o print.

> **Privacidade (LGPD):** mascarar contatos, telefones e conteúdo real das conversas nos prints.

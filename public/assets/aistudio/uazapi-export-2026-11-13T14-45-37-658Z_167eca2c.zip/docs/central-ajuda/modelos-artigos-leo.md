# Modelos de Artigos para a Base de Conhecimento IA (Léo)

> Use estes modelos para cadastrar artigos em **Configurações › Base de Conhecimento IA**. Só perfil **ADMIN** pode editar.

## Regras de ouro (antes de copiar qualquer modelo)

1. **Título pesa 3×** — o Léo dá muito mais valor ao título. Escreva como o usuário perguntaria.
2. **Comece pela resposta** — os ~3.000 primeiros caracteres vão ao Léo. Passos primeiro, detalhes depois.
3. **Um assunto por artigo** — em vez de "Manual do Financeiro", faça "Contas a Receber: dar baixa em um título".
4. **Formatação é removida** — o Léo recebe o texto sem HTML. Negrito, cores etc. não contam.
5. **Até 3 imagens** — 2 MB cada, JPEG/PNG/WEBP. Mascare dados reais (LGPD).
6. **Deixe "Ativo" marcado** — senão o Léo nunca encontra.

## Como testar

Depois de salvar, abra **IA › Chat com Léo** e pergunte como o usuário perguntaria. Se o Léo responder citando *"De acordo com o artigo '...'"*, ele encontrou e usou o seu artigo.

---

## Modelo genérico (copie e adapte)

| Campo | Valor |
|---|---|
| **Título** | `[Módulo]: [tarefa que o usuário quer fazer]` |
| **Categoria** | `[categoria do módulo]` |
| **Conteúdo** | `Para [objetivo]: 1. Abra [caminho]. 2. [ação] e informe [campos]. 3. Confirme. Resultado: [o que acontece]. Dica: [exceção ou atalho].` |

---

## Agenda — Categoria: `Agenda`

**Título:** `Agenda: como criar um agendamento e escolher a unidade`

**Conteúdo:**

Para criar um agendamento:
1. Abra **Agenda**.
2. Clique no horário desejado (ou no botão **Novo**) e informe o cliente, o colaborador, o serviço, a data e o horário de início e término.
3. Selecione a **unidade** (filtra os dados do sistema). Salve.

Resultado: o agendamento aparece na agenda com status **AGENDADO**.

Dica: para remarcar, arraste o agendamento para outro horário. Para ativar a fila de espera, marque o check Fila de espera.

---

## Cadastros — Clientes — Categoria: `Cadastros`

**Título:** `Clientes: como cadastrar um novo cliente e marcar o WhatsApp`

**Conteúdo:**

Para cadastrar um cliente:
1. Abra **Cadastros Comuns > Clientes**.
2. Clique em **Novo** e preencha os campos obrigatórios: nome, CPF ou CNPJ, telefone e e-mail.
3. Marque o campo **WhatsApp** se o telefone for utilizado para mensagens.
4. Salve. O cliente nasce com status **ATIVO**.

Dica: clientes com status **BLOQUEADO** ou **SUSPENSO** não aparecem em algumas listas de atendimento. Para reativar, edite o status.

---

## Comercial — Admissão — Categoria: `Comercial`

**Título:** `Admissão: como cadastrar um contrato e os cenários de recálculo`

**Conteúdo:**

Para registrar uma admissão:
1. Abra **Atendimento > Comercial > Admissão**.
2. Selecione o cliente e preencha: banco, modalidade, parcelas totais, parcelas pagas, valor financiado, valor da parcela e dia de vencimento.
3. Adicione os **cenários de recálculo** (as simulações de renegociação com valores menores).
4. Salve. O status segue o fluxo: **NOVO** → **EM_ANALISE** → **APROVADA** → **CONCLUIDO**.

Dica: se a auditoria retornar com pendências, o status volta para **RETORNO_AUDITORIA**. Corrija e reenvie.

---

## Comercial — Negociação — Categoria: `Negociação`

**Título:** `Negociação: como registrar uma proposta e acompanhar o acordo`

**Conteúdo:**

Para registrar uma negociação:
1. Abra **Atendimento > Comercial > Negociação**.
2. Selecione o cliente e informe a dívida total, o valor negociado e a forma de pagamento.
3. Salve. Os status possíveis são: **ABERTA**, **PROPOSTA**, **ACORDADA**, **ENCERRADA** e **CANCELADA**.

Dica: uma negociação **ACORDADA** gera títulos financeiros automaticamente. Para acompanhá-la, use o painel Financeiro > Negociação.

---

## Auditoria — Categoria: `Auditoria`

**Título:** `Auditoria: como revisar e aprovar uma admissão`

**Conteúdo:**

Para auditar uma admissão:
1. Abra **Atendimento > Auditoria**.
2. Selecione a admissão em análise. Verifique os dados do cliente, os valores, as parcelas e os cenários de recálculo.
3. Aprove (muda para **APROVADA**) ou retorne (muda para **RETORNO_AUDITORIA** com observação).

Dica: o status **CONCLUIDO** é atribuído automaticamente quando todos os passos forem finalizados.

---

## Jurídico — Categoria: `Jurídico`

**Título:** `Jurídico: como cadastrar um processo e acompanhar prazos e audiências`

**Conteúdo:**

Para registrar um processo:
1. Abra **Atendimento > Jurídico** (ou **Acompanhamento Jurídico > Processos**).
2. Informe o número do processo, o tipo (trabalhista, cível, tributário, consumidor, criminal, administrativo), o nível de risco (baixo, médio, alto, crítico) e o valor da causa.
3. Salve. Acompanhe prazos e audiências em **Acompanhamento Jurídico > Prazos e Audiências**.

Dica: o sistema envia notificações automáticas para prazos próximos. Consulte o andamento na fonte oficial do tribunal e registre as atualizações no acompanhamento jurídico.

---

## Financeiro — Contas a Receber — Categoria: `Financeiro`

**Título:** `Contas a Receber: como dar baixa em um título e emitir a fatura`

**Conteúdo:**

Para registrar o pagamento de um título (dar baixa):
1. Abra **Financeiro > Contas a Receber**.
2. Localize o título pelo nome do cliente ou número do documento.
3. Clique em **Dar baixa** e informe a data, o valor recebido e a forma de pagamento.
4. Confirme. O status muda para **PAGO** (ou **PARCIAL**, se o valor for menor que o saldo).

Dica: para baixa parcial, informe um valor menor que o saldo. O título continua **ABERTO** pelo restante. Para emitir a fatura, selecione os títulos e use a opção **Gerar fatura**.

---

## Financeiro — Contas a Pagar — Categoria: `Financeiro`

**Título:** `Contas a Pagar: como registrar uma conta e programar o pagamento`

**Conteúdo:**

Para registrar uma conta a pagar:
1. Abra **Financeiro > Contas a Pagar**.
2. Clique em **Novo** e informe o fornecedor, a descrição, o valor, a data de vencimento e a forma de pagamento.
3. Salve. O status inicial é **ABERTO**.

Dica: para programar, ajuste a data de vencimento. Títulos **VENCIDO** aparecem com alerta. Para dar baixa, o fluxo é o mesmo de Contas a Receber.

---

## Financeiro — Conta Corrente — Categoria: `Financeiro`

**Título:** `Conta Corrente: como lançar movimento e fazer a conciliação bancária`

**Conteúdo:**

Para lançar um movimento:
1. Abra **Financeiro > Conta Corrente > Movimento**.
2. Selecione a conta bancária, informe o tipo (crédito ou débito), o valor e a descrição.
3. Salve. O movimento é registrado com a data do lançamento.

Para conciliar:
1. Abra **Financeiro > Conta Corrente > Conciliação Bancária**.
2. Compare os lançamentos do sistema com o extrato do banco.
3. Marque os movimentos que batem com o extrato. Os pendentes ficam destacados.

Dica: movimentos não conciliados aparecem em relatórios de discrepância.

---

## Cobrança — Categoria: `Cobrança`

**Título:** `Cobrança: como usar o painel operacional e registrar uma tratativa`

**Conteúdo:**

Para registrar uma tratativa de cobrança:
1. Abra **Cobrança > Operacional** (visão do operador) ou **Cobrança > Coordenador** (visão de gestão).
2. Localize o título vencido ou o cliente inadimplente.
3. Adicione uma **nota de cobrança** com o resultado da ligação, e-mail ou WhatsApp.

Dica: o painel do **Coordenador** mostra metas de equipe e desempenho por operador. O painel **Operacional** mostra a fila de trabalho do dia.

---

## Relatórios — Categoria: `Relatórios`

**Título:** `Relatórios: como montar um relatório e exportar em PDF, Excel ou CSV`

**Conteúdo:**

Para gerar um relatório:
1. Abra **Relatórios > Relatórios Gerais**.
2. Selecione a tabela base, os filtros, as colunas e os gráficos desejados.
3. Visualize a prévia e ajuste. Depois exporte em **PDF, Excel, Word ou CSV**.

Dica: relatórios complexos podem conter **subrelatórios**. Use o **Gerador de Consultas** para consultas rápidas com SQL. Usuários não-admin só veem SELECT (sem alteração no banco).

---

## Mensagens (chat interno) — Categoria: `Mensagens`

**Título:** `Mensagens: como conversar com a equipe e criar grupos`

**Conteúdo:**

Para iniciar uma conversa:
1. Abra **Mensagens**.
2. Clique em **Nova conversa** e selecione o colaborador.
3. Digite a mensagem. É possível anexar arquivos.

Para criar um grupo:
1. Clique em **Novo grupo**.
2. Adicione os participantes e dê um nome ao grupo.
3. Envie a mensagem. Todos os participantes recebem.

Dica: o sistema mostra **entregue** (dois ticks) e **lido** (azul). Para broadcast, envie uma mensagem para múltiplos colaboradores de uma vez.

---

## Conversas WhatsApp — Categoria: `WhatsApp`

**Título:** `WhatsApp: como responder conversas e enviar mensagens pelo sistema`

**Conteúdo:**

Para responder uma conversa:
1. Abra **Conversas WhatsApp**.
2. Selecione a conversa na lista. Escreva a resposta e envie.
3. É possível enviar templates, áudio, imagem e documento.

Dica: o sistema suporta **múltiplos canais por unidade** (GoTalk + uazapi). Cada unidade pode ter seu próprio número. Use o filtro por unidade para organizar as conversas.

---

## Configurações — Categoria: `Configurações`

**Título:** `Configurações: como criar um usuário e definir o grupo de acesso`

**Conteúdo:**

Para criar um usuário:
1. Abra **Configurações > Usuários**.
2. Clique em **Novo** e informe o nome, e-mail e grupo de acesso.
3. Selecione as **unidades permitidas** (o usuário só vê dados dessas unidades).
4. Salve. O grupo de acesso define quais menus e ações o usuário pode usar.

Dica: grupos de acesso são criados em **Configurações > Grupos de Acesso**. Usuários com status **INATIVO** não conseguem fazer login.

---

## Configurações — Base de Conhecimento IA (meta) — Categoria: `Configurações`

**Título:** `Base de Conhecimento: como cadastrar um artigo para o Léo`

**Conteúdo:**

Para ensinar o Léo a responder sobre um módulo:
1. Abra **Configurações > Base de Conhecimento IA > Novo**.
2. Escreva um **título** cheio das palavras que o usuário usaria na pergunta (o título tem o maior peso na busca).
3. Coloque o **essencial no começo** do conteúdo — o Léo lê só os ~3.000 primeiros caracteres e a formatação é removida.
4. Anexe até 3 imagens (2 MB cada, JPEG/PNG/WEBP). Mascare dados reais.
5. Deixe o artigo **Ativo** e salve.

Dica: um assunto por artigo. Teste perguntando ao Léo depois. Se ele não citar o artigo, ajuste o título para incluir os termos da pergunta.

---

## IA — Assistente Léo (meta) — Categoria: `Configurações`

**Título:** `Assistente Léo (IA): como tirar dúvidas sobre o sistema`

**Conteúdo:**

Para usar o Léo:
1. Abra **IA > Chat com Léo**.
2. Escreva sua dúvida em linguagem normal (ex.: "como dou baixa em uma conta a receber?").
3. O Léo busca os artigos mais relevantes da Base de Conhecimento e responde com base neles.

Quando o Léo não sabe: se não houver artigo sobre o tema, ele pode não responder com precisão. Nesse caso, cadastre um artigo novo na Base de Conhecimento IA.

Dica: além de dúvidas, o Léo faz **Análise de Dados** (pergunta em português, ele gera SQL e analisa), **Resumo de Relatórios** e **Auditoria IA**. Essas funções avançadas são restritas a ADMIN e COORDENADOR.

---

*Modelo preparado em 2026-06-12. Para atualizar, edite este arquivo ou cadastre novos artigos diretamente na Base de Conhecimento IA.*

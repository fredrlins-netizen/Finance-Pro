# Auditoria somente leitura dos vínculos legados

## Ambiente, data e limites

- **Ambiente consultado: desenvolvimento, não produção.**
- Consulta das relações: **11/11/2026, 19:09:45 UTC**. Inventário complementar e conferência do catálogo realizados na mesma sessão, em consultas separadas.
- A tentativa de leitura de produção pelo recurso autorizado foi recusada por falta de autenticação. **Este relatório não atesta a integridade de produção.** Para obter contagens de produção, será necessário acesso autenticado e repetir os SELECTs pelo recurso de banco com `environment: "production"`.
- O aplicativo usa o banco gerenciado; em produção, sua conexão é derivada desse endpoint com uma role restrita. Não foi acessada conexão alternativa nem lido o conteúdo de segredos.
- Foram inventariadas **71 colunas textuais terminadas em `_id`, sem FK direta, em tabelas-base públicas**: 28 relações internas/históricas e 43 campos separados por semântica.
- O catálogo efetivo de desenvolvimento confirmou as mesmas 71 colunas cobertas pelo contrato. Views não foram contadas novamente. Projeções técnicas `_reference_*`, colunas UUID, arrays e JSON não fazem parte desse recorte.
- As relações UUID ou textuais que já possuem FK direta, como `collection_notes.client_id`, `collection_notes.title_id`, os vínculos UUID de admissões/negociações e `negotiation_contacts.record_id`/`negotiation_proposals.record_id`, não foram tratadas como legado textual sem FK.
- Texto descritivo e snapshots (`client_name`, `collaborator_name`, nomes históricos de usuários, descrições e campos como `blocked_by`) não foram usados para reconstruir relacionamentos. Campos externos como `*_ext`, `idwpp` e `gotalk_channel_uuid`, mesmo quando UUID no formato, também não são FKs internas por esse motivo.
- Cada consulta agregada tem seu próprio snapshot consistente; consultas diferentes não compartilham transação. Não se trata de monitoramento contínuo.
- **Nenhum registro foi excluído, convertido, remapeado, corrigido ou inserido na base auditada. Nenhuma migração foi executada.**

## Resumo dos achados

1. **8 UUIDs órfãos em `appointments.client_id`**: não há cliente com o ID indicado na base consultada.
2. **8 valores textuais sem candidato em `appointments.service_id`**: não correspondem ao ID nem ao nome normalizado de um serviço atual.
3. Esses 16 problemas de vínculo pertencem aos **mesmos 8 agendamentos**: todas as 8 linhas têm ambos os problemas. Não são 16 registros distintos.
4. As 8 referências de unidade desses agendamentos apontam para cadastros existentes.
5. **Nenhum texto com candidato único ou ambíguo** nas relações internas/históricas analisadas; nenhum UUID com espaços ou em maiúsculas.
6. As demais relações operacionais textuais auditadas estavam sem linhas. **Zero linhas não comprova que o comportamento de gravação esteja correto.**
7. No histórico, 356 referências de usuário e 38 de unidade existem atualmente; os demais valores são nulos, não referências órfãs. Ausência de unidade em histórico não foi classificada como erro de identidade.
8. **Não aprovar saneamento de produção com base nestas contagens de desenvolvimento.**

## Critérios de identificação

As categorias principais são mutuamente exclusivas. Para cada relação:

`total = nulos + vazios + IDs válidos + UUIDs órfãos + UUIDs com espaços + textos com candidato único + textos ambíguos + textos sem candidato`.

| Categoria | Critério | Interpretação e proposta, sujeita à aprovação |
|---|---|---|
| Nulo | Valor SQL `NULL` | Ausência; verificar obrigatoriedade de negócio separadamente. Não preencher automaticamente. |
| Vazio | Texto vazio ou contendo somente espaços comuns removidos por `btrim` | Não é ID; distinguir de nulo e revisar antes de qualquer normalização. |
| ID válido | Coincide com o ID do pai; UUID comparado sem diferença entre maiúsculas/minúsculas, sem remover espaços | Manter. Existência não prova unidade/autorização ou coerência entre cliente, admissão e título. |
| UUID órfão | Formato UUID canônico de 36 caracteres, sem pai existente | Investigar exclusão/importação/ambiente. Preservar o original; restaurar pai ou trocar vínculo apenas com evidência e aprovação individual. Nunca procurar outro pai por nome para substituir um UUID órfão. |
| UUID com espaços | Só passa no padrão UUID após `btrim` | Não é contado como ID válido; revisar formato e existência do pai antes de uma eventual correção autorizada. |
| Texto com candidato único | Não é UUID e corresponde a exatamente um ID de pai pelas chaves abaixo | Apenas indício para revisão humana. Não autoriza resolver ou converter. |
| Texto ambíguo | Não é UUID e corresponde a dois ou mais IDs distintos, juntando todas as chaves consultadas | Exigir evidência e decisão explícita. Não desempatar pelo primeiro resultado. |
| Texto sem candidato | Não é UUID, não coincide com ID textual e não tem candidato pelas chaves permitidas | Revisar origem e cadastros. Não criar pai, apagar ou desvincular automaticamente. |

O contador adicional `uuid_maiusculo` é subconjunto de IDs válidos, não uma categoria a somar. Um UUID existente em maiúsculas pode exigir revisão das comparações textuais do consumidor.

Para pais com ID UUID, não se faz cast do texto legado: o ID do pai é comparado com `lower(valor_original)`. Isso evita falhas em valores malformados. Para `messages.id`, que é textual, a comparação é **exata e sensível à caixa**, inclusive para IDs textuais não UUID. Nenhum nome é usado para esse pai.

Candidatos textuais usam somente `lower(btrim(valor))`: não há correspondência aproximada, remoção de acentos, telefone/documento pessoal ou reconstrução por snapshots. Correspondências em duas chaves do **mesmo pai** contam uma vez. A busca é global na tabela-pai, de forma conservadora: não reduz ambiguidades usando uma unidade presumida. Mesmo um candidato único ainda precisaria de validação de negócio e unidade antes de qualquer correção.

### Chaves permitidas para detectar candidatos, nunca para gravar

| Pai | Chaves examinadas |
|---|---|
| `clients` | `name` |
| `service_items` | `name` |
| `companies` | `razao_social`, `nome_fantasia` |
| `collaborators` | `name` |
| `bank_accounts` | `description` |
| `chart_of_accounts` | `code`, `name` |
| `document_types` | `description` |
| `bearers` | `code`, `name` |
| `departments` | `code`, `name` |
| `financial_titles` | `document_number`, `description` — não se presume unicidade |
| `banks` | `febraban_code`, `name` |
| `users` | `name` |
| `messages`, `gotalk_contacts`, `gotalk_attendances` | Nenhuma chave textual alternativa; somente ID |

## Contagens por relação interna operacional

Colunas: **T** total de linhas, **N** nulos, **V** vazios, **ID** IDs válidos, **O** UUIDs órfãos, **E** UUIDs com espaços, **U** textos com candidato único, **A** textos ambíguos, **S** textos sem candidato.

| Relação | Pai | T | N | V | ID | O | E | U | A | S |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `appointments.client_id` | `clients` | 8 | 0 | 0 | 0 | 8 | 0 | 0 | 0 | 0 |
| `appointments.service_id` | `service_items` | 8 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 8 |
| `appointments.unit_id` | `companies` | 8 | 0 | 0 | 8 | 0 | 0 | 0 | 0 | 0 |
| `admissions.unit_id` | `companies` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `commercial_deals.collaborator_id` | `collaborators` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `bank_movements.bank_account_id` | `bank_accounts` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `bank_movements.category_id` | `chart_of_accounts` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `bank_movements.document_type_id` | `document_types` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `bank_movements.bearer_id` | `bearers` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `bank_movements.department_id` | `departments` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `bank_movements.title_id` | `financial_titles` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `collection_notes.collaborator_id` | `collaborators` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `negotiation_records.bank_id` | `banks` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `negotiation_records.collaborator_id` | `collaborators` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `negotiation_contacts.collaborator_id` | `collaborators` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `negotiation_proposals.collaborator_id` | `collaborators` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `negotiation_goals.collaborator_id` | `collaborators` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `messages.sender_id` | `users` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `message_reads.message_id` | `messages` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `message_reads.user_id` | `users` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `message_deliveries.message_id` | `messages` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `message_deliveries.user_id` | `users` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `contract_attachment_operations.unit_id` | `companies` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `contract_attachment_upload_sessions.unit_id` | `companies` | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

### Relações históricas — interpretar separadamente

| Relação | Pai atual | T | N | V | ID | O | E | U | A | S |
|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| `audit_logs.user_id` | `users` | 360 | 4 | 0 | 356 | 0 | 0 | 0 | 0 | 0 |
| `audit_logs.unit_id` | `companies` | 360 | 322 | 0 | 38 | 0 | 0 | 0 | 0 | 0 |
| `gotalk_messages_archive.gotalk_contact_id` | `gotalk_contacts` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |
| `gotalk_messages_archive.attendance_id` | `gotalk_attendances` | 1 | 1 | 0 | 0 | 0 | 0 | 0 | 0 | 0 |

Não somar referências históricas como registros distintos. Não reatribuir autoria nem completar unidades antigas apenas para eliminar nulos. A ausência futura de um pai no arquivo histórico pode ser efeito de retenção; requer interpretação, não remapeamento automático.

## Inventário separado — não tratar como FK interna simples

**T** total, **N** nulos, **P** preenchidos. Todos os campos desta tabela tinham **zero vazios**. A quantidade preenchida não significa “referência válida” nem “referência órfã”.

| Campo | Classificação | T | N | P |
|---|---|---:|---:|---:|
| `appointments.group_id` | Agrupamento | 8 | 7 | 1 |
| `bank_movements.transfer_id` | Agrupamento | 0 | 0 | 0 |
| `audit_logs.entity_id` | Polimórfico, depende de `entity` | 360 | 46 | 314 |
| `audit_unit_backfill_unclassified.entity_id` | Polimórfico | 0 | 0 | 0 |
| `messages.recipient_id` | Polimórfico: USER/GROUP/ALL | 0 | 0 | 0 |
| `client_attachments.target_id` | Polimórfico, depende do tipo do destino | 0 | 0 | 0 |
| `bank_movements.cost_center_id` | Destino não confirmado | 0 | 0 | 0 |
| `gotalk_messages_archive.operator_id` | Destino histórico não confirmado | 1 | 1 | 0 |
| `client_attachment_contract_folder_acl.bucket_id` | Identificador de armazenamento | 0 | 0 | 0 |
| `data_backfill_attempts.backfill_id` | Código técnico do procedimento | 0 | 0 | 0 |
| `data_backfill_runs.backfill_id` | Código técnico do procedimento | 0 | 0 | 0 |
| `homologation_runs.run_id` | Identificador técnico de execução | 0 | 0 | 0 |
| `clients.gotalk_contact_id` | Integração externa | 0 | 0 | 0 |
| `clients.gotalk_channel_id` | Integração externa | 0 | 0 | 0 |
| `gotalk_attendance_history.gotalk_attendance_id` | Integração externa | 21272 | 0 | 21272 |
| `gotalk_attendance_history.channel_id` | Integração externa | 21272 | 0 | 21272 |
| `gotalk_attendance_history.gotalk_operator_id` | Integração externa | 21272 | 158 | 21114 |
| `gotalk_attendance_history.department_id` | Departamento da integração | 21272 | 193 | 21079 |
| `gotalk_attendances.gotalk_attendance_id` | Integração externa | 0 | 0 | 0 |
| `gotalk_attendances.gotalk_operator_id` | Integração externa | 0 | 0 | 0 |
| `gotalk_channels.channel_id` | Integração externa | 10 | 0 | 10 |
| `gotalk_contacts.gotalk_id` | Integração externa | 25775 | 0 | 25775 |
| `gotalk_contacts.channel_id` | Integração externa | 25775 | 0 | 25775 |
| `gotalk_file_uploads.gotalk_message_id` | Integração externa | 6 | 2 | 4 |
| `gotalk_hsm_templates.gotalk_template_id` | Integração externa | 50 | 0 | 50 |
| `gotalk_messages.gotalk_message_id` | Integração externa | 203524 | 0 | 203524 |
| `gotalk_messages.uazapi_instance_id` | Integração externa | 203524 | 202401 | 1123 |
| `gotalk_messages_archive.gotalk_message_id` | Integração externa | 1 | 1 | 0 |
| `gotalk_operator_attendances.gotalk_attendance_id` | Integração externa | 11134 | 0 | 11134 |
| `gotalk_operator_attendances.gotalk_operator_id` | Integração externa | 11134 | 0 | 11134 |
| `gotalk_operator_attendances.channel_id` | Integração externa | 11134 | 0 | 11134 |
| `gotalk_operator_attendances.department_id` | Departamento da integração | 11134 | 0 | 11134 |
| `gotalk_operators.gotalk_operator_id` | Integração externa | 57 | 0 | 57 |
| `prospection_contacts.uazapi_instance_id` | Integração externa | 4982 | 4910 | 72 |
| `prospection_contacts.last_inbound_instance_id` | Integração externa | 4982 | 4911 | 71 |
| `prospection_conversations.uazapi_instance_id` | Integração externa | 23 | 11 | 12 |
| `uazapi_messages.message_id` | Integração externa | 0 | 0 | 0 |
| `uazapi_messages.instance_id` | Integração externa | 0 | 0 | 0 |
| `uazapi_messages.chat_id` | Integração externa | 0 | 0 | 0 |
| `uazapi_messages.quoted_message_id` | Integração externa | 0 | 0 | 0 |
| `unit_whatsapp_credentials.uazapi_instance_id` | Integração externa | 3 | 0 | 3 |
| `whatsapp_call_logs.call_id` | Integração externa | 0 | 0 | 0 |
| `whatsapp_scheduled_messages.chat_id` | Integração externa | 0 | 0 | 0 |

Não associar `bank_movements.cost_center_id` a `departments` por suposição: o código permite o campo, mas não estabelece pai nessa relação; não há tabela de centros de custo confirmada. O `department_id` financeiro, por sua vez, tem destino explícito e foi auditado. O arquivo de mensagens possui variantes históricas de esquema; não presumir se seu `operator_id` é ID interno ou externo.

## Propostas de correção para aprovação — nenhuma executada

| Relação/grupo | Proposta |
|---|---|
| `appointments.client_id` — 8 órfãos | Revisar os oito casos em ambiente restrito com origem do agendamento e evidência do cadastro. Determinar se houve exclusão, importação ou referência de outro ambiente. Aprovar individualmente a restauração do cadastro correto ou o novo ID; manter original e trilha de alteração. Não usar nome do cliente como substituto automático. |
| `appointments.service_id` — 8 textos sem candidato | Confirmar com o responsável qual serviço foi contratado/agendado em cada caso. Somente depois de aprovação explícita, vincular ao ID correto ou autorizar cadastro faltante. Não criar serviços a partir do texto automaticamente. |
| `appointments.unit_id` — 8 válidos | Manter valores. Conferir coerência de unidade se houver futura revisão dos outros dois vínculos; não remapear unidades nesta auditoria. |
| Demais relações operacionais da tabela | Nenhuma correção indicada pela amostra vazia. Conservar as validações por ID existentes e repetir auditoria quando houver dados ou no ambiente autorizado. |
| Histórico de auditoria e mensagens arquivadas | Preservar autoria, valores e ausências. Qualquer enriquecimento exige política aprovada, evidência e distinção entre histórico original e dado derivado. |
| Agrupamentos/polimórficos/integrações | Manter fora de saneamento de FK simples. Qualquer validação futura deve respeitar discriminadores, identificador de execução/grupo e a origem externa. Não converter em UUID apenas pelo formato. |
| Campos sem destino confirmado | Definir semântica e tabela/serviço proprietário antes de planejar correção ou proteção. Atualmente não há valores preenchidos nesses dois campos. |

Depois de correções explicitamente aprovadas, repetir os mesmos critérios no **mesmo ambiente**, verificar as contagens e tratar a validação integral das proteções em trabalho próprio. Este documento não autoriza executar `VALIDATE CONSTRAINT`, novas FKs ou qualquer saneamento.

## Reprodutibilidade e proteção de dados

- Gerador offline: `scripts/audit-legacy-references.js`. `node scripts/audit-legacy-references.js` imprime **apenas o SELECT**, não abre conexão e não executa consultas.
- `buildAuditQuery()` gera um SELECT agregado para as 28 relações; `buildInventoryQuery(contrato)` gera outro para os 43 campos restantes. Ler `schema-contract.json` para o segundo.
- Executar o SELECT pelo recurso autorizado de banco, informando o ambiente explicitamente. Para produção, usar exclusivamente a skill `database` com `environment: "production"` após autenticação. Não substituir por URL, segredo ou acesso direto.
- Antes de repetir em outro esquema, comparar as colunas textuais sem FK direta do catálogo com a união do manifesto e inventário. Campos novos sem mapeamento devem ficar como “destino não confirmado”, nunca ignorados.
- A consulta só retorna nomes técnicos das relações, classes e contagens; valores de referência, IDs de registros/pais, nomes pessoais, documentos, telefone, corpo de mensagens e exemplos não saem do banco.
- Não foi criado endpoint público, relatório nominal, listagem de casos individuais, arquivo de dados brutos ou mecanismo de remapeamento. Uma revisão nominal futura deve ter acesso restrito e autorização própria.
- Verificação automatizada: `node --test tests/legacyReferenceAudit.test.js`. Os dados sintéticos são criados somente em PostgreSQL local descartável; as classificações foram exercitadas em transação somente leitura. Os testes verificam a preservação das linhas, deduplicação de candidatos, ambiguidade entre chaves, órfãos, vazios, espaços, UUIDs em maiúsculas e IDs textuais de mensagens.
- Não houve mudança em telas, rotas, comportamento de execução do aplicativo ou schema.

-- ============================================================
-- MIGRAÇÃO 027: uazapi Foundation
-- Criado em: 2026-04-22
-- Descrição: Prepara o banco para suporte dual de provedores
--            WhatsApp (GoTalk já existente + uazapi novo).
--
--            1. Adiciona whatsapp_number à tabela companies,
--               para que cada unidade declare seu número WA.
--            2. Adiciona coluna source em gotalk_messages,
--               distinguindo a origem das mensagens.
--            3. Cria tabela unit_whatsapp_credentials para
--               armazenar credenciais uazapi por unidade de
--               forma segura (token armazenado com bcrypt hash
--               — nunca exposto em leitura).
-- ============================================================

-- 1. CAMPO WHATSAPP_NUMBER NA TABELA companies
ALTER TABLE companies
  ADD COLUMN IF NOT EXISTS whatsapp_number VARCHAR(30);

-- 2. COLUNA SOURCE EM gotalk_messages
--    Default 'gotalk' preserva todas as mensagens existentes.
ALTER TABLE gotalk_messages
  ADD COLUMN IF NOT EXISTS source VARCHAR(10) NOT NULL DEFAULT 'gotalk'
    CHECK (source IN ('gotalk','uazapi'));

CREATE INDEX IF NOT EXISTS idx_gotalk_messages_source
  ON gotalk_messages(source);

-- 3. TABELA unit_whatsapp_credentials
--    Armazena as credenciais uazapi por unidade.
--    O token nunca é retornado em leitura — apenas has_token (boolean).
CREATE TABLE IF NOT EXISTS unit_whatsapp_credentials (
  id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  unit_id             UUID NOT NULL UNIQUE REFERENCES companies(id) ON DELETE CASCADE,
  uazapi_instance_id  VARCHAR(200),
  uazapi_token_hash   TEXT,
  created_at          TIMESTAMPTZ DEFAULT NOW(),
  updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_unit_wa_creds_unit
  ON unit_whatsapp_credentials(unit_id);

-- ============================================================
-- FIM DA MIGRAÇÃO 027
-- ============================================================

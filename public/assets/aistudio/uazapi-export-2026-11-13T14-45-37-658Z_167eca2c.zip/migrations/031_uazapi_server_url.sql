-- Migration 031: Adiciona campo uazapi_server_url em unit_whatsapp_credentials
-- Permite configurar a URL do servidor uazapi por unidade (ex: https://free.uazapi.com)
-- Se vazio, o backend usa env UAZAPI_SERVER_URL ou o fallback padrão.

ALTER TABLE unit_whatsapp_credentials
  ADD COLUMN IF NOT EXISTS uazapi_server_url VARCHAR(500);

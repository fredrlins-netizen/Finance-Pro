-- Migration 039: Adiciona coluna last_source em prospection_contacts
-- Registra o provedor da ÚLTIMA interação (gotalk ou uazapi),
-- diferente de source que preserva o first-touch.

ALTER TABLE prospection_contacts
  ADD COLUMN IF NOT EXISTS last_source VARCHAR(50);

-- Backfill básico: copia source para last_source em todas as linhas
UPDATE prospection_contacts
   SET last_source = source
 WHERE last_source IS NULL;

-- Backfill inteligente: contatos que têm mensagens IN via uazapi
-- recebem last_source='uazapi' para refletir a realidade do canal mais recente
UPDATE prospection_contacts pc
   SET last_source = 'uazapi'
  FROM (
    SELECT DISTINCT RIGHT(REGEXP_REPLACE(COALESCE(phone_number,''),'[^0-9]','','g'),10) AS last10
      FROM gotalk_messages
     WHERE source = 'uazapi'
       AND direction = 'IN'
       AND phone_number IS NOT NULL
  ) gm
 WHERE RIGHT(REGEXP_REPLACE(COALESCE(pc.phone,''),'[^0-9]','','g'),10) = gm.last10;

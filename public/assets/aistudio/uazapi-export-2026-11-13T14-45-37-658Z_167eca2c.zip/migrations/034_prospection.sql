-- Migration 034: Prospection module tables
-- Purpose: Store all phone numbers involved in prospecting (WhatsApp contacts)
--   and group them into conversation sessions with summaries and outcome data.

CREATE TABLE IF NOT EXISTS prospection_contacts (
  id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone            VARCHAR(20) NOT NULL,
  contact_name     VARCHAR(255),
  classification   VARCHAR(20) NOT NULL DEFAULT 'LEAD' CHECK (classification IN ('LEAD', 'RECUPERACAO')),
  total_contacts   INTEGER NOT NULL DEFAULT 1,
  first_contact_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_contact_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  unit_id          UUID REFERENCES companies(id) ON DELETE SET NULL,
  operator_id      UUID REFERENCES collaborators(id) ON DELETE SET NULL,
  client_id        UUID REFERENCES clients(id) ON DELETE SET NULL,
  source           VARCHAR(20) NOT NULL DEFAULT 'uazapi' CHECK (source IN ('gotalk', 'uazapi')),
  created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_prospection_contacts_phone ON prospection_contacts (phone);
CREATE INDEX IF NOT EXISTS idx_prospection_contacts_classification ON prospection_contacts (classification);
CREATE INDEX IF NOT EXISTS idx_prospection_contacts_unit_id ON prospection_contacts (unit_id);
CREATE INDEX IF NOT EXISTS idx_prospection_contacts_last_contact ON prospection_contacts (last_contact_at DESC);
CREATE INDEX IF NOT EXISTS idx_prospection_contacts_client_id ON prospection_contacts (client_id);

CREATE TABLE IF NOT EXISTS prospection_conversations (
  id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  phone          VARCHAR(20) NOT NULL,
  classification VARCHAR(20) NOT NULL DEFAULT 'LEAD' CHECK (classification IN ('LEAD', 'RECUPERACAO')),
  start_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  end_at         TIMESTAMPTZ,
  operator_id    UUID REFERENCES collaborators(id) ON DELETE SET NULL,
  operator_name  VARCHAR(255),
  unit_id        UUID REFERENCES companies(id) ON DELETE SET NULL,
  source         VARCHAR(20) NOT NULL DEFAULT 'uazapi' CHECK (source IN ('gotalk', 'uazapi')),
  message_count  INTEGER NOT NULL DEFAULT 0,
  outcome        VARCHAR(30) CHECK (outcome IN ('INTERESSE_ALTO', 'INTERESSE_MEDIO', 'INTERESSE_BAIXO', 'SEM_INTERESSE', 'NAO_DEFINIDO')),
  summary_text   TEXT,
  summary_data   JSONB DEFAULT '{}',
  created_at     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at     TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_prospection_conversations_phone ON prospection_conversations (phone);
CREATE INDEX IF NOT EXISTS idx_prospection_conversations_unit_id ON prospection_conversations (unit_id);
CREATE INDEX IF NOT EXISTS idx_prospection_conversations_start_at ON prospection_conversations (start_at DESC);
CREATE INDEX IF NOT EXISTS idx_prospection_conversations_classification ON prospection_conversations (classification);

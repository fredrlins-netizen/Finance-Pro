-- ============================================================
-- MIGRAÇÃO 029: uazapi — unique index em uazapi_instance_id
-- Criado em: 2026-04-22
-- Descrição: Garante que cada instance_id uazapi seja único
--            globalmente, tornando o lookup por instance_id
--            determinístico no handler de webhooks.
-- ============================================================

CREATE UNIQUE INDEX IF NOT EXISTS uq_unit_wa_creds_instance_id
  ON unit_whatsapp_credentials (uazapi_instance_id)
  WHERE uazapi_instance_id IS NOT NULL;

-- ============================================================
-- FIM DA MIGRAÇÃO 029
-- ============================================================

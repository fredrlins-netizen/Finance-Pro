-- ============================================================
-- MIGRAÇÃO 030: Adiciona unit_id a gotalk_messages
-- Criado em: 2026-04-22
-- Descrição: Adiciona coluna unit_id à tabela gotalk_messages
--            para que mensagens uazapi (sem gotalk_channel_uuid)
--            possam ser vinculadas diretamente à unidade.
--            Mensagens GoTalk existentes mantêm unit_id = NULL
--            e continuam sendo identificadas via gotalk_channel_uuid.
-- ============================================================

ALTER TABLE gotalk_messages
  ADD COLUMN IF NOT EXISTS unit_id UUID REFERENCES companies(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_gotalk_messages_unit_id
  ON gotalk_messages(unit_id);

-- ============================================================
-- FIM DA MIGRAÇÃO 030
-- ============================================================

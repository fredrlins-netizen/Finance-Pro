-- Migration 042: add uazapi_unit_id to prospection_contacts
-- Stores the unit that owns the uazapi credentials used to contact this prospect,
-- which may differ from the contact's GoTalk unit_id.
ALTER TABLE prospection_contacts
  ADD COLUMN IF NOT EXISTS uazapi_unit_id UUID REFERENCES companies(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_prospection_contacts_uazapi_unit_id
  ON prospection_contacts(uazapi_unit_id);

-- Migration 043: Definitive prospection_contacts sync for GoTalk via DB trigger
-- ---------------------------------------------------------------------------
-- PROBLEM (root cause):
--   prospection_contacts (the table that powers the Prospecção contact LIST) was
--   kept in sync for GoTalk only by application code: the in-CRM poller and a
--   pg_notify('gotalk_new_message') -> socket.js listener bridge. In production
--   the standalone WhatsApp worker ingests every message in real time via its
--   webhook, but that bridge does not reliably reach the CRM listener (separate
--   process / outdated worker build), so the GoTalk contact list froze at the
--   last backfill date while gotalk_messages kept growing.
--
-- DEFINITIVE FIX:
--   A database AFTER INSERT trigger on gotalk_messages. It fires once per row
--   that is actually inserted (ON CONFLICT DO NOTHING/UPDATE that inserts no row
--   does NOT fire it), so the contact summary can never drift again, no matter
--   which of the many code paths (worker webhook, worker poller, CRM poller,
--   socket bridge, recovery) performs the insert — and without redeploying the
--   separate worker project, because the logic lives in the DB.
--
--   Scope: GoTalk rows only (source <> 'uazapi'). The uazapi channel already has
--   a rich, correct application-level upsert (9th-digit reconciliation, instance
--   linkage, retroactive client link) and keeps its contacts fresh on its own;
--   replicating that in SQL would be risky, so uazapi rows are intentionally
--   excluded here to avoid double counting.

-- ── Transaction tuning (one-time migration) ────────────────────────────────
-- applyMigrations() wraps this whole file in a single BEGIN/COMMIT. The full
-- backfill can scan a large gotalk_messages table, so give it headroom beyond
-- the app's default 30s statement_timeout; lock_timeout fails fast if the table
-- lock below cannot be taken (rather than hanging the deploy).
SET LOCAL statement_timeout = '120s';
SET LOCAL lock_timeout = '30s';

-- ── Self-contained schema dependency ───────────────────────────────────────
-- last_inbound_at is otherwise added by initDB() AFTER applyMigrations() runs,
-- so on a fresh database this migration would reference a missing column and
-- abort startup. Add it idempotently here so the migration never depends on
-- ordering with the application's startup code.
ALTER TABLE prospection_contacts ADD COLUMN IF NOT EXISTS last_inbound_at TIMESTAMPTZ;
CREATE INDEX IF NOT EXISTS idx_prospection_contacts_last_inbound_at
  ON prospection_contacts (last_inbound_at DESC NULLS LAST);

-- ── Close the migration-window drift gap ───────────────────────────────────
-- Block concurrent inserts (notably from the standalone WhatsApp worker) for
-- the brief trigger-install + backfill. Held until COMMIT, this guarantees no
-- inbound message can slip between the backfill snapshot and the trigger
-- becoming visible: every row is either captured by the backfill or, once the
-- lock is released at COMMIT, processed by the now-live trigger. SHARE ROW
-- EXCLUSIVE conflicts with the ROW EXCLUSIVE lock that INSERT takes.
LOCK TABLE gotalk_messages IN SHARE ROW EXCLUSIVE MODE;

-- ── Trigger function ───────────────────────────────────────────────────────
CREATE OR REPLACE FUNCTION sync_prospection_from_gotalk_message()
RETURNS TRIGGER AS $$
DECLARE
  v_phone    TEXT;
  v_existing TEXT;
  v_unit     UUID;
  v_client   UUID;
BEGIN
  -- Canonical phone. Mirrors the worker's normalizePhone(): digits only, then
  -- drop a leading Brazil country code (55) when the number is longer than a
  -- local 11-digit number, so the conflict key matches across ingest paths.
  v_phone := REGEXP_REPLACE(COALESCE(NEW.phone_number, ''), '[^0-9]', '', 'g');
  IF v_phone LIKE '55%' AND LENGTH(v_phone) > 11 THEN
    v_phone := SUBSTRING(v_phone FROM 3);
  END IF;
  IF v_phone = '' THEN
    RETURN NEW;
  END IF;

  -- 9th-digit reconciliation (mirrors upsertProspectionContact): if a contact
  -- already exists sharing the last 8 digits, reuse its phone so 10- vs 11-digit
  -- variants of the same person collapse onto one row instead of splitting.
  SELECT phone INTO v_existing
    FROM prospection_contacts
   WHERE RIGHT(phone, 8) = RIGHT(v_phone, 8)
   LIMIT 1;
  IF v_existing IS NOT NULL THEN
    v_phone := v_existing;
  END IF;

  -- Resolve the unit: prefer the value on the message, then the channel mapping.
  v_unit := NEW.unit_id;
  IF v_unit IS NULL AND NEW.gotalk_channel_uuid IS NOT NULL THEN
    SELECT gch.unit_id INTO v_unit
      FROM gotalk_channels gch
     WHERE gch.id = NEW.gotalk_channel_uuid
       AND gch.unit_id IS NOT NULL
     LIMIT 1;
  END IF;

  -- Resolve the client link: prefer the value on the message, else look up by
  -- the last 10 digits across the client phone columns (retroactive auto-link).
  v_client := NEW.client_id;
  IF v_client IS NULL THEN
    SELECT c.id INTO v_client
      FROM clients c
     WHERE RIGHT(REGEXP_REPLACE(COALESCE(c.phone, ''),    '[^0-9]', '', 'g'), 10) = RIGHT(v_phone, 10)
        OR RIGHT(REGEXP_REPLACE(COALESCE(c.phone2, ''),   '[^0-9]', '', 'g'), 10) = RIGHT(v_phone, 10)
        OR RIGHT(REGEXP_REPLACE(COALESCE(c.celular, ''),  '[^0-9]', '', 'g'), 10) = RIGHT(v_phone, 10)
        OR RIGHT(REGEXP_REPLACE(COALESCE(c.telefone, ''), '[^0-9]', '', 'g'), 10) = RIGHT(v_phone, 10)
     LIMIT 1;
  END IF;

  INSERT INTO prospection_contacts
      (phone, classification, total_contacts, first_contact_at, last_contact_at,
       last_inbound_at, client_id, unit_id, source, last_source)
    VALUES
      (v_phone, 'LEAD', 1, NEW.sent_at, NEW.sent_at,
       NEW.sent_at, v_client, v_unit, 'gotalk', 'gotalk')
  ON CONFLICT (phone) DO UPDATE SET
      classification  = 'RECUPERACAO',
      total_contacts  = prospection_contacts.total_contacts + 1,
      last_contact_at = GREATEST(prospection_contacts.last_contact_at, EXCLUDED.last_contact_at),
      first_contact_at= LEAST(prospection_contacts.first_contact_at, EXCLUDED.first_contact_at),
      last_inbound_at = GREATEST(COALESCE(prospection_contacts.last_inbound_at, EXCLUDED.last_inbound_at), EXCLUDED.last_inbound_at),
      client_id       = COALESCE(prospection_contacts.client_id, EXCLUDED.client_id),
      unit_id         = COALESCE(prospection_contacts.unit_id, EXCLUDED.unit_id),
      last_source     = 'gotalk',
      updated_at      = NOW();

  RETURN NEW;
EXCEPTION WHEN OTHERS THEN
  -- Best-effort: never let prospection bookkeeping block message ingestion.
  RAISE WARNING 'sync_prospection_from_gotalk_message failed (phone=%): %', v_phone, SQLERRM;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- ── Trigger ────────────────────────────────────────────────────────────────
-- Fires only for newly inserted incoming GoTalk messages. Excludes uazapi
-- (handled by its own application-level upsert) and outbound messages.
DROP TRIGGER IF EXISTS trg_sync_prospection_gotalk ON gotalk_messages;
CREATE TRIGGER trg_sync_prospection_gotalk
  AFTER INSERT ON gotalk_messages
  FOR EACH ROW
  WHEN (NEW.direction = 'IN' AND NEW.source <> 'uazapi')
  EXECUTE FUNCTION sync_prospection_from_gotalk_message();

-- ── One-time catch-up backfill ─────────────────────────────────────────────
-- Advances GoTalk contacts that are currently frozen (last_contact_at stuck at
-- the previous backfill cutoff) to reflect every incoming message to date.
-- Idempotent: total_contacts is set to the absolute count of incoming messages,
-- so it stays consistent with the per-message +1 increments the trigger applies
-- afterwards; dates use GREATEST/LEAST so existing values are never regressed.
WITH norm AS (
  -- Canonical per-message phone, matching the trigger: digits only, drop a
  -- leading 55 country code when longer than a local 11-digit number.
  SELECT
    CASE
      WHEN REGEXP_REPLACE(gm.phone_number, '[^0-9]', '', 'g') LIKE '55%'
       AND LENGTH(REGEXP_REPLACE(gm.phone_number, '[^0-9]', '', 'g')) > 11
      THEN SUBSTRING(REGEXP_REPLACE(gm.phone_number, '[^0-9]', '', 'g') FROM 3)
      ELSE REGEXP_REPLACE(gm.phone_number, '[^0-9]', '', 'g')
    END AS phone_norm,
    gm.sent_at,
    gm.gotalk_channel_uuid
  FROM gotalk_messages gm
  WHERE gm.direction = 'IN'
    AND gm.source <> 'uazapi'
    AND gm.phone_number IS NOT NULL
    AND REGEXP_REPLACE(gm.phone_number, '[^0-9]', '', 'g') <> ''
),
keyed AS (
  -- 9th-digit reconciliation key: group 10- vs 11-digit variants of the same
  -- person by their shared last 8 digits, mirroring the trigger's reuse logic.
  SELECT RIGHT(n.phone_norm, 8) AS k, n.phone_norm, n.sent_at, n.gotalk_channel_uuid
  FROM norm n
),
canon AS (
  -- One canonical phone representative per last-8 key (prefer the longer form).
  SELECT DISTINCT ON (k) k, phone_norm AS canon_phone
  FROM keyed
  ORDER BY k, LENGTH(phone_norm) DESC, phone_norm
),
unit_per_phone AS (
  -- Most recent channel-derived unit per last-8 key.
  SELECT DISTINCT ON (kk.k) kk.k, gch.unit_id
  FROM keyed kk
  JOIN gotalk_channels gch ON gch.id = kk.gotalk_channel_uuid
  WHERE gch.unit_id IS NOT NULL
  ORDER BY kk.k, kk.sent_at DESC
)
INSERT INTO prospection_contacts
    (phone, classification, total_contacts, first_contact_at, last_contact_at,
     last_inbound_at, unit_id, source, last_source)
SELECT
  c.canon_phone                                             AS phone,
  CASE
    WHEN COUNT(DISTINCT DATE(kk.sent_at)) > 1 THEN 'RECUPERACAO'
    ELSE 'LEAD'
  END                                                        AS classification,
  COUNT(*)                                                   AS total_contacts,
  MIN(kk.sent_at)                                            AS first_contact_at,
  MAX(kk.sent_at)                                            AS last_contact_at,
  MAX(kk.sent_at)                                            AS last_inbound_at,
  upp.unit_id                                                AS unit_id,
  'gotalk'                                                   AS source,
  'gotalk'                                                   AS last_source
FROM keyed kk
JOIN canon c ON c.k = kk.k
LEFT JOIN unit_per_phone upp ON upp.k = kk.k
GROUP BY c.canon_phone, upp.unit_id
ON CONFLICT (phone) DO UPDATE SET
  total_contacts  = EXCLUDED.total_contacts,
  last_contact_at = GREATEST(prospection_contacts.last_contact_at, EXCLUDED.last_contact_at),
  first_contact_at= LEAST(prospection_contacts.first_contact_at, EXCLUDED.first_contact_at),
  last_inbound_at = GREATEST(COALESCE(prospection_contacts.last_inbound_at, EXCLUDED.last_inbound_at), EXCLUDED.last_inbound_at),
  classification  = EXCLUDED.classification,
  unit_id         = COALESCE(prospection_contacts.unit_id, EXCLUDED.unit_id),
  last_source     = 'gotalk',
  updated_at      = NOW();

-- Migration 038: Rastrear instância uazapi por contato/conversa de prospecção
-- Permite saber qual número WhatsApp (instância) recebeu cada contato.

ALTER TABLE prospection_contacts
  ADD COLUMN IF NOT EXISTS uazapi_instance_id VARCHAR(200);

ALTER TABLE prospection_conversations
  ADD COLUMN IF NOT EXISTS uazapi_instance_id VARCHAR(200);

CREATE INDEX IF NOT EXISTS idx_pc_uazapi_instance
  ON prospection_contacts (uazapi_instance_id)
  WHERE uazapi_instance_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_pcv_uazapi_instance
  ON prospection_conversations (uazapi_instance_id)
  WHERE uazapi_instance_id IS NOT NULL;

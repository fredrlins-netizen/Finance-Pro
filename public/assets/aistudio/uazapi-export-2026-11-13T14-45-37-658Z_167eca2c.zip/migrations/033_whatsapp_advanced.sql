-- ═══════════════════════════════════════════════════════════════
-- 033: WhatsApp Advanced — broadcast, scheduled messages, call logs
-- Modelo: per-unit (unit_id FK para companies)
-- ═══════════════════════════════════════════════════════════════

-- Histórico de campanhas de broadcast
CREATE TABLE IF NOT EXISTS whatsapp_broadcast_logs (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id       UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    campaign_name TEXT,
    message       TEXT NOT NULL,
    total         INTEGER NOT NULL DEFAULT 0,
    sent          INTEGER NOT NULL DEFAULT 0,
    failed        INTEGER NOT NULL DEFAULT 0,
    status        TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','running','done','failed')),
    results       JSONB,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at  TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_wab_broadcast_unit ON whatsapp_broadcast_logs(unit_id);
CREATE INDEX IF NOT EXISTS idx_wab_broadcast_status ON whatsapp_broadcast_logs(status);

-- Mensagens agendadas
CREATE TABLE IF NOT EXISTS whatsapp_scheduled_messages (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id       UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    chat_id       TEXT NOT NULL,
    message       TEXT NOT NULL,
    scheduled_at  TIMESTAMPTZ NOT NULL,
    sent_at       TIMESTAMPTZ,
    status        TEXT NOT NULL DEFAULT 'pending'
                    CHECK (status IN ('pending','sent','failed','cancelled')),
    error         TEXT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_wab_scheduled_unit   ON whatsapp_scheduled_messages(unit_id);
CREATE INDEX IF NOT EXISTS idx_wab_scheduled_status ON whatsapp_scheduled_messages(status);
CREATE INDEX IF NOT EXISTS idx_wab_scheduled_at     ON whatsapp_scheduled_messages(scheduled_at)
    WHERE status = 'pending';

-- Histórico de chamadas recebidas via webhook
CREATE TABLE IF NOT EXISTS whatsapp_call_logs (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    unit_id      UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    call_id      TEXT,
    from_number  TEXT,
    to_number    TEXT,
    type         TEXT DEFAULT 'audio' CHECK (type IN ('audio','video')),
    status       TEXT DEFAULT 'received' CHECK (status IN ('received','missed','rejected')),
    duration     INTEGER DEFAULT 0,
    ts           BIGINT,
    raw          JSONB,
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_wab_calls_unit ON whatsapp_call_logs(unit_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_wab_calls_unit_call_id
    ON whatsapp_call_logs(unit_id, call_id)
    WHERE call_id IS NOT NULL;

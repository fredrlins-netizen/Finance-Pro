-- Migration 051: schema which historically was created lazily by server startup.
-- Keep this forward-only and non-destructive: existing rows are never dropped.

CREATE TABLE IF NOT EXISTS messages (
  id TEXT PRIMARY KEY DEFAULT gen_random_uuid()::text,
  sender_id TEXT NOT NULL,
  sender_name TEXT NOT NULL,
  recipient_type VARCHAR(20) NOT NULL,
  recipient_id TEXT NOT NULL,
  subject VARCHAR(255),
  body TEXT NOT NULL,
  attachments JSONB DEFAULT '[]',
  is_system BOOLEAN DEFAULT FALSE,
  metadata JSONB DEFAULT '{}',
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS message_reads (
  message_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  read_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (message_id, user_id)
);
CREATE TABLE IF NOT EXISTS message_deliveries (
  message_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  delivered_at TIMESTAMPTZ DEFAULT NOW(),
  PRIMARY KEY (message_id, user_id)
);
CREATE INDEX IF NOT EXISTS idx_messages_recipient ON messages(recipient_type, recipient_id);
CREATE INDEX IF NOT EXISTS idx_messages_created ON messages(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_reads_user ON message_reads(user_id);
CREATE INDEX IF NOT EXISTS idx_deliveries_msg ON message_deliveries(message_id);

ALTER TABLE appointments DROP CONSTRAINT IF EXISTS appointments_client_id_fkey;
ALTER TABLE appointments DROP CONSTRAINT IF EXISTS appointments_service_id_fkey;
ALTER TABLE appointments DROP CONSTRAINT IF EXISTS appointments_unit_id_fkey;
ALTER TABLE appointments ALTER COLUMN client_id TYPE VARCHAR(100) USING client_id::TEXT;
ALTER TABLE appointments ALTER COLUMN service_id TYPE VARCHAR(100) USING service_id::TEXT;
ALTER TABLE appointments ALTER COLUMN unit_id TYPE VARCHAR(100) USING unit_id::TEXT;
ALTER TABLE appointments
  ADD COLUMN IF NOT EXISTS prospection_contact_id UUID
  REFERENCES prospection_contacts(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_appointments_prospection_contact_id ON appointments(prospection_contact_id);
CREATE INDEX IF NOT EXISTS idx_appointments_client_id ON appointments(client_id);
CREATE INDEX IF NOT EXISTS idx_appointments_collaborator_id ON appointments(collaborator_id);
CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(date);
CREATE INDEX IF NOT EXISTS idx_appointments_unit_id ON appointments(unit_id);

ALTER TABLE admissions ADD COLUMN IF NOT EXISTS desconto VARCHAR(30);
ALTER TABLE admissions ADD COLUMN IF NOT EXISTS acrescimo VARCHAR(30);
ALTER TABLE users ADD COLUMN IF NOT EXISTS failed_attempts INTEGER DEFAULT 0;
ALTER TABLE users ADD COLUMN IF NOT EXISTS locked_at TIMESTAMPTZ;
ALTER TABLE legal_processes
  ADD COLUMN IF NOT EXISTS admission_id UUID REFERENCES admissions(id) ON DELETE SET NULL;
ALTER TABLE legal_processes
  ADD COLUMN IF NOT EXISTS client_id UUID REFERENCES clients(id) ON DELETE SET NULL;
ALTER TABLE legal_processes ADD COLUMN IF NOT EXISTS client_name VARCHAR(255);
ALTER TABLE legal_processes ADD COLUMN IF NOT EXISTS contract_number VARCHAR(100);
CREATE INDEX IF NOT EXISTS idx_legal_processes_admission ON legal_processes(admission_id);
CREATE INDEX IF NOT EXISTS idx_legal_processes_client_id ON legal_processes(client_id);

ALTER TABLE prospection_contacts ADD COLUMN IF NOT EXISTS last_inbound_instance_id VARCHAR(100);
CREATE INDEX IF NOT EXISTS idx_prospection_contacts_last_inbound_instance
  ON prospection_contacts(last_inbound_instance_id);
CREATE OR REPLACE FUNCTION prospection_phone_base(raw TEXT)
RETURNS TEXT
LANGUAGE sql IMMUTABLE AS $$
  WITH digits AS (
    SELECT regexp_replace(COALESCE(raw, ''), '[^0-9]', '', 'g') AS value
  ), without_country AS (
    SELECT CASE
      WHEN length(value) > 11 AND left(value, 2) = '55' THEN substr(value, 3)
      ELSE value
    END AS value
    FROM digits
  )
  SELECT CASE
    WHEN length(value) = 11 AND substr(value, 3, 1) = '9'
      THEN left(value, 2) || substr(value, 4)
    ELSE value
  END
  FROM without_country
$$;

CREATE TABLE IF NOT EXISTS form_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name VARCHAR(255) NOT NULL,
  description TEXT,
  content TEXT,
  header TEXT,
  footer TEXT,
  menu_ids JSONB DEFAULT '[]',
  docx_template TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_form_templates_name ON form_templates(name);
CREATE INDEX IF NOT EXISTS idx_form_templates_updated ON form_templates(updated_at DESC);

CREATE TABLE IF NOT EXISTS collection_notes (
  id VARCHAR(100) PRIMARY KEY,
  title_id UUID REFERENCES financial_titles(id) ON DELETE SET NULL,
  client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
  date VARCHAR(10) NOT NULL,
  time VARCHAR(5) NOT NULL,
  collaborator_id VARCHAR(100),
  collaborator_name VARCHAR(255),
  contact_channel VARCHAR(20) NOT NULL DEFAULT 'TELEFONE',
  note TEXT NOT NULL,
  next_contact_date VARCHAR(10),
  negotiation_status VARCHAR(40) NOT NULL DEFAULT 'AGUARDANDO_CONTATO',
  negotiation_status_other TEXT,
  debt_snapshot JSONB,
  attachments JSONB,
  cancel_request JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_collection_notes_client ON collection_notes(client_id);
CREATE INDEX IF NOT EXISTS idx_collection_notes_title ON collection_notes(title_id);
CREATE INDEX IF NOT EXISTS idx_collection_notes_collab ON collection_notes(collaborator_id);
CREATE INDEX IF NOT EXISTS idx_collection_notes_status ON collection_notes(negotiation_status);
CREATE INDEX IF NOT EXISTS idx_collection_notes_date ON collection_notes(date DESC);

CREATE TABLE IF NOT EXISTS negotiation_records (
  id VARCHAR(100) PRIMARY KEY, date VARCHAR(10) NOT NULL,
  client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
  client_name VARCHAR(255) NOT NULL DEFAULT '',
  admission_id UUID REFERENCES admissions(id) ON DELETE SET NULL,
  bank_id VARCHAR(100), collaborator_id VARCHAR(100), collaborator_name VARCHAR(255),
  status VARCHAR(30) NOT NULL DEFAULT 'ABERTA', debt_value VARCHAR(30) NOT NULL DEFAULT '',
  next_contact_date VARCHAR(10), next_contact_description TEXT, notes TEXT,
  closed_date VARCHAR(10), closed_value VARCHAR(30), closed_installments INTEGER,
  title_id UUID REFERENCES financial_titles(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ DEFAULT NOW(), updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_neg_records_client ON negotiation_records(client_id);
CREATE INDEX IF NOT EXISTS idx_neg_records_collab ON negotiation_records(collaborator_id);
CREATE INDEX IF NOT EXISTS idx_neg_records_status ON negotiation_records(status);
CREATE INDEX IF NOT EXISTS idx_neg_records_date ON negotiation_records(date DESC);
CREATE TABLE IF NOT EXISTS negotiation_contacts (
  id VARCHAR(100) PRIMARY KEY,
  record_id VARCHAR(100) NOT NULL REFERENCES negotiation_records(id) ON DELETE CASCADE,
  date VARCHAR(10) NOT NULL, time VARCHAR(5) NOT NULL DEFAULT '',
  channel VARCHAR(20) NOT NULL DEFAULT 'TELEFONE',
  response VARCHAR(20) NOT NULL DEFAULT 'ATENDEU', description TEXT NOT NULL,
  next_action_date VARCHAR(10), next_action_description TEXT,
  collaborator_id VARCHAR(100), collaborator_name VARCHAR(255),
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_neg_contacts_record ON negotiation_contacts(record_id);
CREATE TABLE IF NOT EXISTS negotiation_proposals (
  id VARCHAR(100) PRIMARY KEY,
  record_id VARCHAR(100) NOT NULL REFERENCES negotiation_records(id) ON DELETE CASCADE,
  date VARCHAR(10) NOT NULL, original_value VARCHAR(30), discount_percentage NUMERIC(5,2),
  discounted_value VARCHAR(30), installments INTEGER NOT NULL DEFAULT 1,
  installment_value VARCHAR(30), entry_value VARCHAR(30),
  status VARCHAR(30) NOT NULL DEFAULT 'ENVIADA', notes TEXT,
  collaborator_id VARCHAR(100), collaborator_name VARCHAR(255), response_date VARCHAR(10)
);
CREATE INDEX IF NOT EXISTS idx_neg_proposals_record ON negotiation_proposals(record_id);
CREATE TABLE IF NOT EXISTS negotiation_goals (
  id VARCHAR(100) PRIMARY KEY, month VARCHAR(2) NOT NULL, year VARCHAR(4) NOT NULL,
  collaborator_id VARCHAR(100) NOT NULL, target_value VARCHAR(30),
  achieved_value VARCHAR(30) DEFAULT '0', target_count VARCHAR(10),
  achieved_count VARCHAR(10) DEFAULT '0', created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(), UNIQUE(month, year, collaborator_id)
);
CREATE INDEX IF NOT EXISTS idx_neg_goals_collab ON negotiation_goals(collaborator_id);

CREATE TABLE IF NOT EXISTS background_jobs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  queue VARCHAR(100) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  payload JSONB NOT NULL DEFAULT '{}',
  result JSONB,
  error TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS background_jobs_queue_status ON background_jobs(queue, status);
CREATE INDEX IF NOT EXISTS background_jobs_created_at ON background_jobs(created_at DESC);

ALTER TABLE financial_titles ADD COLUMN IF NOT EXISTS contract_number VARCHAR(100);

CREATE TABLE IF NOT EXISTS commercial_deals (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
  client_name VARCHAR(255) NOT NULL DEFAULT '',
  bank_name VARCHAR(255),
  debt_value NUMERIC(15,2) NOT NULL DEFAULT 0,
  proposal_value NUMERIC(15,2) NOT NULL DEFAULT 0,
  stage VARCHAR(30) NOT NULL DEFAULT 'TRIAGEM',
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
ALTER TABLE commercial_deals ADD COLUMN IF NOT EXISTS bank_id UUID REFERENCES banks(id) ON DELETE SET NULL;
ALTER TABLE commercial_deals ADD COLUMN IF NOT EXISTS collaborator_id VARCHAR(100);
ALTER TABLE commercial_deals ADD COLUMN IF NOT EXISTS collaborator_name VARCHAR(255);
ALTER TABLE commercial_deals ADD COLUMN IF NOT EXISTS unit_id UUID REFERENCES companies(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_commercial_deals_stage ON commercial_deals(stage);
CREATE INDEX IF NOT EXISTS idx_commercial_deals_client_id ON commercial_deals(client_id);
CREATE INDEX IF NOT EXISTS idx_commercial_deals_created_at ON commercial_deals(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_commercial_deals_collaborator ON commercial_deals(collaborator_id);
CREATE INDEX IF NOT EXISTS idx_commercial_deals_bank_id ON commercial_deals(bank_id);
CREATE INDEX IF NOT EXISTS idx_commercial_deals_unit_id ON commercial_deals(unit_id);

ALTER TABLE clients ADD COLUMN IF NOT EXISTS natureza VARCHAR(1) DEFAULT 'C';
ALTER TABLE clients ADD COLUMN IF NOT EXISTS blocked BOOLEAN NOT NULL DEFAULT FALSE;
ALTER TABLE clients ADD COLUMN IF NOT EXISTS gotalk_contact_id VARCHAR(100);
ALTER TABLE clients ADD COLUMN IF NOT EXISTS gotalk_channel_id VARCHAR(100);
CREATE INDEX IF NOT EXISTS idx_clients_gotalk_contact ON clients(gotalk_contact_id);
ALTER TABLE companies ADD COLUMN IF NOT EXISTS taxa_minima VARCHAR(30);

CREATE TABLE IF NOT EXISTS gotalk_file_uploads (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  file_name VARCHAR(255) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  file_size INTEGER NOT NULL,
  file_data TEXT NOT NULL,
  transcription TEXT,
  created_at TIMESTAMPTZ DEFAULT NOW()
);
ALTER TABLE gotalk_file_uploads ADD COLUMN IF NOT EXISTS gotalk_message_id VARCHAR(100) UNIQUE;
CREATE TABLE IF NOT EXISTS gotalk_hsm_templates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  template_name VARCHAR(255) UNIQUE NOT NULL,
  gotalk_template_id VARCHAR(100),
  category VARCHAR(100),
  language VARCHAR(50),
  status VARCHAR(50),
  body_text TEXT,
  header_text TEXT,
  footer_text TEXT,
  raw_data JSONB,
  synced_at TIMESTAMPTZ DEFAULT NOW(),
  created_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_hsm_templates_name ON gotalk_hsm_templates(template_name);
ALTER TABLE gotalk_hsm_templates
  ADD COLUMN IF NOT EXISTS gotalk_channel_uuid UUID REFERENCES gotalk_channels(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_hsm_templates_channel ON gotalk_hsm_templates(gotalk_channel_uuid);

ALTER TABLE gotalk_messages ADD COLUMN IF NOT EXISTS uazapi_instance_id VARCHAR(200);
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_uazapi_inst
  ON gotalk_messages(uazapi_instance_id) WHERE uazapi_instance_id IS NOT NULL;

ALTER TABLE unit_whatsapp_credentials
  DROP CONSTRAINT IF EXISTS unit_whatsapp_credentials_unit_id_key;
ALTER TABLE unit_whatsapp_credentials ADD COLUMN IF NOT EXISTS label VARCHAR(100);
ALTER TABLE unit_whatsapp_credentials ADD COLUMN IF NOT EXISTS webhook_registered_at TIMESTAMPTZ;
ALTER TABLE unit_whatsapp_credentials ADD COLUMN IF NOT EXISTS webhook_last_error TEXT;
ALTER TABLE unit_whatsapp_credentials ADD COLUMN IF NOT EXISTS last_inbound_at TIMESTAMPTZ;
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
    WHERE conname = 'unit_whatsapp_credentials_instance_id_key'
      AND conrelid = 'unit_whatsapp_credentials'::regclass
  ) THEN
    ALTER TABLE unit_whatsapp_credentials
      ADD CONSTRAINT unit_whatsapp_credentials_instance_id_key UNIQUE (uazapi_instance_id);
  END IF;
END $$;

CREATE TABLE IF NOT EXISTS uazapi_messages (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  message_id VARCHAR(200) UNIQUE NOT NULL,
  instance_id VARCHAR(200), unit_id UUID REFERENCES companies(id) ON DELETE SET NULL,
  chat_id VARCHAR(200), phone_number VARCHAR(30),
  direction VARCHAR(3) NOT NULL DEFAULT 'IN' CHECK (direction IN ('IN','OUT')),
  body TEXT, message_type VARCHAR(20) NOT NULL DEFAULT 'TEXT',
  attachment_url TEXT, attachment_mime VARCHAR(100), attachment_name VARCHAR(255),
  quoted_message_id VARCHAR(200), quoted_body TEXT, reaction VARCHAR(50),
  is_starred BOOLEAN DEFAULT FALSE, is_forwarded BOOLEAN DEFAULT FALSE,
  ack_status SMALLINT, sent_at TIMESTAMPTZ, imported_at TIMESTAMPTZ DEFAULT NOW(),
  raw_payload JSONB
);
CREATE INDEX IF NOT EXISTS idx_uazapi_messages_phone ON uazapi_messages(phone_number);
CREATE INDEX IF NOT EXISTS idx_uazapi_messages_sent_at ON uazapi_messages(sent_at DESC);
CREATE INDEX IF NOT EXISTS idx_uazapi_messages_instance ON uazapi_messages(instance_id);
CREATE INDEX IF NOT EXISTS idx_uazapi_messages_unit ON uazapi_messages(unit_id);
CREATE INDEX IF NOT EXISTS idx_uazapi_messages_direction ON uazapi_messages(direction);

-- GoTalk attendance objects historically created by initDB.  These are kept
-- here because they are used by the attendance pollers and must exist before
-- the application starts.  Every statement is additive so this also upgrades
-- databases which already contain part of the legacy schema.
CREATE TABLE IF NOT EXISTS gotalk_operator_attendances (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  gotalk_attendance_id VARCHAR(100) NOT NULL UNIQUE,
  gotalk_operator_id VARCHAR(100),
  operator_db_id UUID REFERENCES gotalk_operators(id) ON DELETE SET NULL,
  operator_name VARCHAR(255),
  protocol VARCHAR(50),
  gotalk_contact_id_ext VARCHAR(100),
  gotalk_contact_db_id UUID REFERENCES gotalk_contacts(id) ON DELETE SET NULL,
  client_number VARCHAR(30),
  client_name VARCHAR(255),
  client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
  department_id VARCHAR(100),
  department_name VARCHAR(255),
  channel_id VARCHAR(100),
  status VARCHAR(30) DEFAULT 'in_attendance',
  attendance_start_time TIMESTAMPTZ,
  last_message_at TIMESTAMPTZ,
  raw_data JSONB DEFAULT '{}',
  imported_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_goa_operator ON gotalk_operator_attendances(gotalk_operator_id);
CREATE INDEX IF NOT EXISTS idx_goa_operator_db ON gotalk_operator_attendances(operator_db_id);
CREATE INDEX IF NOT EXISTS idx_goa_contact_ext ON gotalk_operator_attendances(gotalk_contact_id_ext);
CREATE INDEX IF NOT EXISTS idx_goa_contact_db ON gotalk_operator_attendances(gotalk_contact_db_id);
CREATE INDEX IF NOT EXISTS idx_goa_client ON gotalk_operator_attendances(client_id);
CREATE INDEX IF NOT EXISTS idx_goa_status ON gotalk_operator_attendances(status);
CREATE INDEX IF NOT EXISTS idx_goa_start_time ON gotalk_operator_attendances(attendance_start_time DESC);
ALTER TABLE gotalk_operator_attendances
  ADD COLUMN IF NOT EXISTS gotalk_channel_uuid UUID REFERENCES gotalk_channels(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_goa_channel ON gotalk_operator_attendances(gotalk_channel_uuid);

CREATE TABLE IF NOT EXISTS gotalk_attendance_history (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  gotalk_attendance_id VARCHAR(100) NOT NULL UNIQUE,
  protocol VARCHAR(50),
  channel_id VARCHAR(100),
  gotalk_contact_id_ext VARCHAR(100),
  gotalk_contact_db_id UUID REFERENCES gotalk_contacts(id) ON DELETE SET NULL,
  client_number VARCHAR(30),
  client_name VARCHAR(255),
  client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
  gotalk_operator_id VARCHAR(100),
  operator_db_id UUID REFERENCES gotalk_operators(id) ON DELETE SET NULL,
  operator_name VARCHAR(255),
  department_id VARCHAR(100),
  department_name VARCHAR(255),
  status VARCHAR(30) DEFAULT 'in_attendance',
  attendance_start_time TIMESTAMPTZ,
  last_message_at TIMESTAMPTZ,
  finished_at TIMESTAMPTZ,
  contact_raw_data JSONB DEFAULT '{}',
  raw_data JSONB DEFAULT '{}',
  imported_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_gah_client_num ON gotalk_attendance_history(client_number);
CREATE INDEX IF NOT EXISTS idx_gah_contact_ext ON gotalk_attendance_history(gotalk_contact_id_ext);
CREATE INDEX IF NOT EXISTS idx_gah_contact_db ON gotalk_attendance_history(gotalk_contact_db_id);
CREATE INDEX IF NOT EXISTS idx_gah_client ON gotalk_attendance_history(client_id);
CREATE INDEX IF NOT EXISTS idx_gah_operator ON gotalk_attendance_history(gotalk_operator_id);
CREATE INDEX IF NOT EXISTS idx_gah_status ON gotalk_attendance_history(status);
CREATE INDEX IF NOT EXISTS idx_gah_start_time ON gotalk_attendance_history(attendance_start_time DESC);

ALTER TABLE gotalk_messages
  ADD COLUMN IF NOT EXISTS attendance_id UUID REFERENCES gotalk_attendances(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS gotalk_attendance_id_ext VARCHAR(100),
  ADD COLUMN IF NOT EXISTS attendance_history_id UUID REFERENCES gotalk_attendance_history(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS idwpp VARCHAR(200),
  ADD COLUMN IF NOT EXISTS gotalk_channel_uuid UUID REFERENCES gotalk_channels(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS uazapi_instance_id VARCHAR(200);
ALTER TABLE gotalk_attendance_history
  ADD COLUMN IF NOT EXISTS messages_last_fetched_at TIMESTAMPTZ,
  ADD COLUMN IF NOT EXISTS gotalk_channel_uuid UUID REFERENCES gotalk_channels(id) ON DELETE SET NULL;
ALTER TABLE gotalk_attendances
  ADD COLUMN IF NOT EXISTS gotalk_channel_uuid UUID REFERENCES gotalk_channels(id) ON DELETE SET NULL;
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_attendance
  ON gotalk_messages(attendance_id) WHERE attendance_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_att_ext ON gotalk_messages(gotalk_attendance_id_ext);
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_att_hist ON gotalk_messages(attendance_history_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_idwpp ON gotalk_messages(idwpp);
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_channel ON gotalk_messages(gotalk_channel_uuid);
CREATE INDEX IF NOT EXISTS idx_gotalk_attendances_channel ON gotalk_attendances(gotalk_channel_uuid);
CREATE INDEX IF NOT EXISTS idx_gah_channel ON gotalk_attendance_history(gotalk_channel_uuid);
CREATE INDEX IF NOT EXISTS idx_gah_msg_fetched ON gotalk_attendance_history(messages_last_fetched_at);
CREATE INDEX IF NOT EXISTS idx_gah_client_num_status ON gotalk_attendance_history(client_number, status);
CREATE INDEX IF NOT EXISTS idx_gm_phone_sent ON gotalk_messages(phone_number, sent_at DESC);
CREATE INDEX IF NOT EXISTS idx_goa_client_number ON gotalk_operator_attendances(client_number);
CREATE INDEX IF NOT EXISTS idx_gm_phone_last10 ON gotalk_messages(RIGHT(phone_number, 10));
CREATE INDEX IF NOT EXISTS idx_gah_client_last10 ON gotalk_attendance_history(RIGHT(client_number, 10));
CREATE INDEX IF NOT EXISTS idx_goa_client_last10 ON gotalk_operator_attendances(RIGHT(client_number, 10));

-- Views are replaced in place (no table/data is dropped), making their
-- definition converge for both fresh and previously initialized databases.
-- PostgreSQL cannot CREATE OR REPLACE a view when columns are inserted in the
-- middle of an older layout. Historical installations have a source-less
-- version, so rebuild it explicitly inside this transactional migration.
DROP VIEW IF EXISTS v_gotalk_client_timeline;
CREATE VIEW v_gotalk_client_timeline AS
SELECT gm.id AS message_id, gm.gotalk_message_id, gm.idwpp, gm.phone_number,
       gm.direction, gm.body, gm.message_type, gm.attachment_url,
       gm.attachment_name, gm.attachment_mime_type, gm.audio_transcript,
       gm.ack_status, gm.operator_name AS message_operator_name,
       gm.department AS message_department, gm.sent_at, gm.client_id,
       gm.source, gm.uazapi_instance_id,
       gah.id AS attendance_history_id, gah.gotalk_attendance_id, gah.protocol,
       gah.status AS attendance_status, gah.operator_name AS attendance_operator_name,
       gah.department_name AS attendance_department_name,
       gah.attendance_start_time, gah.finished_at,
       gc.id AS contact_db_id, gc.name AS contact_name,
       gc.gotalk_id AS contact_gotalk_id
FROM gotalk_messages gm
LEFT JOIN gotalk_attendance_history gah ON gah.id = gm.attendance_history_id
LEFT JOIN gotalk_contacts gc ON gc.id = gm.gotalk_contact_id;

CREATE OR REPLACE VIEW v_gotalk_attendance_summary AS
SELECT gah.id AS attendance_history_id, gah.gotalk_attendance_id, gah.protocol,
       gah.client_number, gah.client_name, gah.client_id, gah.gotalk_contact_db_id,
       gah.gotalk_contact_id_ext, gah.operator_name, gah.gotalk_operator_id,
       gah.department_name, gah.channel_id, gah.status, gah.attendance_start_time,
       gah.last_message_at, gah.finished_at, gah.messages_last_fetched_at,
       COUNT(gm.id) AS message_count,
       COUNT(gm.id) FILTER (WHERE gm.direction = 'IN') AS messages_in,
       COUNT(gm.id) FILTER (WHERE gm.direction = 'OUT') AS messages_out,
       COUNT(gm.id) FILTER (WHERE gm.message_type = 'AUDIO') AS messages_audio,
       COUNT(gm.id) FILTER (WHERE gm.message_type = 'IMAGE') AS messages_image,
       goo.name AS operator_full_name, goo.email AS operator_email,
       goo.collaborator_id AS operator_collaborator_id
FROM gotalk_attendance_history gah
LEFT JOIN gotalk_messages gm ON gm.attendance_history_id = gah.id
LEFT JOIN gotalk_operator_attendances goa
  ON goa.gotalk_attendance_id = gah.gotalk_attendance_id
LEFT JOIN gotalk_operators goo ON goo.id = goa.operator_db_id
GROUP BY gah.id, gah.gotalk_attendance_id, gah.protocol, gah.client_number,
         gah.client_name, gah.client_id, gah.gotalk_contact_db_id,
         gah.gotalk_contact_id_ext, gah.operator_name, gah.gotalk_operator_id,
         gah.department_name, gah.channel_id, gah.status, gah.attendance_start_time,
         gah.last_message_at, gah.finished_at, gah.messages_last_fetched_at,
         goo.name, goo.email, goo.collaborator_id;

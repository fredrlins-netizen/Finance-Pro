-- ============================================================
-- MIGRAÇÃO 028: uazapi_rename_token_column
-- Criado em: 2026-04-22
-- Descrição: Renomeia uazapi_token_hash → uazapi_token_encrypted
--            na tabela unit_whatsapp_credentials.
--            A coluna original foi criada na migração 027 como hash
--            (bcrypt — irreversível). Para permitir que o backend
--            recupere o token e o use em chamadas à API uazapi,
--            o armazenamento precisa ser reversível (AES-256-GCM).
--            Esta migração renomeia a coluna; o servidor/routes
--            passará a usar encrypt/decrypt via server/utils/encryption.js.
-- ============================================================

DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'unit_whatsapp_credentials'
      AND column_name = 'uazapi_token_hash'
  ) THEN
    ALTER TABLE unit_whatsapp_credentials
      RENAME COLUMN uazapi_token_hash TO uazapi_token_encrypted;
  END IF;
END;
$$;

-- ============================================================
-- FIM DA MIGRAÇÃO 028
-- ============================================================

/**
 * Rate limiting usando express-rate-limit (biblioteca de produção).
 * Substitui a implementação caseira anterior em Map() em memória.
 *
 * keyGenerator usa o userId do JWT quando disponível (mais preciso que IP),
 * caindo back para o IP para requisições não autenticadas.
 */

import rateLimit from 'express-rate-limit';

// validate.keyGeneratorIpFallback: false suprime o aviso de IPv6 porque
// usamos userId como chave primária (o IP só é fallback para rotas anônimas).
const BASE_OPTIONS = {
  standardHeaders: true,
  legacyHeaders: false,
  validate: { keyGeneratorIpFallback: false },
};

const userOrIp = (req) => req.jwtPayload?.userId || req.ip || 'anonymous';

/**
 * Rotas de escrita de alta frequência que NÃO devem consumir o bucket global.
 * São endpoints internos/operacionais de baixo risco disparados frequentemente
 * pelo próprio frontend (ex.: indicador de digitação a cada keystroke).
 */
const HIGH_FREQ_WRITE_PATHS = [
  '/api/uazapi/chats/presence',  // typing presence — dispara a cada ~10s por usuário
];

function isHighFreqWrite(req) {
  return HIGH_FREQ_WRITE_PATHS.some(p => req.path === p || req.path.startsWith(p + '/'));
}

/** Leitura: 200 req/min por usuário (pollers de timeline, auto-refresh, etc.) */
const readLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 200,
  keyGenerator: userOrIp,
  message: { error: 'Limite de leitura excedido. Aguarde 1 minuto.' },
});

/**
 * Escrita: 120 req/min por usuário.
 *
 * Aumentado de 30 → 120 porque o valor anterior era atingido durante uso
 * normal: salvar formulários, enviar mensagens, atualizações de estado e
 * presença de digitação competem pelo mesmo bucket.
 *
 * Endpoints verdadeiramente sensíveis (login, mensagens internas)
 * têm seus próprios limitadores específicos; este serve como proteção residual.
 *
 * Rotas de alta frequência e baixo risco (typing presence) são excluídas
 * via `skip` para não consumir o bucket do operador.
 */
const writeLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 120,
  keyGenerator: userOrIp,
  skip: (req) => process.env.HOMOLOGATION_ISOLATED === 'true' || isHighFreqWrite(req),
  message: { error: 'Limite de escrita excedido. Aguarde 1 minuto.' },
});

/** Autenticação: 15 tentativas/15min por IP */
const authLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 15 * 60 * 1000,
  max: 15,
  skip: () => process.env.HOMOLOGATION_ISOLATED === 'true',
  keyGenerator: (req) => req.ip || 'anonymous',
  message: { error: 'Muitas tentativas de autenticação. Tente novamente em 15 minutos.' },
});

/** Emissão de desafios anti-bot: não deve consumir tentativas de senha. */
const challengeLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 60,
  skip: () => process.env.HOMOLOGATION_ISOLATED === 'true',
  keyGenerator: (req) => req.ip || 'anonymous',
  message: { error: 'Muitas solicitações de desafio. Aguarde 1 minuto.' },
});

/** Envio de mensagens internas: 30 msg/min por usuário */
const messageSendLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 30,
  keyGenerator: userOrIp,
  message: { error: 'Muitas mensagens. Aguarde 1 minuto.' },
});

/**
 * Webhook externo (GoTalk): 200 req/min por IP.
 * Permissivo o suficiente para tráfego legítimo de produção (GoTalk envia
 * eventos em rajadas), mas bloqueia DDoS ou uso abusivo da rota pública.
 * Usa IP puro — webhooks chegam sem autenticação de usuário.
 */
const webhookLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 200,
  keyGenerator: (req) => req.ip || 'anonymous',
  message: { error: 'Muitas requisições ao webhook. Tente novamente em instantes.' },
});

/**
 * Health check: 20 req/min por IP.
 * Protege contra varredura automática de endpoints de infraestrutura.
 */
const healthLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 20,
  keyGenerator: (req) => req.ip || 'anonymous',
  message: { error: 'Limite de health check excedido.' },
});

/**
 * MFA/TOTP: 5 tentativas/min por IP.
 * Protege contra força bruta em códigos de 6 dígitos (1.000.000 combinações)
 * e nos endpoints de setup. Usa IP puro pois o usuário ainda não tem sessão.
 */
const mfaLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 5,
  keyGenerator: (req) => req.ip || 'anonymous',
  message: { error: 'Muitas tentativas de verificação. Aguarde 1 minuto.' },
});

/** Factory para criar limitadores customizados (compatibilidade com código existente) */
function createRateLimiter({ windowMs = 60000, maxRequests = 100, keyFn = null, message = 'Muitas requisições. Tente novamente mais tarde.' } = {}) {
  return rateLimit({
    ...BASE_OPTIONS,
    windowMs,
    max: maxRequests,
    keyGenerator: keyFn || userOrIp,
    message: { error: message },
  });
}

/**
 * IA Chat (Léo): 30 req/min por usuário.
 */
const aiChatLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 30,
  keyGenerator: userOrIp,
  message: { error: 'Muitas perguntas ao assistente. Aguarde 1 minuto.' },
});

/**
 * IA Análise de dados: 20 req/min por usuário.
 */
const aiAnalysisLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 20,
  keyGenerator: userOrIp,
  message: { error: 'Muitas análises. Aguarde 1 minuto.' },
});

/**
 * IA Resumo de relatórios / Auditoria IA: 10 req/min por usuário (operações pesadas).
 */
const aiHeavyLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 10,
  keyGenerator: userOrIp,
  message: { error: 'Muitas requisições de análise pesada. Aguarde 1 minuto.' },
});

/**
 * Extração de PDF via IA (Gemini): 10 req/min por usuário.
 * PDFs consomem muitos tokens — limitar para proteger cota da API.
 */
const pdfExtractLimiter = rateLimit({
  ...BASE_OPTIONS,
  windowMs: 60 * 1000,
  max: 10,
  keyGenerator: userOrIp,
  message: { error: 'Muitas extrações de PDF. Aguarde 1 minuto antes de tentar novamente.' },
});

export { createRateLimiter, readLimiter, writeLimiter, authLimiter, challengeLimiter, mfaLimiter, messageSendLimiter, webhookLimiter, healthLimiter, aiChatLimiter, aiAnalysisLimiter, aiHeavyLimiter, pdfExtractLimiter };

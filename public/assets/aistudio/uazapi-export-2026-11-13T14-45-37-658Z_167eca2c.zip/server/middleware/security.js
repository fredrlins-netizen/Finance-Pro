import helmet from 'helmet';
import jwt from 'jsonwebtoken';
import { COOKIE_NAME } from '../routes/auth.js';
import { hasCurrentSessionVersion } from '../lib/sessionVersion.js';

function createSecurityMiddleware() {
  const helmetMiddleware = helmet({
    contentSecurityPolicy: {
      directives: {
        defaultSrc: ["'self'"],
        // TinyMCE v8 é carregado via npm bundle (não CDN). 'unsafe-inline' removido —
        // não é mais necessário desde que cdn.tiny.cloud foi eliminado.
        // 'blob:' mantido para suportar criação de Web Workers dinâmicos (PDF, etc.).
        scriptSrc: ["'self'", 'blob:'],
        // 'unsafe-inline' em styleSrc é necessário porque o TinyMCE aplica estilos
        // inline ao conteúdo editável durante formatação (negrito, itálico, cor de texto,
        // etc.). É inerente ao funcionamento de qualquer editor WYSIWYG baseado em
        // contenteditable — não é possível remover sem quebrar a formatação do editor.
        // Mitigação futura: CSP com nonces (requer refactor completo do servidor HTML).
        styleSrc: ["'self'", "'unsafe-inline'", 'fonts.googleapis.com'],
        fontSrc: ["'self'", 'fonts.gstatic.com', 'data:'],
        imgSrc: ["'self'", 'data:', 'blob:'],
        connectSrc: ["'self'"],
        frameSrc: ["'none'"],
        objectSrc: ["'none'"],
        workerSrc: ["'self'", 'blob:'],
      },
    },
    crossOriginEmbedderPolicy: false,
    crossOriginResourcePolicy: { policy: 'cross-origin' }
  });

  return helmetMiddleware;
}

function buildReplitOrigins() {
  const trusted = new Set();
  const replitDomains = process.env.REPLIT_DOMAINS;
  if (replitDomains) {
    replitDomains.split(',').map(d => d.trim()).filter(Boolean).forEach(d => {
      trusted.add(`https://${d}`);
    });
  }
  const replitDevDomain = process.env.REPLIT_DEV_DOMAIN;
  if (replitDevDomain) {
    trusted.add(`https://${replitDevDomain}`);
  }
  const replId = process.env.REPL_ID;
  if (replId) {
    trusted.add(`https://${replId}.id.repl.co`);
  }
  return trusted;
}

function createCorsMiddleware(allowedOrigins = []) {
  return (req, res, next) => {
    const origin = req.headers.origin;

    if (process.env.NODE_ENV !== 'production') {
      res.setHeader('Access-Control-Allow-Origin', origin || '*');
    } else {
      if (!origin) {
        // no Origin header — same-origin or server-to-server request, allow
      } else if (allowedOrigins.length > 0) {
        // Strict mode: ALLOWED_ORIGINS is explicitly configured — honour it exclusively
        if (allowedOrigins.includes(origin)) {
          res.setHeader('Access-Control-Allow-Origin', origin);
        } else {
          return res.status(403).json({ error: 'Origem não permitida' });
        }
      } else {
        // Fallback mode: no explicit ALLOWED_ORIGINS — derive trusted set from Replit env vars
        const replitTrusted = buildReplitOrigins();
        if (replitTrusted.size > 0) {
          if (replitTrusted.has(origin)) {
            res.setHeader('Access-Control-Allow-Origin', origin);
          } else {
            return res.status(403).json({ error: 'Origem não permitida' });
          }
        } else {
          // No Replit domains either — deny by default (secure-by-default)
          return res.status(403).json({ error: 'Origem não permitida' });
        }
      }
    }

    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, PATCH, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Unit-Id');
    res.setHeader('Access-Control-Allow-Credentials', 'true');
    res.setHeader('Access-Control-Max-Age', '86400');

    if (req.method === 'OPTIONS') {
      return res.status(204).end();
    }

    next();
  };
}

function requestSizeLimiter(normalLimit = '1mb', uploadLimit = '5mb') {
  return (req, res, next) => {
    const contentLength = parseInt(req.headers['content-length'] || '0', 10);
    const isUpload = req.path.includes('/upload') || req.path.includes('/attachments') || req.path.includes('/messages') || req.path.includes('/settings/theme') || req.path.includes('/form-templates') || req.path.includes('/send-media') || req.path.includes('/client-attachments') || req.path.includes('/import/upload');

    // send-media carries base64 (≈33% overhead) so it needs a larger ceiling than other uploads.
    // Streaming upload is bounded by Busboy after authentication; no body buffering here.
    const limitForReq = req.path === '/api/client-attachments/upload-stream' ? '1025mb'
      : req.path.includes('/import/upload') ? '22mb'
      : req.path.includes('/client-attachments') ? '30mb'
      : req.path.includes('/send-media') ? '30mb' : uploadLimit;
    const maxBytes = isUpload ? parseSize(limitForReq) : parseSize(normalLimit);

    if (contentLength > maxBytes) {
      return res.status(413).json({
        error: 'Payload muito grande',
        details: `Tamanho máximo permitido: ${isUpload ? limitForReq : normalLimit}`
      });
    }

    next();
  };
}

function parseSize(sizeStr) {
  const match = sizeStr.match(/^(\d+)(mb|kb|gb)?$/i);
  if (!match) return 1048576;
  const num = parseInt(match[1], 10);
  const unit = (match[2] || 'mb').toLowerCase();
  if (unit === 'gb') return num * 1073741824;
  if (unit === 'mb') return num * 1048576;
  if (unit === 'kb') return num * 1024;
  return num;
}

function sanitizeAllInputs(req, res, next) {
  // Binary upload routes (for example the XLSX import queue) must reach their
  // handler as a Buffer. Converting a Buffer through Object.entries would turn
  // it into a JSON-like object and corrupt the uploaded file.
  if (req.body && typeof req.body === 'object' && !Buffer.isBuffer(req.body)) {
    req.body = deepSanitize(req.body);
  }
  next();
}

function deepSanitize(obj) {
  if (typeof obj === 'string') {
    return obj
      .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
      .replace(/<[^>]*\bon\w+\s*=/gi, '<')
      .replace(/javascript\s*:/gi, '')
      .replace(/data\s*:\s*text\/html/gi, '');
  }
  if (Array.isArray(obj)) {
    return obj.map(item => deepSanitize(item));
  }
  if (obj && typeof obj === 'object') {
    const sanitized = {};
    for (const [key, value] of Object.entries(obj)) {
      sanitized[key] = deepSanitize(value);
    }
    return sanitized;
  }
  return obj;
}

function logFailedAuth(req, res, next) {
  const originalJson = res.json.bind(res);
  res.json = function(body) {
    if (res.statusCode === 401 || res.statusCode === 403) {
      console.warn(`[SECURITY] Failed auth attempt: ${req.method} ${req.path} | IP: ${req.ip} | Status: ${res.statusCode} | ${body?.error || ''}`);
    }
    return originalJson(body);
  };
  next();
}

// 🔒 SEGURANÇA [VULN-8]: genericiza TODAS as respostas de erro 5xx do servidor.
// Muitos handlers retornavam `{ error: err.message }`, expondo detalhes internos
// (mensagens do PostgreSQL, stack hints, caminhos). Este interceptor substitui o
// corpo de qualquer resposta 5xx por uma mensagem genérica, registrando o original
// no log do servidor para depuração. Respostas 4xx são preservadas (carregam
// mensagens de validação úteis ao frontend).
function sanitizeServerErrors(req, res, next) {
  const originalJson = res.json.bind(res);
  res.json = function (body) {
    if (res.statusCode >= 500 && body && typeof body === 'object') {
      const detail = body.error || body.details || body.message;
      if (detail) {
        console.error(`[SECURITY] 5xx sanitizado: ${req.method} ${req.path} | ${detail}`);
      }
      return originalJson({ error: 'Erro interno no servidor. Tente novamente mais tarde.' });
    }
    return originalJson(body);
  };
  next();
}

import { permitsLocalContractRequest } from '../lib/localContractAuthorization.js';

function isNonAdminClientAttachmentAclWrite(req, payload) {
  if (payload.userRole === 'ADMIN') return false;
  const pathname = req.path;
  if (req.method === 'PUT') {
    return /^\/api\/client-attachments\/acl\/(?:folders|files)\/[^/]+$/.test(pathname);
  }
  if (req.method === 'POST') {
    return /^\/api\/client-attachments\/acl\/legacy\/[^/]+\/protect$/.test(pathname);
  }
  if (req.method === 'DELETE') {
    return /^\/api\/client-attachments\/acl\/legacy\/[^/]+\/protect\/[^/]+$/.test(pathname);
  }
  return false;
}

function createValidateApiAccess(pool, { jwtSecret } = {}) {
  return async function validateApiAccess(req, res, next) {
    const publicPaths = [
      '/api/health',
      '/api/env',
      '/api/version',
      // /api/config permanece público para que a tela de login possa obter os dados de
      // branding (nome, logo, tema) antes da autenticação. A rota verifica o JWT
      // internamente e retorna o conjunto completo de dados apenas para usuários autenticados.
      '/api/config',
      // /api/settings/theme foi removida de publicPaths para que o padrão
      // extractUser + requireAdmin funcione corretamente nas rotas PUT/POST.
      // GET /api/settings/theme requer autenticação (nenhum código frontend
      // não autenticado chama esse endpoint — a tela de login usa /api/config).
      '/api/admin/seed-production',
      // 🔒 SEGURANÇA [VULN-12]: '/api/gotalk/media' removido de publicPaths — agora exige
      // sessão válida (requireAuth na rota). Mídia é carregada same-origin com cookie.
      '/api/gotalk/webhook-url',
      '/api/gotalk/webhook',
      '/api/uazapi/webhook',
      '/health',
      '/api/auth/login',
      '/api/auth/challenge',
      '/api/auth/admin-recovery',
      '/api/auth/logout',
      '/api/auth/me',
      '/api/auth/mfa/verify',
      '/api/auth/mfa/renew',
      // Status da integração IA — público para que o LeoChat possa verificar
      // disponibilidade sem exigir autenticação prévia
      '/api/ai/status',
    ];

    const isPublic = publicPaths.some(p => req.path === p || req.path.startsWith(p + '/'));
    const isStatic = !req.path.startsWith('/api/');

    if (isPublic || isStatic) {
      return next();
    }

    const bearer = req.headers.authorization?.match(/^Bearer (.+)$/)?.[1];
    const token = bearer || req.cookies?.[COOKIE_NAME];
    if (!token) {
      console.warn(`[SECURITY] Unauthenticated API access attempt: ${req.method} ${req.path} | IP: ${req.ip}`);
      return res.status(401).json({ error: 'Autenticação necessária', details: 'Sessão não encontrada' });
    }

    const secret = jwtSecret || process.env.JWT_SECRET;
    if (!secret) {
      console.error('[SECURITY] JWT_SECRET not configured');
      return res.status(500).json({ error: 'Erro de configuração do servidor' });
    }

    try {
      const payload = jwt.verify(token, secret);
      if (bearer || payload.purpose === 'invicta-local-upload') {
        if (payload.purpose !== 'invicta-local-upload' || !permitsLocalContractRequest(req.method, req.path)) {
          return res.status(403).json({ error: 'Autorização local limitada ao envio de contratos.' });
        }
        const admin = await pool.query("SELECT id FROM users WHERE id=$1 AND role='ADMIN' AND status='ATIVO'", [payload.userId]);
        if (!admin.rows.length) return res.status(403).json({ error: 'Administrador não autorizado.' });
        req.localContractUpload = true;
        // Local grants never permit switching away from the approved unit.
        delete req.headers['x-unit-id'];
      }
      // These writes are individually guarded by requireAdmin in the attachment
      // router. A verified non-admin JWT can therefore be rejected there without
      // querying session state or opening a database connection first.
      if (isNonAdminClientAttachmentAclWrite(req, payload)) {
        req.jwtPayload = payload;
        return next();
      }
      if (!await hasCurrentSessionVersion(pool, payload)) {
        console.warn(`[SECURITY] Revoked JWT: ${req.method} ${req.path} | IP: ${req.ip}`);
        return res.status(401).json({ error: 'Sessão inválida ou expirada', details: 'Faça login novamente' });
      }
      req.jwtPayload = payload;
      next();
    } catch (err) {
      console.warn(`[SECURITY] Invalid JWT: ${req.method} ${req.path} | IP: ${req.ip} | ${err.message}`);
      return res.status(401).json({ error: 'Sessão inválida ou expirada', details: 'Faça login novamente' });
    }
  };
}

export {
  createSecurityMiddleware,
  createCorsMiddleware,
  requestSizeLimiter,
  sanitizeAllInputs,
  deepSanitize,
  logFailedAuth,
  sanitizeServerErrors,
  createValidateApiAccess
};

-- Migration 033: Multi-instance WhatsApp/uazapi per unit
-- Applied: server/index.js startup (inline migration pattern used by this project)
-- Date: 2026-04
--
-- Purpose:
--   Allow multiple uazapi instances per unit (e.g. Vendas, Cobrança, Atendimento),
--   each with its own token, server URL, and optional label. The webhook routing
--   key changes from unit_id to uazapi_instance_id (globally unique).

-- 1. Remove per-unit uniqueness constraint (was: one instance per unit)
ALTER TABLE unit_whatsapp_credentials
  DROP CONSTRAINT IF EXISTS unit_whatsapp_credentials_unit_id_key;

-- 2. Add human-readable label column for distinguishing instances within a unit
ALTER TABLE unit_whatsapp_credentials
  ADD COLUMN IF NOT EXISTS label VARCHAR(100);

-- 3. Add global uniqueness on uazapi_instance_id (webhook routing key)
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE table_name = 'unit_whatsapp_credentials'
      AND constraint_name = 'unit_whatsapp_credentials_instance_id_key'
  ) THEN
    ALTER TABLE unit_whatsapp_credentials
      ADD CONSTRAINT unit_whatsapp_credentials_instance_id_key
      UNIQUE (uazapi_instance_id);
  END IF;
END $$;

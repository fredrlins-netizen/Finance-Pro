import { Router } from 'express';
import { createCrudRoutes } from './crudFactory.js';
import { encrypt, decrypt, requireEncryptionKey } from '../utils/encryption.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
import { validateUUIDParam } from '../middleware/validation.js';
import { registerUazapiWebhook as attemptWebhookRegister } from '../lib/uazapiWebhookRegistration.js';
import { getInstancePhoneInfoMany } from '../lib/uazapiInstanceCache.js';

function getPublicBaseUrl() {
  if (process.env.APP_PUBLIC_URL) return process.env.APP_PUBLIC_URL.replace(/\/$/, '');
  if (process.env.REPLIT_DEPLOYMENT_URL) return process.env.REPLIT_DEPLOYMENT_URL.replace(/\/$/, '');
  if (process.env.REPLIT_DEV_DOMAIN) return `https://${process.env.REPLIT_DEV_DOMAIN}`;
  return null;
}

/**
 * Converte um valor monetário em formato BRL ("1.234,56" ou "1234,56")
 * para um número decimal compatível com PostgreSQL DECIMAL(15,2).
 * Retorna null se o valor estiver ausente ou não puder ser convertido.
 */
function parseBRLToDecimal(value) {
  if (value === null || value === undefined || value === '') return null;
  const str = String(value).trim();
  // Remove separadores de milhar (pontos) e troca vírgula decimal por ponto
  const normalized = str.replace(/\./g, '').replace(',', '.');
  const num = parseFloat(normalized);
  return isNaN(num) ? null : num;
}

function sanitizeTaxaMinima(body) {
  if ('taxa_minima' in body) {
    body.taxa_minima = parseBRLToDecimal(body.taxa_minima);
  }
  // crudFactory chama beforeCreate/beforeUpdate ANTES de normalizar camelCase→snake_case
  if ('taxaMinima' in body) {
    body.taxaMinima = parseBRLToDecimal(body.taxaMinima);
  }
}

export function createUnitsRoutes(pool) {
  const crudRouter = createCrudRoutes(pool, {
    table: 'companies',
    columns: [
      'razao_social', 'nome_fantasia', 'cnpj', 'telefone', 'email', 'cep',
      'endereco', 'numero', 'complemento', 'bairro', 'cidade',
      'estado', 'taxa_minima', 'email_sender_name', 'email_host', 'email_port',
      'email_user', 'email_security', 'google_connected',
      'google_account_email', 'google_last_sync', 'whatsapp_number'
    ],
    requiredFields: ['razao_social'],
    searchColumns: ['razao_social', 'nome_fantasia', 'cnpj', 'email', 'cidade'],
    defaultSort: 'razao_social',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'user_allowed_units', fk: 'unit_id', label: 'Usuários vinculados' },
      { table: 'series_unit_numbering', fk: 'unit_id', label: 'Numeração de séries' }
    ],
    beforeCreate: async (body) => { sanitizeTaxaMinima(body); return body; },
    beforeUpdate: async (body) => { sanitizeTaxaMinima(body); return body; },
  });

  // --- Rotas adicionais para credenciais uazapi por unidade ---
  const extraRouter = Router();

  // GET /api/units/:id/uazapi-credentials
  // Requer autenticação + perfil admin.
  // Retorna array de instâncias para a unidade. O token NUNCA é exposto.
  extraRouter.get('/:id/uazapi-credentials', requireAuth, requireAdmin, requireEncryptionKey, validateUUIDParam, async (req, res) => {
    try {
      const { id } = req.params;
      const result = await pool.query(
        `SELECT id AS cred_id,
                label,
                uazapi_instance_id,
                uazapi_server_url,
                uazapi_token_encrypted,
                (uazapi_token_encrypted IS NOT NULL AND uazapi_token_encrypted <> '') AS has_token,
                webhook_registered_at,
                webhook_last_error
         FROM unit_whatsapp_credentials
         WHERE unit_id = $1
         ORDER BY created_at ASC`,
        [id]
      );
      const baseUrl = getPublicBaseUrl();
      const instances = result.rows.map(row => {
        let webhookUrl = null;
        if (baseUrl && row.uazapi_token_encrypted) {
          try {
            const token = decrypt(row.uazapi_token_encrypted);
            if (token) webhookUrl = `${baseUrl}/api/uazapi/webhook?token=${encodeURIComponent(token)}`;
          } catch { /* token decrypt failed */ }
        }
        return {
          credId: row.cred_id,
          label: row.label || null,
          uazapiInstanceId: row.uazapi_instance_id || null,
          hasToken: Boolean(row.has_token),
          uazapiServerUrl: row.uazapi_server_url || null,
          webhookUrl,
          webhookRegisteredAt: row.webhook_registered_at || null,
          webhookLastError: row.webhook_last_error || null,
        };
      });
      return res.json({ instances });
    } catch (err) {
      console.error('[Units] Erro ao buscar credenciais uazapi:', err.message);
      res.status(500).json({ error: 'Erro ao buscar credenciais' });
    }
  });

  // GET /api/units/uazapi-instances-all
  // Retorna todas as unidades que têm pelo menos uma instância uazapi configurada,
  // com suas instâncias. Admin vê tudo; não-admin vê apenas unidades permitidas.
  // Usado pelo modal "Trocar canal" para permitir escolher qualquer unidade uazapi.
  extraRouter.get('/uazapi-instances-all', requireAuth, async (req, res) => {
    try {
      const { isAdmin, allowedUnitIds, currentUnitId } = req.currentUser || {};

      let unitFilter = '';
      let params = [];

      if (!isAdmin) {
        const allowed = Array.isArray(allowedUnitIds) ? allowedUnitIds : [];
        if (currentUnitId && !allowed.includes(currentUnitId)) allowed.push(currentUnitId);
        if (allowed.length === 0) return res.json({ units: [] });
        params.push(allowed);
        unitFilter = `AND uwc.unit_id = ANY($1::uuid[])`;
      }

      // Task #251: pass currentUnitId as parameter so SQL can flag and sort it first.
      // When the user has no fixed unit (admin with currentUnitId=null), sort all alphabetically.
      const currentUnitParam = currentUnitId || null;
      params.push(currentUnitParam);
      const currentUnitParamIdx = params.length;

      const result = await pool.query(
        `SELECT
           uwc.unit_id,
           COALESCE(NULLIF(c.nome_fantasia,''), c.razao_social) AS unit_name,
           COALESCE(uwc.unit_id = $${currentUnitParamIdx}::uuid, false) AS is_current_unit,
           json_agg(
             json_build_object('instanceId', uwc.uazapi_instance_id, 'label', uwc.label,
                               'lastInboundAt', uwc.last_inbound_at)
             ORDER BY uwc.created_at ASC
           ) AS instances
         FROM unit_whatsapp_credentials uwc
         LEFT JOIN companies c ON c.id = uwc.unit_id
         WHERE uwc.uazapi_token_encrypted IS NOT NULL
           AND uwc.uazapi_token_encrypted <> ''
           ${unitFilter}
         GROUP BY uwc.unit_id, c.nome_fantasia, c.razao_social
         ORDER BY
           (uwc.unit_id = $${currentUnitParamIdx}::uuid) DESC,
           unit_name ASC`,
        params
      );

      // Task #312: enriquecer cada instância com o número real (cache 5 min).
      const units = result.rows;
      const allInstanceIds = [];
      for (const u of units) {
        for (const inst of (u.instances || [])) {
          if (inst?.instanceId) allInstanceIds.push(inst.instanceId);
        }
      }
      if (allInstanceIds.length > 0) {
        try {
          const credRows = await pool.query(
            `SELECT uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url
             FROM unit_whatsapp_credentials
             WHERE uazapi_instance_id = ANY($1::text[])
               AND uazapi_token_encrypted IS NOT NULL AND uazapi_token_encrypted <> ''`,
            [allInstanceIds]
          );
          const credsList = [];
          for (const row of credRows.rows) {
            try {
              credsList.push({
                instanceId: row.uazapi_instance_id,
                token: decrypt(row.uazapi_token_encrypted),
                serverUrl: (row.uazapi_server_url || 'https://free.uazapi.com').replace(/\/$/, ''),
              });
            } catch { /* skip undecryptable */ }
          }
          const phoneMap = await getInstancePhoneInfoMany(credsList);
          for (const u of units) {
            for (const inst of (u.instances || [])) {
              const info = phoneMap.get(inst.instanceId);
              inst.phoneNumber = info?.phone || null;
              inst.isConnected = info ? info.isConnected : null;
            }
          }
        } catch (e) {
          console.warn('[Units] Falha ao enriquecer instâncias com número real:', e.message);
        }
      }

      return res.json({ units });
    } catch (err) {
      console.error('[Units] Erro ao listar todas as instâncias uazapi:', err.message);
      res.status(500).json({ error: 'Erro interno' });
    }
  });

  // GET /api/units/:id/uazapi-send-capability
  // Requer autenticação (qualquer usuário com acesso à unidade).
  // Retorna { hasToken: boolean } — sem expor segredos.
  extraRouter.get('/:id/uazapi-send-capability', requireAuth, validateUUIDParam, async (req, res) => {
    try {
      const { id } = req.params;
      const { isAdmin, allowedUnitIds, currentUnitId } = req.currentUser || {};

      // Verificar se o usuário tem acesso à unidade
      if (!isAdmin) {
        const allowed = Array.isArray(allowedUnitIds) ? allowedUnitIds : [];
        if (!allowed.includes(id) && currentUnitId !== id) {
          return res.status(403).json({ error: 'Acesso negado a esta unidade.' });
        }
      }

      const result = await pool.query(
        `SELECT (uazapi_token_encrypted IS NOT NULL AND uazapi_token_encrypted <> '') AS has_token
         FROM unit_whatsapp_credentials
         WHERE unit_id = $1`,
        [id]
      );
      if (result.rows.length === 0) return res.json({ hasToken: false });
      return res.json({ hasToken: Boolean(result.rows[0].has_token) });
    } catch (err) {
      console.error('[Units] Erro ao buscar send-capability:', err.message);
      res.status(500).json({ error: 'Erro interno' });
    }
  });

  // GET /api/units/:id/uazapi-instances
  // Retorna a lista de instâncias uazapi da unidade (só DB, sem chamadas live).
  // Usado pelo modal "Trocar canal" na Prospecção.
  extraRouter.get('/:id/uazapi-instances', requireAuth, validateUUIDParam, async (req, res) => {
    try {
      const { id } = req.params;
      const { isAdmin, allowedUnitIds, currentUnitId } = req.currentUser || {};
      if (!isAdmin) {
        const allowed = Array.isArray(allowedUnitIds) ? allowedUnitIds : [];
        if (!allowed.includes(id) && currentUnitId !== id) {
          return res.status(403).json({ error: 'Acesso negado a esta unidade.' });
        }
      }
      const result = await pool.query(
        `SELECT uazapi_instance_id AS "instanceId", label,
                last_inbound_at AS "lastInboundAt",
                uazapi_token_encrypted, uazapi_server_url
         FROM unit_whatsapp_credentials
         WHERE unit_id = $1
           AND uazapi_token_encrypted IS NOT NULL
           AND uazapi_token_encrypted <> ''
         ORDER BY created_at ASC`,
        [id]
      );

      // Task #312: resolver número real (cache 5 min) e nunca expor o token.
      const credsList = [];
      for (const row of result.rows) {
        try {
          credsList.push({
            instanceId: row.instanceId,
            token: decrypt(row.uazapi_token_encrypted),
            serverUrl: (row.uazapi_server_url || 'https://free.uazapi.com').replace(/\/$/, ''),
          });
        } catch { /* skip undecryptable */ }
      }
      const phoneMap = await getInstancePhoneInfoMany(credsList);
      const instances = result.rows.map(row => {
        const info = phoneMap.get(row.instanceId);
        return {
          instanceId: row.instanceId,
          label: row.label,
          lastInboundAt: row.lastInboundAt,
          phoneNumber: info?.phone || null,
          isConnected: info ? info.isConnected : null,
        };
      });
      return res.json({ instances });
    } catch (err) {
      console.error('[Units] Erro ao listar instâncias uazapi:', err.message);
      res.status(500).json({ error: 'Erro interno' });
    }
  });

  // POST /api/units/:id/uazapi-credentials
  // Requer autenticação + perfil admin.
  // Upsert por instance_id (chave global única). Aceita label.
  // uazapiInstanceId é obrigatório — retorna 400 se ausente.
  // Token vazio = manter existente (apenas atualiza serverUrl e label).
  extraRouter.post('/:id/uazapi-credentials', requireAuth, requireAdmin, requireEncryptionKey, validateUUIDParam, async (req, res) => {
    try {
      const { id } = req.params;
      const { uazapiInstanceId, uazapiToken, uazapiServerUrl, label } = req.body;

      const instanceId = typeof uazapiInstanceId === 'string' ? uazapiInstanceId.trim() : '';
      const tokenRaw = typeof uazapiToken === 'string' ? uazapiToken.trim() : '';
      const serverUrl = typeof uazapiServerUrl === 'string' ? uazapiServerUrl.trim() : '';
      const labelVal = typeof label === 'string' ? label.trim() : null;

      if (!instanceId) {
        return res.status(400).json({ error: 'uazapiInstanceId é obrigatório. Use DELETE /api/uazapi/disconnect para remover uma instância específica.' });
      }

      // Guard: reject cross-unit instance hijacking
      const existing = await pool.query(
        `SELECT unit_id FROM unit_whatsapp_credentials WHERE uazapi_instance_id = $1`,
        [instanceId]
      );
      if (existing.rows[0] && existing.rows[0].unit_id !== id) {
        return res.status(409).json({ error: 'Esta instância uazapi já está vinculada a outra unidade.' });
      }

      if (tokenRaw) {
        const encrypted = encrypt(tokenRaw);
        await pool.query(
          `INSERT INTO unit_whatsapp_credentials (unit_id, uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url, label, updated_at)
           VALUES ($1, $2, $3, $4, $5, NOW())
           ON CONFLICT (uazapi_instance_id) DO UPDATE
             SET uazapi_token_encrypted = EXCLUDED.uazapi_token_encrypted,
                 uazapi_server_url      = EXCLUDED.uazapi_server_url,
                 label                  = COALESCE(EXCLUDED.label, unit_whatsapp_credentials.label),
                 updated_at             = NOW()
           WHERE unit_whatsapp_credentials.unit_id = $1`,
          [id, instanceId, encrypted, serverUrl || null, labelVal]
        );
      } else {
        await pool.query(
          `INSERT INTO unit_whatsapp_credentials (unit_id, uazapi_instance_id, uazapi_server_url, label, updated_at)
           VALUES ($1, $2, $3, $4, NOW())
           ON CONFLICT (uazapi_instance_id) DO UPDATE
             SET uazapi_server_url = EXCLUDED.uazapi_server_url,
                 label             = COALESCE(EXCLUDED.label, unit_whatsapp_credentials.label),
                 updated_at        = NOW()
           WHERE unit_whatsapp_credentials.unit_id = $1`,
          [id, instanceId, serverUrl || null, labelVal]
        );
      }

      // Após salvar, buscar o token atual para registrar webhook
      let webhookRegistered = false;
      let webhookError = null;
      let webhookUrl = null;
      try {
        const credRow = await pool.query(
          `SELECT uazapi_token_encrypted, uazapi_server_url FROM unit_whatsapp_credentials WHERE uazapi_instance_id = $1`,
          [instanceId]
        );
        if (credRow.rows.length > 0 && credRow.rows[0].uazapi_token_encrypted) {
          const currentToken = decrypt(credRow.rows[0].uazapi_token_encrypted);
          const uazapiServer = (credRow.rows[0].uazapi_server_url || serverUrl || '').replace(/\/$/, '') || 'https://free.uazapi.com';
          const baseUrl = getPublicBaseUrl();
          if (currentToken && baseUrl) {
            const result = await attemptWebhookRegister(currentToken, uazapiServer, baseUrl, pool, instanceId);
            webhookRegistered = result.registered;
            webhookUrl = result.webhookUrl;
            webhookError = result.error;
            if (webhookRegistered) {
              console.info(`[Units] Webhook uazapi registrado com sucesso: ${result.webhookUrl}`);
            } else {
              console.warn(`[Units] Webhook uazapi não registrado (${webhookError}) — credenciais salvas normalmente.`);
            }
          }
        }
      } catch (whErr) {
        webhookError = whErr.message;
        console.warn(`[Units] Erro ao registrar webhook uazapi: ${whErr.message} — credenciais salvas normalmente.`);
      }

      return res.json({
        success: true,
        message: 'Credenciais uazapi salvas.',
        webhookRegistered,
        webhookUrl: webhookUrl || undefined,
        webhookError: webhookError || undefined,
      });
    } catch (err) {
      console.error('[Units] Erro ao salvar credenciais uazapi:', err.message);
      res.status(500).json({ error: 'Erro ao salvar credenciais' });
    }
  });

  // POST /api/units/:id/uazapi-credentials/reregister-webhook
  // Re-registra o webhook uazapi para uma instância específica da unidade.
  // Body: { instanceId } — UUID ou nome da instância.
  // Retorna: { webhookUrl, registered, error }
  extraRouter.post('/:id/uazapi-credentials/reregister-webhook', requireAuth, requireAdmin, requireEncryptionKey, validateUUIDParam, async (req, res) => {
    try {
      const { id } = req.params;
      const instanceId = (req.body?.instanceId || '').trim();
      if (!instanceId) return res.status(400).json({ error: 'instanceId é obrigatório.' });

      const credRow = await pool.query(
        `SELECT uazapi_token_encrypted, uazapi_server_url
         FROM unit_whatsapp_credentials
         WHERE unit_id = $1 AND uazapi_instance_id = $2`,
        [id, instanceId]
      );
      if (!credRow.rows.length || !credRow.rows[0].uazapi_token_encrypted) {
        return res.status(404).json({ error: 'Credenciais não encontradas ou token não configurado.' });
      }

      const token = decrypt(credRow.rows[0].uazapi_token_encrypted);
      const uazapiServer = (credRow.rows[0].uazapi_server_url || 'https://free.uazapi.com').replace(/\/$/, '');
      const baseUrl = getPublicBaseUrl();

      if (!baseUrl) {
        return res.status(503).json({ error: 'URL pública do servidor não configurada. Defina APP_PUBLIC_URL ou REPLIT_DEV_DOMAIN.' });
      }

      try {
        const result = await attemptWebhookRegister(token, uazapiServer, baseUrl, pool, instanceId);
        if (result.registered) {
          console.info(`[Units] Webhook re-registrado com sucesso: ${result.webhookUrl}`);
        } else {
          console.warn(`[Units] Falha no re-registro do webhook: ${result.error}`);
        }
        return res.json(result);
      } catch (err) {
        return res.json({ webhookUrl: `${baseUrl}/api/uazapi/webhook?token=${encodeURIComponent(token)}`, registered: false, error: err.message });
      }
    } catch (err) {
      console.error('[Units] Erro ao re-registrar webhook uazapi:', err.message);
      res.status(500).json({ error: 'Erro interno ao re-registrar webhook.' });
    }
  });

  // Monta rotas específicas antes do crudRouter para que /:id/uazapi-credentials
  // não seja capturado pelo handler genérico /:id do CRUD.
  const combined = Router();
  combined.use('/', extraRouter);
  combined.use('/', crudRouter);

  return combined;
}

/**
 * Recupera o token uazapi em plain text para uma unidade.
 * Uso EXCLUSIVAMENTE server-side — nunca expor via rota HTTP.
 * Utilizado pelo webhook handler uazapi para autenticar chamadas de API.
 *
 * @param {import('pg').Pool} pool - Pool de conexões PostgreSQL
 * @param {string} unitId - UUID da unidade
 * @returns {Promise<string|null>} Token em plain text ou null se não configurado
 */
export async function getUazapiTokenForUnit(pool, unitId) {
  try {
    const result = await pool.query(
      `SELECT uazapi_token_encrypted FROM unit_whatsapp_credentials
       WHERE unit_id = $1 ORDER BY created_at ASC LIMIT 1`,
      [unitId]
    );
    if (result.rows.length === 0 || !result.rows[0].uazapi_token_encrypted) return null;
    return decrypt(result.rows[0].uazapi_token_encrypted);
  } catch (err) {
    console.error('[Units] Erro ao recuperar token uazapi para unidade:', err.message);
    return null;
  }
}

/**
 * Recupera credenciais uazapi (instance_id + token) por instance_id.
 * Uso EXCLUSIVAMENTE server-side — nunca expor via rota HTTP.
 * Usado pelo webhook handler para identificar a unidade pelo instance_id recebido no payload.
 *
 * @param {import('pg').Pool} pool - Pool de conexões PostgreSQL
 * @param {string} instanceId - ID da instância uazapi
 * @returns {Promise<{unitId: string, token: string}|null>}
 */
export async function getUazapiCredentialsByInstance(pool, instanceId) {
  try {
    const result = await pool.query(
      `SELECT unit_id, uazapi_token_encrypted, uazapi_server_url
       FROM unit_whatsapp_credentials
       WHERE uazapi_instance_id = $1`,
      [instanceId]
    );
    if (result.rows.length === 0) return null;
    const row = result.rows[0];
    return {
      unitId: row.unit_id,
      token: decrypt(row.uazapi_token_encrypted),
      serverUrl: row.uazapi_server_url || null,
    };
  } catch (err) {
    console.error('[Units] Erro ao buscar credenciais uazapi por instance_id:', err.message);
    return null;
  }
}

/**
 * Busca credenciais uazapi pelo token descriptografado.
 * Usado como fallback no webhook quando instanceName não coincide com uazapi_instance_id
 * (ex: instância compartilha URL de webhook com outra, enviando seu próprio instanceName).
 * Uso EXCLUSIVAMENTE server-side.
 *
 * @param {import('pg').Pool} pool
 * @param {string} plainToken - Token UUID em texto claro
 * @returns {Promise<{unitId: string, token: string, serverUrl: string, instanceId: string}|null>}
 */
export async function getUazapiCredsByToken(pool, plainToken) {
  if (!plainToken) return null;
  try {
    const result = await pool.query(
      `SELECT unit_id, uazapi_token_encrypted, uazapi_server_url, uazapi_instance_id
       FROM unit_whatsapp_credentials
       WHERE uazapi_token_encrypted IS NOT NULL`
    );
    for (const row of result.rows) {
      try {
        const decrypted = decrypt(row.uazapi_token_encrypted);
        if (decrypted === plainToken) {
          return {
            unitId: row.unit_id,
            token: decrypted,
            serverUrl: row.uazapi_server_url || null,
            instanceId: row.uazapi_instance_id || null,
          };
        }
      } catch { /* skip rows with bad encryption */ }
    }
    return null;
  } catch (err) {
    console.error('[Units] Erro ao buscar credenciais uazapi por token:', err.message);
    return null;
  }
}

export async function getUazapiCredsForUnit(pool, unitId) {
  try {
    const result = await pool.query(
      `SELECT uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url
       FROM unit_whatsapp_credentials
       WHERE unit_id = $1 ORDER BY created_at ASC LIMIT 1`,
      [unitId]
    );
    if (result.rows.length === 0) return null;
    const row = result.rows[0];
    if (!row.uazapi_instance_id || !row.uazapi_token_encrypted) return null;
    return {
      instanceId: row.uazapi_instance_id,
      token: decrypt(row.uazapi_token_encrypted),
      serverUrl: row.uazapi_server_url || null,
    };
  } catch (err) {
    console.error('[Units] Erro ao buscar credenciais uazapi por unit_id:', err.message);
    return null;
  }
}

/**
 * uazapiChats.js
 *
 * Rotas de proxy para contatos, chats, mensagens e grupos via uazapi.
 * Prefixo: /api/uazapi/
 *
 * Modelo: per-unit (unitId obrigatório em cada requisição)
 * Auth: requireAuth + verificação IDOR por unidade
 */

import { Router } from 'express';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
import { requireEncryptionKey } from '../utils/encryption.js';
import { logger } from '../logger.js';
import {
  uazApiFetch,
  uazApiFetchWithCreds,
  getCredsByInstanceForUnit,
  formatWaId,
  normalizeChat,
  normalizeMessage,
  hasUnitAccess,
  ssrfSafe,
} from '../lib/uazapiProxy.js';

export function createUazapiChatsRoutes(pool) {
  const router = Router();

  // Guard: todas as rotas dependem de decrypt de credenciais uazapi.
  // Em produção sem ENCRYPTION_KEY dedicado, retorna 503 imediatamente.
  router.use(requireEncryptionKey);

  // ── Middleware de unidade ───────────────────────────────────────────────────

  function resolveUnit(req) {
    return (
      req.query.unitId ||
      req.body?.unitId ||
      req.params.unitId ||
      req.currentUser?.currentUnitId ||
      null
    );
  }

  function unitGuard(req, res) {
    const unitId = resolveUnit(req);
    if (!unitId) {
      res.status(400).json({ error: 'unitId obrigatório.' });
      return null;
    }
    if (!hasUnitAccess(req.currentUser, unitId)) {
      res.status(403).json({ error: 'Acesso negado a esta unidade.' });
      return null;
    }
    return unitId;
  }

  async function proxyGet(pool, unitId, path, res) {
    try {
      const r = await uazApiFetch(pool, unitId, path);
      const data = await r.json().catch(() => ({}));
      return res.status(r.status).json(data);
    } catch (err) {
      const status = err.status || 500;
      logger.error(`[uazapiChats] GET ${path}: ${err.message}`);
      return res.status(status).json({ error: err.message });
    }
  }

  async function proxyPost(pool, unitId, path, body, res) {
    try {
      const r = await uazApiFetch(pool, unitId, path, {
        method: 'POST',
        body: JSON.stringify(body),
      });
      const data = await r.json().catch(() => ({}));
      return res.status(r.status).json(data);
    } catch (err) {
      const status = err.status || 500;
      logger.error(`[uazapiChats] POST ${path}: ${err.message}`);
      return res.status(status).json({ error: err.message });
    }
  }

  async function proxyDelete(pool, unitId, path, body, res) {
    try {
      const r = await uazApiFetch(pool, unitId, path, {
        method: 'DELETE',
        body: body ? JSON.stringify(body) : undefined,
      });
      const data = await r.json().catch(() => ({}));
      return res.status(r.status).json(data);
    } catch (err) {
      const status = err.status || 500;
      logger.error(`[uazapiChats] DELETE ${path}: ${err.message}`);
      return res.status(status).json({ error: err.message });
    }
  }

  // ══════════════════════════════════════════════════════════════
  //  CONTATOS
  // ══════════════════════════════════════════════════════════════

  // GET /contacts
  router.get('/contacts', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const page = req.query.page || 1;
    return proxyGet(pool, unitId, `/contacts?page=${page}`, res);
  });

  // GET /contacts/:contactId
  router.get('/contacts/:contactId', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    return proxyGet(pool, unitId, `/contacts/${req.params.contactId}`, res);
  });

  // POST /contacts
  router.post('/contacts', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { phone, name, ...rest } = req.body || {};
    if (!phone) return res.status(400).json({ error: 'phone obrigatório.' });
    const body = { phone: formatWaId(phone), name, ...rest };
    return proxyPost(pool, unitId, '/contacts', body, res);
  });

  // DELETE /contacts/:contactId
  router.delete('/contacts/:contactId', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    return proxyDelete(pool, unitId, `/contacts/${req.params.contactId}`, null, res);
  });

  // POST /contacts/check — verifica se número existe no WhatsApp
  router.post('/contacts/check', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { phone } = req.body || {};
    if (!phone) return res.status(400).json({ error: 'phone obrigatório.' });
    const body = { phone: formatWaId(phone) };
    return proxyPost(pool, unitId, '/contacts/check', body, res);
  });

  // POST /contact/info — informações completas do perfil WhatsApp
  router.post('/contact/info', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { phone } = req.body || {};
    if (!phone) return res.status(400).json({ error: 'phone obrigatório.' });
    const body = { phone: formatWaId(phone) };
    return proxyPost(pool, unitId, '/contact/info', body, res);
  });

  // POST /contact/avatar — URL da foto de perfil WhatsApp
  router.post('/contact/avatar', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { phone } = req.body || {};
    if (!phone) return res.status(400).json({ error: 'phone obrigatório.' });
    const body = { phone: formatWaId(phone) };
    return proxyPost(pool, unitId, '/contact/avatar', body, res);
  });

  // ══════════════════════════════════════════════════════════════
  //  CHATS
  // ══════════════════════════════════════════════════════════════

  // GET /chats — lista chats normalizados, ordenados por lastMessageTime desc
  router.get('/chats', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const page = req.query.page || 1;
    try {
      const r = await uazApiFetch(pool, unitId, `/chats?page=${page}`);
      const data = await r.json().catch(() => ({}));
      if (!r.ok) return res.status(r.status).json(data);

      const rawList = Array.isArray(data) ? data : (data.chats || data.data || []);
      const normalized = rawList
        .map(normalizeChat)
        .filter(Boolean)
        .sort((a, b) => b.lastMessageTime - a.lastMessageTime);

      return res.json({ chats: normalized, total: normalized.length, page: Number(page) });
    } catch (err) {
      const status = err.status || 500;
      logger.error(`[uazapiChats] GET /chats: ${err.message}`);
      return res.status(status).json({ error: err.message });
    }
  });

  // POST /chats/find — busca chat por phone/name/jid
  router.post('/chats/find', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { phone, name, jid } = req.body || {};

    try {
      const r = await uazApiFetch(pool, unitId, '/chats');
      const data = await r.json().catch(() => ({}));
      const rawList = Array.isArray(data) ? data : (data.chats || data.data || []);
      const chats = rawList.map(normalizeChat).filter(Boolean);

      let found = null;
      if (jid) {
        found = chats.find(c => c.chatId === jid);
      } else if (phone) {
        const digits = String(phone).replace(/\D/g, '');
        found = chats.find(c => c.phoneNumber && c.phoneNumber.endsWith(digits.slice(-10)));
      } else if (name) {
        const lower = name.toLowerCase();
        found = chats.find(c => c.name?.toLowerCase().includes(lower));
      }

      return res.json({ chat: found || null });
    } catch (err) {
      const status = err.status || 500;
      logger.error(`[uazapiChats] POST /chats/find: ${err.message}`);
      return res.status(status).json({ error: err.message });
    }
  });

  // POST /chats/presence — envia indicador de digitação para um chat
  // Body: { unitId, phone, state: 'composing'|'paused', instanceId? }
  router.post('/chats/presence', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { phone, state = 'composing', instanceId } = req.body || {};
    if (!phone) return res.status(400).json({ error: 'phone obrigatório.' });
    const number = String(phone).replace(/\D/g, '');
    const chatId = `${number}@s.whatsapp.net`;
    try {
      // If instanceId provided, use specific instance credentials
      let fetchFn;
      if (instanceId) {
        const creds = await getCredsByInstanceForUnit(pool, unitId, instanceId);
        if (!creds || !creds.token) return res.json({ ok: false, reason: 'instância não encontrada' });
        fetchFn = () => uazApiFetchWithCreds(creds, `/chats/${chatId}/presence`, {
          method: 'POST',
          body: JSON.stringify({ state }),
        });
      } else {
        fetchFn = () => uazApiFetch(pool, unitId, `/chats/${chatId}/presence`, {
          method: 'POST',
          body: JSON.stringify({ state }),
        });
      }
      const r = await fetchFn();
      const data = await r.json().catch(() => ({}));
      return res.status(r.status).json(data);
    } catch (err) {
      // Presence is best-effort — never return 5xx to avoid breaking the UI
      logger.warn(`[uazapiChats] presence error: ${err.message}`);
      return res.json({ ok: false, reason: err.message });
    }
  });

  // POST /chats/:chatId/read
  router.post('/chats/:chatId/read', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    return proxyPost(pool, unitId, `/chats/${req.params.chatId}/read`, {}, res);
  });

  // POST /chats/:chatId/archive
  router.post('/chats/:chatId/archive', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    return proxyPost(pool, unitId, `/chats/${req.params.chatId}/archive`, {}, res);
  });

  // POST /chats/:chatId/pin
  router.post('/chats/:chatId/pin', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    return proxyPost(pool, unitId, `/chats/${req.params.chatId}/pin`, {}, res);
  });

  // DELETE /chats/:chatId
  router.delete('/chats/:chatId', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    return proxyDelete(pool, unitId, `/chats/${req.params.chatId}`, null, res);
  });

  // GET /chats/:chatId/messages — mensagens normalizadas de um chat
  router.get('/chats/:chatId/messages', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const page = req.query.page || 1;
    try {
      const r = await uazApiFetch(pool, unitId, `/chats/${req.params.chatId}/messages?page=${page}`);
      const data = await r.json().catch(() => ({}));
      if (!r.ok) return res.status(r.status).json(data);

      const rawList = Array.isArray(data) ? data : (data.messages || data.data || []);
      const messages = rawList.map(normalizeMessage).filter(Boolean);
      return res.json({ messages, total: messages.length, page: Number(page) });
    } catch (err) {
      const status = err.status || 500;
      logger.error(`[uazapiChats] GET /chats/:id/messages: ${err.message}`);
      return res.status(status).json({ error: err.message });
    }
  });

  // ══════════════════════════════════════════════════════════════
  //  MENSAGENS
  // ══════════════════════════════════════════════════════════════

  // POST /messages/send — suporta text, image, video, audio, document, sticker
  router.post('/messages/send', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;

    const { chatId, type = 'text', message, mediaUrl, caption, fileName, mimeType } = req.body || {};
    if (!chatId) return res.status(400).json({ error: 'chatId obrigatório.' });

    let apiPath = '/messages/send';
    let body = {};

    const normalizedChatId = chatId.includes('@') ? chatId : formatWaId(chatId);

    switch (type) {
      case 'text':
        if (!message) return res.status(400).json({ error: 'message obrigatório para tipo text.' });
        body = { chatId: normalizedChatId, text: message };
        break;
      case 'image':
        if (!mediaUrl) return res.status(400).json({ error: 'mediaUrl obrigatório para tipo image.' });
        body = { chatId: normalizedChatId, imageMessage: { url: mediaUrl, caption: caption || '' } };
        break;
      case 'video':
        if (!mediaUrl) return res.status(400).json({ error: 'mediaUrl obrigatório para tipo video.' });
        body = { chatId: normalizedChatId, videoMessage: { url: mediaUrl, caption: caption || '' } };
        break;
      case 'audio':
        if (!mediaUrl) return res.status(400).json({ error: 'mediaUrl obrigatório para tipo audio.' });
        body = { chatId: normalizedChatId, audioMessage: { url: mediaUrl } };
        break;
      case 'document':
        if (!mediaUrl) return res.status(400).json({ error: 'mediaUrl obrigatório para tipo document.' });
        body = {
          chatId: normalizedChatId,
          documentMessage: {
            url: mediaUrl,
            caption: caption || '',
            fileName: fileName || 'documento',
            mimeType: mimeType || 'application/octet-stream',
          },
        };
        break;
      case 'sticker':
        if (!mediaUrl) return res.status(400).json({ error: 'mediaUrl obrigatório para tipo sticker.' });
        body = { chatId: normalizedChatId, stickerMessage: { url: mediaUrl } };
        break;
      default:
        return res.status(400).json({ error: `Tipo inválido: ${type}. Use text, image, video, audio, document ou sticker.` });
    }

    try {
      const r = await uazApiFetch(pool, unitId, apiPath, {
        method: 'POST',
        body: JSON.stringify(body),
      });
      const data = await r.json().catch(() => ({}));

      if (r.ok && type === 'text' && message) {
        const messageId = data?.key?.id || data?.id || data?.messageid || `local-${Date.now()}`;
        const digits = String(chatId).replace(/[^0-9]/g, '');
        const dbClient = await pool.connect();
        try {
          const clientRow = await dbClient.query(
            `SELECT id FROM clients
             WHERE RIGHT(REGEXP_REPLACE(COALESCE(celular,''), '[^0-9]', '', 'g'), 10) = $1
                OR RIGHT(REGEXP_REPLACE(COALESCE(telefone,''), '[^0-9]', '', 'g'), 10) = $1
             LIMIT 1`,
            [digits.slice(-10)]
          ).catch(() => ({ rows: [] }));
          await dbClient.query(
            `INSERT INTO gotalk_messages
               (gotalk_message_id, client_id, phone_number, direction, body,
                message_type, ack_status, sent_at, source, unit_id)
             VALUES ($1,$2,$3,'OUT',$4,'TEXT',1,NOW(),'uazapi',$5)
             ON CONFLICT (gotalk_message_id) DO NOTHING`,
            [messageId, clientRow.rows[0]?.id || null, digits, message, unitId]
          ).catch(() => {});
        } finally {
          dbClient.release();
        }
      }

      return res.status(r.status).json(data);
    } catch (err) {
      const status = err.status || 500;
      logger.error(`[uazapiChats] POST /messages/send: ${err.message}`);
      return res.status(status).json({ error: err.message });
    }
  });

  // POST /messages/:msgId/react — reação em mensagem
  router.post('/messages/:msgId/react', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { emoji } = req.body || {};
    return proxyPost(pool, unitId, `/messages/${req.params.msgId}/react`, { emoji }, res);
  });

  // DELETE /messages/:msgId — apaga mensagem no WhatsApp (somente admin)
  // Nota: remove do dispositivo do contato, mas o registro permanece no banco (gotalk_messages).
  router.delete('/messages/:msgId', requireAuth, requireAdmin, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    logger.warn(`[uazapiChats] Admin ${req.currentUser?.userName} apagou mensagem WhatsApp msgId=${req.params.msgId} unitId=${unitId} ip=${req.ip}`);
    return proxyDelete(pool, unitId, `/messages/${req.params.msgId}`, null, res);
  });

  // POST /messages/:msgId/forward — encaminha mensagem
  router.post('/messages/:msgId/forward', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { chatId } = req.body || {};
    if (!chatId) return res.status(400).json({ error: 'chatId obrigatório.' });
    return proxyPost(pool, unitId, `/messages/${req.params.msgId}/forward`, { chatId }, res);
  });

  // POST /messages/search — busca mensagens em chat específico ou global
  router.post('/messages/search', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { query, chatId } = req.body || {};
    if (!query) return res.status(400).json({ error: 'query obrigatório.' });
    return proxyPost(pool, unitId, '/messages/search', { query, chatId }, res);
  });

  // GET /messages/global-search
  router.get('/messages/global-search', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const q = req.query.q;
    if (!q) return res.status(400).json({ error: 'Parâmetro q obrigatório.' });
    return proxyGet(pool, unitId, `/messages/search?query=${encodeURIComponent(q)}`, res);
  });

  // ── Mensagens agendadas ──────────────────────────────────────

  // POST /messages/schedule
  router.post('/messages/schedule', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { chatId, message, scheduledAt } = req.body || {};
    if (!chatId || !message || !scheduledAt) {
      return res.status(400).json({ error: 'chatId, message e scheduledAt são obrigatórios.' });
    }
    const ts = new Date(scheduledAt);
    if (isNaN(ts.getTime()) || ts <= new Date()) {
      return res.status(400).json({ error: 'scheduledAt deve ser uma data futura válida.' });
    }
    try {
      const r = await pool.query(
        `INSERT INTO whatsapp_scheduled_messages (unit_id, chat_id, message, scheduled_at)
         VALUES ($1, $2, $3, $4)
         RETURNING id, chat_id, message, scheduled_at, status, created_at`,
        [unitId, chatId, message, ts]
      );
      return res.status(201).json({ scheduled: r.rows[0] });
    } catch (err) {
      logger.error(`[uazapiChats] schedule: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao agendar mensagem.' });
    }
  });

  // GET /messages/scheduled — lista agendadas pendentes da unidade
  router.get('/messages/scheduled', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    try {
      const r = await pool.query(
        `SELECT id, chat_id, message, scheduled_at, sent_at, status, error, created_at
         FROM whatsapp_scheduled_messages
         WHERE unit_id = $1 AND status = 'pending'
         ORDER BY scheduled_at ASC`,
        [unitId]
      );
      return res.json({ scheduled: r.rows });
    } catch (err) {
      logger.error(`[uazapiChats] scheduled list: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao listar mensagens agendadas.' });
    }
  });

  // DELETE /messages/scheduled/:id — cancela agendamento
  router.delete('/messages/scheduled/:id', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    try {
      const r = await pool.query(
        `UPDATE whatsapp_scheduled_messages
         SET status = 'cancelled'
         WHERE id = $1 AND unit_id = $2 AND status = 'pending'
         RETURNING id`,
        [req.params.id, unitId]
      );
      if (r.rowCount === 0) {
        return res.status(404).json({ error: 'Agendamento não encontrado ou já processado.' });
      }
      return res.json({ cancelled: true, id: r.rows[0].id });
    } catch (err) {
      logger.error(`[uazapiChats] cancel scheduled: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao cancelar agendamento.' });
    }
  });

  // ══════════════════════════════════════════════════════════════
  //  GRUPOS
  // ══════════════════════════════════════════════════════════════

  // GET /groups
  router.get('/groups', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    return proxyGet(pool, unitId, '/groups', res);
  });

  // POST /groups
  router.post('/groups', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { name, participants } = req.body || {};
    if (!name || !Array.isArray(participants) || participants.length === 0) {
      return res.status(400).json({ error: 'name e participants obrigatórios.' });
    }
    return proxyPost(pool, unitId, '/groups', { name, participants }, res);
  });

  // GET /groups/:groupId
  router.get('/groups/:groupId', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    return proxyGet(pool, unitId, `/groups/${req.params.groupId}`, res);
  });

  // GET /groups/:groupId/invite
  router.get('/groups/:groupId/invite', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    return proxyGet(pool, unitId, `/groups/${req.params.groupId}/invite`, res);
  });

  // POST /groups/:groupId/participants — adiciona
  router.post('/groups/:groupId/participants', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { participants } = req.body || {};
    if (!Array.isArray(participants) || participants.length === 0) {
      return res.status(400).json({ error: 'participants obrigatório.' });
    }
    return proxyPost(pool, unitId, `/groups/${req.params.groupId}/participants`, { participants }, res);
  });

  // DELETE /groups/:groupId/participants — remove
  router.delete('/groups/:groupId/participants', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { participants } = req.body || {};
    return proxyDelete(pool, unitId, `/groups/${req.params.groupId}/participants`, { participants }, res);
  });

  // PATCH /groups/:groupId/participants/promote
  router.patch('/groups/:groupId/participants/promote', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    try {
      const r = await uazApiFetch(pool, unitId, `/groups/${req.params.groupId}/participants/promote`, {
        method: 'PATCH',
        body: JSON.stringify(req.body || {}),
      });
      const data = await r.json().catch(() => ({}));
      return res.status(r.status).json(data);
    } catch (err) {
      return res.status(err.status || 500).json({ error: err.message });
    }
  });

  // PATCH /groups/:groupId/participants/demote
  router.patch('/groups/:groupId/participants/demote', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    try {
      const r = await uazApiFetch(pool, unitId, `/groups/${req.params.groupId}/participants/demote`, {
        method: 'PATCH',
        body: JSON.stringify(req.body || {}),
      });
      const data = await r.json().catch(() => ({}));
      return res.status(r.status).json(data);
    } catch (err) {
      return res.status(err.status || 500).json({ error: err.message });
    }
  });

  return router;
}

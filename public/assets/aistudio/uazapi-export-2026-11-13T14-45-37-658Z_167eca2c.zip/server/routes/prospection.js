/**
 * ROTAS DE PROSPECÇÃO
 *
 * Gerencia contatos de prospecção (via WhatsApp) e suas conversas.
 * Todos os números de telefone que interagem via WhatsApp são registrados
 * automaticamente como LEAD (novo) ou RECUPERACAO (já existente).
 *
 * Endpoints:
 *   GET  /api/prospection/contacts          — lista paginada com filtros
 *   GET  /api/prospection/contacts/:phone/history — histórico de conversas do número
 *   POST /api/prospection/conversations     — abre/registra uma conversa
 *   PATCH /api/prospection/conversations/:id/summary — salva resumo ao encerrar
 *   GET  /api/prospection/dashboard         — dados agregados para indicadores
 */

import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { logger } from '../logger.js';
import { logAudit } from '../middleware/audit.js';

function normalizePhone(raw) {
  if (!raw) return null;
  let digits = String(raw).replace(/\D/g, '');
  if (digits.startsWith('55') && digits.length > 11) digits = digits.slice(2);
  return digits || null;
}

// UUID v4 pattern used to filter out malformed IDs before SQL ::uuid[] cast
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

async function auditMutation(client, req, entityType, entityId, action, beforeSnapshot, afterSnapshot) {
  const user = req.currentUser || {};
  await logAudit(client, {
    userId: user.id,
    userName: user.name || user.email,
    entityType,
    entityId,
    action,
    beforeSnapshot,
    afterSnapshot,
    ipAddress: req.ip,
    required: true
  });
}

async function withMutation(pool, operation) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await operation(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    throw err;
  } finally {
    client.release();
  }
}

/**
 * parseUnitIds — robust parser for the `unitIds` query parameter.
 * Accepts three formats (as sent by browsers/fetch):
 *   - CSV string:        "id1,id2,id3"
 *   - Repeated params:   Express already coerces to string[] when repeated
 *   - JSON array string: '["id1","id2"]'
 *
 * Only UUID-shaped values are kept — malformed tokens are silently dropped,
 * preventing unexpected 500s from PostgreSQL's ::uuid[] cast.
 *
 * Returns a deduplicated, UUID-validated array, or [] if input is absent/empty.
 */
function parseUnitIds(raw) {
  if (!raw) return [];

  let tokens;

  // Express repeated params: ?unitIds=id1&unitIds=id2 → already an array
  if (Array.isArray(raw)) {
    tokens = raw.map(s => String(s).trim()).filter(Boolean);
  } else {
    const str = String(raw).trim();
    if (!str) return [];

    // JSON array string: '["id1","id2"]'
    if (str.startsWith('[')) {
      try {
        const parsed = JSON.parse(str);
        if (Array.isArray(parsed)) {
          tokens = parsed.map(s => String(s).trim()).filter(Boolean);
        }
      } catch { /* fall through to CSV */ }
    }

    if (!tokens) {
      // CSV: "id1,id2,id3"
      tokens = str.split(',').map(s => s.trim()).filter(Boolean);
    }
  }

  // Deduplicate and validate UUID format — drop malformed tokens silently
  return [...new Set(tokens.filter(t => UUID_RE.test(t)))];
}

export function createProspectionRoutes(pool) {
  const router = Router();

  // ── GET /api/prospection/contacts ──────────────────────────────────────────
  // Lista paginada de contatos de prospecção com filtros.
  // Query params: page (default 1), limit (default 50), search, unitIds (CSV),
  //               operatorId, classification (LEAD|RECUPERACAO),
  //               period (today|7d|30d|custom), dateFrom, dateTo
  //
  // SEGURANÇA: não-admins só vêem contatos das unidades em req.currentUser.allowedUnitIds.
  // O parâmetro unitIds (enviado pelo cliente) é sempre interseccionado com allowedUnitIds —
  // nunca confiamos no cliente para substituir a lista de permissão.
  router.get('/contacts', requireAuth, async (req, res) => {
    try {
      const {
        page = '1',
        limit = '50',
        search,
        unitId: unitIdSingle,
        unitIds: unitIdsParam,
        operatorId,
        operatorName,
        classification,
        period,
        dateFrom,
        dateTo,
      } = req.query;

      const user = req.currentUser;
      const isAdmin = user?.isAdmin === true;
      const allowedUnitIds = Array.isArray(user?.allowedUnitIds) ? user.allowedUnitIds : [];

      // Parse unitIds — distinguish "param absent" from "param present but all tokens malformed".
      // Backward-compatible: legacy callers may send unitId (single) when unitIds is absent.
      const rawUnitIdsParam = unitIdsParam ?? (unitIdSingle ?? undefined);
      const unitIdsExplicit  = rawUnitIdsParam !== undefined; // true = client intentionally passed the param
      const requestedUnitIds = parseUnitIds(rawUnitIdsParam);

      const parsedPage = Math.max(parseInt(page, 10) || 1, 1);
      const parsedLimit = Math.min(Math.max(parseInt(limit, 10) || 50, 1), 200);
      const emptyContacts = () => res.json({ contacts: [], total: 0, page: parsedPage, limit: parsedLimit, totalPages: 0 });

      // Determine effective unit IDs with security enforcement
      if (!isAdmin && allowedUnitIds.length === 0) {
        // User has no unit access → return empty immediately
        return emptyContacts();
      }

      const {
        hasAppointment: hasAppointmentParam,
        apptDateFrom,
        apptDateTo,
      } = req.query;

      const conditions = [];
      const params = [];

      if (search) {
        params.push(`%${search}%`);
        conditions.push(`(pc.phone ILIKE $${params.length} OR pc.contact_name ILIKE $${params.length})`);
      }

      // Unit filter — always apply for non-admins; optional sub-filter for admins.
      // Security: client-provided unitIds are intersected with allowedUnitIds.
      // Semantics:
      //   • param absent          → no sub-filter  → use all allowed units
      //   • param present, valid  → intersect with allowed (empty intersection → empty result)
      //   • param present, all malformed UUIDs → explicit empty → return empty (strict)
      if (!isAdmin) {
        if (unitIdsExplicit) {
          // Explicit filter requested — empty parsed list (malformed) or empty intersection → empty result
          if (requestedUnitIds.length === 0) {
            return emptyContacts();
          }
          const intersection = requestedUnitIds.filter(id => allowedUnitIds.includes(id));
          if (intersection.length === 0) {
            return emptyContacts();
          }
          params.push(intersection);
        } else {
          // No sub-filter: show all allowed units
          params.push(allowedUnitIds);
        }
        conditions.push(`pc.unit_id = ANY($${params.length}::uuid[])`);
      } else if (unitIdsExplicit) {
        // Admin with optional sub-filter
        if (requestedUnitIds.length === 0) {
          // All tokens malformed → treat as explicit empty → no results
          return emptyContacts();
        }
        params.push(requestedUnitIds);
        conditions.push(`pc.unit_id = ANY($${params.length}::uuid[])`);
      }

      if (operatorId) {
        // Guard: only apply if value looks like a UUID (GoTalk-only synthetic ids are skipped by frontend, but double-check here)
        const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        if (UUID_RE.test(operatorId)) {
          params.push(operatorId);
          conditions.push(`pc.operator_id = $${params.length}`);
        }
      }

      // operatorName filter: used for GoTalk-only operators (no UUID) — looks up operator_name
      // in gotalk_messages rows whose phone_number (stripped) matches the contact's phone.
      // Uses EXISTS so it works correctly in both the COUNT and the paginated data sub-query.
      if (operatorName && typeof operatorName === 'string' && operatorName.trim()) {
        params.push(`%${operatorName.trim()}%`);
        conditions.push(`EXISTS (
          SELECT 1 FROM gotalk_messages gm
          WHERE REGEXP_REPLACE(gm.phone_number, '[^0-9]', '', 'g') = REGEXP_REPLACE(pc.phone, '[^0-9]', '', 'g')
            AND gm.operator_name ILIKE $${params.length}
        )`);
      }

      // Source filter: 'gotalk' or 'uazapi'
      // Uses last_source (most recent channel) instead of source (first-touch) for accuracy.
      // Falls back to source for rows that predate the last_source column (migration 039).
      const source = (req.query.source || '').trim().toLowerCase();
      if (source && ['gotalk', 'uazapi'].includes(source)) {
        params.push(source);
        conditions.push(`COALESCE(pc.last_source, pc.source) = $${params.length}`);
      }

      if (classification && ['LEAD', 'RECUPERACAO'].includes(classification)) {
        params.push(classification);
        conditions.push(`pc.classification = $${params.length}`);
      }

      // Period filter on last_contact_at.
      // IMPORTANT: contacts with a FUTURE appointment must remain visible even if
      // their last_contact_at falls outside the selected period (Item 03 fix).
      // We achieve this with: (period_condition) OR (has future appointment).
      let periodClause = null;
      if (period === 'today') {
        periodClause = `pc.last_contact_at >= CURRENT_DATE`;
      } else if (period === '7d') {
        periodClause = `pc.last_contact_at >= NOW() - INTERVAL '7 days'`;
      } else if (period === '30d') {
        periodClause = `pc.last_contact_at >= NOW() - INTERVAL '30 days'`;
      } else if (period === 'custom') {
        const parts = [];
        if (dateFrom) {
          params.push(dateFrom);
          parts.push(`pc.last_contact_at >= $${params.length}::date`);
        }
        if (dateTo) {
          params.push(dateTo);
          parts.push(`pc.last_contact_at < ($${params.length}::date + INTERVAL '1 day')`);
        }
        if (parts.length > 0) periodClause = parts.join(' AND ');
      }

      // When hasAppointment=1 is active the user explicitly wants scheduled contacts —
      // skip the period window entirely so past appointments are not hidden.
      if (periodClause && hasAppointmentParam !== '1') {
        // Allow contacts with a future appointment to bypass the period filter.
        // Matches by prospection_contact_id (direct, reliable) OR client_id fallback.
        conditions.push(
          `(${periodClause} OR EXISTS (
            SELECT 1 FROM appointments a
            WHERE (
              a.prospection_contact_id = pc.id
              OR (pc.client_id IS NOT NULL AND a.client_id = pc.client_id::text)
            )
            AND a.date >= CURRENT_DATE
          ))`
        );
      }

      // ── Filter: only contacts with appointment (Item 01) ──
      // Matches by prospection_contact_id (direct link, reliable) OR by client_id fallback.
      // No date restriction: shows contacts with ANY appointment (past or future).
      if (hasAppointmentParam === '1') {
        const dateClauses = [];
        if (apptDateFrom) {
          params.push(apptDateFrom);
          dateClauses.push(`a_filter.date >= $${params.length}::date`);
        }
        if (apptDateTo) {
          params.push(apptDateTo);
          dateClauses.push(`a_filter.date <= $${params.length}::date`);
        }
        const dateFilter = dateClauses.length > 0 ? ` AND ${dateClauses.join(' AND ')}` : '';
        conditions.push(
          `EXISTS (
            SELECT 1 FROM appointments a_filter
            WHERE (
              a_filter.prospection_contact_id = pc.id
              OR (pc.client_id IS NOT NULL AND a_filter.client_id = pc.client_id::text)
            )${dateFilter}
          )`
        );
      }

      const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

      const offset = (parsedPage - 1) * parsedLimit;

      // Deduplication with consolidation:
      // prospection_contacts has UNIQUE(phone) but may have edge-case duplicates
      // from phone-format differences (e.g. with/without country code prefix) when
      // two providers inserted the same real number in slightly different formats.
      // We group by last-10-digits of normalized phone, pick the row with the
      // latest last_contact_at as representative, and SUM total_contacts across
      // all duplicates so the count reflects real interaction history.
      // Dedup key: full digit-only phone string (regexp_replace removes non-digits).
      // normalizePhone() already canonicalises to "55XXXXXXXXXX" on every insert,
      // so the full stripped phone is a safe equality key that avoids false merges
      // from numbers sharing only the last N digits.
      const PHONE_NORM = `regexp_replace(pc.phone, '[^0-9]', '', 'g')`;

      const countRes = await pool.query(
        `SELECT COUNT(DISTINCT ${PHONE_NORM})
         FROM prospection_contacts pc
         ${whereClause}`,
        params
      );
      const total = parseInt(countRes.rows[0].count, 10);

      params.push(parsedLimit, offset);
      // Task #300: pre-aggregate unread counts per canonical phone (sem cutoff
      // de período — mensagens não lidas SEMPRE pendentes) em CTE para evitar
      // subquery correlacionada — custo passa a ser O(messages) único
      // once instead of O(contacts × messages). Then join back into the ranked
      // contacts result. Ordering: pendentes primeiro; pendentes ordenados por
      // last_inbound_at (chegou agora vai pro topo); restantes por last_contact_at.
      const dataRes = await pool.query(
        `WITH unread_agg AS (
           SELECT RIGHT(REGEXP_REPLACE(gm.phone_number, '[^0-9]', '', 'g'), 10) AS p10,
                  COUNT(*)::int AS cnt
           FROM gotalk_messages gm
           WHERE gm.direction = 'IN'
             AND gm.read_at IS NULL
           GROUP BY p10
         )
         SELECT id, phone, contact_name, classification,
                total_contacts_consolidated AS total_contacts,
                first_contact_at, last_contact_at, last_inbound_at,
                unit_id, unit_name,
                operator_id, operator_name_linked,
                client_id, client_name_linked,
                source, last_source, uazapi_instance_id, uazapi_unit_id, last_inbound_instance_id,
                COALESCE(unread_count, 0)::int AS unread_count
         FROM (
           SELECT
             pc.id, pc.phone, pc.contact_name, pc.classification,
             SUM(pc.total_contacts) OVER (
               PARTITION BY ${PHONE_NORM}
             ) AS total_contacts_consolidated,
             MIN(pc.first_contact_at) OVER (
               PARTITION BY ${PHONE_NORM}
             ) AS first_contact_at,
             pc.last_contact_at,
             pc.last_inbound_at,
             pc.unit_id,
             COALESCE(c.nome_fantasia, c.razao_social) AS unit_name,
             pc.operator_id, col.name AS operator_name_linked,
             pc.client_id, cl.name  AS client_name_linked,
             pc.source, pc.last_source, pc.uazapi_instance_id, pc.uazapi_unit_id, pc.last_inbound_instance_id,
             ua.cnt AS unread_count,
             ROW_NUMBER() OVER (
               PARTITION BY ${PHONE_NORM}
               ORDER BY pc.last_contact_at DESC
             ) AS rn
           FROM prospection_contacts pc
           LEFT JOIN companies     c   ON c.id   = pc.unit_id
           LEFT JOIN collaborators col ON col.id = pc.operator_id
           LEFT JOIN clients       cl  ON cl.id  = pc.client_id
           LEFT JOIN unread_agg    ua  ON ua.p10 = RIGHT(${PHONE_NORM}, 10)
           ${whereClause}
         ) ranked
         WHERE rn = 1
         ORDER BY (COALESCE(unread_count, 0) > 0) DESC,
                  CASE WHEN COALESCE(unread_count, 0) > 0
                       THEN COALESCE(last_inbound_at, last_contact_at)
                       ELSE last_contact_at
                  END DESC NULLS LAST
         LIMIT $${params.length - 1} OFFSET $${params.length}`,
        params
      );

      res.json({
        contacts: dataRes.rows,
        total,
        page: parsedPage,
        limit: parsedLimit,
        totalPages: Math.ceil(total / parsedLimit),
      });
    } catch (err) {
      logger.error(`[Prospection] GET /contacts error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── PUT /api/prospection/scheduling-queue ─────────────────────────────────
  // Rotate/update the scheduling queue for a unit.
  // Available to ALL authenticated users (not admin-only) so that non-admin
  // operators can trigger queue rotation after scheduling via Prospecção.
  router.put('/scheduling-queue', requireAuth, async (req, res) => {
    try {
      const { unitId, collaboratorIds } = req.body;
      if (!unitId || !Array.isArray(collaboratorIds)) {
        return res.status(400).json({ error: 'unitId and collaboratorIds (array) are required.' });
      }
      await withMutation(pool, async client => {
        const locked = await client.query("SELECT value FROM app_data WHERE key = 'portal_config' FOR UPDATE");
        if (locked.rows.length === 0) throw Object.assign(new Error('Config not found.'), { statusCode: 404 });
        const before = locked.rows[0]?.value || {};
        const cfg = JSON.parse(JSON.stringify(before));
        const queue = Array.isArray(cfg.schedulingQueue) ? cfg.schedulingQueue : [];
        const existing = queue.find(q => q.unitId === unitId);
        if (existing) existing.collaboratorIds = collaboratorIds;
        else queue.push({ unitId, collaboratorIds });
        cfg.schedulingQueue = queue;
        await client.query(`UPDATE app_data SET value = $1, updated_at = NOW() WHERE key = 'portal_config'`, [JSON.stringify(cfg)]);
        await auditMutation(client, req, 'CONFIG', 'portal_config', 'UPDATE', { value: before }, { value: cfg });
      });
      res.json({ success: true });
    } catch (err) {
      logger.error(`[Prospection] PUT /scheduling-queue error: ${err.message}`);
      res.status(err.statusCode || 500).json({ error: err.message });
    }
  });

  // ── GET /api/prospection/contacts/:phone/history ──────────────────────────
  // Histórico de conversas de prospecção para um número.
  // SEGURANÇA: não-admins só podem acessar histórico de contatos da(s) sua(s) unidade(s).
  router.get('/contacts/:phone/history', requireAuth, async (req, res) => {
    try {
      const phone = normalizePhone(req.params.phone);
      if (!phone) return res.status(400).json({ error: 'Número de telefone inválido.' });

      const user = req.currentUser;
      const isAdmin = user?.isAdmin === true;
      const allowedUnitIds = Array.isArray(user?.allowedUnitIds) ? user.allowedUnitIds : [];

      // Non-admin with no units → nothing to show
      if (!isAdmin && allowedUnitIds.length === 0) {
        return res.status(404).json({ error: 'Contato não encontrado.' });
      }

      // Build unit-scope filter for the queries
      const unitFilter = isAdmin ? '' : `AND pc.unit_id = ANY($2::uuid[])`;
      const contactParams = isAdmin ? [phone] : [phone, allowedUnitIds];

      const contactRes = await pool.query(
        `SELECT pc.*,
                COALESCE(c.nome_fantasia, c.razao_social) AS unit_name,
                col.name AS operator_name_linked,
                cl.name  AS client_name_linked
         FROM prospection_contacts pc
         LEFT JOIN companies    c   ON c.id   = pc.unit_id
         LEFT JOIN collaborators col ON col.id = pc.operator_id
         LEFT JOIN clients       cl  ON cl.id  = pc.client_id
         WHERE pc.phone = $1 ${unitFilter}`,
        contactParams
      );

      // If non-admin and phone belongs to a different unit, return 404 (no data leakage)
      if (!contactRes.rows[0] && !isAdmin) {
        return res.status(404).json({ error: 'Contato não encontrado.' });
      }

      // Conversations — same unit scope filter
      const convFilter = isAdmin ? '' : `AND pconv.unit_id = ANY($2::uuid[])`;
      const convParams = isAdmin ? [phone] : [phone, allowedUnitIds];

      const conversationsRes = await pool.query(
        `SELECT pconv.*,
                COALESCE(c.nome_fantasia, c.razao_social) AS unit_name
         FROM prospection_conversations pconv
         LEFT JOIN companies c ON c.id = pconv.unit_id
         WHERE pconv.phone = $1 ${convFilter}
         ORDER BY pconv.start_at DESC`,
        convParams
      );

      res.json({
        contact: contactRes.rows[0] || null,
        conversations: conversationsRes.rows,
        total: conversationsRes.rows.length,
      });
    } catch (err) {
      logger.error(`[Prospection] GET /contacts/:phone/history error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/prospection/filter-options ──────────────────────────────────
  // Retorna listas de unidades e operadores com contatos de prospecção.
  // Não-admins só recebem unidades dentro de allowedUnitIds.
  router.get('/filter-options', requireAuth, async (req, res) => {
    try {
      const user = req.currentUser;
      const isAdmin = user?.isAdmin === true;
      const allowedUnitIds = Array.isArray(user?.allowedUnitIds) ? user.allowedUnitIds : [];

      // Build unit query from companies table directly (not from contacts).
      // This ensures ALL accessible units appear in the filter even before any
      // contact has been assigned to them.
      let unitsRes;
      if (!isAdmin && allowedUnitIds.length === 0) {
        unitsRes = { rows: [] };
      } else if (!isAdmin) {
        unitsRes = await pool.query(`
          SELECT id,
                 COALESCE(NULLIF(nome_fantasia, ''), razao_social) AS name
            FROM companies
           WHERE id = ANY($1::uuid[])
             AND COALESCE(NULLIF(nome_fantasia, ''), razao_social) IS NOT NULL
           ORDER BY name
        `, [allowedUnitIds]);
      } else {
        unitsRes = await pool.query(`
          SELECT id,
                 COALESCE(NULLIF(nome_fantasia, ''), razao_social) AS name
            FROM companies
           WHERE COALESCE(NULLIF(nome_fantasia, ''), razao_social) IS NOT NULL
           ORDER BY name
        `);
      }

      // Operators — returns ALL active collaborators (not just those linked to contacts).
      // This allows the filter to work even before any operator has been assigned.
      // Non-admins are scoped to collaborators belonging to their allowed units.
      let operatorsRes;
      if (!isAdmin && allowedUnitIds.length === 0) {
        operatorsRes = { rows: [] };
      } else if (!isAdmin) {
        operatorsRes = await pool.query(`
          SELECT col.id, col.name
            FROM collaborators col
           WHERE col.name IS NOT NULL
             AND col.name != ''
             AND col.unit_id = ANY($1::uuid[])
           ORDER BY col.name
        `, [allowedUnitIds]);
      } else {
        operatorsRes = await pool.query(`
          SELECT col.id, col.name
            FROM collaborators col
           WHERE col.name IS NOT NULL
             AND col.name != ''
           ORDER BY col.name
        `);
      }

      res.json({
        units: unitsRes.rows,
        operators: operatorsRes.rows,
      });
    } catch (err) {
      logger.error(`[Prospection] GET /filter-options error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/prospection/unread-counts ───────────────────────────────────
  // Returns per-phone unread message counts from gotalk_messages (last 30 days).
  // Used on panel mount to hydrate waUnread state with DB-persisted unread data.
  // Response: { counts: { [canonicalPhone]: { gotalk: n, uazapi: n } }, total: N }
  //
  // SEGURANÇA: não-admins só recebem contatos das suas unidades (allowedUnitIds).
  router.get('/unread-counts', requireAuth, async (req, res) => {
    try {
      const user = req.currentUser;
      const isAdmin = user?.isAdmin === true;
      const allowedUnitIds = Array.isArray(user?.allowedUnitIds) ? user.allowedUnitIds : [];

      if (!isAdmin && allowedUnitIds.length === 0) {
        return res.json({ counts: {}, total: 0 });
      }

      const unitFilter = isAdmin ? '' : `AND pc.unit_id = ANY($1::uuid[])`;
      const params = isAdmin ? [] : [allowedUnitIds];

      const result = await pool.query(
        `SELECT pc.phone,
                COALESCE(gm.source, 'gotalk') AS source,
                COUNT(*) AS cnt
         FROM gotalk_messages gm
         JOIN prospection_contacts pc ON
           RIGHT(REGEXP_REPLACE(gm.phone_number, '[^0-9]', '', 'g'), 10) =
           RIGHT(REGEXP_REPLACE(pc.phone,        '[^0-9]', '', 'g'), 10)
         WHERE gm.direction = 'IN'
           AND gm.read_at IS NULL
           ${unitFilter}
         GROUP BY pc.phone, gm.source`,
        params
      );

      const counts = {};
      let total = 0;
      for (const row of result.rows) {
        const phone = String(row.phone).replace(/\D/g, '');
        if (!counts[phone]) counts[phone] = { gotalk: 0, uazapi: 0 };
        const src = row.source === 'uazapi' ? 'uazapi' : 'gotalk';
        const n = parseInt(row.cnt, 10);
        counts[phone][src] = n;
        total += n;
      }

      res.json({ counts, total });
    } catch (err) {
      logger.error(`[Prospection] GET /unread-counts error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── PATCH /api/prospection/contacts/:id ──────────────────────────────────
  // Atualiza campos de um contato de prospecção.
  // Body: { client_id?, last_source?, uazapi_instance_id?, uazapi_unit_id? }
  router.patch('/contacts/:id', requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const { client_id, last_source, uazapi_instance_id, uazapi_unit_id } = req.body || {};

      // Unit-level authorization: non-admin users may only edit contacts
      // that belong to one of their allowed units.
      const user = req.currentUser;
      const isAdmin = user?.isAdmin === true;
      if (!isAdmin) {
        const allowedUnitIds = Array.isArray(user?.allowedUnitIds) ? user.allowedUnitIds : [];
        const contactCheck = await pool.query(
          `SELECT unit_id FROM prospection_contacts WHERE id = $1`,
          [id]
        );
        if (contactCheck.rows.length === 0) {
          return res.status(404).json({ error: 'Contato não encontrado.' });
        }
        const contactUnitId = contactCheck.rows[0].unit_id;
        if (contactUnitId && !allowedUnitIds.includes(contactUnitId)) {
          return res.status(403).json({ error: 'Acesso negado a este contato.' });
        }
      }

      const setClauses = ['updated_at = NOW()'];
      const params = [];

      if (client_id !== undefined) {
        params.push(client_id || null);
        setClauses.push(`client_id = $${params.length}`);
      }

      if (last_source !== undefined) {
        if (!['gotalk', 'uazapi'].includes(last_source)) {
          return res.status(400).json({ error: 'last_source deve ser "gotalk" ou "uazapi".' });
        }
        params.push(last_source);
        setClauses.push(`last_source = $${params.length}`);
      }

      if (uazapi_instance_id !== undefined) {
        params.push(uazapi_instance_id || null);
        setClauses.push(`uazapi_instance_id = $${params.length}`);
      }

      // Task #294: persistent instance-lock for explicit channel switches and
      // auto-follow on inbound replies. Always overwrites prior value.
      if (req.body && Object.prototype.hasOwnProperty.call(req.body, 'last_inbound_instance_id')) {
        const lii = req.body.last_inbound_instance_id;
        params.push(lii || null);
        setClauses.push(`last_inbound_instance_id = $${params.length}`);
      }

      if (uazapi_unit_id !== undefined) {
        // Security: non-admins may only assign uazapi_unit_id to a unit they have access to
        if (uazapi_unit_id && !isAdmin) {
          const allowedUnitIds = Array.isArray(user?.allowedUnitIds) ? user.allowedUnitIds : [];
          if (!allowedUnitIds.includes(uazapi_unit_id)) {
            return res.status(403).json({ error: 'Acesso negado à unidade uazapi solicitada.' });
          }
        }
        params.push(uazapi_unit_id || null);
        setClauses.push(`uazapi_unit_id = $${params.length}`);
      }

      if (params.length === 0) {
        return res.status(400).json({ error: 'Nenhum campo para atualizar.' });
      }

      params.push(id);
      const r = await withMutation(pool, async client => {
        const before = await client.query('SELECT * FROM prospection_contacts WHERE id = $1 FOR UPDATE', [id]);
        if (!before.rows[0]) return { rows: [], rowCount: 0 };
        const updated = await client.query(
          `UPDATE prospection_contacts SET ${setClauses.join(', ')} WHERE id = $${params.length} RETURNING *`,
          params
        );
        if (updated.rows[0]) await auditMutation(client, req, 'PROSPECCAO_CONTATO', id, 'UPDATE', before.rows[0], updated.rows[0]);
        return updated;
      });

      if (r.rows.length === 0) return res.status(404).json({ error: 'Contato não encontrado.' });
      res.json({ contact: r.rows[0] });
    } catch (err) {
      logger.error(`[Prospection] PATCH /contacts/:id error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── POST /api/prospection/conversations ──────────────────────────────────
  // Abre/registra uma nova conversa de prospecção para um número.
  // Body: { phone, unitId?, operatorId?, operatorName?, source? }
  router.post('/conversations', requireAuth, async (req, res) => {
    try {
      const { phone: rawPhone, unitId, operatorId, operatorName, source = 'uazapi', instanceId } = req.body || {};
      const phone = normalizePhone(rawPhone);
      if (!phone) return res.status(400).json({ error: 'Campo phone obrigatório.' });

      const r = await withMutation(pool, async client => {
      const contactRes = await client.query(
        `SELECT classification, uazapi_instance_id FROM prospection_contacts WHERE phone = $1`,
        [phone]
      );
      const classification = contactRes.rows[0]?.classification || 'LEAD';
      const resolvedInstanceId = instanceId || contactRes.rows[0]?.uazapi_instance_id || null;
      const inserted = await client.query(
        `INSERT INTO prospection_conversations
           (phone, classification, start_at, operator_id, operator_name, unit_id, source, uazapi_instance_id)
         VALUES ($1, $2, NOW(), $3, $4, $5, $6, $7)
         RETURNING *`,
        [phone, classification, operatorId || null, operatorName || null, unitId || null, source, resolvedInstanceId]
      );
      await auditMutation(client, req, 'PROSPECCAO_CONVERSA', inserted.rows[0].id, 'CREATE', null, inserted.rows[0]);
      return inserted;
      });
      res.status(201).json({ conversation: r.rows[0] });
    } catch (err) {
      logger.error(`[Prospection] POST /conversations error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── PATCH /api/prospection/conversations/:id/summary ─────────────────────
  // Salva resumo e encerra uma conversa de prospecção.
  // Body: { outcome, summaryText, summaryData?, messageCount? }
  router.patch('/conversations/:id/summary', requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const { outcome, summaryText, summaryData = {}, messageCount } = req.body || {};

      const validOutcomes = ['INTERESSE_ALTO', 'INTERESSE_MEDIO', 'INTERESSE_BAIXO', 'SEM_INTERESSE', 'NAO_DEFINIDO'];
      const outcomeVal = validOutcomes.includes(outcome) ? outcome : 'NAO_DEFINIDO';

      const r = await withMutation(pool, async client => {
      const before = await client.query('SELECT * FROM prospection_conversations WHERE id = $1 FOR UPDATE', [id]);
      if (!before.rows[0]) return { rows: [] };
      const updated = await client.query(
        `UPDATE prospection_conversations
         SET end_at       = COALESCE(end_at, NOW()),
             outcome      = $1,
             summary_text = $2,
             summary_data = $3::jsonb,
             message_count = COALESCE($4, message_count),
             updated_at   = NOW()
         WHERE id = $5
         RETURNING *`,
        [outcomeVal, summaryText || null, JSON.stringify(summaryData), messageCount || null, id]
      );
      await auditMutation(client, req, 'PROSPECCAO_CONVERSA', id, 'UPDATE', before.rows[0], updated.rows[0]);
      return updated;
      });
      if (r.rows.length === 0) return res.status(404).json({ error: 'Conversa não encontrada.' });

      res.json({ conversation: r.rows[0] });
    } catch (err) {
      logger.error(`[Prospection] PATCH /conversations/:id/summary error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/prospection/dashboard ───────────────────────────────────────
  // Dados agregados para o dashboard de indicadores.
  // Query params:
  //   period   — today | 7d | 30d | custom (default: 30d)
  //   dateFrom — ISO date string (only when period=custom)
  //   dateTo   — ISO date string (only when period=custom)
  //   unitId   — UUID for single-unit drill-down (takes precedence over unitIds)
  //   unitIds  — CSV of UUIDs for multi-unit selection (intersected with allowedUnitIds)
  //   groupBy  — day | week | month (default: day) — granularity of the time series
  //
  // SEGURANÇA: não-admins só vêem dados das unidades em req.currentUser.allowedUnitIds.
  router.get('/dashboard', requireAuth, async (req, res) => {
    try {
      const { period = '30d', dateFrom, dateTo, unitId, unitIds: unitIdsParam, groupBy = 'day' } = req.query;

      // Whitelist groupBy — value is used raw inside DATE_TRUNC
      const truncUnit = ['day', 'week', 'month'].includes(groupBy) ? groupBy : 'day';

      const user = req.currentUser;
      const isAdmin = user?.isAdmin === true;
      const allowedUnitIds = Array.isArray(user?.allowedUnitIds) ? user.allowedUnitIds : [];

      // Parse unitIds — distinguish "param absent" from "param present but all tokens malformed".
      const unitIdsExplicit  = unitIdsParam !== undefined; // true = client intentionally passed the param
      const requestedUnitIds = parseUnitIds(unitIdsParam);

      // Compute the effective unit filter for this user.
      // Priority: unitId (single drill-down) > unitIds (multi-selection) > all allowed.
      // Security: client-provided unitIds/unitId are always intersected with allowedUnitIds.
      // Semantics:
      //   • unitIds absent            → no sub-filter → use all units visible to user
      //   • unitIds present, valid    → intersect with allowed (empty intersection → empty result)
      //   • unitIds present, malformed → explicit empty → return empty (strict)
      let dashUnitId = null;    // single UUID for drill-down
      let dashUnitIds = null;   // array for multi-unit (null = no filter = all visible)

      const EMPTY_DASH = { kpi: { total_contacts: '0', total_leads: '0', total_recuperacoes: '0', total_conversations: '0', total_encerradas: '0', interesse_alto: '0', interesse_medio: '0', interesse_baixo: '0', sem_interesse: '0' }, byUnit: [], byOperator: [], timeSeries: [], groupBy: truncUnit };

      if (unitId) {
        // Reject malformed unitId before SQL ::uuid cast (avoid avoidable 500s)
        if (!UUID_RE.test(unitId)) {
          return res.json(EMPTY_DASH);
        }
        // Single unit drill-down — validate against allowedUnitIds for non-admins
        if (!isAdmin && !allowedUnitIds.includes(unitId)) {
          return res.json(EMPTY_DASH);
        }
        dashUnitId = unitId;
      } else if (!isAdmin) {
        if (allowedUnitIds.length === 0) {
          return res.json(EMPTY_DASH);
        }
        if (unitIdsExplicit) {
          if (requestedUnitIds.length === 0) {
            // All tokens malformed → explicit empty
            return res.json(EMPTY_DASH);
          }
          const intersection = requestedUnitIds.filter(id => allowedUnitIds.includes(id));
          if (intersection.length === 0) {
            return res.json(EMPTY_DASH);
          }
          dashUnitIds = intersection;
        } else {
          // No sub-filter: show all allowed units
          dashUnitIds = allowedUnitIds;
        }
      } else if (unitIdsExplicit) {
        // Admin with optional sub-filter
        if (requestedUnitIds.length === 0) {
          return res.json(EMPTY_DASH);
        }
        dashUnitIds = requestedUnitIds;
      }

      // buildWhere — builds a WHERE clause + params array for a given timestamp field + optional unit field.
      // All param numbering starts at $1 per independent query (each query gets its own params array).
      function buildWhere(tsField, unitField) {
        const clauses = [];
        const params = [];

        if (period === 'today') {
          clauses.push(`${tsField} >= CURRENT_DATE`);
        } else if (period === '7d') {
          clauses.push(`${tsField} >= NOW() - INTERVAL '7 days'`);
        } else if (period === '30d') {
          clauses.push(`${tsField} >= NOW() - INTERVAL '30 days'`);
        } else if (period === 'custom') {
          if (dateFrom) {
            params.push(dateFrom);
            clauses.push(`${tsField} >= $${params.length}::date`);
          }
          if (dateTo) {
            params.push(dateTo);
            clauses.push(`${tsField} < ($${params.length}::date + INTERVAL '1 day')`);
          }
        }

        if (unitField) {
          if (dashUnitId) {
            params.push(dashUnitId);
            clauses.push(`${unitField} = $${params.length}`);
          } else if (dashUnitIds) {
            params.push(dashUnitIds);
            clauses.push(`${unitField} = ANY($${params.length}::uuid[])`);
          }
        }

        return {
          whereClause: clauses.length ? `WHERE ${clauses.join(' AND ')}` : '',
          params,
        };
      }

      const cContact = buildWhere('pc.last_contact_at',    'pc.unit_id');
      const cConv    = buildWhere('pconv.start_at',         'pconv.unit_id');
      const cSeries  = buildWhere('pc.first_contact_at',   'pc.unit_id');

      const [kpiRes, convKpiRes, byUnitRes, byOperatorRes, seriesRes] = await Promise.all([
        // KPIs from contacts
        pool.query(
          `SELECT
             COUNT(*) AS total_contacts,
             COUNT(*) FILTER (WHERE pc.classification = 'LEAD') AS total_leads,
             COUNT(*) FILTER (WHERE pc.classification = 'RECUPERACAO') AS total_recuperacoes
           FROM prospection_contacts pc ${cContact.whereClause}`,
          cContact.params
        ),

        // KPIs from conversations (outcomes)
        pool.query(
          `SELECT
             COUNT(*) AS total_conversations,
             COUNT(*) FILTER (WHERE pconv.end_at IS NOT NULL) AS total_encerradas,
             COUNT(*) FILTER (WHERE pconv.outcome = 'INTERESSE_ALTO') AS interesse_alto,
             COUNT(*) FILTER (WHERE pconv.outcome = 'INTERESSE_MEDIO') AS interesse_medio,
             COUNT(*) FILTER (WHERE pconv.outcome = 'INTERESSE_BAIXO') AS interesse_baixo,
             COUNT(*) FILTER (WHERE pconv.outcome = 'SEM_INTERESSE') AS sem_interesse
           FROM prospection_conversations pconv ${cConv.whereClause}`,
          cConv.params
        ),

        // By unit
        pool.query(
          `SELECT
             COALESCE(c.nome_fantasia, c.razao_social, 'Sem unidade') AS unit_name,
             COUNT(*) AS total,
             COUNT(*) FILTER (WHERE pc.classification = 'LEAD') AS leads,
             COUNT(*) FILTER (WHERE pc.classification = 'RECUPERACAO') AS recuperacoes
           FROM prospection_contacts pc
           LEFT JOIN companies c ON c.id = pc.unit_id
           ${cContact.whereClause}
           GROUP BY c.id, c.nome_fantasia, c.razao_social
           ORDER BY total DESC`,
          cContact.params
        ),

        // By operator — leads/recuperacoes from contact classification (consistent with KPI)
        pool.query(
          `SELECT
             COALESCE(col.name, pconv.operator_name, 'Sem operador') AS operator_name,
             COALESCE(c.nome_fantasia, c.razao_social, 'Sem unidade') AS unit_name,
             COUNT(*) AS total_conversations,
             COUNT(*) FILTER (WHERE EXISTS (
               SELECT 1 FROM prospection_contacts pc2
               WHERE pc2.phone = pconv.phone AND pc2.unit_id = pconv.unit_id
                 AND pc2.classification = 'LEAD'
             )) AS leads,
             COUNT(*) FILTER (WHERE EXISTS (
               SELECT 1 FROM prospection_contacts pc2
               WHERE pc2.phone = pconv.phone AND pc2.unit_id = pconv.unit_id
                 AND pc2.classification = 'RECUPERACAO'
             )) AS recuperacoes,
             COUNT(*) FILTER (WHERE pconv.outcome = 'INTERESSE_ALTO') AS interesse_alto,
             COUNT(*) FILTER (WHERE pconv.end_at IS NOT NULL) AS encerradas
           FROM prospection_conversations pconv
           LEFT JOIN collaborators col ON col.id = pconv.operator_id
           LEFT JOIN companies c ON c.id = pconv.unit_id
           ${cConv.whereClause}
           GROUP BY col.id, col.name, pconv.operator_name, c.id, c.nome_fantasia, c.razao_social
           ORDER BY total_conversations DESC
           LIMIT 20`,
          cConv.params
        ),

        // Time series — groupBy (day|week|month) with same period + unitId filters
        pool.query(
          `SELECT
             DATE_TRUNC('${truncUnit}', pc.first_contact_at)::date AS bucket,
             COUNT(*) FILTER (WHERE pc.classification = 'LEAD') AS leads,
             COUNT(*) FILTER (WHERE pc.classification = 'RECUPERACAO') AS recuperacoes
           FROM prospection_contacts pc
           ${cSeries.whereClause}
           GROUP BY DATE_TRUNC('${truncUnit}', pc.first_contact_at)
           ORDER BY bucket ASC`,
          cSeries.params
        ),
      ]);

      // ── KPI: total scheduled contacts in the same period ─────────────────
      // Counts distinct client_ids that have an appointment with date within
      // the selected period and belong to the visible units.
      const apptWhereParts = [];
      const apptParams = [];
      if (period === 'today') {
        apptWhereParts.push(`a.date = CURRENT_DATE`);
      } else if (period === '7d') {
        apptWhereParts.push(`a.date >= (CURRENT_DATE - INTERVAL '7 days')`);
      } else if (period === '30d') {
        apptWhereParts.push(`a.date >= (CURRENT_DATE - INTERVAL '30 days')`);
      } else if (period === 'custom') {
        if (dateFrom) { apptParams.push(dateFrom); apptWhereParts.push(`a.date >= $${apptParams.length}::date`); }
        if (dateTo)   { apptParams.push(dateTo);   apptWhereParts.push(`a.date <= $${apptParams.length}::date`); }
      }
      if (dashUnitId) {
        apptParams.push(dashUnitId);
        // Primary: direct text equality handles UUID-format unit_ids (post-migration standard).
        // Fallback EXISTS via companies: catches any legacy rows whose unit_id was not yet
        // normalized by the initDB() backfill (uc.id::text only matches UUID text, not short IDs,
        // but the backfill migration covers prospection-linked rows, making this defense-in-depth).
        apptWhereParts.push(`(a.unit_id = $${apptParams.length}::text OR EXISTS (SELECT 1 FROM companies uc WHERE uc.id = $${apptParams.length}::uuid AND uc.id::text = a.unit_id))`);
      } else if (dashUnitIds) {
        apptParams.push(dashUnitIds);
        // Same dual-path match for array case (non-admin multi-unit users).
        apptWhereParts.push(`(a.unit_id = ANY($${apptParams.length}::text[]) OR EXISTS (SELECT 1 FROM companies uc WHERE uc.id = ANY($${apptParams.length}::uuid[]) AND uc.id::text = a.unit_id))`);
      }
      // Only count appointments linked to a prospection contact.
      // Primary: prospection_contact_id UUID (direct, indexed). Fallback to client_id ONLY when link is NULL.
      apptWhereParts.push(`EXISTS (
        SELECT 1 FROM prospection_contacts pc2
        WHERE (a.prospection_contact_id IS NOT NULL AND pc2.id = a.prospection_contact_id)
           OR (a.prospection_contact_id IS NULL AND a.client_id IS NOT NULL
               AND pc2.client_id IS NOT NULL AND pc2.client_id::text = a.client_id::text)
      )`);
      const apptWhereClause = apptWhereParts.length ? `WHERE ${apptWhereParts.join(' AND ')}` : '';
      const [apptKpiRes, byModalidadeRes] = await Promise.all([
        pool.query(
          `SELECT COUNT(*) AS total_agendados
             FROM appointments a
             ${apptWhereClause}`,
          apptParams
        ),
        pool.query(
          `SELECT
             COALESCE(NULLIF(a.modalidade, ''), 'SEM_MODALIDADE') AS modalidade,
             COUNT(*) AS total,
             COUNT(*) FILTER (WHERE a.status NOT IN ('CANCELADO_CLIENTE', 'CANCELADO_CONSULTOR')) AS agendados,
             COUNT(*) FILTER (WHERE a.status IN ('CANCELADO_CLIENTE', 'CANCELADO_CONSULTOR')) AS cancelados
           FROM appointments a
           ${apptWhereClause}
           GROUP BY COALESCE(NULLIF(a.modalidade, ''), 'SEM_MODALIDADE')
           ORDER BY total DESC`,
          apptParams
        ),
      ]);

      res.json({
        kpi: { ...kpiRes.rows[0], ...convKpiRes.rows[0], total_agendados: apptKpiRes.rows[0]?.total_agendados || '0' },
        byUnit: byUnitRes.rows,
        byOperator: byOperatorRes.rows,
        timeSeries: seriesRes.rows,
        byModalidade: byModalidadeRes.rows,
        groupBy: truncUnit,
      });
    } catch (err) {
      logger.error(`[Prospection] GET /dashboard error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/prospection/dashboard/report ────────────────────────────────
  // Returns detailed tabular data for dashboard drill-down and report tables.
  // type: leads | recuperacoes | agendados | cancelados | encerramento
  router.get('/dashboard/report', requireAuth, async (req, res) => {
    try {
      const { type, period = '30d', dateFrom, dateTo, unitId, unitIds: unitIdsParam } = req.query;
      const validTypes = ['leads', 'recuperacoes', 'agendados', 'cancelados', 'encerramento', 'modalidade'];
      if (!validTypes.includes(type)) {
        return res.status(400).json({ error: 'type inválido' });
      }

      const user = req.currentUser;
      const isAdmin = user?.isAdmin === true;
      const allowedUnitIds = Array.isArray(user?.allowedUnitIds) ? user.allowedUnitIds : [];

      const unitIdsExplicit = unitIdsParam !== undefined;
      const requestedUnitIds = parseUnitIds(unitIdsParam);
      let dashUnitId = null;
      let dashUnitIds = null;

      if (unitId) {
        if (!UUID_RE.test(unitId)) return res.status(400).json({ error: 'unitId inválido' });
        if (!isAdmin && !allowedUnitIds.includes(unitId)) return res.json({ rows: [] });
        dashUnitId = unitId;
      } else if (!isAdmin) {
        if (allowedUnitIds.length === 0) return res.json({ rows: [] });
        if (unitIdsExplicit) {
          if (requestedUnitIds.length === 0) return res.json({ rows: [] });
          const inter = requestedUnitIds.filter(id => allowedUnitIds.includes(id));
          if (inter.length === 0) return res.json({ rows: [] });
          dashUnitIds = inter;
        } else {
          dashUnitIds = allowedUnitIds;
        }
      } else if (unitIdsExplicit) {
        if (requestedUnitIds.length === 0) return res.json({ rows: [] });
        dashUnitIds = requestedUnitIds;
      }

      // Build contact WHERE clause (last_contact_at + unit_id)
      function buildContactWhere() {
        const clauses = [];
        const params = [];
        if (period === 'today') { clauses.push(`pc.last_contact_at >= CURRENT_DATE`); }
        else if (period === '7d') { clauses.push(`pc.last_contact_at >= NOW() - INTERVAL '7 days'`); }
        else if (period === '30d') { clauses.push(`pc.last_contact_at >= NOW() - INTERVAL '30 days'`); }
        else if (period === 'custom') {
          if (dateFrom) { params.push(dateFrom); clauses.push(`pc.last_contact_at >= $${params.length}::date`); }
          if (dateTo)   { params.push(dateTo);   clauses.push(`pc.last_contact_at < ($${params.length}::date + INTERVAL '1 day')`); }
        }
        if (dashUnitId) { params.push(dashUnitId); clauses.push(`pc.unit_id = $${params.length}`); }
        else if (dashUnitIds) { params.push(dashUnitIds); clauses.push(`pc.unit_id = ANY($${params.length}::uuid[])`); }
        return { w: clauses.length ? `WHERE ${clauses.join(' AND ')}` : '', p: params };
      }

      // Build appointment WHERE clause (date + unit_id)
      function buildApptWhere(extraClause) {
        const parts = [];
        const params = [];
        if (period === 'today') { parts.push(`a.date = CURRENT_DATE`); }
        else if (period === '7d') { parts.push(`a.date >= (CURRENT_DATE - INTERVAL '7 days')`); }
        else if (period === '30d') { parts.push(`a.date >= (CURRENT_DATE - INTERVAL '30 days')`); }
        else if (period === 'custom') {
          if (dateFrom) { params.push(dateFrom); parts.push(`a.date >= $${params.length}::date`); }
          if (dateTo)   { params.push(dateTo);   parts.push(`a.date <= $${params.length}::date`); }
        }
        if (dashUnitId) { params.push(dashUnitId); parts.push(`(a.unit_id = $${params.length}::text OR EXISTS (SELECT 1 FROM companies uc WHERE uc.id = $${params.length}::uuid AND uc.id::text = a.unit_id))`); }
        else if (dashUnitIds) { params.push(dashUnitIds); parts.push(`(a.unit_id = ANY($${params.length}::text[]) OR EXISTS (SELECT 1 FROM companies uc WHERE uc.id = ANY($${params.length}::uuid[]) AND uc.id::text = a.unit_id))`); }
        parts.push(`EXISTS (SELECT 1 FROM prospection_contacts pc2 WHERE (a.prospection_contact_id IS NOT NULL AND pc2.id = a.prospection_contact_id) OR (a.prospection_contact_id IS NULL AND a.client_id IS NOT NULL AND pc2.client_id IS NOT NULL AND pc2.client_id::text = a.client_id::text))`);
        if (extraClause) parts.push(extraClause);
        return { w: parts.length ? `WHERE ${parts.join(' AND ')}` : '', p: params };
      }

      // Build conversation WHERE clause (start_at + unit_id)
      function buildConvWhere(extraClause) {
        const clauses = [];
        const params = [];
        if (period === 'today') { clauses.push(`pconv.start_at >= CURRENT_DATE`); }
        else if (period === '7d') { clauses.push(`pconv.start_at >= NOW() - INTERVAL '7 days'`); }
        else if (period === '30d') { clauses.push(`pconv.start_at >= NOW() - INTERVAL '30 days'`); }
        else if (period === 'custom') {
          if (dateFrom) { params.push(dateFrom); clauses.push(`pconv.start_at >= $${params.length}::date`); }
          if (dateTo)   { params.push(dateTo);   clauses.push(`pconv.start_at < ($${params.length}::date + INTERVAL '1 day')`); }
        }
        if (dashUnitId) { params.push(dashUnitId); clauses.push(`pconv.unit_id = $${params.length}`); }
        else if (dashUnitIds) { params.push(dashUnitIds); clauses.push(`pconv.unit_id = ANY($${params.length}::uuid[])`); }
        if (extraClause) clauses.push(extraClause);
        return { w: clauses.length ? `WHERE ${clauses.join(' AND ')}` : '', p: params };
      }

      let result;

      if (type === 'leads' || type === 'recuperacoes') {
        const classification = type === 'leads' ? 'LEAD' : 'RECUPERACAO';
        const { w, p } = buildContactWhere();
        const classification_param_idx = p.length + 1;
        result = await pool.query(
          `SELECT
             pc.id,
             pc.contact_name AS nome,
             pc.phone AS telefone,
             pc.classification AS tipo,
             COALESCE(c.nome_fantasia, c.razao_social, 'Sem unidade') AS unidade,
             -- Note: prospection_contacts has no operator_name text column (only operator_id UUID).
             -- COALESCE(col.name, 'Sem operador') is the only available operator attribution.
             -- If the collaborator record is deleted, the attribution gracefully degrades to 'Sem operador'.
             COALESCE(col.name, 'Sem operador') AS operador,
             COALESCE(pc.last_source, pc.source, '') AS canal,
             pc.first_contact_at AS primeiro_contato,
             pc.last_contact_at AS ultimo_contato
           FROM prospection_contacts pc
           LEFT JOIN companies c ON c.id = pc.unit_id
           LEFT JOIN collaborators col ON col.id = pc.operator_id
           ${w}
           ${w ? 'AND' : 'WHERE'} pc.classification = $${classification_param_idx}
           ORDER BY pc.last_contact_at DESC NULLS LAST
           LIMIT 1000`,
          [...p, classification]
        );
      } else if (type === 'agendados' || type === 'cancelados') {
        const isCancelled = type === 'cancelados';
        // agendados = ALL appointments linked to prospection (matches KPI count)
        // cancelados = only cancelled ones
        const extraClause = isCancelled
          ? `a.status IN ('CANCELADO_CLIENTE', 'CANCELADO_CONSULTOR')`
          : null;
        const { w, p } = buildApptWhere(extraClause);
        result = await pool.query(
          `SELECT
             a.id,
             a.client_name AS cliente,
             a.date AS data,
             a.start_time AS hora_inicio,
             a.end_time AS hora_fim,
             a.status,
             COALESCE(NULLIF(a.modalidade, ''), 'SEM_MODALIDADE') AS modalidade,
             a.notes AS observacoes,
             col.name AS consultor,
             COALESCE(c.nome_fantasia, c.razao_social, 'Sem unidade') AS unidade,
             COALESCE(pc.contact_name, pc.phone, '') AS contato_prospecao,
             COALESCE(pc.phone, '') AS telefone
           FROM appointments a
           LEFT JOIN collaborators col ON col.id::text = a.collaborator_id::text
           LEFT JOIN companies c ON c.id::text = a.unit_id
           LEFT JOIN prospection_contacts pc ON pc.id = a.prospection_contact_id
           ${w}
           ORDER BY a.date DESC, a.start_time DESC NULLS LAST
           LIMIT 1000`,
          p
        );
      } else if (type === 'encerramento') {
        const { w, p } = buildConvWhere(`pconv.end_at IS NOT NULL`);
        result = await pool.query(
          `SELECT
             pconv.id,
             COALESCE(pconv.outcome, 'NAO_DEFINIDO') AS desfecho,
             COALESCE(col.name, pconv.operator_name, 'Sem operador') AS operador,
             COALESCE(c.nome_fantasia, c.razao_social, 'Sem unidade') AS unidade,
             pconv.classification AS tipo_contato,
             pconv.start_at AS inicio,
             pconv.end_at AS encerramento,
             pconv.source AS canal
           FROM prospection_conversations pconv
           LEFT JOIN collaborators col ON col.id = pconv.operator_id
           LEFT JOIN companies c ON c.id = pconv.unit_id
           ${w}
           ORDER BY pconv.end_at DESC NULLS LAST
           LIMIT 1000`,
          p
        );
      } else if (type === 'modalidade') {
        // Detailed appointments by modalidade param
        const modalidadeFilter = (req.query.modalidade || '').toUpperCase();
        const { w, p } = buildApptWhere(null);
        const modalParam = p.length + 1;
        const useFilter = ['PRESENCIAL', 'ONLINE', 'SEM_MODALIDADE'].includes(modalidadeFilter);
        const modalClause = useFilter
          ? (modalidadeFilter === 'SEM_MODALIDADE'
            ? `AND (a.modalidade IS NULL OR a.modalidade = '')`
            : `AND a.modalidade = $${modalParam}`)
          : '';
        const finalParams = useFilter && modalidadeFilter !== 'SEM_MODALIDADE' ? [...p, modalidadeFilter] : p;
        result = await pool.query(
          `SELECT
             a.id,
             a.client_name AS cliente,
             a.date AS data,
             a.start_time AS hora_inicio,
             a.end_time AS hora_fim,
             a.status,
             COALESCE(NULLIF(a.modalidade, ''), 'SEM_MODALIDADE') AS modalidade,
             a.notes AS observacoes,
             col.name AS consultor,
             COALESCE(c.nome_fantasia, c.razao_social, 'Sem unidade') AS unidade,
             COALESCE(pc.contact_name, pc.phone, '') AS contato_prospecao,
             COALESCE(pc.phone, '') AS telefone
           FROM appointments a
           LEFT JOIN collaborators col ON col.id::text = a.collaborator_id::text
           LEFT JOIN companies c ON c.id::text = a.unit_id
           LEFT JOIN prospection_contacts pc ON pc.id = a.prospection_contact_id
           ${w}
           ${modalClause}
           ORDER BY a.date DESC, a.start_time DESC NULLS LAST
           LIMIT 1000`,
          finalParams
        );
      }

      res.json({ rows: result.rows, type, period });
    } catch (err) {
      logger.error(`[Prospection] GET /dashboard/report error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── PATCH /api/prospection/contacts/:id/operator ─────────────────────────
  // Atribui (ou remove) um operador a um contato de prospecção.
  // Body: { operatorId: uuid | null }
  // Requires ALTERAR permission (any authenticated user may call this for now).
  router.patch('/contacts/:id/operator', requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      const { operatorId } = req.body || {};

      if (!UUID_RE.test(id)) {
        return res.status(400).json({ error: 'ID de contato inválido.' });
      }

      // operatorId may be null (to clear) or a valid UUID
      if (operatorId !== null && operatorId !== undefined && !UUID_RE.test(operatorId)) {
        return res.status(400).json({ error: 'operatorId inválido.' });
      }

      const result = await withMutation(pool, async client => {
      const before = await client.query('SELECT * FROM prospection_contacts WHERE id = $1 FOR UPDATE', [id]);
      const updated = await client.query(
        `UPDATE prospection_contacts
            SET operator_id = $1,
                updated_at  = NOW()
          WHERE id = $2
          RETURNING id, operator_id`,
        [operatorId || null, id]
      );
      if (updated.rows[0]) await auditMutation(client, req, 'PROSPECCAO_CONTATO', id, 'ASSIGN_OPERATOR', before.rows[0], updated.rows[0]);
      return updated;
      });

      if (result.rowCount === 0) {
        return res.status(404).json({ error: 'Contato não encontrado.' });
      }

      // Return the updated operator name for immediate UI update
      let operatorName = null;
      if (operatorId) {
        const colRes = await pool.query(
          `SELECT name FROM collaborators WHERE id = $1`,
          [operatorId]
        );
        operatorName = colRes.rows[0]?.name || null;
      }

      res.json({ ok: true, operatorId: operatorId || null, operatorName });
    } catch (err) {
      logger.error(`[Prospection] PATCH /contacts/:id/operator error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/prospection/contacts/:id/notes ──────────────────────────────
  // Lista anotações de um contato, ordem cronológica ascendente.
  router.get('/contacts/:id/notes', requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      if (!UUID_RE.test(id)) return res.status(400).json({ error: 'ID inválido.' });
     const r = await pool.query(
       `SELECT id, user_id, user_name, note_text, attachments, created_at, updated_at
          FROM prospection_contact_notes
         WHERE contact_id = $1
         ORDER BY created_at ASC`,
       [id]
     );
     res.json({ notes: r.rows });
    } catch (err) {
      logger.error(`[Prospection] GET /contacts/:id/notes error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── POST /api/prospection/contacts/:id/notes ──────────────────────────────
  // Cria uma nova anotação. user_name e created_at são imutáveis após criação.
  // Body: { noteText, attachments? }
  router.post('/contacts/:id/notes', requireAuth, async (req, res) => {
    try {
      const { id } = req.params;
      if (!UUID_RE.test(id)) return res.status(400).json({ error: 'ID inválido.' });

      const user = req.currentUser;
      const userName = user?.name || user?.email || 'Usuário';
      // user_id is stored for reference only — no FK constraint (migration 037)
      const userId = user?.id || null;

      const { noteText = '', attachments = [] } = req.body || {};
      if (!noteText.trim() && (!Array.isArray(attachments) || attachments.length === 0)) {
        return res.status(400).json({ error: 'Anotação ou anexo obrigatório.' });
      }

      // Validate attachments: array of {name, mimeType, data} with max 5MB each
      if (!Array.isArray(attachments)) {
        return res.status(400).json({ error: 'attachments deve ser um array.' });
      }
      const MAX_ATTACH_SIZE = 5 * 1024 * 1024; // 5MB in base64 chars (approx)
      for (const att of attachments) {
        if (!att.name || !att.data) return res.status(400).json({ error: 'Anexo inválido.' });
        if (att.data.length > MAX_ATTACH_SIZE) return res.status(400).json({ error: `Anexo ${att.name} excede 5MB.` });
        // Block SVG
        const mimeType = (att.mimeType || '').toLowerCase();
        if (mimeType === 'image/svg+xml' || att.name.toLowerCase().endsWith('.svg')) {
          return res.status(400).json({ error: 'Arquivos SVG não são permitidos.' });
        }
      }

     const r = await withMutation(pool, async client => {
       const contact = await client.query('SELECT id FROM prospection_contacts WHERE id = $1 FOR UPDATE', [id]);
       if (!contact.rows[0]) return { rows: [] };
       const inserted = await client.query(
       `INSERT INTO prospection_contact_notes
           (contact_id, user_id, user_name, note_text, attachments)
         VALUES ($1, $2, $3, $4, $5)
         RETURNING id, user_id, user_name, note_text, attachments, created_at, updated_at`,
       [id, userId, userName, noteText.trim(), JSON.stringify(attachments)]
       );
       await auditMutation(client, req, 'PROSPECCAO_NOTA', inserted.rows[0].id, 'CREATE', null, inserted.rows[0]);
       return inserted;
       });
      res.status(201).json({ note: r.rows[0] });
    } catch (err) {
      logger.error(`[Prospection] POST /contacts/:id/notes error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── PATCH /api/prospection/notes/:noteId ─────────────────────────────────
  // Edita apenas note_text e/ou attachments de uma anotação existente.
  // user_name e created_at NÃO podem ser alterados.
  router.patch('/notes/:noteId', requireAuth, async (req, res) => {
    try {
      const { noteId } = req.params;
      if (!UUID_RE.test(noteId)) return res.status(400).json({ error: 'ID de anotação inválido.' });

      const { noteText, attachments } = req.body || {};

      // Build dynamic SET clause (only allowed fields)
      const sets = [];
      const params = [];

      if (noteText !== undefined) {
        params.push(noteText);
        sets.push(`note_text = $${params.length}`);
      }
      if (attachments !== undefined) {
        if (!Array.isArray(attachments)) return res.status(400).json({ error: 'attachments deve ser um array.' });
        params.push(JSON.stringify(attachments));
        sets.push(`attachments = $${params.length}`);
      }
      if (sets.length === 0) return res.status(400).json({ error: 'Nenhum campo editável fornecido.' });

      // updated_at uses SQL NOW() inline — not a bound parameter
      sets.push(`updated_at = NOW()`);

      params.push(noteId);
       const r = await withMutation(pool, async client => {
       const before = await client.query('SELECT * FROM prospection_contact_notes WHERE id = $1 FOR UPDATE', [noteId]);
       if (!before.rows[0]) return { rows: [] };
       const updated = await client.query(
        `UPDATE prospection_contact_notes
            SET ${sets.join(', ')}
          WHERE id = $${params.length}
          RETURNING id, user_id, user_name, note_text, attachments, created_at, updated_at`,
         params
      );
       await auditMutation(client, req, 'PROSPECCAO_NOTA', noteId, 'UPDATE', before.rows[0], updated.rows[0]);
       return updated;
       });
      if (r.rowCount === 0) return res.status(404).json({ error: 'Anotação não encontrada.' });
      res.json({ note: r.rows[0] });
    } catch (err) {
      logger.error(`[Prospection] PATCH /notes/:noteId error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── DELETE /api/prospection/notes/:noteId ────────────────────────────────
  // Remove uma anotação (apenas o próprio criador ou admin).
  router.delete('/notes/:noteId', requireAuth, async (req, res) => {
    try {
      const { noteId } = req.params;
      if (!UUID_RE.test(noteId)) return res.status(400).json({ error: 'ID de anotação inválido.' });

      const user = req.currentUser;
      const isAdmin = user?.isAdmin === true;
      const userId = user?.id || null;

      // Only the creator or an admin may delete
       const r = await withMutation(pool, async client => {
       let deleted;
       if (isAdmin) {
         deleted = await client.query(`DELETE FROM prospection_contact_notes WHERE id = $1 RETURNING *`, [noteId]);
       } else {
         deleted = await client.query(
           `DELETE FROM prospection_contact_notes WHERE id = $1 AND user_id = $2 RETURNING *`,
          [noteId, userId]
        );
      }
       if (deleted.rows[0]) await auditMutation(client, req, 'PROSPECCAO_NOTA', noteId, 'DELETE', deleted.rows[0], null);
       return deleted;
       });
      if (r.rowCount === 0) return res.status(404).json({ error: 'Anotação não encontrada ou sem permissão.' });
      res.json({ ok: true });
    } catch (err) {
      logger.error(`[Prospection] DELETE /notes/:noteId error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/prospection/dashboard/whatsapp-by-unit ──────────────────────
  // Retorna dados consolidados de WhatsApp por unidade para o dashboard:
  //   - Volume de mensagens (IN/OUT) no período (gotalk_messages)
  //   - Contagem de contatos LEAD/RECUPERACAO no período (prospection_contacts)
  //   - Status dos canais GoTalk (gotalk_channels)
  //   - Status de conexão uazapi por unidade (live check com timeout de 4s)
  // Access control: não-admins veem apenas suas unidades permitidas.
  router.get('/dashboard/whatsapp-by-unit', requireAuth, async (req, res) => {
    try {
      const { period = '30d', dateFrom, dateTo, unitId, unitIds: unitIdsParam } = req.query;

      const user = req.currentUser;
      const isAdmin = user?.isAdmin === true;
      const allowedUnitIds = Array.isArray(user?.allowedUnitIds) ? user.allowedUnitIds : [];

      // Resolve effective unit filter
      let unitFilter = null; // null = all (admin, no sub-filter)
      if (unitId && UUID_RE.test(unitId)) {
        if (!isAdmin && !allowedUnitIds.includes(unitId)) return res.json({ units: [] });
        unitFilter = [unitId];
      } else if (!isAdmin) {
        if (allowedUnitIds.length === 0) return res.json({ units: [] });
        const requested = parseUnitIds(unitIdsParam);
        if (requested.length > 0) {
          const inter = requested.filter(id => allowedUnitIds.includes(id));
          // Empty intersection means the user requested units they cannot see → return empty
          if (inter.length === 0) return res.json({ units: [] });
          unitFilter = inter;
        } else {
          unitFilter = allowedUnitIds;
        }
      } else if (unitIdsParam) {
        const requested = parseUnitIds(unitIdsParam);
        if (requested.length > 0) unitFilter = requested;
      }

      // Helper: build period + unit WHERE clause (each query gets its own params array)
      function buildWhere(tsField, unitField) {
        const clauses = [];
        const params = [];
        if (period === 'today') clauses.push(`${tsField} >= CURRENT_DATE`);
        else if (period === '7d') clauses.push(`${tsField} >= NOW() - INTERVAL '7 days'`);
        else if (period === '30d') clauses.push(`${tsField} >= NOW() - INTERVAL '30 days'`);
        else if (period === 'custom') {
          if (dateFrom) { params.push(dateFrom); clauses.push(`${tsField} >= $${params.length}::date`); }
          if (dateTo)   { params.push(dateTo);   clauses.push(`${tsField} < ($${params.length}::date + INTERVAL '1 day')`); }
        }
        if (unitFilter) { params.push(unitFilter); clauses.push(`${unitField} = ANY($${params.length}::uuid[])`); }
        return { w: clauses.length ? `WHERE ${clauses.join(' AND ')}` : '', p: params };
      }

      // Unit filter for non-period queries (channels, credentials)
      function buildUnitOnlyWhere(unitField) {
        if (!unitFilter) return { w: '', p: [] };
        return { w: `WHERE ${unitField} = ANY($1::uuid[])`, p: [unitFilter] };
      }

      const msgWhere     = buildWhere('gm.sent_at',           'gm.unit_id');
      const contactWhere = buildWhere('pc.last_contact_at',   'pc.unit_id');
      const chWhere      = buildUnitOnlyWhere('gc.unit_id');
      const credWhere    = buildUnitOnlyWhere('uw.unit_id');
      const compWhere    = buildUnitOnlyWhere('c.id');

      const [compRes, msgRes, contactRes, chRes, credRes] = await Promise.all([
        // Companies (units)
        pool.query(
          `SELECT id, COALESCE(NULLIF(nome_fantasia,''), razao_social, id::text) AS unit_name
           FROM companies c
           ${compWhere.w}
           ORDER BY unit_name`,
          compWhere.p
        ),
        // Message counts per unit
        pool.query(
          `SELECT gm.unit_id,
             COUNT(*) FILTER (WHERE gm.direction = 'IN')  AS messages_in,
             COUNT(*) FILTER (WHERE gm.direction = 'OUT') AS messages_out,
             COUNT(DISTINCT gm.phone_number) AS active_phones
           FROM gotalk_messages gm
           ${msgWhere.w}
           GROUP BY gm.unit_id`,
          msgWhere.p
        ),
        // Contact classification counts per unit
        pool.query(
          `SELECT pc.unit_id,
             COUNT(*) FILTER (WHERE pc.classification = 'LEAD')        AS leads,
             COUNT(*) FILTER (WHERE pc.classification = 'RECUPERACAO') AS recuperacoes
           FROM prospection_contacts pc
           ${contactWhere.w}
           GROUP BY pc.unit_id`,
          contactWhere.p
        ),
        // GoTalk channels per unit
        pool.query(
          `SELECT gc.unit_id,
             COUNT(*) FILTER (WHERE gc.is_active = TRUE) AS active_channels,
             COUNT(*) AS total_channels,
             COALESCE(json_agg(json_build_object(
               'id',           gc.id::text,
               'name',         COALESCE(gc.name, ''),
               'phone_number', COALESCE(gc.phone_number, ''),
               'is_active',    gc.is_active,
               'is_primary',   gc.is_primary
             ) ORDER BY gc.is_primary DESC NULLS LAST, gc.name ASC), '[]'::json) AS channels
           FROM gotalk_channels gc
           ${chWhere.w}
           GROUP BY gc.unit_id`,
          chWhere.p
        ),
        // uazapi credentials count per unit
        pool.query(
          `SELECT uw.unit_id, COUNT(*) AS instance_count
           FROM unit_whatsapp_credentials uw
           ${credWhere.w}
           GROUP BY uw.unit_id`,
          credWhere.p
        ),
      ]);

      // Build lookup maps
      const msgMap     = new Map(msgRes.rows.map(r => [r.unit_id, r]));
      const contactMap = new Map(contactRes.rows.map(r => [r.unit_id, r]));
      const chMap      = new Map(chRes.rows.map(r => [r.unit_id, r]));
      const credMap    = new Map(credRes.rows.map(r => [r.unit_id, parseInt(r.instance_count, 10)]));

      // Merge rows
      const units = compRes.rows.map(c => {
        const msg     = msgMap.get(c.id) || {};
        const contact = contactMap.get(c.id) || {};
        const ch      = chMap.get(c.id) || {};
        const uazapiInstances = credMap.get(c.id) || 0;
        return {
          unit_id:               c.id,
          unit_name:             c.unit_name,
          messages_in:           parseInt(msg.messages_in, 10)   || 0,
          messages_out:          parseInt(msg.messages_out, 10)  || 0,
          active_phones:         parseInt(msg.active_phones, 10) || 0,
          leads:                 parseInt(contact.leads, 10)         || 0,
          recuperacoes:          parseInt(contact.recuperacoes, 10)  || 0,
          gotalk_active_channels: parseInt(ch.active_channels, 10) || 0,
          gotalk_total_channels:  parseInt(ch.total_channels, 10)  || 0,
          gotalk_channels:        ch.channels || [],
          uazapi_instances:       uazapiInstances,
          uazapi_status:          'unknown', // will be enriched below
        };
      });

      // Enrich uazapi live status for units that have credentials (max 4s timeout each)
      const unitsWithCreds = units.filter(u => u.uazapi_instances > 0);
      if (unitsWithCreds.length > 0) {
        try {
          const { getCredsForUnit } = await import('../lib/uazapiProxy.js');

          function isConnected(d) {
            if (!d || typeof d !== 'object') return false;
            if (d.connected === true) return true;
            const open = ['open', 'connected', 'Online', 'online'];
            if (d.state  && open.includes(String(d.state)))  return true;
            if (d.status && open.includes(String(d.status))) return true;
            if (d.instance) {
              if (d.instance.state  && open.includes(String(d.instance.state)))  return true;
              if (d.instance.status && open.includes(String(d.instance.status))) return true;
              if (d.instance.connected === true) return true;
            }
            return false;
          }

          const checks = await Promise.allSettled(
            unitsWithCreds.map(async (u) => {
              const ac = new AbortController();
              const timer = setTimeout(() => ac.abort(), 4000);
              try {
                const creds = await getCredsForUnit(pool, u.unit_id);
                if (!creds || !creds.token) return { unitId: u.unit_id, status: 'not_configured' };
                const r = await fetch(`${creds.serverUrl}/instance/status`, {
                  headers: { token: creds.token, 'Content-Type': 'application/json' },
                  signal: ac.signal,
                });
                clearTimeout(timer);
                const d = await r.json().catch(() => ({}));
                return { unitId: u.unit_id, status: isConnected(d) ? 'connected' : 'disconnected' };
              } catch {
                clearTimeout(timer);
                return { unitId: u.unit_id, status: 'error' };
              }
            })
          );

          const statusMap = new Map();
          checks.forEach(c => {
            if (c.status === 'fulfilled') statusMap.set(c.value.unitId, c.value.status);
          });
          units.forEach(u => {
            if (statusMap.has(u.unit_id)) u.uazapi_status = statusMap.get(u.unit_id);
            else if (u.uazapi_instances === 0) u.uazapi_status = 'not_configured';
          });
        } catch {
          // ENCRYPTION_KEY not set or other error — leave uazapi_status as 'unknown'
        }
      } else {
        units.forEach(u => { u.uazapi_status = 'not_configured'; });
      }

      res.json({ units });
    } catch (err) {
      logger.error(`[Prospection] GET /dashboard/whatsapp-by-unit error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  return router;
}

// ── Shared helper: upsert a prospection contact ───────────────────────────
// Called from uazapiWebhook after a confirmed-new incoming message.
// NOTE: This call is intentionally fire-and-forget (.catch only) in the webhook
// handler to keep webhook response latency minimal. Write loss on abrupt process
// shutdown is an accepted trade-off; the GoTalk poller provides a complementary
// write path that acts as a soft retry for missed uazapi entries.
//
// Uses a single atomic INSERT ... ON CONFLICT DO UPDATE to avoid TOCTOU races
// under concurrent first-contact webhooks.
//
// Classification logic:
//   • INSERT (xmax=0): first contact ever → 'LEAD'
//   • UPDATE (conflict on phone): repeat contact → 'RECUPERACAO'
//
// `source` semantics — FIRST-TOUCH: the channel (gotalk|uazapi) that originated
// the very first inbound message is stored and never overwritten on subsequent
// contacts. This preserves the acquisition channel for reporting.
//
// Deduplication note: both webhook (uazapi) and poller (gotalk) have separate
// upsert implementations to avoid a circular import between server/routes and
// the whatsapp-worker process. Both implementations use the same atomic SQL
// logic; any future change must be applied to both.
//
// Returns the classification that was applied: 'LEAD' | 'RECUPERACAO' | null.
// Task #294: `direction` defaults to 'OUT' so callers that forget to set it
// (e.g. outbound send paths) do NOT accidentally stamp last_inbound_instance_id.
// Inbound callsites must explicitly pass direction:'IN'.
export async function upsertProspectionContact(pool, { phone, unitId = null, clientId = null, contactName = null, source = 'uazapi', instanceId = null, direction = 'OUT' }) {
  if (!phone) return null;

  try {
    // ── Canonical phone resolution: handle Brazilian "9th digit" ambiguity ──
    // uazapi may strip the 9th digit (81981071630 → 8181071630). If a contact
    // already exists with matching last-8-digits, reuse its phone so the
    // ON CONFLICT triggers correctly instead of creating a duplicate row.
    const last8 = String(phone).slice(-8);
    if (last8) {
      try {
        const existing = await pool.query(
          `SELECT phone FROM prospection_contacts WHERE RIGHT(phone, 8) = $1 LIMIT 1`,
          [last8]
        );
        if (existing.rows[0]?.phone) {
          phone = existing.rows[0].phone;
        }
      } catch {
        /* non-fatal — proceed with original phone */
      }
    }

    // ── Retroactive client link: if no clientId was provided, look up by phone ──
    // This ensures contacts already in the clients DB get auto-linked even on the
    // first webhook message, without requiring a manual link step.
    let resolvedClientId = clientId || null;
    if (!resolvedClientId) {
      try {
        const last10 = phone.slice(-10);
        if (last10) {
          const found = await pool.query(
            `SELECT id FROM clients
             WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''),    '[^0-9]', '', 'g'), 10) = $1
                OR RIGHT(REGEXP_REPLACE(COALESCE(phone2,''),   '[^0-9]', '', 'g'), 10) = $1
                OR RIGHT(REGEXP_REPLACE(COALESCE(celular,''),  '[^0-9]', '', 'g'), 10) = $1
                OR RIGHT(REGEXP_REPLACE(COALESCE(telefone,''), '[^0-9]', '', 'g'), 10) = $1
             LIMIT 1`,
            [last10]
          );
          resolvedClientId = found.rows[0]?.id || null;
        }
      } catch {
        /* non-fatal — proceed without client link */
      }
    }

    // Task #294: when this upsert was triggered by an inbound message (direction='IN'),
    // also stamp last_inbound_instance_id so the frontend composer can "follow" the
    // instance that received the reply. Outbound writes never touch this column.
    const inboundInstance = (direction === 'IN' && instanceId) ? instanceId : null;

    // Task #300: stamp last_inbound_at on every inbound write — drives the
    // "pendentes primeiro" ordering in the Prospecção list. Outbound writes
    // preserve the existing value via COALESCE.
    const inboundAt = direction === 'IN' ? new Date() : null;

    const r = await pool.query(
      `INSERT INTO prospection_contacts
         (phone, contact_name, classification, total_contacts, first_contact_at, last_contact_at, unit_id, client_id, source, last_source, uazapi_instance_id, last_inbound_instance_id, last_inbound_at)
       VALUES ($1, $2, 'LEAD', 1, NOW(), NOW(), $3, $4, $5, $5, $6, $7, $8)
       ON CONFLICT (phone) DO UPDATE SET
         classification    = 'RECUPERACAO',
         total_contacts    = prospection_contacts.total_contacts + 1,
         last_contact_at   = NOW(),
         contact_name      = COALESCE(EXCLUDED.contact_name, prospection_contacts.contact_name),
         unit_id           = COALESCE(EXCLUDED.unit_id, prospection_contacts.unit_id),
         -- Preserve existing client_id if already set; apply retroactive link if previously null
         client_id         = COALESCE(prospection_contacts.client_id, EXCLUDED.client_id),
         -- source (first-touch) preserved; last_source always updated to reflect most recent channel
         last_source       = EXCLUDED.last_source,
         -- Keep the most specific instance linkage: update when a non-null instanceId is provided,
         -- otherwise preserve whatever was previously stored (e.g. set by explicit "Trocar canal" PATCH)
         uazapi_instance_id = COALESCE(EXCLUDED.uazapi_instance_id, prospection_contacts.uazapi_instance_id),
         -- Task #294: instance-lock — overwrite on every inbound; preserve on outbound paths
         last_inbound_instance_id = COALESCE(EXCLUDED.last_inbound_instance_id, prospection_contacts.last_inbound_instance_id),
         -- Task #300: overwrite last_inbound_at on inbound; preserve on outbound
         last_inbound_at   = COALESCE(EXCLUDED.last_inbound_at, prospection_contacts.last_inbound_at),
         updated_at        = NOW()
       RETURNING classification, (xmax = 0) AS was_inserted`,
      [phone, contactName || null, unitId || null, resolvedClientId, source, instanceId || null, inboundInstance, inboundAt]
    );
    return r.rows[0]?.classification ?? null;
  } catch (err) {
    logger.error(`[Prospection] upsertProspectionContact error (phone=${phone}): ${err.message}`);
    return null;
  }
}

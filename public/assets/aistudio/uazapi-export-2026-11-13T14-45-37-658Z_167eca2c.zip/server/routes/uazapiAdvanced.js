/**
 * uazapiAdvanced.js
 *
 * Rotas avançadas uazapi: status/conexão, chamadas, broadcast, mídia, SSE, CRM.
 * Prefixo: /api/uazapi/
 *
 * Modelo: per-unit (unitId obrigatório em cada requisição)
 */

import { Router } from 'express';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
import { logger } from '../logger.js';
import {
  getCredsForUnit,
  getCredsByInstanceForUnit,
  uazApiFetchWithCreds,
  uazApiFetch,
  formatWaId,
  hasUnitAccess,
  ssrfSafe,
} from '../lib/uazapiProxy.js';
import { encrypt, requireEncryptionKey } from '../utils/encryption.js';
import { pushSseEvent, sseClients, sseEvents } from '../lib/sseSingleton.js';
import { validateOpenSession } from '../lib/sessionVersion.js';
import { registerUazapiWebhook } from '../lib/uazapiWebhookRegistration.js';

// ══════════════════════════════════════════════════════════════
//  Helpers
// ══════════════════════════════════════════════════════════════

function resolveUnit(req) {
  return (
    req.query.unitId ||
    req.body?.unitId ||
    req.params.unitId ||
    req.currentUser?.currentUnitId ||
    null
  );
}

function unitGuard(req, res) {
  const unitId = resolveUnit(req);
  if (!unitId) { res.status(400).json({ error: 'unitId obrigatório.' }); return null; }
  if (!hasUnitAccess(req.currentUser, unitId)) { res.status(403).json({ error: 'Acesso negado a esta unidade.' }); return null; }
  return unitId;
}

function normalizePhone(raw) {
  if (!raw) return null;
  const d = String(raw).replace(/\D/g, '');
  if (!d) return null;
  return d.startsWith('55') ? d : `55${d}`;
}

function getPublicBaseUrl() {
  if (process.env.APP_PUBLIC_URL) return process.env.APP_PUBLIC_URL.replace(/\/$/, '');
  if (process.env.REPLIT_DEPLOYMENT_URL) return process.env.REPLIT_DEPLOYMENT_URL.replace(/\/$/, '');
  if (process.env.REPLIT_DEV_DOMAIN) return `https://${process.env.REPLIT_DEV_DOMAIN}`;
  return null;
}

/**
 * Interpreta a resposta da API uazapi /instance/status e determina se a instância
 * está conectada. Compatível com múltiplos formatos retornados por diferentes versões
 * e configurações do uazapi.
 */
function isUazapiConnected(d) {
  if (!d || typeof d !== 'object') return false;
  if (d.connected === true) return true;
  const openStates = ['open', 'connected', 'Online', 'online'];
  if (d.state && openStates.includes(String(d.state))) return true;
  if (d.status && openStates.includes(String(d.status))) return true;
  if (d.instance) {
    const inst = d.instance;
    if (inst.state && openStates.includes(String(inst.state))) return true;
    if (inst.status && openStates.includes(String(inst.status))) return true;
    if (inst.connected === true) return true;
  }
  return false;
}

export function createUazapiAdvancedRoutes(pool) {
  const router = Router();

  // Guard: todas as rotas deste router lidam com criptografia de credenciais.
  // Em produção sem ENCRYPTION_KEY dedicado, retorna 503 imediatamente.
  router.use(requireEncryptionKey);

  // ══════════════════════════════════════════════════════════════
  //  CONEXÃO / STATUS
  // ══════════════════════════════════════════════════════════════

  // GET /status
  // ?unitId=... — obrigatório
  // ?instanceId=... — opcional; se fornecido retorna status de uma instância específica;
  //                   se omitido retorna array com status de todas as instâncias da unidade.
  router.get('/status', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;

    const instanceId = (req.query.instanceId || req.body?.instanceId || '').trim() || null;

    async function fetchInstanceStatus(creds) {
      let isConnected = false, connectedAt = null, connectionError = null, livePhone = null, tokenInvalid = false;
      try {
        const r = await uazApiFetchWithCreds(creds, '/instance/status');
        const d = await r.json().catch(() => ({}));
        logger.info(`[uazapiAdv] /instance/status raw response for "${creds.instanceId}": ${JSON.stringify(d)}`);
        // 401 = invalid/expired token — flag it so the frontend can skip and warn
        if (r.status === 401) {
          tokenInvalid = true;
          connectionError = d.message || d.error || 'Token inválido ou expirado.';
        } else {
          isConnected = isUazapiConnected(d);
          connectedAt = d.connectedAt || d.connected_at || d.instance?.connectedAt || null;
          livePhone = d.phone || d.phoneNumber || d.instance?.phoneNumber || d.instance?.phone || d.instance?.number || d.instance?.owner || null;
        }
      } catch {
        connectionError = 'Servidor uazapi inacessível.';
      }
      return {
        configured: true,
        isConnected,
        tokenInvalid,
        connectedAt,
        instanceId: creds.instanceId,
        label: creds.label || null,
        phoneNumber: livePhone || creds.instanceId || null,
        serverUrl: creds.serverUrl,
        error: connectionError,
      };
    }

    try {
      if (instanceId) {
        // Single-instance status
        const creds = await getCredsByInstanceForUnit(pool, unitId, instanceId);
        if (!creds || !creds.token) {
          return res.json({ configured: false, isConnected: false, instanceId });
        }
        return res.json(await fetchInstanceStatus(creds));
      } else {
        // All instances for this unit
        const rows = await pool.query(
          `SELECT unit_id, uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url, label
           FROM unit_whatsapp_credentials
           WHERE unit_id = $1 ORDER BY created_at ASC`,
          [unitId]
        );
        if (rows.rows.length === 0) {
          return res.json({ instances: [] });
        }
        const { decrypt } = await import('../utils/encryption.js');
        const results = await Promise.allSettled(
          rows.rows.map(async row => {
            const token = row.uazapi_token_encrypted ? decrypt(row.uazapi_token_encrypted) : null;
            if (!token) return { configured: false, isConnected: false, instanceId: row.uazapi_instance_id, label: row.label };
            const creds = {
              unitId: row.unit_id,
              instanceId: row.uazapi_instance_id,
              token,
              serverUrl: (row.uazapi_server_url || 'https://free.uazapi.com').replace(/\/$/, ''),
              label: row.label || null,
            };
            return fetchInstanceStatus(creds);
          })
        );
        const instances = results.map(r => r.status === 'fulfilled' ? r.value : { configured: false, isConnected: false, error: 'Erro ao verificar' });
        return res.json({ instances });
      }
    } catch (err) {
      logger.error(`[uazapiAdv] /status: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao verificar status.' });
    }
  });

  // GET /status-batch
  // Query: ?unitIds=id1,id2,id3
  // Returns { results: [{ unitId, status: 'connected'|'disconnected'|'not_configured', instanceId?, phone?, label? }] }
  // Used by the Units list to show a per-row WhatsApp connection badge without opening the detail panel.
  router.get('/status-batch', requireAuth, async (req, res) => {
    let unitIds = [];
    if (typeof req.query.unitIds === 'string') {
      unitIds = req.query.unitIds.split(',').map(s => s.trim()).filter(Boolean);
    } else if (Array.isArray(req.query.unitIds)) {
      unitIds = req.query.unitIds.map(s => String(s).trim()).filter(Boolean);
    }
    if (unitIds.length === 0) return res.status(400).json({ error: 'unitIds obrigatório.' });
    if (unitIds.length > 50) return res.status(400).json({ error: 'Máximo de 50 unidades por requisição.' });

    const user = req.currentUser;
    const isAdmin = user?.isAdmin || user?.isLoggedAdmin;
    const scopedIds = isAdmin ? unitIds : unitIds.filter(id => hasUnitAccess(user, id));

    const { decrypt } = await import('../utils/encryption.js');

    const settled = await Promise.allSettled(
      scopedIds.map(async (unitId) => {
        try {
          const rows = await pool.query(
            `SELECT uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url, label
             FROM unit_whatsapp_credentials
             WHERE unit_id = $1
             ORDER BY created_at ASC
             LIMIT 1`,
            [unitId]
          );
          if (rows.rows.length === 0) return { unitId, status: 'not_configured' };
          const row = rows.rows[0];
          if (!row.uazapi_token_encrypted) return { unitId, status: 'not_configured', instanceId: row.uazapi_instance_id, label: row.label || null };
          const token = decrypt(row.uazapi_token_encrypted);
          const serverUrl = (row.uazapi_server_url || 'https://free.uazapi.com').replace(/\/$/, '');
          const creds = { token, serverUrl, instanceId: row.uazapi_instance_id };
          const r = await uazApiFetchWithCreds(creds, '/instance/status');
          const d = await r.json().catch(() => ({}));
          const connected = isUazapiConnected(d);
          const phone = d.phone || d.phoneNumber || d.instance?.phoneNumber || d.instance?.phone || null;
          return {
            unitId,
            status: connected ? 'connected' : 'disconnected',
            instanceId: row.uazapi_instance_id,
            label: row.label || null,
            phone: phone || null,
          };
        } catch {
          return { unitId, status: 'error' };
        }
      })
    );

    const results = settled.map(s => s.status === 'fulfilled' ? s.value : { unitId: 'unknown', status: 'error' });
    return res.json({ results });
  });

  // POST /connect — configura e valida credenciais para uma instância específica
  router.post('/connect', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;

    const { serverUrl, instanceToken, phoneNumber, instanceId, label } = req.body || {};
    if (!serverUrl || !instanceToken || !phoneNumber) {
      return res.status(400).json({ error: 'serverUrl, instanceToken e phoneNumber são obrigatórios.' });
    }

    try {
      ssrfSafe(serverUrl);
    } catch (err) {
      return res.status(400).json({ error: err.message });
    }

    const phone = normalizePhone(phoneNumber);
    if (!phone || phone.length < 12 || phone.length > 13) {
      return res.status(400).json({ error: 'phoneNumber inválido. Use DDI 55 + DDD + número (12 ou 13 dígitos).' });
    }

    // instanceId is the uazapi instance name (e.g. "empresa1"); falls back to normalised phone if omitted
    const resolvedInstanceId = (typeof instanceId === 'string' && instanceId.trim()) ? instanceId.trim() : phone;
    const labelVal = (typeof label === 'string' && label.trim()) ? label.trim() : null;

    try {
      const testUrl = `${serverUrl.replace(/\/$/, '')}/instance/status`;
      let reachable = false;
      let serverWarn = null;
      try {
        const testRes = await fetch(testUrl, {
          headers: { 'token': instanceToken, 'Content-Type': 'application/json' },
          signal: AbortSignal.timeout(8000),
        });
        reachable = true;
        // 401 = token inválido, mas servidor acessível — salva credenciais de qualquer forma
        // 5xx = instância temporariamente indisponível (ex.: resetando após desconexão) — não bloqueia
        if (!testRes.ok && testRes.status < 500 && testRes.status !== 401) {
          const d = await testRes.json().catch(() => ({}));
          const msg = d.message || d.error || `Erro ${testRes.status} ao validar conexão com a API uazapi.`;
          if (testRes.status === 404) {
            return res.status(422).json({ error: `URL do servidor inválida ou instância não encontrada (${msg}).` });
          }
          serverWarn = msg;
        }
      } catch (fetchErr) {
        return res.status(422).json({ error: `Servidor uazapi inacessível. Verifique a URL: ${fetchErr.message}` });
      }

      const encrypted = encrypt(instanceToken);
      const cleanUrl = serverUrl.replace(/\/$/, '');

      // Guard: reject cross-unit instance hijacking
      const existing = await pool.query(
        `SELECT unit_id FROM unit_whatsapp_credentials WHERE uazapi_instance_id = $1`,
        [resolvedInstanceId]
      );
      if (existing.rows[0] && existing.rows[0].unit_id !== unitId) {
        return res.status(409).json({ error: 'Esta instância uazapi já está vinculada a outra unidade.' });
      }

      // Upsert by uazapi_instance_id within the same unit
      await pool.query(
        `INSERT INTO unit_whatsapp_credentials
           (unit_id, uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url, label, updated_at)
         VALUES ($1, $2, $3, $4, $5, NOW())
         ON CONFLICT (uazapi_instance_id) DO UPDATE
           SET uazapi_token_encrypted = EXCLUDED.uazapi_token_encrypted,
               uazapi_server_url      = EXCLUDED.uazapi_server_url,
               label                  = COALESCE(EXCLUDED.label, unit_whatsapp_credentials.label),
               updated_at             = NOW()
         WHERE unit_whatsapp_credentials.unit_id = $1`,
        [unitId, resolvedInstanceId, encrypted, cleanUrl, labelVal]
      );

      let webhookRegistered = false;
      const baseUrl = getPublicBaseUrl();
      if (baseUrl) {
        const result = await registerUazapiWebhook(instanceToken, cleanUrl, baseUrl, pool, resolvedInstanceId);
        webhookRegistered = result.registered;
        if (result.registered) {
          logger.info(`[uazapiAdv] /connect: webhook registrado para "${resolvedInstanceId}"`);
        } else {
          logger.warn(`[uazapiAdv] /connect: webhook não registrado para "${resolvedInstanceId}": ${result.error}`);
        }
      }

      return res.json({ success: true, webhookRegistered, instanceId: resolvedInstanceId, ...(serverWarn ? { warning: serverWarn } : {}) });
    } catch (err) {
      logger.error(`[uazapiAdv] /connect: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao salvar credenciais.' });
    }
  });

  // DELETE /disconnect
  // Requires instanceId (query param or body) — terminates the WhatsApp session on the
  // uazapi server, then removes local credentials from the DB.
  // Body: { instanceId, force?: boolean }
  //   force=true  → remove DB record even if the uazapi server call fails
  // Response: { success, uazapiDisconnected, error? }
  router.delete('/disconnect', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const instanceId = (req.query.instanceId || req.body?.instanceId || '').trim() || null;
    const force = req.body?.force === true;
    if (!instanceId) {
      return res.status(400).json({ error: 'instanceId é obrigatório para desconectar uma instância específica.' });
    }
    try {
      // Fetch stored credentials so we can call the uazapi server
      const creds = await getCredsByInstanceForUnit(pool, unitId, instanceId);

      let uazapiDisconnected = false;
      let uazapiError = null;

      if (creds && creds.token) {
        try {
          const r = await uazApiFetchWithCreds(creds, '/instance/disconnect', { method: 'POST' });
          const d = await r.json().catch(() => ({}));
          // uazapi returns 200 or 201 on success; accept both
          uazapiDisconnected = r.ok || r.status === 201;
          if (!uazapiDisconnected) {
            uazapiError = d.message || d.error || `Erro ${r.status} ao desconectar no servidor uazapi.`;
            logger.warn(`[uazapiAdv] /disconnect: uazapi responded ${r.status} for "${instanceId}": ${uazapiError}`);
          } else {
            logger.info(`[uazapiAdv] /disconnect: sessão encerrada no servidor uazapi para "${instanceId}"`);
          }
        } catch (fetchErr) {
          uazapiError = `Servidor uazapi inacessível: ${fetchErr.message}`;
          logger.warn(`[uazapiAdv] /disconnect: falha ao contatar uazapi para "${instanceId}": ${fetchErr.message}`);
        }
      } else {
        // No credentials in DB — nothing to terminate on the server; treat as already disconnected
        uazapiDisconnected = true;
      }

      // Remove local DB record when session was terminated OR caller is forcing removal
      if (uazapiDisconnected || force) {
        await pool.query(
          `DELETE FROM unit_whatsapp_credentials WHERE unit_id = $1 AND uazapi_instance_id = $2`,
          [unitId, instanceId]
        );
        return res.json({ success: true, uazapiDisconnected, ...(uazapiError ? { error: uazapiError } : {}) });
      }

      // Server call failed and force was not set → return error without touching DB
      return res.status(422).json({
        success: false,
        uazapiDisconnected: false,
        error: uazapiError || 'Não foi possível encerrar a sessão no servidor uazapi.',
      });
    } catch (err) {
      logger.error(`[uazapiAdv] /disconnect: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao desconectar.' });
    }
  });

  // POST /instance-connect — inicia o processo de conexão WhatsApp e retorna QR code
  // Body: { unitId, instanceId }
  // Chama POST /instance/connect na uazapi — retorna { qrString, qrBase64, pairingCode }
  router.post('/instance-connect', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;

    const instanceId = (req.body?.instanceId || '').trim() || null;

    try {
      let creds;
      if (instanceId) {
        creds = await getCredsByInstanceForUnit(pool, unitId, instanceId);
      } else {
        creds = await getCredsForUnit(pool, unitId);
      }
      if (!creds || !creds.token) {
        return res.status(422).json({ error: 'Credenciais não configuradas. Salve o token primeiro.' });
      }

      const r = await uazApiFetchWithCreds(creds, '/instance/connect', { method: 'POST' });
      const d = await r.json().catch(() => ({}));
      // Log only safe metadata — never log QR/pairing payloads (account-takeover risk)
      logger.info(`[uazapiAdv] /instance-connect for "${creds.instanceId}": httpStatus=${r.status} hasQr=${!!(d.code || d.qrcode || d.qrBase64 || d.instance?.code || d.instance?.qrcode)} hasState=${!!(d.state || d.status)}`);

      // 404 from uazapi usually means the instance is already connected
      // (the /instance/connect endpoint only works for disconnected instances).
      // Fall back to a status check and return "already connected" if so.
      if (r.status === 404) {
        try {
          const sr = await uazApiFetchWithCreds(creds, '/instance/status');
          const sd = await sr.json().catch(() => ({}));
          if (isUazapiConnected(sd)) {
            const rawJid   = sd.status?.jid || null;
            const jidPhone = rawJid ? String(rawJid).split(':')[0].split('@')[0] : null;
            const phone    = sd.phone || sd.phoneNumber
                           || sd.instance?.phoneNumber || sd.instance?.owner
                           || jidPhone || null;
            logger.info(`[uazapiAdv] /instance-connect: instance "${creds.instanceId}" already connected — returning ok`);
            return res.json({ ok: true, alreadyConnected: true, phone, qrString: null, qrBase64: null, pairingCode: null });
          }
        } catch { /* ignore status fallback errors */ }
        // Not connected and /instance/connect returned 404 — surface the error
        const upstreamMsg = d.message || d.error || d.msg || 'Endpoint /instance/connect não encontrado no servidor uazapi.';
        logger.warn(`[uazapiAdv] /instance-connect: 404 for "${creds.instanceId}" and not connected: ${upstreamMsg}`);
        return res.status(422).json({ error: upstreamMsg });
      }

      // Surface other upstream errors rather than silently proceeding
      if (!r.ok) {
        const upstreamMsg = d.message || d.error || d.msg || `Erro ${r.status} da API uazapi.`;
        logger.warn(`[uazapiAdv] /instance-connect upstream error (${r.status}) for "${creds.instanceId}": ${upstreamMsg}`);
        return res.status(r.status >= 400 && r.status < 500 ? 422 : 502).json({ error: upstreamMsg });
      }

      const qrString   = d.code       || d.qrCode   || d.qr        || d.instance?.code   || null;
      const qrBase64   = d.qrcode     || d.qrBase64 || d.instance?.qrcode || null;
      const pairingCode = d.pairingCode || d.pairing_code || null;

      return res.json({ ok: true, qrString, qrBase64, pairingCode, state: d.state || d.status || null });
    } catch (err) {
      logger.error(`[uazapiAdv] /instance-connect: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao iniciar conexão com uazapi.' });
    }
  });

  // GET /instance-qr-status — polling de status durante o fluxo de QR code
  // ?unitId=... &instanceId=...
  // Retorna { isConnected, phone, qrString, qrBase64, state }
  router.get('/instance-qr-status', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;

    const instanceId = (req.query.instanceId || '').trim() || null;

    try {
      let creds;
      if (instanceId) {
        creds = await getCredsByInstanceForUnit(pool, unitId, instanceId);
      } else {
        creds = await getCredsForUnit(pool, unitId);
      }
      if (!creds || !creds.token) {
        return res.status(422).json({ error: 'Credenciais não configuradas.' });
      }

      const r = await uazApiFetchWithCreds(creds, '/instance/status');
      const d = await r.json().catch(() => ({}));
      // Log only safe metadata — never log QR payloads (account-takeover risk)
      logger.info(`[uazapiAdv] /instance-qr-status for "${creds.instanceId}": httpStatus=${r.status} instanceStatus=${d.instance?.status ?? d.state ?? '?'} loggedIn=${d.status?.loggedIn ?? '?'}`);

      const isConnected  = isUazapiConnected(d);
      // Extract phone — field location varies across uazapi versions
      const rawJid   = d.status?.jid || null;
      const jidPhone = rawJid ? String(rawJid).split(':')[0].split('@')[0] : null;
      const phone    = d.phone || d.phoneNumber
                    || d.instance?.phoneNumber || d.instance?.phone
                    || d.instance?.number || d.instance?.owner
                    || jidPhone || null;
      const qrString     = d.code  || d.qrCode     || d.qr      || d.instance?.code   || null;
      const qrBase64     = d.qrcode || d.qrBase64  || d.instance?.qrcode || null;
      const state        = d.instance?.status || d.state
                        || (typeof d.status === 'string' ? d.status : null) || 'unknown';

      // Auto-register webhook when connected AND webhook has never been set
      // (or was registered more than 24 h ago) — avoids repeated upstream POSTs
      // on every panel status check.
      if (isConnected) {
        const baseUrl = getPublicBaseUrl();
        if (baseUrl && creds.serverUrl && creds.token && creds.instanceId) {
          try {
            const credRow = await pool.query(
              `SELECT webhook_registered_at FROM unit_whatsapp_credentials
               WHERE uazapi_instance_id = $1 LIMIT 1`,
              [creds.instanceId]
            ).catch(() => null);
            const lastReg = credRow?.rows?.[0]?.webhook_registered_at;
            const shouldRegister = !lastReg
              || (Date.now() - new Date(lastReg).getTime()) > 24 * 60 * 60 * 1000;

            if (shouldRegister) {
              const result = await registerUazapiWebhook(creds.token, creds.serverUrl, baseUrl, pool, creds.instanceId);
              if (result.registered) {
                logger.info(`[uazapiAdv] /instance-qr-status: webhook auto-registrado para "${creds.instanceId}"`);
              }
            }
          } catch { /* silent */ }
        }
      }

      return res.json({ isConnected, phone, qrString, qrBase64, state });
    } catch (err) {
      logger.error(`[uazapiAdv] /instance-qr-status: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao verificar status.' });
    }
  });

  // Alias: GET /instance-connect-status — compatibility alias for /instance-qr-status
  router.get('/instance-connect-status', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const instanceId = (req.query.instanceId || '').trim() || null;
    try {
      let creds;
      if (instanceId) {
        creds = await getCredsByInstanceForUnit(pool, unitId, instanceId);
      } else {
        creds = await getCredsForUnit(pool, unitId);
      }
      if (!creds || !creds.token) {
        return res.status(422).json({ error: 'Credenciais não configuradas.' });
      }
      const r = await uazApiFetchWithCreds(creds, '/instance/status');
      const d = await r.json().catch(() => ({}));
      const isConnected = isUazapiConnected(d);
      const rawJid   = d.status?.jid || null;
      const jidPhone = rawJid ? String(rawJid).split(':')[0].split('@')[0] : null;
      const phone    = d.phone || d.phoneNumber
                    || d.instance?.phoneNumber || d.instance?.phone
                    || d.instance?.number || d.instance?.owner
                    || jidPhone || null;
      return res.json({ isConnected, phone });
    } catch (err) {
      logger.error(`[uazapiAdv] /instance-connect-status: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao verificar status.' });
    }
  });

  // POST /reconnect
  // Body: { instanceId, label?, serverUrl? }
  // instanceId — opcional; se omitido usa primeira instância (compat)
  // label / serverUrl — se fornecidos, são persistidos antes de verificar conexão
  router.post('/reconnect', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const instanceId = (req.body?.instanceId || req.query.instanceId || '').trim() || null;
    const labelParam = (typeof req.body?.label === 'string' && req.body.label.trim()) ? req.body.label.trim() : null;
    const serverUrlRaw = (typeof req.body?.serverUrl === 'string' && req.body.serverUrl.trim()) ? req.body.serverUrl.trim() : null;
    let serverUrlParam = null;
    if (serverUrlRaw) {
      try {
        ssrfSafe(serverUrlRaw);
        serverUrlParam = serverUrlRaw.replace(/\/$/, '');
      } catch (ssrfErr) {
        return res.status(400).json({ error: ssrfErr.message });
      }
    }

    try {
      let creds;
      if (instanceId) {
        creds = await getCredsByInstanceForUnit(pool, unitId, instanceId);
      } else {
        creds = await getCredsForUnit(pool, unitId);
      }
      if (!creds || !creds.token) {
        return res.status(422).json({ error: 'Credenciais não configuradas. Use /connect primeiro.' });
      }

      // Persist label / serverUrl metadata changes if provided
      if ((labelParam !== null || serverUrlParam !== null) && creds.instanceId) {
        await pool.query(
          `UPDATE unit_whatsapp_credentials
           SET label      = COALESCE($1, label),
               uazapi_server_url = COALESCE($2, uazapi_server_url),
               updated_at = NOW()
           WHERE unit_id = $3 AND uazapi_instance_id = $4`,
          [labelParam, serverUrlParam, unitId, creds.instanceId]
        );
        // Refresh creds with updated serverUrl for connection check
        if (serverUrlParam) creds = { ...creds, serverUrl: serverUrlParam };
        if (labelParam) creds = { ...creds, label: labelParam };
      }

      let isConnected = false;
      try {
        const r = await uazApiFetchWithCreds(creds, '/instance/status');
        const d = await r.json().catch(() => ({}));
        logger.info(`[uazapiAdv] /reconnect status raw for "${creds.instanceId}": ${JSON.stringify(d)}`);
        isConnected = isUazapiConnected(d);
      } catch { /* offline */ }

      // Tentar registrar o webhook mesmo quando o status check não determinou conectividade,
      // pois o sucesso do registro confirma que a instância está acessível.
      let webhookRegistered = false;
      const baseUrl = getPublicBaseUrl();
      if (baseUrl && creds.serverUrl && creds.token) {
        const result = await registerUazapiWebhook(creds.token, creds.serverUrl, baseUrl, pool, creds.instanceId);
        webhookRegistered = result.registered;
        if (webhookRegistered && !isConnected) {
          // Se o webhook foi registrado com sucesso, a instância está online
          isConnected = true;
          logger.info(`[uazapiAdv] /reconnect: webhook OK para "${creds.instanceId}" — considerando instância conectada.`);
        } else if (!webhookRegistered) {
          logger.warn(`[uazapiAdv] /reconnect: webhook falhou para "${creds.instanceId}": ${result.error}`);
        }
      }

      return res.json({ success: true, isConnected, webhookRegistered });
    } catch (err) {
      logger.error(`[uazapiAdv] /reconnect: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao reconectar.' });
    }
  });

  // ══════════════════════════════════════════════════════════════
  //  CHAMADAS
  // ══════════════════════════════════════════════════════════════

  // GET /calls — lista histórico do banco
  router.get('/calls', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    try {
      const r = await pool.query(
        `SELECT id, call_id, from_number, to_number, type, status, duration, ts, created_at
         FROM whatsapp_call_logs
         WHERE unit_id = $1
         ORDER BY created_at DESC
         LIMIT 200`,
        [unitId]
      );
      return res.json({ calls: r.rows });
    } catch (err) {
      logger.error(`[uazapiAdv] /calls: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao listar chamadas.' });
    }
  });

  // POST /calls/offer
  router.post('/calls/offer', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { to, isVideo } = req.body || {};
    if (!to) return res.status(400).json({ error: 'to obrigatório.' });
    try {
      const r = await uazApiFetch(pool, unitId, '/calls/offer', {
        method: 'POST',
        body: JSON.stringify({ to: formatWaId(to), isVideo: !!isVideo }),
      });
      const d = await r.json().catch(() => ({}));
      return res.status(r.status).json(d);
    } catch (err) {
      return res.status(err.status || 500).json({ error: err.message });
    }
  });

  // POST /calls/reject
  router.post('/calls/reject', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { callId } = req.body || {};
    if (!callId) return res.status(400).json({ error: 'callId obrigatório.' });
    try {
      const r = await uazApiFetch(pool, unitId, '/calls/reject', {
        method: 'POST',
        body: JSON.stringify({ callId }),
      });
      const d = await r.json().catch(() => ({}));
      return res.status(r.status).json(d);
    } catch (err) {
      return res.status(err.status || 500).json({ error: err.message });
    }
  });

  // POST /calls/terminate
  router.post('/calls/terminate', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { callId } = req.body || {};
    if (!callId) return res.status(400).json({ error: 'callId obrigatório.' });
    try {
      const r = await uazApiFetch(pool, unitId, '/calls/terminate', {
        method: 'POST',
        body: JSON.stringify({ callId }),
      });
      const d = await r.json().catch(() => ({}));
      return res.status(r.status).json(d);
    } catch (err) {
      return res.status(err.status || 500).json({ error: err.message });
    }
  });

  // ══════════════════════════════════════════════════════════════
  //  SINCRONIZAÇÃO HISTÓRICA
  // ══════════════════════════════════════════════════════════════

  // POST /sync-history
  // Busca chats e mensagens recentes do uazapi e salva no banco (gotalk_messages).
  // Idempotente — usa ON CONFLICT (gotalk_message_id) DO NOTHING.
  // Body: { unitId, instanceId? (opcional), maxChats? (default 50), messagesPerChat? (default 30) }
  router.post('/sync-history', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;

    const maxChats       = Math.min(Number(req.body?.maxChats        || 50),  200);
    const msgsPerChat    = Math.min(Number(req.body?.messagesPerChat  || 30),  100);
    const specificInst   = (req.body?.instanceId || '').trim() || null;

    // Responde imediatamente e processa em background
    res.json({ ok: true, message: 'Sincronização iniciada em background.' });

    setImmediate(async () => {
      try {
        // Buscar todas as instâncias da unidade (ou só a solicitada)
        const q = specificInst
          ? `SELECT uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url
             FROM unit_whatsapp_credentials
             WHERE unit_id = $1 AND uazapi_instance_id = $2`
          : `SELECT uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url
             FROM unit_whatsapp_credentials
             WHERE unit_id = $1
             ORDER BY created_at ASC`;
        const instRows = specificInst
          ? (await pool.query(q, [unitId, specificInst])).rows
          : (await pool.query(q, [unitId])).rows;

        if (!instRows.length) {
          logger.warn(`[uazapiAdv] sync-history: nenhuma instância para unit=${unitId}`);
          return;
        }

        const { decrypt } = await import('../utils/encryption.js');

        let totalInserted = 0;
        let totalSkipped  = 0;

        for (const instRow of instRows) {
          const instanceId = instRow.uazapi_instance_id;
          const token      = instRow.uazapi_token_encrypted ? decrypt(instRow.uazapi_token_encrypted) : null;
          const serverUrl  = (instRow.uazapi_server_url || 'https://free.uazapi.com').replace(/\/$/, '');

          if (!token) {
            logger.warn(`[uazapiAdv] sync-history: instância "${instanceId}" sem token — pulada.`);
            continue;
          }

          const headers = { 'Content-Type': 'application/json', 'token': token };

          // 1. Buscar lista de chats da instância
          let chats = [];
          try {
            const chatsRes = await fetch(`${serverUrl}/chats?page=1`, { headers });
            const chatsData = await chatsRes.json().catch(() => ({}));
            logger.info(`[uazapiAdv] sync-history: raw chats response for "${instanceId}": ${JSON.stringify(chatsData).slice(0, 300)}`);
            // Normalizar resposta de forma defensiva — suporte a todos os formatos da uazapi
            let rawArr = [];
            if (Array.isArray(chatsData)) {
              rawArr = chatsData;
            } else if (Array.isArray(chatsData.chats)) {
              rawArr = chatsData.chats;
            } else if (Array.isArray(chatsData.data)) {
              rawArr = chatsData.data;
            } else if (chatsData.chats && Array.isArray(chatsData.chats.data)) {
              rawArr = chatsData.chats.data;
            } else if (chatsData.chats && typeof chatsData.chats === 'object') {
              rawArr = Object.values(chatsData.chats);
            }
            chats = rawArr.slice(0, maxChats);
            logger.info(`[uazapiAdv] sync-history: instância "${instanceId}" — ${chats.length} chat(s) encontrados.`);
          } catch (err) {
            logger.warn(`[uazapiAdv] sync-history: erro ao buscar chats de "${instanceId}": ${err.message}`);
            continue;
          }

          // 2. Para cada chat, buscar mensagens e salvar
          for (const chat of chats) {
            const chatId = chat.chatid || chat.jid || chat.id || chat.chatId;
            if (!chatId) continue;
            // Pular grupos
            if (String(chatId).endsWith('@g.us') || chat.isGroup) continue;

            const phoneRaw = String(chatId).split('@')[0].replace(/\D/g, '');
            if (!phoneRaw) continue;
            // Normalize like webhook: strip '55' prefix for Brazilian numbers > 11 digits
            const phone = (phoneRaw.startsWith('55') && phoneRaw.length > 11) ? phoneRaw.slice(2) : phoneRaw;

            let messages = [];
            try {
              const msgsRes = await fetch(`${serverUrl}/messages?chatid=${encodeURIComponent(chatId)}&limit=${msgsPerChat}`, { headers });
              if (!msgsRes.ok) {
                logger.warn(`[uazapiAdv] sync-history: /messages retornou ${msgsRes.status} para chat "${chatId}" (instância "${instanceId}")`);
                continue;
              }
              const msgsData = await msgsRes.json().catch(() => ({}));
              const rawMsgs = Array.isArray(msgsData) ? msgsData : (msgsData.messages || msgsData.data || []);
              messages = rawMsgs.slice(0, msgsPerChat);
            } catch { continue; }

            // Resolver client_id pela phone
            let clientId = null;
            try {
              const cRes = await pool.query(
                `SELECT id FROM clients WHERE REGEXP_REPLACE(COALESCE(whatsapp,''), '\\D', '', 'g') = $1
                    OR REGEXP_REPLACE(COALESCE(phone,''), '\\D', '', 'g') = $1 LIMIT 1`,
                [phoneRaw.slice(-11)]
              );
              clientId = cRes.rows[0]?.id || null;
            } catch { /* sem match */ }

            for (const msg of messages) {
              const msgId = msg.messageid || msg.id || msg.key?.id;
              if (!msgId) continue;

              const ts = msg.messageTimestamp || msg.timestamp || msg.sentAt || 0;
              const tsMs = typeof ts === 'number' ? (ts < 1e12 ? ts * 1000 : ts) : (ts ? new Date(ts).getTime() : 0);
              const sentAt = tsMs ? new Date(tsMs).toISOString() : null;

              const direction = msg.fromMe ? 'OUT' : 'IN';
              const body      = msg.text || msg.body || msg.caption || msg.message?.conversation || null;

              const mt = String(msg.messageType || '').toLowerCase();
              let messageType = 'TEXT';
              if (mt.includes('image')) messageType = 'IMAGE';
              else if (mt.includes('video')) messageType = 'VIDEO';
              else if (mt.includes('audio') || mt.includes('ptt')) messageType = 'AUDIO';
              else if (mt.includes('document')) messageType = 'DOCUMENT';
              else if (mt.includes('sticker')) messageType = 'STICKER';

              const attachmentUrl  = msg.fileURL || msg.url || msg.mediaUrl || null;
              const attachmentName = msg.fileName || null;
              const attachmentMime = msg.mimeType || msg.mimetype || null;

              try {
                const r = await pool.query(
                  `INSERT INTO gotalk_messages
                     (gotalk_message_id, client_id, phone_number, direction, body,
                      message_type, attachment_url, attachment_name, attachment_mime_type,
                      ack_status, sent_at, source, unit_id, uazapi_instance_id)
                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,NULL,$10,'uazapi',$11,$12)
                   ON CONFLICT (gotalk_message_id) DO NOTHING`,
                  [msgId, clientId, phone, direction, body, messageType,
                   attachmentUrl, attachmentName, attachmentMime, sentAt, unitId, instanceId || null]
                );
                if (r.rowCount > 0) totalInserted++;
                else totalSkipped++;
              } catch (dbErr) {
                logger.warn(`[uazapiAdv] sync-history: erro ao salvar msg ${msgId}: ${dbErr.message}`);
              }
            }
          }
        }

        logger.info(`[uazapiAdv] sync-history concluída para unit=${unitId}: ${totalInserted} inseridas, ${totalSkipped} já existiam.`);
        // Notificar frontend via SSE
        pushSseEvent(unitId, 'sync_history_done', { inserted: totalInserted, skipped: totalSkipped });

      } catch (outerErr) {
        logger.error(`[uazapiAdv] sync-history erro fatal: ${outerErr.message}`);
      }
    });
  });

  // ══════════════════════════════════════════════════════════════
  //  BROADCAST
  // ══════════════════════════════════════════════════════════════

  // GET /broadcast — histórico de campanhas
  router.get('/broadcast', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    try {
      const r = await pool.query(
        `SELECT id, campaign_name, message, total, sent, failed, status, results, created_at, completed_at
         FROM whatsapp_broadcast_logs
         WHERE unit_id = $1
         ORDER BY created_at DESC
         LIMIT 100`,
        [unitId]
      );
      return res.json({ broadcasts: r.rows });
    } catch (err) {
      logger.error(`[uazapiAdv] /broadcast GET: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao listar broadcasts.' });
    }
  });

  // POST /broadcast — inicia campanha (responde imediatamente, envia em background)
  router.post('/broadcast', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;

    const { campaignName, message, contacts } = req.body || {};
    if (!message || typeof message !== 'string' || !message.trim()) {
      return res.status(400).json({ error: 'message obrigatório.' });
    }
    if (!Array.isArray(contacts) || contacts.length === 0) {
      return res.status(400).json({ error: 'contacts deve ser um array não-vazio de números.' });
    }

    try {
      const r = await pool.query(
        `INSERT INTO whatsapp_broadcast_logs
           (unit_id, campaign_name, message, total, sent, failed, status)
         VALUES ($1, $2, $3, $4, 0, 0, 'running')
         RETURNING id`,
        [unitId, campaignName || null, message.trim(), contacts.length]
      );
      const broadcastId = r.rows[0].id;

      res.json({ broadcastId, status: 'running', total: contacts.length });

      setImmediate(() => runBroadcast(pool, unitId, broadcastId, contacts, message.trim()));
    } catch (err) {
      logger.error(`[uazapiAdv] /broadcast POST: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao iniciar broadcast.' });
    }
  });

  // ══════════════════════════════════════════════════════════════
  //  MÍDIA
  // ══════════════════════════════════════════════════════════════

  // GET /media?url=<encoded> — proxy de mídia
  // 🔒 SEGURANÇA [VULN-1]: requireAuth obrigatório + ssrfSafe() antes do fetch.
  router.get('/media', requireAuth, async (req, res) => {
    const rawUrl = req.query.url;
    if (!rawUrl) return res.status(400).json({ error: 'Parâmetro url obrigatório.' });

    let targetUrl;
    try {
      targetUrl = decodeURIComponent(rawUrl);
      // 🔒 SEGURANÇA [VULN-1]: validar URL contra IPs privados antes do fetch (CWE-918).
      // Sem esta chamada, qualquer URL — incluindo 169.254.169.254 (IMDS) — seria aceita.
      ssrfSafe(targetUrl);
    } catch (err) {
      return res.status(400).json({ error: err.message || 'URL inválida ou bloqueada.' });
    }

    try {
      const upstream = await fetch(targetUrl);

      // 🔒 SEGURANÇA [VULN-11]: nunca espelhar Content-Type do upstream — pode ser
      // text/html com XSS. Usar allowlist restrita de tipos de mídia (CWE-79).
      const upstreamType = upstream.headers.get('Content-Type') || '';
      const ALLOWED_MEDIA_TYPES = [
        'image/jpeg', 'image/png', 'image/webp', 'image/gif',
        'audio/ogg', 'audio/mpeg', 'audio/mp4', 'video/mp4', 'application/pdf',
      ];
      const safeType = ALLOWED_MEDIA_TYPES.find(t => upstreamType.startsWith(t)) || 'application/octet-stream';

      res.set('Content-Type', safeType);
      res.set('Cache-Control', 'private, max-age=3600');
      const { Readable } = await import('stream');
      const readable = Readable.fromWeb(upstream.body);
      readable.pipe(res);
    } catch (err) {
      logger.error(`[uazapiAdv] /media proxy: ${err.message}`);
      return res.status(502).json({ error: 'Erro ao buscar mídia.' });
    }
  });

  // POST /media/upload — upload para Replit Object Storage ou fallback em base64
  router.post('/media/upload', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;

    if (!req.file && !req.body?.base64) {
      return res.status(400).json({ error: 'Envie o arquivo via multipart (campo "file") ou base64 no body.' });
    }

    const baseUrl = getPublicBaseUrl() || '';
    const objectName = `wa-media/${unitId}/${Date.now()}-${(req.file?.originalname || 'upload').replace(/[^a-zA-Z0-9._-]/g, '_')}`;

    if (req.file) {
      try {
        const { Client } = await import('@replit/object-storage');
        const storage = new Client();
        await storage.uploadFromBuffer(objectName, req.file.buffer, { contentType: req.file.mimetype });
        const publicUrl = `${baseUrl}/api/uazapi/media/public/${encodeURIComponent(objectName)}`;
        return res.json({ url: publicUrl, objectName, mimeType: req.file.mimetype });
      } catch (storageErr) {
        logger.warn(`[uazapiAdv] Object Storage indisponível: ${storageErr.message}. Retornando base64 data URL.`);
        const dataUrl = `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`;
        return res.json({ url: dataUrl, objectName, mimeType: req.file.mimetype, warning: 'Object Storage indisponível — URL é data:URL temporária' });
      }
    }

    const { base64, mimeType = 'application/octet-stream', fileName = 'upload' } = req.body;
    const dataUrl = `data:${mimeType};base64,${base64}`;
    return res.json({ url: dataUrl, objectName: fileName, mimeType });
  });

  // GET /media/public/<objectName> — serve arquivo do object storage sem auth
  // Usa router.use para aceitar paths com barras (ex: wa-media/unitId/filename.jpg)
  router.use('/media/public', async (req, res) => {
    const objectName = req.path.replace(/^\//, '');
    if (!objectName) return res.status(400).json({ error: 'objectName obrigatório.' });

    try {
      const { Client } = await import('@replit/object-storage');
      const storage = new Client();
      const buf = await storage.downloadAsBuffer(objectName);
      const ext = objectName.split('.').pop()?.toLowerCase() || '';
      const mimeMap = { jpg: 'image/jpeg', jpeg: 'image/jpeg', png: 'image/png', gif: 'image/gif', webp: 'image/webp', mp4: 'video/mp4', mp3: 'audio/mpeg', ogg: 'audio/ogg', pdf: 'application/pdf' };
      const mimeType = mimeMap[ext] || 'application/octet-stream';
      res.set('Content-Type', mimeType);
      res.set('Cache-Control', 'public, max-age=86400');
      return res.send(buf);
    } catch (err) {
      logger.error(`[uazapiAdv] /media/public: ${err.message}`);
      return res.status(404).json({ error: 'Arquivo não encontrado.' });
    }
  });

  // ══════════════════════════════════════════════════════════════
  //  SSE — Server-Sent Events
  // ══════════════════════════════════════════════════════════════

  // GET /sse — conexão SSE por unidade
  router.get('/sse', requireAuth, (req, res) => {
    const unitId = req.query.unitId || req.currentUser?.currentUnitId;
    if (!unitId || !hasUnitAccess(req.currentUser, unitId)) {
      return res.status(403).json({ error: 'Acesso negado.' });
    }

    res.set({
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'X-Accel-Buffering': 'no',
    });
    res.flushHeaders();

    const clients = sseClients.get(unitId) || [];
    clients.push(res);
    sseClients.set(unitId, clients);

    res.write(`data: ${JSON.stringify({ type: 'connected', ts: Date.now() })}\n\n`);

    const sessionValidationInterval = setInterval(async () => {
      await validateOpenSession(
        pool,
        req.jwtPayload,
        () => {
          clearInterval(sessionValidationInterval);
          res.end();
        }
      );
    }, 5000);
    sessionValidationInterval.unref();

    req.on('close', () => {
      clearInterval(sessionValidationInterval);
      const cur = sseClients.get(unitId) || [];
      sseClients.set(unitId, cur.filter(c => c !== res));
    });
  });

  // GET /sse/events — últimos eventos em memória (debug)
  router.get('/sse/events', requireAuth, (req, res) => {
    const unitId = req.query.unitId || req.currentUser?.currentUnitId;
    if (!unitId || !hasUnitAccess(req.currentUser, unitId)) {
      return res.status(403).json({ error: 'Acesso negado.' });
    }
    return res.json({ events: sseEvents.get(unitId) || [] });
  });

  // ══════════════════════════════════════════════════════════════
  //  CRM — link entre chats e contatos locais
  // ══════════════════════════════════════════════════════════════

  // GET /crm/contacts — lista clientes + colaboradores do banco local
  router.get('/crm/contacts', requireAuth, async (req, res) => {
    const { search = '', type = '', page = 1, limit = 50 } = req.query;
    const offset = (Number(page) - 1) * Number(limit);
    const unitId = req.currentUser?.currentUnitId;

    try {
      const params = [`%${search}%`];
      let baseWhere = `(c.name ILIKE $1 OR c.celular ILIKE $1 OR c.telefone ILIKE $1 OR c.email ILIKE $1)`;
      if (type === 'client') baseWhere += ` AND ctype = 'client'`;
      if (type === 'collaborator') baseWhere += ` AND ctype = 'collaborator'`;

      const query = `
        SELECT id, name, 'client' AS ctype, celular AS phone, email, NULL AS job_title
        FROM clients
        WHERE (name ILIKE $1 OR celular ILIKE $1 OR telefone ILIKE $1 OR email ILIKE $1)
        UNION ALL
        SELECT id::text, name, 'collaborator' AS ctype, phone, email, job_title
        FROM collaborators
        WHERE (name ILIKE $1 OR phone ILIKE $1 OR email ILIKE $1)
        ORDER BY name
        LIMIT $2 OFFSET $3
      `;
      const r = await pool.query(query, [params[0], Number(limit), offset]);
      return res.json({ contacts: r.rows, page: Number(page) });
    } catch (err) {
      logger.error(`[uazapiAdv] /crm/contacts: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao listar contatos.' });
    }
  });

  // POST /chats/:chatId/lead — vincula chat a contato CRM
  router.post('/chats/:chatId/lead', requireAuth, async (req, res) => {
    const unitId = unitGuard(req, res);
    if (!unitId) return;
    const { type, contactId } = req.body || {};
    if (!type || !contactId) return res.status(400).json({ error: 'type e contactId obrigatórios.' });

    return res.json({ linked: true, chatId: req.params.chatId, type, contactId });
  });

  // ══════════════════════════════════════════════════════════════
  //  HISTÓRICO COMPLETO uazapi — tabela uazapi_messages
  // ══════════════════════════════════════════════════════════════

  // GET /import-status — retorna status da importação histórica em andamento
  router.get('/import-status', requireAuth, async (req, res) => {
    try {
      const r = await pool.query(`SELECT value FROM app_data WHERE key = 'uazapi_import_status'`);
      return res.json(r.rows[0]?.value || { running: false });
    } catch (err) {
      logger.error(`[uazapiAdv] /import-status: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao buscar status.' });
    }
  });

  // GET /messages — lista mensagens da tabela uazapi_messages com filtros e paginação
  router.get('/messages', requireAuth, async (req, res) => {
    const user = req.currentUser;
    if (!user) return res.status(401).json({ error: 'Não autenticado.' });

    const {
      phone, dateFrom, dateTo, direction, instanceId, unitId,
      page = '1', limit: lim = '50',
    } = req.query;

    const pageNum  = Math.max(1, parseInt(String(page), 10) || 1);
    const limitNum = Math.min(200, Math.max(1, parseInt(String(lim), 10) || 50));
    const offset   = (pageNum - 1) * limitNum;

    const conds  = [];
    const params = [];
    let   pi     = 1;

    if (!user.isAdmin) {
      const allowedUnits = user.allowedUnitIds || [];
      if (allowedUnits.length === 0) {
        return res.json({ messages: [], total: 0, page: pageNum, pages: 0 });
      }
      conds.push(`unit_id = ANY($${pi++}::uuid[])`);
      params.push(allowedUnits);
    } else if (unitId) {
      conds.push(`unit_id = $${pi++}`);
      params.push(unitId);
    }

    if (phone)      { conds.push(`phone_number ILIKE $${pi++}`); params.push(`%${String(phone).replace(/\D/g, '')}%`); }
    if (direction && ['IN','OUT'].includes(String(direction))) {
      conds.push(`direction = $${pi++}`); params.push(direction);
    }
    if (instanceId) { conds.push(`instance_id = $${pi++}`); params.push(instanceId); }
    if (dateFrom)   { conds.push(`sent_at >= $${pi++}`);    params.push(dateFrom); }
    if (dateTo) {
      // Accept plain YYYY-MM-DD (from date input) or full ISO string; ensure end-of-day for plain dates
      const dateToStr = String(dateTo);
      const dateToFull = dateToStr.length === 10 ? dateToStr + 'T23:59:59.999Z' : dateToStr;
      conds.push(`sent_at <= $${pi++}`);
      params.push(dateToFull);
    }

    // Re-build WHERE with table alias for the JOIN query (uazapi_messages aliased as m)
    const condsPrefixed = conds.map(c =>
      c.startsWith('unit_id') ? c.replace('unit_id', 'm.unit_id') : `m.${c}`
    );
    const whereAliased = condsPrefixed.length ? `WHERE ${condsPrefixed.join(' AND ')}` : '';

    try {

      const [countRes, dataRes] = await Promise.all([
        pool.query(`SELECT COUNT(*) FROM uazapi_messages m ${whereAliased}`, params),
        pool.query(
          `SELECT m.id, m.message_id, m.instance_id, m.unit_id,
                  COALESCE(c.nome_fantasia, c.razao_social, m.unit_id::text) AS unit_name,
                  m.phone_number, m.direction, m.body,
                  m.message_type, m.attachment_url, m.attachment_name, m.attachment_mime,
                  m.ack_status, m.is_starred, m.is_forwarded, m.quoted_body, m.reaction,
                  m.sent_at, m.imported_at
           FROM uazapi_messages m
           LEFT JOIN companies c ON c.id = m.unit_id
           ${whereAliased}
           ORDER BY m.sent_at DESC NULLS LAST
           LIMIT ${limitNum} OFFSET ${offset}`,
          params
        ),
      ]);
      const total = parseInt(countRes.rows[0].count, 10);
      return res.json({
        messages: dataRes.rows,
        total,
        page: pageNum,
        pages: Math.ceil(total / limitNum),
      });
    } catch (err) {
      logger.error(`[uazapiAdv] GET /messages: ${err.message}`);
      return res.status(500).json({ error: 'Erro ao listar mensagens.' });
    }
  });

  // POST /import-all — admin: importa TODO o histórico disponível na uazapi
  // Responde imediatamente (202) e processa em background. Idempotente por message_id.
  router.post('/import-all', requireAdmin, async (req, res) => {
    const specificUnit = (req.body?.unitId || '').trim() || null;

    // Verifica se já está rodando
    try {
      const sr = await pool.query(`SELECT value FROM app_data WHERE key = 'uazapi_import_status'`);
      const current = sr.rows[0]?.value;
      if (current?.running) {
        return res.status(409).json({ error: 'Importação já em andamento.', status: current });
      }
    } catch { /* ok */ }

    const initial = {
      running: true,
      startedAt: new Date().toISOString(),
      totalChats: 0,
      processedChats: 0,
      inserted: 0,
      lastError: null,
    };

    try {
      await pool.query(
        `INSERT INTO app_data (key, value) VALUES ('uazapi_import_status', $1::jsonb)
         ON CONFLICT (key) DO UPDATE SET value = $1::jsonb, updated_at = NOW()`,
        [JSON.stringify(initial)]
      );
    } catch { /* non-fatal */ }

    res.json({ ok: true, message: 'Importação histórica iniciada em background.', status: initial });

    setImmediate(() => runFullImport(pool, specificUnit, logger));
  });

  return router;
}

// ══════════════════════════════════════════════════════════════
//  runFullImport — importação histórica completa para uazapi_messages
// ══════════════════════════════════════════════════════════════

function extractChatsArrayFull(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.chats)) return data.chats;
  if (Array.isArray(data?.data)) return data.data;
  if (data?.chats && Array.isArray(data.chats.data)) return data.chats.data;
  if (data?.chats && typeof data.chats === 'object') return Object.values(data.chats);
  return [];
}

function extractMessagesArrayFull(data) {
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.messages)) return data.messages;
  if (Array.isArray(data?.data)) return data.data;
  return [];
}

function mapMsgTypeFull(t) {
  if (!t) return 'TEXT';
  const s = String(t).toLowerCase();
  if (s.includes('image')) return 'IMAGE';
  if (s.includes('audio') || s.includes('ptt')) return 'AUDIO';
  if (s.includes('document')) return 'DOCUMENT';
  if (s.includes('video')) return 'VIDEO';
  if (s.includes('sticker')) return 'STICKER';
  return 'TEXT';
}

async function saveImportStatus(pool, status) {
  try {
    await pool.query(
      `INSERT INTO app_data (key, value) VALUES ('uazapi_import_status', $1::jsonb)
       ON CONFLICT (key) DO UPDATE SET value = $1::jsonb, updated_at = NOW()`,
      [JSON.stringify(status)]
    );
  } catch { /* non-fatal */ }
}

async function runFullImport(pool, specificUnit, log) {
  const status = {
    running: true,
    startedAt: new Date().toISOString(),
    totalChats: 0,
    processedChats: 0,
    inserted: 0,
    lastError: null,
  };

  try {
    const { decrypt } = await import('../utils/encryption.js');

    // Buscar instâncias (todas ou de uma unidade específica)
    const instQ = specificUnit
      ? `SELECT unit_id, uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url
         FROM unit_whatsapp_credentials WHERE unit_id = $1 ORDER BY created_at ASC`
      : `SELECT unit_id, uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url
         FROM unit_whatsapp_credentials ORDER BY unit_id, uazapi_instance_id`;
    const instRows = specificUnit
      ? (await pool.query(instQ, [specificUnit])).rows
      : (await pool.query(instQ)).rows;

    if (!instRows.length) {
      status.running = false;
      status.lastError = 'Nenhuma instância configurada.';
      await saveImportStatus(pool, status);
      return;
    }

    for (const instRow of instRows) {
      const instanceId = instRow.uazapi_instance_id;
      const unitId     = instRow.unit_id;
      const token      = instRow.uazapi_token_encrypted ? decrypt(instRow.uazapi_token_encrypted) : null;
      const baseUrl    = (instRow.uazapi_server_url || 'https://free.uazapi.com').replace(/\/$/, '');

      if (!token) {
        log.warn(`[uazapiFullImport] Instância "${instanceId}" sem token — pulada.`);
        continue;
      }

      const headers = { 'Content-Type': 'application/json', 'token': token };

      // ── 1. Iterar TODAS as páginas de chats (sem limite artificial) ──────────
      let allChats = [];
      let chatPage = 1;

      while (true) {
        let pageChats = [];
        try {
          const r = await fetch(`${baseUrl}/chats?page=${chatPage}`, {
            headers,
            signal: AbortSignal.timeout(10000),
          });
          if (!r.ok) break;
          const d = await r.json().catch(() => ({}));
          pageChats = extractChatsArrayFull(d);
        } catch (err) {
          log.warn(`[uazapiFullImport] Erro ao buscar chats pág.${chatPage} (${instanceId}): ${err.message}`);
          break;
        }
        if (!pageChats.length) break; // página vazia = fim real da paginação
        allChats = allChats.concat(pageChats);
        log.info(`[uazapiFullImport] Instância "${instanceId}" — pág.${chatPage}: ${pageChats.length} chats recebidos, ${allChats.length} acumulados.`);
        chatPage++;
      }

      status.totalChats += allChats.length;
      await saveImportStatus(pool, status);

      // ── 2. Para cada chat, buscar TODAS as mensagens ────────────────────────
      for (const chat of allChats) {
        const chatId  = String(chat.chatid || chat.jid || chat.id || chat.chatId || '');
        const phoneRaw = chatId.split('@')[0].replace(/\D/g, '');
        if (!phoneRaw) { status.processedChats++; continue; }
        const phone = (phoneRaw.startsWith('55') && phoneRaw.length > 11) ? phoneRaw.slice(2) : phoneRaw;

        // Processa mensagens página a página — insere imediatamente sem acumular em memória
        let msgPage = 1;
        let partialErrCount = 0;

        while (true) {
          let pageMsgs = [];
          try {
            const r = await fetch(
              `${baseUrl}/messages?chatid=${encodeURIComponent(chatId)}&limit=100&page=${msgPage}`,
              { headers, signal: AbortSignal.timeout(10000) }
            );
            if (!r.ok) {
              const errMsg = `HTTP ${r.status} ao buscar msgs chat ${chatId} pág.${msgPage}`;
              log.warn(`[uazapiFullImport] ${errMsg}`);
              partialErrCount++;
              if (partialErrCount === 1) status.lastError = errMsg; // registra primeira falha parcial
              await saveImportStatus(pool, status);
              break;
            }
            const d = await r.json().catch(() => ({}));
            pageMsgs = extractMessagesArrayFull(d);
          } catch (fetchErr) {
            const errMsg = `Timeout/erro de rede ao buscar msgs chat ${chatId} pág.${msgPage}: ${fetchErr.message}`;
            log.warn(`[uazapiFullImport] ${errMsg}`);
            partialErrCount++;
            if (partialErrCount === 1) status.lastError = errMsg;
            await saveImportStatus(pool, status);
            break;
          }
          if (!pageMsgs.length) break; // página vazia = fim real da paginação

          // Upsert imediato desta página (streaming — sem acumular allMsgs)
          for (const msg of pageMsgs) {
            const messageId = msg.messageid || msg.id || msg.key?.id || null;
            if (!messageId) continue;

            const ts     = msg.messageTimestamp || msg.timestamp || msg.sentAt || 0;
            const tsMs   = typeof ts === 'number' ? (ts < 1e12 ? ts * 1000 : ts) : (ts ? new Date(ts).getTime() : 0);
            const sentAt = tsMs ? new Date(tsMs).toISOString() : null;

            const direction      = msg.fromMe ? 'OUT' : 'IN';
            const body           = msg.text || msg.body || msg.caption || msg.message?.conversation || null;
            const messageType    = mapMsgTypeFull(msg.messageType);
            const attachmentUrl  = msg.fileURL || msg.url || msg.mediaUrl || null;
            const attachmentName = msg.fileName || null;
            const attachmentMime = msg.mimeType || msg.mimetype || null;
            const isStarred      = !!(msg.starred || msg.isStarred);
            const isForwarded    = !!(msg.isForwarded || msg.forwarded);
            const reaction       = msg.reaction || null;
            const quotedId       = msg.quotedMessageId || msg.quoted?.id || null;
            const quotedBody     = msg.quotedMessage || msg.quoted?.body || null;
            const ackStatus      = msg.ack != null ? Number(msg.ack) : null;

            // Payload bruto completo para preservar campos nativos e permitir reprocessamento
            const rawPayload = { ...msg, _chatId: chatId, _instanceId: instanceId };

            try {
              const dbR = await pool.query(
                `INSERT INTO uazapi_messages
                   (message_id, instance_id, unit_id, chat_id, phone_number, direction, body,
                    message_type, attachment_url, attachment_mime, attachment_name,
                    quoted_message_id, quoted_body, reaction, is_starred, is_forwarded,
                    ack_status, sent_at, raw_payload)
                 VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19::jsonb)
                 ON CONFLICT (message_id) DO NOTHING`,
                [
                  String(messageId), instanceId, unitId, chatId, phone,
                  direction, body, messageType,
                  attachmentUrl, attachmentMime, attachmentName,
                  quotedId, quotedBody, reaction, isStarred, isForwarded,
                  ackStatus, sentAt, JSON.stringify(rawPayload),
                ]
              );
              if (dbR.rowCount > 0) status.inserted++;
            } catch (dbErr) {
              log.warn(`[uazapiFullImport] Erro ao salvar msg ${messageId}: ${dbErr.message}`);
            }
          }

          msgPage++;
        }

        status.processedChats++;
        // Salva progresso a cada 10 chats processados
        if (status.processedChats % 10 === 0) {
          await saveImportStatus(pool, status);
        }
      }

      log.info(`[uazapiFullImport] Instância "${instanceId}" concluída: ${status.inserted} mensagens inseridas.`);
    }
  } catch (outerErr) {
    log.error(`[uazapiFullImport] Erro geral: ${outerErr.message}`);
    status.lastError = outerErr.message;
  } finally {
    status.running = false;
    await saveImportStatus(pool, status);
    log.info(`[uazapiFullImport] Importação concluída. Total inserido: ${status.inserted}. Chats: ${status.processedChats}/${status.totalChats}.`);
  }
}

// ══════════════════════════════════════════════════════════════
//  Broadcast — lógica de envio em background
// ══════════════════════════════════════════════════════════════

async function runBroadcast(pool, unitId, broadcastId, contacts, message) {
  const results = [];
  let sent = 0;
  let failed = 0;

  for (const contact of contacts) {
    await new Promise(r => setTimeout(r, 1000 + Math.random() * 1000));
    try {
      const chatId = formatWaId(contact);
      const r = await uazApiFetch(pool, unitId, '/messages/send', {
        method: 'POST',
        body: JSON.stringify({ chatId, text: message }),
      });
      const d = await r.json().catch(() => ({}));
      if (r.ok) {
        sent++;
        results.push({ contact, status: 'sent', messageId: d?.key?.id || d?.id || null });
      } else {
        failed++;
        results.push({ contact, status: 'failed', error: d?.message || `HTTP ${r.status}` });
      }
    } catch (err) {
      failed++;
      results.push({ contact, status: 'failed', error: err.message });
    }

    await pool.query(
      `UPDATE whatsapp_broadcast_logs SET sent = $1, failed = $2, results = $3 WHERE id = $4`,
      [sent, failed, JSON.stringify(results), broadcastId]
    ).catch(() => {});
  }

  await pool.query(
    `UPDATE whatsapp_broadcast_logs
     SET sent = $1, failed = $2, results = $3, status = 'done', completed_at = NOW()
     WHERE id = $4`,
    [sent, failed, JSON.stringify(results), broadcastId]
  ).catch(err => logger.error(`[Broadcast] Erro ao finalizar: ${err.message}`));

  logger.info(`[Broadcast] ${broadcastId} concluído: ${sent} enviados, ${failed} falhas.`);
}

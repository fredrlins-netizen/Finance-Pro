import { Router } from 'express';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
import { gotalkFetch, getChannelId } from '../services/gotalkAuth.js';
import { validateReferenceIds } from '../lib/referenceIdentity.js';
import { initPool, linkClientRetroactively, normalizePhone, runOneCycle, importContacts, importOperators, importAttendances, importAttendancesPerOperator, upsertOperatorAttendance, importAttendanceHistory, upsertAttendanceHistory, importMessagesForAttendanceHistory, importMessagesForActiveAttendances, upsertAttendance, backfillMessagesForAttendance, importHSMTemplates } from '../services/gotalkPoller.js';

function encodeTimelineCursor(message) {
  if (!message?.sent_at || !message?.message_id) return null;
  return Buffer.from(JSON.stringify({
    sent_at: new Date(message.sent_at).toISOString(),
    message_id: message.message_id,
  })).toString('base64url');
}

function decodeTimelineCursor(value) {
  try {
    const cursor = JSON.parse(Buffer.from(String(value), 'base64url').toString('utf8'));
    if (
      !cursor
      || typeof cursor.sent_at !== 'string'
      || Number.isNaN(Date.parse(cursor.sent_at))
      || typeof cursor.message_id !== 'string'
      || !cursor.message_id
    ) {
      return null;
    }
    return {
      sent_at: new Date(cursor.sent_at).toISOString(),
      message_id: cursor.message_id,
    };
  } catch {
    return null;
  }
}

// Resolve a gotalk_contacts row from either a local UUID or a Gotalk external _id
async function resolveContact(pool, id) {
  // Try local UUID first
  let res = await pool.query(`SELECT * FROM gotalk_contacts WHERE id = $1`, [id]);
  if (res.rows.length > 0) return res.rows[0];
  // Fall back to Gotalk external ID
  res = await pool.query(`SELECT * FROM gotalk_contacts WHERE gotalk_id = $1`, [id]);
  return res.rows[0] || null;
}

// Resolve GoTalk internal channel_id from a channel UUID (gotalk_channels.id).
// Falls back to the primary channel from GoTalk auth if channelUuid is not provided.
// channel_id is NEVER returned to the frontend — only used server-side.
async function resolveChannelIdByUuid(pool, channelUuid) {
  if (channelUuid) {
    const r = await pool.query(`SELECT channel_id FROM gotalk_channels WHERE id = $1 AND is_active = TRUE`, [channelUuid]);
    if (r.rows[0]?.channel_id) return r.rows[0].channel_id;
    throw new Error('Canal não encontrado ou inativo.');
  }
  return getChannelId();
}

export function createGotalkRoutes(pool) {
  const router = Router();

  // Initialize the poller's shared pool so manual sync routes work without
  // starting the background timers (timers are now the worker's responsibility).
  initPool(pool);

  // ── Helper: build public webhook URL ──────────────────────────────────────
  // Returns the URL where GoTalk should send webhook events.
  // The webhook is handled by the standalone WhatsApp Worker (separate Replit).
  // Set the GOTALK_WORKER_URL env var to the Worker's public base URL so the
  // Settings UI can display the correct webhook endpoint for GoTalk configuration.
  function buildWebhookUrl() {
    const workerBase = process.env.GOTALK_WORKER_URL;
    if (workerBase) return `${workerBase.replace(/\/$/, '')}/api/gotalk/webhook`;
    return null; // URL unknown until GOTALK_WORKER_URL is configured
  }

  // GET /api/gotalk/webhook-url — return the public webhook URL for GoTalk configuration
  // Reflects the Worker Replit URL (GOTALK_WORKER_URL env var) — not this CRM.
  router.get('/webhook-url', async (req, res) => {
    const webhookUrl = buildWebhookUrl();
    res.json({ webhookUrl, configured: !!process.env.GOTALK_WORKER_URL });
  });

  // GET /api/gotalk/webhook-status — status info for the Settings → APIs card
  router.get('/webhook-status', async (req, res) => {
    try {
      const secretConfigured = !!process.env.GOTALK_WEBHOOK_SECRET;
      const [mRes, lastRes] = await Promise.all([
        pool.query(`SELECT COUNT(*) FROM gotalk_messages`),
        pool.query(`SELECT MAX(sent_at) as last_at FROM gotalk_messages`),
      ]);
      res.json({
        webhookUrl: buildWebhookUrl(),
        workerConfigured: !!process.env.GOTALK_WORKER_URL,
        secretConfigured,
        totalMessages: parseInt(mRes.rows[0].count, 10),
        lastWebhookAt: lastRes.rows[0]?.last_at || null,
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/webhook-secret — save webhook secret to DB and apply in-process
  // 🔒 SEGURANÇA [VULN-3]: webhook secret é configuração crítica de segurança.
  // Exige ADMIN — qualquer usuário autenticado podia antes apagar/substituir o secret.
  router.post('/webhook-secret', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { secret } = req.body;
      if (typeof secret !== 'string') return res.status(400).json({ error: 'Campo "secret" obrigatório.' });

      const trimmed = secret.trim();
      if (trimmed.length > 0) {
        // Persist in app_data
        await pool.query(
          `INSERT INTO app_data (key, value) VALUES ('gotalk_webhook_secret', $1::jsonb)
           ON CONFLICT (key) DO UPDATE SET value = $1::jsonb, updated_at = NOW()`,
          [JSON.stringify({ secret: trimmed })]
        );
        // Apply immediately in this process
        process.env.GOTALK_WEBHOOK_SECRET = trimmed;
        console.log('[Gotalk] GOTALK_WEBHOOK_SECRET atualizado via Settings UI.');
        res.json({ success: true, message: 'Secret salvo e aplicado com sucesso.' });
      } else {
        // Clear
        await pool.query(`DELETE FROM app_data WHERE key = 'gotalk_webhook_secret'`);
        delete process.env.GOTALK_WEBHOOK_SECRET;
        console.log('[Gotalk] GOTALK_WEBHOOK_SECRET removido via Settings UI.');
        res.json({ success: true, message: 'Secret removido.' });
      }
    } catch (err) {
      // 🔒 SEGURANÇA [VULN-8]: não expor err.message ao cliente.
      console.error('[Gotalk] webhook-secret error:', err.message);
      res.status(500).json({ error: 'Erro interno no servidor.' });
    }
  });

  // POST /api/gotalk/sync-operators — fetch operators from GoTalk API and upsert into gotalk_operators.
  // Triggers the same importOperators() used by the poller but on demand so the user can
  // force a refresh without waiting for the next poll cycle.
  router.post('/sync-operators', async (req, res) => {
    try {
      await importOperators();
      const result = await pool.query(
        `SELECT gotalk_operator_id, name, email, phone, active, collaborator_id, updated_at
         FROM gotalk_operators
         ORDER BY name ASC`
      );
      res.json({
        success: true,
        total: result.rows.length,
        operators: result.rows,
        message: `${result.rows.length} operador(es) sincronizado(s) com sucesso.`,
      });
    } catch (err) {
      console.error('[Gotalk] POST /sync-operators error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/operators — list all operators stored in the DB (no GoTalk call).
  router.get('/operators', async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT go.id, go.gotalk_operator_id, go.name, go.email, go.phone,
                go.active, go.collaborator_id, go.imported_at, go.updated_at,
                c.name AS collaborator_name
         FROM gotalk_operators go
         LEFT JOIN collaborators c ON c.id = go.collaborator_id
         ORDER BY go.name ASC`
      );
      res.json({ operators: result.rows, total: result.rows.length });
    } catch (err) {
      console.error('[Gotalk] GET /operators error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/sync-operator-attendances — fetch open attendances from GoTalk for every
  // active operator via GET /attendance/operatorId/:id and upsert into gotalk_operator_attendances.
  router.post('/sync-operator-attendances', async (req, res) => {
    try {
      await importAttendancesPerOperator();
      const result = await pool.query(
        `SELECT goa.gotalk_attendance_id, goa.protocol, goa.operator_name,
                goa.client_name, goa.client_number, goa.department_name,
                goa.status, goa.attendance_start_time, goa.last_message_at, goa.updated_at
         FROM gotalk_operator_attendances goa
         ORDER BY goa.attendance_start_time DESC
         LIMIT 200`
      );
      res.json({
        success: true,
        total: result.rows.length,
        attendances: result.rows,
        message: `${result.rows.length} atendimento(s) de operadores sincronizados.`,
      });
    } catch (err) {
      console.error('[Gotalk] POST /sync-operator-attendances error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/operator-attendances — list operator attendances from DB.
  // Supports optional query params: operatorId, status, limit (default 200).
  router.get('/operator-attendances', async (req, res) => {
    try {
      const { operatorId, status, limit = '200' } = req.query;
      const conditions = [];
      const params = [];

      if (operatorId) {
        params.push(operatorId);
        conditions.push(`goa.gotalk_operator_id = $${params.length}`);
      }
      if (status) {
        params.push(status);
        conditions.push(`goa.status = $${params.length}`);
      }

      const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
      const limitVal = Math.min(parseInt(limit, 10) || 200, 1000);

      const result = await pool.query(
        `SELECT goa.id, goa.gotalk_attendance_id, goa.gotalk_operator_id,
                goa.operator_name, goa.protocol, goa.gotalk_contact_id_ext,
                goa.client_number, goa.client_name, goa.client_id,
                goa.department_id, goa.department_name, goa.channel_id,
                goa.status, goa.attendance_start_time, goa.last_message_at,
                goa.imported_at, goa.updated_at,
                go.name AS operator_full_name,
                c.name  AS client_crm_name
         FROM gotalk_operator_attendances goa
         LEFT JOIN gotalk_operators go ON go.gotalk_operator_id = goa.gotalk_operator_id
         LEFT JOIN clients c ON c.id = goa.client_id
         ${whereClause}
         ORDER BY goa.attendance_start_time DESC
         LIMIT ${limitVal}`,
        params
      );
      res.json({ attendances: result.rows, total: result.rows.length });
    } catch (err) {
      console.error('[Gotalk] GET /operator-attendances error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/sync-attendance-history — trigger an immediate import of attendance history
  // for all known contact phone numbers (from operator_attendances + contacts linked to CRM clients).
  router.post('/sync-attendance-history', async (req, res) => {
    try {
      importAttendanceHistory().catch(err =>
        console.error('[Gotalk] sync-attendance-history error:', err.message)
      );
      res.json({ ok: true, message: 'Importação de histórico de atendimentos iniciada em background.' });
    } catch (err) {
      console.error('[Gotalk] POST /sync-attendance-history error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/attendance-history — list attendance history records from DB.
  // Query params: clientNumber, clientId, operatorId, status, limit (default 100).
  router.get('/attendance-history', async (req, res) => {
    try {
      const { clientNumber, clientId, operatorId, status, limit = 100 } = req.query;
      const conditions = [];
      const params = [];

      if (clientNumber) {
        params.push(normalizePhone(clientNumber));
        conditions.push(`client_number = $${params.length}`);
      }
      if (clientId) {
        params.push(clientId);
        conditions.push(`client_id = $${params.length}`);
      }
      if (operatorId) {
        params.push(operatorId);
        conditions.push(`gotalk_operator_id = $${params.length}`);
      }
      if (status) {
        params.push(status);
        conditions.push(`status = $${params.length}`);
      }

      const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
      params.push(parseInt(limit, 10) || 100);
      const result = await pool.query(
        `SELECT id, gotalk_attendance_id, protocol, channel_id,
                gotalk_contact_id_ext, gotalk_contact_db_id,
                client_number, client_name, client_id,
                gotalk_operator_id, operator_db_id, operator_name,
                department_id, department_name,
                status, attendance_start_time, last_message_at, finished_at,
                imported_at, updated_at
         FROM gotalk_attendance_history
         ${where}
         ORDER BY attendance_start_time DESC
         LIMIT $${params.length}`,
        params
      );
      res.json({ history: result.rows, total: result.rows.length });
    } catch (err) {
      console.error('[Gotalk] GET /attendance-history error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/sync-messages-by-attendance — trigger immediate import of messages for all
  // attendances stored in gotalk_attendance_history (active re-fetched, closed fetched once).
  router.post('/sync-messages-by-attendance', async (req, res) => {
    try {
      importMessagesForAttendanceHistory().catch(err =>
        console.error('[Gotalk] sync-messages-by-attendance error:', err.message)
      );
      res.json({ ok: true, message: 'Importação de mensagens por atendimento iniciada em background.' });
    } catch (err) {
      console.error('[Gotalk] POST /sync-messages-by-attendance error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/messages-by-attendance — list gotalk_messages filtered by attendance.
  // Query params: attendanceId (GoTalk external ID), attendanceHistoryId (UUID), clientId, clientNumber, limit (default 200).
  router.get('/messages-by-attendance', async (req, res) => {
    try {
      const { attendanceId, attendanceHistoryId, clientId, clientNumber, limit = 200 } = req.query;
      const conditions = [];
      const params = [];

      if (attendanceId) {
        params.push(attendanceId);
        conditions.push(`gotalk_attendance_id_ext = $${params.length}`);
      }
      if (attendanceHistoryId) {
        params.push(attendanceHistoryId);
        conditions.push(`attendance_history_id = $${params.length}`);
      }
      if (clientId) {
        params.push(clientId);
        conditions.push(`client_id = $${params.length}`);
      }
      if (clientNumber) {
        params.push(normalizePhone(clientNumber));
        conditions.push(`phone_number = $${params.length}`);
      }

      if (conditions.length === 0) {
        return res.status(400).json({ error: 'Informe pelo menos um filtro: attendanceId, attendanceHistoryId, clientId ou clientNumber.' });
      }

      const where = `WHERE ${conditions.join(' AND ')}`;
      params.push(parseInt(limit, 10) || 200);
      const result = await pool.query(
        `SELECT gm.id, gm.gotalk_message_id, gm.idwpp,
                gm.gotalk_contact_id, gm.attendance_history_id, gm.gotalk_attendance_id_ext,
                gm.client_id, gm.phone_number,
                gm.direction, gm.body, gm.message_type,
                gm.attachment_url, gm.attachment_name, gm.attachment_mime_type,
                gm.audio_transcript, gm.ack_status,
                gm.operator_name, gm.department,
                gm.sent_at, gm.imported_at,
                ht.body_text   AS template_body,
                ht.header_text AS template_header,
                ht.footer_text AS template_footer,
                ht.category    AS template_category,
                ht.status      AS template_status
         FROM gotalk_messages gm
         LEFT JOIN gotalk_hsm_templates ht
           ON gm.message_type = 'TEMPLATE' AND ht.template_name = gm.attachment_name
         ${where}
         ORDER BY gm.sent_at ASC
         LIMIT $${params.length}`,
        params
      );
      res.json({ messages: result.rows, total: result.rows.length });
    } catch (err) {
      console.error('[Gotalk] GET /messages-by-attendance error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/sync-contacts — importa/atualiza todos os contatos do GoTalk para gotalk_contacts.
  router.post('/sync-contacts', async (req, res) => {
    try {
      importContacts().catch(err =>
        console.error('[Gotalk] sync-contacts error:', err.message)
      );
      res.json({ ok: true, message: 'Importação de contatos iniciada em background.' });
    } catch (err) {
      console.error('[Gotalk] POST /sync-contacts error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/contacts-summary — contagem e estado atual de gotalk_contacts.
  router.get('/contacts-summary', async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT COUNT(*) AS total,
                COUNT(*) FILTER (WHERE client_id IS NOT NULL) AS vinculados,
                COUNT(*) FILTER (WHERE client_id IS NULL) AS nao_vinculados,
                MAX(imported_at) AS ultima_importacao
         FROM gotalk_contacts`
      );
      res.json(result.rows[0]);
    } catch (err) {
      console.error('[Gotalk] GET /contacts-summary error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/sync-attendances — importa/atualiza todos os atendimentos de gotalk_attendances
  // (legado, via API de atendimentos por operador e histórico).
  router.post('/sync-attendances', async (req, res) => {
    try {
      importAttendances().catch(err =>
        console.error('[Gotalk] sync-attendances error:', err.message)
      );
      res.json({ ok: true, message: 'Importação de atendimentos iniciada em background.' });
    } catch (err) {
      console.error('[Gotalk] POST /sync-attendances error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/attendances-summary — contagem e estado atual de gotalk_attendances.
  router.get('/attendances-summary', async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT COUNT(*) AS total,
                COUNT(*) FILTER (WHERE status = 'open') AS abertos,
                COUNT(*) FILTER (WHERE status = 'closed') AS fechados,
                MAX(updated_at) AS ultima_atualizacao
         FROM gotalk_attendances`
      );
      res.json(result.rows[0]);
    } catch (err) {
      console.error('[Gotalk] GET /attendances-summary error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/sync-active-messages — importa mensagens dos atendimentos ativos
  // (re-executa importMessagesForActiveAttendances do poller).
  router.post('/sync-active-messages', async (req, res) => {
    try {
      importMessagesForActiveAttendances().catch(err =>
        console.error('[Gotalk] sync-active-messages error:', err.message)
      );
      res.json({ ok: true, message: 'Importação de mensagens de atendimentos ativos iniciada em background.' });
    } catch (err) {
      console.error('[Gotalk] POST /sync-active-messages error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/messages-summary — contagem e estado atual de gotalk_messages.
  router.get('/messages-summary', async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT COUNT(*) AS total,
                COUNT(*) FILTER (WHERE direction = 'IN') AS recebidas,
                COUNT(*) FILTER (WHERE direction = 'OUT') AS enviadas,
                COUNT(*) FILTER (WHERE message_type = 'AUDIO') AS audios,
                COUNT(DISTINCT phone_number) AS contatos_ativos,
                MAX(sent_at) AS ultima_mensagem
         FROM gotalk_messages`
      );
      res.json(result.rows[0]);
    } catch (err) {
      console.error('[Gotalk] GET /messages-summary error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/hsm-templates — lista todos os templates HSM sincronizados.
  // Aceita ?channelUuid=<uuid> para filtrar por canal.
  router.get('/hsm-templates', async (req, res) => {
    try {
      const { channelUuid } = req.query;
      let query, params;
      if (channelUuid) {
        query = `SELECT id, template_name, gotalk_template_id, category, language, status,
                        body_text, header_text, footer_text, gotalk_channel_uuid, synced_at
                 FROM gotalk_hsm_templates
                 WHERE gotalk_channel_uuid = $1
                 ORDER BY template_name ASC`;
        params = [channelUuid];
      } else {
        query = `SELECT id, template_name, gotalk_template_id, category, language, status,
                        body_text, header_text, footer_text, gotalk_channel_uuid, synced_at
                 FROM gotalk_hsm_templates
                 ORDER BY template_name ASC`;
        params = [];
      }
      const result = await pool.query(query, params);
      res.json({ templates: result.rows, total: result.rows.length });
    } catch (err) {
      console.error('[Gotalk] GET /hsm-templates error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/sync-hsm-templates — sincronização manual dos templates HSM.
  router.post('/sync-hsm-templates', async (req, res) => {
    try {
      importHSMTemplates().catch(err => console.error('[Gotalk] sync-hsm-templates bg error:', err.message));
      res.json({ ok: true, message: 'Sincronização de templates HSM iniciada.' });
    } catch (err) {
      console.error('[Gotalk] POST /sync-hsm-templates error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/client-timeline?phone= — timeline cronológica de mensagens de um número de telefone,
  // enriquecida com dados do atendimento e do contato, via view v_gotalk_client_timeline.
  // Params: phone (obrigatório), limit (default 200), offset (legado),
  // cursor + direction=next|previous para paginação estável.
  router.get('/client-timeline', async (req, res) => {
    try {
      const {
        phone,
        limit = 200,
        offset = 0,
        order = 'asc',
        cursor: encodedCursor,
        direction = 'next',
      } = req.query;
      if (!phone) return res.status(400).json({ error: 'Parâmetro phone é obrigatório.' });
      if (encodedCursor && !['next', 'previous'].includes(String(direction).toLowerCase())) {
        return res.status(400).json({ error: 'Parâmetro direction deve ser next ou previous.' });
      }

      const norm = normalizePhone(phone);
      // Use last 8 digits for matching to handle Brazilian "9th digit" ambiguity:
      // uazapi may strip the 9th digit (e.g. 81981071630 → 8181071630),
      // but last 8 digits are invariant across both formats.
      const last8 = norm.slice(-8);

      const lim = Math.min(parseInt(limit, 10) || 200, 500);
      const off = parseInt(offset, 10) || 0;
      // order=desc retorna as mensagens MAIS RECENTES primeiro (usado pela
      // Prospecção para carregar os 500 últimos e paginar mensagens anteriores
      // via offset). Default 'asc' preserva o comportamento dos demais callers.
      const sortDir = String(order).toLowerCase() === 'desc' ? 'DESC' : 'ASC';
      const cursor = encodedCursor ? decodeTimelineCursor(encodedCursor) : null;
      if (encodedCursor && !cursor) {
        return res.status(400).json({ error: 'Cursor inválido.' });
      }

      const cursorDirection = String(direction).toLowerCase();
      const isPrevious = Boolean(cursor) && cursorDirection === 'previous';
      const pageSortDir = isPrevious
        ? (sortDir === 'ASC' ? 'DESC' : 'ASC')
        : sortDir;
      const comparison = (
        (sortDir === 'ASC' && !isPrevious)
        || (sortDir === 'DESC' && isPrevious)
      ) ? '>' : '<';
      const cursorClause = cursor
        ? `AND (sent_at, message_id) ${comparison} ($2::timestamptz, $3)`
        : '';
      const queryParams = cursor
        ? [last8, cursor.sent_at, cursor.message_id, lim]
        : [last8, lim, off];
      const paginationClause = cursor ? 'LIMIT $4' : 'LIMIT $2 OFFSET $3';

      const result = await pool.query(
        `SELECT *
         FROM v_gotalk_client_timeline
         WHERE RIGHT(phone_number, 8) = $1
         ${cursorClause}
         ORDER BY sent_at ${pageSortDir}, message_id ${pageSortDir}
         ${paginationClause}`,
        queryParams
      );
      const messages = isPrevious ? [...result.rows].reverse() : result.rows;

      const total = await pool.query(
        `SELECT COUNT(*) FROM v_gotalk_client_timeline WHERE RIGHT(phone_number, 8) = $1`,
        [last8]
      );

      res.json({
        phone_normalized: norm,
        messages,
        total: parseInt(total.rows[0].count, 10),
        limit: lim,
        offset: cursor ? null : off,
        next_cursor: encodeTimelineCursor(messages.at(-1)),
        previous_cursor: encodeTimelineCursor(messages[0]),
      });
    } catch (err) {
      console.error('[Gotalk] GET /client-timeline error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/attendance-summary?phone= — resumo de todos os atendimentos de um número,
  // com contagem de mensagens por atendimento, via view v_gotalk_attendance_summary.
  // Params: phone (obrigatório), status (opcional: in_attendance|finished|abandoned|closed|waiting),
  //         limit (default 50, max 200), offset (default 0).
  router.get('/attendance-summary', async (req, res) => {
    try {
      const { phone, status, limit = 50, offset = 0 } = req.query;
      if (!phone) return res.status(400).json({ error: 'Parâmetro phone é obrigatório.' });

      const norm = normalizePhone(phone);
      const last10 = norm.slice(-10);
      const lim = Math.min(parseInt(limit, 10) || 50, 200);
      const off = parseInt(offset, 10) || 0;

      const conditions = [`RIGHT(client_number, 10) = $1`];
      const filterParams = [last10];

      if (status) {
        filterParams.push(status);
        conditions.push(`status = $${filterParams.length}`);
      }

      const where = conditions.join(' AND ');

      // Total count (separate query for accurate pagination metadata)
      const countRes = await pool.query(
        `SELECT COUNT(*) FROM v_gotalk_attendance_summary WHERE ${where}`,
        filterParams
      );
      const total = parseInt(countRes.rows[0].count, 10);

      // Paginated result
      const pageParams = [...filterParams, lim, off];
      const result = await pool.query(
        `SELECT *
         FROM v_gotalk_attendance_summary
         WHERE ${where}
         ORDER BY attendance_start_time DESC
         LIMIT $${pageParams.length - 1} OFFSET $${pageParams.length}`,
        pageParams
      );

      res.json({
        phone_normalized: norm,
        attendances: result.rows,
        total,
        limit: lim,
        offset: off,
      });
    } catch (err) {
      console.error('[Gotalk] GET /attendance-summary error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/rotate-webhook-secret — generate a new cryptographically secure secret,
  // persist it to DB and apply immediately in-process (no restart required).
  // Admin-only: secret is logged server-side only; never returned to the browser.
  router.post('/rotate-webhook-secret', requireAuth, requireAdmin, async (req, res) => {
    try {
      const { randomBytes } = await import('crypto');
      const newSecret = randomBytes(32).toString('hex');

      await pool.query(
        `INSERT INTO app_data (key, value) VALUES ('gotalk_webhook_secret', $1::jsonb)
         ON CONFLICT (key) DO UPDATE SET value = $1::jsonb, updated_at = NOW()`,
        [JSON.stringify({ secret: newSecret })]
      );

      // Apply immediately — no restart needed
      process.env.GOTALK_WEBHOOK_SECRET = newSecret;

      // Secret is intentionally logged server-side only — never sent to the browser.
      // To configure GoTalk: check server logs or use the SQL Console (app_data table).
      console.log('[Gotalk] ════════════════════════════════════════════════════════════════');
      console.log('[Gotalk] NOVO WEBHOOK SECRET GERADO — configure este valor no GoTalk Web:');
      console.log(`[Gotalk] ${newSecret}`);
      console.log('[Gotalk] ════════════════════════════════════════════════════════════════');

      res.json({ success: true, message: 'Novo secret gerado e aplicado com sucesso. Consulte os logs do servidor para obter o valor.' });
    } catch (err) {
      console.error('POST /gotalk/rotate-webhook-secret error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/status
  router.get('/status', async (req, res) => {
    try {
      const configured = !!(process.env.GOTALK_LOGIN && process.env.GOTALK_PASSWORD);
      const [cRes, mRes] = await Promise.all([
        pool.query(`SELECT COUNT(*) FROM gotalk_contacts`),
        pool.query(`SELECT COUNT(*) FROM gotalk_messages`),
      ]);

      let channelStatus = null;
      let channelConnected = false;
      let channelName = null;
      let channelNumber = null;
      try {
        const channelId = await getChannelId();
        if (channelId) {
          const chRes = await gotalkFetch(`/channel/${channelId}`);
          if (chRes.ok) {
            const chData = await chRes.json();
            const ch = chData?.channel?.channel || chData?.channel || {};
            channelStatus = ch.status || null;
            channelName = ch.name || null;
            channelNumber = ch.channelNumber || null;
            // "open" = legacy connected; "authenticated" = Cloud channel (META API), also connected
            channelConnected = channelStatus === 'open' || channelStatus === 'authenticated';
          }
        }
      } catch (_) { /* ignore channel fetch errors */ }

      const isCloudChannel = channelStatus === 'authenticated';
      res.json({
        configured,
        totalContacts: parseInt(cRes.rows[0].count, 10),
        totalMessages: parseInt(mRes.rows[0].count, 10),
        channelStatus,
        channelConnected,
        isCloudChannel,
        channelName,
        channelNumber,
      });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/contacts
  // ?source=gotalk  => paginated directly from Gotalk API
  // default         => local synced cache (fast, searchable)
  router.get('/contacts', async (req, res) => {
    try {
      if (req.query.source === 'gotalk') {
        const channelId = await getChannelId();
        if (!channelId) return res.status(503).json({ error: 'Gotalk não autenticado.' });
        const page = req.query.page || 1;
        const apiRes = await gotalkFetch(`/contact/channel/${channelId}/page/${page}`);
        if (!apiRes.ok) return res.status(apiRes.status).json({ error: await apiRes.text() });
        return res.json(await apiRes.json());
      }

      const page = Math.max(1, parseInt(req.query.page || '1', 10));
      const limit = Math.min(100, Math.max(1, parseInt(req.query.limit || '50', 10)));
      const offset = (page - 1) * limit;
      const search = req.query.search || '';
      const linked = req.query.linked;

      const params = [];
      const conditions = [];
      if (search) {
        params.push(`%${search}%`);
        conditions.push(`(gc.name ILIKE $${params.length} OR gc.phone_number ILIKE $${params.length})`);
      }
      if (linked === 'true') conditions.push('gc.client_id IS NOT NULL');
      else if (linked === 'false') conditions.push('gc.client_id IS NULL');

      const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';
      const countRes = await pool.query(`SELECT COUNT(*) FROM gotalk_contacts gc ${where}`, params);
      const total = parseInt(countRes.rows[0].count, 10);

      const dataParams = [...params, limit, offset];
      const dataRes = await pool.query(
        `SELECT gc.*, c.name AS client_name, c.document AS client_document
         FROM gotalk_contacts gc
         LEFT JOIN clients c ON c.id = gc.client_id
         ${where}
         ORDER BY gc.name ASC NULLS LAST
         LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
        dataParams
      );

      res.json({ data: dataRes.rows, total, page, totalPages: Math.ceil(total / limit) });
    } catch (err) {
      console.error('GET /gotalk/contacts error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/sync — manual one-time import (fire-and-forget)
  router.post('/sync', async (req, res) => {
    res.json({ message: 'Sincronização iniciada em segundo plano.' });
    setImmediate(() => runOneCycle().catch(err => console.error('[Gotalk] sync error:', err.message)));
  });

  // POST /api/gotalk/link-client — manually link a Gotalk contact to a CRM client
  router.post('/link-client', async (req, res) => {
    try {
      const { gotalkContactId, clientId } = req.body;
      if (!gotalkContactId || !clientId) {
        return res.status(400).json({ error: 'gotalkContactId e clientId são obrigatórios.' });
      }
      const dbClient = await pool.connect();
      try {
        await dbClient.query('BEGIN');
        await dbClient.query(
          `UPDATE gotalk_contacts SET client_id = $1, linked_at = NOW() WHERE id = $2`,
          [clientId, gotalkContactId]
        );
        await dbClient.query(
          `UPDATE gotalk_messages SET client_id = $1 WHERE gotalk_contact_id = $2 AND client_id IS NULL`,
          [clientId, gotalkContactId]
        );
        const cRow = await dbClient.query(
          `SELECT channel_id FROM gotalk_contacts WHERE id = $1`, [gotalkContactId]
        );
        await dbClient.query(
          `UPDATE clients SET gotalk_contact_id = $1, gotalk_channel_id = $2 WHERE id = $3`,
          [gotalkContactId, cRow.rows[0]?.channel_id || null, clientId]
        );
        await dbClient.query('COMMIT');
        res.json({ success: true });
      } catch (err) {
        await dbClient.query('ROLLBACK');
        throw err;
      } finally {
        dbClient.release();
      }
    } catch (err) {
      console.error('POST /gotalk/link-client error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/unlink-client
  router.post('/unlink-client', async (req, res) => {
    try {
      const { gotalkContactId } = req.body;
      if (!gotalkContactId) return res.status(400).json({ error: 'gotalkContactId é obrigatório.' });
      const dbClient = await pool.connect();
      try {
        await dbClient.query('BEGIN');
        const contact = await dbClient.query(
          `SELECT client_id FROM gotalk_contacts WHERE id = $1`, [gotalkContactId]
        );
        const clientId = contact.rows[0]?.client_id;
        await dbClient.query(
          `UPDATE gotalk_contacts SET client_id = NULL, linked_at = NULL WHERE id = $1`, [gotalkContactId]
        );
        if (clientId) {
          await dbClient.query(`UPDATE clients SET gotalk_contact_id = NULL WHERE id = $1`, [clientId]);
        }
        await dbClient.query('COMMIT');
        res.json({ success: true });
      } catch (err) {
        await dbClient.query('ROLLBACK');
        throw err;
      } finally {
        dbClient.release();
      }
    } catch (err) {
      console.error('POST /gotalk/unlink-client error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/messages/contact/:gotalkContactId
  router.get('/messages/contact/:gotalkContactId', async (req, res) => {
    try {
      const { gotalkContactId } = req.params;
      const limit = Math.min(200, parseInt(req.query.limit || '100', 10));
      const offset = parseInt(req.query.offset || '0', 10);
      const result = await pool.query(
        `SELECT gm.*, gm.audio_transcript AS transcription,
                ht.body_text   AS template_body,
                ht.header_text AS template_header,
                ht.footer_text AS template_footer,
                ht.category    AS template_category,
                ht.status      AS template_status,
                gfu.file_size  AS attachment_size
         FROM gotalk_messages gm
         LEFT JOIN gotalk_hsm_templates ht
           ON gm.message_type = 'TEMPLATE' AND ht.template_name = gm.attachment_name
         LEFT JOIN gotalk_file_uploads gfu ON gfu.gotalk_message_id = gm.id::text
         WHERE gm.gotalk_contact_id = $1
         ORDER BY gm.sent_at ASC NULLS LAST LIMIT $2 OFFSET $3`,
        [gotalkContactId, limit, offset]
      );
      const countRes = await pool.query(
        `SELECT COUNT(*) FROM gotalk_messages WHERE gotalk_contact_id = $1`, [gotalkContactId]
      );
      res.json({ data: result.rows, total: parseInt(countRes.rows[0].count, 10) });
    } catch (err) {
      console.error('GET /gotalk/messages/contact/:id error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/messages/client/:clientId (internal alias)
  router.get('/messages/client/:clientId', async (req, res) => {
    try {
      const { clientId } = req.params;
      const limit = Math.min(200, parseInt(req.query.limit || '100', 10));
      const offset = parseInt(req.query.offset || '0', 10);
      const result = await pool.query(
        `SELECT gm.*, gm.audio_transcript AS transcription, gc.name AS contact_name,
                ht.body_text   AS template_body,
                ht.header_text AS template_header,
                ht.footer_text AS template_footer,
                ht.category    AS template_category,
                ht.status      AS template_status
         FROM gotalk_messages gm
         LEFT JOIN gotalk_contacts gc ON gc.id = gm.gotalk_contact_id
         LEFT JOIN gotalk_hsm_templates ht
           ON gm.message_type = 'TEMPLATE' AND ht.template_name = gm.attachment_name
         WHERE gm.client_id = $1 ORDER BY gm.sent_at ASC NULLS LAST LIMIT $2 OFFSET $3`,
        [clientId, limit, offset]
      );
      const countRes = await pool.query(
        `SELECT COUNT(*) FROM gotalk_messages WHERE client_id = $1`, [clientId]
      );
      res.json({ data: result.rows, total: parseInt(countRes.rows[0].count, 10) });
    } catch (err) {
      console.error('GET /gotalk/messages/client/:id error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/messages/unread-count
  router.get('/messages/unread-count', async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT COUNT(*) FROM gotalk_messages
         WHERE direction = 'IN' AND read_at IS NULL
           AND sent_at > NOW() - INTERVAL '24 hours'`
      );
      res.json({ count: parseInt(result.rows[0].count, 10) });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/messages/mark-all-read — marca todas mensagens IN como lidas
  router.post('/messages/mark-all-read', async (req, res) => {
    try {
      await pool.query(
        `UPDATE gotalk_messages SET read_at = NOW()
         WHERE direction = 'IN' AND read_at IS NULL`
      );
      res.json({ success: true });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/messages/recent — last incoming messages for toast notifications
  router.get('/messages/recent', async (req, res) => {
    try {
      const since = req.query.since ? new Date(req.query.since) : new Date(Date.now() - 35000);
      const result = await pool.query(
        `SELECT gm.id, gm.body, gm.message_type, gm.sent_at, gm.imported_at,
                gm.gotalk_contact_id, gm.client_id,
                gc.name AS contact_name, c.name AS client_name
         FROM gotalk_messages gm
         LEFT JOIN gotalk_contacts gc ON gc.id = gm.gotalk_contact_id
         LEFT JOIN clients c ON c.id = gm.client_id
         WHERE gm.direction = 'IN' AND gm.imported_at > $1
         ORDER BY gm.imported_at DESC LIMIT 20`,
        [since]
      );
      res.json({ data: result.rows });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/messages/all — lista geral de mensagens com filtros e ordenação
  router.get('/messages/all', async (req, res) => {
    try {
      const { operator, phone, direction, contact, channel_uuid, sort_by, sort_dir, limit: lim, offset: off } = req.query;
      const limit  = Math.min(200, parseInt(lim  || '100', 10));
      const offset = parseInt(off || '0', 10);

      const conditions = [];
      const params = [];

      if (operator) {
        params.push(`%${operator}%`);
        conditions.push(`gm.operator_name ILIKE $${params.length}`);
      }
      if (phone) {
        const digits = phone.replace(/\D/g, '');
        params.push(`%${digits}%`);
        conditions.push(`REPLACE(REPLACE(REPLACE(gm.phone_number,'+',''),'-',''),' ','') ILIKE $${params.length}`);
      }
      if (direction === 'IN' || direction === 'OUT') {
        params.push(direction);
        conditions.push(`gm.direction = $${params.length}`);
      }
      if (contact) {
        params.push(`%${contact}%`);
        conditions.push(`(gc.name ILIKE $${params.length} OR c.name ILIKE $${params.length})`);
      }
      if (channel_uuid && channel_uuid.trim()) {
        params.push(channel_uuid.trim());
        conditions.push(`gc.gotalk_channel_uuid = $${params.length}`);
      }

      const where = conditions.length ? 'WHERE ' + conditions.join(' AND ') : '';

      // Safe sort column whitelist
      const sortColMap = {
        sent_at:      'gm.sent_at',
        direction:    'gm.direction',
        phone_number: 'gm.phone_number',
        contact_name: 'COALESCE(c.name, gc.name)',
        operator_name:'gm.operator_name',
        message_type: 'gm.message_type',
      };
      const sortCol = sortColMap[sort_by] || 'gm.sent_at';
      const sortDir = sort_dir === 'asc' ? 'ASC' : 'DESC';

      params.push(limit, offset);
      const dataRows = await pool.query(
        `SELECT gm.id, gm.gotalk_message_id, gm.phone_number, gm.direction,
                gm.body, gm.message_type, gm.operator_name, gm.department,
                gm.sent_at, gm.read_at, gm.attachment_url, gm.attachment_name,
                gm.attachment_mime_type, gm.audio_transcript, gm.ack_status,
                gc.name AS contact_name,
                c.name  AS client_name,
                gfu.file_size AS attachment_size
         FROM gotalk_messages gm
         LEFT JOIN gotalk_contacts gc ON gc.id = gm.gotalk_contact_id
         LEFT JOIN clients c ON c.id = gm.client_id
         LEFT JOIN gotalk_file_uploads gfu ON gfu.gotalk_message_id = gm.id::text
         ${where}
         ORDER BY ${sortCol} ${sortDir} NULLS LAST
         LIMIT $${params.length - 1} OFFSET $${params.length}`,
        params
      );

      const countParams = params.slice(0, params.length - 2);
      const countRow = await pool.query(
        `SELECT COUNT(*) FROM gotalk_messages gm
         LEFT JOIN gotalk_contacts gc ON gc.id = gm.gotalk_contact_id
         LEFT JOIN clients c ON c.id = gm.client_id
         ${where}`,
        countParams
      );

      res.json({ data: dataRows.rows, total: parseInt(countRow.rows[0].count, 10) });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/messages/operators — lista de operadores distintos
  router.get('/messages/operators', async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT DISTINCT operator_name FROM gotalk_messages
         WHERE operator_name IS NOT NULL AND operator_name <> ''
         ORDER BY operator_name`
      );
      res.json({ data: result.rows.map(r => r.operator_name) });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/messages/by-phone/:phone — todas as mensagens de um número específico
  // Params: limit (default 100, max 500), offset (default 0)
  router.get('/messages/by-phone/:phone', async (req, res) => {
    try {
      const { phone } = req.params;
      const limit  = Math.min(500, parseInt(req.query.limit  || '100', 10));
      const offset = parseInt(req.query.offset || '0', 10);

      const norm = normalizePhone(phone || '');
      // Canonical BR phone key = DDD (area code) + last 8 digits, with the
      // optional 9th mobile digit removed and the country code (55) stripped.
      // This unifies GoTalk (often 11-digit, with the 9th digit) and uazapi
      // (often 10-digit, without it) for the SAME number into one timeline,
      // while PRESERVING the DDD so different area codes that share the last 8
      // digits are never merged (avoids cross-contact contamination).
      //   5581981071630 → 8181071630
      //   81981071630   → 8181071630
      //   8181071630    → 8181071630
      const brPhoneKey = (raw) => {
        let d = String(raw || '').replace(/\D/g, '');
        if (d.length >= 12 && d.startsWith('55')) d = d.slice(2); // strip country code
        if (d.length === 11) d = d.slice(0, 2) + d.slice(3);      // drop BR 9th digit
        return d;
      };
      const phoneKey = brPhoneKey(norm);

      // Validate phone: reject if too short after normalisation (needs DDD + 8)
      if (phoneKey.length < 10) {
        return res.status(400).json({ error: 'Número de telefone inválido ou muito curto.' });
      }

      // Equivalent canonical-key expression in SQL for the stored phone_number.
      const _rd  = `REGEXP_REPLACE(gm.phone_number, '[^0-9]', '', 'g')`;
      const _str = `CASE WHEN length(${_rd}) >= 12 AND left(${_rd}, 2) = '55' THEN substr(${_rd}, 3) ELSE ${_rd} END`;
      const phoneKeySql = `CASE WHEN length(${_str}) = 11 THEN left(${_str}, 2) || substr(${_str}, 4) ELSE ${_str} END`;

      // Validate pagination params: reject NaN or negative values
      if (!Number.isFinite(limit) || limit < 1) {
        return res.status(400).json({ error: 'Parâmetro limit inválido.' });
      }
      if (!Number.isFinite(offset) || offset < 0) {
        return res.status(400).json({ error: 'Parâmetro offset inválido.' });
      }

      const dataRows = await pool.query(
        `SELECT gm.id, gm.gotalk_message_id, gm.phone_number, gm.direction,
                gm.body, gm.message_type, gm.operator_name, gm.department,
                gm.sent_at, gm.read_at, gm.attachment_url, gm.attachment_name,
                gm.attachment_mime_type, gm.audio_transcript, gm.ack_status,
                gm.source, gm.unit_id, gm.uazapi_instance_id,
                gc.name AS contact_name,
                c.name  AS client_name,
                co.nome_fantasia AS unit_name,
                co.razao_social  AS unit_legal_name,
                uwc.label        AS instance_label,
                ht.body_text   AS template_body,
                ht.header_text AS template_header,
                ht.footer_text AS template_footer,
                ht.category    AS template_category,
                ht.status      AS template_status,
                gfu.file_size  AS attachment_size
         FROM gotalk_messages gm
         LEFT JOIN gotalk_contacts gc ON gc.id = gm.gotalk_contact_id
         LEFT JOIN clients c ON c.id = gm.client_id
         LEFT JOIN companies co ON co.id = gm.unit_id
         LEFT JOIN unit_whatsapp_credentials uwc
           ON uwc.unit_id = gm.unit_id AND uwc.uazapi_instance_id = gm.uazapi_instance_id
         LEFT JOIN gotalk_hsm_templates ht
           ON gm.message_type = 'TEMPLATE' AND ht.template_name = gm.attachment_name
         LEFT JOIN gotalk_file_uploads gfu ON gfu.gotalk_message_id = gm.id::text
         WHERE ${phoneKeySql} = $1
         ORDER BY gm.sent_at DESC NULLS LAST
         LIMIT $2 OFFSET $3`,
        [phoneKey, limit, offset]
      );

      const countRow = await pool.query(
        `SELECT COUNT(*) FROM gotalk_messages gm
         WHERE ${phoneKeySql} = $1`,
        [phoneKey]
      );

      res.json({ data: dataRows.rows, total: parseInt(countRow.rows[0].count, 10) });
    } catch (err) {
      console.error('[Gotalk] GET /messages/by-phone error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/chatbot-menus — proxy para GET /menu/channel/:channelId na API GoTalk
  // Retorna os menus do chatbot configurados no canal.
  router.get('/chatbot-menus', async (req, res) => {
    try {
      const channelId = await getChannelId();
      if (!channelId) return res.status(503).json({ error: 'GoTalk não autenticado ou channelId indisponível.' });

      const apiRes = await gotalkFetch(`/menu/channel/${channelId}`);
      if (!apiRes.ok) {
        const text = await apiRes.text();
        return res.status(apiRes.status).json({ error: `GoTalk API: ${apiRes.status} ${text}` });
      }

      const data = await apiRes.json();
      res.json(data);
    } catch (err) {
      console.error('[Gotalk] GET /chatbot-menus error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/messages/mark-read
  router.post('/messages/mark-read', async (req, res) => {
    try {
      const { contactId, clientId, phone } = req.body;
      if (!contactId && !clientId && !phone) {
        return res.status(400).json({ error: 'contactId, clientId ou phone obrigatório.' });
      }
      let result;
      if (contactId) {
        result = await pool.query(
          `UPDATE gotalk_messages SET read_at = NOW()
           WHERE gotalk_contact_id = $1 AND direction = 'IN' AND read_at IS NULL`,
          [contactId]
        );
      } else if (clientId) {
        result = await pool.query(
          `UPDATE gotalk_messages SET read_at = NOW()
           WHERE client_id = $1 AND direction = 'IN' AND read_at IS NULL`,
          [clientId]
        );
      } else {
        const norm = normalizePhone(String(phone));
        const last10 = norm.slice(-10);
        result = await pool.query(
          `UPDATE gotalk_messages SET read_at = NOW()
           WHERE RIGHT(REGEXP_REPLACE(phone_number, '[^0-9]', '', 'g'), 10) = $1
             AND direction = 'IN' AND read_at IS NULL`,
          [last10]
        );
      }
      res.json({ success: true, updated: result.rowCount });
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/messages/:clientId (task-spec path)
  // Returns merged timeline: local stored messages + live Gotalk messages, deduped and sorted.
  router.get('/messages/:clientId', async (req, res) => {
    try {
      const { clientId } = req.params;
      const limit = Math.min(200, parseInt(req.query.limit || '100', 10));
      const offset = parseInt(req.query.offset || '0', 10);

      const localResult = await pool.query(
        `SELECT gm.*, gm.audio_transcript AS transcription, gc.name AS contact_name,
                gfu.file_size AS attachment_size
         FROM gotalk_messages gm
         LEFT JOIN gotalk_contacts gc ON gc.id = gm.gotalk_contact_id
         LEFT JOIN gotalk_file_uploads gfu ON gfu.gotalk_message_id = gm.id::text
         WHERE gm.client_id = $1 ORDER BY gm.sent_at ASC NULLS LAST LIMIT $2 OFFSET $3`,
        [clientId, limit, offset]
      );
      const countRes = await pool.query(
        `SELECT COUNT(*) FROM gotalk_messages WHERE client_id = $1`, [clientId]
      );

      // Fetch live Gotalk messages for linked contact and merge into unified timeline
      let merged = [...localResult.rows];
      const localIds = new Set(localResult.rows.map(r => r.gotalk_message_id).filter(Boolean));

      // Prefer lookup via gotalk_contact_id stored on the client (persists after phone changes).
      // Fallback to gotalk_contacts.client_id if clients.gotalk_contact_id is not yet set.
      let resolvedGotalkId = null;
      const clientGotalkRow = await pool.query(
        `SELECT c.gotalk_contact_id, gc.gotalk_id
         FROM clients c
         LEFT JOIN gotalk_contacts gc ON gc.id::text = c.gotalk_contact_id
         WHERE c.id = $1 LIMIT 1`, [clientId]
      );
      if (clientGotalkRow.rows.length > 0 && clientGotalkRow.rows[0].gotalk_id) {
        resolvedGotalkId = clientGotalkRow.rows[0].gotalk_id;
      } else {
        const fallbackRow = await pool.query(
          `SELECT gotalk_id FROM gotalk_contacts WHERE client_id = $1 LIMIT 1`, [clientId]
        );
        if (fallbackRow.rows.length > 0) resolvedGotalkId = fallbackRow.rows[0].gotalk_id;
      }

      if (resolvedGotalkId) {
        try {
          const apiRes = await gotalkFetch(`/attendance/contact/${resolvedGotalkId}`);
          if (apiRes.ok) {
            const data = await apiRes.json();
            const liveMsgs = Array.isArray(data) ? data : (data.messages || data.data || []);
            for (const msg of liveMsgs) {
              const lid = msg._id || msg.id;
              if (lid && !localIds.has(lid)) {
                merged.push({
                  gotalk_message_id: lid,
                  body: msg.body || msg.message || msg.text || '',
                  direction: msg.fromMe ? 'OUT' : 'IN',
                  message_type: 'TEXT',
                  sent_at: msg.timestamp ? new Date(msg.timestamp * 1000) : null,
                  source: 'live',
                });
              }
            }
          }
        } catch (_err) { /* live fetch is best-effort */ }
      }

      // Sort unified timeline by sent_at ascending
      merged.sort((a, b) => {
        const ta = a.sent_at ? new Date(a.sent_at).getTime() : 0;
        const tb = b.sent_at ? new Date(b.sent_at).getTime() : 0;
        return ta - tb;
      });

      res.json({ data: merged, total: parseInt(countRes.rows[0].count, 10) });
    } catch (err) {
      console.error('GET /gotalk/messages/:clientId error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/sync-attendance — manually sync messages for a GoTalk attendance session
  // Used when the attendance was created via GoTalk web UI (not our CRM) and we have the ID.
  // Body: { attendanceId, contactId?, phone?, channel_uuid? }
  router.post('/sync-attendance', async (req, res) => {
    try {
      const { attendanceId, contactId, phone: phoneOverride, channel_uuid: channelUuid } = req.body;
      if (!attendanceId) return res.status(400).json({ error: 'attendanceId é obrigatório.' });

      const defaultChannelId = await getChannelId();

      // Resolve contact (optional — we can sync without it)
      let contact = null;
      if (contactId) {
        contact = await resolveContact(pool, contactId);
      }

      let phone = phoneOverride || contact?.phone_number || null;
      if (phone && !phone.startsWith('55')) phone = '55' + phone;
      // Resolve channel_id from DB UUID if provided, else fall back to contact's stored channel_id
      const resolvedByUuid = channelUuid ? await resolveChannelIdByUuid(pool, channelUuid) : null;
      const channelId = resolvedByUuid || contact?.channel_id || defaultChannelId;

      // Upsert attendance record so the poller picks it up automatically going forward
      if (contact) {
        await pool.query(
          `INSERT INTO gotalk_attendances
             (gotalk_attendance_id, gotalk_contact_id, client_id, status, started_at, updated_at)
           VALUES ($1, $2, $3, 'open', NOW(), NOW())
           ON CONFLICT (gotalk_attendance_id) DO UPDATE SET updated_at = NOW()`,
          [attendanceId, contact.id, contact.client_id || null]
        );
      }

      // Fetch messages from GoTalk
      const apiRes = await gotalkFetch('/message/load_messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          attendance: { _id: attendanceId, clientNumber: phone, channelId },
        }),
      });

      if (!apiRes.ok) {
        const text = await apiRes.text();
        return res.status(apiRes.status).json({ error: `GoTalk: ${text}` });
      }

      const data = await apiRes.json();
      const messages = Array.isArray(data) ? data : (data.messages || data.data || []);

      let saved = 0;
      let skipped = 0;
      const dbClient = await pool.connect();
      try {
        for (const msg of messages) {
          const msgId = msg._id || msg.id;
          if (!msgId) continue;

          const dup = await dbClient.query(
            `SELECT id FROM gotalk_messages WHERE gotalk_message_id = $1`, [msgId]
          );
          if (dup.rows.length > 0) { skipped++; continue; }

          const fromMe = msg.fromMe === true || msg.direction === 'OUT';
          const direction = fromMe ? 'OUT' : 'IN';
          const body = msg.body || msg.text || msg.caption || '';
          const ts = msg.timestamp;
          const sentAt = ts
            ? new Date(typeof ts === 'number' && ts < 1e12 ? ts * 1000 : ts)
            : new Date();

          const waMsgType = (msg.type || 'chat').toLowerCase();
          let messageType = 'TEXT';
          if (waMsgType === 'image') messageType = 'IMAGE';
          else if (waMsgType === 'audio' || waMsgType === 'ptt') messageType = 'AUDIO';
          else if (waMsgType === 'document') messageType = 'DOCUMENT';
          else if (waMsgType === 'video') messageType = 'VIDEO';

          const ackStatus = direction === 'OUT' ? (typeof msg.ack === 'number' ? Math.min(msg.ack, 3) : 1) : null;
          const normPhone = phone ? phone.replace(/^55/, '') : null;

          await dbClient.query(
            `INSERT INTO gotalk_messages
               (gotalk_message_id, gotalk_contact_id, client_id, phone_number,
                direction, body, message_type, attachment_url, attachment_name, attachment_mime_type,
                ack_status, sent_at)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
            [
              msgId, contact?.id || null, contact?.client_id || null, normPhone,
              direction, body, messageType,
              msg.mediaUrl || msg.url || null,
              msg.fileName || null,
              msg.mimetype || null,
              ackStatus, sentAt,
            ]
          );
          saved++;
        }
      } finally { dbClient.release(); }

      console.log(`[Gotalk] sync-attendance ${attendanceId}: ${saved} salvas, ${skipped} já existiam.`);
      res.json({ success: true, total: messages.length, saved, skipped });
    } catch (err) {
      console.error('POST /gotalk/sync-attendance error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/sync-by-phone — sync all messages for a contact identified by phone number.
  // Looks up active/recent attendances for the contact and calls /message/load_messages for each.
  // Body: { phone }  — digits only, with or without country code 55.
  router.post('/sync-by-phone', async (req, res) => {
    try {
      const { phone: rawPhone, clientId: forceClientId, channel_uuid: channelUuid } = req.body;
      if (!rawPhone) return res.status(400).json({ error: 'phone é obrigatório.' });

      const norm = normalizePhone(rawPhone);
      if (!norm) return res.status(400).json({ error: 'Telefone inválido.' });

      const phone55 = norm.startsWith('55') ? norm : ('55' + norm);
      const last10 = norm.slice(-10);
      const channelId = await resolveChannelIdByUuid(pool, channelUuid);

      // ── Step 1: resolve gotalk_contacts row ──────────────────────────────
      let contactRow = null;
      const contactRes = await pool.query(
        `SELECT * FROM gotalk_contacts WHERE RIGHT(COALESCE(phone_number,''), 10) = $1 LIMIT 1`,
        [last10]
      );
      contactRow = contactRes.rows[0] || null;

      // If no contact record exists yet, create a stub so messages can be stored
      if (!contactRow) {
        const resolvedClientId = forceClientId || (await pool.query(
          `SELECT id FROM clients
           WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''), '[^0-9]','','g'), 10) = $1
              OR RIGHT(REGEXP_REPLACE(COALESCE(phone2,''), '[^0-9]','','g'), 10) = $1
           LIMIT 1`,
          [last10]
        )).rows[0]?.id || null;
        const insRes = await pool.query(
          `INSERT INTO gotalk_contacts (gotalk_id, phone_number, channel_id, client_id, imported_at)
           VALUES ($1, $2, $3, $4, NOW())
           ON CONFLICT DO NOTHING RETURNING *`,
          [`wh_${phone55}`, norm, channelId, resolvedClientId]
        );
        contactRow = insRes.rows[0] || null;
        if (!contactRow) {
          const retry = await pool.query(
            `SELECT * FROM gotalk_contacts WHERE RIGHT(COALESCE(phone_number,''), 10) = $1 LIMIT 1`,
            [last10]
          );
          contactRow = retry.rows[0] || null;
        }
      }

      if (!contactRow) {
        return res.status(404).json({ error: 'Não foi possível localizar ou criar o contato para este telefone.' });
      }

      // ── Step 1b: if a clientId was forced, ensure bidirectional link ──────
      if (forceClientId && contactRow) {
        // Unlink any previous gotalk_contact that was bound to this client
        // (phone number changed — the old contact must be detached)
        await pool.query(
          `UPDATE gotalk_contacts SET client_id = NULL
           WHERE client_id = $1 AND id != $2`,
          [forceClientId, contactRow.id]
        );
        // Link the new contact to this client (both directions)
        await pool.query(
          `UPDATE gotalk_contacts SET client_id = $1 WHERE id = $2`,
          [forceClientId, contactRow.id]
        );
        await pool.query(
          `UPDATE clients SET gotalk_contact_id = $1 WHERE id = $2`,
          [contactRow.id, forceClientId]
        );
        // Assign all messages stored under this contact to the client
        await pool.query(
          `UPDATE gotalk_messages SET client_id = $1
           WHERE gotalk_contact_id = $2 AND (client_id IS NULL OR client_id != $1)`,
          [forceClientId, contactRow.id]
        );
      }

      // ── Step 2: gather attendance IDs from multiple tables (phone-centric) ─
      // gotalk_attendances: linked via gotalk_contact_id (UUID FK to gotalk_contacts)
      const [attByContact, attByOpPhone, attByHistory] = await Promise.all([
        pool.query(
          `SELECT gotalk_attendance_id FROM gotalk_attendances
           WHERE gotalk_contact_id = $1
             AND (status != 'closed' OR updated_at > NOW() - INTERVAL '7 days')
           ORDER BY updated_at DESC LIMIT 20`,
          [contactRow.id]
        ),
        // gotalk_operator_attendances: has client_number column (phone digits)
        pool.query(
          `SELECT gotalk_attendance_id FROM gotalk_operator_attendances
           WHERE RIGHT(COALESCE(client_number,''), 10) = $1
             AND (status != 'closed' OR updated_at > NOW() - INTERVAL '7 days')
           ORDER BY updated_at DESC LIMIT 20`,
          [last10]
        ),
        // gotalk_attendance_history: stores full history with client_number
        pool.query(
          `SELECT gotalk_attendance_id FROM gotalk_attendance_history
           WHERE RIGHT(COALESCE(client_number,''), 10) = $1
           ORDER BY updated_at DESC LIMIT 20`,
          [last10]
        ),
      ]);

      // Deduplicate attendance IDs across all sources
      const seenIds = new Set();
      const attendanceIds = [];
      for (const row of [
        ...attByContact.rows,
        ...attByOpPhone.rows,
        ...attByHistory.rows,
      ]) {
        if (row.gotalk_attendance_id && !seenIds.has(row.gotalk_attendance_id)) {
          seenIds.add(row.gotalk_attendance_id);
          attendanceIds.push(row.gotalk_attendance_id);
        }
      }

      // ── Step 3: message import helper ────────────────────────────────────
      let totalSaved = 0;
      let totalSkipped = 0;

      const importMsgs = async (attendanceId) => {
        try {
          const apiRes = await gotalkFetch('/message/load_messages', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ attendance: { _id: attendanceId, clientNumber: phone55, channelId } }),
          });
          if (!apiRes.ok) return;
          const data = await apiRes.json();
          const msgs = Array.isArray(data) ? data : (data.messages || data.data || []);
          const dbClient = await pool.connect();
          try {
            for (const msg of msgs) {
              const msgId = msg._id || msg.id;
              if (!msgId) continue;
              const dup = await dbClient.query(
                `SELECT id FROM gotalk_messages WHERE gotalk_message_id = $1`, [msgId]
              );
              if (dup.rows.length > 0) { totalSkipped++; continue; }
              const dir = (msg.fromMe === true || msg.direction === 'OUT') ? 'OUT' : 'IN';
              const ts = msg.timestamp;
              const sentAt = ts ? new Date(typeof ts === 'number' && ts < 1e12 ? ts * 1000 : ts) : new Date();
              const waMsgType = (msg.type || 'chat').toLowerCase();
              let messageType = 'TEXT';
              if (waMsgType === 'image') messageType = 'IMAGE';
              else if (waMsgType === 'audio' || waMsgType === 'ptt') messageType = 'AUDIO';
              else if (waMsgType === 'document') messageType = 'DOCUMENT';
              else if (waMsgType === 'video') messageType = 'VIDEO';
              const ackStatus = dir === 'OUT' ? (typeof msg.ack === 'number' ? Math.min(msg.ack, 3) : 1) : null;
              try {
                await dbClient.query(
                  `INSERT INTO gotalk_messages
                     (gotalk_message_id, gotalk_contact_id, client_id, phone_number,
                      direction, body, message_type, attachment_url, attachment_name,
                      attachment_mime_type, ack_status, sent_at)
                   VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
                   ON CONFLICT (gotalk_message_id) DO NOTHING`,
                  [
                    msgId, contactRow.id, contactRow.client_id || null, norm,
                    dir, msg.body || msg.text || msg.caption || '', messageType,
                    msg.mediaUrl || msg.url || null, msg.fileName || null, msg.mimetype || null,
                    ackStatus, sentAt,
                  ]
                );
                totalSaved++;
              } catch (rowErr) {
                if (!rowErr.message.includes('unique') && !rowErr.message.includes('duplicate')) {
                  console.warn('[sync-by-phone] rowErr:', rowErr.message);
                }
              }
            }
          } finally { dbClient.release(); }
        } catch (err) {
          console.warn('[sync-by-phone] Erro ao importar mensagens de atendimento:', err.message);
        }
      };

      let totalAttendances = attendanceIds.length;
      if (attendanceIds.length > 0) {
        for (const atId of attendanceIds) {
          await importMsgs(atId);
        }
      } else {
        // No local attendance records — try GoTalk API directly.
        // Use the real gotalk_id when available; fall back to a phone-number search.
        const gotalkId = contactRow.gotalk_id && !contactRow.gotalk_id.startsWith('wh_')
          ? contactRow.gotalk_id : null;
        try {
          const remoteUrl = gotalkId
            ? `/attendance/contact/${gotalkId}`
            : `/attendance/phone/${phone55}`;
          const aRes = await gotalkFetch(remoteUrl);
          if (aRes.ok) {
            const adata = await aRes.json();
            const atList = Array.isArray(adata) ? adata : (adata.attendances || adata.data || []);
            const remoteBatch = atList.slice(0, 10);
            totalAttendances = remoteBatch.length; // report remote count
            for (const at of remoteBatch) {
              const atId = at._id || at.id;
              if (atId) await importMsgs(atId);
            }
          }
        } catch (_) {}
      }

      console.log(`[Gotalk] sync-by-phone ${norm}: ${totalSaved} salvas, ${totalSkipped} já existiam. Atendimentos: ${totalAttendances}`);
      res.json({ success: true, saved: totalSaved, skipped: totalSkipped, attendances: totalAttendances });
    } catch (err) {
      console.error('POST /gotalk/sync-by-phone error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/client/:clientId — get linked Gotalk contact info for a CRM client
  // Priority: clients.gotalk_contact_id (explicit link) → gotalk_contacts.client_id (fallback)
  router.get('/client/:clientId', async (req, res) => {
    try {
      const { clientId } = req.params;
      // Prefer the contact explicitly recorded on the client row (set during phone sync)
      const result = await pool.query(
        `SELECT gc.*, c.name AS client_name, c.phone AS client_phone
         FROM clients c
         JOIN gotalk_contacts gc ON gc.id::text = c.gotalk_contact_id
         WHERE c.id = $1
         UNION ALL
         SELECT gc.*, c.name AS client_name, c.phone AS client_phone
         FROM gotalk_contacts gc
         JOIN clients c ON c.id = gc.client_id
         WHERE gc.client_id = $1
           AND NOT EXISTS (
             SELECT 1 FROM clients cx WHERE cx.id = $1 AND cx.gotalk_contact_id IS NOT NULL
           )
         LIMIT 1`,
        [clientId]
      );
      if (!result.rows.length) {
        return res.json({ linked: false, contact: null });
      }
      const msgRes = await pool.query(
        `SELECT body, direction, message_type, sent_at FROM gotalk_messages
         WHERE client_id = $1 ORDER BY sent_at DESC LIMIT 1`, [clientId]
      );
      res.json({ linked: true, contact: result.rows[0], lastMessage: msgRes.rows[0] || null });
    } catch (err) {
      console.error('GET /gotalk/client/:id error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/client/:clientId/sync-phone — link single client by phone match
  router.post('/client/:clientId/sync-phone', async (req, res) => {
    try {
      const { clientId } = req.params;
      const clientRow = await pool.query(`SELECT id, phone, phone2 FROM clients WHERE id = $1`, [clientId]);
      if (!clientRow.rows.length) return res.status(404).json({ error: 'Cliente não encontrado.' });
      const client = clientRow.rows[0];
      const phones = [client.phone, client.phone2].filter(Boolean);
      if (!phones.length) return res.status(400).json({ error: 'Cliente sem telefone cadastrado.' });

      const result2 = await linkClientRetroactively(pool, clientId, phones[0] || null, phones[1] || null);

      if (result2) {
        res.json({ success: true, message: 'Vinculado com sucesso por telefone.' });
      } else {
        res.json({ success: false, message: 'Nenhum contato Gotalk com telefone correspondente encontrado.' });
      }
    } catch (err) {
      console.error('POST /gotalk/client/:id/sync-phone error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/conversations — list ALL contacts with messages (linked + unlinked)
  // Groups by gotalk_contact so every contact appears regardless of CRM link status.
  // Returns camelCase fields to match frontend expectations.
  // Optional query params: search (text), limit (number), channel_uuid (UUID of gotalk_channels row)
  router.get('/conversations', async (req, res) => {
    try {
      const limit = Math.min(500, parseInt(req.query.limit || '200', 10));
      const search = (req.query.search || '').trim();
      const channelUuid = (req.query.channel_uuid || '').trim() || null;

      const params = [limit];
      let paramIdx = 2;
      const conditions = [];

      if (search) {
        conditions.push(`(gc.name ILIKE $${paramIdx} OR gc.phone_number ILIKE $${paramIdx} OR cl.name ILIKE $${paramIdx})`);
        params.push(`%${search}%`);
        paramIdx++;
      }
      if (channelUuid) {
        conditions.push(`gc.gotalk_channel_uuid = $${paramIdx}`);
        params.push(channelUuid);
        paramIdx++;
      }
      const whereClause = conditions.length > 0 ? `AND ${conditions.join(' AND ')}` : '';

      const result = await pool.query(
        `SELECT
           gc.id                        AS "contactId",
           gc.gotalk_id                 AS "gotalkId",
           gc.client_id                 AS "clientId",
           gc.gotalk_channel_uuid       AS "channelUuid",
           MAX(cl.name)                 AS "clientName",
           MAX(gc.name)                 AS "contactName",
           MAX(gc.phone_number)         AS "phone",
           MAX(ch.name)                 AS "channelName",
           MAX(ch.phone_number)         AS "channelPhone",
           MAX(COALESCE(co.nome_fantasia, co.razao_social)) AS "unitName",
           (SELECT body FROM gotalk_messages m2 WHERE m2.gotalk_contact_id = gc.id ORDER BY sent_at DESC NULLS LAST, id DESC LIMIT 1) AS "lastBody",
           (SELECT direction = 'OUT' FROM gotalk_messages m3 WHERE m3.gotalk_contact_id = gc.id ORDER BY sent_at DESC NULLS LAST, id DESC LIMIT 1) AS "lastFromMe",
           MAX(gm.sent_at)              AS "lastSentAt",
           COUNT(CASE WHEN gm.read_at IS NULL AND gm.direction = 'IN' THEN 1 END)::int AS unread
         FROM gotalk_contacts gc
         LEFT JOIN gotalk_messages gm ON gm.gotalk_contact_id = gc.id
         LEFT JOIN clients cl ON cl.id = gc.client_id
         LEFT JOIN gotalk_channels ch ON ch.id = gc.gotalk_channel_uuid
         LEFT JOIN companies co ON co.id = ch.unit_id
         WHERE 1=1 ${whereClause}
         GROUP BY gc.id, gc.client_id, gc.gotalk_channel_uuid
         HAVING MAX(gm.sent_at) IS NOT NULL
         ORDER BY MAX(gm.sent_at) DESC NULLS LAST
         LIMIT $1`,
        params
      );
      res.json({ data: result.rows });
    } catch (err) {
      console.error('GET /gotalk/conversations error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/contact-by-id/:contactId — get a gotalk_contact row by local UUID
  router.get('/contact-by-id/:contactId', async (req, res) => {
    try {
      const { contactId } = req.params;
      const result = await pool.query(
        `SELECT gc.*, c.name AS client_name
         FROM gotalk_contacts gc
         LEFT JOIN clients c ON c.id = gc.client_id
         WHERE gc.id = $1 LIMIT 1`,
        [contactId]
      );
      if (!result.rows.length) return res.status(404).json({ error: 'Contato não encontrado.' });
      res.json(result.rows[0]);
    } catch (err) {
      console.error('GET /gotalk/contact-by-id error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // ── File serving endpoint ──────────────────────────────────────────────────────

  // GET /api/gotalk/media/:messageId — proxy CDN media through CRM server.
  // 🔒 SEGURANÇA [VULN-12]: requer autenticação. Imagens/anexos são carregados via
  // <img src>/<a href> same-origin, que enviam o cookie de sessão automaticamente.
  // Caches content in gotalk_file_uploads on first fetch. Add ?download=1 for attachment mode.
  router.get('/media/:messageId', requireAuth, async (req, res) => {
    try {
      const { messageId } = req.params;
      const forceDownload = req.query.download === '1';

      // 1. Look up the message
      const msgResult = await pool.query(
        `SELECT id, attachment_url, attachment_name, attachment_mime_type, gotalk_message_id
         FROM gotalk_messages WHERE id = $1`,
        [messageId]
      );
      if (!msgResult.rows.length) return res.status(404).json({ error: 'Mensagem não encontrada.' });

      const msg = msgResult.rows[0];
      if (!msg.attachment_url) return res.status(404).json({ error: 'Mensagem sem anexo.' });

      const mimeType = msg.attachment_mime_type || 'application/octet-stream';

      // Ensure fileName always carries an extension for correct browser download behaviour
      const rawName  = msg.attachment_name || `media-${messageId}`;
      const fileName = (() => {
        if (rawName.includes('.')) return rawName;
        const mimeExtMap = {
          'image/jpeg': '.jpg', 'image/png': '.png', 'image/gif': '.gif', 'image/webp': '.webp',
          'audio/mpeg': '.mp3', 'audio/wav': '.wav', 'audio/ogg': '.ogg', 'audio/mp4': '.m4a',
          'video/mp4': '.mp4', 'video/webm': '.webm', 'video/ogg': '.ogv',
          'application/pdf': '.pdf',
          'application/msword': '.doc',
          'application/vnd.openxmlformats-officedocument.wordprocessingml.document': '.docx',
          'application/vnd.ms-excel': '.xls',
          'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': '.xlsx',
        };
        const ext = mimeExtMap[mimeType.split(';')[0].trim()] || '';
        return rawName + ext;
      })();
      const disposition = forceDownload ? `attachment; filename="${fileName}"` : `inline; filename="${fileName}"`;

      // 2. Check cache by internal message UUID
      const cacheResult = await pool.query(
        `SELECT file_data, mime_type, file_name FROM gotalk_file_uploads WHERE gotalk_message_id = $1`,
        [messageId]
      );

      if (cacheResult.rows.length) {
        const cached = cacheResult.rows[0];
        const buffer = Buffer.from(cached.file_data, 'base64');
        res.setHeader('Content-Type', cached.mime_type);
        res.setHeader('Content-Disposition', `${forceDownload ? 'attachment' : 'inline'}; filename="${cached.file_name}"`);
        res.setHeader('Cache-Control', 'public, max-age=604800');
        res.setHeader('Content-Length', buffer.length);
        return res.send(buffer);
      }

      // 3. Fetch from GoTalk CDN
      const fetch = (await import('node-fetch')).default;
      const cdnRes = await fetch(msg.attachment_url, { timeout: 30000 });
      if (!cdnRes.ok) {
        return res.status(502).json({ error: `CDN respondeu ${cdnRes.status}` });
      }

      const arrayBuf = await cdnRes.arrayBuffer();
      const buffer = Buffer.from(arrayBuf);
      const base64 = buffer.toString('base64');
      const detectedMime = cdnRes.headers.get('content-type') || mimeType;
      const fileSize = buffer.length;

      // 4. Save to cache
      try {
        await pool.query(
          `INSERT INTO gotalk_file_uploads (file_name, mime_type, file_size, file_data, gotalk_message_id)
           VALUES ($1, $2, $3, $4, $5)
           ON CONFLICT (gotalk_message_id) DO NOTHING`,
          [fileName, detectedMime, fileSize, base64, messageId]
        );
      } catch (cacheErr) {
        // Cache failure is non-fatal — still serve the file
        console.warn('[GoTalk Media] Cache write error:', cacheErr.message);
      }

      res.setHeader('Content-Type', detectedMime);
      res.setHeader('Content-Disposition', disposition);
      res.setHeader('Cache-Control', 'public, max-age=604800');
      res.setHeader('Content-Length', buffer.length);
      res.send(buffer);
    } catch (err) {
      console.error('GET /gotalk/media/:messageId error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/files/:fileId — serves uploaded files; requires authenticated user.
  // extractUser runs via the parent app.use('/api/gotalk', extractUser, ...) registration.
  // /api/gotalk/files is NOT listed in publicPaths, so JWT is always decoded before this route.
  // Files are stored indefinitely — no expiry.
  router.get('/files/:fileId', requireAuth, async (req, res) => {
    try {
      const { fileId } = req.params;
      const result = await pool.query(
        `SELECT file_name, mime_type, file_data FROM gotalk_file_uploads WHERE id = $1`,
        [fileId]
      );
      if (!result.rows.length) return res.status(404).json({ error: 'Arquivo não encontrado.' });

      const { file_name, mime_type, file_data } = result.rows[0];
      const buffer = Buffer.from(file_data, 'base64');
      res.setHeader('Content-Type', mime_type);
      res.setHeader('Content-Disposition', `inline; filename="${file_name}"`);
      res.setHeader('Cache-Control', 'public, max-age=86400');
      res.setHeader('Content-Length', buffer.length);
      res.send(buffer);
    } catch (err) {
      console.error('GET /gotalk/files/:fileId error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/gotalk/operators — list all GoTalk operators with CRM collaborator link ──
  router.get('/operators', async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT
           go.id,
           go.gotalk_operator_id,
           go.name,
           go.email,
           go.phone,
           go.active,
           go.collaborator_id,
           go.imported_at,
           go.updated_at,
           co.name AS collaborator_name
         FROM gotalk_operators go
         LEFT JOIN collaborators co ON co.id = go.collaborator_id
         ORDER BY go.active DESC, go.name ASC NULLS LAST`
      );
      res.json({ data: result.rows });
    } catch (err) {
      console.error('GET /gotalk/operators error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/operators/:id/link-collaborator — manually link operator to CRM collaborator
  router.post('/operators/:id/link-collaborator', async (req, res) => {
    try {
      const { id } = req.params;
      const { collaboratorId } = req.body;
      if (!collaboratorId) return res.status(400).json({ error: 'collaboratorId é obrigatório.' });
      await validateReferenceIds(pool, req.body, [['collaboratorId', 'collaborators', 'Colaborador']]);
      await pool.query(
        `UPDATE gotalk_operators SET collaborator_id = $1, updated_at = NOW() WHERE id = $2`,
        [collaboratorId, id]
      );
      res.json({ success: true });
    } catch (err) {
      console.error('POST /gotalk/operators/:id/link-collaborator error:', err.message);
      res.status(err.statusCode || 500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/operators/:id/unlink-collaborator — remove collaborator link from operator
  router.post('/operators/:id/unlink-collaborator', async (req, res) => {
    try {
      const { id } = req.params;
      await pool.query(
        `UPDATE gotalk_operators SET collaborator_id = NULL, updated_at = NOW() WHERE id = $1`,
        [id]
      );
      res.json({ success: true });
    } catch (err) {
      console.error('POST /gotalk/operators/:id/unlink-collaborator error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/gotalk/attendances/clients-with-history — returns array of clientIds that have GoTalk attendances ──
  router.get('/attendances/clients-with-history', async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT DISTINCT client_id FROM gotalk_attendances WHERE client_id IS NOT NULL`
      );
      res.json({ clientIds: result.rows.map(r => r.client_id) });
    } catch (err) {
      console.error('GET /gotalk/attendances/clients-with-history error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/gotalk/attendances — filterable list of attendance sessions ──────
  // Filters: clientId, collaboratorId, operatorId (gotalk), type (CLIENT|BANK),
  //          dateFrom, dateTo, status, unitId (UUID of companies.id), page, limit
  router.get('/attendances', async (req, res) => {
    try {
      const {
        clientId,
        collaboratorId,
        operatorId,
        type,
        status,
        dateFrom,
        dateTo,
        unitId,
      } = req.query;

      // Access control for unitId filter
      const user = req.currentUser;
      const isAdmin = user?.isAdmin === true;
      const allowedUnitIds = Array.isArray(user?.allowedUnitIds) ? user.allowedUnitIds : [];

      const page  = Math.max(1, parseInt(req.query.page  || '1',   10));
      const limit = Math.min(200, Math.max(1, parseInt(req.query.limit || '50', 10)));
      const offset = (page - 1) * limit;

      const params  = [];
      const conds   = [];

      if (clientId) {
        params.push(clientId);
        conds.push(`ga.client_id = $${params.length}`);
      }
      if (collaboratorId) {
        params.push(collaboratorId);
        // Match via resolved operator_id FK **or** via gotalk_operator_id string
        // (covers attendances imported before the operator was linked to a collaborator)
        conds.push(`(go.collaborator_id = $${params.length}
          OR ga.gotalk_operator_id IN (
            SELECT gotalk_operator_id FROM gotalk_operators WHERE collaborator_id = $${params.length}
          ))`);
      }
      if (operatorId) {
        params.push(operatorId);
        conds.push(`ga.gotalk_operator_id = $${params.length}`);
      }
      if (type) {
        params.push(type.toUpperCase());
        conds.push(`ga.type = $${params.length}`);
      }
      if (status) {
        params.push(status.toLowerCase());
        conds.push(`ga.status = $${params.length}`);
      }
      if (dateFrom) {
        params.push(new Date(dateFrom));
        conds.push(`ga.started_at >= $${params.length}`);
      }
      if (dateTo) {
        // For date-only inputs (e.g. "2024-01-15"), treat as end-of-day so same-day
        // records are included; for ISO datetime strings, use the exact value provided.
        const dateToVal = /^\d{4}-\d{2}-\d{2}$/.test(dateTo)
          ? new Date(dateTo + 'T23:59:59.999Z')
          : new Date(dateTo);
        params.push(dateToVal);
        conds.push(`ga.started_at <= $${params.length}`);
      }
      // Non-admin default scoping in standalone mode (no fixed clientId/collaboratorId).
      // Existing client-fixed callers always supply clientId so this block is skipped,
      // preserving current behaviour for LegalPanel / CollectionCoordinatorPanel /
      // AdmissionFormView.
      if (!isAdmin && !clientId && !collaboratorId) {
        if (allowedUnitIds.length === 0) {
          return res.json({ data: [], total: 0, page: 1, totalPages: 0 });
        }
        if (!unitId) {
          // No explicit unit requested → scope to all user's allowed units.
          params.push(allowedUnitIds);
          conds.push(`gch.unit_id = ANY($${params.length})`);
        }
        // If unitId IS provided, the block below validates and applies it.
      }
      if (unitId) {
        const UUID_RE_LOCAL = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        if (!UUID_RE_LOCAL.test(unitId)) {
          return res.status(400).json({ error: 'unitId inválido.' });
        }
        if (!isAdmin && !allowedUnitIds.includes(unitId)) {
          return res.json({ data: [], total: 0, page: 1, totalPages: 0 });
        }
        params.push(unitId);
        conds.push(`gch.unit_id = $${params.length}`);
      }

      const where = conds.length ? `WHERE ${conds.join(' AND ')}` : '';

      const countRes = await pool.query(
        `SELECT COUNT(*)
         FROM gotalk_attendances ga
         LEFT JOIN gotalk_operators go ON go.id = ga.operator_id
         LEFT JOIN gotalk_channels gch ON gch.id = ga.gotalk_channel_uuid
         ${where}`,
        params
      );
      const total = parseInt(countRes.rows[0].count, 10);

      const dataParams = [...params, limit, offset];
      const dataRes = await pool.query(
        `SELECT
           ga.id,
           ga.gotalk_attendance_id,
           ga.status,
           ga.type,
           ga.department,
           ga.subject,
           ga.started_at,
           ga.ended_at,
           ga.client_id,
           ga.gotalk_contact_id,
           ga.operator_id,
           ga.gotalk_operator_id,
           cl.name  AS client_name,
           gc.name  AS contact_name,
           gc.phone_number AS contact_phone,
           go.name  AS operator_name,
           go.collaborator_id,
           co.name  AS collaborator_name,
           COALESCE(gm_agg.message_count, 0) AS message_count,
           gm_agg.last_message_at
         FROM gotalk_attendances ga
         LEFT JOIN clients cl         ON cl.id = ga.client_id
         LEFT JOIN gotalk_contacts gc  ON gc.id = ga.gotalk_contact_id
         LEFT JOIN gotalk_operators go ON go.id = ga.operator_id
         LEFT JOIN collaborators co    ON co.id = go.collaborator_id
         LEFT JOIN gotalk_channels gch ON gch.id = ga.gotalk_channel_uuid
         LEFT JOIN (
           SELECT attendance_id, COUNT(*)::int AS message_count, MAX(sent_at) AS last_message_at
           FROM gotalk_messages
           WHERE attendance_id IS NOT NULL
           GROUP BY attendance_id
         ) gm_agg ON gm_agg.attendance_id = ga.id
         ${where}
         ORDER BY COALESCE(ga.started_at, ga.imported_at) DESC NULLS LAST
         LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
        dataParams
      );

      res.json({
        data: dataRes.rows,
        total,
        page,
        totalPages: Math.ceil(total / limit),
      });
    } catch (err) {
      console.error('GET /gotalk/attendances error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/attendances/:id/messages — messages for a specific attendance session
  router.get('/attendances/:id/messages', async (req, res) => {
    try {
      const { id } = req.params;
      const limit  = Math.min(500, parseInt(req.query.limit  || '200', 10));
      const offset = parseInt(req.query.offset || '0', 10);

      // Verify attendance exists
      const atRes = await pool.query(
        `SELECT ga.*, go.name AS operator_name, cl.name AS client_name,
                gc.name AS contact_name, gc.phone_number AS contact_phone
         FROM gotalk_attendances ga
         LEFT JOIN gotalk_operators go ON go.id = ga.operator_id
         LEFT JOIN clients cl          ON cl.id = ga.client_id
         LEFT JOIN gotalk_contacts gc  ON gc.id = ga.gotalk_contact_id
         WHERE ga.id::text = $1 OR ga.gotalk_attendance_id = $1 LIMIT 1`,
        [id]
      );
      if (!atRes.rows.length) {
        return res.status(404).json({ error: 'Atendimento não encontrado.' });
      }
      const attendance = atRes.rows[0];

      const msgRes = await pool.query(
        `SELECT
           gm.id, gm.gotalk_message_id, gm.direction, gm.body, gm.message_type,
           gm.attachment_url, gm.attachment_name, gm.attachment_mime_type,
           gm.audio_transcript, gm.ack_status, gm.sent_at, gm.read_at,
           gm.operator_name, gm.department
         FROM gotalk_messages gm
         WHERE gm.attendance_id = $1
         ORDER BY gm.sent_at ASC NULLS LAST
         LIMIT $2 OFFSET $3`,
        [attendance.id, limit, offset]
      );

      const countRes = await pool.query(
        `SELECT COUNT(*) FROM gotalk_messages WHERE attendance_id = $1`,
        [attendance.id]
      );

      res.json({
        attendance,
        data: msgRes.rows,
        total: parseInt(countRes.rows[0].count, 10),
      });
    } catch (err) {
      console.error('GET /gotalk/attendances/:id/messages error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/attendances/client/:clientId — shortcut: attendances for a CRM client
  // (without attendance_id association, falls back to messages by client)
  router.get('/attendances/client/:clientId', async (req, res) => {
    try {
      const { clientId } = req.params;
      const type = req.query.type || null;

      const params = [clientId];
      let typeFilter = '';
      if (type) {
        params.push(type.toUpperCase());
        typeFilter = `AND ga.type = $${params.length}`;
      }

      const result = await pool.query(
        `SELECT
           ga.id,
           ga.gotalk_attendance_id,
           ga.status,
           ga.type,
           ga.department,
           ga.subject,
           ga.started_at,
           ga.ended_at,
           ga.gotalk_operator_id,
           go.name  AS operator_name,
           go.collaborator_id,
           co.name  AS collaborator_name,
           gc.name  AS contact_name,
           gc.phone_number AS contact_phone,
           COALESCE(gm_agg.message_count, 0) AS message_count,
           gm_agg.last_message_at
         FROM gotalk_attendances ga
         LEFT JOIN gotalk_operators go ON go.id = ga.operator_id
         LEFT JOIN collaborators co    ON co.id = go.collaborator_id
         LEFT JOIN gotalk_contacts gc  ON gc.id = ga.gotalk_contact_id
         LEFT JOIN (
           SELECT attendance_id, COUNT(*)::int AS message_count, MAX(sent_at) AS last_message_at
           FROM gotalk_messages
           WHERE attendance_id IS NOT NULL
           GROUP BY attendance_id
         ) gm_agg ON gm_agg.attendance_id = ga.id
         WHERE ga.client_id = $1 ${typeFilter}
         ORDER BY COALESCE(ga.started_at, ga.imported_at) DESC NULLS LAST`,
        params
      );

      res.json({ data: result.rows });
    } catch (err) {
      console.error('GET /gotalk/attendances/client/:clientId error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // ── Channel management (multi-channel GoTalk support) ────────────────────
  // Security rule: `channel_id` (GoTalk internal ID) is NEVER returned to the
  // frontend — it is stored server-side only and used for API calls.

  // GET /api/gotalk/channels — list all configured channels (without channel_id)
  router.get('/channels', async (req, res) => {
    try {
      const result = await pool.query(`
        SELECT gc.id, gc.name, gc.phone_number, gc.is_primary, gc.is_active,
               gc.unit_id, c.nome_fantasia AS unit_name, gc.notes,
               gc.created_at, gc.updated_at
        FROM gotalk_channels gc
        LEFT JOIN companies c ON c.id = gc.unit_id
        ORDER BY gc.is_primary DESC, gc.name ASC
      `);
      res.json({ channels: result.rows, total: result.rows.length });
    } catch (err) {
      console.error('[Gotalk] GET /channels error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/channels — create a new channel
  // channel_id is NEVER accepted from the client — it is resolved server-side:
  //   • is_primary=true  → fetched from GoTalk auth (getChannelId)
  //   • is_primary=false → saved as NULL ("pendente") until /discover or /scan-all links it
  router.post('/channels', async (req, res) => {
    try {
      const { name, phone_number, unit_id, is_primary, is_active, notes } = req.body;
      if (!name || typeof name !== 'string' || !name.trim()) {
        return res.status(400).json({ error: 'Campo "name" obrigatório.' });
      }

      let resolvedChannelId = null;

      if (is_primary) {
        // Auto-resolve primary channelId from GoTalk auth (server-side only)
        try {
          resolvedChannelId = await getChannelId();
        } catch (authErr) {
          console.warn('[Gotalk] Canal principal: não foi possível obter channelId do GoTalk:', authErr.message);
        }
        // Unset any previous primary
        await pool.query(`UPDATE gotalk_channels SET is_primary = FALSE WHERE is_primary = TRUE`);
      }

      const result = await pool.query(
        `INSERT INTO gotalk_channels (name, phone_number, channel_id, unit_id, is_primary, is_active, notes)
         VALUES ($1, $2, $3, $4, $5, $6, $7)
         RETURNING id, name, phone_number, is_primary, is_active, unit_id, notes, created_at, updated_at`,
        [
          name.trim(),
          phone_number?.trim() || null,
          resolvedChannelId || null,
          unit_id || null,
          is_primary === true,
          is_active !== false,
          notes?.trim() || null,
        ]
      );
      const isPrimaryLabel = is_primary ? ` (primary, channelId=${resolvedChannelId ?? 'unknown'})` : ' (secondary, pendente)';
      console.log(`[Gotalk] Canal criado: ${name.trim()}${isPrimaryLabel}`);
      res.status(201).json({ channel: result.rows[0] });
    } catch (err) {
      if (err.code === '23505') {
        return res.status(409).json({ error: 'Já existe um canal com esse channel_id GoTalk. Use /discover para verificar.' });
      }
      console.error('[Gotalk] POST /channels error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // PATCH /api/gotalk/channels/:id — update channel metadata
  // Note: channel_id (GoTalk internal ID) cannot be changed here to prevent accidental misconfiguration.
  router.patch('/channels/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const current = await pool.query(`SELECT * FROM gotalk_channels WHERE id = $1`, [id]);
      if (current.rows.length === 0) return res.status(404).json({ error: 'Canal não encontrado.' });
      const ch = current.rows[0];

      const newName      = typeof req.body.name         !== 'undefined' ? String(req.body.name).trim()              : ch.name;
      const newPhone     = typeof req.body.phone_number !== 'undefined' ? (req.body.phone_number?.trim() || null)   : ch.phone_number;
      const newUnitId    = typeof req.body.unit_id      !== 'undefined' ? (req.body.unit_id || null)                : ch.unit_id;
      const newIsPrimary = typeof req.body.is_primary   !== 'undefined' ? Boolean(req.body.is_primary)              : ch.is_primary;
      const newIsActive  = typeof req.body.is_active    !== 'undefined' ? Boolean(req.body.is_active)               : ch.is_active;
      const newNotes     = typeof req.body.notes        !== 'undefined' ? (req.body.notes?.trim() || null)          : ch.notes;

      if (newIsPrimary && !ch.is_primary) {
        await pool.query(`UPDATE gotalk_channels SET is_primary = FALSE WHERE is_primary = TRUE AND id != $1`, [id]);
      }

      const result = await pool.query(
        `UPDATE gotalk_channels
         SET name=$1, phone_number=$2, unit_id=$3, is_primary=$4, is_active=$5, notes=$6, updated_at=NOW()
         WHERE id=$7
         RETURNING id, name, phone_number, is_primary, is_active, unit_id, notes, created_at, updated_at`,
        [newName, newPhone, newUnitId, newIsPrimary, newIsActive, newNotes, id]
      );
      res.json({ channel: result.rows[0] });
    } catch (err) {
      console.error('[Gotalk] PATCH /channels/:id error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/gotalk/channels/:id — remove a channel
  router.delete('/channels/:id', async (req, res) => {
    try {
      const { id } = req.params;
      const result = await pool.query(
        `DELETE FROM gotalk_channels WHERE id = $1 RETURNING id, name, is_primary`,
        [id]
      );
      if (result.rows.length === 0) return res.status(404).json({ error: 'Canal não encontrado.' });
      console.log(`[Gotalk] Canal removido: ${result.rows[0].name}`);
      res.json({ success: true });
    } catch (err) {
      console.error('[Gotalk] DELETE /channels/:id error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/channels/discover — detect the primary channel from GoTalk auth.
  // Returns a SUGGESTION only — does NOT persist anything. Admin must confirm by calling
  // POST /api/gotalk/channels with { is_primary: true } (which auto-fetches the channelId
  // server-side and saves). This two-step flow ensures admin confirmation before saving.
  router.post('/channels/discover', async (req, res) => {
    try {
      const channelId = await getChannelId();
      if (!channelId) {
        return res.status(404).json({ error: 'GoTalk não retornou um channelId. Verifique as credenciais (GOTALK_LOGIN / GOTALK_PASSWORD).' });
      }

      const existing = await pool.query(
        `SELECT id, name, phone_number, is_primary, is_active, unit_id, notes
         FROM gotalk_channels WHERE channel_id = $1`,
        [channelId]
      );

      if (existing.rows.length > 0) {
        return res.json({
          found: true,
          alreadyRegistered: true,
          existingChannel: existing.rows[0],
          message: `Canal primário já registrado como "${existing.rows[0].name}".`,
        });
      }

      // Not registered yet — try to get phone/name from GoTalk channel info
      let suggestedName = 'Canal Principal';
      let suggestedPhone = null;
      try {
        const infoRes = await gotalkFetch(`/channel/${channelId}`);
        if (infoRes.ok) {
          const info = await infoRes.json();
          suggestedName = info.name || info.nome || suggestedName;
          suggestedPhone = info.phoneNumber || info.phone || info.number || null;
        }
      } catch (_) {}

      return res.json({
        found: true,
        alreadyRegistered: false,
        existingChannel: null,
        suggestedName,
        suggestedPhone,
        message: `Canal primário disponível. Confirme o registro clicando em "Salvar canal".`,
      });
    } catch (err) {
      console.error('[Gotalk] POST /channels/discover error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/channels/scan-all — query GoTalk API for all channels and match
  // them with pending channels in our DB (those with channel_id = NULL). Does NOT
  // auto-create new channels — only backfills the channel_id for pending ones.
  // Returns the updated channel list and any unmatched discovered channels as suggestions.
  router.post('/channels/scan-all', async (req, res) => {
    try {
      let discoveredChannels = [];
      const endpointsToTry = ['/channel', '/channel/list', '/channels'];
      for (const ep of endpointsToTry) {
        try {
          const r = await gotalkFetch(ep);
          if (r.ok) {
            const data = await r.json();
            const list = Array.isArray(data) ? data
              : Array.isArray(data.channels) ? data.channels
              : Array.isArray(data.data) ? data.data : [];
            if (list.length > 0) { discoveredChannels = list; break; }
          }
        } catch (_) {}
      }

      let backfilled = 0;
      let created = 0;
      const suggestions = [];

      for (const ch of discoveredChannels) {
        const chId    = ch._id || ch.id || ch.channelId;
        const chPhone = ch.phoneNumber || ch.phone || ch.number || null;
        const chName  = ch.name || ch.nome || `Canal ${chId?.slice(-6) ?? 'desconhecido'}`;
        if (!chId) continue;

        // 1. Already in DB by channel_id? Update name/phone if still missing.
        const byId = await pool.query(`SELECT id, name, phone_number FROM gotalk_channels WHERE channel_id = $1`, [chId]);
        if (byId.rows.length > 0) {
          const row = byId.rows[0];
          if ((!row.name || !row.phone_number) && (chName || chPhone)) {
            await pool.query(
              `UPDATE gotalk_channels SET
                 name = COALESCE(NULLIF(name,''), $1),
                 phone_number = COALESCE(phone_number, $2),
                 updated_at = NOW()
               WHERE id = $3`,
              [chName, chPhone, row.id]
            );
          }
          continue;
        }

        // 2. Pending channel with matching phone? Backfill channel_id.
        if (chPhone) {
          const byPhone = await pool.query(
            `SELECT id FROM gotalk_channels WHERE channel_id IS NULL AND phone_number = $1 LIMIT 2`,
            [chPhone]
          );
          if (byPhone.rows.length === 1) {
            await pool.query(
              `UPDATE gotalk_channels SET channel_id = $1, name = COALESCE(NULLIF(name,''), $2), updated_at = NOW() WHERE id = $3`,
              [chId, chName, byPhone.rows[0].id]
            );
            backfilled++;
            continue;
          }
        }

        // Unmatched — names are presentation only, never channel identity.
        // Admin must confirm by manually creating the channel via POST /api/gotalk/channels.
        suggestions.push({ name: chName, phone: chPhone });
      }

      console.log(`[Gotalk] scan-all: ${backfilled} vinculado(s), ${suggestions.length} sugestão(ões) pendentes.`);
      const allResult = await pool.query(`
        SELECT gc.id, gc.name, gc.phone_number, gc.is_primary, gc.is_active,
               (gc.channel_id IS NOT NULL) AS linked,
               gc.unit_id, c.nome_fantasia AS unit_name, gc.notes, gc.created_at, gc.updated_at
        FROM gotalk_channels gc LEFT JOIN companies c ON c.id = gc.unit_id
        ORDER BY gc.is_primary DESC, gc.name ASC
      `);
      const allChannels = allResult.rows.map(r => ({ ...r, linked: undefined }));

      const message = backfilled > 0
        ? `${backfilled} canal(is) pendente(s) vinculado(s) com sucesso.`
        : discoveredChannels.length === 0
          ? 'A API GoTalk não listou canais disponíveis.'
          : suggestions.length > 0
            ? 'Nenhum canal pendente para vincular. Veja as sugestões abaixo.'
            : 'Todos os canais já estavam registrados.';

      res.json({
        backfilled,
        created: 0,
        message,
        suggestions,
        channels: allChannels,
        total: allChannels.length,
      });
    } catch (err) {
      console.error('[Gotalk] POST /channels/scan-all error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/retrolink — bulk retroactive phone-linking
  // Normalizes phones first, then links all clients with GoTalk contacts by phone.
  // Stores gotalk_contact_id in clients so the link persists after phone changes.
  router.post('/retrolink', async (req, res) => {
    try {
      // Step 1: normalize phone numbers to pure digits (idempotent)
      await pool.query(
        `UPDATE clients SET phone = REGEXP_REPLACE(phone, '[^0-9]', '', 'g')
         WHERE phone IS NOT NULL AND phone ~ '[^0-9]'`
      );
      await pool.query(
        `UPDATE clients SET phone2 = REGEXP_REPLACE(phone2, '[^0-9]', '', 'g')
         WHERE phone2 IS NOT NULL AND phone2 ~ '[^0-9]'`
      );

      // Step 2: retrolink all clients with a phone
      const clientsRes = await pool.query(
        `SELECT id, phone, phone2 FROM clients WHERE phone IS NOT NULL OR phone2 IS NOT NULL`
      );
      let linked = 0;
      for (const c of clientsRes.rows) {
        try {
          const count = await linkClientRetroactively(pool, c.id, c.phone, c.phone2);
          linked += (count || 0);
        } catch (_err) { /* continue */ }
      }
      console.log(`[Gotalk] Retrolink concluído: ${clientsRes.rows.length} clientes processados, ${linked} vínculos criados.`);
      res.json({ success: true, processed: clientsRes.rows.length, linked });
    } catch (err) {
      console.error('POST /gotalk/retrolink error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // ─── POST /gotalk/send-template ──────────────────────────────────────────────
  // Server-side proxy that sends an active-notification (HSM) template via GoTalk.
  // category:"attendance" is always injected server-side per GoTalk Postman docs.
  // Body: { phone, contactName, templateId, variables:{}, channelUuid? }
  router.post('/send-template', async (req, res) => {
    try {
      const { phone, contactName, templateId, variables, channelUuid } = req.body;
      if (!phone || !templateId) {
        return res.status(400).json({ error: 'phone e templateId são obrigatórios.' });
      }

      const channelId = await resolveChannelIdByUuid(pool, channelUuid || null);

      // Normalise phone: ensure leading country-code prefix (55) is present
      const normalised = normalizePhone(String(phone));
      const phoneForGoTalk = normalised.startsWith('55') ? normalised : `55${normalised}`;

      // Build tag map from variables object or array
      let tag = {};
      if (variables && typeof variables === 'object' && !Array.isArray(variables)) {
        tag = variables;
      } else if (Array.isArray(variables)) {
        variables.forEach((v, i) => { tag[String(i + 1)] = v; });
      }

      const payload = {
        channelId,
        phone: phoneForGoTalk,
        phoneIsFixed: false,
        contactName: contactName || '',
        templateId,
        category: 'attendance',
        tag,
      };

      const response = await gotalkFetch('/message/send-active-notification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });

      let data;
      try { data = await response.json(); } catch (_) { data = {}; }

      if (!response.ok) {
        console.error('[Gotalk] send-template error:', response.status, data);
        return res.status(response.status).json({ error: data?.message || data?.error || 'Erro ao enviar template.', details: data });
      }

      res.json({ success: true, result: data });
    } catch (err) {
      console.error('POST /gotalk/send-template error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // ═══════════════════════════════════════════════════════════════════════════
  // ── LIVE GoTalk API PROXIES ──────────────────────────────────────────────
  // All routes below are thin, authenticated proxies to the GoTalk REST API.
  // They resolve channelId server-side (never accept it from the client) and
  // strip channel_id from any response before forwarding to the frontend.
  // ═══════════════════════════════════════════════════════════════════════════

  // Helper: forward a GoTalk JSON response to the Express response, stripping
  // any field named channel_id or channelId from every object in the payload.
  async function forwardGoTalkResponse(apiRes, res) {
    let data;
    try { data = await apiRes.json(); } catch (_) { data = {}; }
    if (!apiRes.ok) {
      return res.status(apiRes.status).json({ error: data?.message || data?.error || `GoTalk API: ${apiRes.status}` });
    }
    return res.json(stripChannelId(data));
  }

  // Recursively remove channel_id / channelId from objects so it is never
  // forwarded to the frontend (critical security rule).
  function stripChannelId(obj) {
    if (Array.isArray(obj)) return obj.map(stripChannelId);
    if (obj && typeof obj === 'object') {
      const out = {};
      for (const [k, v] of Object.entries(obj)) {
        if (k === 'channel_id' || k === 'channelId') continue;
        out[k] = stripChannelId(v);
      }
      return out;
    }
    return obj;
  }

  // ── OPERATORS (live GoTalk) ───────────────────────────────────────────────

  // GET /api/gotalk/live/operators/:channelUuid — list all operators from GoTalk
  router.get('/live/operators/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/operator/channel/${channelId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/live/operators/:channelUuid/online — online operators
  router.get('/live/operators/:channelUuid/online', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/operator/online/${channelId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/live/operator/:operatorId — single operator by GoTalk ID
  router.get('/live/operator/:operatorId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/operator/${req.params.operatorId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/live/operator/:operatorId/attendance-count
  router.get('/live/operator/:operatorId/attendance-count', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/operator/total/attendances/count/operatorId/${req.params.operatorId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/live/operator/:operatorId/token — get operator token (supervisor-level)
  // Admin-only: bearer tokens must not be accessible to non-admin users.
  router.get('/live/operator/:operatorId/token', requireAuth, requireAdmin, async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/user/operator-token/operatorId/${req.params.operatorId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/operator/create — create operator in GoTalk
  // Body: { name, login, password, department[], weekDays?, weekStartTime?, weekFinishTime?,
  //         satStartTime?, satFinishTime?, sunStartTime?, sunFinishTime?, channelUuid }
  router.post('/live/operator/create', async (req, res) => {
    try {
      const { channelUuid, ...rest } = req.body;
      const channelId = await resolveChannelIdByUuid(pool, channelUuid || null);
      const payload = { ...rest, role: 'operator', channelId };
      const apiRes = await gotalkFetch('/user/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // PUT /api/gotalk/live/operator/:operatorId — update operator
  // Body: { department?: [] } (any updatable fields)
  router.put('/live/operator/:operatorId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/operator/${req.params.operatorId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/gotalk/live/operator/:operatorId
  router.delete('/live/operator/:operatorId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/operator/${req.params.operatorId}`, { method: 'DELETE' });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── ATTENDANCES (live GoTalk) ─────────────────────────────────────────────

  // POST /api/gotalk/live/attendances/:channelUuid — channel attendances with filters
  // Body: { filters: { type: "keyword"|"department"|"operator", keyword?, department?, operator? } }
  router.post('/live/attendances/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/attendance/follow/channelId/${channelId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/attendances/transfer-operator — transfer attendance to another operator
  // Body: { operatorId, attendanceId }
  router.post('/live/attendances/transfer-operator', async (req, res) => {
    try {
      const { operatorId, attendanceId } = req.body;
      if (!operatorId || !attendanceId) {
        return res.status(400).json({ error: 'operatorId e attendanceId são obrigatórios.' });
      }
      const apiRes = await gotalkFetch('/message/transfer-attendance-operator', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ operatorId, attendanceId }),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/attendances/finish — finish an attendance
  // Body: { attendanceId, reason }
  router.post('/live/attendances/finish', async (req, res) => {
    try {
      const { attendanceId, reason } = req.body;
      if (!attendanceId || !reason) {
        return res.status(400).json({ error: 'attendanceId e reason são obrigatórios.' });
      }
      const apiRes = await gotalkFetch('/attendance/finish-attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ attendanceId, reason }),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/attendances/search/:channelUuid — search attendances by name/number/date
  // Body: { search?, filters?: { type: "period", firstPeriod, finalPeriod } }
  router.post('/live/attendances/search/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/attendance/search/old/channelId/${channelId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── DEPARTMENTS (live GoTalk) ─────────────────────────────────────────────

  // GET /api/gotalk/live/departments/:channelUuid — list departments
  router.get('/live/departments/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/department/channel/${channelId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/live/department/:departmentId — single department
  router.get('/live/department/:departmentId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/department/${req.params.departmentId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/department/create — create department
  // Body: { name, channelUuid }
  router.post('/live/department/create', async (req, res) => {
    try {
      const { channelUuid, name } = req.body;
      if (!name) return res.status(400).json({ error: 'name é obrigatório.' });
      const channelId = await resolveChannelIdByUuid(pool, channelUuid || null);
      const apiRes = await gotalkFetch('/department', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, channelId }),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // PUT /api/gotalk/live/department/:departmentId — update department
  // Body: { name }
  router.put('/live/department/:departmentId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/department/${req.params.departmentId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/gotalk/live/department/:departmentId
  router.delete('/live/department/:departmentId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/department/${req.params.departmentId}`, { method: 'DELETE' });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── GOTALK CONTACTS (direct GoTalk API) ──────────────────────────────────

  // GET /api/gotalk/live/contacts/:channelUuid/page/:page — paginated contacts (9/page)
  router.get('/live/contacts/:channelUuid/page/:page', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/contact/channel/${channelId}/page/${req.params.page}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/live/contact/:contactId — single contact by GoTalk _id
  router.get('/live/contact/:contactId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/contact/${req.params.contactId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/contact/create — create contact in GoTalk
  // Body: { name, number, channelUuid, state?, genre? }
  router.post('/live/contact/create', async (req, res) => {
    try {
      const { channelUuid, name, number, ...rest } = req.body;
      if (!name || !number) return res.status(400).json({ error: 'name e number são obrigatórios.' });
      const channelId = await resolveChannelIdByUuid(pool, channelUuid || null);
      const apiRes = await gotalkFetch('/contact/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, number, channelId, ...rest }),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // PUT /api/gotalk/live/contact/:contactId — update contact
  router.put('/live/contact/:contactId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/contact/${req.params.contactId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/gotalk/live/contact/:contactId
  router.delete('/live/contact/:contactId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/contact/${req.params.contactId}`, { method: 'DELETE' });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/contacts/filter/:channelUuid/page/:page — filtered contacts
  // Body: { filter: { type: "keyword"|"region"|"gender"|"customerPortfolio"|"period"|"attendances",
  //                   search?, startDate?, endDate? } }
  router.post('/live/contacts/filter/:channelUuid/page/:page', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/contact/filter/channel/${channelId}/page/${req.params.page}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── SUPERVISORS (live GoTalk) ─────────────────────────────────────────────

  // GET /api/gotalk/live/supervisors/:channelUuid — list supervisors
  router.get('/live/supervisors/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/channel/manager/channel/${channelId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // GET /api/gotalk/live/supervisor/:managerId — single supervisor
  router.get('/live/supervisor/:managerId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/channel/manager/${req.params.managerId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/supervisor/create — create supervisor
  // Body: { name, login, password, channelUuid, permissions?: [], nickname? }
  router.post('/live/supervisor/create', async (req, res) => {
    try {
      const { channelUuid, ...rest } = req.body;
      if (!rest.name || !rest.login) return res.status(400).json({ error: 'name e login são obrigatórios.' });
      const channelId = await resolveChannelIdByUuid(pool, channelUuid || null);
      const apiRes = await gotalkFetch('/user/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...rest, role: 'channel_manager', channelId }),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // PUT /api/gotalk/live/supervisor/:managerId — update supervisor
  router.put('/live/supervisor/:managerId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/channel/manager/${req.params.managerId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/gotalk/live/supervisor/:managerId
  router.delete('/live/supervisor/:managerId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/channel/manager/${req.params.managerId}`, { method: 'DELETE' });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── TABULATIONS (live GoTalk) ─────────────────────────────────────────────

  // GET /api/gotalk/live/tabulations/:channelUuid — list tabulations
  router.get('/live/tabulations/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/channel/tabulations/${channelId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/tabulation/create/:channelUuid — create tabulation
  // Body: { reason: [{ text: "..." }] }
  router.post('/live/tabulation/create/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/channel/tabulations/${channelId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // PUT /api/gotalk/live/tabulation/:tabulationId — update tabulation
  // Body: { text: "..." }
  router.put('/live/tabulation/:tabulationId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/channel/tabulations/${req.params.tabulationId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/gotalk/live/tabulation/:tabulationId
  router.delete('/live/tabulation/:tabulationId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/channel/tabulations/${req.params.tabulationId}`, { method: 'DELETE' });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── TAGS / LABELS (live GoTalk) ───────────────────────────────────────────

  // GET /api/gotalk/live/tags/:channelUuid — list tags/labels
  router.get('/live/tags/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/channel/tags/${channelId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/tag/create/:channelUuid — create tag
  // Body: { name, color }
  router.post('/live/tag/create/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/channel/tags/${channelId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // PUT /api/gotalk/live/tag/:tagId — update tag
  // Body: { name?, color? }
  router.put('/live/tag/:tagId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/channel/tags/${req.params.tagId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/gotalk/live/tag/:tagId
  router.delete('/live/tag/:tagId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/channel/tags/${req.params.tagId}`, { method: 'DELETE' });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── CHATBOT MENUS (live GoTalk – CRUD) ───────────────────────────────────

  // GET /api/gotalk/live/chatbot-menu/:menuId — single menu by _id
  router.get('/live/chatbot-menu/:menuId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/menu/${req.params.menuId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/chatbot-menu/create — create chatbot menu
  // Body: { name, channelUuid, menus?, text?, imageEnabled?, media?, contentOrder?,
  //         topMenuId?, refObjectMenus? }
  router.post('/live/chatbot-menu/create', async (req, res) => {
    try {
      const { channelUuid, ...rest } = req.body;
      if (!rest.name) return res.status(400).json({ error: 'name é obrigatório.' });
      const channelId = await resolveChannelIdByUuid(pool, channelUuid || null);
      const apiRes = await gotalkFetch('/menu', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...rest, channelId }),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // PUT /api/gotalk/live/chatbot-menu/:menuId — update menu
  router.put('/live/chatbot-menu/:menuId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/menu/${req.params.menuId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/gotalk/live/chatbot-menu/:menuId
  router.delete('/live/chatbot-menu/:menuId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/menu/${req.params.menuId}`, { method: 'DELETE' });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── QUICK ANSWERS (live GoTalk) ───────────────────────────────────────────

  // POST /api/gotalk/live/quick-answers/:channelUuid — list quick answers (with optional filter)
  // Body: { type?: "keyword"|"department", keyword?, department? }
  router.post('/live/quick-answers/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/message/quick-answers/channelId/${channelId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/quick-answers/by-department/:channelUuid — by department
  // Body: { departments: ["departmentId"], shortcut? }
  router.post('/live/quick-answers/by-department/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const apiRes = await gotalkFetch(`/message/quick-answers/departments/${channelId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/quick-answer/create/:channelUuid — create quick answer
  // Body: { name, departments: [], content, shortcuts?: [] }
  router.post('/live/quick-answer/create/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const { name, departments, content, shortcuts } = req.body;
      if (!name || !content || !departments) {
        return res.status(400).json({ error: 'name, departments e content são obrigatórios.' });
      }
      const apiRes = await gotalkFetch(`/message/quick-answers/${channelId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, departments, content, shortcuts }),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // PUT /api/gotalk/live/quick-answer/:quickAnswerId — update quick answer
  // Body: { name?, departments?: [], content?, shortcuts?: [] }
  router.put('/live/quick-answer/:quickAnswerId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/message/quick-answers/${req.params.quickAnswerId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(req.body),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // DELETE /api/gotalk/live/quick-answer/:quickAnswerId
  router.delete('/live/quick-answer/:quickAnswerId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/message/quick-answers/${req.params.quickAnswerId}`, { method: 'DELETE' });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── MESSAGING / NOTIFICATIONS ─────────────────────────────────────────────

  // POST /api/gotalk/send-text — send a plain text message to a contact number
  // Body: { contactNumber?, contactId?, message, channelUuid? }
  router.post('/send-text', async (req, res) => {
    try {
      const { contactNumber, contactId, message, channelUuid } = req.body;
      if (!message) return res.status(400).json({ error: 'message é obrigatório.' });
      if (!contactNumber && !contactId) return res.status(400).json({ error: 'contactNumber ou contactId é obrigatório.' });

      const payload = { message };
      if (contactNumber) payload.contactNumber = String(contactNumber);
      if (contactId) payload.contactId = String(contactId);

      if (channelUuid) {
        payload.channelId = await resolveChannelIdByUuid(pool, channelUuid);
      }

      const apiRes = await gotalkFetch('/message/send_message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/send-message-attendance — send message associated with an attendance session
  // Body: { channelUuid, attendanceId, phone, body, type?, url?, filename? }
  router.post('/send-message-attendance', async (req, res) => {
    try {
      const { channelUuid, attendanceId, phone, body, type, url, filename } = req.body;
      if (!attendanceId || !phone || !body) {
        return res.status(400).json({ error: 'attendanceId, phone e body são obrigatórios.' });
      }
      const channelId = await resolveChannelIdByUuid(pool, channelUuid || null);

      const payload = { channelId, attendanceId, phone: String(phone), body, type: type || 'text' };
      if (url) payload.url = url;
      if (filename) payload.filename = filename;

      const apiRes = await gotalkFetch('/websocket/send-message', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/send-hsm-template — send template by name (not active notification)
  // Body: { contactNumber?, contactId?, templateName, channelUuid?, tag? }
  router.post('/send-hsm-template', async (req, res) => {
    try {
      const { contactNumber, contactId, templateName, channelUuid, tag } = req.body;
      if (!templateName) return res.status(400).json({ error: 'templateName é obrigatório.' });
      if (!contactNumber && !contactId) return res.status(400).json({ error: 'contactNumber ou contactId é obrigatório.' });

      const payload = { templateName };
      if (contactNumber) payload.contactNumber = String(contactNumber);
      if (contactId) payload.contactId = String(contactId);
      if (tag) payload.tag = tag;

      if (channelUuid) {
        payload.channelId = await resolveChannelIdByUuid(pool, channelUuid);
      }

      const apiRes = await gotalkFetch('/message/send_template', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/send-active-notification — full active notification (all fields)
  // Body: { channelUuid, phone, contactName, phoneIsFixed?, operatorId?, templateId?, text?, tag? }
  // Note: /send-template above is a simpler wrapper; this exposes all GoTalk fields.
  router.post('/send-active-notification', async (req, res) => {
    try {
      const { channelUuid, phone, contactName, phoneIsFixed, operatorId, templateId, text, tag } = req.body;
      if (!phone || !contactName) return res.status(400).json({ error: 'phone e contactName são obrigatórios.' });
      if (!templateId && !text) return res.status(400).json({ error: 'templateId ou text é obrigatório.' });

      const channelId = await resolveChannelIdByUuid(pool, channelUuid || null);
      const norm = normalizePhone(String(phone));
      const phoneForGoTalk = norm.startsWith('55') ? norm : `55${norm}`;

      const payload = { channelId, phone: phoneForGoTalk, contactName, phoneIsFixed: phoneIsFixed === true };
      if (operatorId) payload.operatorId = operatorId;
      if (templateId) payload.templateId = templateId;
      if (text) payload.text = text;
      if (tag) payload.tag = tag;

      const apiRes = await gotalkFetch('/message/send-active-notification', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── MESSAGES (live GoTalk) ────────────────────────────────────────────────

  // GET /api/gotalk/live/messages/by-attendance/:attendanceId — get messages for an attendance via GoTalk API
  router.get('/live/messages/by-attendance/:attendanceId', async (req, res) => {
    try {
      const apiRes = await gotalkFetch(`/message/load/protocol/attendanceId/${req.params.attendanceId}`);
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // POST /api/gotalk/live/messages/group — get messages for a WhatsApp group
  // Body: { groupId }
  router.post('/live/messages/group', async (req, res) => {
    try {
      const { groupId } = req.body;
      if (!groupId) return res.status(400).json({ error: 'groupId é obrigatório.' });
      const apiRes = await gotalkFetch('/message/load_messages_group', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ groupId }),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── REPORTS (live GoTalk) ─────────────────────────────────────────────────

  // POST /api/gotalk/live/reports/access-log/:page — access log report
  // Body: { filters: { channelUuid, type: "operator"|"channel_manager",
  //                    id?, departmentId?, date: "1"|"2"|"3"|"4",
  //                    firstPeriod?, finalPeriod? } }
  router.post('/live/reports/access-log/:page', async (req, res) => {
    try {
      const { filters = {} } = req.body;
      if (!filters.channelUuid && !filters.channelId) {
        return res.status(400).json({ error: 'filters.channelUuid é obrigatório.' });
      }

      const channelId = filters.channelId
        || await resolveChannelIdByUuid(pool, filters.channelUuid);

      const goTalkFilters = { ...filters, channelId };
      delete goTalkFilters.channelUuid;

      const apiRes = await gotalkFetch(`/report/access-log/${req.params.page}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ filters: goTalkFilters }),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── CAMPAIGNS (live GoTalk) ───────────────────────────────────────────────

  // POST /api/gotalk/live/campaign/:channelUuid — create and send a campaign
  // Body: { name, templateId, automation: { enable: bool },
  //         sendingMessages: { immediate: bool, schedulingDate? },
  //         contacts: [{ contactId }] }
  router.post('/live/campaign/:channelUuid', async (req, res) => {
    try {
      const channelId = await resolveChannelIdByUuid(pool, req.params.channelUuid);
      const { name, templateId, automation, sendingMessages, contacts } = req.body;
      if (!name || !templateId || !contacts?.length) {
        return res.status(400).json({ error: 'name, templateId e contacts são obrigatórios.' });
      }
      const apiRes = await gotalkFetch(`/campaign/channelId/${channelId}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, templateId, automation, sendingMessages, contacts }),
      });
      return forwardGoTalkResponse(apiRes, res);
    } catch (err) {
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/whatsapp/messages (alias) / GET /api/gotalk/messages-list ─────
  // Listagem unificada de mensagens WhatsApp (GoTalk + uazapi) com filtros ricos.
  // O endpoint canônico é /api/whatsapp/messages; /api/gotalk/messages-list é o
  // handler interno roteado via alias em server/index.js.
  // Query params:
  //   page       — página (1-based, default 1)
  //   limit      — itens por página (default 50, max 200)
  //   phone      — filtra por últimos 10 dígitos do telefone
  //   unit_id    — UUID da unidade
  //   client_id  — UUID do cliente (filtra mensagens vinculadas a esse cliente)
  //   source     — 'gotalk' | 'uazapi' (omitir = todos)
  //   direction  — 'IN' | 'OUT' (omitir = todos)
  //   type       — message_type (TEXT, AUDIO, IMAGE …)
  //   operator   — operator_name (ILIKE)
  //   date_from  — ISO date string (sent_at >=)
  //   date_to    — ISO date string (sent_at <=)
  //   q          — busca full-text no body (GIN index)
  //   format     — 'csv' → retorna CSV com até 5.000 linhas (sem paginação)
  router.get('/messages-list', async (req, res) => {
    try {
      const {
        page = '1',
        limit = '50',
        phone,
        unit_id,
        client_id,
        source,
        direction,
        type,
        operator,
        date_from,
        date_to,
        q,
        format,
      } = req.query;

      const isExport = format === 'csv';
      const lim = isExport ? 5000 : Math.min(parseInt(limit, 10) || 50, 200);
      const off = isExport ? 0 : (Math.max(parseInt(page, 10) || 1, 1) - 1) * lim;

      const conditions = [];
      const params = [];

      if (phone) {
        const last10 = normalizePhone(phone).slice(-10);
        params.push(last10);
        conditions.push(`RIGHT(gm.phone_number, 10) = $${params.length}`);
      }
      if (unit_id) {
        params.push(unit_id);
        conditions.push(`(gm.unit_id = $${params.length} OR gch.unit_id = $${params.length})`);
      }
      if (client_id) {
        params.push(client_id);
        conditions.push(`gm.client_id = $${params.length}`);
      }
      if (source) {
        params.push(source);
        conditions.push(`gm.source = $${params.length}`);
      }
      if (direction) {
        params.push(direction);
        conditions.push(`gm.direction = $${params.length}`);
      }
      if (type) {
        params.push(type);
        conditions.push(`gm.message_type = $${params.length}`);
      }
      if (operator) {
        params.push(`%${operator}%`);
        conditions.push(`gm.operator_name ILIKE $${params.length}`);
      }
      if (date_from) {
        params.push(date_from);
        conditions.push(`gm.sent_at >= $${params.length}`);
      }
      if (date_to) {
        // Normalize to end-of-day so date-only values include the full day
        params.push(date_to);
        conditions.push(`gm.sent_at < ($${params.length}::date + interval '1 day')`);
      }
      if (q && q.trim()) {
        params.push(q.trim());
        conditions.push(`to_tsvector('portuguese', COALESCE(gm.body,'')) @@ plainto_tsquery('portuguese', $${params.length})`);
      }

      const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

      // Total count (skip for export to save one query round-trip)
      let total = 0;
      if (!isExport) {
        const countRes = await pool.query(
          `SELECT COUNT(*) FROM gotalk_messages gm
           LEFT JOIN gotalk_channels gch ON gch.id = gm.gotalk_channel_uuid
           ${where}`,
          params
        );
        total = parseInt(countRes.rows[0].count, 10);
      }

      // Data query
      const dataParams = [...params, lim, off];
      const result = await pool.query(
        `SELECT
           gm.id,
           gm.gotalk_message_id,
           gm.phone_number,
           gm.direction,
           gm.body,
           gm.message_type,
           gm.attachment_url,
           gm.attachment_name,
           gm.attachment_mime_type,
           gm.ack_status,
           gm.operator_name,
           gm.department,
           gm.sent_at,
           gm.source,
           gm.unit_id,
           gm.client_id,
           gm.gotalk_contact_id,
           c.name    AS client_name,
           COALESCE(u.nome_fantasia, u.razao_social) AS unit_name
         FROM gotalk_messages gm
         LEFT JOIN gotalk_channels gch ON gch.id = gm.gotalk_channel_uuid
         LEFT JOIN clients c ON c.id = gm.client_id
         LEFT JOIN companies u ON u.id = gm.unit_id
         ${where}
         ORDER BY gm.sent_at DESC
         LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
        dataParams
      );

      if (isExport) {
        const escCsv = (v) => {
          if (v == null) return '';
          let s = String(v);
          // Neutralize formula injection: prefix dangerous leading chars with a tab
          // so spreadsheet apps treat the cell as text rather than a formula.
          if (s.length > 0 && /^[=+\-@\t\r]/.test(s)) {
            s = '\t' + s;
          }
          if (s.includes(',') || s.includes('"') || s.includes('\n') || s.includes('\r') || s.includes('\t')) {
            return '"' + s.replace(/"/g, '""') + '"';
          }
          return s;
        };

        const dirLabel = (d) => d === 'IN' ? 'Recebida' : d === 'OUT' ? 'Enviada' : d || '';
        const typeMap = {
          TEXT: 'Texto', AUDIO: 'Áudio', IMAGE: 'Imagem', VIDEO: 'Vídeo',
          DOCUMENT: 'Documento', TEMPLATE: 'Template', STICKER: 'Sticker',
          LOCATION: 'Localização', CONTACT: 'Contato',
        };

        const header = ['Data', 'Número', 'Cliente', 'Unidade', 'Provedor', 'Direção', 'Tipo', 'Mensagem', 'Operador'];
        const rows = result.rows.map(m => [
          m.sent_at ? new Date(m.sent_at).toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }) : '',
          m.phone_number || '',
          m.client_name || '',
          m.unit_name || '',
          m.source || '',
          dirLabel(m.direction),
          typeMap[m.message_type] || m.message_type || '',
          m.body || (m.attachment_name ? `[${m.attachment_name}]` : ''),
          m.operator_name || '',
        ]);

        const csvLines = [header, ...rows].map(row => row.map(escCsv).join(','));
        const csv = '\uFEFF' + csvLines.join('\r\n');

        res.setHeader('Content-Type', 'text/csv; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment; filename="conversas-whatsapp.csv"');
        return res.send(csv);
      }

      res.json({
        messages: result.rows,
        total,
        page: Math.max(parseInt(page, 10) || 1, 1),
        limit: lim,
        pages: Math.ceil(total / lim),
      });
    } catch (err) {
      console.error('[Gotalk] GET /messages-list error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  // ── GET /api/gotalk/contact-profile ───────────────────────────────────────
  // Retorna dados de perfil de um contato GoTalk pelo número de telefone.
  // Usado pelo painel de Prospecção para enriquecer contatos com source='gotalk'.
  // Segurança: channel_id NUNCA é retornado (stripChannelId enforced).
  router.get('/contact-profile', requireAuth, async (req, res) => {
    try {
      const { phone } = req.query;
      if (!phone) return res.status(400).json({ error: 'phone obrigatório.' });
      const last10 = String(phone).replace(/\D/g, '').slice(-10);
      if (!last10 || last10.length < 8) return res.status(400).json({ error: 'Telefone inválido.' });

      // Query gotalk_contacts by phone (last 10 digits)
      const contactRes = await pool.query(
        `SELECT gc.gotalk_id, gc.name, gc.phone_number, gc.raw_data,
                gch.name AS channel_name, gch.phone_number AS channel_phone,
                gch.unit_id
           FROM gotalk_contacts gc
           LEFT JOIN gotalk_channels gch ON gch.channel_id = gc.channel_id AND gch.is_active = TRUE
          WHERE RIGHT(COALESCE(gc.phone_number, ''), 10) = $1
          LIMIT 1`,
        [last10]
      );

      if (contactRes.rowCount === 0) {
        return res.json({ found: false });
      }

      const row = contactRes.rows[0];
      const rawData = row.raw_data || {};
      // picture_url may be in raw_data under various keys
      const pictureUrl = rawData.picture_url || rawData.pictureUrl || rawData.avatar || rawData.photo || null;
      const displayName = row.name || rawData.name || rawData.pushName || null;

      return res.json({
        found: true,
        gotalkId: row.gotalk_id,
        name: displayName,
        phoneNumber: row.phone_number,
        pictureUrl,
        channelName: row.channel_name || null,
        channelPhone: row.channel_phone || null,
      });
    } catch (err) {
      logger.error?.(`[Gotalk] GET /contact-profile error: ${err.message}`);
      res.status(500).json({ error: err.message });
    }
  });

  return router;
}

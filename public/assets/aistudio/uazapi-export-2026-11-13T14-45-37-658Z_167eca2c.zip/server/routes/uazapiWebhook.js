/**
 * WEBHOOK UAZAPI
 *
 * Endpoint público para receber eventos do SaaS uazapi.
 * Responde 200 imediatamente e processa de forma assíncrona.
 *
 * Autenticação: inclua o token da instância como query param na URL do webhook
 * configurada no painel uazapi:
 *   https://SEU_DOMINIO/api/uazapi/webhook?token=UUID_TOKEN_DA_INSTANCIA
 * O handler lê ?token= e valida contra o token armazenado em unit_whatsapp_credentials.
 *
 * Eventos suportados (formato real do uazapi, conforme docs.uazapi.com):
 *  - "messages"        → armazena nova(s) mensagem(ns) (Formato C nativo uazapi)
 *  - "message"         → alias singular para "messages"
 *  - "messages_update" → atualiza ack_status
 *  - "status"          → alias para "messages_update"
 *  - "message_status"  → alias legado (compatibilidade)
 *  - "messages.upsert" → alias legado Baileys (compatibilidade)
 *  - "messages.update" → alias legado Baileys (compatibilidade)
 *
 * Formato de payload nativo uazapi (Formato C):
 *   {
 *     "event": "messages",
 *     "instance": "nome-da-instancia",
 *     "data": {
 *       "messageid": "3EB0...",
 *       "chatid": "5511999999999@s.whatsapp.net",
 *       "fromMe": false,
 *       "text": "Olá",
 *       "messageType": "conversation",
 *       "messageTimestamp": 1704067200000,
 *       "isGroup": false,
 *       "fileURL": "https://...",
 *       "senderName": "João"
 *     }
 *   }
 * O campo "data" pode ser um objeto único ou um array de objetos.
 *
 * IMPORTANTE: "Nome da Instância" = o nome configurado no painel uazapi (campo "instance"
 * no payload). Deve ser cadastrado exatamente igual em Configurações > Unidades.
 */

import { Router } from 'express';
import { logger } from '../logger.js';
import { getUazapiCredentialsByInstance, getUazapiCredsForUnit, getUazapiCredsByToken } from './units.js';
import { getCredsByInstanceForUnit } from '../lib/uazapiProxy.js';
import { requireAuth } from '../middleware/auth.js';
import { pushSseEvent } from '../lib/sseSingleton.js';
import { emitGotalkNewMessage, emitGotalkAckUpdate } from '../socket.js';
import { upsertProspectionContact } from './prospection.js';
import { decrypt } from '../utils/encryption.js';

const router = Router();

// ── In-memory webhook event log (ring buffer, last 50 events) ────────────────
// Allows operators to verify uazapi is calling the endpoint without needing
// server log access. Exposed via GET /api/uazapi/webhook-log (admin-only).
const WEBHOOK_LOG_MAX = 50;
const _webhookLog = [];
function _logWebhookEvent(entry) {
  _webhookLog.unshift({ ...entry, ts: new Date().toISOString() });
  if (_webhookLog.length > WEBHOOK_LOG_MAX) _webhookLog.length = WEBHOOK_LOG_MAX;
}

// ═══════════════════════════════════════════════════════════════════════════
//  WEBHOOK DISPATCHER — multi-instância uazapi
// ═══════════════════════════════════════════════════════════════════════════

/**
 * Extrai o identificador da instância do payload do webhook uazapi.
 * Suporta múltiplos campos porque diferentes versões da API uazapi usam
 * nomes diferentes para o mesmo conceito.
 *
 * Prioridade de extração:
 *   1. body.instanceId  (nome técnico do SDK uazapi)
 *   2. body.instance    (nome legível configurado no painel uazapi)
 *   3. body.instanceName
 *   4. body.phone       (número do WhatsApp que originou o evento — fallback)
 *   5. body.data?.instance
 *   6. body.data?.instanceId
 *   7. body.data?.phone
 *
 * @returns {string|null} — identificador da instância (ou null se não encontrado)
 */
function extractInstanceIdentifier(body) {
  if (!body || typeof body !== 'object') return null;

  const candidates = [
    body.instanceId,
    body.instance,
    body.instanceName,
    body.phone,
    body.data?.instance,
    body.data?.instanceId,
    body.data?.phone,
  ];

  for (const c of candidates) {
    if (c && typeof c === 'string' && c.trim()) return c.trim();
  }
  return null;
}

/**
 * Busca as credenciais exatas da instância que originou o evento.
 * Prioridade:
 *   1. Busca por instanceId (exact match em uazapi_instance_id)
 *   2. Fallback por token (quando uma instância compartilha a mesma URL webhook)
 *   3. Fallback por número de telefone (último recurso)
 */
async function resolveWebhookCredentials(pool, instanceId, req) {
  // ── 1. Exact match por instanceId ───────────────────────────────────────
  let creds = await getUazapiCredentialsByInstance(pool, instanceId);
  if (creds) {
    return { creds, resolvedBy: 'instanceId', instanceId };
  }

  // ── 2. Fallback por token (query param ou header) ──────────────────────
  const rawHeaderToken = req.headers['x-webhook-token'];
  const rawToken =
    (typeof req.query.token === 'string' ? req.query.token : null) ||
    (typeof rawHeaderToken === 'string' ? rawHeaderToken : Array.isArray(rawHeaderToken) ? rawHeaderToken[0] : null);
  const providedToken = rawToken
    ? (rawToken.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i)?.[0] ?? rawToken)
    : null;

  if (providedToken) {
    creds = await getUazapiCredsByToken(pool, providedToken);
    if (creds) {
      logger.warn(
        `[uazapi Webhook Dispatcher] Instance "${instanceId}" não cadastrada por instanceId — ` +
        `autenticada pelo token (unit=${creds.unitId}, storedInstance="${creds.instanceId}"). ` +
        `Mensagens serão registradas com instanceId="${instanceId}".`
      );
      return { creds, resolvedBy: 'token', instanceId };
    }
  }

  // ── 3. Fallback por número de telefone ────────────────────────────────
  const phone = normalizePhone(instanceId);
  if (phone) {
    try {
      const r = await pool.query(
        `SELECT unit_id, uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url
         FROM unit_whatsapp_credentials
         WHERE uazapi_instance_id LIKE $1
         ORDER BY created_at ASC LIMIT 1`,
        [`%${phone}%`]
      );
      if (r.rows[0]) {
        const row = r.rows[0];
        creds = {
          unitId: row.unit_id,
          token: decrypt(row.uazapi_token_encrypted),
          serverUrl: row.uazapi_server_url || null,
        };
        logger.warn(
          `[uazapi Webhook Dispatcher] Instance "${instanceId}" resolvida por telefone ` +
          `(unit=${creds.unitId}, storedInstance="${row.uazapi_instance_id}").`
        );
        return { creds, resolvedBy: 'phone', instanceId };
      }
    } catch (err) {
      logger.warn(`[uazapi Webhook Dispatcher] Erro no fallback por telefone: ${err.message}`);
    }
  }

  return { creds: null, resolvedBy: null, instanceId };
}

/**
 * Dicionário de funções de processamento por tipo de evento.
 * Cada handler recebe: (pool, msgData, unitId, instanceId, creds, event)
 * O 'creds' garante que todas as operações (DB, SSE, socket) usem
 * os tokens e o serverUrl exatos da instância que disparou o evento.
 */
const EVENT_DISPATCH_TABLE = {
  // ── Mensagens recebidas ───────────────────────────────────────────────
  message:         async (pool, msgData, unitId, instanceId, creds, event) => {
    await processMessageEvent(pool, msgData, unitId, instanceId);
    pushSseEvent(unitId, event, msgData);
  },
  messages:        async (pool, msgData, unitId, instanceId, creds, event) => {
    await processMessageEvent(pool, msgData, unitId, instanceId);
    pushSseEvent(unitId, event, msgData);
  },
  'messages.upsert': async (pool, msgData, unitId, instanceId, creds, event) => {
    await processMessageEvent(pool, msgData, unitId, instanceId);
    pushSseEvent(unitId, event, msgData);
  },
  receivedcallback: async (pool, msgData, unitId, instanceId, creds, event) => {
    await processMessageEvent(pool, msgData, unitId, instanceId);
    pushSseEvent(unitId, event, msgData);
  },

  // ── Atualizações de status (ACK) ───────────────────────────────────────
  message_status:  async (pool, msgData, unitId, instanceId, creds, event) => {
    await processStatusEvent(pool, msgData);
    pushSseEvent(unitId, 'message_status', msgData);
  },
  'messages.update': async (pool, msgData, unitId, instanceId, creds, event) => {
    await processStatusEvent(pool, msgData);
    pushSseEvent(unitId, 'message_status', msgData);
  },
  messages_update: async (pool, msgData, unitId, instanceId, creds, event) => {
    await processStatusEvent(pool, msgData);
    pushSseEvent(unitId, 'message_status', msgData);
  },
  status:          async (pool, msgData, unitId, instanceId, creds, event) => {
    await processStatusEvent(pool, msgData);
    pushSseEvent(unitId, 'message_status', msgData);
  },
  ackcallback:     async (pool, msgData, unitId, instanceId, creds, event) => {
    await processStatusEvent(pool, msgData);
    pushSseEvent(unitId, 'message_status', msgData);
  },

  // ── Chamadas ──────────────────────────────────────────────────────────
  call:            async (pool, msgData, unitId, instanceId, creds, event, body) => {
    const callData = extractCallFromWebhook(body, event);
    if (callData) {
      await upsertCallLog(pool, unitId, callData, body);
      pushSseEvent(unitId, 'call', callData);
    }
  },
};

/**
 * Dispatcher principal: identifica a instância, resolve credenciais, autentica,
 * e delega o processamento para a função correta do dicionário.
 *
 * PRINCÍPIO FUNDAMENTAL: o número que RECEBE a mensagem (instanceId/phone)
 * deve ser estritamente o mesmo que ENVIA a resposta.
 * Isso é garantido por:
 *   1. Cada evento é processado com as credenciais da instância que o originou
 *   2. `sendTextViaUazapi` usa `getCredsByInstanceForUnit` quando instanceId é passado
 *   3. O `processMessageEvent` persiste `uazapi_instance_id` para que o frontend
 *      saiba qual instância deve responder
 */
async function dispatchWebhookEvent(pool, body, req, res) {
  const startMs = Date.now();

  // ── 1. Extrair identificador da instância ─────────────────────────────
  const instanceId = extractInstanceIdentifier(body);
  if (!instanceId) {
    logger.warn(
      `[uazapi Webhook Dispatcher] Rejeitado: nenhum identificador de instância encontrado no payload. ` +
      `bodyKeys=[${Object.keys(body || {}).join(',')}] path="${req.path}" ip=${req.ip}`
    );
    return res.status(400).json({
      error: 'Campo "instance" obrigatório no payload.',
      hint: 'Envie instanceId, instance, instanceName ou phone no body.'
    });
  }

  logger.info(
    `[uazapi Webhook Dispatcher] Recebido evento para instanceId="${instanceId}" ` +
    `ip=${req.ip} path="${req.path}" bodyKeys=[${Object.keys(body).join(',')}]`
  );

  // ── 2. Resolver credenciais ──────────────────────────────────────────
  const { creds, resolvedBy } = await resolveWebhookCredentials(pool, instanceId, req);

  if (!creds) {
    logger.warn(
      `[uazapi Webhook Dispatcher] Instance desconhecida: "${instanceId}" — rejeitado. ` +
      `Verifique se a instância está cadastrada em Configurações > Unidades.`
    );
    return res.status(400).json({
      error: 'Instance não cadastrada.',
      instanceId,
    });
  }

  logger.info(
    `[uazapi Webhook Dispatcher] Credenciais resolvidas: instanceId="${instanceId}" ` +
    `unitId="${creds.unitId}" resolvedBy="${resolvedBy}" serverUrl="${creds.serverUrl || 'default'}"`
  );

  // ── 3. Autenticação opcional por token ───────────────────────────────
  const rawHeaderToken = req.headers['x-webhook-token'];
  const rawToken =
    (typeof req.query.token === 'string' ? req.query.token : null) ||
    (typeof rawHeaderToken === 'string' ? rawHeaderToken : Array.isArray(rawHeaderToken) ? rawHeaderToken[0] : null);
  const providedToken = rawToken
    ? (rawToken.match(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i)?.[0] ?? rawToken)
    : null;

  const tokenStatus = creds.token
    ? (providedToken ? (providedToken === creds.token ? 'valid' : 'invalid') : 'missing')
    : (providedToken ? 'no-server-token' : 'unauthenticated');

  logger.info(
    `[uazapi Webhook Dispatcher] Auth — instanceId="${instanceId}" tokenStatus="${tokenStatus}" ` +
    `rawLen=${rawToken?.length ?? 0} extractedLen=${providedToken?.length ?? 0}`
  );

  if (creds.token) {
    if (!providedToken) {
      logger.warn(
        `[uazapi Webhook Dispatcher] Instance "${instanceId}" requer token mas nenhum foi fornecido. ` +
        `Configure ?token= na URL do webhook.`
      );
      return res.status(401).json({
        error: 'Token obrigatório. Configure a URL do webhook com ?token=SEU_TOKEN.'
      });
    }
    if (providedToken !== creds.token) {
      logger.warn(
        `[uazapi Webhook Dispatcher] Token inválido para instance "${instanceId}" ` +
        `(rawLen=${rawToken?.length}, extractedLen=${providedToken?.length}).`
      );
      return res.status(401).json({ error: 'Token inválido.' });
    }
  }

  // ── 4. Responder 200 imediatamente (fire-and-forget) ─────────────────
  res.status(200).json({ ok: true, instanceId, unitId: creds.unitId });

  // ── 5. Processar de forma assíncrona ──────────────────────────────────
  setImmediate(async () => {
    try {
      // Extrair evento do body
      let rawEvent = body.EventType
        || (Array.isArray(body.event) ? body.event[0] : body.event);

      if (!rawEvent && rawToken) {
        const tokenSuffix = rawToken.replace(
          /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/i,
          ''
        );
        if (tokenSuffix) rawEvent = tokenSuffix.split('/')[0];
      }

      if (!rawEvent && req.path) {
        const pathSuffix = req.path.replace(/^\/webhook\/?/, '');
        if (pathSuffix) rawEvent = pathSuffix.split('/')[0];
      }

      const event = (typeof rawEvent === 'string' ? rawEvent.trim() : '').toLowerCase();
      const msgData = body.message || body.chat || body.data || null;
      const dataPreview = msgData ? JSON.stringify(msgData).slice(0, 400) : '(no data)';

      const effectiveInstanceId = instanceId || creds.instanceId || null;

      logger.info(
        `[uazapi Webhook Dispatcher] PROCESSING event="${event}" instanceId="${effectiveInstanceId}" ` +
        `unitId="${creds.unitId}" dataPreview=${dataPreview}`
      );

      // Log no ring buffer
      _logWebhookEvent({
        event,
        instance: effectiveInstanceId,
        unitId: creds.unitId,
        resolvedBy,
        dataKeys: msgData && typeof msgData === 'object'
          ? (Array.isArray(msgData) ? `array[${msgData.length}]` : Object.keys(msgData).join(','))
          : typeof msgData,
        dataPreview,
      });

      // ── 6. Dispatch via dicionário de funções ─────────────────────────
      const handler = EVENT_DISPATCH_TABLE[event];
      if (handler) {
        await handler(pool, msgData, creds.unitId, effectiveInstanceId, creds, event, body);
        logger.info(
          `[uazapi Webhook Dispatcher] HANDLED event="${event}" instanceId="${effectiveInstanceId}" ` +
          `unitId="${creds.unitId}" handler="${event}" elapsedMs=${Date.now() - startMs}`
        );
      } else if (event.includes('call') || body.call || body.messageType === 'call') {
        // Fallback para eventos de chamada com nomes dinâmicos
        const callHandler = EVENT_DISPATCH_TABLE.call;
        await callHandler(pool, msgData, creds.unitId, effectiveInstanceId, creds, event, body);
        logger.info(
          `[uazapi Webhook Dispatcher] HANDLED call event="${event}" instanceId="${effectiveInstanceId}" ` +
          `unitId="${creds.unitId}" elapsedMs=${Date.now() - startMs}`
        );
      } else {
        logger.info(
          `[uazapi Webhook Dispatcher] IGNORED event="${event || '(sem evento)'}" ` +
          `instanceId="${effectiveInstanceId}" unitId="${creds.unitId}"` +
          ` — nenhum handler registrado no dispatch table.`
        );
        pushSseEvent(creds.unitId, event || 'unknown', msgData || {});
      }

      logger.info(
        `[uazapi Webhook Dispatcher] COMPLETED instanceId="${effectiveInstanceId}" ` +
        `unitId="${creds.unitId}" totalElapsedMs=${Date.now() - startMs}`
      );
    } catch (err) {
      logger.error(
        `[uazapi Webhook Dispatcher] Erro assíncrono no processamento: ${err.message} ` +
        `instanceId="${instanceId}" unitId="${creds.unitId}"`
      );
    }
  });
}

// ── Helpers ──────────────────────────────────────────────────────────────────

function normalizePhone(raw) {
  if (!raw) return null;
  let digits = String(raw).replace(/\D/g, '');
  if (digits.startsWith('55') && digits.length > 11) digits = digits.slice(2);
  return digits || null;
}

function extractRemoteJid(jid) {
  if (!jid) return null;
  return jid.split('@')[0];
}

/**
 * Mapeia messageType do formato simples legado (lowercase, sem sufixo "Message").
 */
function mapMessageTypeSimple(type) {
  if (!type) return 'TEXT';
  const t = String(type).toLowerCase();
  if (t === 'image' || t === 'imagemessage') return 'IMAGE';
  if (t === 'audio' || t === 'ptt' || t === 'audiomessage' || t === 'pttmessage') return 'AUDIO';
  if (t === 'document' || t === 'documentmessage') return 'DOCUMENT';
  if (t === 'video' || t === 'videomessage') return 'VIDEO';
  return 'TEXT';
}

/**
 * Mapeia messageType do formato nativo uazapi (PascalCase com sufixo "Message").
 * Ex: "conversation" → "TEXT", "imageMessage" → "IMAGE"
 */
function mapMessageTypeUazapi(type) {
  if (!type) return 'TEXT';
  const t = String(type).toLowerCase();
  if (t === 'conversation' || t === 'extendedtextmessage') return 'TEXT';
  if (t === 'imagemessage') return 'IMAGE';
  if (t === 'audiomessage' || t === 'pttmessage') return 'AUDIO';
  if (t === 'documentmessage') return 'DOCUMENT';
  if (t === 'videomessage') return 'VIDEO';
  // Fallback para aliases legados (sem sufixo)
  return mapMessageTypeSimple(type);
}

function extractBodyTextBaileys(message) {
  if (!message) return '';
  return (
    message.conversation ||
    message.extendedTextMessage?.text ||
    message.imageMessage?.caption ||
    message.videoMessage?.caption ||
    message.documentMessage?.caption ||
    message.audioMessage?.caption ||
    ''
  );
}

function extractMessageTypeBaileys(message) {
  if (!message) return 'TEXT';
  if (message.imageMessage) return 'IMAGE';
  if (message.audioMessage || message.pttMessage) return 'AUDIO';
  if (message.documentMessage) return 'DOCUMENT';
  if (message.videoMessage) return 'VIDEO';
  return 'TEXT';
}

function extractAttachmentUrlBaileys(message) {
  if (!message) return null;
  return (
    message.imageMessage?.url ||
    message.audioMessage?.url ||
    message.documentMessage?.url ||
    message.videoMessage?.url ||
    null
  );
}

function extractAttachmentNameBaileys(message) {
  if (!message) return null;
  return message.documentMessage?.fileName || null;
}

function extractAttachmentMimeBaileys(message) {
  if (!message) return null;
  return (
    message.imageMessage?.mimetype ||
    message.audioMessage?.mimetype ||
    message.documentMessage?.mimetype ||
    message.videoMessage?.mimetype ||
    null
  );
}

/**
 * Mapeia status de ACK para valor numérico.
 * Suporta tanto o formato legado Evolution/GoTalk quanto as strings PascalCase do uazapi.
 *  0 = erro/cancelado
 *  1 = enviado/server_ack
 *  2 = entregue
 *  3 = lido/reproduzido
 */
function mapAckStatus(status) {
  if (!status) return null;
  switch (String(status).toUpperCase()) {
    case 'ERROR':
    case 'FAILED':
    case 'CANCELED':
    case 'QUEUED':      return 0;
    case 'PENDING':
    case 'SERVER_ACK':
    case 'SENT':        return 1;
    case 'DELIVERY_ACK':
    case 'DELIVERED':   return 2;
    case 'READ':
    case 'PLAYED':      return 3;
    default:            return null;
  }
}

/**
 * Normalisa um payload bruto do webhook uazapi num array plano de objetos de mensagem.
 *
 * Suporta três formatos:
 *
 * Formato C (nativo uazapi — PRINCIPAL):
 *   data = { messageid, chatid, fromMe, text, messageType, messageTimestamp, fileURL, isGroup }
 *   OU data = array de objetos com os mesmos campos.
 *
 * Formato A (simples legado):
 *   data = { id, from, body, type, timestamp }
 *
 * Formato B (Baileys/WA-style legado):
 *   data = { messages: [{ key: { id, remoteJid }, message, messageTimestamp }] }
 */
function normaliseMessages(data) {
  if (!data || typeof data !== 'object') return [];

  // ── Formato C: nativo uazapi ─────────────────────────────────────────────
  // Detectar por presença de "chatid" ou "messageid" (campos exclusivos do uazapi)
  const rawItems = Array.isArray(data) ? data : [data];
  const isFormatC = rawItems.some(
    i => i && (i.chatid !== undefined || i.messageid !== undefined)
  );

  if (isFormatC) {
    return rawItems
      .map(msg => {
        if (!msg || typeof msg !== 'object') return null;
        if (!msg.messageid) return null;
        if (msg.isGroup) return null;

        const chatid = msg.chatid || '';
        // Ignorar grupos via JID
        if (chatid.endsWith('@g.us')) return null;

        const phone = normalizePhone(extractRemoteJid(chatid));
        const ts = msg.messageTimestamp;

        return {
          messageId:      String(msg.messageid),
          phone,
          fromMe:         !!msg.fromMe,
          body:           String(msg.text || ''),
          messageType:    mapMessageTypeUazapi(msg.messageType),
          attachmentUrl:  msg.fileURL || null,
          attachmentName: null,
          attachmentMime: null,
          sentAt:         ts ? new Date(ts < 1e12 ? ts * 1000 : ts) : new Date(),
        };
      })
      .filter(Boolean);
  }

  // ── Formato A: objeto plano simples { id, from, body, type, timestamp } ──
  if (data.id && data.from !== undefined) {
    const phone = normalizePhone(String(data.from));
    const ts = data.timestamp;
    return [{
      messageId:      String(data.id),
      phone,
      fromMe:         false,
      body:           String(data.body || ''),
      messageType:    mapMessageTypeSimple(data.type),
      attachmentUrl:  data.mediaUrl || data.url || null,
      attachmentName: data.fileName || null,
      attachmentMime: data.mimetype || null,
      sentAt:         ts ? new Date(typeof ts === 'number' && ts < 1e12 ? ts * 1000 : ts) : new Date(),
    }];
  }

  // ── Formato B: Baileys-style data.messages[] ─────────────────────────────
  const msgs = Array.isArray(data.messages) ? data.messages
             : data.key ? [data]
             : [];

  if (msgs.length === 0) return [];

  return msgs
    .map(msg => {
      const key = msg.key || {};
      const messageId = key.id || msg.id || null;
      if (!messageId) return null;

      const remoteJid = key.remoteJid || msg.remoteJid || null;
      if (!remoteJid) return null;
      if (remoteJid.endsWith('@g.us')) return null;

      const phone = normalizePhone(extractRemoteJid(remoteJid));
      const inner = msg.message || null;
      const ts = msg.messageTimestamp || msg.timestamp || null;

      return {
        messageId:      String(messageId),
        phone,
        fromMe:         !!(key.fromMe || msg.fromMe),
        body:           extractBodyTextBaileys(inner),
        messageType:    extractMessageTypeBaileys(inner),
        attachmentUrl:  extractAttachmentUrlBaileys(inner),
        attachmentName: extractAttachmentNameBaileys(inner),
        attachmentMime: extractAttachmentMimeBaileys(inner),
        sentAt:         ts ? new Date(typeof ts === 'number' && ts < 1e12 ? ts * 1000 : ts) : new Date(),
      };
    })
    .filter(Boolean);
}

/**
 * Extrai o número de telefone do remoteJid de um item de ACK uazapi.
 * Suporta o formato nativo { id: { remoteJid: "55...@s.whatsapp.net" } }
 * e formatos legados { key.remoteJid, remoteJid }.
 */
function extractPhoneFromAckItem(item) {
  const jid = item?.id?.remoteJid || item?.key?.remoteJid || item?.remoteJid || null;
  if (jid) return normalizePhone(extractRemoteJid(jid));
  return null;
}

/**
 * Normalisa um payload bruto de ACK em pares planos {messageId, ack, phone}.
 *
 * Formato nativo uazapi (messages_update — confirmado via docs.uazapi.com):
 *   data = {
 *     id:     { id: "3EB0...", fromMe: true, remoteJid: "55...@s.whatsapp.net" },
 *     status: "DELIVERY_ACK",   // ou "READ" | "SERVER_ACK" | "PLAYED" | "ERROR"
 *     // algumas versões enviam ack como inteiro em vez de status como string:
 *     // ack: 2  (0=erro, 1=enviado, 2=entregue, 3=lido, 4=reproduzido)
 *   }
 *
 * Formatos legados também suportados:
 *   Formato A: data.messageid + data.status  (uazapi antigo campo plano)
 *   Formato B: array de { key.id, update.status }  (Baileys/wuzapi)
 */
function normaliseAcks(data) {
  if (!data) return [];

  // ── Formato nativo uazapi (messages_update) ───────────────────────────────
  // Payload: { id: { id: "3EB0...", fromMe: true, remoteJid: "..." }, status: "DELIVERY_ACK" }
  // O campo data.id é um OBJETO com a chave aninhada id.id — não uma string.
  // A branch abaixo também trata o caso em que data é um objeto único sem ser array.

  if (!Array.isArray(data)) {
    // Extrair messageId — 3 formatos possíveis:
    //   1) uazapi nativo: data.id.id (objeto aninhado)
    //   2) uazapi legado: data.messageid (campo plano)
    //   3) Baileys legado: data.key.id
    const messageId = data?.id?.id || data.messageid || data?.key?.id ||
      (typeof data.id === 'string' ? data.id : null) || null;

    // Extrair status — pode ser string ("DELIVERY_ACK") ou inteiro (2)
    const rawStatus = data.status ?? data.ack ?? null;
    if (!messageId || rawStatus === null || rawStatus === undefined) return [];

    const phone = extractPhoneFromAckItem(data);

    // Se for inteiro, usar diretamente (já está no formato interno)
    if (typeof rawStatus === 'number') {
      const ack = Number.isInteger(rawStatus) && rawStatus >= 0 && rawStatus <= 4
        ? rawStatus : null;
      return ack !== null ? [{ messageId: String(messageId), ack, phone }] : [];
    }
    const ack = mapAckStatus(rawStatus);
    return ack !== null ? [{ messageId: String(messageId), ack, phone }] : [];
  }

  // Array de atualizações (pode vir de lotes)
  return data
    .map(item => {
      if (!item) return null;
      // Mesmo multi-formato para cada item do array
      const messageId = item?.id?.id || item.messageid || item?.key?.id ||
        (typeof item.id === 'string' ? item.id : null) || null;
      const rawStatus = item?.update?.status ?? item?.status ?? item?.ack ?? null;
      if (!messageId || rawStatus === null || rawStatus === undefined) return null;
      const phone = extractPhoneFromAckItem(item);
      if (typeof rawStatus === 'number') {
        const ack = Number.isInteger(rawStatus) && rawStatus >= 0 && rawStatus <= 4
          ? rawStatus : null;
        return ack !== null ? { messageId: String(messageId), ack, phone } : null;
      }
      const ack = mapAckStatus(rawStatus);
      return ack !== null ? { messageId: String(messageId), ack, phone } : null;
    })
    .filter(Boolean);
}

// ── Client linking ────────────────────────────────────────────────────────────

async function findClientByPhone(dbClient, phone) {
  if (!phone) return null;
  const last10 = phone.slice(-10);
  if (!last10) return null;
  try {
    // Search all phone columns: phone/phone2 (set via CRM client form),
    // celular/telefone (legacy columns from old imports).
    // Using last-10-digits comparison so "5511999998888" matches "11999998888".
    const r = await dbClient.query(
      `SELECT id FROM clients
       WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''),    '[^0-9]', '', 'g'), 10) = $1
          OR RIGHT(REGEXP_REPLACE(COALESCE(phone2,''),   '[^0-9]', '', 'g'), 10) = $1
          OR RIGHT(REGEXP_REPLACE(COALESCE(celular,''),  '[^0-9]', '', 'g'), 10) = $1
          OR RIGHT(REGEXP_REPLACE(COALESCE(telefone,''), '[^0-9]', '', 'g'), 10) = $1
       LIMIT 1`,
      [last10]
    );
    return r.rows[0]?.id || null;
  } catch {
    return null;
  }
}

// ── Event processors ─────────────────────────────────────────────────────────

async function processMessageEvent(pool, data, unitId, instanceId = null) {
  const messages = normaliseMessages(data);

  if (messages.length === 0) {
    logger.info('[uazapi Webhook] Evento de mensagem sem dados normalizáveis — ignorado.');
    return;
  }

  let sawInbound = false;
  const dbClient = await pool.connect();
  try {
    for (const msg of messages) {
      const clientId = await findClientByPhone(dbClient, msg.phone);
      const direction = msg.fromMe ? 'OUT' : 'IN';
      if (direction === 'IN') sawInbound = true;

      try {
        // Mensagens de saída (fromMe) chegam ao webhook depois que o WhatsApp
        // confirmou o recebimento no servidor — ack_status começa em 1 (SERVER_ACK).
        // Mensagens recebidas (IN) não têm status de entrega próprio, usar NULL.
        const initialAck = msg.fromMe ? 1 : null;

        const insertRes = await dbClient.query(
          `INSERT INTO gotalk_messages
             (gotalk_message_id, client_id, phone_number, direction, body,
              message_type, attachment_url, attachment_name, attachment_mime_type,
              ack_status, sent_at, source, unit_id, uazapi_instance_id)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'uazapi',$12,$13)
           ON CONFLICT (gotalk_message_id) DO NOTHING`,
          [
            msg.messageId,
            clientId,
            msg.phone,
            direction,
            msg.body,
            msg.messageType,
            msg.attachmentUrl,
            msg.attachmentName,
            msg.attachmentMime,
            initialAck,
            msg.sentAt,
            unitId,
            instanceId || null,
          ]
        );

        const wasInserted = insertRes.rowCount > 0;
        if (wasInserted) {
          logger.info(`[uazapi Webhook] Mensagem ${msg.messageId} armazenada (unit=${unitId}, phone=${msg.phone}, dir=${direction}).`);
        }

        // Auto-register in prospection_contacts only when message was truly new
        // (rowCount=0 means ON CONFLICT DO NOTHING fired — duplicate delivery, skip)
        if (wasInserted) {
          if (direction === 'IN' && msg.phone) {
            upsertProspectionContact(pool, {
              phone: msg.phone,
              unitId: unitId || null,
              clientId: clientId || null,
              source: 'uazapi',
              instanceId: instanceId || null,
              direction: 'IN',
            }).catch(e => logger.warn(`[uazapi Webhook] Prospection upsert failed: ${e.message}`));
          }

          // Notify the frontend in real time for BOTH incoming and outgoing new messages.
          // - IN: shows toast + increments unread badge in ProspeccaoPanel.
          // - OUT (fromMe=true from real phone app, not from CRM send): refreshes the
          //   open timeline so the message appears without a manual reload.
          // Include body in the payload so ProspeccaoPanel can display the toast preview
          // immediately without an extra HTTP fetch (eliminates race condition).
          if (msg.phone) {
            try {
              emitGotalkNewMessage({
                source: 'uazapi',
                unitId,
                phone: msg.phone,
                direction,
                body: msg.body || null,
                // Task #294: include the instance that received this message so the
                // frontend composer can "follow" inbound replies to the same instance.
                uazapiInstanceId: instanceId || null,
              });
            } catch { /* non-fatal */ }
          }
        }
      } catch (err) {
        logger.error(`[uazapi Webhook] Erro ao inserir mensagem ${msg.messageId}: ${err.message}`);
      }
    }

    // Task #308: stamp last_inbound_at on the instance's credentials whenever the
    // SaaS delivers a real inbound message. This is the liveness heartbeat that lets
    // the UI flag instances whose inbound webhook has gone silent. Best-effort.
    if (sawInbound && instanceId) {
      await dbClient.query(
        `UPDATE unit_whatsapp_credentials SET last_inbound_at = NOW() WHERE uazapi_instance_id = $1`,
        [instanceId]
      ).catch(e => logger.warn(`[uazapi Webhook] last_inbound_at update failed: ${e.message}`));
    }
  } finally {
    dbClient.release();
  }
}

async function processStatusEvent(pool, data) {
  const acks = normaliseAcks(data);

  if (acks.length === 0) {
    logger.info('[uazapi Webhook] Evento de status sem dados normalizáveis — ignorado.');
    return;
  }

  const dbClient = await pool.connect();
  try {
    for (const { messageId, ack, phone: payloadPhone } of acks) {
      try {
        const r = await dbClient.query(
          `UPDATE gotalk_messages
           SET ack_status = $1
           WHERE gotalk_message_id = $2
             AND source = 'uazapi'
             AND (ack_status IS NULL OR ack_status < $1)
           RETURNING phone_number`,
          [ack, messageId]
        );
        if (r.rowCount > 0) {
          logger.info(`[uazapi Webhook] ACK atualizado: ${messageId} → ${ack}`);
          // Prefer phone from DB row; fall back to phone extracted from ACK payload remoteJid
          const phone = r.rows[0]?.phone_number || payloadPhone || null;
          try { emitGotalkAckUpdate({ messageId, ack, phone }); } catch { /* non-fatal */ }
        } else {
          // Row not found — may be a race condition or ID mismatch.
          // Still emit the socket event using the payload phone so the frontend can
          // refresh the timeline even when the DB hasn't committed the row yet.
          if (payloadPhone) {
            logger.warn(`[uazapi Webhook] ACK ${messageId} → ${ack}: nenhuma linha atualizada (ID não encontrado). Emitindo socket com phone=${payloadPhone}.`);
            try { emitGotalkAckUpdate({ messageId, ack, phone: payloadPhone }); } catch { /* non-fatal */ }
          } else {
            logger.warn(`[uazapi Webhook] ACK ${messageId} → ${ack}: nenhuma linha atualizada e phone desconhecido — verifique o messageId e o /webhook-log.`);
          }
        }
      } catch (err) {
        logger.error(`[uazapi Webhook] Erro ao atualizar ACK de ${messageId}: ${err.message}`);
      }
    }
  } finally {
    dbClient.release();
  }
}

// ── Send text ─────────────────────────────────────────────────────────────────

const UAZAPI_DEFAULT_SERVER = 'https://free.uazapi.com';

/**
 * Envia uma mensagem de texto via uazapi e persiste em gotalk_messages.
 *
 * POST /api/uazapi/send-text
 * Body: { unitId: string, phone: string, text: string }
 * Requires: auth session (requireAuth)
 */
async function sendTextViaUazapi(pool, unitId, phone, text, instanceId = null) {
  let creds;
  if (instanceId) {
    creds = await getCredsByInstanceForUnit(pool, unitId, instanceId);
    if (!creds) throw Object.assign(new Error('Instância uazapi não encontrada para esta unidade.'), { status: 422 });
  } else {
    creds = await getUazapiCredsForUnit(pool, unitId);
    if (!creds) throw Object.assign(new Error('Credenciais uazapi não configuradas para esta unidade.'), { status: 422 });
  }
  if (!creds.token) throw Object.assign(new Error('Token uazapi não configurado para esta unidade.'), { status: 422 });

  const serverUrl = creds.serverUrl || process.env.UAZAPI_SERVER_URL || UAZAPI_DEFAULT_SERVER;
  const number = String(phone).replace(/\D/g, '');

  const apiUrl = `${serverUrl.replace(/\/$/, '')}/send/text`;
  const apiRes = await fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'token': creds.token,
    },
    body: JSON.stringify({ number, text }),
  });

  const apiData = await apiRes.json().catch(() => ({}));

  if (!apiRes.ok) {
    const msg = apiData?.message || apiData?.error || `Erro ${apiRes.status} da API uazapi`;
    throw Object.assign(new Error(msg), { status: 422, apiData });
  }

  // Extrair messageId retornado pela API.
  // uazapi /send/text responde: { key: { id: "3EB0...", fromMe: true, remoteJid: "..." }, ... }
  // Cobrir também variantes legacy e o campo messageid plano.
  // IMPORTANTE: só aceitar valores string-like — apiData.id pode ser um objeto
  // aninhado em algumas variantes da API; nesse caso, usar apiData.id.id (string).
  function _pickStringId(...candidates) {
    for (const c of candidates) {
      if (c && typeof c === 'string') return c;
    }
    return null;
  }
  const messageId = _pickStringId(
    apiData?.key?.id,
    apiData?.id?.id,
    apiData?.messageid,
    typeof apiData?.id === 'string' ? apiData.id : null,
  );
  if (!messageId) {
    logger.warn(`[uazapi SendText] API não retornou messageId para ${number} — apiData: ${JSON.stringify(apiData).slice(0, 200)}`);
  }
  const effectiveMessageId = messageId || `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  let resultMsg;
  const dbClient = await pool.connect();
  try {
    const clientRow = await dbClient.query(
      `SELECT id FROM clients
       WHERE RIGHT(REGEXP_REPLACE(COALESCE(celular,''), '[^0-9]', '', 'g'), 10) = $1
          OR RIGHT(REGEXP_REPLACE(COALESCE(telefone,''), '[^0-9]', '', 'g'), 10) = $1
       LIMIT 1`,
      [number.slice(-10)]
    ).catch(() => ({ rows: [] }));
    const clientId = clientRow.rows[0]?.id || null;

    const now = new Date();
    await dbClient.query(
      `INSERT INTO gotalk_messages
         (gotalk_message_id, client_id, phone_number, direction, body,
          message_type, ack_status, sent_at, source, unit_id, uazapi_instance_id)
       VALUES ($1,$2,$3,'OUT',$4,'TEXT',1,$5,'uazapi',$6,$7)
       ON CONFLICT (gotalk_message_id) DO NOTHING`,
      [effectiveMessageId, clientId, number, text, now, unitId, creds.instanceId || null]
    );

    resultMsg = {
      id: effectiveMessageId,
      gotalk_message_id: effectiveMessageId,
      phone_number: number,
      body: text,
      direction: 'OUT',
      message_type: 'TEXT',
      sent_at: now.toISOString(),
      source: 'uazapi',
      unit_id: unitId,
      instance_id: creds.instanceId || null,
      ack_status: 1,
    };
  } finally {
    dbClient.release();
  }

  // Auto-create/update prospection contact for the recipient so the number
  // appears in the Prospecção panel even if it was never contacted before.
  // Use creds.instanceId (server-resolved) so the upsert always persists the
  // actual instance used — not the possibly-null request instanceId.
  // Fire-and-forget: runs after client is released; failure is non-fatal.
  upsertProspectionContact(pool, {
    phone: number,
    unitId: unitId || null,
    source: 'uazapi',
    instanceId: creds.instanceId || instanceId || null,
    // Task #294: outbound send — MUST NOT update last_inbound_instance_id.
    direction: 'OUT',
  }).catch(e => logger.warn(`[uazapi SendText] Prospection upsert failed: ${e.message}`));

  return resultMsg;
}

// Map uazapi media `type` → gotalk_messages.message_type (renderer expects upper-case).
const UAZAPI_MEDIA_TYPE_TO_MSGTYPE = {
  image: 'IMAGE',
  video: 'VIDEO',
  audio: 'AUDIO',
  ptt: 'AUDIO',
  myaudio: 'AUDIO',
  document: 'DOCUMENT',
  sticker: 'STICKER',
};

/**
 * Envia uma mídia (imagem/vídeo/áudio/documento/sticker) via uazapi e persiste em gotalk_messages.
 * `file` é uma URL pública OU uma string base64 (data URL aceita pela API uazapi).
 *
 * POST /api/uazapi/send-media
 * Body: { unitId, phone, type, file, fileName?, mimeType?, caption?, instanceId? }
 */
async function sendMediaViaUazapi(pool, unitId, phone, media, instanceId = null) {
  const { type, file, fileName, mimeType, caption } = media || {};
  const allowed = ['image', 'video', 'audio', 'ptt', 'document', 'sticker'];
  if (!allowed.includes(type)) {
    throw Object.assign(new Error(`Tipo de mídia inválido: ${type}.`), { status: 400 });
  }
  if (!file || typeof file !== 'string') {
    throw Object.assign(new Error('Conteúdo do arquivo (file) obrigatório.'), { status: 400 });
  }

  let creds;
  if (instanceId) {
    creds = await getCredsByInstanceForUnit(pool, unitId, instanceId);
    if (!creds) throw Object.assign(new Error('Instância uazapi não encontrada para esta unidade.'), { status: 422 });
  } else {
    creds = await getUazapiCredsForUnit(pool, unitId);
    if (!creds) throw Object.assign(new Error('Credenciais uazapi não configuradas para esta unidade.'), { status: 422 });
  }
  if (!creds.token) throw Object.assign(new Error('Token uazapi não configurado para esta unidade.'), { status: 422 });

  const serverUrl = creds.serverUrl || process.env.UAZAPI_SERVER_URL || UAZAPI_DEFAULT_SERVER;
  const number = String(phone).replace(/\D/g, '');

  const apiUrl = `${serverUrl.replace(/\/$/, '')}/send/media`;
  const apiBody = { number, type, file };
  if (caption) apiBody.text = caption;
  if (fileName) apiBody.docName = fileName;

  const apiRes = await fetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'token': creds.token },
    body: JSON.stringify(apiBody),
  });
  const apiData = await apiRes.json().catch(() => ({}));
  if (!apiRes.ok) {
    const msg = apiData?.message || apiData?.error || `Erro ${apiRes.status} da API uazapi`;
    throw Object.assign(new Error(msg), { status: 422, apiData });
  }

  function _pickStringId(...candidates) {
    for (const c of candidates) {
      if (c && typeof c === 'string') return c;
    }
    return null;
  }
  const messageId = _pickStringId(
    apiData?.key?.id,
    apiData?.id?.id,
    apiData?.messageid,
    typeof apiData?.id === 'string' ? apiData.id : null,
  );
  const effectiveMessageId = messageId || `local-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;

  // Best-effort: capture a hosted media URL if the API returned one (field name varies by version).
  const attachmentUrl = _pickStringId(
    apiData?.fileURL,
    apiData?.url,
    apiData?.mediaUrl,
    apiData?.message?.fileURL,
  ) || null;
  const messageType = UAZAPI_MEDIA_TYPE_TO_MSGTYPE[type] || 'DOCUMENT';

  let resultMsg;
  const dbClient = await pool.connect();
  try {
    const clientRow = await dbClient.query(
      `SELECT id FROM clients
       WHERE RIGHT(REGEXP_REPLACE(COALESCE(celular,''), '[^0-9]', '', 'g'), 10) = $1
          OR RIGHT(REGEXP_REPLACE(COALESCE(telefone,''), '[^0-9]', '', 'g'), 10) = $1
       LIMIT 1`,
      [number.slice(-10)]
    ).catch(() => ({ rows: [] }));
    const clientId = clientRow.rows[0]?.id || null;

    const now = new Date();
    await dbClient.query(
      `INSERT INTO gotalk_messages
         (gotalk_message_id, client_id, phone_number, direction, body,
          message_type, attachment_url, attachment_name, attachment_mime_type,
          ack_status, sent_at, source, unit_id, uazapi_instance_id)
       VALUES ($1,$2,$3,'OUT',$4,$5,$6,$7,$8,1,$9,'uazapi',$10,$11)
       ON CONFLICT (gotalk_message_id) DO NOTHING`,
      [effectiveMessageId, clientId, number, caption || '', messageType,
       attachmentUrl, fileName || null, mimeType || null, now, unitId, creds.instanceId || null]
    );

    resultMsg = {
      id: effectiveMessageId,
      gotalk_message_id: effectiveMessageId,
      phone_number: number,
      body: caption || '',
      direction: 'OUT',
      message_type: messageType,
      attachment_url: attachmentUrl,
      attachment_name: fileName || null,
      attachment_mime_type: mimeType || null,
      sent_at: now.toISOString(),
      source: 'uazapi',
      unit_id: unitId,
      instance_id: creds.instanceId || null,
      ack_status: 1,
    };
  } finally {
    dbClient.release();
  }

  upsertProspectionContact(pool, {
    phone: number,
    unitId: unitId || null,
    source: 'uazapi',
    instanceId: creds.instanceId || instanceId || null,
    // Task #294: outbound send — MUST NOT update last_inbound_instance_id.
    direction: 'OUT',
  }).catch(e => logger.warn(`[uazapi SendMedia] Prospection upsert failed: ${e.message}`));

  return resultMsg;
}

// ── Sync-contact helper ───────────────────────────────────────────────────────
// Importa mensagens recentes de um número específico via uazapi API e faz upsert
// em gotalk_messages. Retorna o número de registros novos inseridos.
async function syncContactMessages(pool, { phone, unitId }) {
  const creds = await getUazapiCredsForUnit(pool, unitId);
  if (!creds?.token) return 0;

  const { token, serverUrl } = creds;
  const baseUrl = (serverUrl || 'https://free.uazapi.com').replace(/\/$/, '');
  const headers = { 'Content-Type': 'application/json', 'token': token };

  // Normalizar telefone → chatId
  const phoneDigits = String(phone).replace(/\D/g, '');
  const waPhone = (phoneDigits.startsWith('55') && phoneDigits.length > 11)
    ? phoneDigits
    : `55${phoneDigits}`;
  const chatId = `${waPhone}@s.whatsapp.net`;

  // Lookback window: last 24h (aligned with the task spec; broader than
  // just "since midnight" to cover messages received late the previous night).
  const lookbackMs = Date.now() - 24 * 60 * 60 * 1000;

  let messages = [];
  try {
    const mr = await fetch(
      `${baseUrl}/messages?chatid=${encodeURIComponent(chatId)}&limit=100`,
      { headers, signal: AbortSignal.timeout(10_000) }
    );
    if (!mr.ok) return 0;
    const raw = await mr.json().catch(() => ({}));
    const all = Array.isArray(raw) ? raw
               : Array.isArray(raw?.messages) ? raw.messages
               : Array.isArray(raw?.data)     ? raw.data
               : [];
    // Filter to messages within the 24h lookback window
    messages = all.filter(m => {
      const ts = m.messageTimestamp || m.timestamp || 0;
      const ms = typeof ts === 'number' ? (ts < 1e12 ? ts * 1000 : ts) : 0;
      return ms >= lookbackMs;
    });
  } catch (err) {
    logger.warn(`[uazapi sync-contact] Erro ao buscar msgs para ${phone}: ${err.message}`);
    return 0;
  }

  if (!messages.length) return 0;

  let inserted = 0;
  const dbClient = await pool.connect();
  try {
    for (const msg of messages) {
      const messageId = msg.messageid || msg.id || msg.key?.id || null;
      if (!messageId) continue;
      if ((msg.chatid || '').endsWith('@g.us') || msg.isGroup) continue;

      const ts = msg.messageTimestamp || msg.timestamp || Date.now() / 1000;
      const sentAt = new Date(ts < 1e12 ? ts * 1000 : ts);
      const direction = msg.fromMe ? 'OUT' : 'IN';
      const body = msg.text || msg.body || msg.caption || '';
      const msgType = (() => {
        const t = String(msg.messageType || msg.type || '').toLowerCase();
        if (t.includes('image')) return 'IMAGE';
        if (t.includes('audio') || t.includes('ptt')) return 'AUDIO';
        if (t.includes('document')) return 'DOCUMENT';
        if (t.includes('video')) return 'VIDEO';
        return 'TEXT';
      })();
      const clientId = await findClientByPhone(dbClient, phoneDigits);

      try {
        const r = await dbClient.query(
          `INSERT INTO gotalk_messages
             (gotalk_message_id, client_id, phone_number, direction, body,
              message_type, attachment_url, ack_status, sent_at, source, unit_id, uazapi_instance_id)
           VALUES ($1,$2,$3,$4,$5,$6,$7,NULL,$8,'uazapi',$9,$10)
           ON CONFLICT (gotalk_message_id) DO NOTHING`,
          [
            String(messageId),
            clientId,
            phoneDigits.length > 11 ? phoneDigits.slice(2) : phoneDigits,
            direction,
            body,
            msgType,
            msg.fileURL || msg.url || null,
            sentAt,
            unitId,
            creds.instanceId || null,
          ]
        );
        if (r.rowCount > 0) inserted++;
      } catch (err) {
        logger.warn(`[uazapi sync-contact] Upsert erro msg ${messageId}: ${err.message}`);
      }
    }
  } finally {
    dbClient.release();
  }

  return inserted;
}

// ── Route ────────────────────────────────────────────────────────────────────

export function createUazapiWebhookRoutes(pool) {
  // POST /api/uazapi/send-text — envia mensagem de texto via uazapi
  // GET /api/uazapi/capable-units — lista unidades com token uazapi ativo
  // Filtra pelas unidades às quais o usuário tem acesso.
  router.get('/capable-units', requireAuth, async (req, res) => {
    try {
      const { isAdmin, allowedUnitIds, currentUnitId } = req.currentUser || {};

      let rows;
      if (isAdmin) {
        const r = await pool.query(`
          SELECT c.id AS unit_id, COALESCE(c.nome_fantasia, c.razao_social) AS unit_name
          FROM companies c
          JOIN unit_whatsapp_credentials w ON w.unit_id = c.id
          WHERE w.uazapi_token_encrypted IS NOT NULL AND w.uazapi_token_encrypted <> ''
          ORDER BY unit_name
        `);
        rows = r.rows;
      } else {
        const allowed = [...(Array.isArray(allowedUnitIds) ? allowedUnitIds : []), currentUnitId].filter(Boolean);
        if (allowed.length === 0) return res.json({ units: [] });
        const placeholders = allowed.map((_, i) => `$${i + 1}`).join(',');
        const r = await pool.query(`
          SELECT c.id AS unit_id, COALESCE(c.nome_fantasia, c.razao_social) AS unit_name
          FROM companies c
          JOIN unit_whatsapp_credentials w ON w.unit_id = c.id
          WHERE c.id IN (${placeholders})
            AND w.uazapi_token_encrypted IS NOT NULL AND w.uazapi_token_encrypted <> ''
          ORDER BY unit_name
        `, allowed);
        rows = r.rows;
      }
      return res.json({ units: rows });
    } catch (err) {
      logger.error(`[uazapi capable-units] Erro: ${err.message}`);
      return res.status(500).json({ error: 'Erro interno' });
    }
  });

  // POST /api/uazapi/sync-contact — mini-sync de mensagens de hoje para um número
  // Chamado pelo ProspeccaoPanel ao abrir uma conversa uazapi (fire-and-forget).
  router.post('/sync-contact', requireAuth, async (req, res) => {
    const { phone, unitId } = req.body || {};
    if (!phone || !unitId) return res.status(400).json({ error: 'phone e unitId são obrigatórios.' });

    // Verificação IDOR: não-admins só podem sincronizar unidades permitidas.
    const { isAdmin, allowedUnitIds, currentUnitId } = req.currentUser || {};
    if (!isAdmin) {
      const allowed = [...(Array.isArray(allowedUnitIds) ? allowedUnitIds : []), currentUnitId].filter(Boolean);
      if (!allowed.includes(unitId)) return res.status(403).json({ error: 'Acesso negado.' });
    }

    // Responde imediatamente; sincronização ocorre em background.
    res.json({ ok: true, status: 'syncing' });

    setImmediate(async () => {
      try {
        const inserted = await syncContactMessages(pool, { phone, unitId });
        if (inserted > 0) {
          logger.info(`[uazapi sync-contact] ${inserted} msg(s) novas para ${phone} (unit=${unitId}).`);
          try { emitGotalkNewMessage({ source: 'uazapi', unitId }); } catch { /* non-fatal */ }
        }
      } catch (err) {
        logger.warn(`[uazapi sync-contact] Erro: ${err.message}`);
      }
    });
  });

  // POST /api/uazapi/send-text — envia mensagem de texto via uazapi
  router.post('/send-text', requireAuth, async (req, res) => {
    const { unitId, phone, text, instanceId } = req.body || {};

    if (!unitId || typeof unitId !== 'string') {
      return res.status(400).json({ error: 'Campo unitId obrigatório.' });
    }
    if (!phone || typeof phone !== 'string' || !/\d{8,}/.test(phone.replace(/\D/g, ''))) {
      return res.status(400).json({ error: 'Campo phone inválido.' });
    }
    if (!text || typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({ error: 'Campo text obrigatório.' });
    }

    // Controle de acesso por unidade (IDOR): admin pode qualquer unidade;
    // demais usuários apenas unidades permitidas pelo JWT.
    const { isAdmin, allowedUnitIds, currentUnitId } = req.currentUser || {};
    if (!isAdmin) {
      const allowed = Array.isArray(allowedUnitIds) ? allowedUnitIds : [];
      if (!allowed.includes(unitId) && currentUnitId !== unitId) {
        return res.status(403).json({ error: 'Acesso negado a esta unidade.' });
      }
    }

    try {
      const msg = await sendTextViaUazapi(pool, unitId, phone, text.trim(), instanceId || null);
      return res.json({ ok: true, message: msg });
    } catch (err) {
      const status = err.status || 500;
      logger.error(`[uazapi SendText] Erro: ${err.message}`);
      return res.status(status).json({ error: err.message });
    }
  });

  // POST /api/uazapi/send-media — envia mídia (imagem/vídeo/áudio/documento) via uazapi.
  // Body: { unitId, phone, type, file(base64|url), fileName?, mimeType?, caption?, instanceId? }
  router.post('/send-media', requireAuth, async (req, res) => {
    const { unitId, phone, instanceId, type, file, fileName, mimeType, caption } = req.body || {};

    if (!unitId || typeof unitId !== 'string') {
      return res.status(400).json({ error: 'Campo unitId obrigatório.' });
    }
    if (!phone || typeof phone !== 'string' || !/\d{8,}/.test(phone.replace(/\D/g, ''))) {
      return res.status(400).json({ error: 'Campo phone inválido.' });
    }
    if (!file || typeof file !== 'string') {
      return res.status(400).json({ error: 'Campo file obrigatório.' });
    }

    // Controle de acesso por unidade (IDOR).
    const { isAdmin, allowedUnitIds, currentUnitId } = req.currentUser || {};
    if (!isAdmin) {
      const allowed = Array.isArray(allowedUnitIds) ? allowedUnitIds : [];
      if (!allowed.includes(unitId) && currentUnitId !== unitId) {
        return res.status(403).json({ error: 'Acesso negado a esta unidade.' });
      }
    }

    try {
      const msg = await sendMediaViaUazapi(
        pool, unitId, phone,
        { type, file, fileName, mimeType, caption },
        instanceId || null,
      );
      return res.json({ ok: true, message: msg });
    } catch (err) {
      const status = err.status || 500;
      logger.error(`[uazapi SendMedia] Erro: ${err.message}`);
      return res.status(status).json({ error: err.message });
    }
  });

  // Register both /webhook and /webhook/:path* to handle uazapi's addUrlEvents/addUrlTypesMessages
  // feature, which appends {evento}/{tipodemensagem} as path segments to the webhook URL.
  // Note: path-to-regexp v8+ does not support bare /webhook/* — use named wildcard instead.
  async function webhookHandler(req, res) {
    await dispatchWebhookEvent(pool, req.body, req, res);
  }

  // ====== OLD webhookHandler replaced by dispatchWebhookEvent above ======
  // The old inline implementation (200+ lines) has been replaced by the
  // dispatchWebhookEvent function defined at the top of this file.  It
  // provides the same behaviour but with a clean separation of concerns:
  //   1. extractInstanceIdentifier
  //   2. resolveWebhookCredentials
  //   3. EVENT_DISPATCH_TABLE
  //   4. dispatchWebhookEvent
  // ====== end of replacement ======

  // Register /webhook and sub-paths to handle uazapi's addUrlEvents/addUrlTypesMessages
  // which appends {evento}/{tipodemensagem} as path segments to the webhook base URL.
  // path-to-regexp v8+ does not support bare wildcards (/webhook/*) — explicit params used instead.
  router.post('/webhook', webhookHandler);
  router.post('/webhook/:p1', webhookHandler);
  router.post('/webhook/:p1/:p2', webhookHandler);

  // GET /api/uazapi/webhook-log — últimos 50 eventos recebidos pelo webhook (admin-only).
  // Permite que operadores verifiquem se o uazapi SaaS está chamando o endpoint
  // sem precisar acessar os logs do servidor.
  router.get('/webhook-log', requireAuth, (req, res) => {
    const { isAdmin } = req.currentUser || {};
    if (!isAdmin) return res.status(403).json({ error: 'Acesso restrito a administradores.' });
    res.json({ events: _webhookLog, total: _webhookLog.length });
  });

  return router;
}

// ── Helpers de chamada ────────────────────────────────────────────────────────

/**
 * Extrai dados de chamada do payload do webhook (3 formatos diferentes).
 */
function extractCallFromWebhook(payload, event) {
  let callRaw = null;

  if (payload.call && typeof payload.call === 'object') {
    callRaw = payload.call;
  } else if (payload.data?.call && typeof payload.data.call === 'object') {
    callRaw = payload.data.call;
  } else if (payload.messageType === 'call') {
    callRaw = payload.data || payload;
  } else if (event.includes('call')) {
    callRaw = payload.data || payload;
  }

  if (!callRaw) return null;

  const callId = callRaw.callId || callRaw.id || callRaw.call_id || null;
  const from = callRaw.from || callRaw.fromNumber || callRaw.callerJid || payload.from || null;
  const to = callRaw.to || callRaw.toNumber || payload.to || null;
  const isVideo = !!(callRaw.isVideo || callRaw.video || String(callRaw.type || '').toLowerCase().includes('video'));
  const type = isVideo ? 'video' : 'audio';
  const duration = Number(callRaw.duration || 0);
  const ts = callRaw.timestamp || callRaw.ts || Math.floor(Date.now() / 1000);

  let status = 'missed';
  const evName = (event + ' ' + String(callRaw.status || '')).toLowerCase();
  if (/accept|receiv|answered/.test(evName)) status = 'received';
  else if (/reject|decline|busy/.test(evName)) status = 'rejected';
  else if (/timeout|missed|no_answer|offer|ring/.test(evName)) status = 'missed';

  return { callId, from: String(from || '').split('@')[0] || null, to: String(to || '').split('@')[0] || null, type, status, duration, ts: Number(ts) };
}

/**
 * Faz upsert em whatsapp_call_logs (dedup por unitId + callId).
 */
async function upsertCallLog(pool, unitId, callData, rawPayload) {
  try {
    if (callData.callId) {
      await pool.query(
        `INSERT INTO whatsapp_call_logs
           (unit_id, call_id, from_number, to_number, type, status, duration, ts, raw)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
         ON CONFLICT (unit_id, call_id) DO UPDATE
           SET status = EXCLUDED.status,
               duration = GREATEST(whatsapp_call_logs.duration, EXCLUDED.duration),
               raw = EXCLUDED.raw`,
        [unitId, callData.callId, callData.from, callData.to, callData.type, callData.status, callData.duration, callData.ts, JSON.stringify(rawPayload)]
      );
    } else {
      await pool.query(
        `INSERT INTO whatsapp_call_logs
           (unit_id, from_number, to_number, type, status, duration, ts, raw)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
        [unitId, callData.from, callData.to, callData.type, callData.status, callData.duration, callData.ts, JSON.stringify(rawPayload)]
      );
    }
    logger.info(`[uazapi Webhook] Call log salvo (unit=${unitId}, from=${callData.from}, status=${callData.status}).`);
  } catch (err) {
    logger.error(`[uazapi Webhook] Erro ao salvar call log: ${err.message}`);
  }
}

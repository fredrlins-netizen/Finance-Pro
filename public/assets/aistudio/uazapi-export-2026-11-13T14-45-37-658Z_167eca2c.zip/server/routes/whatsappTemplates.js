import { createCrudRoutes } from './crudFactory.js';

const VALID_AREAS = ['COBRANCA_COORD', 'COBRANCA_OP', 'ADMISSAO', 'JURIDICO', 'NEGOCIACAO'];

function serializeVariables(data) {
  if (data.variables !== undefined && typeof data.variables !== 'string') {
    data.variables = JSON.stringify(data.variables);
  }
  return data;
}

export function createWhatsappTemplatesRoutes(pool) {
  return createCrudRoutes(pool, {
    table: 'whatsapp_templates',
    columns: ['name', 'area', 'template_text', 'variables', 'active'],
    requiredFields: ['name', 'area', 'template_text'],
    searchColumns: ['name', 'area'],
    defaultSort: 'area',
    defaultOrder: 'ASC',
    disableAudit: true,
    beforeCreate: async (data) => {
      if (data.area && !VALID_AREAS.includes(data.area)) {
        throw Object.assign(new Error(`area inválida. Aceitos: ${VALID_AREAS.join(', ')}`), { statusCode: 400 });
      }
      return serializeVariables(data);
    },
    beforeUpdate: async (data) => {
      if (data.area && !VALID_AREAS.includes(data.area)) {
        throw Object.assign(new Error(`area inválida. Aceitos: ${VALID_AREAS.join(', ')}`), { statusCode: 400 });
      }
      return serializeVariables(data);
    },
  });
}

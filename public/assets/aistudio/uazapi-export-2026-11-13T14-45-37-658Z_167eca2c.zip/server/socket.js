/**
 * Socket.io server — tempo real para o CRM FinancePro / Invicta
 *
 * Responsabilidades:
 *  - Autenticação via cookie JWT (mesmo mecanismo das rotas HTTP)
 *  - Atribuição de sala por usuário: "user:{id}"
 *  - Rastreamento de presença (usuários online)
 *  - LISTEN/NOTIFY do PostgreSQL para receber eventos do WhatsApp Worker
 *    sem polling e sem Redis
 */

import { Server } from 'socket.io';
import { createAdapter } from '@socket.io/redis-adapter';
import { getRedisConnection, getRedisSubConnection } from './queues/connection.js';
import pg from 'pg';
import jwt from 'jsonwebtoken';
import { COOKIE_NAME } from './routes/auth.js';
import { hasCurrentSessionVersion, validateOpenSession } from './lib/sessionVersion.js';
import { runtimeDatabaseUrl } from './db.js';
import { invalidateCollectionSummaryCache } from './routes/admissions.js';
import { observeSocketLifetime } from './lib/attachmentMetrics.js';

let io = null;

/**
 * Inicializa o servidor Socket.io acoplado a um servidor HTTP existente.
 * Deve ser chamado após initDB(), pois precisa do pool e do httpServer.
 *
 * @param {import('http').Server} httpServer
 * @param {import('pg').Pool} pool
 * @returns {import('socket.io').Server}
 */
export async function initSocketServer(httpServer, pool) {
  io = new Server(httpServer, {
    path: '/socket.io',
    transports: ['websocket', 'polling'],
    cors: { origin: false },
    pingTimeout: 60000,
    pingInterval: 25000,
  });

  // ── Redis Adapter (opcional) ──────────────────────────────────────────────
  // Quando REDIS_URL está configurado, usa o adapter Redis para que presença
  // e salas funcionem corretamente em múltiplas instâncias / após reinicios.
  // Reutiliza a conexão IORedis singleton de server/queues/connection.js —
  // sem cliente redis separado (node-redis eliminado).
  const pubClient = getRedisConnection();
  if (pubClient) {
    try {
      const subClient = getRedisSubConnection();
      io.adapter(createAdapter(pubClient, subClient));
      console.log('[Socket.io] Redis Adapter ativo (ioredis).');
    } catch (err) {
      console.warn('[Socket.io] Redis Adapter falhou, usando memória local:', err.message);
    }
  }

  // ── Middleware de autenticação ────────────────────────────────────────────
  io.use(async (socket, next) => {
    const secret = process.env.JWT_SECRET;
    if (!secret) return next(new Error('Erro de configuração do servidor'));

    const cookieHeader = socket.handshake.headers.cookie || '';
    const cookieMap = Object.fromEntries(
      cookieHeader.split(';').map(c => {
        const idx = c.indexOf('=');
        if (idx === -1) return [c.trim(), ''];
        return [c.slice(0, idx).trim(), c.slice(idx + 1).trim()];
      })
    );

    const token = cookieMap[COOKIE_NAME];
    if (!token) return next(new Error('Autenticação necessária'));

    try {
      const payload = jwt.verify(token, secret);
      if (!await hasCurrentSessionVersion(pool, payload)) {
        return next(new Error('Sessão inválida ou expirada'));
      }
      socket.userId    = payload.userId;
      socket.userName  = payload.userName;
      socket.userRole  = payload.userRole;
      socket.groupIds  = Array.isArray(payload.groupIds) ? payload.groupIds : [];
      socket.sessionVersion = payload.sessionVersion;
      next();
    } catch {
      next(new Error('Sessão inválida ou expirada'));
    }
  });

  // ── Handler de conexão ───────────────────────────────────────────────────
  io.on('connection', (socket) => {
    observeSocketLifetime(socket);
    socket.join(`user:${socket.userId}`);

    _broadcastPresence();

    socket.on('disconnect', () => {
      setTimeout(_broadcastPresence, 2000);
    });
  });

  const sessionValidationInterval = setInterval(async () => {
    const sockets = Array.from(io.of('/').sockets.values());
    await Promise.all(sockets.map(async socket => {
      await validateOpenSession(
        pool,
        {
          userId: socket.userId,
          sessionVersion: socket.sessionVersion,
        },
        () => socket.disconnect(true)
      );
    }));
  }, 5000);
  sessionValidationInterval.unref();

  // ── LISTEN no PostgreSQL para mensagens GoTalk ───────────────────────────
  _setupPgListener(pool);

  console.log('[Socket.io] Servidor inicializado.');
  return io;
}

/** Retorna a instância io singleton (após initSocketServer). */
export function getIO() {
  return io;
}

/** Retorna IDs únicos de usuários conectados via Socket.io. */
export function getOnlineUserIds() {
  if (!io) return [];
  const ids = new Set();
  for (const [, socket] of io.of('/').sockets) {
    if (socket.userId) ids.add(socket.userId);
  }
  return Array.from(ids);
}

/**
 * Emite gotalk:new_message para todos os clientes conectados.
 * Chamado pelo handler de NOTIFY do PostgreSQL.
 */
export function emitGotalkNewMessage(payload) {
  if (!io) return;
  io.emit('gotalk:new_message', payload);
}

/**
 * Emite gotalk:ack_update para todos os clientes conectados.
 * Chamado após atualização de ack_status no processStatusEvent do uazapi webhook.
 * payload: { messageId: string, ack: number, phone: string | null }
 */
export function emitGotalkAckUpdate(payload) {
  if (!io) return;
  io.emit('gotalk:ack_update', payload);
}

/** Notifica somente a sala privada do autor da operação cancelada. */
export function emitBucketAdminCancellation(payload) {
  if (!io || !payload?.authorId) return;
  io.to(`user:${payload.authorId}`).emit('bucket-admin:operation-cancelled', payload);
}

/** Emite a lista de usuários online para todos os clientes. */
function _broadcastPresence() {
  if (!io) return;
  io.emit('presence:update', { onlineUserIds: getOnlineUserIds() });
}

/**
 * Configura um cliente PostgreSQL dedicado (não-pooled) para LISTEN/NOTIFY.
 * O WhatsApp Worker envia NOTIFY gotalk_new_message após salvar nova mensagem.
 * Ao receber a notificação, emitimos via Socket.io para o frontend. O registro do
 * contato em prospection_contacts é feito pelo trigger de banco trg_sync_prospection_gotalk.
 *
 * @param {import('pg').Pool} pool — pool compartilhado do CRM
 */
function _setupPgListener(pool) {
  const client = new pg.Client({
    connectionString: runtimeDatabaseUrl,
    application_name: 'crm_socket_listener',
  });

  async function connect() {
    try {
      await client.connect();
      await client.query('LISTEN gotalk_new_message');
      await client.query('LISTEN dashboard_invalidation');
      console.log('[Socket.io] PostgreSQL LISTEN gotalk_new_message ativo.');

      client.on('notification', (msg) => {
        if (msg.channel === 'dashboard_invalidation') {
          try {
            const payload = msg.payload ? JSON.parse(msg.payload) : null;
            const allowedDomains = new Set(['finance', 'prospection', 'legal', 'collection']);
            if (payload && allowedDomains.has(payload.domain)) {
              if (payload.domain === 'collection') invalidateCollectionSummaryCache();
              // This event is only an invalidation hint. Never include row data;
              // each connected client refetches through its authorized API.
              io?.emit('dashboard:invalidate', { domain: payload.domain });
            }
          } catch (err) {
            console.warn('[Socket.io] Invalid dashboard invalidation payload:', err.message);
          }
          return;
        }
        try {
          const payload = msg.payload ? JSON.parse(msg.payload) : {};

          // GoTalk contacts are synced into prospection_contacts by the DB trigger
          // `trg_sync_prospection_gotalk` (migration 043), which fires on every
          // inserted incoming gotalk_messages row. We no longer upsert here to
          // avoid double-counting total_contacts. This listener only relays the
          // realtime event to the frontend.
          emitGotalkNewMessage(payload);
        } catch {
          emitGotalkNewMessage({});
        }
      });

      client.on('error', (err) => {
        console.warn('[Socket.io] Erro no listener PG, reconectando em 5s:', err.message);
        setTimeout(reconnect, 5000);
      });
    } catch (err) {
      console.warn('[Socket.io] Falha ao conectar listener PG, tentando em 5s:', err.message);
      setTimeout(reconnect, 5000);
    }
  }

  async function reconnect() {
    try { await client.end(); } catch {}
    const fresh = new pg.Client({
      connectionString: runtimeDatabaseUrl,
      application_name: 'crm_socket_listener',
    });
    Object.assign(client, fresh);
    await connect();
  }

  connect();
}

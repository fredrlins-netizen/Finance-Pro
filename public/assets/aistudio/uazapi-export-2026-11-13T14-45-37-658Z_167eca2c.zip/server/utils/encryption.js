/**
 * Utilitário de criptografia reversível AES-256-GCM.
 * Usado para armazenar tokens de terceiros (ex: uazapi) de forma
 * que possam ser recuperados pelo backend para chamadas de API.
 *
 * A chave é derivada de ENCRYPTION_KEY (env) ou, como fallback
 * de desenvolvimento, de JWT_SECRET. Em produção, defina ENCRYPTION_KEY
 * como um valor aleatório de 32+ bytes.
 */

import crypto from 'crypto';

function deriveKey() {
  // 🔒 SEGURANÇA [VULN-10]: removido o fallback para JWT_SECRET. Reutilizar o segredo
  // do JWT como chave de criptografia acopla dois segredos de propósitos distintos —
  // um único leak comprometeria sessões E tokens WhatsApp simultaneamente (CWE-321).
  // ENCRYPTION_KEY é obrigatório em TODOS os ambientes; falha explícita se ausente.
  const raw = process.env.ENCRYPTION_KEY || '';
  if (!raw) {
    throw new Error('[Encryption] ENCRYPTION_KEY deve estar definido (gere com: openssl rand -hex 32).');
  }
  return crypto.createHash('sha256').update(raw).digest(); // 32 bytes para AES-256
}

/**
 * Criptografa um valor em plain text.
 * Retorna uma string no formato: iv:authTag:ciphertext (hex:hex:hex).
 */
export function encrypt(plaintext) {
  if (!plaintext) return null;
  const key = deriveKey();
  const iv = crypto.randomBytes(12); // 96-bit IV para GCM
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const authTag = cipher.getAuthTag();
  return [iv.toString('hex'), authTag.toString('hex'), encrypted.toString('hex')].join(':');
}

/**
 * Express middleware — exige ENCRYPTION_KEY dedicada em produção.
 *
 * Se NODE_ENV=production e ENCRYPTION_KEY não está configurado, retorna 503
 * para todos os endpoints que dependem de criptografia de credenciais.
 * Em desenvolvimento, o fallback para JWT_SECRET é permitido.
 */
export function requireEncryptionKey(req, res, next) {
  if (process.env.NODE_ENV === 'production' && !process.env.ENCRYPTION_KEY) {
    return res.status(503).json({
      error: 'Serviço temporariamente indisponível.',
      detail: 'ENCRYPTION_KEY não configurado. Defina esta variável nos Secrets antes de usar integrações WhatsApp em produção.'
    });
  }
  next();
}

/**
 * Descriptografa um valor produzido por `encrypt`.
 * Retorna o plain text original, ou null se o input for null/inválido.
 */
export function decrypt(stored) {
  if (!stored) return null;
  try {
    const [ivHex, authTagHex, dataHex] = stored.split(':');
    if (!ivHex || !authTagHex || !dataHex) return null;
    const key = deriveKey();
    const iv = Buffer.from(ivHex, 'hex');
    const authTag = Buffer.from(authTagHex, 'hex');
    const data = Buffer.from(dataHex, 'hex');
    const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
    decipher.setAuthTag(authTag);
    return Buffer.concat([decipher.update(data), decipher.final()]).toString('utf8');
  } catch {
    return null;
  }
}

/**
 * Base de conhecimento dinâmica do Léo.
 * Compila o conhecimento sobre o sistema a partir de replit.md e dos módulos de treinamento.
 * Carregada uma vez no startup e re-carregada a cada 6h para absorver atualizações.
 *
 * getRelevantArticles(question, pool) — busca top-5 artigos da tabela leo_knowledge_articles
 * por correspondência de palavras-chave (ILIKE), retornando título, conteúdo e imagens.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let _knowledgeCache = null;
let _lastLoaded = 0;
const CACHE_TTL_MS = 6 * 60 * 60 * 1000; // 6 horas

// Cache for knowledge articles (invalidated on write)
let _articlesCache = null;
let _articlesLastLoaded = 0;
const ARTICLES_CACHE_TTL_MS = 10 * 60 * 1000; // 10 minutos

function loadReplitMd() {
  try {
    const replitMdPath = path.join(__dirname, '..', '..', 'replit.md');
    if (fs.existsSync(replitMdPath)) {
      return fs.readFileSync(replitMdPath, 'utf8');
    }
  } catch (err) {
    console.error('[TrainingKnowledge] Erro ao ler replit.md:', err.message);
  }
  return '';
}

function buildSystemPrompt(replitMdContent) {
  return `Você é o Léo, o assistente de treinamento e suporte do sistema FinancePro Assessoria.

REGRA ABSOLUTA: Você SOMENTE responde perguntas relacionadas ao uso, funcionamento, módulos, campos, fluxos e configurações do sistema FinancePro. Se o usuário perguntar qualquer coisa fora deste contexto (notícias, piadas, outros sistemas, informações gerais, etc.), responda educadamente:
"Desculpe, só posso ajudar com dúvidas sobre o sistema FinancePro Assessoria. Tem alguma dúvida sobre como usar algum módulo?"

PERSONALIDADE:
- Amigável, paciente e encorajador
- Use linguagem simples e direta em português
- Quando explicar passo a passo, numere os passos
- Se relevante, mencione atalhos ou dicas úteis
- Formate respostas com **negrito** para termos importantes
- Quando sua resposta for baseada em um artigo da base de conhecimento, mencione: "De acordo com o artigo '[título do artigo]'..."

CONHECIMENTO DO SISTEMA (documentação completa):
${replitMdContent.substring(0, 50000)}

MÓDULOS PRINCIPAIS DO SISTEMA:
- **Home/Dashboard**: Visão geral com indicadores
- **Agenda**: Agendamento de atendimentos com controle de unidade, fila de espera e drag-and-drop
- **Cadastros Comuns**: Clientes, Cargos, Colaboradores, Departamentos, Bancos, Modalidades, Produtos, Série/Números
- **Atendimento > Comercial**: Prospecção, Admissão (fluxo completo de cadastro com tabela de serviços), Negociação
- **Atendimento > Auditoria**: Gestão do processo de auditoria de clientes
- **Atendimento > Jurídico**: Processos jurídicos de clientes
- **Acompanhamento Jurídico**: Dashboard, Processos da empresa, Prazos e Audiências
- **Financeiro**: Cadastros financeiros, Conta Corrente (cadastro/movimento/conciliação), Contas a Receber, Contas a Pagar, Gerenciamento
- **Cobrança**: Painel do Coordenador e Operacional
- **Negociação (Financeiro)**: Gestão de negociações de dívidas
- **Relatórios**: Consultas, Formulários (editor com TinyMCE), Relatórios Gerais (ReportBuilder)
- **Mensagens**: Sistema interno estilo WhatsApp (diretas, grupos, broadcast)
- **Conversas WhatsApp**: Integração GoTalk/uazapi
- **IA & Análise**: Assistente inteligente para análise de dados e relatórios (este módulo)
- **Configurações**: Portal, Unidades, Usuários, E-mail, Integrações, Auditoria, Ajuda

Para cada módulo, você sabe explicar: como acessar, quais campos existem, como criar/editar/excluir registros, filtros disponíveis, status possíveis, permissões necessárias e casos de uso comuns.`;
}

function getTrainingKnowledge() {
  const now = Date.now();
  if (_knowledgeCache && (now - _lastLoaded) < CACHE_TTL_MS) {
    return _knowledgeCache;
  }

  const replitMdContent = loadReplitMd();
  _knowledgeCache = buildSystemPrompt(replitMdContent);
  _lastLoaded = now;
  return _knowledgeCache;
}

/**
 * Invalida o cache de artigos — chamado após criar/editar/excluir artigos.
 */
function invalidateArticlesCache() {
  _articlesCache = null;
  _articlesLastLoaded = 0;
}

/**
 * Busca os top-5 artigos mais relevantes para a pergunta do usuário.
 * Usa matching de palavras-chave (ILIKE) em título e conteúdo.
 * Retorna título, conteúdo de texto e imagens (base64 + mimeType).
 *
 * @param {string} question - Pergunta do usuário
 * @param {import('pg').Pool} pool - PostgreSQL pool
 * @returns {Promise<Array<{title: string, category: string, content: string, images: Array}>>}
 */
async function getRelevantArticles(question, pool) {
  if (!pool) return [];

  try {
    const now = Date.now();

    // Serve from cache if still fresh
    if (_articlesCache && (now - _articlesLastLoaded) < ARTICLES_CACHE_TTL_MS) {
      return scoreArticles(_articlesCache, question);
    }

    // Load all active articles (with images) from DB
    const result = await pool.query(`
      SELECT id, title, category, content, images
      FROM leo_knowledge_articles
      WHERE active = TRUE
      ORDER BY updated_at DESC
    `);

    _articlesCache = result.rows;
    _articlesLastLoaded = now;

    return scoreArticles(_articlesCache, question);
  } catch (err) {
    console.error('[TrainingKnowledge] getRelevantArticles error:', err.message);
    return [];
  }
}

/**
 * Scores articles by keyword frequency and returns top-5.
 */
function scoreArticles(articles, question) {
  if (!articles || articles.length === 0) return [];

  // Extract meaningful words (>= 3 chars) from the question
  const words = question
    .toLowerCase()
    .replace(/[^\wàáâãäéêëíïóôõöúüçñ\s]/gi, ' ')
    .split(/\s+/)
    .filter(w => w.length >= 3);

  if (words.length === 0) return articles.slice(0, 3);

  const scored = articles.map(article => {
    const haystack = `${article.title} ${article.category} ${article.content}`.toLowerCase();
    const score = words.reduce((acc, word) => {
      // Title matches weigh 3x, content matches weigh 1x
      const titleOccurrences = (article.title.toLowerCase().match(new RegExp(word, 'g')) || []).length * 3;
      const contentOccurrences = (haystack.match(new RegExp(word, 'g')) || []).length;
      return acc + titleOccurrences + contentOccurrences;
    }, 0);
    return { article, score };
  });

  return scored
    .filter(s => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .map(s => s.article);
}

export { getTrainingKnowledge, getRelevantArticles, invalidateArticlesCache };

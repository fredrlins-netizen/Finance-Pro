# FinancePro Assessoria

## Overview
CRM completo para assessoria financeira, com módulos de cadastros, comercial, financeiro, jurídico, cobrança, negociação, agenda, mensagens internas e WhatsApp.

## User Preferences
- Comunicação clara e concisa. Perguntar antes de mudanças grandes.
- Desenvolvimento iterativo. Explicar o **"porquê"** das escolhas.
- Linguagem simples, sem jargão técnico desnecessário.

## System Architecture
- **Frontend:** React 18 + TypeScript + Vite + Tailwind CSS
- **Backend:** Express.js + PostgreSQL
- **Estilo:** Color scheme (`moss-800`, `gray-50`, `moss-500`, `blue-500`, `purple-500`), cards arredondados, selects e checkboxes customizados.
- **Moeda:** `formatCurrencyBRL` / `parseCurrencyBRL` para BRL.
- **Onboarding:** Guia interativo com avatar mascote e base de conhecimento.

## Módulos Principais
| Módulo | Descrição |
|---|---|
| **Cadastros** | Clientes, colaboradores, bancos, unidades, modalidades, produtos, séries, cargos, departamentos |
| **Comercial** | Admissões, recálculos, ficha de contrato, prospecção |
| **Financeiro** | Contas a Receber/Pagar, baixas, faturas, parcelas recorrentes, movimentação bancária |
| **Jurídico** | Acompanhamento de processos (cliente e empresa), prazos, audiências, notificações automáticas |
| **Cobrança / Negociação** | Painéis operacional e coordenador, metas, propostas |
| **Agenda** | Agendamentos com filtro por unidade, rodízio de colaboradores, drag-and-drop |
| **Mensagens** | Chat interno (estilo WhatsApp) em tempo real via SSE, com entrega/lido, anexos, grupos |
| **WhatsApp** | Integração GoTalk + uazapi (multi-canal), webhook, envio de mensagens, conversas |
| **Relatórios** | Gerador customizado com SQL, filtros, gráficos, subrelatórios, exportação (PDF/Excel/Word/CSV) |
| **Formulários** | Editor com TinyMCE, variáveis dinâmicas, integração com templates em múltiplos módulos |
| **IA** | Assistente Leo (Gemini) |

## Segurança (Zero-Trust)
- Autenticação JWT em cookie `httpOnly` + `SameSite=strict` (8h)
- Rate limiting em todos os endpoints públicos e sensíveis
- Sanitização de inputs, headers de segurança (Helmet, CSP)
- Revalidação de status de conta em escritas sensíveis
- Erros 5xx genéricos ao cliente (detalhes logados servidor)
- SQL read-only no Report Builder; não-admin não controla o SQL
- Tokens criptografados (AES-256-GCM), nunca expostos na API
- `channel_id` GoTalk resolvido server-side, nunca retornado ao frontend
- Testes de segurança: `scripts/security-tests.mjs`

## Production Checklist
| Variável | Nível | Notas |
|---|---|---|
| `APP_DB_PASSWORD` | 🔴 Obrigatório em produção | Senha da role PostgreSQL restrita `app_user` |
| `DATABASE_URL` | 🔴 Obrigatório | Destino PostgreSQL gerenciado pelo Replit |
| `JWT_SECRET` | 🔴 Obrigatório | Mínimo 32 bytes aleatórios |
| `ENCRYPTION_KEY` | 🟡 Altamente recomendado | Diferente de JWT_SECRET |
| `REDIS_URL` | 🟡 Altamente recomendado | Jobs perdidos no restart sem Redis |
| `ALLOWED_ORIGINS` | 🟡 Altamente recomendado | Origens permitidas (CORS) |
| `BULL_BOARD_USER` | 🟡 Recomendado | Painel `/admin/filas` |
| `GOTALK_LOGIN` / `GOTALK_PASSWORD` | ⚪ Opcional | WhatsApp GoTalk |
| `GEMINI_API_KEY` | ⚪ Opcional | IA Léo |

**Deploy:** `autoscale` em `.replit`. `npm run start` inicia servidor único (Express + Worker embedded em produção). Em produção gerenciada, o Publish aplica o diff de schema; o startup apenas valida as dependências, sem executar migrations.

**Checagem obrigatória antes de toda publicação:** antes de preparar ou recomendar uma publicação, carregar `.agents/skills/permissoes-pre-publicacao/SKILL.md` e validar as permissões efetivas da role de runtime no desenvolvimento e na produção. Não presumir que o Publish transporta grants de roles personalizadas. Informar e resolver pendências antes de recomendar publicação; objetos novos ainda ausentes exigem nova checagem após a criação pelo Publish. Esta regra orienta o agente, não intercepta publicações manuais nem autoriza hooks ou escritas diretas na produção.

## Roadmap de Refatoração
- `FinancialPanel` ✅ (3,774 → 400 linhas)
- `SettingsPanel` 🔧 (~2,378 linhas, tabs extraídas em progresso)
- `AccountsPayableManager` ⏳ (~2,486 linhas)
- `NegotiationPanel` ⏳ (~1,689 linhas)
- `SchedulerPanel` ⏳ (~2,056 linhas)

---

*Detalhes técnicos completos (migrations, changelog histórico, arquitetura de APIs) estão em `docs/`.*

# 5. Documentos armazenados, seleção, exclusão e permissões

## 5.1 Contexto e distinção dos anexos da nota
Na lateral do título monta ClientAttachmentsPanel com clientId, module=**COLLECTION_PROSPECTION**, targetType=**FINANCIAL_TITLE**, targetId=activeTitle.id e compact.

Não informa readOnly (padrão false), mas também **não informa allowUpload, cujo padrão é false**. Portanto pode haver seleção/exclusão e controles administrativos permitidos, mas **não aparece Anexar arquivo nesse chamador**. Os arquivos de nova nota são outro mecanismo, FileReader+JSON no modal de contato.

Na ficha de admissão o mesmo componente é readOnly e module=ADMISSION; os controles abaixo de escrita/ACL não aparecem naquele contexto.

## 5.2 Lista, pesquisa e leitura
Cabeçalho **Documentos armazenados**; subtítulo **Anexos classificados por cliente, separados dos anexos legados.**; contador.

GET `/api/client-attachments/` com clientId, module, targetType, targetId, search, limit=**25** e cursor. **Filtrar...**, inicialmente vazio, após 300 ms atualiza query e volta à primeira página. **Atualizar** recarrega página atual.

Cada item: checkbox; indicador PDF/DOC; originalFilename; category ou **Sem categoria**; nome do módulo; tamanho (KB arredondado para cima ou MB com uma casa; ausente travessão); aviso **Legado sem ACL** para admin quando aplicável.

**Ver** só para imagem/PDF: abre `/api/client-attachments/:id/content?browser=1` em nova aba. **Baixar**: `/api/client-attachments/:id/download?browser=1`. Entrega por navegador/stream autenticado, sem criar Blob integral no cliente.

Estados carregando, erro, **Nenhum documento encontrado.** com busca ou **Nenhum documento armazenado para este contexto.** sem busca. Paginação Anterior/Próxima por cursor, página e faixa de registros; limites/bloqueio em carregamento.

## 5.3 Seleção e exclusão
Checkbox individual e **Selecionar todos os anexos exibidos**. Seleção é mantida entre páginas por Set/Map e limpa ao trocar cliente. **Excluir selecionados (N)** usa os itens selecionados; **Excluir** por item inicia a mesma confirmação.

Confirmação inline **Confirmar exclusão de anexos** lista cliente, quantidade e nomes, avisa perda permanente; botões **Confirmar exclusão/Cancelar**, bloqueados enquanto exclui. Faz um DELETE `/api/client-attachments/:id` por item; mantém selecionados os que falharam e informa quantidade/nomes das falhas; recarrega lista.

Não há renomear ou editar descrição nesse painel. A existência dos botões não elimina controles do servidor: módulo, unidade, ACL e autorização da mutação permanecem aplicáveis.

## 5.4 Quem vê os controles de ACL
Componente testa GET `/api/client-attachments/acl/options?type=groups&limit=1`. O servidor exige **requireAdmin** nesse endpoint e nos endpoints de edição ACL/legados.

Somente quando a chamada tem sucesso accessOptionsLoaded permite **Acesso da pasta**, **Histórico ACL legado**, **Acesso** por arquivo protegido e ações de adesão legada. Não descrever isso como permissão de qualquer operador comum.

## 5.5 Modal Acesso à pasta do cliente / Acesso ao arquivo
**Acesso da pasta** carrega GET `/api/client-attachments/acl/folders/:clientId`. **Acesso** por arquivo carrega GET `/api/client-attachments/acl/files/:attachmentId`.

Campos:
- **Grupos**: seletor pesquisável, IDs múltiplos, busca por nome do grupo.
- **Usuários**: seletor pesquisável, IDs múltiplos, busca por nome/e-mail.
- **Ativar exceção para este arquivo e substituir a regra da pasta**: checkbox só no arquivo, inicial conforme overrideEnabled recebido.

Defaults vêm da configuração carregada; não há destinatários fixos inventados. Opções consultam `/api/client-attachments/acl/options` por type/search/offset/limit=50 e IDs já selecionados. Checkboxes alternam destinatário; chips removem; **Carregar mais resultados** pagina opções. Estados de carregamento, erro e nenhum destinatário.

Sem grupos/usuários selecionados avisa **somente administradores terão acesso**. Exceção desativada limpa listas e herda pasta; ativada substitui destinatários da pasta, sem contornar módulo/unidade.

**Salvar permissões** faz PUT do alvo:
- Pasta: groupIds e userIds.
- Arquivo: overrideEnabled, groupIds/userIds só se exceção ativa; senão [].

Bloqueia salvar até terminar carregamento/ficar pronto e durante envio; erro mantém modal. Cancelar/X fecham sem salvar, indisponíveis durante envio.

## 5.6 Proteção de anexos legados
Admin pode ver contador de legados sem ACL; **Selecionar legados exibidos** adiciona os itens não protegidos da página à seleção. **Proteger selecionados (N)** só considera legados do cliente; acima de 500 desabilita e orienta selecionar até 500.

Abre **Confirmar proteção de anexos legados**; busca impacto atualizado em GET `/api/client-attachments/acl/legacy/:clientId/impact`. Exibe selecionados/total de legados, nomes, módulo/categoria, existência de regra da pasta e quantidades de grupos/usuários.

Sem pasta configurada bloqueia confirmação e oferece **Configurar regra da pasta**. Regra sem destinatários avisa acesso só a administradores. **Confirmar proteção (N)** faz POST `/acl/legacy/:clientId/protect` com attachmentIds; requer itens e pasta configurada; limpa os selecionados adotados, atualiza contagem/lista. **Cancelar/X/fundo** fecham quando não salva.

Adesão afeta só arquivos selecionados, acrescenta exigência da pasta e não amplia permissões de módulo/unidade.

## 5.7 Histórico ACL legado e reversão
**Histórico ACL legado** abre **Histórico de proteção dos anexos legados**; GET `/acl/legacy/:clientId/protected`, limit=25 e offset. Cada item: originalFilename, módulo, categoria, adoptedByName (fallback **Usuário removido**) e adoptedAt. Contador e Anterior/Próxima; estados carregando/vazio/erro.

**Reverter proteção** abre confirmação **Reverter a proteção deste anexo?**, identifica arquivo e informa retorno às regras anteriores sem apagar registro ou objeto. **Confirmar reversão** faz DELETE `/acl/legacy/:clientId/protect/:attachmentId`; recarrega histórico/lista/impacto e ajusta página se necessário. **Cancelar** apenas fecha a confirmação.

Reversão não contorna módulo/unidade, não baixa arquivo e não o exclui. Controles ficam bloqueados durante reversão; X/fundo do histórico respeitam estado de envio.

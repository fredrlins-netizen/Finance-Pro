# 4. WhatsApp, GoTalk, uazapi e demais integrações

## 4.0 Situação real de conexão no menu atual
O ponto de montagem principal inspecionado é DashboardLayout: importa diretamente CollectionPanel e o renderiza sem gotalkEnabled, GotalkChatPanel ou GotalkConversationsTab. O pai condiciona os componentes a gotalkEnabled. Sem essas props, **a aba WhatsApp, o chat adicional e o botão/overlay de conversas não são habilitados nesse caminho**.

As seções seguintes documentam integralmente as funções já implementadas e suas condições, mas não afirmam que os botões estejam disponíveis no menu atual. Não basta existir configuração/contato GoTalk no banco para suprir props não repassadas. O carregamento do badge de mensagens e sua assinatura de socket são independentes dessas props e continuam previstos no componente.

## 4.1 Quatro acessos distintos à comunicação
1. **Aba WhatsApp do modal de contato**: UnifiedWhatsappTab por telefone; agrega mensagens GoTalk/uazapi.
2. **Chat adicional quando Forma de Contato=WHATSAPP**: GotalkChatPanel por clientId; pode coexistir com a aba unificada.
3. **Botão WhatsApp no cabeçalho do modal**: overlay GotalkConversationsTab por clientId, histórico de consulta.
4. **Mensagens internas**: notificações automáticas via MessagingContext ao salvar contatos, sem relação com selecionar o canal MENSAGEM isoladamente.

O pai só fornece GotalkChatPanel e GotalkConversationsTab se gotalkEnabled. A aba WhatsApp unificada depende da presença de GotalkChatPanel para seu botão ser mostrado, embora ela mesma use endpoint por telefone.

## 4.2 Aba WhatsApp unificada — campos, conteúdo e acionamentos
Resolve telefone do cliente por phone, senão phone1; remove não dígitos. Sem cliente mostra **Cliente não encontrado.**. Sem telefone usa o chat fallback por clientId, area=COBRANCA_OP e operatorName=currentUser.name; se nem fallback existir informa indisponibilidade.

Consulta `/api/gotalk/client-timeline?phone={digitos}&limit=200`, retornando messages. Exibe carregamento, erro ou **Nenhuma mensagem encontrada para este número.**. O frontend não implementa botões de cursor/carregar mais nessa aba, embora o endpoint tenha suporte a paginação.

Bolhas: direction OUT à direita/verde e IN à esquerda/branco; body; attachment_url como link externo com attachment_name ou **Anexo**; audio_transcript como texto; sent_at em dia/mês/hora/minuto; operador para mensagens de saída. Essa aba **não usa** GoTalkMediaRenderer, logo não herda seus players/lightbox/preview PDF. source e ack_status existem no modelo, mas não são mostrados como seletores de canal/estado nessa bolha.

Campo **Digite uma mensagem… (Enter envia, Shift+Enter quebra linha)**: vazio; trim; sem vazio/envio concorrente. **Enviar**, desabilitado sem texto ou durante envio; texto muda **Enviando…**. POST `/api/gotalk/send-text` com contactNumber e message. Sucesso adiciona mensagem otimista OUT/source=gotalk/ack_status=sent, operador e data, e limpa texto. Erro usa alert **Falha ao enviar: ...**.

Não há seletor GoTalk versus uazapi para envio nessa aba. Histórico unificado não significa roteamento de saída pelo provedor de cada mensagem.

**HSM** abre GotalkSendTemplateModal com contactPhone em dígitos e nome. Não passa modo uazapi, portanto usa o fluxo GoTalk do modal.

## 4.3 Atualização em tempo real e badges
UnifiedWhatsappTab assina socket **gotalk:new_message**. Aceita payload quando os **últimos oito dígitos** de payload.phone e telefone do cliente coincidem; cria mensagem com os dados disponíveis. Deduplica apenas por gotalk_message_id quando presente; sem esse ID, evento e mensagem otimista podem duplicar. Rola ao fim quando cresce a lista.

O backend client-timeline consultado também usa RIGHT(phone_number,8), o que não distingue DDDs com os mesmos oito dígitos finais. É limitação relevante de identidade; não foi alterada neste levantamento.

Badge do grid usa outra chave: últimos **dez dígitos** de phone/phone1. Inicializa por GET `/api/prospection/unread-counts`, somando gotalk+uazapi por chave. Eventos IN incrementam, exceto se o mesmo telefone está aberto na aba WHATSAPP do modal.

Abrir essa aba zera o badge **local**. Esse efeito não chama endpoint de marcar leitura. Não comprova atualização persistida da leitura no servidor, e novo carregamento pode trazer contagens antigas. Essas chaves não são uma normalização canônica única entre todos os fluxos.

## 4.4 GotalkChatPanel adicional ou fallback
Por clientId e area=COBRANCA_OP. Busca contato em `/api/gotalk/client/:clientId`, até 100 mensagens em `/api/gotalk/messages/:clientId?limit=100`; marca leitura por POST `/api/gotalk/messages/mark-read`. Atualiza manualmente e a cada 60 segundos.

Sem contato retorna aviso antes de renderizar os botões do chat; não assumir acesso à importação nesse estado.

Compositor de texto: Enter envia, Shift+Enter nova linha; vazio/envio concorrente impedidos. Consulta canais ativos. Resolve um atendimento aberto por clientId/status=open/limit=1. Se há ID GoTalk e telefone, POST `/api/gotalk/send-message-attendance`; senão POST `/api/gotalk/send-text` com telefone do contato. Sucesso limpa e insere mensagem otimista; falha exibe erro/toast.

**Importar histórico** abre modal com duas abas: **Por atendimento** (inicial) e **Por telefone**, campos inicialmente vazios:
- ID do atendimento GoTalk → POST `/api/gotalk/sync-attendance` com attendanceId e contactId.
- Telefone → remove não dígitos; POST `/api/gotalk/sync-by-phone` com phone; exemplo do placeholder 11999998888 ou 5511999998888.
- Confirmação usa handler da aba; mostra saved/total quando disponíveis e atualiza mensagens se salvou registros.
- Cancelar/X fecham; troca de aba limpa resultado/erro.

**Enviar template HSM** exige telefone do contato. O recurso compartilhado de vincular CRM exige `!clientId && gotalkContactId`; como Operacionais passa clientId, esse modal de vínculo não é acionável normalmente aqui.

## 4.5 Overlay de Conversas WhatsApp
Cabeçalho **Conversas WhatsApp — {cliente}**, subtítulo **Histórico de mensagens GoTalk**, botão **Voltar**. Abre portal no body, sem fechar o modal de contato subjacente.

GotalkConversationsTab busca em paralelo contato por clientId e `/api/gotalk/messages/:clientId?limit=500`. Sem vínculo mostra aviso para vincular no cadastro; não cria vínculo nesse overlay.

Campos:
- **Data Inicial**, vazio; compara dia ISO de sent_at >= início.
- **Data Final**, vazio; compara <= fim.
- **Atendente**, inicialmente Todos os atendentes; opções distintas/ordenadas de operator_name das mensagens carregadas. Sem opções usa texto “Filtrar por atendente...”.
- **Limpar filtros**, quando há filtros.
- **Atualizar**, recarrega dados e bloqueia durante refreshing.

Filtro de atendente usa substring sem diferença de maiúsculas; datas não removem mensagens sem sent_at. Contador mostra quantidade filtrada e, quando difere, total carregado. Não há paginação além dos 500 nem compositor nesse overlay.

Agrupa visualmente por dia; bolhas IN/OUT; hora; operador e departamento/area nas saídas. ACK: 1=um visto, 2=dois vistos, >=3=dois vistos azuis. Não altera ACK por clique.

## 4.6 Conteúdo de mídia no chat legado e overlay
GoTalkMediaRenderer, presente nesses caminhos mas não na aba unificada:
- TEXT: texto formatado, quebras e fallback vazio; cartões para conteúdo interativo reconhecido.
- IMAGE: imagem, legenda, lightbox por clique, fechar e download quando há proxy.
- STICKER: imagem da figurinha.
- AUDIO/VOICE/PTT: player com controles, metadados, download e transcrição recebida expansível.
- VIDEO: player com controles, metadados e download.
- DOCUMENT PDF: nome, MIME/tamanho; **Visualizar PDF/Recolher**, visualização embutida, alternativa externa/download.
- DOCUMENT outros: identificação, link/download conforme origem.
- TEMPLATE: conteúdo HSM, cabeçalho/corpo/rodapé e categoria/status quando recebidos.
- Outros: fallback textual.

Proxy por messageId: `/api/gotalk/media/:id`, download `?download=1`; sem ID depende de attachmentUrl. Não há envio de arquivo no compositor de texto apenas por existir visualizador de mídia.

## 4.7 Modal HSM — todos os campos
**Canal WhatsApp**: canais ativos de GET `/api/gotalk/channels`; padrão ativo principal ou primeiro ativo. **Template**: sem seleção inicial; GET `/api/gotalk/hsm-templates?channelUuid=...`; prefere status ausente/approved/ativo/active; se nenhum passa, usa lista retornada integralmente (não garante aprovação pelo provedor).

**Variáveis do template**: um input por índice {{n}}, inicialmente vazio, todos obrigatórios para habilitar envio. **Prévia**: textos substituídos, somente leitura. Destinatário é recebido do cliente, sem seletor próprio.

**Enviar** exige canal/template/variáveis e bloqueia durante envio. POST `/api/gotalk/send-active-notification`, corpo channelUuid, phone, contactName (fallback Contato), templateId do provedor e tag de variáveis quando existem. Sucesso informa e fecha após cerca de 2 segundos; erro mantém mensagem. Cancelar/X/fundo fecham.

O modo uazapi do componente compartilhado renderiza texto por callback, mas não é passado pelos chamadores deste módulo; não é uma opção selecionável de envio aqui.

## 4.8 Agenda, mensagens internas e auditoria
saveNoteCore cria agenda em POST `/api/appointments` para contatos comuns com próxima data (12:00–12:30, ONLINE, AGENDADO), e envia notificações de grupos por sendMessage→POST `/api/messages`. Cancelamentos seguem outro ramo de notificação de grupos, sem criação de agenda nesse handler. Detalhes e defaults no capítulo 2.

useAudit registra NOTA_COBRANCA e CONTA_RECEBER conforme criar/editar/excluir. O grid tem histórico do título, não um botão de histórico separado de cada nota.

Resumo de fichas e aditivos usa POST `/api/admissions/collection-summary` com clientIds únicos; detalhe do cliente usa `/api/admissions/client-detail/:clientId`. Não são integrações bancárias ou consulta jurídica externa.

# 3. Dados do cliente, ficha de admissão e auditoria

## 3.1 Dados completos do cliente
**Dados do Cliente** na linha, **Ver Cliente** na lateral ou **Ficha do Cliente** no modal de contato abrem painel em portal no body, com nome e **Dados Completos — Somente Leitura**. Só renderiza se o ID resolve um cliente na configuração. Fecha por **Voltar**; não há handler geral de Escape/fundo nesse painel.

Abas: **Cadastro** (inicial DADOS), **Títulos (N)** e **Admissões (N)**.

### Cadastro — todos os campos
Nome/Razão; Tipo; CPF/CNPJ (document); RG; Telefone; Telefone 2; E-mail; Profissão; Estado Civil; Nascimento; Endereço; Número; Complemento; Bairro; Cidade; UF; CEP; Observações (só se notes).

Fallback geral travessão; endereço combina componentes. Tipo é **Pessoa Física** somente se type=FISICA; senão exibe **Pessoa Jurídica**, mesmo se a propriedade estiver ausente. Não há editar cadastro, ligação, envio de e-mail ou desbloqueio nesse bloco.

Cliente bloqueado exibe banner com blockStatus, nome, blockedAt e blockedBy se presentes; **Ver motivo/Ocultar motivo** alterna blockReason. Tenta alerta sonoro uma vez por montagem. BLOQUEADO é vermelho/pulsante, demais estados bloqueados em âmbar. É aviso visual, não prova de bloqueio de todos os handlers.

### Títulos
Fonte dos contadores: títulos PADRAO do cliente no array recebido, inclusive pagos, mas sem cancelados removidos pelo pai. Quatro resumos: **Total**, **Em Aberto** (exclui PAGO/CANCELADO/AGRUPADO), **Liquidados** (PAGO), **Saldo Devedor** dos em aberto.

Ao escolher cliente busca `/api/admissions/client-detail/:clientId`; máximo 50 admissões AUDITADA/FINALIZADA e 200 títulos relacionados ao conjunto. Agrupa por ficha; mostra contrato ou **Sem contrato**, quantidade de parcelas e selo **Possui Aditivo Contratual**, com data recente se houver. Colunas de cada grupo: **Documento, Descrição, Vencimento, Valor, Saldo, Status**.

Grupo **Sem Ficha de Admissão** contém os títulos locais sem admissionId ou sem ficha entre as retornadas, com as mesmas seis colunas. Sem títulos, texto **Nenhum título encontrado.**.

A API de parcelas não usa o mesmo recorte COBRAR/operador/status da carteira; listas e totais podem diferir. Não há CRUD nesse grid de consulta.

### Admissões
Fonte: config.admissions do cliente com status APROVADA, FINALIZADA, CONCLUIDO ou AUDITADA. Cartão: Contrato; Status; Data Admissão; Parcelas pagas/total; Em Atraso; Valor Financiado; Valor Parcela; Dia Vencimento; **Ver Ficha**.

Sem itens: **Nenhuma admissão aprovada encontrada para este cliente.**. Não há inclusão/edição/cancelamento de admissão aqui.

## 3.2 Ficha de Admissão: acionamento e limitação das props
**Ver Ficha** e **Ver Ficha Completa** exigem admin ou com_admissao:VISUALIZAR; negativa informa **Sem permissão para visualizar a Ficha de Admissão.**.

**Diferença importante do Operacional:** o chamador passa somente admission, clientName e onClose para AdmissionViewerModal. Não passa client, titular, bank, modality, collaboratorName, seriesSigla ou unitName, e o visualizador não busca esses cadastros por conta própria.

Consequências: seções **Dados do Responsável** e **Dados do Titular** não são renderizadas nesse fluxo; Série e Colaborador ficam em travessão; Unidade fica omitida; Banco e Modalidade em travessão; tabela de serviços do banco não é exibida. Esses campos existem no componente compartilhado, mas não são preenchidos por este menu. Os dados do cliente continuam disponíveis no painel Cadastro descrito acima.

Modal: título **Ficha de Admissão**, cliente, contrato e status no cabeçalho; começa em **Identificação**. Outras abas **Contrato / Financeiro**, **Documentos (N)** e **Auditoria**. Fecha pelo X ou **Fechar**; rodapé **Somente visualização**. Não modifica a ficha.

## 3.3 Aba Identificação — conteúdo neste fluxo
**Identificação do Processo**: Cliente (Responsável), Contrato, Data Admissão, Status, Tipo Cliente (tipoCliente), Série (sem prop→travessão), Colaborador (sem prop→travessão), Indicação (indicationType), Origem (originType). Unidade só aparece se unitName, não fornecido aqui.

**Dados do Veículo**, se vehicleBrand: Marca, Modelo, Ano, Placa, Cor, Chassi, Renavam; omite valores vazios; selo **ELÉTRICO** se isElectricVehicle.

**Informações Adicionais**: Taxa Administração (R$)=otherInfo1 e Primeira Parcela (R$)=otherInfo2, somente se preenchidos.

Campos de responsável/titular do componente, não renderizados por falta das props nesse chamador: responsável teria CPF/CNPJ, RG, nascimento, estado civil, profissão, tipo, dois telefones, e-mail, endereço completo e anotações; titular teria nome, documento, RG, telefone e e-mail. Não presumir que aparecem na ficha aberta pelo Operacional.

## 3.4 Aba Contrato / Financeiro
Banco e Modalidade sem props mostram travessão. **Tarifa Bancária=Inclusa** se admission.hasBankFeeIncluded; **Contrato=De Terceiro** se isThirdPartyContract.

**Dados Financeiros do Contrato**:
- Valor Financiado=financedAmount.
- Valor Parcela Atual=installmentValue.
- Total Parcelas=totalInstallments.
- Pagas / Em Atraso=paidInstallments/overdueInstallments, zero quando ausentes.
- Dia Vencimento=dueDay.
- Tipo Pagamento=paymentType.
- Condicionais: Venc. 1ª Parcela=firstInstallmentDueDate; Taxa Administrativa=parcela1; 1ª Parcela Real=parcela2; Taxa de Cobrança=taxaCobranca; Desconto=desconto.

Textos ausentes normalmente viram travessão. Campos condicionados por truthiness podem ocultar zero numérico. Não confundir parcela1/parcela2 com otherInfo1/otherInfo2.

**Cenários de Recálculo**, quando existem: Cenário (label), Dívida Orig. (originalDebt), Nova Dívida (newDebt), Economia (savings), Parcelas (installmentsToPay), Vl. Parcela (installmentValue), Dia Venc. (dueDay). Consulta, sem recalcular ou escolher proposta.

## 3.5 Aba Documentos da ficha
Busca sob demanda `/api/admissions/:id/attachments`, mapeando id/title/file_name/file_data; prefere o retorno buscado aos anexos pré-carregados. Conteúdo da aba inclui painel ClientAttachmentsPanel **readOnly**, **compact**, module=ADMISSION, targetType=ADMISSION, targetId=admission.id, clientId=admission.clientId.

Contador soma anexos legados resolvidos e bucketCount. Carregamento, vazio e erro com **Tentar novamente**. Branch de sem permissão existe no JSX legado, mas o catch atual só atribui LOAD_ERROR; não presumir que um 403 resulte naquela mensagem específica.

Legados: título/nome; ícone imagem/PDF/outro; **Visualizar** abre janela com iframe; **Baixar documento** usa link; imagens data:image têm miniatura ampliável.

Armazenados protegidos: **Filtrar**, **Atualizar**, **Ver** para imagem/PDF, **Baixar** e paginação. Sem upload, seleção de exclusão ou modais ACL nesse modo de ficha. Os controles de escrita do painel de documentos da lateral da cobrança são um contexto diferente.

## 3.6 Aba Auditoria da ficha
**Consulta jurídica registrada**: usa admission.legalScan pré-carregado ou GET `/api/admissions/:id/legal-scan` ao abrir. Estados carregando, 403 sem permissão, erro, ausente e resultado histórico.

Campos históricos: lastUpdate; found; número do processo; tribunal; última movimentação; parte autora, se presentes. Se allProcesses existe, cada item contém numeroProcesso, tribunal, classe, assunto, parteAutora, dataAjuizamento e ultimaMovimentacao. Não consulta DataJud nem dispara pesquisa jurídica nova.

**Rounds de Auditoria (N)**: roundNumber, critiqueDate, critiquedBy, critique; response/respondedBy/responseDate quando existe resposta. Sem itens informa ausência. Somente leitura, sem responder crítica ou aprovar ficha.

## 3.7 Histórico de Movimentações da linha
Ícone de relógio → modal **Histórico de Movimentações**, selo **Somente Leitura** e identificação da entidade. Busca `/api/audit-logs?entity_id={id}&limit=500`, não usa logs pré-carregados como fonte efetiva.

Ordena do mais recente; cada change vira linha: **Data/Hora; Usuário; Ação; Campo; De; →; Para**. Sem changes, usa descrição em Para; ausências como travessão; usuário ausente **Sistema**. As cores reconhecem CREATE, UPDATE, DELETE, BAIXA, BAIXA_PARCIAL, CANCELAR_BAIXA, CANCELAR, INVOICE, RECORRENCIA, LINK e DEDUCAO. São ações históricas, não botões para executá-las aqui.

Paginação de 15 linhas de alterações, contagem de eventos, Anterior/Próxima. X, **Fechar** ou fundo fecham. Estado carregando/vazio; catch silencioso pode parecer ausência de movimentação. Não é o mesmo histórico de notas nem os rounds da admissão.

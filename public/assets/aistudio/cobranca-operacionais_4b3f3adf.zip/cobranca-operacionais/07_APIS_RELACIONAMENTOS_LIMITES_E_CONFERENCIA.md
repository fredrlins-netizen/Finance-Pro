# 7. APIs, relacionamentos, limites e roteiro de conferência

## 7.1 APIs acionadas pelo fluxo
| Método/caminho | Acionamento | Conteúdo |
|---|---|---|
| GET /api/financial-titles | Montagem/busca/página/refresh | RECEBER; limit=50; busca client_name/description/document_number |
| DELETE /api/financial-titles/:id | Excluir título | ID; auditoria e onRefresh |
| GET /api/collection-notes?clientId=... | Abrir lateral/modal | Notas do cliente |
| GET /api/collection-notes?collaboratorId=...&negotiationStatus=SOLICITA_CANCELAMENTO | Montagem | Solicitações do colaborador corrente |
| POST /api/collection-notes | Salvar Contato | Nota, canal, status, snapshot, anexos e cancelRequest opcional |
| PUT /api/collection-notes/:id | Salvar edição | note, negotiationStatus, nextContactDate |
| DELETE /api/collection-notes/:id | Excluir nota | ID |
| POST /api/collection-notes/bulk | Migração automática legada | notes de collection_notes_v1 |
| POST /api/appointments | Nota comum com próxima data | Cliente, colaborador, data, 12:00–12:30, ONLINE/AGENDADO |
| POST /api/messages | Notificação de grupos | recipientType GROUP, recipientId, assunto e corpo |
| POST /api/admissions/collection-summary | Muda lista filtrada | clientIds únicos; contagem de fichas/aditivos |
| GET /api/admissions/client-detail/:clientId | Selecionar cliente | Fichas, parcelas, aditivos |
| GET /api/admissions/:id/attachments | Abrir Documentos | Legados da admissão |
| GET /api/admissions/:id/legal-scan | Abrir Auditoria | Consulta histórica |
| GET /api/audit-logs?entity_id=...&limit=500 | Histórico | Movimentações do título |
| GET /api/prospection/unread-counts | Montagem | Contagens GoTalk+uazapi por telefone |
| GET /api/gotalk/client-timeline?phone=...&limit=200 | Aba WhatsApp unificada | Histórico por telefone |
| POST /api/gotalk/send-text | Enviar texto | contactNumber/message |
| GET /api/gotalk/client/:clientId | Chat legado e overlay | Contato vinculado |
| GET /api/gotalk/messages/:clientId | Chat/overlay | limit=100 ou 500 |
| POST /api/gotalk/messages/mark-read | Carregamento do chat legado | clientId |
| GET /api/gotalk/attendances | Resolver atendimento aberto no chat legado | clientId, status=open, limit=1 |
| POST /api/gotalk/send-message-attendance | Enviar pelo chat com atendimento | attendanceId, phone, body |
| POST /api/gotalk/sync-attendance | Importar histórico legado | attendanceId, contactId |
| POST /api/gotalk/sync-by-phone | Importar por telefone | phone |
| GET /api/gotalk/channels | Chat/HSM | Canais |
| GET /api/gotalk/hsm-templates | Selecionar canal HSM | channelUuid |
| POST /api/gotalk/send-active-notification | Enviar HSM | Canal, telefone, templateId, tags |
| GET /api/gotalk/media/:id | Visualização de mídia legado/overlay | Download com ?download=1 |
| GET /api/client-attachments/ | Documentos armazenados | Cliente, módulo, alvo, busca, cursor, limit=25 |
| GET /api/client-attachments/:id/content | Preview | browser=1 |
| GET /api/client-attachments/:id/download | Baixar | browser=1 |
| DELETE /api/client-attachments/:id | Excluir documento | ID |
| GET /api/client-attachments/acl/options | Seletores ACL admin | type, search, offset, limit e ids |
| GET/PUT /api/client-attachments/acl/folders/:clientId | Acesso pasta admin | groupIds/userIds |
| GET/PUT /api/client-attachments/acl/files/:attachmentId | Exceção arquivo admin | overrideEnabled e destinatários |
| GET /api/client-attachments/acl/legacy/:clientId/impact | Preparar proteção admin | Impacto/regras |
| POST /api/client-attachments/acl/legacy/:clientId/protect | Confirmar proteção admin | attachmentIds |
| GET /api/client-attachments/acl/legacy/:clientId/protected | Histórico admin | limit/offset |
| DELETE /api/client-attachments/acl/legacy/:clientId/protect/:attachmentId | Reverter proteção admin | Cliente/arquivo |

Endpoints de incluir/editar títulos, efetuar baixa, aprovar cancelamento, importar arquivos e upload armazenado existem em outros contextos do projeto, mas não são ações ligadas pelos controles deste menu. Não inventar esses modais.

## 7.2 Todos os relacionamentos relevantes
| Origem | Destino | Uso no fluxo |
|---|---|---|
| Usuário logado.id | config.users.id | Resolve cadastro de usuário |
| Usuário.collaboratorId | collaborators.id | Carteira do operador |
| Colaborador.userId ou id | currentUserId | Fallback se não há collaboratorId informado |
| Título.clientId | clients.id | Cadastro, telefone, UF, avisos |
| Título.assignedCollaboratorId | collaborators.id | Responsável e recorte do operador |
| Título.admissionId | admissions.id | Agrupamento de parcelas na consulta do cliente |
| Admissão.clientId | clients.id | Lista de admissões do cliente |
| admission_addendums.admission_id | admissions.id | Contagem, existência e data de aditivos |
| Nota.titleId | financial_titles.id | Histórico do título, próxima data |
| Nota.clientId | clients.id | Timeline de contatos do cliente |
| Nota.collaboratorId | collaborators.id | Autor e busca de solicitações |
| Nota.cancelRequest.admissionId | ID no JSON de cancelamento | Contrato selecionado; não cancela automaticamente |
| Nota.debtSnapshot | Valores copiados/simulados | Evidência do valor conversado, não altera título |
| Nota.attachments | name/dataUrl/type em JSON | Arquivo embutido, não documento do bucket |
| Usuário.groupIds | userGroups.id | Destinatários de mensagens e primeiro grupo da agenda |
| Agendamento.clientId/collaboratorId/groupId | Cliente/colaborador/grupo | Follow-up criado na nota nova comum |
| audit_logs.entity_id | ID do título ou nota | Rastro de mudanças |
| Documentos.clientId + targetType/targetId | Cliente e título/admissão | Escopo de documentos e ACL |
| ACL.groupIds/userIds | Grupos/usuários | Destinatários admin; intersecta módulo/unidade |
| Contato GoTalk vinculado | clientId CRM | Histórico legado e overlay |
| Telefone do cliente | Timeline e eventos de mensagem | Correspondência por telefone no fluxo unificado |
| Título.settlements | amount/date recebidos | Recebido e baixas do dia, quando presentes |

**Resumo de admissão da lateral não usa título.admissionId**: escolhe primeira admissão elegível do cliente, podendo resumir outro contrato. Não confundir esse caminho com o agrupamento por ID da aba Títulos.

## 7.3 Persistência, cache e atualização
loadClientNotes consulta uma vez por clientId por montagem e memoriza o ID antes de concluir. Falha silenciosa deixa o cliente marcado como carregado; reabrir pode não tentar novamente. Contadores de notas e próximo contato dependem de quais clientes já tiveram notas carregadas.

Migração legada automática: lê localStorage `collection_notes_v1`, POST bulk; mantém apenas failedIds quando há falhas ou remove chave ao concluir; limpa cache de clientes. Notas novas são gravadas no backend, não nessa chave.

Isso difere da coordenação: o painel Coordenadores inspecionado ainda lê a chave legada para o card de cancelamentos. Não há garantia de que notificações internas ou a nova nota apareçam automaticamente no card daquela tela.

CollectionPanel registra invalidação **collection** com refreshTitles. O Operacional recebe onRefresh global, não refreshTitles diretamente. Excluir título chama o callback global e pode depender de invalidação/refetch do hook para a página refletir; a existência do toast não prova o refresh imediato.

## 7.4 Segurança: o que o código mostra
- UI de exclusão: canExcluir=admin ou fin_cobranca_op:EXCLUIR; handlers de exclusão chamam validarPermissao.
- Edição lateral de nota é apresentada dentro de canExcluir; duplo clique de edição no histórico do modal não tem a mesma guarda frontend.
- Visualização da ficha exige com_admissao:VISUALIZAR; resumo/detalhe/anexos/scan possuem autorização de leitura no servidor, não bastando acesso a cobrança.
- Rotas de títulos/admissões são montadas com requireAuth e validateAccountStatus. Agenda é montada com extractUser; não possui os mesmos middlewares nesse ponto de montagem. Isso não substitui avaliação de autorização por ação no servidor.
- CollectionNotes é montado com extractUser e o arquivo não mostra guarda específica de autenticação/permissão por operação; isso é achado estático a avaliar separadamente, não exploração realizada.
- Rotas de ACL e adesão/reversão de documentos exigem requireAdmin; o componente só habilita opções ACL após sucesso da consulta administrativa.
- Banner de cliente bloqueado não substitui validação: handlers de salvar contato/excluir título deste componente não testam client.blocked explicitamente.
- Cadastro de grupos por correspondência de nome determina destinatários da notificação; não é seleção formal de uma role fixa de coordenador.
- Nenhuma credencial, token, conexão privada ou mensagem real foi exportada.

## 7.5 Pontos de atenção e efeito observável
| Ponto | Efeito/limite |
|---|---|
| Paginação de 50 antes do filtro operacional | Carteira, resumos e Dashboard não são totais globais garantidos |
| Layout não repassa props GoTalk | Recursos de chat/aba/overlay são condicionais e não ficam habilitados no caminho principal atual |
| Ver Cancelados com pai removendo CANCELADO | Não recupera cancelados do servidor |
| Dois formulários de contato diferentes | Lateral não tem cancelamento/simulação/anexos embutidos como o modal |
| Zero na simulação usa fallback no save | Prévia pode diferir do snapshot salvo |
| Snapshot parte do original | Pode não equivaler ao saldo pendente após baixas |
| Agenda/grupos falham em catch silencioso | Toast de integração não é confirmação individual |
| Edição de data/status da nota | Não sincroniza agenda ou notifica como na criação |
| Editar para cancelamento sem submodal | Pode não haver cancelRequest correspondente |
| Cancelar submodal não limpa objeto antigo | Dados de cancelamento podem persistir no formulário com outro status |
| Resumo usa primeira admissão por cliente | Pode não ser a admissão vinculada ao título |
| Ficha sem props auxiliares | Dados de responsável/titular e nomes de banco/série etc. não aparecem completos |
| CPF/CNPJ do modal usa cpfCnpj | Pode ficar omitido mesmo havendo document |
| Badge local e normalizações 8/10 dígitos | Contagem/leitura e correspondência podem divergir; DDD pode ser perdido na timeline |
| Timeline unificada sem carregar mais | Só primeira resposta até 200 mensagens |
| Evento sem ID externo e envio otimista | Pode exibir duplicata |
| Baixas Hoje em myTitles sem PAGO | Exclui baixas dos títulos totalmente pagos fora desse conjunto |
| Fórmula DSO específica | Não representa indicador contábil convencional |
| Sentença financeira e saldo persistido | Igualdade visual não é validada pelo cálculo |

Nada disso foi corrigido, pois o pedido foi documentar e compactar.

## 7.6 Roteiro de conferência — não executado
Usar sessão autorizada, ambiente de testes e dados descartáveis para operações de escrita/envio.

1. Comparar admin, operador vinculado e usuário sem colaborador; verificar rótulos e carteira.
2. Testar busca, quatro ordenações, filtros individuais/combinados, cards clicáveis e Limpar.
3. Conferir paginação de 50 e diferenças de contagens antes/depois do filtro.
4. Abrir lateral por duplo clique; conferir resumo de admissão versus admissionId real.
5. Conferir Ver Cancelados e a origem dos títulos recebidos.
6. Cadastrar nota comum, Outros sem/com detalhe e próxima data; inspecionar nota, auditoria, agenda e mensagem de grupo separadamente.
7. Abrir modal de contato, testar simulação vazia, zero e valores positivos; comparar snapshot salvo com prévia sem alterar título.
8. Anexar/remover arquivo antes de salvar e baixar pelo histórico; não usar arquivo privado de produção.
9. Selecionar cancelamento, cancelar submodal, confirmar contrato e só depois salvar; conferir nota/notificações, sem esperar cancelamento financeiro.
10. Editar nota por lateral e por modal com perfis diferentes; conferir que agenda não é sincronizada automaticamente.
11. Excluir nota/título descartável com permissão; testar negativa e rejeições de integridade.
12. Conferir as três abas do cliente, campos padrão e quatro abas da ficha, inclusive os campos não preenchidos pelo chamador.
13. Conferir Documentos armazenados versus anexos da nota, seleção entre páginas e ACL admin com confirmação consciente dos efeitos.
14. Testar WhatsApp unificado, chat legado e overlay separadamente; conferir leitura, limites 200/100/500 e eventos por telefone.
15. Enviar texto/HSM apenas para destinatário de teste; confirmar o provedor efetivamente usado.
16. Conferir Dashboard com massa conhecida: hoje, período por vencimento, pagos, settlements e mudanças de página.
17. Conferir fórmulas e as diferenças de critério entre Carteira Total, Abertos e Pagos.
18. Conferir gráficos por faixa e evolução acumulada por vencimento, sem interpretar como recebimento.

Não se executaram testes autenticados, mutações, envios GoTalk, alterações ACL, leitura da base de produção ou publicação neste levantamento.

# 1. Acesso, permissões de perfil, carteira e data grid

## 1.1 Navegação e estado inicial
Menu **Cobrança → Operacionais**, visualização interna `fin_cob_operacional`. O layout carrega CollectionPanel, que monta CollectionOperationalPanel. Cabeçalho real: **Cobrança — Operacional**.

Operador: subtítulo **Títulos atribuídos a {colaborador}**; abas **Minha Carteira** e **Meus Resultados**. Administrador: **Visão administrativa — todos os títulos em cobrança**, selo **Administrador**, abas **Todas as Carteiras** e **Resultados Gerais**. A aba de carteira começa ativa (`CARTEIRA`); Dashboard usa `DASHBOARD`.

**Voltar**, quando há callback, navega para Coordenadores (`fin_cob_coordenador`), não para o histórico do navegador. **Expandir** alterna um contêiner fixo sobre a janela; passa a **Minimizar**. É expansão por CSS, não a API de tela cheia do navegador.

## 1.2 Identificação do colaborador e elegibilidade
O pai resolve o usuário em config.users pelo currentUserId e repassa seu collaboratorId. O painel tenta localizar o colaborador por esse ID; só se o ID não foi informado tenta collaborator.id=currentUserId ou collaborator.userId=currentUserId.

Operador sem colaborador resolvido fica com carteira vazia e aviso **Seu usuário não está vinculado a um colaborador. Solicite ao administrador que vincule seu cadastro para visualizar os títulos.**.

Todos os registros vêm de GET `/api/financial-titles`, escopo `filter_title_scope=RECEBER`, página de **50 registros**. O pai remove status CANCELADO. O painel seleciona `type=PADRAO`, `collectionStatus=COBRAR` e status diferente de CANCELADO, AGRUPADO e PAGO.

Para operador, exige também assignedCollaboratorId=currentCollaborator.id. Para administrador, não exige responsável específico. “Todas as carteiras” significa todas as elegíveis **recebidas naquela página**, não carregamento integral automático do banco.

## 1.3 Barra de busca e filtros
**Buscar cliente...**, inicial vazio: após 300 ms chama onSearch e a busca do servidor. O endpoint financeiro pesquisa client_name, description e document_number; apesar do rótulo, pode encontrar descrição/documento também.

**Filtros**, inicialmente recolhido, abre/fecha controles. Indicador **N de M título(s)**: N=filteredTitles, M=myTitles, ambos locais à página.

| Campo | Padrão | Opções | Acionamento |
|---|---|---|---|
| Responsável, só administrador | Todos / vazio | Colaboradores que possuem ao menos um título em myTitles; id/name | Filtra assignedCollaboratorId |
| Status | Todos / vazio | ABERTO=Em Aberto; PARCIAL=Parcial; PROTESTADO=Protestado; PROVISAO=Provisão | Igualdade exata |
| Faixa de Atraso | Todos / vazio | A Vencer; 1-30 dias; 31-60 dias; 61-90 dias; 90+ dias | Filtra faixa e limpa filtro de card |
| Vencimento De | Vazio | Data | dueDate >= início |
| Vencimento Até | Vazio | Data | dueDate <= fim |
| Limpar Filtros | Botão | Sem opções | Limpa busca, responsável, status, datas, faixa e card selecionado |

Não há filtro editável de situação de cobrança: COBRAR é critério fixo. Não há filtro próprio por UF, banco, modalidade ou unidade. Filtros avançados são locais e combinados por E. Não há validação explícita de intervalo invertido.

## 1.4 Quatro cards da carteira
1. **Total Títulos**: quantidade e saldo de filteredTitles.
2. **A Vencer**: quantidade e saldo com agingDays<=0 dentro de filteredTitles. Clicável: alterna filtro A Vencer.
3. **Vencidos**: quantidade e saldo com agingDays>0 dentro de filteredTitles. Clicável: alterna filtro Vencidos.
4. **Saldo Devedor Total**: saldo de filteredTitles, não clicável.

Os cards mostram a sentença financeira: original + juros + multa − desconto = atualizado − recebido = saldo. Juros/multa/desconto/recebido só aparecem na sentença quando positivos. O saldo mostrado é currentBalance recebido, não um recálculo forçado para garantir igualdade.

Clicar em card limpa o filtro de faixa e alterna selectedCardBucket. Aparece **Filtro ativo: {faixa}**, com **Limpar**. Como os próprios cards usam filteredTitles, seus números também diminuem com o filtro de card já ativo.

## 1.5 Solicitações de Cancelamento na carteira
Card laranja aparece somente quando há notas de cancelamento com cancelRequest. Busca pelo colaborador corrente com negotiationStatus=SOLICITA_CANCELAMENTO; mostra **Registradas por você — clique para ver**. Mesmo administrador não recebe aqui uma lista global de todos os operadores.

Clique expande/recolhe (estado inicial null). Cada item: cliente resolvido no título ou clientId, documento quando resolvido, data/hora da nota, contrato e observações. Botão **Ver** aparece apenas se o título foi encontrado na página e abre o modal de contato. Não executa cancelamento nem aprova solicitação. Esse card está na carteira, não no JSX do Dashboard.

## 1.6 Todas as colunas do grid
São **11 colunas para operador e 12 para administrador**, contando a faixa visual inicial.

| Coluna | Origem | Conteúdo e acionamento |
|---|---|---|
| Faixa visual, sem título | dueDate→agingBucket | Barra de cor por atraso; não é checkbox |
| Cliente | clientName | Nome; badge de WhatsApp não lido por telefone; quantidade de notas carregadas do cliente |
| Fichas | resumo API por clientId | Admissões AUDITADA/FINALIZADA; travessão sem resumo; não clicável |
| Aditivos | resumo API por clientId | Quantidade de aditivos das fichas elegíveis; não clicável |
| Responsável, só admin | assignedCollaboratorId→collaborators.id | Nome ou travessão |
| Documento | documentNumber | Texto |
| Vencimento | dueDate | Data pt-BR |
| Saldo | currentBalance | BRL |
| Atraso | agingDays | “Nd” se positivo, “Em dia” senão; cor por faixa |
| Status | status | Rótulo traduzido e badge |
| Próx. Contato | Notas carregadas de titleId | nextContactDate da nota com data mais recente entre as que têm próximo contato; travessão se ausente |
| Ações | IDs da linha | Registrar / Ver Contatos; Histórico; Dados do Cliente; Excluir Título se permitido |

Badge WhatsApp: quantidade; acima de 99 mostra **99+**. Badge do botão de contatos: acima de 9 mostra **9+**. Quantidade de notas junto ao nome é por cliente, embora histórico do modal seja por título.

**Duplo clique na linha** alterna activeTitle e abre/fecha painel lateral de gestão. Clicar no botão Registrar / Ver Contatos abre outro fluxo: modal amplo em três colunas. Esses caminhos têm campos e permissões diferentes.

Ordenação por clique em **Cliente, Documento, Vencimento e Saldo**. Inicial dueDate asc; mesmo cabeçalho inverte; nova coluna inicia asc; saldo é numérico, demais comparação JavaScript. A API retorna por padrão due_date DESC, e a reordenação asc é só da página carregada.

Sem multisseleção de títulos, sem inclusão direta, sem editar célula, sem atribuição em lote, sem exportar ou imprimir próprios do grid. Ações de nota não equivalem a baixa financeira.

## 1.7 Rodapé, vazios e paginação
Rodapé: quantidade de títulos, vencidos, Saldo Devedor; linha **Recálculo Financeiro** com Valor Original, Juros, Multa, Desconto, Valor Atualizado, Recebido e Saldo Devedor.

Vazio admin: **Nenhum título em cobrança no momento.** Operador vinculado: **Nenhum título atribuído a você no momento.** Não vinculado: **Vincule seu usuário a um colaborador para ver os títulos.** Sem painel ativo e havendo linhas, orienta duplo clique.

PaginationBar é montada pelo pai abaixo do painel, em ambos os modos; usa total/totalPages do servidor, páginas numeradas/reticências, Anterior e Próxima, com limites e bloqueio durante carregamento. Oculta-se quando cabe em uma página de 50. Totais do servidor antecedem os recortes locais, podendo divergir dos contadores visíveis.

## 1.8 Datas e faixas
agingDays usa new Date(dueDate), zera horas de hoje e vencimento e aplica floor da diferença /86.400.000. A Vencer inclui hoje (<=0), depois 1–30, 31–60, 61–90, e **mais de 90** para “90+”. Cores: verde, amarelo, laranja, vermelho e vermelho forte.

A exibição de datas acrescenta T00:00:00; o cálculo de atraso usa parsing diferente, podendo sofrer diferença de fuso. Comparações com “hoje” em outros pontos usam data UTC de toISOString. Não presumir equivalência de todos esses critérios perto da virada do dia.

# Cobrança → Operacionais
## Relação de campos, funcionalidades, opções, integrações e relacionamentos

Levantamento da implementação existente na cópia de trabalho do projeto. Inclui as diferenças entre administrador e operador, carteira, data grid, CRUD efetivamente disponível, dois caminhos de registro de contato, solicitações de cancelamento, cliente, ficha de admissão, auditoria, anexos, WhatsApp e Dashboard.

## Como consultar
- **DOCUMENTACAO_COMPLETA.html**: documento reunido, índice navegável, leitura em navegador, pesquisa por Ctrl+F e impressão pelo navegador.
- Documentos Markdown numerados: capítulos separados e editáveis.
- **inventario_campos.csv**: catálogo com área, campo, propriedade, tipo, padrão, opções e acionamento; UTF-8 com BOM, separador ponto e vírgula.
- **inventario_campos.json**: mesmo catálogo em formato estruturado.
- **evidencias_controles.json**: controles, handlers, chamadas e estados extraídos das fontes, com caminho e linha.
- **fontes_e_integridade.json**: fontes consultadas, hashes e integridade dos arquivos.
- **tela-publica.jpg**, quando presente: captura da tela pública, não da área autenticada.

## Método e limites
Análise estática do frontend e dos pontos relevantes do backend. Não foram feitos cadastros, alterações, exclusões, envios de mensagens, mudanças de permissões ou consultas à base de produção. O código funcional do aplicativo não foi alterado.

A captura pública não tem sessão autenticada. A interface interna e as operações externas não foram verificadas em sessão autenticada. O pacote documenta o código e seus acionamentos, não certifica o funcionamento dos provedores ou dos dados em produção.

“Padrão” significa valor inicial, fallback ou conteúdo fixo presente no código. Registros de clientes, nomes de operadores, usuários, grupos, templates e arquivos são dinâmicos: informamos a origem sem exportar dados reais ou segredos.

## Atenção ao alcance
Os indicadores são calculados sobre os títulos recebidos na página, não necessariamente a carteira inteira. Existem diferenças entre o painel lateral, o modal de contato, o histórico unificado WhatsApp e a consulta GoTalk. Essas diferenças e os acionamentos incompletos são explicitados nos capítulos, sem inventar operações inexistentes.

**Integração não conectada no caminho principal atual:** DashboardLayout monta CollectionPanel sem gotalkEnabled, GotalkChatPanel e GotalkConversationsTab. Assim, as abas, chats e overlay condicionados a essas props não ficam habilitados por esse caminho, mesmo havendo código dos recursos. O capítulo 4 detalha os recursos condicionais e deixa essa distinção explícita. A busca de contadores de mensagens da carteira é independente dessas props.

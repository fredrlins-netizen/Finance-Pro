# 6. Dashboard — Meus Resultados / Resultados Gerais

## 6.1 Acesso, filtros e alcance
Operador clica **Meus Resultados**; admin **Resultados Gerais**. Ambos ativam DASHBOARD.

Campos **Período De** e **Período Até**, inicialmente vazios, comparam dueDate inclusivamente. **Limpar** zera os dois. Sem Aplicar: recalcula de imediato.

Não há filtro de colaborador no Dashboard, mesmo para admin. O filtro de responsável da carteira e os demais filtros locais não são usados por dashboardData. Busca/página do componente pai, porém, restringem os títulos disponíveis aos dois modos.

Todos os cálculos usam arrays recebidos na página de 50 registros e settlements **se presentes**. Não há chamada de endpoint agregado de carteira inteira. O texto “Gerais” não garante total global.

## 6.2 Resultados do Dia — três cards, sem filtro de período
“Hoje” é a data UTC `new Date().toISOString().split('T')[0]`.

1. **Vencendo Hoje**: quantidade de myTitles com dueDate igual a hoje; complemento **Saldo** = soma currentBalance desses títulos.
2. **Vencidos Acum.**: quantidade com agingDays>0; complemento **Saldo vencido** = soma currentBalance.
3. **Baixas Hoje**: conta **cada item de settlements** de myTitles cuja date iguala hoje; complemento **Recebido** = soma amount.

Esses cards usam myTitles e não os filtros de período. myTitles exclui PAGO, logo baixas de títulos totalmente pagos que saíram desse conjunto não entram nessa contagem. Sem settlements carregados o total é zero; não há fetch dedicado de baixas nesse cálculo.

Os três cards são informativos, sem modal de detalhamento por clique.

## 6.3 Resultados Acumulados — quatro cards
### Carteira Total
Cria allMyTitlesIncludingPaid: admin recebe todos os títulos PADRAO da página; operador os PADRAO atribuídos ao colaborador. Esse conjunto não exige collectionStatus=COBRAR e não exclui AGRUPADO por si só. CANCELADO já foi retirado pelo pai.

Filtra por vencimento no período → periodAllTitles.
- Número principal **N tít.** = quantidade de periodAllTitles.
- **Abertos** = periodTitles.length, sendo periodTitles=myTitles filtrado pelo vencimento.
- **Pagos** = quantidade de periodAllTitles com status PAGO.

Os três números não usam critérios idênticos; Carteira Total não precisa ser a soma de Abertos+Pagos.

### Taxa Recuperação
`totalAssignedValue = soma originalValue de periodAllTitles`.

`recoveredValue = soma originalValue dos periodAllTitles PAGO`.

`taxaRecuperacao = recoveredValue / totalAssignedValue ×100`, ou zero se denominador<=0. Exibe uma casa decimal e **Recuperado: R$ ...**.

Não soma pagamentos efetivos nem utiliza data da baixa: usa valor original e data de vencimento.

### Inadimplência
periodTitles=myTitles no período. `100 × quantidade vencida / quantidade de periodTitles`, ou zero sem títulos. Uma casa decimal. Complemento **Vencido** soma saldo vencido desse conjunto.

### DSO (Dias)
`openBalance = soma currentBalance em periodTitles`.

`avgBalance = openBalance / periodTitles.length` ou zero.

`dailyRecovery = recoveredValue>0 ? recoveredValue/30 : 1`.

`DSO = round(avgBalance / dailyRecovery ×30)` se dailyRecovery>0; senão zero.

Complemento **Saldo aberto**. É fórmula específica do código, não DSO contábil convencional; usa saldo médio por título, período fixo de 30 dias e fallback 1, mesmo com filtro de outra duração.

Os quatro cards não possuem drill-down, ação de cobrança, impressão ou exportação.

## 6.4 Recálculo Financeiro da Carteira — Período Selecionado
periodTitles é a fonte. Campos:
- **Valor Original/Orig.** = soma originalValue.
- **Juros** = soma interestValue.
- **Multa** = soma penaltyValue.
- **Desconto/Desc.** = soma discountValue.
- **Atualizado** = original+juros+multa−desconto.
- **Recebido** = soma dos amounts de todos os settlements desses títulos.
- **Saldo Devedor** = soma currentBalance.

Mostra sentença-equação e sete células de detalhe. A sentença omite encargos/desconto/recebido não positivos; as células mostram todos os sete valores.

O saldo não é calculado como atualizado−recebido no código dessa função; é valor persistido somado. Portanto a igualdade desenhada pode não fechar se a base tiver outra regra de saldo. Recebido não filtra a data de cada settlement pelo período: primeiro filtra o título pelo vencimento e depois soma seus settlements.

## 6.5 Carteira por Faixa de Atraso
Cinco linhas fixas: A Vencer (<=0, inclui hoje), 1–30, 31–60, 61–90, 90+ (>90), nas cores verde/amarelo/laranja/vermelho/vermelho forte.

Cada linha: rótulo, barra, quantidade **N tít.** quando positiva e saldo BRL. Rodapé soma quantidade e saldo de todas as faixas.

Largura = max(saldoDaFaixa/maiorSaldoDasFaixas ×100, **2%**); maiorSaldo tem piso 1. A barra não representa percentual sobre o total, e faixas sem saldo ainda podem ter largura mínima. Não há clique para filtrar a carteira nesse gráfico; o filtro por card é outro controle no modo carteira.

## 6.6 Evolução Diária — Saldo Acumulado
Agrupa periodTitles por **dueDate**, soma currentBalance e quantidade por dia, ordena datas crescentes e acumula saldo. Cada coluna tem saldo acumulado até o vencimento e quantidade **daquele dia**, não quantidade acumulada.

Altura = max(acumulado/maiorAcumulado ×100, **3%**), denominador com piso 1. Tooltip visual ao passar o mouse mostra data pt-BR, saldo acumulado e quantidade do dia. Eixo inferior mostra primeira e última datas, quando houver.

Sem dados: **Sem dados para o período selecionado.**. Não é uma série de recebimentos, contatos realizados ou evolução histórica diária do estoque: é distribuição acumulada dos saldos atuais por data de vencimento.

## 6.7 Opções inexistentes neste Dashboard
Não há metas, seleção de operador, comparação com período anterior, visão por banco/UF/unidade, exportação, impressão, clique de gráfico para abrir clientes ou card de cancelamentos dentro do Dashboard. Solicitações ficam no modo carteira.

As notas ou os envios de WhatsApp não alimentam uma métrica própria de produtividade nesse cálculo. A invalidação do tópico collection pode atualizar títulos por refreshTitles, mas não transforma cálculos locais em agregação completa de banco.

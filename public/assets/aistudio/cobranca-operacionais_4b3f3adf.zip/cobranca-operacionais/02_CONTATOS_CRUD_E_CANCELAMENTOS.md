# 2. CRUD, dois painéis de contato e solicitação de cancelamento

## 2.1 Matriz real de CRUD
| Entidade | Incluir | Consultar | Alterar | Excluir |
|---|---|---|---|---|
| Títulos | Não neste menu | Grid, lateral e cliente | Não há modal de edição do título nem botão de baixa | DELETE com permissão e confirmação |
| Notas/contatos | Lateral e modal de contato | Linha do tempo do cliente ou histórico do título | Edição inline; campos variam por caminho | DELETE com confirmação |
| Solicitações de cancelamento | Pela seleção de status e submodal, depois Salvar Contato | Card, resumo e histórico | Seleção antes de salvar; depois edição limitada da nota | Excluir a nota; não cancela contrato |
| Cliente/admissão | Não | Somente leitura | Não | Não |
| Agenda | Criação automática ao salvar nota comum com próxima data | Não há grade da agenda aqui | Editar nota não sincroniza agenda | Apagar nota não apaga agenda |
| Mensagem interna | Notificação automática conforme fluxo | Não há caixa de entrada nesse menu | Não | Não |
| WhatsApp | Enviar texto/HSM em componentes integrados | Conversa/histórico | Não há editar mensagem nesse fluxo | Não há excluir mensagem nesse fluxo |
| Anexos | Arquivos embutidos na nova nota; painel armazenado tem upload desativado neste chamador | Ver/baixar | ACL dos armazenados para admin | Exclusão dos armazenados e remoção de arquivo antes de salvar nota |

## 2.2 Painel lateral por duplo clique
Cabeçalho: cliente; Doc; Venc; Saldo; **Ver Cliente** abre dados completos; X fecha painel.

**Resumo da Ficha de Admissão**: escolhe a primeira admissão do cliente na lista recebida com status APROVADA/FINALIZADA/CONCLUIDO/AUDITADA, sem resolver admissionId do título nem ordenar pela mais recente. Campos: Contrato; Status; Valor Financiado; Parcela; Parcelas pagas/total; Em Atraso; Dia Vencimento; Tipo Pgto; Veículo quando há marca. **Ver Ficha Completa** abre o visualizador com permissão de admissão.

**Títulos do Cliente**: PADRAO do cliente na página recebida. Inicialmente exclui CANCELADO e AGRUPADO; **Ver Cancelados/Ocultar Cancelados** alterna a exclusão local. Cada linha mostra Documento, Vencimento, Saldo e marcador Pago/Canc./dias/OK. Não é botão de selecionar outro título. Como o pai remove CANCELADO, o botão não consegue recuperá-los do banco.

**Linha do Tempo de Contatos**: notas de todo o cliente, ordenadas por date desc e time desc; ícone do canal; operador; data/hora; status; nota; detalhe Outros, se presente; próxima data, se presente. Editar/Excluir aparecem dentro de canExcluir (admin ou fin_cobranca_op:EXCLUIR). Na edição lateral, o único input exposto é o texto da nota, com **Cancelar/Salvar**; o handler também envia os valores de status/data que copiou ao iniciar edição.

## 2.3 Registrar Contato na lateral
| Campo | Padrão | Opções e regras |
|---|---|---|
| Forma de Contato | TELEFONE | Botões Telefone, WhatsApp, E-mail e Mensagem; selecionam metadado, sem discador/envio automático |
| Nota / Observação * | Vazio | Textarea 3 linhas; obrigatório não vazio após trim; placeholder “Descreva o contato, negociação ou observação...” |
| Status Negociação * | AGUARDANDO_CONTATO | Aguardando Contato; ENCAMINHOU_BOLETO=Encaminhou Boleto/Pix; FECHADA=Negociação Fechada; RECUSA_DIVIDA=Recusa Dívida; OUTROS |
| Próximo Contato | Vazio | Data opcional |
| Detalhe — Outros * | Vazio | Só aparece em OUTROS; obrigatório nesse caso; placeholder “Descreva o motivo...” |

**Registrar Nota** aciona handleSaveNote→saveNoteCore; botão bloqueia durante isSavingNote e muda para **Salvando...**. O título da seção é **Registrar Contato**, diferente do rótulo do botão. Não há opção SOLICITA_CANCELAMENTO nesse select lateral, nem inputs de simulação ou seletor de anexos embutidos da nota nesse formulário. Há um painel separado de Documentos armazenados associado ao título (capítulo 5).

## 2.4 Modal Registrar / Ver Contatos
Acionamento: botão da linha, ou **Ver** em solicitação cujo título foi resolvido. Cabeçalho: cliente; documento; vencimento; saldo atual; badge de próximo contato quando há.

**Voltar** fecha modal e overlay de conversa. **Ficha do Cliente** abre dados completos do cliente (não abre diretamente AdmissionViewerModal). **WhatsApp**, no cabeçalho, abre overlay de consulta GoTalk quando GotalkConversationsTab foi fornecido.

O corpo tem três colunas:
1. Dados Cadastrais e Valores da Dívida/simulação.
2. Abas Registrar Contato / WhatsApp; formulário e eventual chat adicional por canal.
3. Histórico de Contatos do título.

Ao mudar o ID do título do modal, começa na aba FORM. Abrir pelo botão da linha também reinicia modalNoteForm; abrir pelo card Ver apenas define o título, sem o mesmo reset explícito. Fechar por Voltar não limpa expressamente todos os estados globais de edição.

### Coluna 1 — dados e todos os valores
Cliente: Nome; CPF/CNPJ somente se **ctClient.cpfCnpj**; Telefone se phone; Celular se cellPhone; E-mail se email; Endereço se address, com cidade/UF. Sem cliente: **Dados do cliente não encontrados.**. Esse bloco não usa document como fallback do CPF/CNPJ, diferentemente do cadastro completo.

Valores somente leitura: **Valor Original**, **Juros (base)**, **Multa (base)**, **Desconto (base)** e **Saldo Atual**.

Simulação:
- **Juros (R$)**: interestSim, string vazia inicialmente; number min=0 step=0.01; placeholder juros base com duas casas.
- **Multa (R$)**: penaltySim, string vazia; mesmas características; placeholder multa base.
- **Desconto (R$)**: discountSim, string vazia; mesmas características; placeholder 0.00, embora vazio use desconto base no cálculo.
- **Saldo Simulado**, somente leitura: original + juros escolhidos/base + multa escolhida/base − desconto escolhido/base. Texto **Será registrado na nota do contato**.

Não recalcula o título persistido, não gera liquidação e não reduz currentBalance. É snapshot de negociação. A fórmula parte de originalValue, sem subtrair automaticamente os pagamentos já recebidos.

### Coluna 2 — todos os campos do formulário
| Campo | Padrão | Opções/efeito |
|---|---|---|
| Canal | TELEFONE | Select TELEFONE=Telefone; WHATSAPP=WhatsApp; EMAIL=E-mail; MENSAGEM=Mensagem |
| Status da Negociação | AGUARDANDO_CONTATO | Aguardando Contato; Encaminhou Boleto; Negociação Fechada; Recusa a Dívida; Outros; Solicitação de Cancelamento |
| Detalhe Outros | Vazio | Input condicional em OUTROS, “Descreva o status...” |
| Resumo de cancelamento | Ausente | Mostra contrato/data/anotações selecionados; **Selecionar Contrato** ou **Editar** abre submodal |
| Nota * | Vazio | Textarea 5 linhas; “Descreva o contato realizado...” |
| Próximo Contato | Vazio | Data opcional; legenda de criação de agendamento/notificação |
| Anexos | [] | **Adicionar arquivo(s)**, file multiple, sem accept/limite de tamanho explícito nesse input; FileReader para data URL |
| Salvar Contato | Botão | Indisponível enquanto salva ou nota vazia; grava via API |

Arquivos embutidos: mostra nome e botão para remover do formulário antes de salvar; o conteúdo é enviado no JSON da nota como name/dataUrl/type, não pelo upload do bucket.

Mudar canal para WHATSAPP e haver GotalkChatPanel monta um **chat adicional** “Conversa WhatsApp — {cliente}”, independentemente da aba unificada. Trocar canal para TELEFONE/EMAIL/MENSAGEM apenas classifica o registro: não efetua chamada, não envia e-mail nem mensagem interna por essa escolha isolada.

### Coluna 3 — Histórico de Contatos
Filtra notas por **titleId**, sem sort explícito nesse trecho; usa ordem do estado carregado/inserido. Cada cartão: ícone do canal; colaborador; data/hora; status; texto; snapshot da dívida; próxima data; solicitação vinculada e anexos com link de download quando presentes.

Snapshot: Original; Juros/Multa/Desconto somente se positivos; Saldo. Cancelamento: contrato, data e observações. Arquivos: nome, href=dataUrl, download=name.

**Duplo clique para editar** chama handleStartEditNote sem guarda canExcluir no handler de abertura do cartão. Diferentemente da lateral, esse acionamento não é ocultado por canExcluir. Campos de edição: **Nota**, **Status da Negociação** com as seis opções e **Próximo Contato**; **Cancelar/Salvar**.

Não há inputs para editar anexos, canal, snapshot, responsável, data original, detalhe Outros ou dados do cancelamento nesse editor. Selecionar SOLICITA_CANCELAMENTO na edição não abre o submodal nem cria automaticamente cancelRequest.

## 2.5 Salvar contato — sequência e padrões
Valida nota após trim, senão **Informe o texto da nota.**; OUTROS exige detalhe, senão **Descreva o status "Outros".**.

Cria objeto:
- id=`note_` + Date.now(); titleId e clientId do título.
- date=dia UTC (toISOString); time=hora local HH:mm.
- collaboratorId=currentCollaborator.id, senão currentUserId.
- collaboratorName=currentCollaborator.name, senão currentUser.name, senão **Operador**.
- Canal, nota com trim, próximo contato opcional, status e detalhe de Outros apenas nesse status.
- debtSnapshot com original, juros, multa, desconto e saldo calculados.
- attachments quando não vazios; cancelRequest se existir no objeto do formulário.

POST `/api/collection-notes`; em sucesso insere/mescla no estado local e também cancelNotesData se status for SOLICITA_CANCELAMENTO; registra auditoria NOTA_COBRANCA. Em falha mostra **Não foi possível salvar a nota.**; sempre libera o estado de salvamento. Sucesso reinicia o formulário correspondente, sem fechar obrigatoriamente o modal.

**Atenção ao zero:** para salvar snapshot usa `parseFloat(simulado) || valorBase || 0`; digitar zero faz fallback para base. A prévia do modal escolhe pela string preenchida e pode mostrar zero corretamente. Assim prévia e snapshot salvo podem divergir para “0”/“0.00”.

## 2.6 Agenda e mensagens após criar a nota
Se status **SOLICITA_CANCELAMENTO**: monta mensagem com cliente, operador, contrato, data, anotações, documento e saldo. Envia por MessagingContext aos grupos do usuário mais grupos cujo nome minúsculo contém **cobran**, **gerenci**, **diretor** ou **coordena**; remove IDs duplicados. Assunto **Solicitação de Cancelamento — {cliente}**.

Se não é cancelamento e há próximo contato: notifica grupos do usuário com assunto **Cobrança — {cliente}**, incluindo canal, status, nota e próxima data. Tenta POST `/api/appointments`:
- clientId/clientName do título.
- collaboratorId do colaborador resolvido ou currentCollaboratorId.
- serviceId vazio; date=nextContactDate.
- startTime **12:00**, endTime **12:30**.
- status **AGENDADO**; modalidade **ONLINE**.
- notes=`[Cobrança] {nota} — Canal: {canal}`.
- groupId=primeiro grupo do usuário, se houver.

O fluxo de cancelamento tem precedência: mesmo preenchendo próximo contato, não entra no ramo que cria agenda. Sem data e sem cancelamento, somente salva nota.

Falhas individuais de mensagem e agenda são silenciadas; o toast pode dizer **Agenda e mensagem de grupo atualizadas** ou **grupos notificados** sem garantir que essas integrações tenham concluído. Não há transação única nota+agenda+mensagens.

## 2.7 Editar e excluir notas
Salvar edição exige texto não vazio; PUT `/api/collection-notes/:id` com note, negotiationStatus e nextContactDate ou null. Atualiza as duas listas locais, registra NOTA_COBRANCA, limpa edição e mostra **Nota atualizada com sucesso.**. Falha mantém edição e mostra erro.

Editar próximo contato **não cria nem atualiza agenda** pelo handler de edição. Mudar status para cancelamento na edição **não notifica grupos** nem cadastra os dados de contrato pelo mesmo fluxo de criação. Outras propriedades antigas permanecem, inclusive cancelRequest quando mudar para outro status.

Excluir exige validarPermissao(fin_cobranca_op:EXCLUIR). Modal **Excluir Nota de Cobrança**, mensagem **Excluir esta nota de cobrança? Esta ação não pode ser desfeita.**. Confirma DELETE, auditoria, remoção das listas de notas e solicitações; não remove agenda ou mensagens anteriores.

## 2.8 Excluir título e confirmação compartilhada
Botão da linha visível quando admin ou fin_cobranca_op:EXCLUIR; handler chama validarPermissao. Modal **Excluir Título**; mensagem com documento e cliente e aviso de irreversibilidade. Confirmar faz DELETE `/api/financial-titles/:id`, auditoria CONTA_RECEBER, onRefresh e toast. Handler não tem bloqueio explícito por client.blocked, diferentemente do painel Coordenadores.

O backend impede excluir PAGO e membro de grupo com outro título pago; há vínculo de liquidações e demais regras de integridade que podem impedir a exclusão.

ConfirmDeleteModal tem **Cancelar/Excluir**, spinner e botões indisponíveis durante requisição; Escape ou fundo cancelam apenas quando não está carregando. Após tentativa, o fluxo fecha a confirmação, inclusive em erro. Excluir é diferente de cancelar título; este menu não expõe o PATCH de cancelamento financeiro.

## 2.9 Submodal Solicitação de Cancelamento
Selecionar SOLICITA_CANCELAMENTO no formulário do modal abre o submodal; **Selecionar Contrato/Editar** reabre.

Campos:
- **Ficha de Admissão / Contrato a Cancelar**: cartões de todas as admissões recebidas do cliente, sem filtrar status. Mostram contrato, data, pagas/total, financiado e status. Clique armazena admissionId e admissionContract (contrato ou ID).
- **Data da Solicitação**: data inicial hoje em UTC; editável, sem validação obrigatória explícita.
- **Anotações Gerais**: vazio, textarea 4 linhas; “Motivo, observações ou instruções para o cancelamento...”.

Sem admissões: **Nenhuma ficha de admissão encontrada para este cliente.**. **Confirmar Solicitação** só habilita com admissionId; copia dados para modalNoteForm, fixa status e preenche nota se vazia: **Solicitação de cancelamento — Contrato: {contrato}**. Apenas fecha o submodal; **a gravação ainda depende de Salvar Contato**.

**Cancelar** ou X fecha e muda status para AGUARDANDO_CONTATO; não executa cancelamento de contrato. Dados cancelRequest anteriores não são removidos explicitamente nessa operação. saveNoteCore não valida de novo contrato obrigatório para o status de cancelamento; a restrição principal está na confirmação do submodal.

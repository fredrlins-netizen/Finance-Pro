# Inventário funcional — Negociação

## 1. Escopo, método e limites

Este documento relaciona os campos, conteúdos padrão, opções, ações, grades, CRUD, modais, dashboards, integrações e relacionamentos encontrados no código atual do projeto. Abrange as duas entradas com o mesmo nome: **Comercial > Negociação** (`com_negociacao`) e **Financeiro > Negociação** (`fin_negociacao`).

O inventário descreve a implementação encontrada, não uma especificação de recursos futuros. Diferencia **interface acionável**, **API disponível sem acionador visual** e **comportamento não encontrado**. Não foram criados, alterados ou excluídos registros de negócio; não houve leitura de credenciais ou consulta a dados de produção. Os conteúdos de clientes, bancos, colaboradores e contratos são dinâmicos e privados: documenta-se sua origem, não os nomes e dados reais.

O escopo de dashboards compreende os indicadores do Comercial, o resumo Financeiro, Dashboard Cliente, Performance e indicadores da ficha do cliente. A página inicial geral é descrita para não ser confundida com esses painéis. Não se pretende inventariar todos os demais módulos do sistema.

Validação principal: leitura cruzada de componentes, handlers, rotas Express, tipos TypeScript, schema de referência e migrações de identidade. **Não houve validação interativa dos fluxos autenticados ou execução das operações descritas.** Um recurso presente na API não é apresentado como botão funcional da interface. O schema documentado é o versionado, não uma certificação do catálogo de produção.

Os marcadores F01…F17 do capítulo de evidências permitem localizar as fontes. O pacote inclui o inventário tabular de campos e ações, contratos de API, relacionamentos, opções em JSON e extração de todos os campos das interfaces de dados centrais.

## 2. Mapa de acesso e composição

| Entrada | Tela real | Composição | Forma de trabalho |
| --- | --- | --- | --- |
| Comercial > Negociação | Pipeline de Negociação Comercial | F01 | Quatro colunas Kanban, cards e modal único de inclusão/edição. |
| Financeiro > Negociação | Negociação Financeira | F02 dentro de F03 | Abas Negociações, Dashboard Cliente e Performance; ficha detalhada e consultas vinculadas. |
| Voltar do Financeiro | Cobrança — Coordenador | Callback fornecido por F03 | Aciona navegação `fin_cob_coordenador`, não o histórico do navegador. |
| Início / Dashboard geral | Identidade da empresa | F16 | Logo e nome da empresa; sem indicadores próprios de negociação. |

No Financeiro, F03 fornece clientes, colaboradores, admissões, bancos, usuário/colaborador logado, títulos e disponibilidade de WhatsApp. Os títulos vêm de um recurso paginado de Contas a Receber com **50 itens por página**. A barra inferior pagina esses títulos, não a grade de negociações. O Comercial pede **até 500 registros da primeira página**, sem controle de paginação visível.

Não foi encontrada conversão automática entre card Comercial e registro Financeiro: as tabelas e APIs são diferentes e as duas telas não sincronizam suas etapas/status entre si.

## 3. Negociação Comercial — visão completa

### 3.1 Kanban, colunas, cards e indicadores

Colunas fixas, na ordem de avanço: Triagem / Análise, Proposta Enviada, Aguardando Banco e Acordo Fechado. Cada cabeçalho mostra a contagem dos cards daquela etapa. A API/tipo também aceita `PERDIDO`, porém **não existe coluna nem opção de formulário correspondente**. Assim, um registro PERDIDO retornado pela API não aparece nas quatro colunas, embora entre nas somas do conjunto carregado.

Cada card contém: identificador abreviado com os últimos seis caracteres, cliente, banco/credor quando preenchido, observações opcionais em uma linha truncada, dívida original riscada, valor proposto e desconto percentual arredondado sem casas decimais. Fórmula: se dívida > 0, `(dívida − proposta) / dívida × 100`; caso contrário, 0. A apresentação antepõe o sinal de menos ao percentual; proposta superior à dívida não é barrada por regra explícita no handler.

Indicadores: **Total em Dívida** = soma de debtValue; **Potencial Acordo** = soma de proposalValue. Ambos abrangem todos os cards carregados, inclusive etapas fechadas e PERDIDO, sem deduplicação por cliente. Não são saldo contábil, receita recebida ou total garantido de toda a base quando há mais de 500 registros.

A área permite rolagem horizontal entre colunas e vertical dentro de cada coluna. Estados de tela: Carregando negociações..., Nenhuma negociação por coluna, toast de erro em falha de carregamento. Não há grade tabular alternativa, busca, filtros, seleção múltipla, edição inline, anexos, impressão ou exportação nesse componente.

### 3.2 CRUD Comercial e modais

**Incluir:** + Nova Negociação verifica INCLUIR, limpa formulário e abre modal Nova Negociação. Selecionar cliente cadastrado armazena ID e nome; sem seleção, aparece Nome do cliente (livre). Banco segue a mesma lógica: cadastro ou credor livre. Remover uma seleção mantém o nome anterior como texto editável, até que o usuário o altere.

**Consultar:** leitura dos cards carregados. Não há modal separado de consulta somente leitura.

**Alterar:** ícone Editar, condicionado a ALTERAR, abre o mesmo modal com os valores existentes. É possível escolher diretamente qualquer uma das quatro etapas; não é obrigatório percorrer cada coluna.

**Mover:** setas Avançar e Voltar surgem na lateral do card ao passar o ponteiro. Movimentam uma etapa por vez, sem arrastar e soltar real. Triagem não oferece Voltar e Fechado não oferece Avançar. Os botões de movimento não estão ocultos por canEdit, mas o handler recusa sem permissão. Atualização otimista: move primeiro na tela e desfaz se a API falhar.

**Salvar:** nome do cliente é obrigatório, com trim. Valores usam parseFloat ou 0. O formulário indica min 0 e passo 0,01, mas o clique de Salvar executa handler, sem validação financeira completa explícita. Não há aprovação bancária, envio de mensagem ou geração de títulos ao escolher Proposta Enviada/Fechado. Na gravação, Salvar vira Salvando... e fica desabilitado. Sucesso fecha modal; erro mantém o formulário.

**Excluir:** ícone Excluir exige EXCLUIR e abre confirmação Excluir Negociação, com a mensagem de exclusão irreversível contendo o nome do cliente. Confirmar executa DELETE e remove o card do estado; Cancelar preserva o registro. Não existe lixeira comercial nesse fluxo.

**Cancelar formulário:** fecha e limpa a referência de edição, sem chamada de gravação. Campos completos e padrões estão no capítulo 8 e no CSV.

Fontes: F01, F05, F10 e F11.

## 4. Negociação Financeira — tela principal e grades

### 4.1 Cabeçalho e abas

Título Negociação Financeira; subtítulo Gestão de negociações, propostas e metas. Voltar retorna ao Coordenador se o callback foi fornecido. Expandir/Minimizar alterna um contêiner fixo de tela cheia; não é fullscreen nativo do navegador. Abas: **Negociações** (inicial), **Dashboard Cliente** e **Performance**.

Na aba inicial, Resumo e Filtros começa recolhido. Exibir mostra quatro indicadores e os filtros; Ocultar recolhe sem limpar valores. Nova Negociação abre a criação. Os registros e metas são carregados ao montar o componente. As rotinas iniciais de leitura suprimem falhas sem toast específico, portanto lista vazia não é prova suficiente de que a base esteja vazia.

### 4.2 Grade de negociações

| Coluna | Conteúdo / origem | Acionamento |
| --- | --- | --- |
| Data | date em DD/MM/AAAA | Cabeçalho ordena. |
| Cliente | clientName e marcador compacto se bloqueado | Cabeçalho ordena; linha abre ficha. |
| Contrato | admission.contractNumber ou — | Consulta, sem ordenação própria. |
| Banco | Nome localizado por bankId ou — | Consulta, sem ordenação própria. |
| Valor Dívida | debtValue em BRL | Ordena por valor convertido, não lexicograficamente. |
| Negociador | collaboratorName | Cabeçalho ordena. |
| Status | Etiqueta colorida com um dos seis status | Cabeçalho ordena pelo valor técnico. |
| Próximo Contato | nextContactDate ou — | Destaque por proximidade; sem cabeçalho ordenável. |
| Ações | Histórico, Abrir, Excluir condicional | Cliques não propagam para a linha. |

Ordem inicial: Data descendente. Cabeçalho da mesma coluna alterna ascendente/descendente; uma nova coluna começa ascendente. Filtros locais: nome contém sem distinguir caixa, status exato, colaborador por ID, data inicial inclusiva e final inclusiva, sobre a **data de abertura**. Não há botão explícito Limpar Filtros na grade; limpa-se cada controle. Os filtros não afetam os cards de resumo, Dashboard Cliente ou Performance.

O lembrete fica vermelho pulsante se vencido, âmbar se hoje e amarelo se até três dias à frente; acima disso não recebe classe especial. A regra compara datas à meia-noite local e não cria notificação externa.

Estados: Carregando negociações... e Nenhuma negociação encontrada. Clique simples na linha ou Abrir entra na ficha em Dados. Não há edição inline, seleção em lote, exportação ou paginação local da lista de negociações.

### 4.3 Grade de títulos disponíveis

Título Títulos a Receber Disponíveis para Negociação, contador e busca Nome, CPF/CNPJ, telefone.... O filtro elimina `NAO_COBRAR`, títulos CANCELADO/AGRUPADO/PAGO e qualquer type diferente de PADRAO. Portanto não exige exclusivamente atraso: títulos ainda não vencidos podem aparecer.

Colunas: Cliente, Descrição (truncada), Documento, Emissão, Vencimento, Valor Original, Saldo, Status e Cobrança. Datas em DD/MM/AAAA. Vencido recebe destaque vermelho. Cobrança mostra Cobrar se collectionStatus=COBRAR, caso contrário Em Dia para os demais valores que passaram no filtro. Rodapé mostra quantidade e soma do currentBalance **dos títulos visíveis na página**.

A busca normaliza pontuação de documentos/telefones, espaços e caixa. Considera clientName do título e document, phone e phone2 do cadastro do cliente. Não consulta globalmente o servidor a cada digitação. Sem itens: Nenhum título disponível.

**Duplo clique** abre Nova Negociação com apenas o cliente pré-selecionado; limpa admissão, negociador e observações. Não associa titleId, não copia saldo/originalValue e não escolhe automaticamente o contrato. Não há CRUD do título nesta grade; manutenção e baixas pertencem ao módulo financeiro de origem.

Fontes: F02, F03, F04 e F12.

## 5. Criação Financeira e ficha detalhada

### 5.1 Modal Nova Negociação

É uma tela modal de tamanho integral, com Voltar no topo e Cancelar/Criar Negociação no rodapé. Campos: Cliente obrigatório, Admissão / Contrato opcional, Negociador obrigatório, Observações opcionais. Cliente e negociador começam sem seleção; não há nome livre. A lista de contratos é restrita ao cliente e aos status APROVADA, FINALIZADA, CONCLUIDO, AUDITADA e NEGOCIAÇÃO. Sem cliente, o seletor de admissão fica desabilitado.

Ao escolher contrato, o resumo mostra banco, valor financiado, total de parcelas × valor da parcela, parcelas vencidas e taxas de negociação dos serviços do banco. A exibição desse resumo exige admissão e banco localizados. A dívida gravada é o valor financiado formatado, não o saldo do contrato ou do título. Sem contrato, a dívida é enviada vazia; o modal não oferece campo manual para preenchê-la.

Criar envia data de hoje em UTC, cliente/negociador por ID e nome, admissão/banco opcionais, status ABERTA, dívida e observações. Cliente bloqueado não pode ser incluído. Campos obrigatórios ausentes geram aviso. Após tentativa de rede, sucesso ou erro, o handler fecha e limpa o formulário; nas saídas antecipadas de validação isso não ocorre. Cancelar/Voltar só fecham e não limpam explicitamente o estado. O botão Nova Negociação também não reinicializa explicitamente campos ao abrir.

O painel registra ações de teclado para salvar/cancelar a criação e cancelar a ficha; as combinações dependem da configuração global de atalhos e não são fixadas neste componente. Não há confirmação de alterações pendentes ou trava local de duplo envio explícita na criação financeira.

### 5.2 Cabeçalho da Ficha de Negociação

Mostra nome do cliente, status e indicação de bloqueio quando houver. A ficha sempre abre em Dados. Oferece Alterar Status, Ficha de Admissão quando vinculada e Voltar. O seletor de status só existe enquanto o status atual não for ACORDO_FECHADO, CANCELADA ou ENCERRADA; lista os outros cinco valores, excluindo o atual.

ABERTA (azul), EM_ANDAMENTO (âmbar), ACORDO_FECHADO (verde), ACORDO_QUEBRADO (vermelho), CANCELADA (cinza) e ENCERRADA (cinza-ardósia). Escolher CANCELADA ou ENCERRADA acrescenta closedDate=hoje. Escolher manualmente ACORDO_FECHADO **não preenche closedValue, closedInstallments ou closedDate**; isso difere do aceite de uma proposta pela API. Ao tornar-se fechado/cancelado/encerrado, o seletor desaparece, sem botão de reabertura neste fluxo. ACORDO_QUEBRADO continua com o seletor e formulários.

Abas: Dados, Contatos (quantidade), Propostas (quantidade), Metas; botão Ficha do Cliente e WhatsApp condicional. O banner de bloqueio é exibido na ficha. Criar, adicionar contato, adicionar proposta e alterar status possuem verificação de cliente bloqueado nos handlers; não se deve supor que todas as outras ações tenham a mesma verificação.

### 5.3 Aba Dados

Dados da Admissão, se localizada: Contrato, Banco, Valor Financiado, Parcela, Total Parcelas, Pagas, Vencidas, Status Admissão, Veículo (marca/modelo) se houver marca e Placa se informada. Botão Ver Ficha de Admissão.

Taxas de Negociação do Banco: um cartão por serviço, com nome e negotiationPercentage, se banco e serviços existirem. São informações de referência; não ajustam automaticamente desconto nem impõem teto na proposta.

Dados da Negociação: Data Abertura, Negociador, Valor Dívida, Status; Data Fechamento, Valor Acordo e Parcelas Acordo quando preenchidos; Observações quando existentes. Essa aba não contém formulário geral de edição de cliente, contrato, dívida, negociador ou notas.

### 5.4 Aba Contatos

Histórico em linha do tempo, em ordem inversa ao array retornado: canal, resposta, data/hora, descrição, próxima ação/data/descrição se existente, colaborador e Excluir se permitido. Respostas e cores: Atendeu verde, Não Atendeu vermelho, Recado amarelo, Caixa Postal cinza, Recusou vermelho escuro, Interessado verde-esmeralda e Sem Resposta cinza claro.

Novo Contato oferece Data, Hora, Canal, Resposta, Descrição, Data Próxima Ação e Descrição Próxima Ação. Defaults: hoje em UTC na montagem, hora vazia, Telefone, Atendeu e textos/datas seguintes vazios. Canal e resposta apenas classificam o registro; selecionar WhatsApp não abre nem envia uma conversa e selecionar E-mail/SMS não dispara comunicação.

Descrição é obrigatória. Autor = colaborador do usuário logado ou negociador da ficha. Salvar chama POST; o servidor altera ABERTA para EM_ANDAMENTO e atualiza a próxima ação com os valores fornecidos. Campos descrição, hora e próxima ação são limpos após tentativa de gravação; data/canal/resposta persistem no estado.

O formulário desaparece para ACORDO_FECHADO, CANCELADA ou ENCERRADA e o botão fica desabilitado se cliente bloqueado. A exclusão continua disponível por permissão, sem condição de status terminal nesse botão; exige confirmação Excluir Contato. Depois de excluir, o servidor procura o **contato mais recente por data/hora com próxima data informada**, não a próxima data cronologicamente mais próxima. Se nenhum restar, limpa o lembrete.

Existem estado de edição, openEditContact, handleSaveEditContact e endpoint PUT, mas **não há chamada visual para abrir edição nem modal de edição renderizado**. Não apresentar como CRUD completo de contatos pela interface.

### 5.5 Aba Propostas

Resumo Banco e Taxas Máximas de Negociação: nome do banco, código Febraban, serviço e percentual; contrato, valor financiado e parcelamento se houver admissão. Sem serviços, informa Nenhum serviço cadastrado para este banco. O termo Máximas é um rótulo: não foi encontrada validação vinculando esse percentual ao desconto digitado.

Grade Propostas Enviadas: Data, Valor Original, Desconto (uma casa), Valor Proposta, Parcelas (Nx), Valor Parcela, Status e Ações. Em Ações aparecem data da resposta ou — e Excluir quando permitido; **não há Editar, Aceitar, Recusar ou seletor de status renderizados**.

Nova Proposta só aparece em status não terminal. Valor Original é somente leitura, derivado da dívida; Desconto numérico começa 0 e informa min=0, max=100, step=0,5; Valor da Proposta é calculado; Parcelas começa 1 com min=1; Valor da Parcela é calculado; Entrada é moeda opcional vazia; Observações livres.

Fórmulas: proposta = dívida × (1 − desconto/100); saldo a parcelar = proposta − entrada; parcela = saldo/quantidade. Cálculos formatam BRL com duas casas; não há calendário de parcelas, juros, multa, taxa bancária automática ou compensação explícita de arredondamento entre parcelas. Exemplo fictício: dívida R$ 10.000,00, desconto 20%, entrada R$ 2.000,00 e 6 parcelas resultam em proposta R$ 8.000,00 e parcela R$ 1.000,00.

Registrar Proposta grava status ENVIADA, data atual e autor, e muda ABERTA para EM_ANDAMENTO. Isso **não significa envio real** por WhatsApp ou e-mail. Cliente bloqueado é impedido. Não há guarda explícita no handler contra desconto fora da faixa ou entrada maior que a proposta; atributos HTML não equivalem a uma validação de negócio completa.

Status previstos: Enviada, Em Análise, Aceita, Recusada, Contra-Proposta, Expirada e Cancelada. Handlers de alteração/edição estão definidos, mas sem acionador JSX/modal. O PUT com status ACEITA fecha o registro como ACORDO_FECHADO, usa responseDate ou hoje, e grava closedValue/closedInstallments a partir dos campos fornecidos. **Não cria títulos, boletos ou parcelas em financial_titles nessa rotina.** Se o chamador enviar apenas status, os dados de fechamento podem ficar nulos; o handler não visível de aceite envia também valor e parcelas.

Excluir exige confirmação Excluir Proposta e permissão; remove proposta sem reabrir nem recalcular acordo fechado. Alterar uma proposta antes aceita para outro status via API também não reverte automaticamente o fechamento. Um POST já com ACEITA não executa a regra de fechamento do PUT.

### 5.6 Aba Metas

Meta do Mês Atual consulta metas por colaborador logado (ou negociador da ficha) e **mês/ano atuais do calendário**. Mostra Meta Valor, Atingido Valor, Meta Acordos, Atingido Acordos e progresso, ou Nenhuma meta definida para este mês. O progresso usa atingidoValor/metaValor; meta zero resulta em 0%. Verde a partir de 80%, âmbar a partir de 50%, vermelho abaixo; barra limitada visualmente a 100%.

Definir / Atualizar Meta contém Meta de Valor (R$), Meta de Acordos (R$) e Salvar Meta. Embora targetCount/achievedCount indiquem contagem no nome técnico, a UI trata ambos como moeda. Ao clicar na aba, a meta de valor recebe a dívida da negociação; se há proposta, Meta de Acordos recebe a economia da última proposta (original − proposta). Não é preenchimento pela meta existente; sem proposta o segundo valor anterior não é explicitamente limpo.

Salvar usa **perfMonth/perfYear dos filtros Performance**, o que pode divergir da competência exibida em Meta do Mês Atual. POST realiza upsert por colaborador+mês+ano. A tela não envia atingidos e a API coloca default '0'; por isso uma atualização pode zerar atingidos já existentes. Não há atualização automática de metas atingidas nas rotas financeiras de negociação examinadas, nem exclusão de meta na tela/API.

### 5.7 Modal de exclusão compartilhado

Títulos conforme contexto: Excluir Negociação, Excluir Contato ou Excluir Proposta. Confirmar usa Excluir, Cancelar preserva dados, Escape e clique fora cancelam quando não está carregando. Durante requisição, botões ficam desabilitados, mostra spinner e callback de cancelamento ignora o fechamento. Após finalizar, fecha; falhas geram toast conforme a rotina.

Fontes: F02, F04, F07 e F08.

## 6. Fichas e integrações acionadas

### 6.1 Ficha do Cliente — consulta

Botão Ficha do Cliente abre sobreposição com nome, Dados Completos — Somente Leitura, Histórico e Voltar. Cadastro inicia selecionada. Não edita dados do cadastro.

Cadastro exibe: Nome/Razão, Tipo (Pessoa Física se FISICA, caso contrário Pessoa Jurídica), CPF/CNPJ, RG, Telefone, Telefone 2, E-mail, Profissão, Estado Civil, Nascimento, Endereço completo (logradouro, número, complemento, bairro, cidade/UF e CEP), Observações se houver e banner de bloqueio. Ausências em geral recebem —; partes do endereço podem ficar vazias.

Títulos (contador) reúne títulos carregados do cliente, não somente os elegíveis da grade inicial. Cards: Total; Em Aberto exclui PAGO/CANCELADO/AGRUPADO; Liquidados conta PAGO; Saldo Devedor soma saldo dos não pagos/cancelados/agrupados. Grade: Documento, Descrição, Vencimento, Valor original, Saldo e Status. Liquidado recebe fundo verde; vencido não pago/cancelado recebe vermelho. Sem baixa, edição, exclusão ou duplo clique de negociação neste painel.

Admissões (contador) considera **todas as admissões recebidas do cliente**, sem os cinco status do seletor de nova negociação. Cada cartão mostra Contrato, banco se localizado, Valor Financiado, Parcela, parcelas pagas/total, Vencidas, Veículo e Placa condicionais. Ver Ficha busca a admissão completa. Sem registros, mostra mensagem.

Histórico da ficha do cliente usa entityId do cliente, não ID da negociação. Há diferença entre as propriedades passadas nessa chamada (entityType/className e ausência de entityName) e o contrato atual de AuditLogButton, que requer entityName e não usa aquelas duas propriedades. A consulta por ID existe no componente, mas título/subtítulo e estilo personalizados não devem ser considerados garantidos por essa passagem. Não foi executada validação visual autenticada desse detalhe.

### 6.2 Visualizador Ficha de Admissão

Ao clicar Ficha de Admissão/Ver Ficha, solicita `/api/admissions/:id`; 403 mostra aviso e não abre. Outras falhas fazem o chamador usar a admissão local, possivelmente parcial. É modal compartilhado com quatro abas, somente leitura:

- **Identificação:** Cliente (Responsável), Contrato, Data Admissão, Status, Tipo Cliente, Série, Colaborador, Indicação e Origem; Unidade quando fornecida. Se objetos completos forem fornecidos, também mostra dados do responsável (Nome, CPF/CNPJ, RG, Nascimento, Estado Civil, Profissão, Telefone/Telefone 2, E-mail, Endereço, Anotações) e titular (Nome, CPF/CNPJ, RG, Telefone, E-mail). Veículo condicional: Marca, Modelo, Ano, Placa, Cor, Chassi, Renavam e indicação ELÉTRICO. Informações adicionais: Taxa Administração e Primeira Parcela.
- **Contrato / Financeiro:** Banco, Modalidade, Tarifa Bancária Inclusa e Contrato De Terceiro quando aplicáveis; serviços do banco com percentual e cálculo sobre valor financiado; Valor Financiado, Valor Parcela Atual, Total Parcelas, Pagas/Em Atraso, Dia Vencimento, Tipo Pagamento, Venc. 1ª Parcela, Taxa Administrativa, 1ª Parcela Real, Taxa de Cobrança e Desconto quando preenchidos. Cenários de Recálculo: Cenário, Dívida Original, Nova Dívida, Economia, Parcelas, Valor Parcela e Dia Vencimento.
- **Documentos:** soma contador de anexos legados e bucket; carrega anexos legados sob demanda, com título, nome e conteúdo; permite visualizar em janela/iframe e baixar. Falha mostra aviso e Tentar novamente. Painel de bucket recebe clientId, módulo ADMISSION e targetId da admissão, com readOnly e compact; mantém Filtrar..., Atualizar, Ver (imagens/PDF), Baixar e paginação de 25 itens por cursor. Mostra nome do arquivo, categoria ou Sem categoria, módulo, tamanho em KB/MB e identificador PDF/DOC. Busca aplica trim após 300 ms e volta à primeira página. Ver abre `/content?browser=1` em nova aba e Baixar usa `/download?browser=1`; sem modal de edição de documentos. Estados: carregando, erro, Nenhum documento encontrado ou Nenhum documento armazenado para este contexto. Sem upload/exclusão/edição de ACL por esse caminho.
- **Auditoria:** busca consulta jurídica registrada sob demanda por legal-scan; distingue carregamento, acesso negado, erro e não realizada. Exibe histórico jurídico por componente compartilhado, sem nova consulta externa. Rounds mostram número, data da crítica, responsável/crítica, resposta, autor e data da resposta quando existentes. Botão Fechar encerra visualizador.

Na consulta jurídica histórica, os campos condicionais são: data da última atualização, indicação de processo localizado/não localizado, número do processo, tribunal, última movimentação e parte autora. Havendo allProcesses, a lista mostra por processo número, tribunal, classe, assunto, parte autora, data de ajuizamento e última movimentação. O aviso informa que resultado histórico não representa consulta atual. Não existe botão de nova pesquisa nesse componente.

**Limite específico do caminho Negociação:** ele passa somente admission, clientName e onClose ao visualizador. Não fornece os objetos opcionais client, titular, bank, modality, seriesSigla, collaboratorName ou unitName. Portanto os blocos dependentes deles não surgem ou mostram —, mesmo que o componente compartilhado os suporte. As taxas exibidas na própria Ficha de Negociação não significam que o mesmo objeto bank seja passado ao visualizador.

Documentos privados são sujeitos às regras de acesso do módulo/anexo. Ter botão de download não garante acesso a todo arquivo. O arquivo ZIP deste inventário **não contém documentos de clientes**.

### 6.3 Histórico de Movimentações

Relógio da grade abre modal somente leitura. Busca até 500 logs por entity_id; a propriedade logs recebida no chamador não é a fonte usada pelo componente atual. Ordena por timestamp decrescente e expande cada alteração em uma linha por campo. Colunas: Data/Hora, Usuário, Ação, Campo, De, seta e Para. Se não há alterações detalhadas, usa descrição no valor novo. Paginação local de 15 linhas; botões anterior/próxima; fechar por X ou clique no fundo. Sem editar, excluir ou exportar.

As rotas financeiras executam mutações e auditoria obrigatória na mesma transação, com snapshots antes/depois, usuário e IP quando disponíveis. Há também logTransaction em parte dos handlers de tela; a existência dele não implica contagem única de eventos no histórico. O roteador Comercial examinado não chama a mesma rotina de auditoria transacional de negociação.

### 6.4 WhatsApp / GoTalk

O painel pai só fornece a aba se gotalkEnabled estiver ativo e o componente existir. Abrir a aba recebe clientId e faz GET do contato vinculado e GET de até 500 mensagens. Sem vínculo, informa Nenhum contato WhatsApp vinculado a este cliente e orienta cadastrar em outra tela; não há vínculo novo nessa aba.

Cabeçalho: avatar com inicial, nome, telefone do contato, contador e Atualizar. Filtros: Data Inicial, Data Final e Atendente (opções únicas ordenadas das mensagens; campo livre quando não há opções). Limpar Filtros aparece quando algum valor foi informado. Filtragem local inclusiva por data e por nome do atendente sem distinguir caixa. Mensagens sem data não são automaticamente eliminadas por filtro de data.

Mensagens são separadas por dia; entrada à esquerda e saída à direita, com horário, corpo/mídia e atendente/setor ou área nas saídas. O renderizador compartilhado recebe tipo, URL/nome/MIME/tamanho do anexo, transcrição, corpo e metadados de template (cabeçalho/corpo/rodapé/categoria/status). ACK: 1 um visto cinza; 2 dois vistos cinza; 3 ou mais dois vistos azuis; ausente não mostra símbolo.

**Sem envio, gravação de áudio, criação de template, reatribuição de atendimento ou automação da proposta nesta aba.** O módulo integra consulta GoTalk; a existência de uazapi em outras telas não estabelece envio por uazapi neste caminho. Atualizar refaz as consultas; não há polling periódico ou assinatura de eventos nesse componente de histórico.

### 6.5 Outras integrações e efeitos relacionais

- Bancos/serviços fornecem nomes, Febraban e percentuais; não há consulta bancária externa ao movimentar coluna.
- Clientes e colaboradores alimentam seletores e nomes; identidades relacionais usam IDs, não nomes livres para vínculos.
- Admissões fornecem contrato, banco, dívida inicial e consultas vinculadas; não são criadas/alteradas pelo cadastro de negociação.
- Contas a Receber fornece títulos paginados. Cancelamento de título no backend cancela negociações vinculadas por title_id, adiciona observação e a listagem de negociações as oculta se o título está CANCELADO. O efeito depende do vínculo realmente existir; o duplo clique atual não o cria. A cascata inclui acordos fechados porque exclui apenas CANCELADA/ENCERRADA na condição SQL.
- Próxima ação é um lembrete no registro, não evento de Agenda, notificação push, e-mail ou WhatsApp.
- Aceite de proposta altera registro/proposta; não há INSERT de financial_titles, liquidação ou emissão de boleto nesse endpoint.
- Nenhum acionamento de IA, assinatura eletrônica, motor de juros, integração bancária de cobrança, relatório/exportação ou nova consulta jurídica foi encontrado nas ações desses dois painéis. Recursos existentes em outros módulos não são automaticamente funcionalidades da Negociação.

Fontes: F02, F03, F06–F09, F12 e F13.

## 7. Dashboards, fórmulas e opções

### 7.1 Resumo Financeiro

| Indicador | Cálculo | Escopo / interpretação |
| --- | --- | --- |
| Total Negociações | records.length | Registros carregados, não apenas os filtrados da grade. |
| Em Andamento | Quantidade status EM_ANDAMENTO | Não inclui ABERTA. |
| Acordos | Quantidade status ACORDO_FECHADO | Conta mesmo se closedValue não estiver preenchido. |
| Valor Recuperado | Soma closedValue em ACORDO_FECHADO | Acordos registrados, não baixas de caixa. |

### 7.2 Dashboard Cliente

Selecionar Cliente é a única seleção própria; inicia vazia. Usa todos os registros carregados com o mesmo clientId e admissões recebidas desse cliente, sem herdar filtros da grade.

| Card | Fórmula |
| --- | --- |
| Dívida Total | Soma debtValue de todas as negociações do cliente. |
| Valor Negociado | Soma closedValue de todos os registros que o possuem, independentemente do status atual. |
| Valor Recuperado | Soma closedValue apenas onde status=ACORDO_FECHADO. |
| % Recuperação | Recuperado / Dívida Total × 100; denominador zero resulta em 0%; uma casa decimal. |

Linha do Tempo de Ações agrega contatos e propostas de todas as negociações do cliente, ordenando por data ascendente (antigas primeiro); não usa hora como critério explícito de desempate. Contato: canal, data, resposta e descrição; proposta: data, valor, desconto, parcelas e status. Sem ações: Nenhuma ação registrada.

Grade de propostas consolidadas: Data, Valor Original, Desc. %, Valor Proposta, Parcelas e Status; somente leitura, sem Ações ou edição. Sem propostas: Nenhuma proposta. Não há ordenação/paginação própria.

Admissões do Cliente mostra todas as admissões recebidas do cliente, com Contrato, Banco, Valor Financiado, Parcela, Total Parcelas, Pagas, Vencidas e Status, além de taxas por serviço do banco. Não são os cinco status do seletor. Esse bloco do Dashboard não possui o botão Ver Ficha presente na sobreposição Ficha do Cliente.

Se o mesmo cliente tem várias negociações para a mesma dívida, a soma considera cada registro; não foi encontrada deduplicação por contrato/título. Por isso Dívida Total é soma de negociações, não necessariamente saldo único consolidado do cliente.

### 7.3 Performance

Mês: 01 a 12, padrão mês atual; Ano: opções fixas 2024, 2025, 2026, padrão ano atual. O período é extraído de **r.date, a abertura**, via Date.getMonth/getFullYear, e não da data de fechamento, resposta ou pagamento. O parse usa Date do navegador; datas ISO sem horário exigem atenção em mudanças de fuso/dia.

| Indicador | Cálculo no período |
| --- | --- |
| Taxa de Conversão | Quantidade de ACORDO_FECHADO / total de negociações × 100; zero quando sem registros. |
| Ticket Médio Recuperado | Soma closedValue dos acordos / quantidade de acordos; zero sem acordos. |
| Taxa de Recuperação | Soma closedValue dos acordos / soma debtValue de todos os registros do período × 100. |
| Total Acordos | Quantidade de registros ACORDO_FECHADO no conjunto de aberturas do período. |

Ranking de Negociadores: posição, Nome, Carteira (R$), Recuperado (R$), % Atingido, Acordos e Pontos. Agrupa por collaboratorId; Carteira soma dívida; Recuperado soma fechamento de acordos; % Atingido=recuperado/carteira×100, **não percentual da meta cadastrada**. Pontos somente para acordo com closedValue: 1 parcela=3 pontos; 2–6=2; 7–12=1; mais de 12=0,5. Sem closedInstallments considera 1. Ordena por pontos descendentes, sem desempate adicional explícito. Sem dados: Nenhum dado para o período.

Metas por Colaborador aparece se há metas para mês/ano selecionados. Usa targetValue/achievedValue armazenados; mostra nome, atingido/meta, barra e acordos atingidos/meta, apresentados como moeda. Verde >=80%, âmbar >=50%, vermelho abaixo, largura limitada a 100%. Não substitui esses valores por cálculos do ranking.

Performance por Negociador desenha barras locais por pontos, relativas ao maior valor (denominador mínimo 1), com nome, pontos e valor recuperado. Não são barras por valor ou meta; sem ranking o bloco não aparece.

### 7.4 Indicadores do cliente e dashboard geral

Os quatro cards de Títulos na Ficha do Cliente estão descritos em 6.1 e só abrangem a página fornecida. Os dois totais do Kanban estão em 3.1 e só abrangem até 500 registros carregados. O início geral exibe logo configurado e nome da empresa; sem logo mostra orientação para cadastrá-lo em Configurações > Portal. Não há outro dashboard de negociação nessa página inicial.

Nenhum desses painéis oferece CRUD de métricas, exportação, impressão, salvamento de visão ou customização de widgets no código examinado.

## 8. Catálogo completo de campos, padrões e opções

Valores como “hoje”, “nome do cliente selecionado” ou “banco da admissão” são conteúdos dinâmicos, não textos fixos. Placeholders R$ 100.000,00 e R$ 0,00 não são valores gravados automaticamente. “Vazio” significa estado inicial do controle; a API pode convertê-lo em null ou ausente conforme o endpoint.

| Área | Campo | Rótulo | Tipo | Conteúdo padrão | Opções / origem | Função / regra |
| --- | --- | --- | --- | --- | --- | --- |
| Comercial / formulário | clientId | Cliente cadastrado | select / UUID opcional | Sem seleção | config.clients: ID e nome | Selecionar preenche clientName e oculta nome livre; desmarcar preserva o último nome. |
| Comercial / formulário | clientName | Nome do cliente | texto | Vazio | Cadastro ou digitação livre | Obrigatório; trim antes de salvar; entrada livre somente sem clientId. |
| Comercial / formulário | bankId | Banco / Credor cadastrado | select / UUID opcional | Sem seleção | config.banks: ID e nome | Selecionar preenche bankName; sem vínculo permite texto livre. |
| Comercial / formulário | bankName | Banco / Credor livre | texto opcional | Vazio | Ex: Banco do Brasil, Bradesco... (placeholder) | Não obrigatório; nome mantido ao remover a seleção do banco. |
| Comercial / formulário | debtValue | Valor da Dívida | número | 0 | min 0; step 0,01 | parseFloat ou zero; base do desconto do card. |
| Comercial / formulário | proposalValue | Valor Proposto | número | 0 | min 0; step 0,01 | parseFloat ou zero; não há regra explícita impedindo valor maior que a dívida. |
| Comercial / formulário | stage | Etapa | select | TRIAGEM | TRIAGEM / PROPOSTA / AGUARDANDO_BANCO / FECHADO | Pode escolher diretamente qualquer coluna do formulário; API também admite PERDIDO. |
| Comercial / formulário | notes | Observações | textarea | Vazio | Observações internas... (placeholder) | Texto interno; resumo truncado no card. |
| Comercial / dados técnicos | id | Identificador | UUID | Gerado no banco | commercial_deals | Card mostra apenas os seis últimos caracteres. |
| Comercial / dados técnicos | collaboratorId | Colaborador | referência opcional | Não enviado pelo formulário | collaborators | Disponível na API; não é seletor da tela comercial. |
| Comercial / dados técnicos | collaboratorName | Nome do colaborador | texto opcional | Não enviado pelo formulário | API | Informativo; vínculo se dá pelo ID. |
| Comercial / dados técnicos | unitId | Unidade | UUID opcional | Não enviado pelo formulário | companies | Campo da API; não existe seletor próprio neste modal. |
| Comercial / dados técnicos | createdAt | Criado em | timestamp | NOW() no banco | API | Não editável nem exibido no card. |
| Comercial / dados técnicos | updatedAt | Atualizado em | timestamp | NOW() no banco | API | Atualizado em edição/movimentação; ordenação da listagem no servidor. |
| Financeiro / nova negociação | newClientId / clientId | Cliente | select / UUID | Sem seleção | clients recebidos do painel pai | Obrigatório na interface; mudar cliente limpa admissão; cliente bloqueado impede criar. |
| Financeiro / nova negociação | clientName | Nome do cliente | texto automático | Nome do cliente selecionado | clients.name | Não há digitação livre neste formulário; backend exige nome. |
| Financeiro / nova negociação | newAdmissionId / admissionId | Admissão / Contrato | select opcional / UUID | Sem seleção | Admissões do cliente nos cinco status permitidos | Desabilitado sem cliente; exibe contrato, valor financiado e banco. |
| Financeiro / nova negociação | bankId | Banco | referência automática | Banco da admissão; ausente sem contrato | admissions.bankId | Não há seletor independente no Financeiro. |
| Financeiro / nova negociação | newCollaboratorId / collaboratorId | Negociador | select | Sem seleção | collaborators recebidos do painel pai | Obrigatório; não é preenchido automaticamente pelo usuário logado ao criar. |
| Financeiro / nova negociação | collaboratorName | Nome do negociador | texto automático | Nome do colaborador selecionado | collaborators.name | Enviado como nome descritivo, com vínculo pelo ID. |
| Financeiro / nova negociação | newNotes / notes | Observações | textarea opcional | Vazio | Observações iniciais... (placeholder) | Salvas na criação; aba Dados é somente leitura para este campo. |
| Financeiro / nova negociação | date | Data de abertura | data automática | Dia atual em UTC, YYYY-MM-DD | new Date().toISOString() | Sem campo para alterar na criação. |
| Financeiro / nova negociação | status | Status inicial | texto automático | ABERTA | status_negociacao | Muda pelo seletor da ficha ou pelas regras de contatos/propostas da API. |
| Financeiro / nova negociação | debtValue | Valor Dívida | moeda como texto | financedAmount formatado; vazio sem admissão | Admissão selecionada | Não existe entrada manual no modal financeiro; não usa automaticamente o saldo de um título. |
| Financeiro / nova negociação | titleId | Título de origem | UUID opcional | Não enviado pelo modal atual | financial_titles | Tipo e API suportam vínculo; duplo clique no título não o preenche. |
| Financeiro / registro técnico | id | Identificador | texto | Servidor gera base36 de tempo + componente aleatório | negotiation_records | Não é UUID obrigatório. |
| Financeiro / registro técnico | contacts | Contatos | lista | [] | negotiation_contacts.record_id | Retornada com o registro completo. |
| Financeiro / registro técnico | proposals | Propostas | lista | [] | negotiation_proposals.record_id | Retornada com o registro completo. |
| Financeiro / registro técnico | nextContactDate | Próximo Contato | data opcional | Ausente | Próxima ação de contato | Criação de contato preenche se informado; edição/exclusão recalcula pelo contato mais recente com próxima data. |
| Financeiro / registro técnico | nextContactDescription | Descrição próxima ação | texto opcional | Ausente | Contato | Acompanha nextContactDate; não é um compromisso criado na Agenda. |
| Financeiro / registro técnico | closedDate | Data Fechamento | data opcional | Ausente | Aceite da proposta; cancelamento ou encerramento manual | Escolher manualmente ACORDO_FECHADO não preenche automaticamente data/valor/parcelas. |
| Financeiro / registro técnico | closedValue | Valor Acordo | moeda como texto opcional | Ausente | discountedValue no aceite via API | Base dos indicadores de recuperação; não comprova recebimento. |
| Financeiro / registro técnico | closedInstallments | Parcelas Acordo | inteiro opcional | Ausente | installments no aceite via API | Base da pontuação; sem valor a performance usa 1. |
| Financeiro / registro técnico | created_at / updated_at | Datas técnicas | timestamp no banco | NOW() | Banco | Não retornadas pelo mapRecordRow e sem campo na ficha. |
| Financeiro / filtros e navegação | activeTab | Aba principal | botões | NEGOCIACOES | Negociações / Dashboard Cliente / Performance | Troca conteúdo sem navegar para outra rota. |
| Financeiro / filtros e navegação | showCardsFilters | Resumo e filtros | alternância | Oculto | Exibir / Ocultar Resumo e Filtros | Ocultar não limpa filtros já aplicados. |
| Financeiro / filtros e navegação | filterClient | Buscar cliente | texto | Vazio | Nome do registro | Contém, sem distinguir maiúsculas; não normaliza acentos. |
| Financeiro / filtros e navegação | filterStatus | Status | select | Todos Status | Todos + seis status de negociação | Igualdade exata; filtro local. |
| Financeiro / filtros e navegação | filterCollaborator | Negociador | select | Todos Negociadores | Todos + colaboradores | Compara collaboratorId; filtro local. |
| Financeiro / filtros e navegação | filterDateStart | Data inicial | date | Vazio | date do registro | Inclusivo: date >= início. |
| Financeiro / filtros e navegação | filterDateEnd | Data final | date | Vazio | date do registro | Inclusivo: date <= fim; sem validação explícita de intervalo invertido. |
| Financeiro / filtros e navegação | sortColumn / sortDirection | Ordenação da grade | clique no cabeçalho | date / desc | Data, Cliente, Valor Dívida, Negociador e Status | Mesma coluna alterna asc/desc; nova coluna inicia asc; moeda convertida para comparar. |
| Financeiro / filtros e navegação | receivableSearch | Busca de títulos | texto | Vazio | Nome, CPF/CNPJ, telefone e telefone 2 | Remove pontuação . - / ( ) e espaços; minúsculas; somente títulos carregados. |
| Financeiro / filtros e navegação | dashboardClientId | Selecionar Cliente | select | Selecione um cliente... | clients | Sem seleção mostra instrução; seleção recalcula painel. |
| Financeiro / filtros e navegação | perfMonth | Mês | select | Mês atual em dois dígitos | 01 a 12 | Filtra performance por data de abertura; também é usado ao salvar metas. |
| Financeiro / filtros e navegação | perfYear | Ano | select | Ano atual | 2024, 2025 e 2026 | Lista fixa; futuros anos não constam automaticamente nas opções. |
| Financeiro / filtros e navegação | isFullscreen | Tela cheia | alternância | false | Expandir / Minimizar | Sobreposição CSS; não usa a API de fullscreen do navegador. |
| Financeiro / filtros e navegação | fichaTab | Aba da ficha | botões | DADOS ao abrir | Dados / Contatos / Propostas / Metas / WhatsApp condicional | Contatos e Propostas exibem contadores. |
| Financeiro / filtros e navegação | clientPanelTab | Aba da ficha do cliente | botões | Cadastro ao abrir | Cadastro / Títulos / Admissões | Consulta somente leitura; títulos limitados à página recebida. |
| Financeiro / novo contato | date | Data | date | Dia atual em UTC na montagem do painel | contactDate | Não é renovada automaticamente a cada abertura de ficha. |
| Financeiro / novo contato | time | Hora | time | Vazio | HH:mm | Limpa após tentativa de salvar. |
| Financeiro / novo contato | channel | Canal | select | TELEFONE | canais_contato: seis opções | Classificação do contato; não dispara ligação, WhatsApp, SMS, e-mail ou carta. |
| Financeiro / novo contato | response | Resposta | select | ATENDEU | respostas_contato: sete opções | Altera rótulo/cor do histórico; não dispara automação específica por resposta. |
| Financeiro / novo contato | description | Descrição | textarea | Vazio | Descreva o contato realizado... (placeholder) | Obrigatória na interface e API; verificação de presença, sem trim explícito no handler. |
| Financeiro / novo contato | nextActionDate | Data Próxima Ação | date opcional | Vazio | contactNextDate | Atualiza lembrete do registro; não gera item de agenda nesta rotina. |
| Financeiro / novo contato | nextActionDescription | Descrição Próxima Ação | texto opcional | Vazio | O que fazer na próxima ação... (placeholder) | Atualiza descrição do lembrete quando fornecida. |
| Financeiro / novo contato | collaboratorId / collaboratorName | Autor do contato | automático | Colaborador logado; na falta, negociador do registro | currentCollaboratorId / collaborators | Nome obtido do cadastro ou — se não localizado. |
| Financeiro / novo contato | id / record_id | Identificadores | texto automático | Gerado pelo servidor / ID da negociação da URL | negotiation_contacts | Contato pertence a uma única negociação. |
| Financeiro / nova proposta | date | Data | automático | Dia atual em UTC ao registrar | todayStr() | Sem campo editável no formulário. |
| Financeiro / nova proposta | originalValue | Valor Original | moeda, somente leitura | debtValue do registro | negociação selecionada | Não é saldo atualizado automaticamente por baixa financeira. |
| Financeiro / nova proposta | discountPercentage | Desconto (%) | number | 0 | min 0 / max 100 / step 0,5 no HTML | Recalcula valor proposto; o handler não faz validação explícita de faixa. |
| Financeiro / nova proposta | discountedValue | Valor da Proposta | moeda calculada, somente leitura | Original com desconto 0% | original × (1 − desconto/100) | Salvo em texto monetário formatado. |
| Financeiro / nova proposta | installments | Parcelas | number inteiro | 1 | min 1 no HTML | parseInt ou 1; sem lista fixa ou máximo. |
| Financeiro / nova proposta | installmentValue | Valor da Parcela | moeda calculada, somente leitura | Valor da proposta / 1 | (proposta − entrada) / parcelas | Não há rateio de resíduos ou calendário de vencimentos no formulário. |
| Financeiro / nova proposta | entryValue | Entrada (opcional) | texto monetário | Vazio; cálculo usa zero | R$ 0,00 (placeholder) | Digitação da esquerda para a direita; até duas casas; não há guarda explícita contra entrada superior à proposta. |
| Financeiro / nova proposta | notes | Observações | textarea | Vazio | Notas sobre a proposta... (placeholder) | Não é exibida na grade de propostas. |
| Financeiro / nova proposta | status | Status inicial | automático | ENVIADA | status_proposta: sete valores no contrato | O formulário não envia mensagem; status não é comprovação de envio externo. |
| Financeiro / nova proposta | collaboratorId / collaboratorName | Autor da proposta | automático | Colaborador logado; na falta, negociador do registro | collaborators | Referência e nome descritivo. |
| Financeiro / nova proposta | responseDate | Data da resposta | opcional | Ausente | PUT da proposta | Grade mostra data ou —; não existe acionador visível de mudança de status. |
| Financeiro / nova proposta | id / record_id | Identificadores | automático | Gerado no servidor / ID da URL | negotiation_proposals | Uma negociação para muitas propostas. |
| Financeiro / metas | month / year | Competência | texto | perfMonth / perfYear | Filtros de Performance | Consulta Meta do Mês Atual usa mês civil atual, não necessariamente os filtros. |
| Financeiro / metas | collaboratorId | Responsável pela meta | automático | Colaborador logado; na falta, negociador do registro | collaborators | Não há seletor próprio na aba Metas da ficha. |
| Financeiro / metas | targetValue | Meta de Valor (R$) | texto monetário | Dívida da ficha ao clicar Metas | R$ 100.000,00 é apenas placeholder | Clicar Metas preenche pela dívida, não pela meta já salva. |
| Financeiro / metas | targetCount | Meta de Acordos (R$) | texto monetário | Original − proposta da última proposta, se existir | R$ 0,00 é placeholder | Apesar do nome técnico Count, tela usa moeda; sem proposta o valor anterior não é explicitamente limpo. |
| Financeiro / metas | achievedValue | Atingido Valor | texto monetário no retorno | 0 no POST quando omitido | negotiation_goals | Não é recalculado pelos acordos nas rotinas de negociação examinadas. |
| Financeiro / metas | achievedCount | Atingido Acordos | texto no banco, moeda na tela | 0 no POST quando omitido | negotiation_goals | POST de atualização sem atingidos envia defaults 0 ao upsert. |
| Financeiro / metas | id | Identificador da meta | texto | Gerado se omitido | Banco; unicidade mês + ano + colaborador | POST cria ou atualiza a mesma competência; sem exclusão na UI/API deste módulo. |
| WhatsApp / consulta integrada | filterDateFrom | Data Inicial | date | Vazio | sent_at | Filtro inclusivo local; mensagem sem sent_at não é eliminada apenas pela data. |
| WhatsApp / consulta integrada | filterDateTo | Data Final | date | Vazio | sent_at | Filtro inclusivo local. |
| WhatsApp / consulta integrada | filterOperator | Atendente | select ou texto | Todos os atendentes / vazio | Nomes únicos das mensagens em ordem alfabética | Se não há nomes, mostra texto livre; comparação por conteúdo sem distinguir caixa. |
| WhatsApp / consulta integrada | contact | Contato vinculado | somente leitura | Carregado por clientId | Nome / telefone / inicial do avatar | Sem vínculo mostra orientação para cadastrar em outra tela. |
| WhatsApp / consulta integrada | messages | Mensagens | lista de consulta | Até 500 na requisição | GoTalk, endpoints de consulta | Direção IN/OUT, corpo, mídia, horário, atendente, setor/área, status e templates; sem campo de envio. |
| Admissão / documentos privados | filter / search | Filtrar documentos | texto | Vazio | Busca por API no contexto da admissão | Aplica trim após 300 ms; volta à primeira página; placeholder Filtrar.... |
| Admissão / documentos privados | page / cursor | Página dos anexos | paginação | 1 / sem cursor | 25 anexos por página | Anterior/Próxima; mantém cursores por página; não é a paginação dos títulos. |
| Admissão / documentos privados | originalFilename / category / module / fileSize | Metadados do anexo | consulta | Dados da API; Sem categoria se ausente | Anexos com clientId, módulo ADMISSION e targetId da admissão | Nome, categoria, módulo, tamanho em KB/MB e tipo PDF/DOC; não editáveis neste caminho. |

### 8.1 Domínios de opções

#### etapas_comercial

| Valor técnico | Conteúdo exibido / significado |
| --- | --- |
| TRIAGEM | Triagem / Análise |
| PROPOSTA | Proposta Enviada |
| AGUARDANDO_BANCO | Aguardando Banco |
| FECHADO | Acordo Fechado |
| PERDIDO | Aceito pela API e pelo tipo, mas sem coluna ou opção no formulário atual |

#### status_negociacao

| Valor técnico | Conteúdo exibido / significado |
| --- | --- |
| ABERTA | Aberta |
| EM_ANDAMENTO | Em Andamento |
| ACORDO_FECHADO | Acordo Fechado |
| ACORDO_QUEBRADO | Acordo Quebrado |
| CANCELADA | Cancelada |
| ENCERRADA | Encerrada |

#### status_proposta

| Valor técnico | Conteúdo exibido / significado |
| --- | --- |
| ENVIADA | Enviada |
| EM_ANALISE | Em Análise |
| ACEITA | Aceita |
| RECUSADA | Recusada |
| CONTRA_PROPOSTA | Contra-Proposta |
| EXPIRADA | Expirada |
| CANCELADA | Cancelada |

#### canais_contato

| Valor técnico | Conteúdo exibido / significado |
| --- | --- |
| TELEFONE | Telefone |
| WHATSAPP | WhatsApp |
| EMAIL | E-mail |
| SMS | SMS |
| PRESENCIAL | Presencial |
| CARTA | Carta |

#### respostas_contato

| Valor técnico | Conteúdo exibido / significado |
| --- | --- |
| ATENDEU | Atendeu |
| NAO_ATENDEU | Não Atendeu |
| RECADO | Recado |
| CAIXA_POSTAL | Caixa Postal |
| RECUSOU | Recusou |
| INTERESSADO | Interessado |
| SEM_RESPOSTA | Sem Resposta |

#### status_titulo_exibidos

| Valor técnico | Conteúdo exibido / significado |
| --- | --- |
| ABERTO | Em Aberto |
| PAGO | Liquidado |
| PARCIAL | Parcial |
| CANCELADO | Cancelado |
| AGRUPADO | Fatura Gerada |
| ADIANTAMENTO | Adiantamento |
| ADIANTAMENTO_PARCIAL | Adiant. Parcial |
| DEVOLUCAO | Devolução |
| DEVOLUCAO_VINCULADA | Dev. Vinculada |
| DEVOLUCAO_PARCIAL | Dev. Parcial |
| PROTESTADO | Protestado |
| PROVISAO | Provisão |

#### admissoes_selecionaveis

APROVADA, FINALIZADA, CONCLUIDO, AUDITADA, NEGOCIAÇÃO.

#### meses_performance

01, 02, 03, 04, 05, 06, 07, 08, 09, 10, 11, 12.

#### anos_performance

2024, 2025, 2026.

### 8.2 Campos de edição existentes apenas em rotinas internas

Contato: editContactDate, editContactTime, editContactChannel, editContactResponse, editContactDescription, editContactNextDate e editContactNextDesc recebem os valores do contato ao chamar openEditContact. handleSaveEditContact envia data, hora, canal, resposta, descrição e próxima ação, e limpa editContact ao concluir. Porém openEditContact não é chamado por botão/linha do JSX e não há modal renderizado.

Proposta: editProposalDiscount=0, editProposalInstallments=1, editProposalEntry='', editProposalNotes='', editProposalStatus=ENVIADA e editProposal=null na montagem. handleSaveEditProposal recalcula com base na dívida atual, define responseDate se o status mudou e envia edição; nenhum formulário/modal da proposta usa esses controles no JSX atual. A existência de useState e handler não torna o fluxo disponível ao usuário.

### 8.3 Campos derivados e de consulta

Além dos controles listados, as grades e modais mostram os campos de cliente, admissão, banco, serviço, título, mensagens e auditoria detalhados nos capítulos 3–7. São consultas a cadastros existentes, não entradas adicionais no formulário de negociação. O arquivo `interfaces_dados.json` enumera integralmente as propriedades declaradas de NegotiationRecord, NegotiationContact, NegotiationProposal e NegotiationGoal, com tipo e opcionalidade.

## 9. Matriz de acionamento

| Área | Opção | Acionamento | Condição | Função / efeito | API |
| --- | --- | --- | --- | --- | --- |
| Comercial | Abrir módulo | Comercial > Negociação | Acesso pelo menu | Carrega até 500 cards da primeira página e calcula dois totais. | GET /api/commercial-deals?limit=500&page=1 |
| Comercial | Nova Negociação | Clique em + Nova Negociação | Admin ou com_negociacao:INCLUIR | Limpa formulário e abre modal. | Nenhum |
| Comercial | Selecionar cliente | Alterar select Cliente | Modal aberto | Preenche nome pelo ID; desmarcar permite nome livre. | Nenhum |
| Comercial | Selecionar banco | Alterar select Banco / Credor | Modal aberto | Preenche nome pelo ID; desmarcar permite credor livre. | Nenhum |
| Comercial | Editar | Ícone Editar no card | Admin ou com_negociacao:ALTERAR | Preenche o mesmo modal com valores atuais. | Nenhum |
| Comercial | Salvar inclusão | Salvar | Nome não vazio; botão bloqueado durante gravação | POST; adiciona card ao estado local; toast de sucesso; fecha modal. | POST /api/commercial-deals |
| Comercial | Salvar alteração | Salvar em edição | Nome não vazio | PUT; substitui card no estado; fecha modal. | PUT /api/commercial-deals/:id |
| Comercial | Cancelar formulário | Cancelar | Modal aberto | Fecha modal e limpa referência de edição, sem gravar. | Nenhum |
| Comercial | Avançar etapa | Seta Avançar do card ao passar ponteiro | canEdit validado no handler; não aparece na última coluna | Move uma coluna; otimista; desfaz em erro. | PATCH /api/commercial-deals/:id/stage |
| Comercial | Voltar etapa | Seta Voltar | canEdit validado no handler; não aparece na primeira coluna | Move uma coluna para trás; desfaz em erro. | PATCH /api/commercial-deals/:id/stage |
| Comercial | Excluir | Ícone Excluir + confirmação | Admin ou com_negociacao:EXCLUIR | DELETE; remove card; ação irreversível sem lixeira neste módulo. | DELETE /api/commercial-deals/:id |
| Financeiro | Abrir módulo | Financeiro > Negociação | Sessão e acesso ao menu | Busca negociações e metas; pai carrega página de títulos. | GET /api/negotiations; GET /api/negotiation-goals; GET /api/financial-titles |
| Financeiro | Voltar | Botão Voltar no cabeçalho | Callback do painel pai disponível | Navega para fin_cob_coordenador. | Nenhum |
| Financeiro | Expandir / Minimizar | Botão do cabeçalho | Sempre na tela principal | Alterna sobreposição CSS de tela cheia. | Nenhum |
| Financeiro | Trocar aba principal | Negociações / Dashboard Cliente / Performance | Sempre | Renderiza conteúdo selecionado; conserva estados. | Nenhum |
| Financeiro | Exibir / Ocultar Resumo e Filtros | Botão de alternância | Aba Negociações | Mostra quatro cards e cinco filtros; ocultar mantém filtros ativos. | Nenhum |
| Financeiro | Filtrar registros | Digitar nome ou escolher status, negociador ou datas | Resumo expandido | Filtra somente grade de negociações; cards não usam filteredRecords. | Nenhum |
| Financeiro | Ordenar registros | Cabeçalho ordenável | Grade principal | Alterna asc/desc; não ordena contrato, banco ou próxima data. | Nenhum |
| Financeiro | Nova Negociação | Clique no botão | Sem guarda INCLUIR explícita neste componente | Abre modal de criação; botão não redefine explicitamente os campos. | Nenhum |
| Financeiro | Escolher cliente | Select do modal | Modal de criação | Limpa admissão e recalcula contratos elegíveis. | Nenhum |
| Financeiro | Escolher contrato | Select Admissão / Contrato | Cliente selecionado; contrato elegível | Exibe banco, valor, parcelas, vencidas e taxas; prepara valor da dívida. | Nenhum |
| Financeiro | Criar Negociação | Clique no rodapé | Cliente e negociador; cliente não bloqueado | POST ABERTA; adiciona registro; registra auditoria; após a tentativa fecha e limpa formulário, mesmo em erro de rede. | POST /api/negotiations |
| Financeiro | Cancelar / Voltar do modal | Botão correspondente | Modal aberto | Fecha criação sem gravar; não há limpeza explícita nesses botões. | Nenhum |
| Financeiro | Abrir ficha | Clique na linha ou Abrir | Grade principal | Seleciona registro; abre ficha em Dados. | Nenhum |
| Financeiro | Histórico | Ícone de relógio | Grade principal | Busca histórico do ID e abre modal somente leitura. | GET /api/audit-logs?entity_id=:id&limit=500 |
| Financeiro | Excluir negociação | Excluir + confirmar | Admin/EXCLUIR para botão; validarPermissao no handler | DELETE registro e filhos em cascata; remove linha. | DELETE /api/negotiations/:id |
| Financeiro | Buscar títulos | Nome, CPF/CNPJ, telefone... | Aba Negociações | Busca local na página de títulos recebida. | Nenhum |
| Financeiro | Iniciar a partir de título | Duplo clique na linha do título | Título elegível | Abre criação com cliente do título, sem admissionId, negociador, notas, titleId ou saldo copiados. | Nenhum |
| Financeiro | Paginar títulos | Barra de paginação inferior | Componente pai | Carrega outra página do recurso financial-titles; não pagina registros de negociação. | GET /api/financial-titles |
| Ficha | Alterar status | Selecionar valor no cabeçalho | Status atual não fechado/cancelado/encerrado; cliente não bloqueado | PUT registro completo + novo status; CANCELADA/ENCERRADA recebem data de fechamento. | PUT /api/negotiations/:id |
| Ficha | Ficha de Admissão | Botão no cabeçalho ou em Dados | Admissão vinculada | Busca admissão completa; abre visualizador; 403 informa acesso negado; outros erros usam objeto local. | GET /api/admissions/:id |
| Ficha | Dados | Aba Dados | Ficha aberta | Mostra contrato, banco, taxas, dados do registro e fechamento, sem editor geral. | Nenhum |
| Ficha | Contatos | Aba Contatos (n) | Ficha aberta | Mostra histórico inverso e formulário se registro não terminal. | Nenhum |
| Ficha | Salvar Contato | Botão do formulário | Descrição presente; cliente não bloqueado; formulário visível | POST; ABERTA vira EM_ANDAMENTO; atualiza próxima ação; limpa descrição, hora e próxima ação após tentativa. | POST /api/negotiations/:id/contacts |
| Ficha | Excluir Contato | Excluir no item + confirmação | EXCLUIR | DELETE; recalcula próxima ação pelo contato mais recente com data de próxima ação. | DELETE /api/negotiations/:id/contacts/:cid |
| Ficha | Propostas | Aba Propostas (n) | Ficha aberta | Mostra banco/taxas, grade e formulário em situação não terminal. | Nenhum |
| Ficha | Calcular proposta | Alterar desconto, entrada ou parcelas | Nova proposta visível | Recalcula proposta e parcela em tempo real; sem requisição ou envio externo. | Nenhum |
| Ficha | Registrar Proposta | Botão do formulário | Cliente não bloqueado; registro não terminal | POST ENVIADA; ABERTA vira EM_ANDAMENTO; limpa formulário após tentativa. | POST /api/negotiations/:id/proposals |
| Ficha | Excluir Proposta | Excluir + confirmação | EXCLUIR | DELETE; não reabre nem recalcula fechamento do registro. | DELETE /api/negotiations/:id/proposals/:pid |
| Ficha | Editar contato | Sem acionador JSX | Não acionável pela tela atual | Rotina e API existentes, sem botão/modal renderizado na versão analisada. | PUT /api/negotiations/:id/contacts/:cid |
| Ficha | Editar / aceitar / recusar proposta | Sem acionador JSX | Não acionável pela tela atual | Handlers e API existentes; ACEITA fecha registro; não gera parcelas financeiras. | PUT /api/negotiations/:id/proposals/:pid |
| Ficha | Metas | Aba Metas | Ficha aberta | Consulta mês civil atual; preenche metas pela dívida e economia da última proposta. | Nenhum |
| Ficha | Salvar Meta | Botão da aba | Colaborador logado ou negociador do registro | POST com upsert por colaborador/competência dos filtros Performance. | POST /api/negotiation-goals |
| Ficha | Ficha do Cliente | Botão da barra | Ficha aberta | Abre sobreposição somente leitura em Cadastro, com abas Títulos e Admissões. | Nenhum |
| Ficha | WhatsApp | Aba condicional | Integração habilitada e componente fornecido | Monta consulta de mensagens pelo clientId, sem envio. | Nenhum |
| Dashboard Cliente | Selecionar cliente | Select do cliente | Cliente selecionado | Calcula quatro indicadores, timeline, propostas e cartões de admissões. | Nenhum |
| Performance | Selecionar mês / ano | Filtros | Meses 01–12; anos 2024–2026 | Recalcula indicadores, ranking e barras por data de abertura. | Nenhum |
| Cliente | Cadastro / Títulos / Admissões | Abas da sobreposição | Ficha do cliente aberta | Troca consulta sem permitir alteração de cadastro ou baixa. | Nenhum |
| Cliente | Ver Ficha | Botão no cartão de admissão | Admissão presente | Abre visualizador compartilhado com busca por ID. | GET /api/admissions/:id |
| Admissão | Identificação / Contrato / Documentos / Auditoria | Abas do visualizador | Modal de admissão aberto | Alterna consulta; documentos e consulta jurídica são buscados sob demanda. | Nenhum |
| Admissão | Ver documento legado | Ver / miniatura | Conteúdo de anexo disponível; navegador permite janela | Abre nova janela com iframe do conteúdo carregado. | Nenhum |
| Admissão | Baixar documento | Baixar | Permissão de leitura de anexo | Anexo legado por data URI; bucket por rota autenticada. | GET /api/client-attachments/:id/download?browser=1 |
| Admissão | Filtrar / atualizar documentos privados | Filtrar... ou Atualizar | Aba Documentos | Busca por contexto; 300 ms após digitação; Atualizar refaz página corrente. | GET /api/client-attachments/ |
| Admissão | Ver documento privado | Ver | Imagem ou PDF; leitura autorizada | Abre conteúdo em nova aba, sem copiar arquivo inteiro para Blob na aplicação. | GET /api/client-attachments/:id/content?browser=1 |
| Admissão | Paginar documentos privados | Anterior / Próxima | Existe página anterior ou próximo cursor | Navega páginas de 25 anexos; controles bloqueados durante leitura. | GET /api/client-attachments/ |
| WhatsApp | Atualizar | Botão Atualizar | Cliente com vínculo | Refaz as duas consultas; botão desabilitado durante atualização. | GET /api/gotalk/client/:id; GET /api/gotalk/messages/:id?limit=500 |
| WhatsApp | Filtrar / Limpar Filtros | Datas, atendente e botão de limpar | Histórico disponível | Filtra mensagens carregadas; contador mostra filtradas/total; rola ao final. | Nenhum |
| Confirmação | Confirmar exclusão | Excluir | Modal de exclusão aberto | Executa callback; mostra progresso; bloqueia botões e cancelamento durante execução. | Nenhum |
| Confirmação | Cancelar exclusão | Cancelar, Escape ou clique fora | Não está carregando | Fecha sem excluir; cancelamento ignorado enquanto grava. | Nenhum |

## 10. CRUD real por entidade

| Entidade | Criar | Consultar | Alterar | Excluir |
| --- | --- | --- | --- | --- |
| Card Comercial | Modal + POST | Kanban + GET | Modal, setas e PUT/PATCH | Confirmação + DELETE |
| Negociação Financeira | Modal + POST | Grade, ficha e GET | Status no cabeçalho; API aceita outros campos, sem editor geral na ficha | Confirmação + DELETE |
| Contato Financeiro | Formulário embutido + POST | Histórico e GET do registro | PUT e handler existentes; sem botão/modal visual | Confirmação + DELETE |
| Proposta Financeira | Formulário embutido + POST | Grade e GET do registro | PUT/handlers existentes; sem editar/aceitar/recusar visual | Confirmação + DELETE |
| Meta | Formulário + POST upsert | Aba Metas e Performance | Mesmo formulário + POST; PUT adicional na API | Não exposto nem implementado no roteador de metas |
| Título a receber | Não nessa tela | Grade e ficha do cliente | Não nessa tela | Não nessa tela |
| Cliente | Não nessa tela | Ficha somente leitura | Não nessa tela | Não nessa tela |
| Admissão | Não nessa tela | Resumo e visualizador | Não nessa tela | Não nessa tela |
| Documento de admissão | Não pelo visualizador | Consultar/baixar com permissão | Não pelo visualizador | Não pelo visualizador |
| Mensagem WhatsApp | Não nessa aba | Histórico com filtros | Não nessa aba | Não nessa aba |
| Histórico de auditoria | Gerado pelas mutações | Modal somente leitura | Não | Não |

CRUD não significa que todos os objetos auxiliares sejam editáveis dentro de Negociação. Onde há lacuna entre API e tela, ela foi explicitada.

## 11. APIs, persistência e relacionamentos

### 11.1 Contratos de endpoints

Os prefixos são montados no servidor. Respostas listadas são as de sucesso; validação pode retornar 400/404/409 conforme rotina, referências inválidas seguem referenceWriteStatus, autenticação pode retornar 401/403 e falhas internas são tratadas pela camada global. Esta tabela não promete uniformidade dos formatos de erro entre rotas.

| Método | Endpoint | Entrada | Saída | Observações |
| --- | --- | --- | --- | --- |
| GET | /api/commercial-deals | Query limit/page (máximo 500), stage, client_id, search | {data, total} | UI usa primeira página, 500; search pesquisa cliente, banco e observações na API. |
| GET | /api/commercial-deals/:id | ID UUID | {data} | Disponível; edição do card usa objeto já carregado. |
| POST | /api/commercial-deals | client_name obrigatório; client_id, bank_id, bank_name, collaborator_id/name, unit_id, debt_value, proposal_value, stage, notes | 201 {data} | Valida referências e etapa; nome com trim; dinheiro numérico. |
| PUT | /api/commercial-deals/:id | Mesmos campos, conforme edição | {data} | Mantém IDs omitidos; atualiza updated_at; notes omitida vira null. |
| PATCH | /api/commercial-deals/:id/stage | {stage} | {data} | Cinco etapas válidas; usada pelas setas. |
| PATCH | /api/commercial-deals/:id/move-stage | {stage} | {data} | Alias da mesma rotina. |
| DELETE | /api/commercial-deals/:id | ID UUID | {data:{id,deleted:true}} | Exclusão física; 404 se inexistente. |
| GET | /api/negotiations | Query collaboratorId, status, clientId | Array de registros completos | Sem paginação nesta rota; exclui registros vinculados a título CANCELADO. |
| GET | /api/negotiations/:id | ID textual | Registro com contacts e proposals | 404 se ausente; busca por ID não repete o filtro de título cancelado. |
| POST | /api/negotiations | clientName e collaboratorId obrigatórios; demais campos do registro | 201 registro completo | Valida IDs e titularidade de admissão/título em relação ao cliente; transação e auditoria. |
| PUT | /api/negotiations/:id | Campos do registro; UI de status envia registro completo | Registro completo | Bloqueio FOR UPDATE; IDs omitidos preservados; vários opcionais omitidos são limpos. |
| DELETE | /api/negotiations/:id | ID textual | {success:true} | Transação e auditoria; contatos/propostas dependentes em cascata. |
| POST | /api/negotiations/:id/contacts | description obrigatório; date, time, channel, response, próxima ação e autor | 201 registro completo | Default TELEFONE/ATENDEU; ABERTA -> EM_ANDAMENTO. |
| PUT | /api/negotiations/:id/contacts/:cid | date, time, channel, response, description, próxima ação | Registro completo | API disponível, sem editor renderizado; recalcula próxima ação. |
| DELETE | /api/negotiations/:id/contacts/:cid | IDs de registro e contato | Registro completo | Recalcula próxima ação pelo último contato com next_action_date. |
| POST | /api/negotiations/:id/proposals | Campos financeiros, data, status, notas, autor, resposta | 201 registro completo | Default ENVIADA, desconto 0, parcelas 1; não envia ao cliente. |
| PUT | /api/negotiations/:id/proposals/:pid | Desconto, valor, parcelas, parcela, entrada, status, notas, data resposta | Registro completo | ACEITA fecha registro, com dados fornecidos no payload; sem gerar títulos. |
| DELETE | /api/negotiations/:id/proposals/:pid | IDs do registro e proposta | Registro completo | Não recalcula fechamento. |
| GET | /api/negotiation-goals | Query collaboratorId, month, year | Array de metas | Ordena ano/mês descendente. |
| POST | /api/negotiation-goals | collaboratorId, month, year obrigatórios; metas e atingidos | Meta | Upsert; atingidos omitidos recebem 0, inclusive em conflito. |
| PUT | /api/negotiation-goals/:id | targetValue, targetCount, achievedValue, achievedCount | Meta | Disponível na API; interface usa POST; não existe DELETE nessa rota. |
| GET | /api/financial-titles | Paginação, filter_title_scope=RECEBER no pai | {data e paginação} | Fonte dos títulos; pageSize 50. |
| GET | /api/admissions/:id | ID UUID | {data} | Busca para visualizador; 403 bloqueia abertura. |
| GET | /api/admissions/:id/attachments | ID de admissão | {data} | Anexos legados sob demanda. |
| GET | /api/admissions/:id/legal-scan | ID de admissão | {data} | Consulta jurídica histórica; não executa nova consulta externa. |
| GET | /api/audit-logs | entity_id e limit=500 | {data} | Grade somente leitura; paginação local em 15 linhas. |
| GET | /api/gotalk/client/:clientId | ID do cliente | {linked, contact} | Vínculo do contato WhatsApp. |
| GET | /api/gotalk/messages/:clientId | limit=500 | {data} | Histórico; sem envio nesta aba. |
| GET | /api/client-attachments/ | clientId, module=ADMISSION, targetType=ADMISSION, targetId, search, limit=25, cursor | data + total/pagination/nextCursor | Listagem contextual de documentos privados; filtro após 300 ms. |
| GET | /api/client-attachments/:id/content | browser=1 | Conteúdo do arquivo | Ver imagem/PDF em nova aba; sujeito a autorização. |
| GET | /api/client-attachments/:id/download | browser=1 | Arquivo / resposta de acesso | Download autenticado, sujeito a ACL; não é URL pública permanente. |

### 11.2 Relacionamentos

| Origem | Campo | Destino | Cardinalidade | Efeito / observação |
| --- | --- | --- | --- | --- |
| commercial_deals | client_id | clients.id | N:1 opcional | Nome livre permitido sem vínculo; nome não substitui ID. |
| commercial_deals | bank_id | banks.id | N:1 opcional | Credor livre permitido; seletor usa cadastro. |
| commercial_deals | collaborator_id | collaborators.id | N:1 opcional | API suporta; formulário não expõe. |
| commercial_deals | unit_id | companies.id | N:1 opcional | API suporta; formulário não expõe. |
| negotiation_records | client_id | clients.id | N:1 | Cliente obrigatório na UI; nome é cópia descritiva; exclusão SET NULL no schema base. |
| negotiation_records | admission_id | admissions.id | N:1 opcional | Pertencimento ao cliente validado; seleção filtra status; SET NULL no schema base. |
| negotiation_records | bank_id | banks.id | N:1 opcional | Derivado do contrato no modal; migração de identidade protege referência. |
| negotiation_records | collaborator_id | collaborators.id | N:1 | Negociador; autoria dos contatos/propostas pode ser outro colaborador. |
| negotiation_records | title_id | financial_titles.id | N:1 opcional | Modelo suporta; modal atual não associa; cancelamento do título afeta negociação. |
| negotiation_contacts | record_id | negotiation_records.id | N:1 obrigatório | DELETE CASCADE ao excluir negociação. |
| negotiation_contacts | collaborator_id | collaborators.id | N:1 opcional | Autor do contato; guardas de identidade nas migrações. |
| negotiation_proposals | record_id | negotiation_records.id | N:1 obrigatório | DELETE CASCADE ao excluir negociação. |
| negotiation_proposals | collaborator_id | collaborators.id | N:1 opcional | Autor da proposta; aceitação atualiza registro pai. |
| negotiation_goals | collaborator_id | collaborators.id | N:1 | Unicidade colaborador + mês + ano; independente de uma negociação específica. |
| banks | services[] | Serviços / negotiationPercentage | 1:N no objeto do banco | Taxas exibidas; não impostas pelo cálculo de desconto. |
| Ficha financeira | clientId | GoTalk / contato vinculado | Integração de consulta | Exibe mensagens por cliente, não por negociação. |
| Visualizador de admissão | clientId + ADMISSION + targetId | Anexos privados e ACL | Consulta somente leitura | Não abre upload, exclusão ou manutenção de ACL por esse caminho. |
| Mutações financeiras | entityId + snapshots | audit_logs | 1:N histórico | Auditoria transacional obrigatória nas rotas financeiras examinadas. |

### 11.3 Defaults e integridade no schema versionado

commercial_deals usa UUID gerado pelo banco, dinheiro NUMERIC(15,2), etapa TRIAGEM, dívida/proposta 0 e timestamps NOW(). negotiation_records usa ID textual, data textual YYYY-MM-DD obrigatória, nome default vazio, status ABERTA, dívida como VARCHAR(30) default vazio e timestamps. Contatos usam canal TELEFONE, resposta ATENDEU e hora vazia; propostas usam ENVIADA e parcelas 1. Metas têm atingidos '0' e unicidade mês/ano/colaborador.

Contatos/propostas pertencem ao registro por record_id com ON DELETE CASCADE. O schema base de cliente/admissão/título usa ON DELETE SET NULL. Migrações de identidade acrescentam validações e FKs auxiliares para banco e colaboradores, com restrição de exclusão; não inferir a política final só do schema base. O código valida referências dos registros e pertencimento de admissão/título ao cliente antes de gravar. Não foram auditadas permissões ou integridade do catálogo de produção para esta entrega.

A tabela histórica `negotiations` e referências dela em código de IA/schema antigo não foram confundidas com `negotiation_records`, que é a fonte do painel Financeiro atual. Não se presume integração de IA por simples semelhança de nomes.

### 11.4 Segurança e recortes de acesso observados

Todas as APIs privadas passam pela camada global de sessão, e os três roteadores principais são montados com extractUser. Comercial verifica INCLUIR, ALTERAR e EXCLUIR no componente, ou administrador. Financeiro condiciona botões de excluir a administrador/permissão e chama validarPermissao para exclusões; não há guardas equivalentes INCLUIR/ALTERAR explícitas em todos os handlers desse componente. Os roteadores de negociação examinados não contêm verificações locais equivalentes por ação; isso não deve ser apresentado como certificação completa de autorização.

F02 recebe listas de cadastros do pai; não implementa filtro próprio por unidade no painel. GET de negociações e GET de cards, nas rotas examinadas, também não adicionam condição unit_id. A disponibilidade real de dados depende do contexto e da infraestrutura de acesso; não afirmar isolamento multiunidade apenas porque unitId existe no contrato Comercial.

O bloqueio de cliente é verificado na criação financeira, novo contato, nova proposta e alteração de status; não está uniformemente presente nas exclusões ou nos handlers de edição internos. A documentação descreve essas verificações, não modifica nem testa segurança de produção.

## 12. Pontos de atenção e recursos não acionáveis

1. **Duas funcionalidades homônimas:** Kanban Comercial não é a negociação de dívida Financeira; sem sincronização automática encontrada.
2. **Não existe data grid Comercial:** há Kanban com CRUD de card. Grades Financeiras têm comportamentos diferentes por entidade.
3. **Contatos e propostas não têm CRUD visual completo:** rotinas de edição existem, mas faltam botões e modais renderizados. Não foram inventados modais inexistentes.
4. **Aceitar proposta não é acionável na grade atual:** API aceita ACEITA; não há botão correspondente. Alterar status da negociação para Fechado manualmente não substitui aceite completo.
5. **Aceite não gera títulos/parcelas nesse endpoint:** a ajuda descritiva menciona geração de títulos, mas o caminho atual examinado só atualiza proposta/registro. O código foi priorizado sobre esse texto de ajuda.
6. **Recuperado não equivale a pago:** os dashboards somam acordos fechados; não consultam baixas para esse indicador.
7. **Duplo clique no título não cria vínculo com título:** apenas pré-seleciona cliente. Sem titleId, efeitos de cancelamento do título não atingem esse registro por essa relação.
8. **Escopo de títulos é paginado:** buscas, contadores e totais locais não representam necessariamente todos os títulos da carteira.
9. **Cards Comerciais limitados a 500:** não há paginação visível; PERDIDO não tem coluna, mas pode entrar em totais.
10. **Taxas máximas são informativas:** sem validação implementada do teto de desconto por serviço/banco.
11. **Metas têm divergência de competência:** consulta mês civil atual, grava período escolhido em Performance.
12. **Meta de Acordos usa moeda e economia:** o rótulo atual é R$, apesar de campos Count; não tratar como quantidade inteira.
13. **Atingidos de meta podem zerar no upsert:** valores omitidos recebem '0'; não há cálculo automático dos atingidos no roteador analisado.
14. **Não há validação explícita completa dos cálculos:** limites HTML não barram todos os casos no handler; entrada maior que proposta pode gerar parcela negativa.
15. **Estados e falhas:** criação financeira e registro de contato/proposta limpam campos após tentativa de rede, inclusive falha; cancelar criação não limpa os campos por si só.
16. **Status terminais ocultam controles:** fechado, cancelado e encerrado não têm reabertura visual; acordo quebrado permanece operável.
17. **Limite do visualizador compartilhado:** dados opcionais completos de cliente/titular/banco não são repassados por Negociação; não prometer blocos ausentes.
18. **Sem envio pela aba WhatsApp:** é histórico de consulta; canais do contato são classificações.
19. **Sem exportação nativa de negociação localizada:** o ZIP é documentação produzida para esta solicitação, não nova funcionalidade incorporada ao sistema.
20. **Datas e exercício:** criação usa dia UTC, performance usa Date local e anos fixos; não foi simulada mudança de fuso/ano.

Essas observações são constatações de leitura do código, não autorização para correções. Nenhum comportamento foi alterado.

## 13. Roteiro de conferência funcional por opção

Roteiro para futura homologação com dados fictícios e permissões apropriadas; **não executado nesta documentação**:

1. Abrir Comercial e conferir quatro colunas, totais e estado vazio; criar card com cliente/credor livre e outro por ID.
2. Editar valores e etapa; usar setas, verificar recusa sem ALTERAR e reversão visual se PATCH falhar.
3. Cancelar e confirmar exclusão com registro descartável; conferir ausência de lixeira.
4. Abrir Financeiro, expandir resumo, aplicar os cinco filtros e ordenar cada cabeçalho habilitado.
5. Paginar títulos; confirmar que busca/soma usam página; testar duplo clique e conferir que só cliente é copiado.
6. Criar negociação com/sem contrato, obrigatórios e cliente bloqueado; conferir defaults ABERTA/dívida.
7. Abrir ficha, conferir consulta, estados terminais e campos de fechamento ao mudar status manualmente.
8. Registrar contato em cada canal/resposta sem supor envio; testar lembrete e exclusão recalculando a próxima ação.
9. Registrar proposta com desconto, entrada e parcelas; conferir fórmulas e ausência de botões Editar/Aceitar.
10. Em ambiente controlado, chamar PUT de aceite com payload completo e comprovar fechamento sem títulos gerados por esse endpoint.
11. Definir meta em competência atual e distinta, observar formato monetário e efeito de upsert sobre atingidos.
12. Consultar Ficha do Cliente, admissões, documentos autorizados e histórico; validar recusa de leitura conforme perfil.
13. Consultar WhatsApp com/sem vínculo, atualizar, filtrar e verificar ausência de compositor de envio.
14. Conferir Dashboard Cliente/Performance com contas manuais baseadas em data de abertura e acordos fechados.

## 14. Evidências e rastreabilidade

Cada fonte abaixo foi localizada no projeto. Linhas servem de referência do snapshot, não de garantia para versões futuras. `fontes.json` registra SHA-256 e número de linhas dos arquivos para permitir identificar a versão sem incluir segredos ou conteúdo de banco. `cobertura.json` resume a quantidade de itens tabulares e as verificações automáticas do pacote.

| ID | Arquivo | Linhas / assunto |
| --- | --- | --- |
| F01 | components/comercial/NegotiationPanel.tsx | 20–57: Modelo, etapas e defaults; 58–198: Permissões, carga, CRUD e movimento; 200–447: Kanban e modais |
| F02 | components/financeiro/NegotiationPanel.tsx | 15–122: Props e domínios; 125–255: Estados e defaults; 273–417: Filtros, cálculos, criação e ficha; 420–681: Handlers e metas; 683–766: Dashboard e performance; 774–1017: Cabeçalho, filtros e grades; 1019–1340: Dashboard Cliente e Performance; 1342–1855: Modal criação, ficha e abas; 1857–2049: Ficha cliente e visualizadores |
| F03 | components/financeiro/CollectionPanel.tsx | 24–45: Dados, paginação e integração; 95–116: Composição da Negociação Financeira |
| F04 | server/routes/negotiations.js | 1–145: Referências, mapeamento e transações; 147–306: CRUD registros; 310–427: Contatos; 431–520: Propostas; 524–602: Metas |
| F05 | server/routes/commercialDeals.js | 1–40: Referências, etapas e mapeamento; 41–202: Rotas e persistência Comercial |
| F06 | components/ui/AdmissionViewerModal.tsx | 8–118: Props, anexos e consulta histórica; 120–343: Identificação; 345–504: Contrato financeiro; 506–683: Documentos, auditoria e fechamento |
| F07 | components/ui/AuditLogButton.tsx | 1–145: Props, busca e paginação; 146–270: Modal, grade e navegação |
| F08 | components/ui/ConfirmDeleteModal.tsx | 1–82: Confirmação compartilhada |
| F09 | components/gotalk/GotalkConversationsTab.tsx | 1–331: Vínculo, histórico, filtros e mensagens |
| F10 | migrations/051_startup_schema.sql | 124–168: Tabelas Financeiras; 185–205: Tabela Comercial |
| F11 | migrations/084_internal_reference_guards.sql | 1–135: Guardas de identidade e referências |
| F12 | server/routes/financialTitles.js | 365–390: Cancelamento em lote; 495–516: Cancelamento individual |
| F13 | components/attachments/ClientAttachmentsPanel.tsx | 1–145: Contrato, busca e leitura; 350–465: Download e readOnly |
| F14 | types.ts | 619–685: Tipos e interfaces centrais |
| F15 | components/layout/DashboardLayout.tsx | 340–365: Roteamento Financeiro; 405–415: Roteamento Comercial |
| F16 | components/dashboard/DashboardHome.tsx | 1–32: Início geral sem métricas de negociação |
| F17 | server/middleware/security.js | 215–305: Autenticação global de APIs |
| F18 | components/atendimento/HistoricalLegalScan.tsx | 1–40: Campos da consulta jurídica histórica sem nova consulta |

Snapshot documental gerado em UTC: 2026-11-15T14:25:06.714928+00:00. Este inventário não substitui testes autenticados nem auditoria de produção.

Exportação de código-fonte relacionado ao GoTalk

Gerado em: 2026-11-13T14:34:19.914Z
Arquivos incluídos: 163

O manifesto manifest.json lista caminhos originais, tamanho e SHA-256.
As cópias idênticas permanecem no pacote e são indicadas no manifesto.
Secrets, arquivos .env, dados de clientes, uploads, binários, dependências
instaladas e builds não fazem parte desta exportação.

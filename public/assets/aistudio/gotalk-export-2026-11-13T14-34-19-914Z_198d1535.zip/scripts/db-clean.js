#!/usr/bin/env node
/**
 * db-clean.js — Limpeza de dados transacionais do banco de dados (DEV ou PRO)
 *
 * A deleção respeita todos os relacionamentos FK um a um, sem CASCADE forçado.
 * As tabelas são apagadas na ordem correta: filhos antes dos pais.
 *
 * SEMPRE PRESERVADO (nunca apagado em nenhum modo):
 *   • Todas as tabelas gotalk_*  (canais, contatos, mensagens, atendimentos, etc.)
 *   • Tabelas de Configurações: usuários, grupos, empresas, colaboradores,
 *     bancos, modalidades, séries, departamentos, tipos de documento,
 *     plano de contas, templates de relatório/formulário/WhatsApp, etc.
 *
 * MODOS:
 *   --mode transactional  (padrão) Apaga dados de negócio: clientes, admissões,
 *                         títulos financeiros, processos jurídicos, negociações,
 *                         cobranças, mensagens internas, agenda, audit_logs.
 *   --mode full           Idem + apaga tabelas de estado do sistema:
 *                         app_data, agenda_config, config_options,
 *                         retention_config, migrations_log.
 *
 * BANCO:
 *   --url <conn_string>   Usa a string de conexão fornecida (considera PRODUÇÃO).
 *   (sem --url)           Usa DATABASE_URL do ambiente (dev local).
 *
 * CONFIRMAÇÃO:
 *   O script sempre exige digitação manual da palavra de confirmação.
 *   Produção exige também --backup-evidence apontando para uma evidência
 *   verificável de backup/restauração.
 *   Não existe flag para pular essa etapa — intencional.
 *
 * FLAGS ADICIONAIS:
 *   --dry-run             Mostra o plano sem apagar nada (não conecta ao banco).
 *
 * EXEMPLOS:
 *   node scripts/db-clean.js --dry-run
 *   node scripts/db-clean.js
 *   node scripts/db-clean.js --mode full
 *   node scripts/db-clean.js --url "postgres://..." --mode full --dry-run
 */

import pg from 'pg';
import readline from 'readline';

// ── Argumentos ─────────────────────────────────────────────────────────────

const args = process.argv.slice(2);
const modeIdx = args.indexOf('--mode');
const MODE = modeIdx !== -1 ? args[modeIdx + 1] : 'transactional';
const urlIdx = args.indexOf('--url');
const CUSTOM_URL = urlIdx !== -1 ? args[urlIdx + 1] : null;
const CONNECTION_STRING = CUSTOM_URL || process.env.DATABASE_URL;
const DRY_RUN = args.includes('--dry-run');
const environmentIdx = args.indexOf('--environment');
const ENVIRONMENT = environmentIdx !== -1 ? args[environmentIdx + 1] : null;
const evidenceIdx = args.indexOf('--backup-evidence');
const BACKUP_EVIDENCE = evidenceIdx !== -1 ? args[evidenceIdx + 1] : null;

if (!['transactional', 'full'].includes(MODE)) {
  console.error(`❌  Modo inválido: "${MODE}". Use --mode transactional ou --mode full.`);
  process.exit(1);
}
if (!DRY_RUN && !CONNECTION_STRING) {
  console.error('❌  Nenhuma connection string disponível. Defina DATABASE_URL ou use --url.');
  process.exit(1);
}

// Identifica o banco a partir da connection string (host + nome do banco)
function describeDb(url) {
  try {
    const u = new URL(url);
    return `${u.hostname}${u.pathname}`;
  } catch {
    return url.replace(/:[^:@]*@/, ':***@').slice(0, 60);
  }
}

const DB_LABEL = CONNECTION_STRING ? describeDb(CONNECTION_STRING) : '(dry-run — nenhuma conexão)';
const IS_PROD = ENVIRONMENT === 'production' || CUSTOM_URL !== null;
if (!DRY_RUN && !['development', 'production'].includes(ENVIRONMENT)) {
  console.error('❌  --environment deve ser development ou production.');
  process.exit(1);
}

// ── Ordem de deleção ───────────────────────────────────────────────────────
//
// Lógica: filhos (FK child) antes dos pais (FK parent).
// Mesmo quando a FK é ON DELETE SET NULL, listamos explicitamente para
// garantir transparência e auditabilidade.
//
// Self-referências (chart_of_accounts.parent_id, financial_titles.parent_id)
// usam SET NULL — uma única DELETE é suficiente.
//
// NUNCA APAGADO (em nenhum modo):
//   • Qualquer tabela gotalk_*
//   • Tabelas de Configurações:
//       users, user_groups, user_group_members, user_group_permissions,
//       user_allowed_units, companies, collaborators, series_unit_numbering,
//       banks, bank_accounts, bank_services, bearers, series, modalities,
//       departments, document_types, chart_of_accounts, measurement_units,
//       service_items, products, report_templates, form_templates,
//       whatsapp_templates

// Dados de negócio apagados no modo "transactional" (padrão)
const TRANSACTIONAL_TABLES = [
  // ── Auditoria e jobs ────────────────────────────────────────────────────
  'audit_logs',
  'background_jobs',

  // ── Mensagens internas (CRM) ────────────────────────────────────────────
  'message_deliveries',
  'message_reads',
  'messages',

  // ── Financeiro: links e derivados antes dos títulos ─────────────────────
  'title_advance_links',
  'title_return_links',
  'title_settlements',
  'bank_movements',
  'collection_notes',
  'negotiation_goals',
  'negotiation_contacts',
  'negotiation_proposals',
  'negotiation_records',
  'financial_titles',

  // ── Jurídico ────────────────────────────────────────────────────────────
  'legal_process_attachments',
  'legal_process_deadlines',
  'legal_process_hearings',
  'legal_process_movements',
  'legal_processes',

  // ── Admissões ───────────────────────────────────────────────────────────
  'admission_attachments',
  'admission_legal_scans',
  'recalc_scenarios',
  'admissions',

  // ── Agenda e lista de espera ─────────────────────────────────────────────
  'schedule_blocks',
  'appointments',
  'waitlist',

  // ── Clientes ────────────────────────────────────────────────────────────
  'clients',
];

// Estado de sistema apagado APENAS no modo "full"
// (não inclui configurações feitas pelo usuário via painel)
const FULL_ONLY_TABLES = [
  'app_data',
  'agenda_config',
  'config_options',
  'retention_config',
  'migrations_log',
];

// ── Utilidades ─────────────────────────────────────────────────────────────

function prompt(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  return new Promise(resolve => rl.question(question, answer => { rl.close(); resolve(answer); }));
}

function hr(char = '─', width = 60) {
  return char.repeat(width);
}

function pad(str, len) {
  return String(str).padEnd(len);
}

// ── Principal ──────────────────────────────────────────────────────────────

async function main() {
  const tables =
    MODE === 'full'
      ? [...TRANSACTIONAL_TABLES, ...FULL_ONLY_TABLES]
      : TRANSACTIONAL_TABLES;

  const modeLabel =
    MODE === 'full'
      ? 'COMPLETO (dados de negócio + estado do sistema; preserva GoTalk e Configurações)'
      : 'TRANSACIONAL (dados de negócio; preserva GoTalk e todas as Configurações)';

  console.log('\n' + hr('═'));
  console.log('  LIMPEZA DE BANCO DE DADOS' + (DRY_RUN ? ' — DRY RUN (nenhum dado será apagado)' : ''));
  console.log(hr('═'));
  console.log(`  Banco    : ${DB_LABEL}`);
  console.log(`  Modo     : ${modeLabel}`);
  console.log(`  Tabelas  : ${tables.length}`);
  console.log(hr('─'));

  if (!DRY_RUN && (IS_PROD || CUSTOM_URL)) {
    console.log('\n  ⚠️   ATENÇÃO: banco de PRODUÇÃO detectado ou --url explícito.\n');
  }

  console.log('  Tabelas que serão limpas (em ordem):');
  tables.forEach((t, i) => console.log(`    ${String(i + 1).padStart(2)}. ${t}`));
  console.log('\n' + hr('─'));

  if (DRY_RUN) {
    console.log('\n  ℹ️   Modo dry-run: nenhuma conexão estabelecida, nenhum dado apagado.');
    console.log('      Remova --dry-run para executar a limpeza real.\n');
    process.exit(0);
  }

  if (ENVIRONMENT === 'production') {
    if (process.env.NODE_ENV !== 'production') {
      console.error('\n  ❌  Produção exige NODE_ENV=production.\n');
      process.exit(1);
    }
  }
  if (!BACKUP_EVIDENCE) {
    console.error('\n  ❌  Toda limpeza exige --backup-evidence com backup/restauração verificados.\n');
    process.exit(1);
  }
  try {
    const evidence = await import('node:fs/promises');
    const stat = await evidence.stat(BACKUP_EVIDENCE);
    if (!stat.isFile() || stat.size < 20) throw new Error('arquivo vazio');
  } catch {
    console.error('\n  ❌  Evidência de backup/restauração ausente ou inválida.\n');
    process.exit(1);
  }
  const keyword = `LIMPAR:${IS_PROD ? 'PROTEGIDO' : ENVIRONMENT}:${DB_LABEL}`;
  const answer = await prompt(`\n  Para confirmar, digite exatamente: ${keyword}\n  > `);

  if (answer.trim() !== keyword) {
    console.log('\n  ❌  Cancelado. Nenhum dado foi apagado.\n');
    process.exit(0);
  }

  console.log('\n  Conectando ao banco...');
  const client = new pg.Client({ connectionString: CONNECTION_STRING });
  await client.connect();
  console.log('  ✅  Conectado.\n');
  await client.query('BEGIN');

  console.log(hr('─'));
  console.log(`  ${'Tabela'.padEnd(40)} ${'Deletadas'.padStart(10)}`);
  console.log(hr('─'));

  let totalDeleted = 0;
  const errors = [];

  for (const table of tables) {
    try {
      const res = await client.query(`DELETE FROM "${table}"`);
      const count = res.rowCount ?? 0;
      totalDeleted += count;
      console.log(`  ${pad(table, 40)} ${String(count).padStart(10)}`);
    } catch (err) {
      console.log(`  ${pad(table, 40)} ${'ERRO'.padStart(10)}  ← ${err.message}`);
      errors.push({ table, message: err.message });
    }
  }

  console.log(hr('─'));
  console.log(`  ${'TOTAL'.padEnd(40)} ${String(totalDeleted).padStart(10)}`);
  console.log(hr('═'));

  if (errors.length > 0) {
    await client.query('ROLLBACK');
    console.log('\n  ⚠️   Erros encontrados:');
    errors.forEach(e => console.log(`    - ${e.table}: ${e.message}`));
    console.log('');
    process.exit(1);
  } else {
    await client.query('COMMIT');
    console.log('\n  ✅  Limpeza concluída sem erros.\n');
    process.exit(0);
  }
  await client.end();
}

main().catch(err => {
  console.error('\n  ❌  Erro fatal:', err.message);
  process.exit(1);
});

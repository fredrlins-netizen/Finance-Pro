import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const OUTPUT_DIR = path.join(ROOT, 'generated-artifacts');
const TEXT_EXTENSIONS = new Set([
  '.cjs', '.css', '.html', '.js', '.json', '.md', '.mjs', '.replit',
  '.sh', '.sql', '.toml', '.ts', '.tsx', '.txt', '.yaml', '.yml',
]);
const IGNORED_DIRS = new Set([
  '.agents', '.git', '.local', '.cache', 'artifacts', 'attached_assets',
  'build', 'coverage', 'dist', 'generated-artifacts', 'node_modules',
  'playwright-report', 'test-results', 'tmp', 'uploads',
]);
const EXPLICIT_FILES = [
  '.replit',
  'App.tsx',
  'contexts/GotalkContext.tsx',
  'contexts/MessagingContext.tsx',
  'hooks/useWhatsappMutePrefs.ts',
  'services/whatsappService.ts',
  'server/index.js',
  'server/socket.js',
  'server/lib/gotalkOperatorIdentity.js',
  'server/routes/gotalk.js',
  'server/routes/whatsappTemplates.js',
  'server/services/gotalkAuth.js',
  'server/services/gotalkPoller.js',
  'server/services/gotalkTranscription.js',
  'components/gotalk/GotalkChatPanel.tsx',
  'components/gotalk/GotalkAttendanceViewer.tsx',
  'components/gotalk/GoTalkMediaRenderer.tsx',
  'components/gotalk/GotalkConversationsTab.tsx',
  'components/gotalk/GotalkPhoneModal.tsx',
  'components/gotalk/GotalkSendTemplateModal.tsx',
  'components/gotalk/GotalkSyncSection.tsx',
  'components/settings/tabs/GotalkMessagesTab.tsx',
  'components/settings/tabs/WhatsappTemplatesTab.tsx',
  'components/conversas/ConversasPanel.tsx',
  'components/financeiro/CollectionOperationalPanel.tsx',
  'components/comercial/ProspeccaoWhatsappModal.tsx',
  'tests/gotalkClientTimeline.test.js',
  'tests/boundedPollerScheduler.test.js',
  'docs/central-ajuda/mensagens-whatsapp.md',
  'docs/PRD-financepro-assessoria-as-is.md',
  'schema-contract.json',
  'package.json',
  'whatsapp-worker/README.md',
  'whatsapp-worker/package.json',
  'whatsapp-worker/server.js',
  'whatsapp-worker/routes/webhook.js',
  'whatsapp-worker/services/boundedPollerScheduler.js',
  'whatsapp-worker/services/gotalkAuth.js',
  'whatsapp-worker/services/gotalkChannels.js',
  'whatsapp-worker/services/gotalkPoller.js',
  'whatsapp-worker/services/gotalkTranscription.js',
];
const RELEVANCE = /gotalk|go[\s_-]?talk|whatsapp/i;
const SECRET_VALUE_PATTERNS = [
  /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/,
  /\b(?:sk-[A-Za-z0-9_-]{24,}|AIza[A-Za-z0-9_-]{30,}|gh[pousr]_[A-Za-z0-9]{30,}|AKIA[A-Z0-9]{16})\b/,
  /\bpostgres(?:ql)?:\/\/[^/\s:@]+:[^@\s]+@/i,
];

function toPosixPath(filePath) {
  return filePath.split(path.sep).join('/');
}

function isExcludedPath(relativePath) {
  const normalized = toPosixPath(relativePath);
  const segments = normalized.split('/');
  const basename = segments.at(-1) || '';

  if (segments.some(segment => IGNORED_DIRS.has(segment))) return true;
  if (/^\.env(?:\.|$)/i.test(basename)) return true;
  if (/^\.env(?:\.|$)/i.test(normalized)) return true;
  if (/^\.{1,2}\/?$/.test(normalized)) return true;
  if (/(^|\/)(?:secrets?|credentials?)(?:\/|\.|$)/i.test(normalized)) return true;
  if (/\.(?:pem|key|p12|pfx|jks|keystore|log|zip|gz|pdf|png|jpe?g|webp|gif|mp4|webm)$/i.test(basename)) return true;
  if (/^(?:package-lock|pnpm-lock|yarn\.lock|bun\.lockb?)$/i.test(basename)) return true;
  return false;
}

async function walk(relativeDirectory = '') {
  const absoluteDirectory = path.join(ROOT, relativeDirectory);
  let entries;
  try {
    entries = await fs.readdir(absoluteDirectory, { withFileTypes: true });
  } catch (error) {
    if (error.code === 'ENOENT') return [];
    throw error;
  }

  const found = [];
  for (const entry of entries) {
    const relativePath = path.join(relativeDirectory, entry.name);
    if (isExcludedPath(relativePath)) continue;

    if (entry.isDirectory()) {
      found.push(...await walk(relativePath));
      continue;
    }
    if (entry.isFile()) found.push(relativePath);
  }
  return found;
}

async function readSafeText(relativePath) {
  if (isExcludedPath(relativePath)) return { excluded: 'path_excluded' };
  const extension = path.extname(relativePath).toLowerCase();
  if (!TEXT_EXTENSIONS.has(extension) && path.basename(relativePath) !== '.replit') {
    return { excluded: 'non_text_file' };
  }

  const absolutePath = path.join(ROOT, relativePath);
  const bytes = await fs.readFile(absolutePath);
  if (bytes.includes(0)) return { excluded: 'binary_content' };

  let content;
  try {
    content = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
  } catch {
    return { excluded: 'non_utf8_content' };
  }

  if (SECRET_VALUE_PATTERNS.some(pattern => pattern.test(content))) {
    return { excluded: 'possible_secret_value' };
  }

  return { bytes, content };
}

function timestampForFilename(date) {
  return date.toISOString().replace(/[:.]/g, '-');
}

async function main() {
  const candidates = new Set(EXPLICIT_FILES);
  const discovered = await walk();

  for (const relativePath of discovered) {
    if (isExcludedPath(relativePath)) continue;
    const normalized = toPosixPath(relativePath);
    const extension = path.extname(normalized).toLowerCase();
    if (!TEXT_EXTENSIONS.has(extension)) continue;

    const { content } = await readSafeText(normalized);
    if (RELEVANCE.test(normalized) || (content && RELEVANCE.test(content))) {
      candidates.add(normalized);
    }
  }

  const entries = [];
  const excluded = [];
  const digestOwner = new Map();
  const zip = new JSZip();

  for (const candidate of [...candidates].sort()) {
    const normalized = toPosixPath(candidate);
    const safe = await readSafeText(normalized);
    if (safe.excluded) {
      excluded.push({ path: normalized, reason: safe.excluded });
      continue;
    }

    const digest = crypto.createHash('sha256').update(safe.bytes).digest('hex');
    const firstPath = digestOwner.get(digest);
    if (!firstPath) digestOwner.set(digest, normalized);

    zip.file(normalized, safe.bytes, { date: new Date(0) });
    entries.push({
      path: normalized,
      sizeBytes: safe.bytes.length,
      sha256: digest,
      ...(firstPath ? { duplicateContentOf: firstPath } : {}),
    });
  }

  if (entries.length === 0) {
    throw new Error('Nenhum arquivo GoTalk elegível foi encontrado para exportação.');
  }

  const generatedAt = new Date();
  const manifest = {
    format: 'financepro-gotalk-source-export',
    version: 1,
    generatedAt: generatedAt.toISOString(),
    includedFileCount: entries.length,
    files: entries,
    excludedFiles: excluded,
    exclusions: [
      'Secrets, credenciais e arquivos .env (inclusive exemplos)',
      'Dados de clientes, uploads, logs e arquivos binários',
      'Dependências instaladas, builds, artefatos e diretórios temporários',
    ],
    notes: [
      'Os caminhos dentro do ZIP preservam a localização relativa no projeto original.',
      'Arquivos com referências GoTalk/WhatsApp são descobertos automaticamente e somados à lista central de arquivos.',
      'Arquivos idênticos recebem duplicateContentOf para destacar cópias sem removê-las.',
    ],
  };

  zip.file('README-EXPORT.txt', [
    'Exportação de código-fonte relacionado ao GoTalk',
    '',
    `Gerado em: ${manifest.generatedAt}`,
    `Arquivos incluídos: ${entries.length}`,
    '',
    'O manifesto manifest.json lista caminhos originais, tamanho e SHA-256.',
    'As cópias idênticas permanecem no pacote e são indicadas no manifesto.',
    'Secrets, arquivos .env, dados de clientes, uploads, binários, dependências',
    'instaladas e builds não fazem parte desta exportação.',
    '',
  ].join('\n'));
  zip.file('manifest.json', JSON.stringify(manifest, null, 2));

  await fs.mkdir(OUTPUT_DIR, { recursive: true });
  const outputPath = path.join(OUTPUT_DIR, `gotalk-export-${timestampForFilename(generatedAt)}.zip`);
  const archive = await zip.generateAsync({
    type: 'nodebuffer',
    compression: 'DEFLATE',
    compressionOptions: { level: 6 },
  });
  await fs.writeFile(outputPath, archive, { flag: 'wx' });

  console.log(`Exportação GoTalk criada: ${toPosixPath(path.relative(ROOT, outputPath))}`);
  console.log(`Arquivos-fonte incluídos: ${entries.length}`);
  console.log(`Arquivos candidatos excluídos: ${excluded.length}`);
  console.log(`Tamanho do ZIP: ${archive.length} bytes`);
}

main().catch(error => {
  console.error(`[export:gotalk] ${error.message}`);
  process.exitCode = 1;
});

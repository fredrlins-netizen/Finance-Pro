/**
 * Testes de segurança de integração (HTTP) — Auditoria Zero-Trust v3.
 *
 * Exercita o servidor ATIVO (http://localhost:3001) validando cada correção
 * aplicada. Forja cookies JWT válidos com JWT_SECRET do ambiente para simular
 * sessões admin e não-admin de forma controlada (sem depender de senhas).
 *
 * Uso:  node scripts/security-tests.mjs
 */
import jwt from 'jsonwebtoken';
import pg from 'pg';

const BASE = process.env.SEC_TEST_BASE || 'http://localhost:3001';
const COOKIE_NAME = 'finpro_auth';
const SECRET = process.env.JWT_SECRET;
if (!SECRET) {
  console.error('JWT_SECRET ausente — impossível forjar sessões de teste.');
  process.exit(1);
}

// IDs reais (seed). Admin = master; Não-admin = auditoria (USER, ATIVO).
const ADMIN_ID = '55555555-0001-4000-8000-000000000001';
const USER_ID = '33333333-0002-4000-8000-000000000002';
// Template acessível a qualquer autenticado (allowed_users/groups NULL) com filtros.
const TEMPLATE_ID = 'f0811d59-80e4-4fae-a22b-fa5e0d542134';

function sign(payload) {
  return jwt.sign(payload, SECRET, { expiresIn: '8h' });
}
const adminCookie = `${COOKIE_NAME}=${sign({ userId: ADMIN_ID, userName: 'Master', userRole: 'ADMIN', groupIds: [], allowedUnitIds: [], currentUnitId: null })}`;
const userCookie = `${COOKIE_NAME}=${sign({ userId: USER_ID, userName: 'Auditoria', userRole: 'USER', groupIds: [], allowedUnitIds: [], currentUnitId: null })}`;

let pass = 0, fail = 0;
function check(name, cond, extra = '') {
  if (cond) { pass++; console.log(`  ✓ ${name}`); }
  else { fail++; console.log(`  ✗ ${name} ${extra}`); }
}

async function req(path, { method = 'GET', cookie, body } = {}) {
  const headers = {};
  if (cookie) headers['Cookie'] = cookie;
  if (body !== undefined) headers['Content-Type'] = 'application/json';
  const res = await fetch(BASE + path, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
  let json = null;
  try { json = await res.json(); } catch { /* non-json */ }
  return { status: res.status, json };
}

async function main() {
  console.log(`\n=== Testes de Segurança (Zero-Trust v3) → ${BASE} ===\n`);

  // VULN-4 — /api/online-users exige autenticação
  console.log('[VULN-4] /api/online-users');
  {
    const noauth = await req('/api/online-users');
    check('sem auth → 401', noauth.status === 401, `(got ${noauth.status})`);
    const withauth = await req('/api/online-users', { cookie: adminCookie });
    check('com auth → 200', withauth.status === 200, `(got ${withauth.status})`);
  }

  // VULN-12 — /api/gotalk/media exige autenticação
  console.log('[VULN-12] /api/gotalk/media/:id');
  {
    const noauth = await req('/api/gotalk/media/00000000-0000-4000-8000-000000000000');
    check('sem auth → 401', noauth.status === 401, `(got ${noauth.status})`);
  }

  // VULN-3 — webhook-secret exige admin
  console.log('[VULN-3] POST /api/gotalk/webhook-secret');
  {
    const noauth = await req('/api/gotalk/webhook-secret', { method: 'POST', body: {} });
    check('sem auth → 401', noauth.status === 401, `(got ${noauth.status})`);
    const asUser = await req('/api/gotalk/webhook-secret', { method: 'POST', cookie: userCookie, body: {} });
    check('não-admin → 403', asUser.status === 403, `(got ${asUser.status})`);
  }

  // VULN-2 — execute-query: não-admin não controla o SQL
  console.log('[VULN-2] POST /api/reports/execute-query');
  {
    // (a) sem templateId → 403
    const noTpl = await req('/api/reports/execute-query', { method: 'POST', cookie: userCookie, body: { sql: 'SELECT 1' } });
    check('não-admin sem templateId → 403', noTpl.status === 403, `(got ${noTpl.status})`);

    // (b) SQL malicioso é IGNORADO; servidor roda o SQL armazenado do template
    const inj = await req('/api/reports/execute-query', {
      method: 'POST', cookie: userCookie,
      body: { sql: "SELECT 'PWNED' AS pwned_col", params: [], templateId: TEMPLATE_ID, filterValues: {} },
    });
    const cols = inj.json && inj.json.fields ? inj.json.fields.map(f => f.name) : [];
    check('não-admin: SQL injetado ignorado (sem coluna pwned_col)', inj.status === 200 && !cols.includes('pwned_col'), `(status ${inj.status}, cols ${JSON.stringify(cols)})`);

    // (c) admin pode rodar SELECT read-only arbitrário
    const adm = await req('/api/reports/execute-query', {
      method: 'POST', cookie: adminCookie,
      body: { sql: 'SELECT 42 AS resposta', params: [] },
    });
    check('admin: SELECT arbitrário → 200 com dado', adm.status === 200 && adm.json && adm.json.rows && adm.json.rows[0] && Number(adm.json.rows[0].resposta) === 42, `(status ${adm.status})`);

    // (d) admin: SQL de escrita bloqueado
    const wr = await req('/api/reports/execute-query', { method: 'POST', cookie: adminCookie, body: { sql: 'DELETE FROM users' } });
    check('admin: SQL de escrita → 403', wr.status === 403, `(got ${wr.status})`);
  }

  // VULN-8 — mensagens de erro genéricas (sem detalhes internos)
  console.log('[VULN-8] mensagens de erro genéricas');
  {
    const adm = await req('/api/reports/execute-query', { method: 'POST', cookie: adminCookie, body: { sql: 'SELECT * FROM tabela_que_nao_existe_xyz' } });
    const msg = adm.json && adm.json.error ? adm.json.error : '';
    check('erro de query não vaza detalhe do PostgreSQL', !/relation|does not exist|tabela_que_nao_existe/i.test(msg), `(msg "${msg}")`);
  }

  // VULN-9 — revalidação de status da conta em escritas
  console.log('[VULN-9] revalidação de status da conta');
  {
    const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
    try {
      await pool.query("UPDATE users SET status='INATIVO' WHERE id=$1", [USER_ID]);
      const blocked = await req('/api/clients', { method: 'POST', cookie: userCookie, body: { name: 'x' } });
      check('conta INATIVO: escrita → 403', blocked.status === 403, `(got ${blocked.status})`);
      check('mensagem indica conta inativa', /inativa/i.test(blocked.json?.error || ''), `(msg "${blocked.json?.error}")`);
    } finally {
      await pool.query("UPDATE users SET status='ATIVO' WHERE id=$1", [USER_ID]);
      await pool.end();
    }
  }

  console.log(`\n=== Resultado: ${pass} passou, ${fail} falhou ===\n`);
  process.exit(fail === 0 ? 0 : 1);
}

main().catch((e) => { console.error('Erro no runner de testes:', e); process.exit(1); });

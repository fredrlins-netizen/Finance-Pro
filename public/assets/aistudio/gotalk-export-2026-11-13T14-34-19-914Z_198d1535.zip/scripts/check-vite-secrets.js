#!/usr/bin/env node
/**
 * check-vite-secrets.js
 *
 * Verifica se existem referências a variáveis VITE_* no código frontend.
 * Qualquer import.meta.env.VITE_* é incorporado no bundle do browser durante
 * o build e fica publicamente visível — segredos de servidor NUNCA devem ser
 * expostos dessa forma.
 *
 * Uso: node scripts/check-vite-secrets.js
 * Retorna exit code 0 se não houver problemas, 1 se encontrar referências.
 *
 * É invocado automaticamente como "prebuild" antes de cada npm run build.
 */

import { readdirSync, readFileSync, statSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';

const ROOT = fileURLToPath(new URL('..', import.meta.url));

const SKIP_DIRS = new Set([
  'node_modules', 'dist', '.git', '.local',
  'whatsapp-worker', 'scripts', 'server',
]);

const INCLUDE_EXT = /\.(ts|tsx|js|jsx)$/;

function scanDir(dir) {
  const hits = [];
  let entries;
  try { entries = readdirSync(dir); } catch { return hits; }
  for (const entry of entries) {
    if (SKIP_DIRS.has(entry)) continue;
    const fullPath = join(dir, entry);
    let stat;
    try { stat = statSync(fullPath); } catch { continue; }
    if (stat.isDirectory()) {
      hits.push(...scanDir(fullPath));
    } else if (INCLUDE_EXT.test(entry)) {
      try {
        const content = readFileSync(fullPath, 'utf8');
        if (content.includes('import.meta.env.VITE_')) {
          hits.push(fullPath.replace(ROOT, '').replace(/^\//, ''));
        }
      } catch { }
    }
  }
  return hits;
}

const hits = scanDir(ROOT);

if (hits.length > 0) {
  console.error('\n[VITE_* audit] FAIL — Referências a import.meta.env.VITE_* encontradas:');
  hits.forEach(h => console.error(`  - ${h}`));
  console.error('\nGaranta que nenhuma variável VITE_* contém segredos de servidor (chaves de API,');
  console.error('tokens, senhas). Variáveis VITE_* são incorporadas no bundle do browser e ficam');
  console.error('publicamente visíveis para qualquer pessoa que inspecionar os arquivos estáticos.\n');
  process.exit(1);
} else {
  console.log('[VITE_* audit] OK — Nenhuma referência a import.meta.env.VITE_* encontrada no código frontend.');
  process.exit(0);
}

import assert from 'node:assert/strict';
import test from 'node:test';
import { readFile } from 'node:fs/promises';
import {
  RELATIONS, buildAuditQuery, relationSelect, buildInventoryQuery, inventoryColumns, exclusionCategory,
} from '../scripts/audit-legacy-references.js';
import { disposablePostgres } from './helpers/disposablePostgres.js';

test('consulta só SELECTs, sem exposição de valores ou identificadores de registros', () => {
  const query = buildAuditQuery();
  assert.doesNotMatch(query, /\b(INSERT|UPDATE|DELETE|ALTER|CREATE|DROP|COPY|CALL)\b/i);
  assert.doesNotMatch(query, /array_agg|string_agg|jsonb_agg\(raw|SELECT \*/i);
  assert.equal(RELATIONS.length, new Set(RELATIONS.map(([t, f]) => `${t}.${f}`)).size);
  assert.throws(() => relationSelect(['clients;DELETE', 'id']), /não permitida/);
  assert.throws(() => relationSelect(['appointments', 'group_id']), /não permitida/);
});

test('todas as relações e chaves existem no contrato, sem depender de projeções novas', async () => {
  const contract = JSON.parse(await readFile(new URL('../schema-contract.json', import.meta.url)));
  for (const [table, field, parent] of RELATIONS) {
    assert.ok(contract.columns.some(c => c.table === table && c.name === field), `${table}.${field}`);
    assert.ok(contract.columns.some(c => c.table === parent && c.name === 'id'), parent);
  }
  const inventory = inventoryColumns(contract);
  assert.ok(inventory.some(c => c.table === 'bank_movements' && c.name === 'cost_center_id'));
  assert.ok(!inventory.some(c => c.table.startsWith('v_') || c.name === 'record_id'));
  assert.doesNotMatch(buildInventoryQuery(contract), /\b(INSERT|UPDATE|DELETE|ALTER|CREATE|DROP|COPY|CALL)\b/i);
  assert.equal(exclusionCategory('new_table', 'unknown_id'), 'sem_destino_confirmado');
  assert.equal(exclusionCategory('messages', 'recipient_id'), 'polimorfico');
  assert.equal(exclusionCategory('appointments', 'group_id'), 'agrupamento');
  assert.equal(exclusionCategory('clients', 'gotalk_contact_id'), 'integracao_externa');
  assert.equal(exclusionCategory('gotalk_messages_archive', 'operator_id'), 'sem_destino_confirmado');
});

test('PostgreSQL classifica sem alterar dados e retorna somente agregados', async t => {
  const db = await disposablePostgres(t, { migrate: false });
  // Synthetic fixtures are confined to a disposable local database.
  await db.query(`
    CREATE TABLE companies (id uuid PRIMARY KEY, razao_social text, nome_fantasia text);
    CREATE TABLE admissions (unit_id text);
    INSERT INTO companies VALUES
      ('abcdefab-0000-0000-0000-000000000001', 'Única', 'Única'),
      ('abcdefab-0000-0000-0000-000000000002', 'Dupla', 'Fantasia'),
      ('abcdefab-0000-0000-0000-000000000003', 'Outra', 'Dupla');
    INSERT INTO admissions VALUES (NULL), (''), ('  '),
      ('abcdefab-0000-0000-0000-000000000001'),
      ('ABCDEFAB-0000-0000-0000-000000000001'),
      ('abcdefab-0000-0000-0000-000000000099'),
      (' abcdefab-0000-0000-0000-000000000001 '),
      ('  ÚNICA '), ('dupla'), ('Inexistente');
  `);
  const before = (await db.query('SELECT unit_id FROM admissions')).rows;
  await db.query('BEGIN READ ONLY');
  try {
    const result = (await db.query(relationSelect(['admissions', 'unit_id']))).rows[0];
    assert.deepEqual(result, {
      relation: 'admissions.unit_id', parent: 'companies', context: 'operacional',
      total: '10', nulo: '1', vazio: '2', id_valido: '2', uuid_orfao: '1',
      uuid_com_espacos: '1', texto_candidato_unico: '1', texto_ambiguo: '1',
      texto_sem_candidato: '1', uuid_maiusculo: '1',
    });
    assert.doesNotMatch(JSON.stringify(result), /Única|abcdefab|Inexistente/);
    assert.deepEqual((await db.query('SELECT unit_id FROM admissions')).rows, before);
  } finally {
    await db.query('ROLLBACK');
  }
});

test('IDs textuais de mensagens têm comparação exata, não resolução por nome', async t => {
  const db = await disposablePostgres(t, { migrate: false });
  await db.query(`
    CREATE TABLE messages (id text PRIMARY KEY);
    CREATE TABLE message_reads (message_id text);
    INSERT INTO messages VALUES ('legado-ABC');
    INSERT INTO message_reads VALUES ('legado-ABC'), ('legado-abc'), ('sem-pai');
  `);
  const row = (await db.query(relationSelect(['message_reads', 'message_id']))).rows[0];
  assert.equal(row.id_valido, '1');
  assert.equal(row.texto_sem_candidato, '2');
});

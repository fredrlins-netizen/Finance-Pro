import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { createServer } from 'node:http';
import test from 'node:test';
import express from 'express';
import { disposablePostgres } from './helpers/disposablePostgres.js';
import { createClientsRoutes } from '../server/routes/clients.js';
import { createCollaboratorsRoutes } from '../server/routes/collaborators.js';
import { createBanksRoutes } from '../server/routes/banks.js';
import { createUnitsRoutes } from '../server/routes/units.js';
import { createModalitiesRoutes } from '../server/routes/modalities.js';
import { createProductsRoutes } from '../server/routes/products.js';
import { createSeriesRoutes } from '../server/routes/series.js';
import { createRolesRoutes } from '../server/routes/roles.js';
import { createLookupsRoutes } from '../server/routes/lookups.js';
import { createAppointmentsRoutes } from '../server/routes/appointments.js';
import { createScheduleBlocksRoutes } from '../server/routes/scheduleBlocks.js';
import { createAdmissionsRoutes } from '../server/routes/admissions.js';
import { createFinancialTitlesRoutes } from '../server/routes/financialTitles.js';
import { createBankMovementsRoutes } from '../server/routes/bankMovements.js';
import { createUsersRoutes } from '../server/routes/users.js';
import { createUserGroupsRoutes } from '../server/routes/userGroups.js';
import { createLegalProcessesRoutes } from '../server/routes/legalProcesses.js';
import { createNegotiationsRoutes } from '../server/routes/negotiations.js';
import { createCommercialDealsRoutes } from '../server/routes/commercialDeals.js';
import { createCollectionNotesRoutes } from '../server/routes/collectionNotes.js';
import { createConfigOptionsRoutes } from '../server/routes/configOptions.js';
import { createSettlementsRoutes } from '../server/routes/settlements.js';
import { syncConfigToDB } from '../server/sync-config-to-db.js';
import { findUniqueCollaboratorByPhone } from '../server/lib/gotalkOperatorIdentity.js';

const camel = key => key.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
const readField = (row, key) => row[key] ?? row[camel(key)];

test('CRUD real dos cadastros: inclusão, listagem, busca, visualização, alteração, cópia e exclusão', {
  timeout: 120_000,
}, async t => {
  const pool = await disposablePostgres(t);
  const ids = Object.fromEntries(['unit', 'client', 'bank', 'collaborator', 'account', 'actor'].map(key => [key, randomUUID()]));
  await pool.query('INSERT INTO companies(id, razao_social, nome_fantasia) VALUES ($1,$2,$2)', [ids.unit, 'Unidade de teste isolada']);
  await pool.query('INSERT INTO clients(id, name) VALUES ($1,$2)', [ids.client, 'Cliente de teste isolado']);
  await pool.query('INSERT INTO banks(id, name) VALUES ($1,$2)', [ids.bank, 'Banco de teste isolado']);
  await pool.query('INSERT INTO collaborators(id, name, unit_id) VALUES ($1,$2,$3)', [ids.collaborator, 'Colaborador de teste isolado', ids.unit]);
  await pool.query('INSERT INTO bank_accounts(id, bank_id, description) VALUES ($1,$2,$3)', [ids.account, ids.bank, 'Conta de teste isolada']);

  const app = express();
  app.use(express.json());
  app.use((req, _res, next) => {
    req.currentUser = {
      id: ids.actor, name: 'Auditoria isolada', isAdmin: true, role: 'ADMIN',
      currentUnitId: ids.unit, allowedUnitIds: [ids.unit],
    };
    next();
  });
  for (const [route, create] of [
    ['clients', createClientsRoutes], ['collaborators', createCollaboratorsRoutes],
    ['banks', createBanksRoutes], ['units', createUnitsRoutes],
    ['modalities', createModalitiesRoutes], ['products', createProductsRoutes],
    ['series', createSeriesRoutes], ['roles', createRolesRoutes],
    ['lookups', createLookupsRoutes], ['appointments', createAppointmentsRoutes],
    ['schedule-blocks', createScheduleBlocksRoutes], ['admissions', createAdmissionsRoutes],
    ['financial-titles', createFinancialTitlesRoutes], ['bank-movements', createBankMovementsRoutes],
    ['users', createUsersRoutes], ['user-groups', createUserGroupsRoutes],
    ['legal-processes', createLegalProcessesRoutes],
    ['negotiations', createNegotiationsRoutes], ['commercial-deals', createCommercialDealsRoutes],
    ['collection-notes', createCollectionNotesRoutes], ['config-options', createConfigOptionsRoutes],
    ['settlements', createSettlementsRoutes],
  ]) app.use(`/api/${route}`, create(pool));
  const server = createServer(app);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => {
    server.close(resolve);
    server.closeAllConnections();
  }));
  const base = `http://127.0.0.1:${server.address().port}/api`;
  const request = async (method, route, body, expected = 200) => {
    const response = await fetch(`${base}/${route}`, {
      method, headers: { 'Content-Type': 'application/json' },
      ...(body === undefined ? {} : { body: JSON.stringify(body) }),
      signal: AbortSignal.timeout(10_000),
    });
    const result = await response.json();
    assert.equal(response.status, expected, `${method} ${route}: ${JSON.stringify(result)}`);
    const assertPublicKeys = value => {
      if (!value || typeof value !== 'object') return;
      for (const [key, nested] of Object.entries(value)) {
        assert.ok(!key.startsWith('_reference_') && !/^Reference[A-Z]/.test(key),
          `Coluna técnica exposta em ${method} ${route}: ${key}`);
        assertPublicKeys(nested);
      }
    };
    assertPublicKeys(result);
    return result;
  };

  await t.test('vínculos exigem IDs existentes, nunca nomes, e alterações parciais preservam relações', async () => {
    const appointment = { date: '2026-11-11', start_time: '14:00', end_time: '15:00' };
    for (const value of ['Cliente de teste isolado', randomUUID()]) {
      await request('POST', 'appointments', { ...appointment, client_id: value }, 400);
      await request('POST', 'admissions', { client_name: 'Snapshot', status: 'PENDENTE', unit_id: value }, 400);
      await request('POST', 'bank-movements', { bank_account_id: value, date: '2026-11-11', description: 'Inválido', value: 1, type: 'CREDITO' }, 400);
      await request('POST', 'commercial-deals', { client_name: 'Snapshot', collaborator_id: value }, 400);
      await request('POST', 'collection-notes', { id: randomUUID(), note: 'Teste', clientId: value }, 400);
      await request('POST', 'negotiations', { clientName: 'Snapshot', collaboratorId: ids.collaborator, clientId: value }, 400);
    }
    const created = (await request('POST', 'appointments', { ...appointment, client_id: ids.client, unit_id: ids.unit }, 201)).data;
    await request('PUT', `appointments/${created.id}`, { client_id: 'Cliente por nome' }, 400);
    await request('PUT', `appointments/${created.id}`, { notes: 'Alteração sem mudar vínculo' });
    assert.equal((await request('GET', `appointments/${created.id}`)).data.clientId, ids.client);
    await request('DELETE', `appointments/${created.id}`);

    const deal = (await request('POST', 'commercial-deals', { client_id: ids.client, client_name: 'Snapshot', bank_id: ids.bank, unit_id: ids.unit }, 201)).data;
    const changed = (await request('PUT', `commercial-deals/${deal.id}`, { notes: 'Apenas observação' })).data;
    assert.equal(changed.clientId, ids.client);
    assert.equal(changed.bankId, ids.bank);
    assert.equal(changed.unitId, ids.unit);
    assert.equal((await request('PUT', `commercial-deals/${deal.id}`, { client_id: null })).data.clientId, undefined);
    await request('DELETE', `commercial-deals/${deal.id}`);

    const negotiation = await request('POST', 'negotiations', { clientId: ids.client, clientName: 'Snapshot', bankId: ids.bank, collaboratorId: ids.collaborator }, 201);
    const edited = await request('PUT', `negotiations/${negotiation.id}`, { notes: 'Apenas observação' });
    assert.equal(edited.clientId, ids.client);
    assert.equal(edited.bankId, ids.bank);
    await request('DELETE', `negotiations/${negotiation.id}`);
    const bulk = await request('POST', 'collection-notes/bulk', { notes: [{ id: 'invalid-link', note: 'Não gravar', clientId: 'Nome não é ID' }] });
    assert.deepEqual(bulk.failedIds, ['invalid-link']);
  });

  await t.test('admissões e títulos não podem ser vinculados ao cliente errado e a sincronização conserva IDs jurídicos', async () => {
    const otherClientId = randomUUID();
    await pool.query('INSERT INTO clients(id, name) VALUES ($1, $2)', [otherClientId, 'Outro cliente']);
    const admission = (await request('POST', 'admissions', { client_id: ids.client, client_name: 'Snapshot', status: 'PENDENTE', contract_number: 'CONTRATO-IDENTIDADE' }, 201)).data;
    const title = (await request('POST', 'financial-titles', { title_scope: 'RECEBER', value: 10, client_id: ids.client, admission_id: admission.id }, 201)).data;
    await request('POST', 'financial-titles', { title_scope: 'RECEBER', value: 10, client_id: otherClientId, admission_id: admission.id }, 400);
    await request('POST', 'negotiations', { clientId: otherClientId, clientName: 'Outro', collaboratorId: ids.collaborator, admissionId: admission.id }, 400);
    await request('POST', 'negotiations', { clientId: otherClientId, clientName: 'Outro', collaboratorId: ids.collaborator, titleId: title.id }, 400);
    await request('POST', 'legal-processes', { client_id: otherClientId, admission_id: admission.id, process_number: 'CROSS-CLIENT', status: 'ATIVO' }, 400);
    await request('PUT', `financial-titles/${title.id}`, { client_id: otherClientId }, 400);
    const processId = randomUUID();
    await request('POST', 'financial-titles/create-installments', {
      title_scope: 'RECEBER', value: 10, total_installments: 2, due_date: '2026-11-11',
      client_id: otherClientId, model_title_id: title.id,
    }, 400);
    const config = {
      admissions: [{ id: admission.id, clientId: ids.client, clientName: 'Snapshot', unitId: ids.unit, titularClientId: otherClientId, contractNumber: 'CONTRATO-IDENTIDADE', status: 'PENDENTE' }],
      companyLegalProcesses: [{ id: processId, clientId: ids.client, admissionId: admission.id, unitId: ids.unit, processNumber: 'SYNC-IDENTITY', status: 'ATIVO' }],
    };
    await pool.query("INSERT INTO app_data(key, value) VALUES ('portal_config', $1) ON CONFLICT(key) DO UPDATE SET value = EXCLUDED.value", [JSON.stringify(config)]);
    await syncConfigToDB(pool);
    assert.deepEqual((await pool.query('SELECT client_id, admission_id FROM legal_processes WHERE id = $1', [processId])).rows, [{ client_id: ids.client, admission_id: admission.id }]);
    assert.deepEqual((await pool.query('SELECT unit_id, titular_client_id FROM admissions WHERE id = $1', [admission.id])).rows, [{ unit_id: ids.unit, titular_client_id: otherClientId }]);
    await request('DELETE', `legal-processes/${processId}`);
    await request('DELETE', `financial-titles/${title.id}`);
    await request('DELETE', `admissions/${admission.id}`);
  });

  await t.test('operadores só recebem o ID de colaborador por telefone completo e único, preservando o DDD', async () => {
    const first = randomUUID();
    const otherArea = randomUUID();
    const duplicate = randomUUID();
    await pool.query("INSERT INTO collaborators(id, name, phone) VALUES ($1, 'Mesmo nome', '(11) 91234-5678'), ($2, 'Mesmo nome', '(21) 91234-5678')", [first, otherArea]);
    assert.equal(await findUniqueCollaboratorByPhone(pool, '+55 11 91234-5678'), first);
    assert.equal(await findUniqueCollaboratorByPhone(pool, '21912345678'), otherArea);
    assert.equal(await findUniqueCollaboratorByPhone(pool, 'Mesmo nome'), null);
    await pool.query("INSERT INTO collaborators(id, name, phone) VALUES ($1, 'Outro nome', '+55 11 91234-5678')", [duplicate]);
    assert.equal(await findUniqueCollaboratorByPhone(pool, '11912345678'), null);
    await pool.query('DELETE FROM collaborators WHERE id = ANY($1::uuid[])', [[first, otherArea, duplicate]]);
  });

  const cases = [
    { route: 'clients', field: 'name', data: { name: 'AUD Cliente', type: 'FISICA', document: '12345678901', notes: 'Inicial' } },
    { route: 'collaborators', field: 'name', data: { name: 'AUD Colaborador', unit_id: ids.unit, active: true } },
    { route: 'banks', field: 'name', data: { name: 'AUD Banco', status: 'ATIVO' } },
    { route: 'units', field: 'razao_social', data: { razao_social: 'AUD Unidade', nome_fantasia: 'AUD Unidade' } },
    { route: 'modalities', field: 'description', data: { type: 'AUD Modalidade', description: 'AUD Modalidade' } },
    { route: 'products', field: 'description', data: { type: 'SERVICO', description: 'AUD Produto' } },
    { route: 'series', field: 'sigla', data: { sigla: 'AUD', description: 'AUD Série', general_number: 0 } },
    { route: 'roles', field: 'value', data: { value: JSON.stringify({ name: 'AUD Cargo', participatesInScheduling: false }) } },
    { route: 'lookups/bearers', field: 'name', data: { code: 'AUD', name: 'AUD Portador', type: 'CARTEIRA' } },
    { route: 'lookups/departments', field: 'name', data: { code: 'AUD', name: 'AUD Departamento', status: 'ATIVO' } },
    { route: 'lookups/document-types', field: 'description', data: { description: 'AUD Documento', status: 'ATIVO' } },
    { route: 'lookups/chart-of-accounts', field: 'name', data: { code: 'AUD', name: 'AUD Conta contábil', type: 'RECEITA', is_analytical: true } },
    { route: 'lookups/measurement-units', field: 'name', data: { name: 'AUD Medida', conversion_factor: 1 } },
    { route: 'appointments', field: 'notes', rejectIdentical: true, copyOverrides: { start_time: '12:00', end_time: '13:00' }, data: { date: '2026-10-21', start_time: '10:00', end_time: '11:00', client_id: ids.client, client_name: 'Cliente isolado', collaborator_id: ids.collaborator, unit_id: ids.unit, notes: 'AUD Agendamento', status: 'AGENDADO' } },
    { route: 'schedule-blocks', field: 'reason', data: { start_date: '2026-10-21', end_date: '2026-10-21', collaborator_id: ids.collaborator, is_whole_day: true, reason: 'AUD Bloqueio' } },
    { route: 'admissions', field: 'client_name', data: { client_name: 'AUD Admissão', client_id: ids.client, bank_id: ids.bank, unit_id: ids.unit, date: '2026-10-21', status: 'PENDENTE', contract_number: 'AUD-001' } },
    ...['RECEBER', 'PAGAR'].map(scope => ({
      route: 'financial-titles', field: 'description',
      data: { title_scope: scope, description: `AUD ${scope}`, client_id: ids.client, unit_id: ids.unit, value: 123.45, due_date: '2026-10-21', status: 'ABERTO' },
    })),
    { route: 'bank-movements', field: 'description', data: { bank_account_id: ids.account, date: '2026-10-21', description: 'AUD Movimento', value: 12.34, type: 'CREDITO', origin: 'MANUAL' } },
    { route: 'users', field: 'name', unique: 'email', data: { name: 'AUD Usuário', email: 'auditoria@example.invalid', role: 'USER', status: 'ATIVO' } },
    { route: 'user-groups', field: 'name', data: { name: 'AUD Grupo' } },
    { route: 'legal-processes', field: 'process_number', snakeBody: true, data: { process_number: 'AUD-PROC-001', status: 'EM_ANDAMENTO', client_id: ids.client, unit_id: ids.unit } },
    { route: 'commercial-deals', field: 'client_name', snakeBody: true, data: { client_name: 'AUD Negociação comercial', client_id: ids.client, unit_id: ids.unit, bank_id: ids.bank, collaborator_id: ids.collaborator, stage: 'TRIAGEM', debt_value: 100, proposal_value: 80 } },
  ];

  for (const item of cases) {
    await t.test(`${item.route} ${item.data.title_scope || ''}`.trim(), async () => {
      const { route, data, field } = item;
      await request('POST', route, {}, 400);
      const created = (await request('POST', route, data, 201)).data;
      assert.ok(created.id);
      const originalId = created.id;
      assert.equal(readField(created, field), data[field]);
      const detail = (await request('GET', `${route}/${originalId}`)).data;
      assert.equal(detail.id, originalId);
      const list = await request('GET', `${route}?limit=1&page=1`);
      assert.ok(list.total >= 1);
      assert.equal(list.data.length, 1);
      const editedValue = field === 'value'
        ? JSON.stringify({ name: 'AUD Cargo alterado', participatesInScheduling: true })
        : `${data[field]} alterado`;
      const updated = (await request('PUT', `${route}/${originalId}`, { [item.snakeBody ? field : camel(field)]: editedValue })).data;
      assert.equal(readField(updated, field), editedValue, 'o formato enviado pela interface deve persistir');
      const visible = (await request('GET', `${route}/${originalId}`)).data;
      assert.equal(readField(visible, field), editedValue);
      const search = await request('GET', `${route}?search=${encodeURIComponent('AUD')}&limit=100`);
      assert.ok(search.data.some(row => row.id === originalId), 'registro alterado deve continuar pesquisável');
      if (item.rejectIdentical) await request('POST', route, data, 409);
      const copyData = { ...data, ...item.copyOverrides, id: originalId, [field]: field === 'value' ? JSON.stringify({ name: 'AUD Cargo cópia' }) : `${data[field]} cópia` };
      if (item.unique) copyData[item.unique] = 'copia-auditoria@example.invalid';
      const copy = (await request('POST', route, copyData, 201)).data;
      assert.notEqual(copy.id, originalId, 'uma cópia nunca pode sobrescrever o original');
      assert.equal(readField((await request('GET', `${route}/${originalId}`)).data, field), editedValue);
      await request('DELETE', `${route}/${copy.id}`);
      await request('GET', `${route}/${copy.id}`, undefined, 404);
      await request('DELETE', `${route}/${originalId}`);
      await request('GET', `${route}/${originalId}`, undefined, 404);
      await request('PUT', `${route}/${originalId}`, { [field]: editedValue }, 404);
      await request('DELETE', `${route}/${originalId}`, undefined, 404);
      await request('GET', `${route}/invalid-id`, undefined, 400);
    });
  }

  await t.test('e-mail duplicado é recusado sem modificar o usuário original', async () => {
    const data = { name: 'AUD Duplicidade', email: 'duplicado@example.invalid' };
    const first = (await request('POST', 'users', data, 201)).data;
    await request('POST', 'users', { ...data, name: 'Não deve substituir' }, 409);
    assert.equal((await request('GET', `users/${first.id}`)).data.name, data.name);
    await request('DELETE', `users/${first.id}`);
  });

  await t.test('vínculos bloqueiam exclusões de cliente, banco e colaborador', async () => {
    const admission = (await request('POST', 'admissions', {
      client_id: ids.client, client_name: 'Vínculo isolado', bank_id: ids.bank,
      collaborator_id: ids.collaborator, status: 'PENDENTE', unit_id: ids.unit,
    }, 201)).data;
    for (const [route, id] of [['clients', ids.client], ['banks', ids.bank], ['collaborators', ids.collaborator]]) {
      await request('DELETE', `${route}/${id}`, undefined, 409);
      assert.equal((await request('GET', `${route}/${id}`)).data.id, id);
    }
    await request('DELETE', `admissions/${admission.id}`);
  });

  await t.test('negociação financeira: CRUD, visualização e conflito de identidade', async () => {
    const data = { id: randomUUID(), clientId: ids.client, clientName: 'AUD Negociação financeira', collaboratorId: ids.collaborator, bankId: ids.bank, debtValue: '100,00', notes: 'Inicial' };
    const created = await request('POST', 'negotiations', data, 201);
    assert.equal(created.id, data.id);
    await request('POST', 'negotiations', { ...data, clientName: 'Não deve substituir' }, 409);
    assert.equal((await request('GET', `negotiations/${data.id}`)).clientName, data.clientName);
    assert.ok((await request('GET', `negotiations?clientId=${ids.client}`)).some(row => row.id === data.id));
    await request('PUT', `negotiations/${data.id}`, { ...created, notes: 'Alterada' });
    assert.equal((await request('GET', `negotiations/${data.id}`)).notes, 'Alterada');
    await request('DELETE', `negotiations/${data.id}`);
    await request('GET', `negotiations/${data.id}`, undefined, 404);
  });

  await t.test('notas de cobrança: CRUD e reenvio idempotente sem sobrescrever o texto', async () => {
    const data = { id: randomUUID(), clientId: ids.client, note: 'AUD Nota inicial', collaboratorId: ids.collaborator };
    const created = await request('POST', 'collection-notes', data, 201);
    assert.equal(created.note, data.note);
    await request('POST', 'collection-notes', { ...data, note: 'Não deve substituir' });
    let rows = await request('GET', `collection-notes?clientId=${ids.client}`);
    assert.equal(rows.find(row => row.id === data.id).note, data.note);
    await request('PUT', `collection-notes/${data.id}`, { note: 'AUD Nota alterada', negotiationStatus: 'FECHADA' });
    rows = await request('GET', `collection-notes?clientId=${ids.client}`);
    assert.equal(rows.find(row => row.id === data.id).note, 'AUD Nota alterada');
    await request('DELETE', `collection-notes/${data.id}`);
    assert.equal((await request('GET', `collection-notes?clientId=${ids.client}`)).some(row => row.id === data.id), false);
    await request('DELETE', `collection-notes/${data.id}`, undefined, 404);
  });

  for (const optionType of (await request('GET', 'config-options/types')).data) {
    await t.test(`opções auxiliares ${optionType}: criar, listar, alterar e excluir`, async () => {
      const route = `config-options/${optionType}`;
      const created = (await request('POST', route, { value: `AUD ${optionType}` }, 201)).data;
      assert.ok((await request('GET', route)).data.some(row => row.id === created.id));
      await request('PUT', `${route}/${created.id}`, { value: `AUD ${optionType} alterado` });
      assert.equal((await request('GET', route)).data.find(row => row.id === created.id).value, `AUD ${optionType} alterado`);
      await request('DELETE', `${route}/${created.id}`);
      assert.equal((await request('GET', route)).data.some(row => row.id === created.id), false);
    });
  }

  await t.test('liquidação: criar, editar, visualizar e excluir mantendo saldo do título', async () => {
    const title = (await request('POST', 'financial-titles', {
      title_scope: 'RECEBER', value: 100, client_id: ids.client, unit_id: ids.unit,
    }, 201)).data;
    const settlement = (await request('POST', 'settlements', {
      title_id: title.id, date: '2026-10-21', amount: 30,
    }, 201)).data;
    assert.equal(Number((await request('GET', `financial-titles/${title.id}`)).data.currentBalance), 70);
    await request('PUT', `settlements/${settlement.id}`, { amount: 40 });
    assert.equal(Number((await request('GET', `settlements/${settlement.id}`)).data.amount), 40);
    const afterUpdate = (await request('GET', `financial-titles/${title.id}`)).data;
    assert.equal(Number(afterUpdate.currentBalance), 60, 'editar a liquidação deve recalcular o saldo');
    assert.equal(afterUpdate.status, 'PARCIAL');
    await request('PUT', `settlements/${settlement.id}`, { amount: 0 }, 400);
    assert.equal(Number((await request('GET', `financial-titles/${title.id}`)).data.currentBalance), 60);
    await request('PUT', `settlements/${settlement.id}`, { amount: 100 });
    assert.equal((await request('GET', `financial-titles/${title.id}`)).data.status, 'PAGO');
    await request('PUT', `settlements/${settlement.id}`, { amount: 40 });
    assert.equal((await request('GET', `financial-titles/${title.id}`)).data.status, 'PARCIAL');
    await request('DELETE', `settlements/${settlement.id}`);
    const afterDelete = (await request('GET', `financial-titles/${title.id}`)).data;
    assert.equal(Number(afterDelete.currentBalance), 100);
    assert.equal(afterDelete.status, 'ABERTO');
    await request('DELETE', `financial-titles/${title.id}`);
  });

  await t.test('liquidações simultâneas não deixam o saldo desatualizado', async () => {
    const title = (await request('POST', 'financial-titles', {
      title_scope: 'RECEBER', value: 100, client_id: ids.client, unit_id: ids.unit,
    }, 201)).data;
    const settlements = await Promise.all([30, 20].map(amount =>
      request('POST', 'settlements', { title_id: title.id, date: '2026-10-21', amount }, 201)
    ));
    assert.equal(Number((await request('GET', `financial-titles/${title.id}`)).data.currentBalance), 50);
    await Promise.all(settlements.map((result, index) =>
      request('PUT', `settlements/${result.data.id}`, { amount: 10 + index * 10 })
    ));
    assert.equal(Number((await request('GET', `financial-titles/${title.id}`)).data.currentBalance), 70);
    await Promise.all(settlements.map(result => request('DELETE', `settlements/${result.data.id}`)));
    const restored = (await request('GET', `financial-titles/${title.id}`)).data;
    assert.equal(Number(restored.currentBalance), 100);
    assert.equal(restored.status, 'ABERTO');
    await request('DELETE', `financial-titles/${title.id}`);
  });

  assert.ok((await pool.query('SELECT COUNT(*)::int AS count FROM audit_logs')).rows[0].count > 0);
});

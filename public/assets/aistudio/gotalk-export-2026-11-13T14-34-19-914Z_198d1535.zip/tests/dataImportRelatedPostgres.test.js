import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { createServer } from 'node:http';
import { mkdtemp, readdir, readFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import test from 'node:test';
import express from 'express';
import ExcelJS from 'exceljs';
import pg from 'pg';
import { createDataImportRoutes, parseXlsxImport, validateImportGroups } from '../server/routes/dataImport.js';
import { processDataImport } from '../server/workers/dataImportWorker.js';
import { encodeImportMappingHeader } from '../utils/importSpreadsheet.js';
import { parseAdmissionRecalculation, persistAdmissionRecalculation } from '../server/lib/admissionRecalculationImport.js';
import { createContractAttachmentRoutes } from '../server/routes/contractAttachments.js';

const { Pool } = pg;
const XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const USER = {
  id: '10000000-0000-4000-8000-000000000001',
  name: 'Teste de importação relacionada',
  isAdmin: true,
  role: 'ADMIN',
  currentUnitId: '10000000-0000-4000-8000-000000000002',
};

test('importação resolve nomes únicos para IDs, recusa duplicados e não troca vínculos fora de admissões após a prévia', {
  timeout: 120_000,
}, async t => {
  let prepared;
  const job = {
    id: '10000000-0000-4000-8000-000000000099',
    queue: 'data-import-xlsx', status: 'completed',
    payload: { userId: USER.id, unitId: USER.currentUnitId },
    result: { dataKey: 'isolated-prepared-import' },
  };
  const { pool, baseUrl } = await createDisposablePostgres(t, {
    getJob: async () => job,
    claimJobForExecution: async () => job,
    downloadImportObject: async () => Buffer.from(JSON.stringify(prepared)),
    updateJob: async () => true,
    deleteImportObject: async () => true,
  }, { migrationPath: 'fresh' });
  const [first, second, unique, replacement] = [81, 82, 83, 84].map(n => `10000000-0000-4000-8000-0000000000${n}`);
  await pool.query(`INSERT INTO banks(id, name, febraban_code) VALUES
    ($1, 'Banco repetido', '101'), ($2, 'Banco repetido', '102'), ($3, 'Banco único', '103')`,
  [first, second, unique]);
  const groups = [{ table: 'bank_contacts', rows: [
    { name: 'Recusado ambíguo', bank_name: 'Banco repetido' },
    { name: 'Vínculo por código único', bank_name: 'Banco repetido', bank_febraban_code: '102' },
    { name: 'Recusado conflitante', bank_name: 'Banco único', bank_febraban_code: '102' },
    { name: 'Recusado ausente', bank_name: 'Banco inexistente' },
  ] }];
  const preview = await validateImportGroups(pool, groups, false, undefined, { includeParentSnapshots: true });
  assert.deepEqual(preview[0].rows.map(row => row.status), ['error', 'ok', 'error', 'error']);
  assert.equal(preview[0].rows[1].parentIds.bank_id, second);
  const execute = async body => {
    const response = await fetch(`${baseUrl}/api/import/execute`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stepUpToken: 'disposable-postgres-test', ...body }),
    });
    assert.equal(response.status, 200, await response.clone().text());
    return response.json();
  };
  const result = await execute({ groups });
  assert.equal(result.inserted, 1, JSON.stringify(result));
  assert.equal(result.inconsistent, 3, JSON.stringify(result));
  assert.deepEqual((await pool.query('SELECT bank_id FROM bank_contacts')).rows, [{ bank_id: second }]);

  const duplicates = [{ table: 'banks', rows: [{ name: ' banco repetido ', notes: 'Não sobrescrever por acaso' }] }];
  const duplicatePreview = await validateImportGroups(pool, duplicates);
  assert.equal(duplicatePreview[0].rows[0].status, 'error');
  const duplicateResult = await execute({ groups: duplicates });
  assert.equal(duplicateResult.inconsistent, 1);
  assert.equal((await pool.query('SELECT count(*)::int AS total FROM banks WHERE notes IS NOT NULL')).rows[0].total, 0);

  const uniqueGroups = [{ table: 'bank_contacts', rows: [{ name: 'Contato da prévia', bank_name: 'Banco único' }] }];
  const uniquePreview = await validateImportGroups(pool, uniqueGroups, false, undefined, { includeParentSnapshots: true });
  prepared = { groups: uniqueGroups, parentSnapshots: { bank_contacts: uniquePreview[0].rows.map(row => row.parentIds) } };
  await pool.query('UPDATE banks SET name = $2 WHERE id = $1', [unique, 'Banco renomeado']);
  await pool.query('INSERT INTO banks(id, name) VALUES ($1, $2)', [replacement, 'Banco único']);
  const changed = await execute({ importJobId: job.id });
  assert.equal(changed.inserted, 0, JSON.stringify(changed));
  assert.equal(changed.inconsistent, 1, JSON.stringify(changed));
  assert.match(changed.groups[0].errors[0].errors[0].message, /mudou desde a prévia/);
  assert.equal((await pool.query("SELECT count(*)::int AS total FROM bank_contacts WHERE name = 'Contato da prévia'")).rows[0].total, 0);

  const clientA = '10000000-0000-4000-8000-000000000085';
  const clientB = '10000000-0000-4000-8000-000000000086';
  await pool.query("INSERT INTO clients(id, name, document) VALUES ($1, 'Homônimo entre lote e banco', '11111111111'), ($2, 'Outro cliente relacionado', '22222222222')", [clientA, clientB]);
  const homonyms = [
    { table: 'clients', rows: [{ name: 'Homônimo entre lote e banco', document: '33333333333' }] },
    { table: 'admissions', rows: [{ client_name: 'Homônimo entre lote e banco', contract_number: 'AMBIGUOUS-BATCH' }] },
  ];
  const homonymPreview = await validateImportGroups(pool, homonyms);
  assert.equal(homonymPreview.find(group => group.table === 'admissions').rows[0].status, 'error');
  const homonymExecution = await execute({ groups: homonyms });
  assert.equal(homonymExecution.groups.find(group => group.table === 'admissions').inserted, 0);
  await pool.query("INSERT INTO admissions(client_id, client_name, contract_number) VALUES ($1, 'Snapshot', 'OWNER-A')", [clientA]);
  const crossed = [
    { table: 'legal_processes', rows: [{ process_number: 'CROSSED-IMPORT', client_name: 'Outro cliente relacionado', admission_contract_number: 'OWNER-A' }] },
    { table: 'financial_titles', rows: [{ title_scope: 'RECEBER', value: 10, client_name: 'Outro cliente relacionado', admission_contract_number: 'OWNER-A' }] },
  ];
  const crossedPreview = await validateImportGroups(pool, crossed);
  assert.ok(crossedPreview.every(group => group.rows[0].status === 'error'));
  const crossedExecution = await execute({ groups: crossed });
  assert.equal(crossedExecution.inserted, 0);
  assert.equal(crossedExecution.inconsistent, 2);
  const sameBatchGroups = [
    { table: 'banks', rows: [{ name: 'Banco criado após prévia' }] },
    { table: 'bank_contacts', rows: [{ name: 'Contato do mesmo lote', bank_name: 'Banco criado após prévia' }] },
  ];
  const sameBatchPreview = await validateImportGroups(pool, sameBatchGroups, false, undefined, { includeParentSnapshots: true });
  prepared = {
    groups: sameBatchGroups,
    parentSnapshots: Object.fromEntries(sameBatchPreview.map(group => [group.table, group.rows.map(row => row.parentIds || {})])),
  };
  const sameBatchExecution = await execute({ importJobId: job.id, mode: 'abort_on_any_error' });
  assert.equal(sameBatchExecution.inserted, 2, JSON.stringify(sameBatchExecution));
  assert.equal((await pool.query(`SELECT count(*)::int AS total FROM bank_contacts c JOIN banks b ON b.id = c.bank_id
    WHERE c.name = 'Contato do mesmo lote' AND b.name = 'Banco criado após prévia'`)).rows[0].total, 1);
});

async function createDisposablePostgres(t, routeDependencies = {}, { migrationPath = 'minimal' } = {}) {
  const root = await mkdtemp(path.join(tmpdir(), 'data-import-related-pg-'));
  const socketDir = path.join(root, 'socket');
  const dataDir = path.join(root, 'data');
  const databaseName = 'data_import_related';
  const port = 20_000 + Math.floor(Math.random() * 20_000);
  let started = false;
  let pool;
  let server;

  t.after(async () => {
    if (server) {
      await new Promise(resolve => {
        server.close(() => resolve());
        server.closeAllConnections();
      });
    }
    if (pool) await pool.end();
    if (started) {
      execFileSync('pg_ctl', ['-D', dataDir, '-m', 'immediate', '-w', 'stop'], { stdio: 'ignore' });
    }
    await rm(root, { recursive: true, force: true });
  });

  execFileSync('mkdir', ['-p', socketDir]);
  execFileSync('initdb', ['-D', dataDir, '-A', 'trust', '-U', 'postgres', '--no-locale'], { stdio: 'ignore' });
  execFileSync('pg_ctl', ['-D', dataDir, '-o', `-F -k ${socketDir} -p ${port}`, '-w', 'start'], { stdio: 'ignore' });
  started = true;

  const adminPool = new Pool({
    host: socketDir,
    port,
    user: 'postgres',
    database: 'postgres',
    max: 1,
  });
  await adminPool.query(`CREATE DATABASE ${databaseName}`);
  await adminPool.end();

  pool = new Pool({
    host: socketDir,
    port,
    user: 'postgres',
    database: databaseName,
    max: 3,
  });
  if (migrationPath === 'fresh') {
    const databaseUrl = `postgresql://postgres@localhost:${port}/${databaseName}?host=${encodeURIComponent(socketDir)}`;
    try {
      execFileSync(process.execPath, [path.join(projectRoot, 'scripts/migrate.js')], {
        cwd: projectRoot,
        env: { ...process.env, DATABASE_URL: databaseUrl },
        stdio: 'pipe',
      });
    } catch (error) {
      const output = [error.stdout, error.stderr].filter(Boolean).map(value => value.toString()).join('\n');
      throw new Error(`As migrações atuais falharam no PostgreSQL descartável.${output ? `\n${output}` : ''}`, {
        cause: error,
      });
    }
  } else if (migrationPath === 'upgrade') {
    const migrationNames = (await readdir(path.join(projectRoot, 'migrations')))
      .filter(filename => filename.endsWith('.sql'))
      .sort();
    const client = await pool.connect();
    try {
      await client.query(`
        CREATE TABLE migrations_log (
          id SERIAL PRIMARY KEY,
          filename VARCHAR(255) NOT NULL UNIQUE,
          applied_at TIMESTAMPTZ DEFAULT NOW()
        )
      `);
      for (const filename of migrationNames.filter(name => name < '051_startup_schema.sql')) {
        await client.query('BEGIN');
        await client.query(await readFile(path.join(projectRoot, 'migrations', filename), 'utf8'));
        await client.query('INSERT INTO migrations_log(filename) VALUES ($1)', [filename]);
        await client.query('COMMIT');
      }

      await client.query(
        'INSERT INTO clients(id, name) VALUES ($1, $2)',
        ['20000000-0000-4000-8000-000000000001', 'Cliente legado preservado'],
      );
      await client.query(`
        CREATE VIEW v_gotalk_client_timeline AS
        SELECT gm.id AS message_id,
               gm.gotalk_message_id,
               gm.phone_number,
               gm.direction,
               gm.body,
               gm.message_type,
               gm.attachment_url,
               gm.attachment_name,
               gm.attachment_mime_type,
               gm.audio_transcript,
               gm.ack_status,
               gm.operator_name AS message_operator_name,
               gm.department AS message_department,
               gm.sent_at,
               gm.client_id,
               NULL::UUID AS attendance_history_id
          FROM gotalk_messages gm
      `);

      for (const filename of migrationNames.filter(name => name >= '051_startup_schema.sql')) {
        await client.query('BEGIN');
        await client.query(await readFile(path.join(projectRoot, 'migrations', filename), 'utf8'));
        await client.query('INSERT INTO migrations_log(filename) VALUES ($1)', [filename]);
        await client.query('COMMIT');
      }
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  } else if (migrationPath === 'minimal') {
    await pool.query(`
    CREATE TABLE clients (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      name TEXT NOT NULL,
      document TEXT
    );
    CREATE TABLE legal_processes (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      process_number TEXT NOT NULL UNIQUE,
      client_name TEXT,
      client_id UUID REFERENCES clients(id),
      partner_id UUID REFERENCES clients(id),
      status TEXT NOT NULL DEFAULT 'ATIVO',
      tags JSONB NOT NULL DEFAULT '[]'
    );
    CREATE TABLE background_jobs (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      queue VARCHAR(100) NOT NULL,
      status VARCHAR(20) NOT NULL DEFAULT 'pending',
      payload JSONB NOT NULL DEFAULT '{}',
      result JSONB,
      error TEXT,
      lease_token UUID,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE chart_of_accounts (
      id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
      code TEXT NOT NULL,
      name TEXT NOT NULL,
      type TEXT NOT NULL,
      parent_id UUID REFERENCES chart_of_accounts(id)
    );
    CREATE FUNCTION fail_selected_process_import() RETURNS trigger AS $$
    BEGIN
      IF NEW.process_number = 'ROLLBACK-TEST' THEN
        RAISE EXCEPTION 'intentional database failure for rollback test';
      END IF;
      RETURN NEW;
    END;
    $$ LANGUAGE plpgsql;
    CREATE TRIGGER fail_selected_process_import
      BEFORE INSERT ON legal_processes
      FOR EACH ROW EXECUTE FUNCTION fail_selected_process_import();
    `);
  } else {
    throw new Error(`Caminho de migração desconhecido: ${migrationPath}`);
  }

  const app = express();
  app.use('/api/import/upload', express.raw({ type: XLSX_MIME, limit: '22mb' }));
  app.use(express.json({ limit: '1mb' }));
  app.use('/api/import', (req, _res, next) => {
    req.currentUser = USER;
    next();
  });
  app.use('/api/import', createDataImportRoutes(pool, {
    verifyStepUpToken: () => 'disposable-postgres-test',
    consumeStepUp: () => {},
    logAudit: async () => {},
    ...routeDependencies,
  }));
  server = createServer(app);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));

  return { baseUrl: `http://127.0.0.1:${server.address().port}`, pool };
}

test('a exportação XLSX resolve todos os vínculos virtuais configurados após migrações reais', {
  timeout: 120_000,
}, async t => {
  const { baseUrl, pool } = await createDisposablePostgres(t, {}, { migrationPath: 'fresh' });
  const schemaResponse = await fetch(`${baseUrl}/api/import/schema`);
  assert.equal(schemaResponse.status, 200);
  const { tables } = await schemaResponse.json();

  const referencedColumns = new Map();
  const addReference = (table, column) => {
    if (!referencedColumns.has(table)) referencedColumns.set(table, new Set());
    referencedColumns.get(table).add(column);
  };
  const unitScopedTables = new Set(['collaborators', 'admissions', 'legal_processes', 'financial_titles']);
  for (const table of tables) {
    addReference(table.key, 'id');
    if (unitScopedTables.has(table.key)) addReference(table.key, 'unit_id');
    for (const field of table.fields) {
      const source = field.profileSource || field.exportSource;
      if (source) {
        addReference(table.key, source.fkColumn);
        addReference('clients', 'id');
        addReference('clients', source.column);
        continue;
      }
      if (!field.virtual) {
        addReference(table.key, field.key);
        continue;
      }
      const link = table.parentLinks.find(candidate => candidate.childKey === field.key);
      assert.ok(link, `${table.key}.${field.key} must have a configured export join`);
      addReference(table.key, link.fkColumn);
      addReference(link.parentTable, 'id');
      if (link.parentKey) addReference(link.parentTable, link.parentKey);
      if (link.parentKeySql) {
        const columns = link.parentKeySql.match(/[a-z_][a-z0-9_]*/gi) || [];
        for (const column of columns.filter(name => !['coalesce', 'nullif'].includes(name.toLowerCase()))) {
          addReference(link.parentTable, column);
        }
      }
    }
  }

  const catalog = await pool.query(
    `SELECT table_name, column_name
       FROM information_schema.columns
      WHERE table_schema = current_schema()
        AND table_name = ANY($1::text[])`,
    [[...referencedColumns.keys()]],
  );
  const installedColumns = new Map();
  for (const { table_name: tableName, column_name: columnName } of catalog.rows) {
    if (!installedColumns.has(tableName)) installedColumns.set(tableName, new Set());
    installedColumns.get(tableName).add(columnName);
  }
  const missingColumns = [];
  for (const [tableName, columns] of referencedColumns) {
    for (const columnName of columns) {
      if (!installedColumns.get(tableName)?.has(columnName)) {
        missingColumns.push(`${tableName}.${columnName}`);
      }
    }
  }
  assert.deepEqual(
    missingColumns,
    [],
    `fresh migrations must create every physical export field and join column; missing: ${missingColumns.join(', ')}`,
  );

  const unitId = USER.currentUnitId;
  const otherUnitId = '10000000-0000-4000-8000-000000000003';
  const clientId = '10000000-0000-4000-8000-000000000004';
  const titularClientId = '10000000-0000-4000-8000-000000000005';
  const partnerClientId = '10000000-0000-4000-8000-000000000008';
  const bankId = '10000000-0000-4000-8000-000000000009';
  const collaboratorId = '10000000-0000-4000-8000-000000000010';
  const seriesId = '10000000-0000-4000-8000-000000000011';
  const modalityId = '10000000-0000-4000-8000-000000000012';
  const measurementUnitId = '10000000-0000-4000-8000-000000000013';
  const departmentId = '10000000-0000-4000-8000-000000000014';
  const bankAccountId = '10000000-0000-4000-8000-000000000015';
  const documentTypeId = '10000000-0000-4000-8000-000000000016';
  const bearerId = '10000000-0000-4000-8000-000000000017';
  const parentCategoryId = '10000000-0000-4000-8000-000000000018';
  const childCategoryId = '10000000-0000-4000-8000-000000000019';
  const parentTitleId = '10000000-0000-4000-8000-000000000020';
  const childTitleId = '10000000-0000-4000-8000-000000000021';

  await pool.query(
    `INSERT INTO companies (id, razao_social, nome_fantasia)
     VALUES ($1, 'Empresa de Teste', 'Unidade Exportada'),
            ($2, 'Outra Empresa de Teste', 'Unidade Fora do Escopo')`,
    [unitId, otherUnitId],
  );
  await pool.query(
    `INSERT INTO clients (id, name, document)
     VALUES ($1, 'Cliente da Admissão', '11111111111'),
            ($2, 'Cliente Titular da Admissão', '22222222222'),
            ($3, 'Cliente Parceiro Exportado', '33333333333')`,
    [clientId, titularClientId, partnerClientId],
  );
  await pool.query(
    `INSERT INTO banks (id, name, febraban_code)
     VALUES ($1, 'Banco Exportado', '999')`,
    [bankId],
  );
  await pool.query(
    `INSERT INTO departments (id, name) VALUES ($1, 'Departamento Exportado')`,
    [departmentId],
  );
  await pool.query(
    `INSERT INTO modalities (id, type, description)
     VALUES ($1, 'FINANCIAMENTO', 'Modalidade Exportada')`,
    [modalityId],
  );
  await pool.query(
    `INSERT INTO measurement_units (id, name) VALUES ($1, 'Unidade de Medida Exportada')`,
    [measurementUnitId],
  );
  await pool.query(
    `INSERT INTO series (id, sigla, description) VALUES ($1, 'EXP', 'Série Exportada')`,
    [seriesId],
  );
  await pool.query(
    `INSERT INTO bank_accounts (id, description, bank_id)
     VALUES ($1, 'Conta Bancária Exportada', $2)`,
    [bankAccountId, bankId],
  );
  await pool.query(
    `INSERT INTO document_types (id, description) VALUES ($1, 'Tipo de Documento Exportado')`,
    [documentTypeId],
  );
  await pool.query(
    `INSERT INTO bearers (id, code, name, associated_bank_account_id)
     VALUES ($1, 'PORT-EXP', 'Portador Exportado', $2)`,
    [bearerId, bankAccountId],
  );
  await pool.query(
    `INSERT INTO collaborators (id, name, unit_id, department_id)
     VALUES ($1, 'Colaborador Exportado', $2, $3)`,
    [collaboratorId, unitId, departmentId],
  );
  await pool.query(
    `INSERT INTO chart_of_accounts (id, code, name, type, is_analytical)
     VALUES ($1, '9.1', 'Categoria-pai Exportada', 'RECEITA', FALSE)`,
    [parentCategoryId],
  );
  await pool.query(
    `INSERT INTO admissions (
       id, unit_id, client_id, client_name, titular_client_id, bank_id,
       collaborator_id, series_id, modality_id, contract_number, status
     ) VALUES
       ('10000000-0000-4000-8000-000000000006', $1, $4, $3, $5, $6, $7, $8, $9, 'CONTRATO-EXPORTADO', 'PENDENTE'),
       ('10000000-0000-4000-8000-000000000007', $2, $4, $3, $5, $6, $7, $8, $9, 'CONTRATO-OUTRA-UNIDADE', 'PENDENTE')`,
    [unitId, otherUnitId, 'Cliente da Admissão', clientId, titularClientId,
      bankId, collaboratorId, seriesId, modalityId],
  );
  await pool.query(
    `INSERT INTO chart_of_accounts (id, code, name, type, parent_id, is_analytical)
     VALUES ($1, '9.1.1', 'Categoria filha Exportada', 'RECEITA', $2, TRUE)`,
    [childCategoryId, parentCategoryId],
  );
  await pool.query(
    `INSERT INTO bank_contacts (bank_id, name, sector)
     VALUES ($1, 'Contato Bancário Exportado', 'Relacionamento')`,
    [bankId],
  );
  await pool.query(
    `INSERT INTO bank_services (bank_id, name, modality_id, negotiation_percentage)
     VALUES ($1, 'Serviço Bancário Exportado', $2, 12.5)`,
    [bankId, modalityId],
  );
  await pool.query(
    `INSERT INTO products (description, unit_id) VALUES ('Produto Exportado', $1)`,
    [measurementUnitId],
  );
  await pool.query(
    `INSERT INTO legal_processes (
       process_number, unit_id, client_id, client_name, partner_id, admission_id
     ) VALUES ('PROCESSO-EXPORTADO', $1, $2, 'Cliente da Admissão', $3, $4)`,
    [unitId, clientId, partnerClientId, '10000000-0000-4000-8000-000000000006'],
  );
  await pool.query(
    `INSERT INTO financial_titles (
       id, title_scope, value, document_number
     ) VALUES ($1, 'RECEBER', 10, 'TITULO-PAI-EXPORTADO')`,
    [parentTitleId],
  );
  await pool.query(
    `INSERT INTO financial_titles (
       id, title_scope, value, document_number, client_name, category_id, document_type_id,
       bearer_id, department_id, unit_id, seller_id, bank_account_id,
       assigned_collaborator_id, admission_id, parent_id
     ) VALUES (
       $1, 'RECEBER', 20, 'TITULO-FILHO-EXPORTADO', 'Cliente da Admissão', $2, $3, $4, $5, $6,
       $7, $8, $7, '10000000-0000-4000-8000-000000000006', $9
     )`,
    [childTitleId, childCategoryId, documentTypeId, bearerId, departmentId, unitId,
      collaboratorId, bankAccountId, parentTitleId],
  );

  const response = await fetch(`${baseUrl}/api/import/export`, { method: 'POST' });
  if (response.status !== 200) assert.fail(`export failed: ${await response.text()}`);
  assert.match(response.headers.get('content-type'), new RegExp(XLSX_MIME));

  const exportedBuffer = Buffer.from(await response.arrayBuffer());
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(exportedBuffer);
  const sheet = workbook.getWorksheet('Admissões');
  assert.ok(sheet, 'export should contain the Admissões worksheet');
  const headers = sheet.getRow(1).values.slice(1);
  const rows = Array.from({ length: sheet.rowCount - 1 }, (_, index) => {
    const row = sheet.getRow(index + 2);
    return Object.fromEntries(headers.map((header, column) => [header, row.getCell(column + 1).value]));
  });

  assert.equal(rows.length, 1, 'export should only include admissions from the active unit');
  assert.equal(rows[0]['Número do Contrato'], 'CONTRATO-EXPORTADO');
  assert.equal(rows[0].Unidade, 'Unidade Exportada');
  assert.equal(rows[0]['Nome do Cliente'], 'Cliente da Admissão');
  assert.equal(rows[0]['CPF/CNPJ do Cliente'], '11111111111');
  assert.equal(rows[0]['Cliente Titular'], 'Cliente Titular da Admissão');
  assert.equal(rows[0]['CPF/CNPJ do Titular'], '22222222222');

  const expectedVirtualValues = {
    collaborators: {
      unit_name: 'Unidade Exportada',
      department_name: 'Departamento Exportado',
    },
    bank_contacts: {
      bank_name: 'Banco Exportado',
      bank_febraban_code: '999',
    },
    bank_services: {
      bank_name: 'Banco Exportado',
      bank_febraban_code: '999',
      modality_name: 'Modalidade Exportada',
    },
    products: {
      measurement_unit_name: 'Unidade de Medida Exportada',
    },
    chart_of_accounts: {
      parent_code: '9.1',
    },
    admissions: {
      bank_name: 'Banco Exportado',
      client_document: '11111111111',
      collaborator_name: 'Colaborador Exportado',
      series_name: 'Série Exportada',
      modality_name: 'Modalidade Exportada',
      unit_name: 'Unidade Exportada',
      titular_client_name: 'Cliente Titular da Admissão',
      titular_client_document: '22222222222',
    },
    legal_processes: {
      unit_name: 'Unidade Exportada',
      partner_name: 'Cliente Parceiro Exportado',
      admission_contract_number: 'CONTRATO-EXPORTADO',
    },
    financial_titles: {
      category_code: '9.1.1',
      document_type_name: 'Tipo de Documento Exportado',
      bearer_name: 'Portador Exportado',
      department_name: 'Departamento Exportado',
      unit_name: 'Unidade Exportada',
      seller_name: 'Colaborador Exportado',
      bank_account_name: 'Conta Bancária Exportada',
      assigned_collaborator_name: 'Colaborador Exportado',
      admission_contract_number: 'CONTRATO-EXPORTADO',
      parent_document_number: 'TITULO-PAI-EXPORTADO',
    },
  };
  const fixtureIdentity = {
    collaborators: { fieldKey: 'name', label: 'Nome', value: 'Colaborador Exportado' },
    bank_contacts: { fieldKey: 'name', label: 'Nome do Contato', value: 'Contato Bancário Exportado' },
    bank_services: { fieldKey: 'name', label: 'Nome do Serviço', value: 'Serviço Bancário Exportado' },
    products: { fieldKey: 'description', label: 'Descrição', value: 'Produto Exportado' },
    chart_of_accounts: { fieldKey: 'code', label: 'Código', value: '9.1.1' },
    admissions: { fieldKey: 'contract_number', label: 'Número do Contrato', value: 'CONTRATO-EXPORTADO' },
    legal_processes: { fieldKey: 'process_number', label: 'Número do Processo', value: 'PROCESSO-EXPORTADO' },
    financial_titles: { fieldKey: 'document_number', label: 'Nº do Documento', value: 'TITULO-FILHO-EXPORTADO' },
  };
  const virtualTables = tables
    .filter(table => table.fields.some(field => field.virtual && !field.profileSource))
    .map(table => table.key)
    .sort();
  assert.deepEqual(virtualTables, Object.keys(expectedVirtualValues).sort(),
    'the PostgreSQL export test must cover every table with virtual fields');

  const importMappings = {};
  for (const tableKey of virtualTables) {
    const table = tables.find(candidate => candidate.key === tableKey);
    const sheet = workbook.getWorksheet(table.label);
    assert.ok(sheet, `${table.key} export should contain the ${table.label} worksheet`);
    const headers = sheet.getRow(1).values.slice(1);
    const identity = fixtureIdentity[table.key];
    const identityColumn = headers.indexOf(identity.label) + 1;
    assert.ok(identityColumn > 0, `${table.key} should export its fixture identity column`);
    const matchingRows = [];
    for (let rowNumber = 2; rowNumber <= sheet.rowCount; rowNumber += 1) {
      if (sheet.getRow(rowNumber).getCell(identityColumn).value === identity.value) {
        matchingRows.push(sheet.getRow(rowNumber));
      }
    }
    assert.equal(matchingRows.length, 1, `${table.key} should export its related fixture exactly once`);
    const exportedRow = Object.fromEntries(headers.map((header, index) => [
      header,
      matchingRows[0].getCell(index + 1).value,
    ]));
    const virtualFields = table.fields.filter(field => field.virtual && !field.profileSource);
    assert.deepEqual(
      virtualFields.map(field => field.key).sort(),
      Object.keys(expectedVirtualValues[table.key]).sort(),
      `${table.key} should assert each configured virtual field`,
    );
    importMappings[table.key] = table.fields.map(field => ({
      fieldKey: field.key,
      sheetColumn: field.label,
    }));
    for (const field of table.fields) {
      assert.ok(headers.includes(field.label),
        `${table.key}.${field.key} should be included in the export/import mapping`);
    }
    for (const field of virtualFields) {
      assert.equal(
        exportedRow[field.label],
        expectedVirtualValues[table.key][field.key],
        `${table.key}.${field.key} should export the related value`,
      );
    }
  }

  const importedVirtualValues = await parseXlsxImport(exportedBuffer, virtualTables, importMappings);
  const expectedImportTables = [...new Set(virtualTables)].sort();
  assert.deepEqual(importedVirtualValues.map(group => group.table).sort(), expectedImportTables);
  for (const group of importedVirtualValues.filter(item => virtualTables.includes(item.table))) {
    const identity = fixtureIdentity[group.table];
    const matchingRows = group.rows.filter(row => row[identity.fieldKey] === identity.value);
    assert.equal(matchingRows.length, 1, `${group.table} relation values should be readable by the importer`);
    for (const [fieldKey, expectedValue] of Object.entries(expectedVirtualValues[group.table])) {
      assert.equal(matchingRows[0][fieldKey], expectedValue,
        `${group.table} importer should preserve ${fieldKey}`);
    }
  }

  const fixtureForeignKeys = {
    collaborators: {
      identity: ['name', 'Colaborador Exportado'],
      foreignKeys: { unit_id: unitId, department_id: departmentId },
    },
    bank_contacts: {
      identity: ['name', 'Contato Bancário Exportado'],
      filters: { name: 'Contato Bancário Exportado', bank_id: bankId },
      foreignKeys: { bank_id: bankId },
    },
    bank_services: {
      identity: ['name', 'Serviço Bancário Exportado'],
      filters: { name: 'Serviço Bancário Exportado', bank_id: bankId },
      foreignKeys: { bank_id: bankId, modality_id: modalityId },
    },
    products: {
      identity: ['description', 'Produto Exportado'],
      foreignKeys: { unit_id: measurementUnitId },
    },
    chart_of_accounts: {
      identity: ['code', '9.1.1'],
      foreignKeys: { parent_id: parentCategoryId },
    },
    admissions: {
      identity: ['contract_number', 'CONTRATO-EXPORTADO'],
      foreignKeys: {
        bank_id: bankId,
        collaborator_id: collaboratorId,
        series_id: seriesId,
        modality_id: modalityId,
        unit_id: unitId,
        titular_client_id: titularClientId,
      },
    },
    legal_processes: {
      identity: ['process_number', 'PROCESSO-EXPORTADO'],
      foreignKeys: {
        unit_id: unitId,
        partner_id: partnerClientId,
        admission_id: '10000000-0000-4000-8000-000000000006',
      },
    },
    financial_titles: {
      identity: ['document_number', 'TITULO-FILHO-EXPORTADO'],
      foreignKeys: {
        category_id: childCategoryId,
        document_type_id: documentTypeId,
        bearer_id: bearerId,
        department_id: departmentId,
        unit_id: unitId,
        seller_id: collaboratorId,
        bank_account_id: bankAccountId,
        assigned_collaborator_id: collaboratorId,
        admission_id: '10000000-0000-4000-8000-000000000006',
        parent_id: parentTitleId,
      },
    },
  };

  // Clear fixture FK values after export so successful validation and reimport
  // must resolve the exported labels rather than inheriting the stored IDs.
  const decoyBankId = '10000000-0000-4000-8000-000000000022';
  await pool.query(
    'INSERT INTO banks (id, name) VALUES ($1, $2)',
    [decoyBankId, 'Banco Divergente da Reimportação'],
  );
  await pool.query(
    'UPDATE collaborators SET unit_id = NULL, department_id = NULL WHERE id = $1',
    [collaboratorId],
  );
  await pool.query(
    'UPDATE bank_contacts SET bank_id = $2 WHERE name = $1',
    ['Contato Bancário Exportado', decoyBankId],
  );
  await pool.query(
    'UPDATE bank_services SET bank_id = $2, modality_id = NULL WHERE name = $1',
    ['Serviço Bancário Exportado', decoyBankId],
  );
  await pool.query('UPDATE products SET unit_id = NULL WHERE description = $1', ['Produto Exportado']);
  await pool.query('UPDATE chart_of_accounts SET parent_id = NULL WHERE id = $1', [childCategoryId]);
  await pool.query(
    `UPDATE admissions
        SET bank_id = NULL, collaborator_id = NULL, series_id = NULL,
            modality_id = NULL, unit_id = NULL, titular_client_id = NULL
      WHERE id = $1`,
    ['10000000-0000-4000-8000-000000000006'],
  );
  await pool.query(
    'UPDATE legal_processes SET unit_id = NULL, partner_id = NULL, admission_id = NULL WHERE process_number = $1',
    ['PROCESSO-EXPORTADO'],
  );
  await pool.query(
    `UPDATE financial_titles
        SET category_id = NULL, document_type_id = NULL, bearer_id = NULL,
            department_id = NULL, unit_id = NULL, seller_id = NULL,
            bank_account_id = NULL, assigned_collaborator_id = NULL,
            admission_id = NULL, parent_id = NULL
      WHERE id = $1`,
    [childTitleId],
  );

  const validationResponse = await fetch(`${baseUrl}/api/import/validate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ groups: importedVirtualValues }),
  });
  assert.equal(validationResponse.status, 200, await validationResponse.clone().text());
  const validation = await validationResponse.json();
  assert.deepEqual(validation.groups.map(group => group.table).sort(), expectedImportTables);
  for (const group of validation.groups) {
    assert.equal(
      group.error,
      0,
      `${group.table} exported labels should resolve during PostgreSQL validation: ${JSON.stringify(group.rows.filter(row => row.status === 'error'))}`,
    );
    assert.ok(group.rows.length > 0, `${group.table} should validate exported rows`);
    assert.ok(group.rows.every(row => row.status !== 'error'),
      `${group.table} should not report unresolved exported links`);
  }

  const reimportResponse = await fetch(`${baseUrl}/api/import/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      stepUpToken: 'test-token',
      groups: importedVirtualValues,
      duplicateStrategy: 'update',
    }),
  });
  assert.equal(reimportResponse.status, 200, await reimportResponse.clone().text());
  const reimport = await reimportResponse.json();
  assert.equal(reimport.inconsistent, 0, JSON.stringify(reimport));

  for (const tableKey of virtualTables) {
    const fixture = fixtureForeignKeys[tableKey];
    const [identityColumn, identityValue] = fixture.identity;
    const filters = Object.entries(fixture.filters || { [identityColumn]: identityValue });
    const foreignKeyColumns = Object.keys(fixture.foreignKeys);
    const whereClause = filters.map(([column], index) => `${column} = $${index + 1}`).join(' AND ');
    const result = await pool.query(
      `SELECT ${foreignKeyColumns.join(', ')} FROM ${tableKey} WHERE ${whereClause}`,
      filters.map(([, value]) => value),
    );
    assert.equal(result.rows.length, 1, `${tableKey} reimport should restore its expected relation`);
    assert.deepEqual(
      result.rows[0],
      fixture.foreignKeys,
      `${tableKey} exported labels should resolve to their original PostgreSQL records`,
    );
  }

  for (const fantasyName of ['', null]) {
    await pool.query('UPDATE companies SET nome_fantasia = $2 WHERE id = $1', [unitId, fantasyName]);

    const fallbackResponse = await fetch(`${baseUrl}/api/import/export`, { method: 'POST' });
    if (fallbackResponse.status !== 200) {
      assert.fail(`export with fantasy name ${JSON.stringify(fantasyName)} failed: ${await fallbackResponse.text()}`);
    }
    assert.match(fallbackResponse.headers.get('content-type'), new RegExp(XLSX_MIME));

    const fallbackWorkbook = new ExcelJS.Workbook();
    await fallbackWorkbook.xlsx.load(Buffer.from(await fallbackResponse.arrayBuffer()));
    const fallbackSheet = fallbackWorkbook.getWorksheet('Admissões');
    assert.ok(fallbackSheet, 'export should contain the Admissões worksheet');
    const fallbackHeaders = fallbackSheet.getRow(1).values.slice(1);
    const fallbackUnitColumn = fallbackHeaders.indexOf('Unidade') + 1;
    assert.ok(fallbackUnitColumn > 0, 'export should contain the Unidade column');
    assert.equal(
      fallbackSheet.getRow(2).getCell(fallbackUnitColumn).value,
      'Empresa de Teste',
      `the legal company name should be exported when the fantasy name is ${JSON.stringify(fantasyName)}`,
    );
  }
});

test('a exportação PostgreSQL mantém os vínculos e a ordem das admissões entre páginas', {
  timeout: 120_000,
}, async t => {
  const { baseUrl, pool } = await createDisposablePostgres(t, {}, { migrationPath: 'fresh' });
  const unitId = USER.currentUnitId;
  const otherUnitId = '10000000-0000-4000-8000-000000000003';
  const unitName = 'Unidade ativa da paginação';
  const otherUnitName = 'Unidade fora do escopo';
  const fixtureId = (prefix, sequence) =>
    `${prefix}-0000-4000-8000-${String(sequence).padStart(12, '0')}`;
  const fixtureRows = Array.from({ length: 1020 }, (_, index) => {
    const sequence = index + 1;
    const isOtherUnit = sequence % 102 === 0;
    return {
      clientId: fixtureId('30000000', sequence),
      clientName: `Cliente vinculado ${String(sequence).padStart(4, '0')}`,
      admissionId: fixtureId('40000000', sequence),
      contractNumber: `Contrato paginado ${String(sequence).padStart(4, '0')}`,
      unitId: isOtherUnit ? otherUnitId : unitId,
    };
  });
  const expectedRows = fixtureRows.filter(row => row.unitId === unitId);
  assert.equal(expectedRows.length, 1010, 'active-unit admissions should require two export pages');
  assert.notEqual(expectedRows[999].clientName, expectedRows[1000].clientName,
    'the last row on the first page and first row on the next page must link to different clients');

  await pool.query(
    `INSERT INTO companies (id, razao_social, nome_fantasia)
     VALUES ($1, $2, $2), ($3, $4, $4)`,
    [unitId, unitName, otherUnitId, otherUnitName],
  );
  await pool.query(
    `INSERT INTO clients (id, name)
     SELECT fixture.id, fixture.name
       FROM UNNEST($1::uuid[], $2::text[]) AS fixture(id, name)`,
    [
      fixtureRows.map(row => row.clientId),
      fixtureRows.map(row => row.clientName),
    ],
  );
  await pool.query(
    `INSERT INTO admissions (id, unit_id, titular_client_id, client_name, contract_number, status)
     SELECT fixture.id, fixture.unit_id, fixture.client_id, fixture.client_name,
            fixture.contract_number, 'PENDENTE'
       FROM UNNEST($1::uuid[], $2::text[], $3::uuid[], $4::text[], $5::text[])
         AS fixture(id, unit_id, client_id, client_name, contract_number)`,
    [
      fixtureRows.map(row => row.admissionId),
      fixtureRows.map(row => row.unitId),
      fixtureRows.map(row => row.clientId),
      fixtureRows.map(row => row.clientName),
      fixtureRows.map(row => row.contractNumber),
    ],
  );

  const response = await fetch(`${baseUrl}/api/import/export`, { method: 'POST' });
  if (response.status !== 200) assert.fail(`export failed: ${await response.text()}`);
  assert.match(response.headers.get('content-type'), new RegExp(XLSX_MIME));

  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(Buffer.from(await response.arrayBuffer()));
  const sheet = workbook.getWorksheet('Admissões');
  assert.ok(sheet, 'export should contain the Admissões worksheet');
  const headers = sheet.getRow(1).values.slice(1);
  const contractColumn = headers.indexOf('Número do Contrato') + 1;
  const linkedClientColumn = headers.indexOf('Cliente Titular') + 1;
  const unitColumn = headers.indexOf('Unidade') + 1;
  assert.ok(contractColumn > 0, 'export should include admission contract numbers');
  assert.ok(linkedClientColumn > 0, 'export should include the linked titular client');
  assert.ok(unitColumn > 0, 'export should include the unit name');

  const exportedRows = Array.from({ length: sheet.rowCount - 1 }, (_, index) => {
    const row = sheet.getRow(index + 2);
    return {
      contractNumber: row.getCell(contractColumn).value,
      linkedClientName: row.getCell(linkedClientColumn).value,
      unitName: row.getCell(unitColumn).value,
    };
  });
  assert.equal(exportedRows.length, expectedRows.length,
    'export should include only active-unit admissions and all active-unit pages');
  assert.deepEqual(
    exportedRows.map(row => row.contractNumber),
    expectedRows.map(row => row.contractNumber),
    'admission rows should retain their PostgreSQL ID order across the page boundary',
  );
  assert.deepEqual(
    exportedRows.map(row => row.linkedClientName),
    expectedRows.map(row => row.clientName),
    'each admission should retain its own distinct linked client on both pages',
  );
  assert.deepEqual(
    exportedRows.map(row => row.unitName),
    Array(expectedRows.length).fill(unitName),
    'the export should keep the active-unit scope and exclude other-unit admissions',
  );
  assert.deepEqual(
    exportedRows.slice(998, 1002).map(row => [row.contractNumber, row.linkedClientName]),
    expectedRows.slice(998, 1002).map(row => [row.contractNumber, row.clientName]),
    'related values and order should be correct immediately before and after the page boundary',
  );
});

test('a exportação PostgreSQL preserva a razão social no XLSX e no parser quando o nome fantasia está vazio ou nulo', {
  timeout: 120_000,
}, async t => {
  const { baseUrl, pool } = await createDisposablePostgres(t, {}, { migrationPath: 'fresh' });
  const unitId = USER.currentUnitId;
  const legalName = 'Razão Social de Fallback da Exportação';
  const fixtures = [
    {
      table: 'collaborators',
      sheet: 'Colaboradores',
      identityLabel: 'Nome',
      identityValue: 'Colaborador com Unidade de Fallback',
      insert: () => pool.query(
        'INSERT INTO collaborators (id, name, unit_id) VALUES ($1, $2, $3)',
        ['10000000-0000-4000-8000-000000000023', 'Colaborador com Unidade de Fallback', unitId],
      ),
    },
    {
      table: 'legal_processes',
      sheet: 'Processos Jurídicos',
      identityLabel: 'Número do Processo',
      identityValue: 'PROCESSO-UNIDADE-FALLBACK',
      insert: () => pool.query(
        'INSERT INTO legal_processes (process_number, unit_id) VALUES ($1, $2)',
        ['PROCESSO-UNIDADE-FALLBACK', unitId],
      ),
    },
    {
      table: 'financial_titles',
      sheet: 'Títulos Financeiros',
      identityLabel: 'Nº do Documento',
      identityValue: 'TITULO-UNIDADE-FALLBACK',
      insert: () => pool.query(
        `INSERT INTO financial_titles (title_scope, value, document_number, unit_id)
         VALUES ('PAGAR', 125, 'TITULO-UNIDADE-FALLBACK', $1)`,
        [unitId],
      ),
    },
  ];

  await pool.query(
    'INSERT INTO companies (id, razao_social, nome_fantasia) VALUES ($1, $2, $3)',
    [unitId, legalName, 'Nome Fantasia Inicial'],
  );
  for (const fixture of fixtures) await fixture.insert();

  const schemaResponse = await fetch(`${baseUrl}/api/import/schema`);
  assert.equal(schemaResponse.status, 200, await schemaResponse.clone().text());
  const { tables } = await schemaResponse.json();
  const tableKeys = fixtures.map(fixture => fixture.table);
  const mappingByTable = Object.fromEntries(tableKeys.map(tableKey => {
    const table = tables.find(candidate => candidate.key === tableKey);
    assert.ok(table, `import schema should include ${tableKey}`);
    return [tableKey, table.fields.map(field => ({
      fieldKey: field.key,
      sheetColumn: field.label,
    }))];
  }));

  for (const fantasyName of ['', null]) {
    await pool.query('UPDATE companies SET nome_fantasia = $2 WHERE id = $1', [unitId, fantasyName]);

    const response = await fetch(`${baseUrl}/api/import/export`, { method: 'POST' });
    if (response.status !== 200) {
      assert.fail(`export with fantasy name ${JSON.stringify(fantasyName)} failed: ${await response.text()}`);
    }
    assert.match(response.headers.get('content-type'), new RegExp(XLSX_MIME));
    const exportedBuffer = Buffer.from(await response.arrayBuffer());
    const workbook = new ExcelJS.Workbook();
    await workbook.xlsx.load(exportedBuffer);

    for (const fixture of fixtures) {
      const sheet = workbook.getWorksheet(fixture.sheet);
      assert.ok(sheet, `export should contain the ${fixture.sheet} worksheet`);
      const headers = sheet.getRow(1).values.slice(1);
      const identityColumn = headers.indexOf(fixture.identityLabel) + 1;
      const unitColumn = headers.indexOf('Unidade') + 1;
      assert.ok(identityColumn > 0, `${fixture.sheet} should contain its identity column`);
      assert.ok(unitColumn > 0, `${fixture.sheet} should contain the Unidade column`);
      const matchingRows = [];
      for (let rowNumber = 2; rowNumber <= sheet.rowCount; rowNumber += 1) {
        if (sheet.getRow(rowNumber).getCell(identityColumn).value === fixture.identityValue) {
          matchingRows.push(sheet.getRow(rowNumber));
        }
      }
      assert.equal(matchingRows.length, 1, `${fixture.sheet} should export the fixture exactly once`);
      assert.equal(
        matchingRows[0].getCell(unitColumn).value,
        legalName,
        `${fixture.sheet} should export the legal company name when the fantasy name is ${JSON.stringify(fantasyName)}`,
      );
    }

    const parsedGroups = await parseXlsxImport(exportedBuffer, tableKeys, mappingByTable);
    assert.deepEqual(parsedGroups.map(group => group.table).sort(), [...tableKeys].sort());
    for (const fixture of fixtures) {
      const parsedGroup = parsedGroups.find(group => group.table === fixture.table);
      const parsedRow = parsedGroup.rows.find(row => {
        const identityKey = mappingByTable[fixture.table]
          .find(mapping => mapping.sheetColumn === fixture.identityLabel)?.fieldKey;
        return row[identityKey] === fixture.identityValue;
      });
      assert.ok(parsedRow, `${fixture.table} parser should preserve the exported fixture`);
      assert.equal(
        parsedRow.unit_name,
        legalName,
        `${fixture.table} parser should preserve the fallback unit name for ${JSON.stringify(fantasyName)}`,
      );
    }
  }
});

test('a importação PostgreSQL vincula admissões pela razão social quando o nome fantasia está vazio ou nulo', {
  timeout: 120_000,
}, async t => {
  const { baseUrl, pool } = await createDisposablePostgres(t, {}, { migrationPath: 'fresh' });
  const unitId = USER.currentUnitId;
  const legalName = 'Razão Social da Unidade Importada';
  await pool.query(
    'INSERT INTO companies (id, razao_social, nome_fantasia) VALUES ($1, $2, $3)',
    [unitId, legalName, ''],
  );

  for (const [fantasyName, contractNumber] of [
    ['', 'CONTRATO-UNIDADE-FANTASIA-VAZIA'],
    [null, 'CONTRATO-UNIDADE-FANTASIA-NULL'],
  ]) {
    await pool.query(
      'UPDATE companies SET nome_fantasia = $2 WHERE id = $1',
      [unitId, fantasyName],
    );
    const response = await fetch(`${baseUrl}/api/import/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        stepUpToken: 'test-token',
        groups: [{
          table: 'admissions',
          rows: [{
            contract_number: contractNumber,
            unit_name: legalName,
          }],
        }],
      }),
    });
    assert.equal(response.status, 200, await response.clone().text());
    const result = await response.json();
    assert.equal(result.inserted, 1, JSON.stringify(result));
    assert.equal(result.inconsistent, 0, JSON.stringify(result));

    const importedAdmission = await pool.query(
      'SELECT unit_id::text AS unit_id FROM admissions WHERE contract_number = $1',
      [contractNumber],
    );
    assert.deepEqual(
      importedAdmission.rows,
      [{ unit_id: unitId }],
      `a razão social deve resolver para o unit_id correto com nome fantasia ${JSON.stringify(fantasyName)}`,
    );
  }
});

test('reimportar uma admissão por contrato não altera sua unidade ao atualizar ou ignorar', {
  timeout: 120_000,
}, async t => {
  const { baseUrl, pool } = await createDisposablePostgres(t, {}, { migrationPath: 'fresh' });
  const originalUnitId = USER.currentUnitId;
  const otherUnitId = '10000000-0000-4000-8000-000000000099';
  const contractNumber = 'CONTRATO-REIMPORTACAO-UNIDADE';
  const originalUnitName = 'Unidade Original da Admissão';
  const otherUnitName = 'Outra Unidade da Reimportação';

  await pool.query(
    'INSERT INTO companies (id, razao_social, nome_fantasia) VALUES ($1, $2, $3), ($4, $5, $6)',
    [originalUnitId, originalUnitName, originalUnitName, otherUnitId, otherUnitName, otherUnitName],
  );
  await pool.query(
    `INSERT INTO admissions (unit_id, contract_number, status)
     VALUES ($1, $2, $3)`,
    [originalUnitId, contractNumber, 'PENDENTE'],
  );

  const execute = async (decision, status) => {
    const response = await fetch(`${baseUrl}/api/import/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        stepUpToken: 'test-token',
        duplicateStrategy: 'update',
        rowDecisions: { admissions: { 0: decision } },
        groups: [{
          table: 'admissions',
          rows: [{
            contract_number: contractNumber,
            status,
            unit_name: otherUnitName,
          }],
        }],
      }),
    });
    assert.equal(response.status, 200, await response.clone().text());
    return response.json();
  };

  const updated = await execute('update', 'APROVADA');
  assert.equal(updated.total, 1, JSON.stringify(updated));
  assert.equal(updated.inserted, 0, JSON.stringify(updated));
  assert.equal(updated.updated, 1, JSON.stringify(updated));
  assert.equal(updated.ignored, 0, JSON.stringify(updated));
  assert.equal(updated.inconsistent, 0, JSON.stringify(updated));
  assert.deepEqual(
    { inserted: updated.groups[0].inserted, updated: updated.groups[0].updated,
      ignored: updated.groups[0].ignored, inconsistent: updated.groups[0].inconsistent },
    { inserted: 0, updated: 1, ignored: 0, inconsistent: 0 },
  );

  const ignored = await execute('ignore', 'REPROVADA');
  assert.equal(ignored.total, 1, JSON.stringify(ignored));
  assert.equal(ignored.inserted, 0, JSON.stringify(ignored));
  assert.equal(ignored.updated, 0, JSON.stringify(ignored));
  assert.equal(ignored.ignored, 1, JSON.stringify(ignored));
  assert.equal(ignored.inconsistent, 0, JSON.stringify(ignored));
  assert.deepEqual(
    { inserted: ignored.groups[0].inserted, updated: ignored.groups[0].updated,
      ignored: ignored.groups[0].ignored, inconsistent: ignored.groups[0].inconsistent },
    { inserted: 0, updated: 0, ignored: 1, inconsistent: 0 },
  );

  const admission = await pool.query(
    `SELECT unit_id::text AS unit_id, status
       FROM admissions
      WHERE contract_number = $1`,
    [contractNumber],
  );
  assert.deepEqual(
    admission.rows,
    [{ unit_id: originalUnitId, status: 'APROVADA' }],
    'atualizar pode modificar os demais dados, mas atualizar ou ignorar nunca troca a unidade original',
  );
});

test('a prévia PostgreSQL aceita a razão social e a execução vincula processos jurídicos e títulos com nome fantasia vazio ou nulo', {
  timeout: 120_000,
}, async t => {
  const { baseUrl, pool } = await createDisposablePostgres(t, {}, { migrationPath: 'fresh' });
  const unitId = USER.currentUnitId;
  const legalName = 'Razão Social da Unidade para Processos e Títulos';
  await pool.query(
    'INSERT INTO companies (id, razao_social, nome_fantasia) VALUES ($1, $2, $3)',
    [unitId, legalName, ''],
  );

  const affectedImports = [
    {
      table: 'legal_processes',
      makeRow: (value, unitName) => ({ process_number: value, unit_name: unitName }),
      query: value => pool.query(
        'SELECT unit_id::text AS unit_id FROM legal_processes WHERE process_number = $1',
        [value],
      ),
    },
    {
      table: 'financial_titles',
      makeRow: (value, unitName) => ({
        title_scope: 'PAGAR',
        value: 125,
        document_number: value,
        unit_name: unitName,
      }),
      query: value => pool.query(
        'SELECT unit_id::text AS unit_id FROM financial_titles WHERE document_number = $1',
        [value],
      ),
    },
  ];

  for (const [fantasyName, suffix, unitName] of [
    ['', 'VAZIA', legalName],
    [null, 'NULA', legalName],
    ['Nome Fantasia Prioritário', 'PREENCHIDA', 'Nome Fantasia Prioritário'],
  ]) {
    await pool.query('UPDATE companies SET nome_fantasia = $2 WHERE id = $1', [unitId, fantasyName]);

    for (const config of affectedImports) {
      const identity = `${config.table.toUpperCase()}-RAZAO-SOCIAL-${suffix}`;
      const row = config.makeRow(identity, unitName);
      const validationResponse = await fetch(`${baseUrl}/api/import/validate`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          groups: [{
            table: config.table,
            rows: [row],
          }],
        }),
      });
      assert.equal(validationResponse.status, 200, await validationResponse.clone().text());
      const validation = await validationResponse.json();
      const previewGroup = validation.groups.find(group => group.table === config.table);
      assert.ok(previewGroup, `${config.table}: a prévia deve retornar o grupo validado`);
      assert.equal(previewGroup.error, 0, `${config.table}: ${JSON.stringify(previewGroup)}`);
      assert.equal(previewGroup.rows[0]?.status, 'ok',
        `${config.table}: a razão social deve ser aceita na prévia com nome fantasia ${JSON.stringify(fantasyName)}`);

      const response = await fetch(`${baseUrl}/api/import/execute`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          stepUpToken: 'test-token',
          groups: [{
            table: config.table,
            rows: [row],
          }],
        }),
      });
      assert.equal(response.status, 200, await response.clone().text());
      const result = await response.json();
      assert.equal(result.inserted, 1, `${config.table}: ${JSON.stringify(result)}`);
      assert.equal(result.inconsistent, 0, `${config.table}: ${JSON.stringify(result)}`);
      assert.deepEqual(
        (await config.query(identity)).rows,
        [{ unit_id: unitId }],
        `${config.table} deve resolver a unidade correta com nome fantasia ${JSON.stringify(fantasyName)}`,
      );
    }
  }
});

test('a rota grava vínculos relacionados e desfaz a transação após falha no PostgreSQL', {
  timeout: 120_000,
}, async t => {
  const { baseUrl, pool } = await createDisposablePostgres(t);
  const execute = (groups, mode = 'approved_only') => fetch(`${baseUrl}/api/import/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      stepUpToken: 'test-token',
      groups,
      mode,
      duplicateStrategy: 'ignore',
    }),
  });

  // A filha chega antes da pai no corpo, e a tabela dependente aparece antes
  // da tabela de clientes; as relações devem continuar corretas ao persistir.
  const relatedImport = await execute([
    {
      table: 'legal_processes',
      rows: [{
        process_number: 'PROC-CLIENTE-001',
        client_name: 'Cliente titular',
        partner_name: 'Cliente parceiro',
        tags: '["urgente","ação"]',
      }],
    },
    {
      table: 'clients',
      rows: [
        { name: 'Cliente titular', document: '00123456789' },
        { name: 'Cliente parceiro', document: '00000000421' },
      ],
    },
  ]);
  assert.equal(relatedImport.status, 200);
  const relatedResult = await relatedImport.json();
  assert.equal(relatedResult.inserted, 3, JSON.stringify(relatedResult));
  assert.equal(relatedResult.inconsistent, 0);

  const persistedRelations = await pool.query(`
    SELECT p.process_number, client.name AS client_name, partner.name AS partner_name, p.tags
    FROM legal_processes p
    JOIN clients client ON client.id = p.client_id
    JOIN clients partner ON partner.id = p.partner_id
    WHERE p.process_number = 'PROC-CLIENTE-001'
  `);
  assert.deepEqual(persistedRelations.rows, [{
    process_number: 'PROC-CLIENTE-001',
    client_name: 'Cliente titular',
    partner_name: 'Cliente parceiro',
    tags: ['urgente', 'ação'],
  }]);

  const hierarchyImport = await execute([{
    table: 'chart_of_accounts',
    rows: [
      { code: '2.1', name: 'Conta filha', type: 'DESPESA', parent_code: '2' },
      { code: '2', name: 'Conta principal', type: 'DESPESA', parent_code: '' },
    ],
  }]);
  assert.equal(hierarchyImport.status, 200);
  const hierarchyResult = await hierarchyImport.json();
  assert.equal(hierarchyResult.inserted, 2, JSON.stringify(hierarchyResult));
  assert.equal(hierarchyResult.inconsistent, 0);

  const persistedHierarchy = await pool.query(`
    SELECT child.code AS child_code, parent.code AS parent_code
    FROM chart_of_accounts child
    JOIN chart_of_accounts parent ON parent.id = child.parent_id
    WHERE child.code = '2.1'
  `);
  assert.deepEqual(persistedHierarchy.rows, [{ child_code: '2.1', parent_code: '2' }]);

  const rollbackImport = await execute([
    {
      table: 'legal_processes',
      rows: [
        { process_number: 'PROC-ROLLBACK-001', client_name: 'Cliente a reverter' },
        { process_number: 'ROLLBACK-TEST', client_name: 'Cliente a reverter' },
      ],
    },
    {
      table: 'clients',
      rows: [{ name: 'Cliente a reverter', document: '00987654321' }],
    },
  ], 'abort_on_any_error');
  assert.equal(rollbackImport.status, 200);
  const rollbackResult = await rollbackImport.json();
  assert.equal(rollbackResult.aborted, true, JSON.stringify(rollbackResult));
  assert.equal(rollbackResult.inserted, 0);

  const rolledBackRows = await pool.query(`
    SELECT
      (SELECT COUNT(*)::int FROM clients WHERE name = 'Cliente a reverter') AS clients,
      (SELECT COUNT(*)::int FROM legal_processes WHERE process_number IN ('PROC-ROLLBACK-001', 'ROLLBACK-TEST')) AS processes
  `);
  assert.deepEqual(rolledBackRows.rows[0], { clients: 0, processes: 0 });
});

test('contratos: recálculo idempotente, lixeira, restauração e prévia invalidada', async t => {
  const { pool } = await createDisposablePostgres(t, {}, { migrationPath: 'fresh' });
  await pool.query("INSERT INTO users(id,name,email,role) VALUES($1,'Admin teste','synthetic@example.invalid','ADMIN')", [USER.id]);
  await pool.query("INSERT INTO companies(id,razao_social) VALUES($1,'Unidade teste')", [USER.currentUnitId]);
  const clientId = (await pool.query("INSERT INTO clients(name) VALUES('Cliente Teste') RETURNING id")).rows[0].id;
  const admissionId = (await pool.query("INSERT INTO admissions(client_id,contract_number,unit_id) VALUES($1,'08',$2) RETURNING id", [clientId,USER.currentUnitId])).rows[0].id;
  const text = 'Recálculo: parcelas a pagar 2; dívida original R$ 100,00; parcela recalculada R$ 25,00; dívida recalculada R$ 50,00; economia R$ 50,00; dia venc. 10';
  await persistAdmissionRecalculation(pool, admissionId, text);
  await persistAdmissionRecalculation(pool, admissionId, text);
  assert.equal((await pool.query('SELECT count(*)::int AS count FROM recalc_scenarios')).rows[0].count,1);
  assert.equal(parseAdmissionRecalculation(text).scenario.original_debt,'100,00');
  await pool.query(`INSERT INTO client_attachments(client_id,module,category,target_type,target_id,original_filename,mime_type,file_size,object_key,checksum_sha256,import_status,source_path)
    VALUES($1,'ADMISSION','OUTRO','ADMISSION',$2,'teste.txt','text/plain',1,'BucketdaInvicta/contracts/synthetic-only',$3,'IMPORTED','08_Cliente Teste/sub/teste.txt')`, [clientId,admissionId,'a'.repeat(64)]);
  const app = express();
  app.use(express.json());
  app.use((req,_res,next)=>{ req.currentUser=USER;next(); });
  const lock = async (_pool,fn) => {const db=await pool.connect();try{return await fn(db);}finally{db.release();}};
  let deletedObjects = 0;
  app.use(createContractAttachmentRoutes(pool,{signApproval:()=>'',withLock:lock,deleteObject:async key=>{
    assert.equal(key,'BucketdaInvicta/contracts/synthetic-only'); deletedObjects++;
    if (deletedObjects===1) throw new Error('falha sintética de rede');
  }}));
  const server=createServer(app);
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  t.after(()=>new Promise(resolve=>{server.close(resolve);server.closeAllConnections();}));
  const base=`http://127.0.0.1:${server.address().port}`;
  const post=async (route,body)=>{const response=await fetch(base+route,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});return {status:response.status,body:await response.json()};};
  for(const action of ['trash','restore','trash','purge']) {
    const preview=await post('/lifecycle/preview',{action,clientId,folder:'08_Cliente Teste'});
    assert.equal(preview.status,200,JSON.stringify(preview.body));
    assert.equal(preview.body.count,1);
    const start=await post('/lifecycle/start',{token:preview.body.token,confirmed:true});
    assert.equal(start.status,200,JSON.stringify(start.body));
    let tick=await post(`/lifecycle/jobs/${start.body.jobId}/tick`,{});
    if(action==='purge') {
      assert.equal(tick.body.status,'failed');
      assert.equal((await pool.query('SELECT state FROM contract_attachment_trash')).rows[0].state,'PURGING');
      tick=await post(`/lifecycle/jobs/${start.body.jobId}/tick`,{});
    }
    assert.equal(tick.body.status,'completed',JSON.stringify(tick.body));
    assert.equal((await pool.query('SELECT count(*)::int AS n FROM contract_attachment_trash')).rows[0].n,action==='trash'?1:0);
    const replay=await post('/lifecycle/start',{token:preview.body.token,confirmed:true});
    assert.equal(replay.status,409);
  }
  assert.equal(deletedObjects,2);
  assert.equal((await pool.query('SELECT count(*)::int AS n FROM client_attachments')).rows[0].n,0);
});

test('layout e importação de admissões criam clientes e vinculam responsável e titular', {
  timeout: 120_000,
}, async t => {
  const { baseUrl, pool } = await createDisposablePostgres(t, {}, { migrationPath: 'fresh' });
  await pool.query(
    'INSERT INTO companies (id, razao_social, nome_fantasia) VALUES ($1, $2, $3)',
    [USER.currentUnitId, 'Unidade de teste', 'Unidade de teste'],
  );

  const schemaResponse = await fetch(`${baseUrl}/api/import/schema`);
  assert.equal(schemaResponse.status, 200);
  const { tables } = await schemaResponse.json();
  const clientsConfig = tables.find(table => table.key === 'clients');
  const admissionsConfig = tables.find(table => table.key === 'admissions');
  const responsibleProfile = {
    address: 'Rua do Responsável',
    number: '101',
    complement: 'Casa',
    district: 'Centro',
    city: 'Campinas',
    state: 'SP',
    cep: '13000001',
    notes: 'Observação do responsável',
  };
  const titularProfile = {
    address: 'Rua do Titular',
    number: '202',
    complement: 'Apto 2',
    district: 'Jardim',
    city: 'Santos',
    state: 'SP',
    cep: '11000002',
    notes: 'Observação do titular',
  };

  const conflictingGroups = [
    {
      table: 'clients',
      rows: [{
        name: 'Cliente com divergência',
        document: '00111111111',
        address: 'Endereço da aba Clientes',
      }],
    },
    {
      table: 'admissions',
      rows: [{
        client_name: 'Cliente com divergência',
        client_address: 'Endereço diferente na aba Admissões',
        contract_number: 'ADM-CONFLITO-PERFIL',
        unit_name: 'Unidade de teste',
      }],
    },
  ];
  const conflictValidation = await validateImportGroups(pool, conflictingGroups);
  const clientConflict = conflictValidation.find(group => group.table === 'clients');
  const admissionConflict = conflictValidation.find(group => group.table === 'admissions');
  assert.equal(clientConflict.rows[0].status, 'error');
  assert.equal(clientConflict.rows[0].errors.some(error => error.column === 'address'), true);
  assert.equal(admissionConflict.rows[0].status, 'error');
  assert.equal(admissionConflict.rows[0].errors.some(error => error.column === 'client_address'), true);

  const rejectedConflict = await fetch(`${baseUrl}/api/import/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      stepUpToken: 'disposable-postgres-test',
      groups: conflictingGroups,
      duplicateStrategy: 'ignore',
    }),
  });
  assert.equal(rejectedConflict.status, 200);
  const conflictResult = await rejectedConflict.json();
  assert.equal(conflictResult.inserted, 0);
  assert.equal(conflictResult.inconsistent, 2);
  const conflictRows = await pool.query(`
    SELECT
      (SELECT COUNT(*)::int FROM clients WHERE name = 'Cliente com divergência') AS clients,
      (SELECT COUNT(*)::int FROM admissions WHERE contract_number = 'ADM-CONFLITO-PERFIL') AS admissions
  `);
  assert.deepEqual(conflictRows.rows[0], { clients: 0, admissions: 0 },
    'divergent data in the two worksheets must not partially write either record');

  const layoutResponse = await fetch(`${baseUrl}/api/import/layout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tables: ['admissions', 'clients'] }),
  });
  assert.equal(layoutResponse.status, 200);
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(Buffer.from(await layoutResponse.arrayBuffer()));
  assert.deepEqual(workbook.worksheets.map(sheet => sheet.name), ['Clientes', 'Admissões']);

  workbook.getWorksheet('Clientes').addRow(clientsConfig.fields.map(field => ({
    name: 'Responsável da admissão',
    document: '00123456789',
    phone: '11999990001',
    email: 'responsavel@example.test',
  }[field.key] || '')));
  workbook.getWorksheet('Clientes').addRow(clientsConfig.fields.map(field => ({
    name: 'Titular da admissão',
    document: '00987654321',
    phone: '11999990002',
    email: 'titular@example.test',
  }[field.key] || '')));
  workbook.getWorksheet('Admissões').addRow(admissionsConfig.fields.map(field => ({
    client_name: 'Responsável da admissão',
    contract_number: 'ADM-CLIENTES-AUTO-001',
    unit_name: 'Unidade de teste',
    titular_client_name: 'Titular da admissão',
    ...Object.fromEntries(Object.entries(responsibleProfile).map(([column, value]) => [`client_${column}`, value])),
    ...Object.fromEntries(Object.entries(titularProfile).map(([column, value]) => [`titular_${column}`, value])),
  }[field.key] || '')));

  const mapping = {
    clients: clientsConfig.fields.map(field => ({
      fieldKey: field.key,
      sheetColumn: field.label,
    })),
    admissions: admissionsConfig.fields.map(field => ({
      fieldKey: field.key,
      sheetColumn: field.label,
    })),
  };
  const groups = await parseXlsxImport(
    Buffer.from(await workbook.xlsx.writeBuffer()),
    ['admissions', 'clients'],
    mapping,
  );
  assert.deepEqual(new Set(groups.map(group => group.table)), new Set(['clients', 'admissions']));
  assert.equal(groups.find(group => group.table === 'clients').rows.length, 2);
  assert.equal(groups.find(group => group.table === 'admissions').rows.length, 1);

  const execute = await fetch(`${baseUrl}/api/import/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      stepUpToken: 'disposable-postgres-test',
      groups,
      duplicateStrategy: 'ignore',
    }),
  });
  assert.equal(execute.status, 200, await execute.clone().text());
  const result = await execute.json();
  assert.equal(result.inserted, 3, JSON.stringify(result));
  assert.equal(result.inconsistent, 0, JSON.stringify(result));
  assert.equal(result.clientProfilesUpdated, 2, JSON.stringify(result));
  assert.equal(result.responsibleClientProfilesUpdated, 1, JSON.stringify(result));
  assert.equal(result.titularClientProfilesUpdated, 1, JSON.stringify(result));

  const savedAdmission = await pool.query(`
    SELECT admission.contract_number,
           responsible.name AS responsible_name,
           titular.name AS titular_name,
           responsible.address AS responsible_address,
           responsible.number AS responsible_number,
           responsible.complement AS responsible_complement,
           responsible.district AS responsible_district,
           responsible.city AS responsible_city,
           responsible.state AS responsible_state,
           responsible.cep AS responsible_cep,
           responsible.notes AS responsible_notes,
           titular.address AS titular_address,
           titular.number AS titular_number,
           titular.complement AS titular_complement,
           titular.district AS titular_district,
           titular.city AS titular_city,
           titular.state AS titular_state,
           titular.cep AS titular_cep,
           titular.notes AS titular_notes,
           admission.client_id::text AS responsible_id,
           admission.titular_client_id::text AS titular_id
      FROM admissions admission
      JOIN clients responsible ON responsible.id = admission.client_id
      JOIN clients titular ON titular.id = admission.titular_client_id
     WHERE admission.contract_number = 'ADM-CLIENTES-AUTO-001'
  `);
  assert.equal(savedAdmission.rowCount, 1);
  assert.equal(savedAdmission.rows[0].responsible_name, 'Responsável da admissão');
  assert.equal(savedAdmission.rows[0].titular_name, 'Titular da admissão');
  assert.deepEqual(
    [
      savedAdmission.rows[0].responsible_address,
      savedAdmission.rows[0].responsible_number,
      savedAdmission.rows[0].responsible_complement,
      savedAdmission.rows[0].responsible_district,
      savedAdmission.rows[0].responsible_city,
      savedAdmission.rows[0].responsible_state,
      savedAdmission.rows[0].responsible_cep,
      savedAdmission.rows[0].responsible_notes,
    ],
    Object.values(responsibleProfile),
  );
  assert.deepEqual(
    [
      savedAdmission.rows[0].titular_address,
      savedAdmission.rows[0].titular_number,
      savedAdmission.rows[0].titular_complement,
      savedAdmission.rows[0].titular_district,
      savedAdmission.rows[0].titular_city,
      savedAdmission.rows[0].titular_state,
      savedAdmission.rows[0].titular_cep,
      savedAdmission.rows[0].titular_notes,
    ],
    Object.values(titularProfile),
  );
  assert.ok(savedAdmission.rows[0].responsible_id);
  assert.ok(savedAdmission.rows[0].titular_id);
  assert.notEqual(savedAdmission.rows[0].responsible_id, savedAdmission.rows[0].titular_id);

  const noProfileChangesResponse = await fetch(`${baseUrl}/api/import/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      stepUpToken: 'disposable-postgres-test',
      groups: [{
        table: 'admissions',
        rows: [{
          client_name: 'Responsável da admissão',
          titular_client_name: 'Titular da admissão',
          contract_number: 'ADM-CLIENTES-SEM-ALTERACAO',
          unit_name: 'Unidade de teste',
        }],
      }],
      duplicateStrategy: 'ignore',
    }),
  });
  assert.equal(noProfileChangesResponse.status, 200, await noProfileChangesResponse.clone().text());
  const noProfileChangesResult = await noProfileChangesResponse.json();
  assert.equal(noProfileChangesResult.inserted, 1, JSON.stringify(noProfileChangesResult));
  assert.equal(noProfileChangesResult.clientProfilesUpdated, 0, JSON.stringify(noProfileChangesResult));
  assert.equal(noProfileChangesResult.responsibleClientProfilesUpdated, 0, JSON.stringify(noProfileChangesResult));
  assert.equal(noProfileChangesResult.titularClientProfilesUpdated, 0, JSON.stringify(noProfileChangesResult));

  const updatedResponsibleProfile = {
    address: 'Avenida do Responsável',
    number: '303',
    complement: 'Fundos',
    district: 'Cambui',
    city: 'Campinas',
    state: 'SP',
    cep: '13000003',
    notes: 'Perfil atualizado do responsável',
  };
  const updateOnlyAdmission = {
    client_name: 'Responsável da admissão',
    titular_client_name: 'Titular da admissão',
    contract_number: 'ADM-CLIENTES-AUTO-002',
    unit_name: 'Unidade de teste',
    ...Object.fromEntries(Object.entries(updatedResponsibleProfile).map(([column, value]) => [`client_${column}`, value])),
  };
  const updateOnlyResponse = await fetch(`${baseUrl}/api/import/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      stepUpToken: 'disposable-postgres-test',
      groups: [{ table: 'admissions', rows: [updateOnlyAdmission] }],
      duplicateStrategy: 'ignore',
    }),
  });
  assert.equal(updateOnlyResponse.status, 200, await updateOnlyResponse.clone().text());
  const updateOnlyResult = await updateOnlyResponse.json();
  assert.equal(updateOnlyResult.inserted, 1);
  assert.equal(updateOnlyResult.clientProfilesUpdated, 1);
  assert.equal(updateOnlyResult.responsibleClientProfilesUpdated, 1);
  assert.equal(updateOnlyResult.titularClientProfilesUpdated, 0);
  const updatedProfile = await pool.query(
    'SELECT address, number, complement, district, city, state, cep, notes FROM clients WHERE name = $1',
    ['Responsável da admissão'],
  );
  assert.deepEqual(updatedProfile.rows[0], updatedResponsibleProfile);

  const updatedTitularProfile = {
    address: 'Alameda do Titular',
    number: '404',
    complement: 'Bloco B',
    district: 'Gonzaga',
    city: 'Santos',
    state: 'SP',
    cep: '11000004',
    notes: 'Perfil atualizado do titular',
  };
  const executeAdmission = async (row, contractNumber) => {
    const response = await fetch(`${baseUrl}/api/import/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        stepUpToken: 'disposable-postgres-test',
        groups: [{
          table: 'admissions',
          rows: [{ ...row, contract_number: contractNumber, unit_name: 'Unidade de teste' }],
        }],
        duplicateStrategy: 'ignore',
      }),
    });
    assert.equal(response.status, 200, await response.clone().text());
    return response.json();
  };

  const titularOnlyResult = await executeAdmission({
    client_name: 'Responsável da admissão',
    titular_client_name: 'Titular da admissão',
    ...Object.fromEntries(Object.entries(updatedTitularProfile).map(([column, value]) => [`titular_${column}`, value])),
  }, 'ADM-CLIENTES-TITULAR-ONLY');
  assert.equal(titularOnlyResult.clientProfilesUpdated, 1, JSON.stringify(titularOnlyResult));
  assert.equal(titularOnlyResult.responsibleClientProfilesUpdated, 0, JSON.stringify(titularOnlyResult));
  assert.equal(titularOnlyResult.titularClientProfilesUpdated, 1, JSON.stringify(titularOnlyResult));

  const updatedBothResult = await executeAdmission({
    client_name: 'Responsável da admissão',
    titular_client_name: 'Titular da admissão',
    client_address: 'Rua atualizada dos dois papéis',
    titular_address: 'Rua atualizada dos dois papéis',
  }, 'ADM-CLIENTES-AMBOS');
  assert.equal(updatedBothResult.clientProfilesUpdated, 2, JSON.stringify(updatedBothResult));
  assert.equal(updatedBothResult.responsibleClientProfilesUpdated, 1, JSON.stringify(updatedBothResult));
  assert.equal(updatedBothResult.titularClientProfilesUpdated, 1, JSON.stringify(updatedBothResult));

  const sharedClientId = '10000000-0000-4000-8000-000000000098';
  await pool.query(
    'INSERT INTO clients (id, name, address) VALUES ($1, $2, $3)',
    [sharedClientId, 'Pessoa responsável e titular', 'Endereço anterior'],
  );
  const samePersonResult = await executeAdmission({
    client_name: 'Pessoa responsável e titular',
    titular_client_name: 'Pessoa responsável e titular',
    client_address: 'Endereço atualizado para ambos',
    titular_address: 'Endereço atualizado para ambos',
  }, 'ADM-CLIENTES-MESMA-PESSOA');
  assert.equal(samePersonResult.clientProfilesUpdated, 1, JSON.stringify(samePersonResult));
  assert.equal(samePersonResult.responsibleClientProfilesUpdated, 1, JSON.stringify(samePersonResult));
  assert.equal(samePersonResult.titularClientProfilesUpdated, 1, JSON.stringify(samePersonResult));

  const sharedProfileRows = [
    { client_address: 'Endereço repetido no lote', contract_number: 'ADM-PERFIL-COMPARTILHADO-001' },
    { client_address: 'Endereço repetido no lote', contract_number: 'ADM-PERFIL-COMPARTILHADO-002' },
    { client_address: 'Endereço final diferente', contract_number: 'ADM-PERFIL-COMPARTILHADO-003' },
  ].map(row => ({
    ...row,
    client_name: 'Pessoa responsável e titular',
    unit_name: 'Unidade de teste',
  }));
  const sharedProfileResponse = await fetch(`${baseUrl}/api/import/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      stepUpToken: 'disposable-postgres-test',
      groups: [{ table: 'admissions', rows: sharedProfileRows }],
      duplicateStrategy: 'ignore',
    }),
  });
  assert.equal(sharedProfileResponse.status, 200, await sharedProfileResponse.clone().text());
  const sharedProfileResult = await sharedProfileResponse.json();
  assert.equal(sharedProfileResult.inserted, 3, JSON.stringify(sharedProfileResult));
  assert.equal(sharedProfileResult.clientProfilesUpdated, 1, JSON.stringify(sharedProfileResult));
  assert.equal(sharedProfileResult.responsibleClientProfilesUpdated, 1, JSON.stringify(sharedProfileResult));
  assert.equal(sharedProfileResult.titularClientProfilesUpdated, 0, JSON.stringify(sharedProfileResult));
  const finalSharedProfile = await pool.query(
    'SELECT address FROM clients WHERE id = $1',
    [sharedClientId],
  );
  assert.equal(finalSharedProfile.rows[0].address, 'Endereço final diferente');
});

test('cliente sem documento não duplica um nome existente e nomes repetidos não vinculam responsável ou titular por acaso', {
  timeout: 120_000,
}, async t => {
  const { baseUrl, pool } = await createDisposablePostgres(t, {}, { migrationPath: 'fresh' });
  const unitId = USER.currentUnitId;
  const existingClientId = '10000000-0000-4000-8000-000000000071';
  const existingClientName = 'Cliente sem documento já cadastrado';
  const repeatedClientName = 'Cliente repetido sem documento';

  await pool.query(
    'INSERT INTO companies (id, razao_social, nome_fantasia) VALUES ($1, $2, $3)',
    [unitId, 'Unidade para teste de clientes', 'Unidade para teste de clientes'],
  );
  await pool.query(
    'INSERT INTO clients (id, name) VALUES ($1, $2)',
    [existingClientId, existingClientName],
  );

  const validate = async groups => {
    const response = await fetch(`${baseUrl}/api/import/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ groups }),
    });
    assert.equal(response.status, 200, await response.clone().text());
    return (await response.json()).groups;
  };
  const execute = async groups => {
    const response = await fetch(`${baseUrl}/api/import/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ stepUpToken: 'disposable-postgres-test', groups }),
    });
    assert.equal(response.status, 200, await response.clone().text());
    return response.json();
  };

  const existingNameGroups = [
    { table: 'clients', rows: [{ name: existingClientName, document: '' }] },
    {
      table: 'admissions',
      rows: [{
        contract_number: 'ADM-CLIENTE-SEM-DOCUMENTO-EXISTENTE',
        client_name: existingClientName,
        titular_client_name: existingClientName,
        unit_name: 'Unidade para teste de clientes',
      }],
    },
  ];
  const existingPreview = await validate(existingNameGroups);
  const existingClientPreview = existingPreview.find(group => group.table === 'clients');
  const existingAdmissionPreview = existingPreview.find(group => group.table === 'admissions');
  assert.equal(existingClientPreview.rows[0].status, 'error');
  assert.match(existingClientPreview.rows[0].errors[0].message, /Informe o CPF\/CNPJ/);
  assert.equal(existingAdmissionPreview.rows[0].status, 'ok',
    'o nome existente e único deve continuar resolvendo para o cadastro já salvo');

  const existingResult = await execute(existingNameGroups);
  assert.equal(existingResult.inconsistent, 1, JSON.stringify(existingResult));
  assert.equal(existingResult.inserted, 1, JSON.stringify(existingResult));
  const existingCounts = await pool.query(
    `SELECT (SELECT COUNT(*)::int FROM clients WHERE name = $1) AS clients,
            (SELECT client_id::text FROM admissions WHERE contract_number = $2) AS responsible_id,
            (SELECT titular_client_id::text FROM admissions WHERE contract_number = $2) AS titular_id`,
    [existingClientName, 'ADM-CLIENTE-SEM-DOCUMENTO-EXISTENTE'],
  );
  assert.deepEqual(existingCounts.rows, [{
    clients: 1,
    responsible_id: existingClientId,
    titular_id: existingClientId,
  }], 'a admissão deve apontar para o único cliente existente, sem criar uma cópia');

  await pool.query(
    'INSERT INTO clients (id, name) VALUES ($1, $2)',
    ['10000000-0000-4000-8000-000000000072', existingClientName],
  );
  const ambiguousExistingGroups = [{
    table: 'admissions',
    rows: [{
      contract_number: 'ADM-CLIENTE-NOME-AMBIGUO-NO-BANCO',
      client_name: existingClientName,
      titular_client_name: existingClientName,
      unit_name: 'Unidade para teste de clientes',
    }],
  }];
  const ambiguousExistingPreview = await validate(ambiguousExistingGroups);
  const ambiguousExistingAdmission = ambiguousExistingPreview.find(group => group.table === 'admissions');
  assert.equal(ambiguousExistingAdmission.rows[0].status, 'error');
  assert.deepEqual(
    ambiguousExistingAdmission.rows[0].errors
      .filter(error => ['client_name', 'titular_client_name'].includes(error.column))
      .map(error => error.column)
      .sort(),
    ['client_name', 'titular_client_name'],
    'responsável e titular devem rejeitar nomes duplicados já existentes no banco',
  );
  const ambiguousExistingResult = await execute(ambiguousExistingGroups);
  assert.equal(ambiguousExistingResult.inserted, 0, JSON.stringify(ambiguousExistingResult));
  assert.equal(ambiguousExistingResult.inconsistent, 1, JSON.stringify(ambiguousExistingResult));

  const repeatedNameGroups = [
    {
      table: 'clients',
      rows: [
        { name: repeatedClientName, document: '' },
        { name: repeatedClientName, document: '' },
      ],
    },
    {
      table: 'admissions',
      rows: [{
        contract_number: 'ADM-CLIENTE-SEM-DOCUMENTO-REPETIDO',
        client_name: repeatedClientName,
        titular_client_name: repeatedClientName,
        unit_name: 'Unidade para teste de clientes',
      }],
    },
  ];
  const repeatedPreview = await validate(repeatedNameGroups);
  const repeatedClientPreview = repeatedPreview.find(group => group.table === 'clients');
  const repeatedAdmissionPreview = repeatedPreview.find(group => group.table === 'admissions');
  assert.deepEqual(repeatedClientPreview.rows.map(row => row.status), ['error', 'error']);
  assert.ok(repeatedClientPreview.rows.every(row =>
    row.errors.some(error => /repetido na planilha/.test(error.message))));
  assert.equal(repeatedAdmissionPreview.rows[0].status, 'error');
  const admissionLinkErrors = repeatedAdmissionPreview.rows[0].errors.filter(error =>
    ['client_name', 'titular_client_name'].includes(error.column));
  assert.deepEqual(
    admissionLinkErrors.map(error => error.column).sort(),
    ['client_name', 'titular_client_name'],
    'responsável e titular devem sinalizar separadamente o nome ambíguo',
  );
  assert.ok(admissionLinkErrors.every(error => /ambíguo/.test(error.message)));

  const repeatedResult = await execute(repeatedNameGroups);
  assert.equal(repeatedResult.inserted, 0, JSON.stringify(repeatedResult));
  assert.equal(repeatedResult.inconsistent, 3, JSON.stringify(repeatedResult));
  const repeatedCounts = await pool.query(
    `SELECT (SELECT COUNT(*)::int FROM clients WHERE name = $1) AS clients,
            (SELECT COUNT(*)::int FROM admissions WHERE contract_number = $2) AS admissions`,
    [repeatedClientName, 'ADM-CLIENTE-SEM-DOCUMENTO-REPETIDO'],
  );
  assert.deepEqual(repeatedCounts.rows, [{ clients: 0, admissions: 0 }]);

  const sameName = 'Pessoa homônima com documento';
  const firstDocument = '11122233344';
  const secondDocument = '55566677788';
  await pool.query(
    'INSERT INTO clients (id, name, document) VALUES ($1, $2, $3), ($4, $2, $5)',
    [
      '10000000-0000-4000-8000-000000000073',
      sameName,
      firstDocument,
      '10000000-0000-4000-8000-000000000074',
      secondDocument,
    ],
  );
  const disambiguatedGroups = [{
    table: 'admissions',
    rows: [{
      contract_number: 'ADM-CLIENTES-DOCUMENTOS-DIFERENTES',
      client_name: sameName,
      client_document: '111.222.333-44',
      titular_client_name: sameName,
      titular_client_document: '555.666.777-88',
      unit_name: 'Unidade para teste de clientes',
    }],
  }];
  const disambiguatedPreview = await validate(disambiguatedGroups);
  const disambiguatedAdmission = disambiguatedPreview.find(group => group.table === 'admissions');
  assert.equal(disambiguatedAdmission.rows[0].status, 'ok',
    'documentos distintos devem resolver os dois vínculos apesar dos nomes iguais');
  const disambiguatedResult = await execute(disambiguatedGroups);
  assert.equal(disambiguatedResult.inserted, 1, JSON.stringify(disambiguatedResult));
  const savedDisambiguatedAdmission = await pool.query(
    `SELECT client_id::text AS client_id, titular_client_id::text AS titular_client_id
       FROM admissions WHERE contract_number = $1`,
    ['ADM-CLIENTES-DOCUMENTOS-DIFERENTES'],
  );
  assert.deepEqual(savedDisambiguatedAdmission.rows, [{
    client_id: '10000000-0000-4000-8000-000000000073',
    titular_client_id: '10000000-0000-4000-8000-000000000074',
  }]);

  for (const [contractNumber, name, document, expectedError] of [
    ['ADM-CLIENTE-DOCUMENTO-INEXISTENTE', sameName, '99988877766', /CPF\/CNPJ não encontrado/],
    ['ADM-CLIENTE-DOCUMENTO-CONFLITANTE', 'Outro nome', firstDocument, /não corresponde ao CPF\/CNPJ cadastrado/],
  ]) {
    const invalidPreview = await validate([{
      table: 'admissions',
      rows: [{
        contract_number: contractNumber,
        client_name: name,
        client_document: document,
        unit_name: 'Unidade para teste de clientes',
      }],
    }]);
    const invalidAdmission = invalidPreview.find(group => group.table === 'admissions');
    assert.equal(invalidAdmission.rows[0].status, 'error');
    assert.ok(invalidAdmission.rows[0].errors.some(error =>
      error.column === 'client_document' && expectedError.test(error.message)));
  }

  const sameRunName = 'Pessoa homônima incluída no mesmo lote';
  const sameRunGroups = [
    {
      table: 'clients',
      rows: [
        { name: sameRunName, document: '12312312312' },
        { name: sameRunName, document: '32132132132' },
      ],
    },
    {
      table: 'admissions',
      rows: [{
        contract_number: 'ADM-CLIENTES-MESMO-LOTE-DOCUMENTOS',
        client_name: sameRunName,
        client_document: '123.123.123-12',
        titular_client_name: sameRunName,
        titular_client_document: '321.321.321-32',
        unit_name: 'Unidade para teste de clientes',
      }],
    },
  ];
  const sameRunPreview = await validate(sameRunGroups);
  assert.deepEqual(sameRunPreview.find(group => group.table === 'clients').rows.map(row => row.status),
    ['ok', 'ok'], 'a planilha pode conter pessoas homônimas quando os documentos são distintos');
  assert.equal(sameRunPreview.find(group => group.table === 'admissions').rows[0].status, 'ok');
  const sameRunResult = await execute(sameRunGroups);
  assert.equal(sameRunResult.inserted, 3, JSON.stringify(sameRunResult));
  const sameRunSavedIds = await pool.query(
    `SELECT admission.client_id::text AS client_id, admission.titular_client_id::text AS titular_client_id,
            responsible.document AS responsible_document, titular.document AS titular_document
       FROM admissions admission
       JOIN clients responsible ON responsible.id = admission.client_id
       JOIN clients titular ON titular.id = admission.titular_client_id
      WHERE admission.contract_number = $1`,
    ['ADM-CLIENTES-MESMO-LOTE-DOCUMENTOS'],
  );
  assert.equal(sameRunSavedIds.rowCount, 1);
  assert.deepEqual(sameRunSavedIds.rows, [{
    client_id: sameRunSavedIds.rows[0].client_id,
    titular_client_id: sameRunSavedIds.rows[0].titular_client_id,
    responsible_document: '12312312312',
    titular_document: '32132132132',
  }]);
  assert.notEqual(sameRunSavedIds.rows[0].client_id, sameRunSavedIds.rows[0].titular_client_id);

  const conflictingDocumentGroups = [
    {
      table: 'clients',
      rows: [
        { name: 'Nome da primeira pessoa', document: '44455566677' },
        { name: 'Nome da segunda pessoa', document: '44455566677' },
      ],
    },
    {
      table: 'admissions',
      rows: [{
        contract_number: 'ADM-CLIENTE-DOCUMENTO-DUPLICADO-NO-LOTE',
        client_name: 'Nome da primeira pessoa',
        client_document: '44455566677',
        unit_name: 'Unidade para teste de clientes',
      }],
    },
  ];
  const conflictingDocumentPreview = await validate(conflictingDocumentGroups);
  assert.deepEqual(conflictingDocumentPreview.find(group => group.table === 'clients').rows
    .map(row => row.status), ['error', 'error']);
  const conflictingDocumentAdmission = conflictingDocumentPreview.find(group => group.table === 'admissions');
  assert.equal(conflictingDocumentAdmission.rows[0].status, 'error');
  assert.ok(conflictingDocumentAdmission.rows[0].errors.some(error =>
    error.column === 'client_document' && /CPF\/CNPJ informado está associado a mais de um cliente/.test(error.message)));
});

async function assertXlsxImportPersistsClientRelations(t, migrationPath) {
  const objects = new Map();
  let pool;
  const storeObject = async (key, bytes) => objects.set(key, Buffer.from(bytes));
  const readObject = async key => {
    const value = objects.get(key);
    if (!value) throw new Error(`Objeto de importação não encontrado: ${key}`);
    return Buffer.from(value);
  };
  const deleteObject = async key => objects.delete(key);
  const routeDependencies = {
    uploadImportObject: storeObject,
    downloadImportObject: readObject,
    deleteImportObject: deleteObject,
    enqueueDataImport: async payload => {
      const result = await pool.query(
        'INSERT INTO background_jobs (queue, payload) VALUES ($1, $2) RETURNING id',
        ['data-import-xlsx', JSON.stringify(payload)],
      );
      return result.rows[0].id;
    },
    getJob: async id => {
      const result = await pool.query(
        `SELECT id, queue, status, payload, result, error, created_at, updated_at
           FROM background_jobs WHERE id = $1`,
        [id],
      );
      return result.rows[0] || null;
    },
    claimJobForExecution: async id => {
      const result = await pool.query(
        `UPDATE background_jobs SET status = 'executing', updated_at = NOW()
          WHERE id = $1 AND queue = 'data-import-xlsx' AND status = 'completed'
          RETURNING id, queue, status, payload, result, error, lease_token, created_at, updated_at`,
        [id],
      );
      return result.rows[0] || null;
    },
    updateJob: async (id, status, result = null, error = null, leaseToken = null) => {
      const updated = await pool.query(
        `UPDATE background_jobs
            SET status = $2, result = $3, error = $4, updated_at = NOW()
          WHERE id = $1 AND status IN ('processing', 'executing')
            AND $5::uuid IS NOT NULL AND lease_token = $5::uuid
          RETURNING id`,
        [id, status, result ? JSON.stringify(result) : null, error, leaseToken],
      );
      return updated.rowCount > 0;
    },
  };
  const harness = await createDisposablePostgres(t, routeDependencies, { migrationPath });
  pool = harness.pool;

  const workbook = new ExcelJS.Workbook();
  workbook.addWorksheet('Clientes').addRows([
    ['Nome / Razão Social', 'CPF / CNPJ'],
    ['João da Silva', '00123456789'],
    ['Cliente parceiro', '00000000421'],
  ]);
  workbook.addWorksheet('Processos Jurídicos').addRows([
    ['Número do Processo', 'Nome do Cliente', 'Cliente Parceiro', 'Marcadores (JSON)'],
    ['000000001', 'João da Silva', 'Cliente parceiro', '["urgente","ação"]'],
  ]);
  const bytes = Buffer.from(await workbook.xlsx.writeBuffer());
  const mapping = {
    clients: [
      { fieldKey: 'name', sheetColumn: 'Nome / Razão Social' },
      { fieldKey: 'document', sheetColumn: 'CPF / CNPJ' },
    ],
    legal_processes: [
      { fieldKey: 'process_number', sheetColumn: 'Número do Processo' },
      { fieldKey: 'client_name', sheetColumn: 'Nome do Cliente' },
      { fieldKey: 'partner_name', sheetColumn: 'Cliente Parceiro' },
      { fieldKey: 'tags', sheetColumn: 'Marcadores (JSON)' },
    ],
  };

  const upload = await fetch(`${harness.baseUrl}/api/import/upload`, {
    method: 'POST',
    headers: {
      'Content-Type': XLSX_MIME,
      'X-Import-Tables': JSON.stringify(['legal_processes', 'clients']),
      'X-Import-Mapping': encodeImportMappingHeader(mapping),
      'X-Import-File-Name': encodeURIComponent('clientes-e-processos.xlsx'),
    },
    body: bytes,
  });
  assert.equal(upload.status, 202, await upload.clone().text());
  const { jobId } = await upload.json();

  const pending = await pool.query(
    'SELECT payload FROM background_jobs WHERE id = $1',
    [jobId],
  );
  assert.deepEqual(pending.rows[0].payload.tables, ['legal_processes', 'clients']);
  const claimed = await pool.query(
    `UPDATE background_jobs
        SET status = 'processing', lease_token = gen_random_uuid(), updated_at = NOW()
      WHERE id = $1 AND status = 'pending'
      RETURNING lease_token`,
    [jobId],
  );
  assert.equal(claimed.rowCount, 1);

  await processDataImport({
    ...pending.rows[0].payload,
    _pgJobId: jobId,
    _pgLeaseToken: claimed.rows[0].lease_token,
  }, pool, {
    uploadImportObject: storeObject,
    downloadImportObject: readObject,
    deleteImportObject: deleteObject,
    updateJob: routeDependencies.updateJob,
    renewDataImportJobLease: async (id, token) => {
      const renewed = await pool.query(
        `UPDATE background_jobs SET updated_at = NOW()
          WHERE id = $1 AND status = 'processing' AND lease_token = $2::uuid
          RETURNING id`,
        [id, token],
      );
      return renewed.rows[0] || null;
    },
  });

  const prepared = await fetch(`${harness.baseUrl}/api/import/job/${jobId}`);
  assert.equal(prepared.status, 200);
  const preview = await prepared.json();
  assert.equal(preview.status, 'completed');
  assert.equal(preview.fileName, 'clientes-e-processos.xlsx');
  assert.deepEqual(
    preview.groups.map(group => [group.table, group.total, group.ok, group.error]),
    [['clients', 2, 2, 0], ['legal_processes', 1, 1, 0]],
  );

  const execute = await fetch(`${harness.baseUrl}/api/import/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ importJobId: jobId, stepUpToken: 'disposable-postgres-test' }),
  });
  assert.equal(execute.status, 200, await execute.clone().text());
  const result = await execute.json();
  assert.equal(result.inserted, 3, JSON.stringify(result));
  assert.equal(result.inconsistent, 0, JSON.stringify(result));

  const importedClients = await pool.query(
    `SELECT name, id::text AS id
       FROM clients
      WHERE name = ANY($1::text[])`,
    [['João da Silva', 'Cliente parceiro']],
  );
  assert.equal(importedClients.rowCount, 2);
  const clientIdsByName = new Map(importedClients.rows.map(row => [row.name, row.id]));
  const savedRelations = await pool.query(`
    SELECT p.process_number,
           p.client_id::text AS client_id,
           client.id::text AS resolved_client_id,
           client.name AS client_name,
           p.partner_id::text AS partner_id,
           partner.id::text AS resolved_partner_id,
           partner.name AS partner_name,
           p.tags
      FROM legal_processes p
      JOIN clients client ON client.id = p.client_id
      JOIN clients partner ON partner.id = p.partner_id
     WHERE p.process_number = '000000001'
  `);
  assert.deepEqual(savedRelations.rows, [{
    process_number: '000000001',
    client_id: clientIdsByName.get('João da Silva'),
    resolved_client_id: clientIdsByName.get('João da Silva'),
    client_name: 'João da Silva',
    partner_id: clientIdsByName.get('Cliente parceiro'),
    resolved_partner_id: clientIdsByName.get('Cliente parceiro'),
    partner_name: 'Cliente parceiro',
    tags: ['urgente', 'ação'],
  }]);

  if (migrationPath !== 'minimal') {
    const importedForeignKeys = await pool.query(`
      SELECT array_agg(a.attname::text ORDER BY key.ordinality) AS columns
        FROM pg_constraint c
        CROSS JOIN LATERAL unnest(c.conkey) WITH ORDINALITY AS key(attnum, ordinality)
        JOIN pg_attribute a
          ON a.attrelid = c.conrelid AND a.attnum = key.attnum
       WHERE c.contype = 'f'
         AND c.conrelid = 'legal_processes'::regclass
         AND c.confrelid = 'clients'::regclass
       GROUP BY c.oid
       ORDER BY columns
    `);
    assert.deepEqual(
      importedForeignKeys.rows.map(row => row.columns),
      [['client_id'], ['partner_id']],
      'o esquema migrado mantém as FKs reais de cliente titular e parceiro',
    );
  }
  if (migrationPath === 'upgrade') {
    const preservedClient = await pool.query(
      `SELECT id::text AS id FROM clients WHERE name = 'Cliente legado preservado'`,
    );
    assert.deepEqual(preservedClient.rows, [{
      id: '20000000-0000-4000-8000-000000000001',
    }], 'a atualização mantém o ID do cliente que já existia antes da importação');
  }
  assert.equal(objects.size, 0, 'o XLSX original e o resultado preparado foram removidos');
}

test('XLSX enviado, lido e confirmado preserva vínculos de clientes no PostgreSQL mínimo', {
  timeout: 120_000,
}, async t => {
  await assertXlsxImportPersistsClientRelations(t, 'minimal');
});

test('XLSX enviado, lido e confirmado preserva IDs e chaves estrangeiras após as migrações atuais', {
  timeout: 120_000,
}, async t => {
  await assertXlsxImportPersistsClientRelations(t, 'fresh');
});

test('XLSX enviado, lido e confirmado preserva IDs e chaves estrangeiras após atualizar esquema legado', {
  timeout: 120_000,
}, async t => {
  await assertXlsxImportPersistsClientRelations(t, 'upgrade');
});

test('XLSX reverte clientes e processos juntos após falha de gravação no esquema migrado', {
  timeout: 120_000,
}, async t => {
  const objects = new Map();
  let pool;
  const storeObject = async (key, bytes) => objects.set(key, Buffer.from(bytes));
  const readObject = async key => {
    const value = objects.get(key);
    if (!value) throw new Error(`Objeto de importação não encontrado: ${key}`);
    return Buffer.from(value);
  };
  const deleteObject = async key => objects.delete(key);
  const routeDependencies = {
    uploadImportObject: storeObject,
    downloadImportObject: readObject,
    deleteImportObject: deleteObject,
    enqueueDataImport: async payload => {
      const result = await pool.query(
        'INSERT INTO background_jobs (queue, payload) VALUES ($1, $2) RETURNING id',
        ['data-import-xlsx', JSON.stringify(payload)],
      );
      return result.rows[0].id;
    },
    getJob: async id => {
      const result = await pool.query(
        `SELECT id, queue, status, payload, result, error, created_at, updated_at
           FROM background_jobs WHERE id = $1`,
        [id],
      );
      return result.rows[0] || null;
    },
    claimJobForExecution: async id => {
      const result = await pool.query(
        `UPDATE background_jobs SET status = 'executing', updated_at = NOW()
          WHERE id = $1 AND queue = 'data-import-xlsx' AND status = 'completed'
          RETURNING id, queue, status, payload, result, error, lease_token, created_at, updated_at`,
        [id],
      );
      return result.rows[0] || null;
    },
    updateJob: async (id, status, result = null, error = null, leaseToken = null) => {
      const updated = await pool.query(
        `UPDATE background_jobs
            SET status = $2, result = $3, error = $4, updated_at = NOW()
          WHERE id = $1 AND status IN ('processing', 'executing')
            AND $5::uuid IS NOT NULL AND lease_token = $5::uuid
          RETURNING id`,
        [id, status, result ? JSON.stringify(result) : null, error, leaseToken],
      );
      return updated.rowCount > 0;
    },
  };
  const harness = await createDisposablePostgres(t, routeDependencies, { migrationPath: 'fresh' });
  pool = harness.pool;

  const existingClientId = '20000000-0000-4000-8000-000000000002';
  await pool.query(
    `INSERT INTO clients (id, name, document, email)
     VALUES ($1, $2, $3, $4)`,
    [existingClientId, 'Cliente antes do XLSX', '00987654321', 'antes@example.test'],
  );

  const workbook = new ExcelJS.Workbook();
  workbook.addWorksheet('Clientes').addRows([
    ['Nome / Razão Social', 'CPF / CNPJ', 'E-mail'],
    ['Cliente XLSX atualizado', '00987654321', 'depois@example.test'],
  ]);
  workbook.addWorksheet('Processos Jurídicos').addRows([
    ['Número do Processo', 'Nome do Cliente'],
    ['ROLLBACK-XLSX-TEST', 'Cliente XLSX atualizado'],
  ]);
  const bytes = Buffer.from(await workbook.xlsx.writeBuffer());
  const mapping = {
    clients: [
      { fieldKey: 'name', sheetColumn: 'Nome / Razão Social' },
      { fieldKey: 'document', sheetColumn: 'CPF / CNPJ' },
      { fieldKey: 'email', sheetColumn: 'E-mail' },
    ],
    legal_processes: [
      { fieldKey: 'process_number', sheetColumn: 'Número do Processo' },
      { fieldKey: 'client_name', sheetColumn: 'Nome do Cliente' },
    ],
  };

  const upload = await fetch(`${harness.baseUrl}/api/import/upload`, {
    method: 'POST',
    headers: {
      'Content-Type': XLSX_MIME,
      'X-Import-Tables': JSON.stringify(['legal_processes', 'clients']),
      'X-Import-Mapping': encodeImportMappingHeader(mapping),
      'X-Import-File-Name': encodeURIComponent('rollback-clientes-e-processos.xlsx'),
    },
    body: bytes,
  });
  assert.equal(upload.status, 202, await upload.clone().text());
  const { jobId } = await upload.json();

  const pending = await pool.query(
    'SELECT payload FROM background_jobs WHERE id = $1',
    [jobId],
  );
  const originalObjectKey = pending.rows[0].payload.fileKey;
  const preparedObjectKey = `${originalObjectKey}.data`;
  const claimed = await pool.query(
    `UPDATE background_jobs
        SET status = 'processing', lease_token = gen_random_uuid(), updated_at = NOW()
      WHERE id = $1 AND status = 'pending'
      RETURNING lease_token`,
    [jobId],
  );
  assert.equal(claimed.rowCount, 1);
  await processDataImport({
    ...pending.rows[0].payload,
    _pgJobId: jobId,
    _pgLeaseToken: claimed.rows[0].lease_token,
  }, pool, {
    uploadImportObject: storeObject,
    downloadImportObject: readObject,
    deleteImportObject: deleteObject,
    updateJob: routeDependencies.updateJob,
    renewDataImportJobLease: async (id, token) => {
      const renewed = await pool.query(
        `UPDATE background_jobs SET updated_at = NOW()
          WHERE id = $1 AND status = 'processing' AND lease_token = $2::uuid
          RETURNING id`,
        [id, token],
      );
      return renewed.rows[0] || null;
    },
  });

  const preview = await fetch(`${harness.baseUrl}/api/import/job/${jobId}`);
  assert.equal(preview.status, 200);
  const previewResult = await preview.json();
  assert.equal(previewResult.status, 'completed');
  assert.deepEqual(
    previewResult.groups.map(group => [group.table, group.total, group.ok, group.duplicate, group.error]),
    [['clients', 1, 0, 1, 0], ['legal_processes', 1, 1, 0, 0]],
  );
  assert.equal(objects.has(originalObjectKey), false, 'o XLSX original é removido após a preparação');
  assert.equal(objects.has(preparedObjectKey), true, 'o resultado preparado permanece disponível até a execução');
  const clientBeforeExecute = await pool.query(
    'SELECT name, email FROM clients WHERE id = $1',
    [existingClientId],
  );
  assert.deepEqual(clientBeforeExecute.rows, [{
    name: 'Cliente antes do XLSX',
    email: 'antes@example.test',
  }], 'a preparação do XLSX não altera o cliente existente');

  await pool.query(`
    CREATE FUNCTION fail_xlsx_process_import() RETURNS trigger AS $$
    BEGIN
      IF NEW.process_number = 'ROLLBACK-XLSX-TEST' THEN
        RAISE EXCEPTION 'intentional XLSX database failure for rollback test';
      END IF;
      RETURN NEW;
    END;
    $$ LANGUAGE plpgsql;
    CREATE TRIGGER fail_xlsx_process_import
      BEFORE INSERT ON legal_processes
      FOR EACH ROW EXECUTE FUNCTION fail_xlsx_process_import();
  `);

  const execute = await fetch(`${harness.baseUrl}/api/import/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      importJobId: jobId,
      stepUpToken: 'disposable-postgres-test',
      mode: 'abort_on_any_error',
    }),
  });
  assert.equal(execute.status, 200, await execute.clone().text());
  const result = await execute.json();
  assert.equal(result.aborted, true, JSON.stringify(result));
  assert.match(result.error, /inconsistência nos dados/,
    'erros inesperados do banco devem continuar localizados em português');
  assert.doesNotMatch(result.error, /intentional XLSX database failure/,
    'a mensagem interna do banco não deve ser exposta ao usuário');
  assert.equal(result.inserted, 0);

  const remainingBatchRows = await pool.query(`
    SELECT
      (SELECT jsonb_build_object(
         'id', id::text,
         'name', name,
         'document', document,
         'email', email
       ) FROM clients WHERE id = $1) AS client,
      (SELECT COUNT(*)::int FROM legal_processes WHERE process_number = 'ROLLBACK-XLSX-TEST') AS processes
  `, [existingClientId]);
  assert.deepEqual(remainingBatchRows.rows[0], {
    client: {
      id: existingClientId,
      name: 'Cliente antes do XLSX',
      document: '00987654321',
      email: 'antes@example.test',
    },
    processes: 0,
  }, 'a falha ao inserir o processo desfaz a atualização do cliente existente e não salva processos do lote');
  assert.equal(objects.has(originalObjectKey), false, 'o XLSX original não permanece após a falha');
  assert.equal(objects.has(preparedObjectKey), false, 'os dados preparados são removidos após a falha');
  assert.equal(objects.size, 0, 'nenhum objeto temporário do lote permanece após a falha');
});

test('XLSX enviado, preparado e confirmado valida vínculos de unidade por admissão, inclusive ao cancelar tudo', {
  timeout: 120_000,
}, async t => {
  const objects = new Map();
  let pool;
  const storeObject = async (key, bytes) => objects.set(key, Buffer.from(bytes));
  const readObject = async key => {
    const value = objects.get(key);
    if (!value) throw new Error(`Objeto de importação não encontrado: ${key}`);
    return Buffer.from(value);
  };
  const deleteObject = async key => objects.delete(key);
  const routeDependencies = {
    uploadImportObject: storeObject,
    downloadImportObject: readObject,
    deleteImportObject: deleteObject,
    enqueueDataImport: async payload => {
      const result = await pool.query(
        'INSERT INTO background_jobs (queue, payload) VALUES ($1, $2) RETURNING id',
        ['data-import-xlsx', JSON.stringify(payload)],
      );
      return result.rows[0].id;
    },
    getJob: async id => {
      const result = await pool.query(
        `SELECT id, queue, status, payload, result, error, created_at, updated_at
           FROM background_jobs WHERE id = $1`,
        [id],
      );
      return result.rows[0] || null;
    },
    claimJobForExecution: async id => {
      const result = await pool.query(
        `UPDATE background_jobs SET status = 'executing', updated_at = NOW()
          WHERE id = $1 AND queue = 'data-import-xlsx' AND status = 'completed'
          RETURNING id, queue, status, payload, result, error, lease_token, created_at, updated_at`,
        [id],
      );
      return result.rows[0] || null;
    },
    updateJob: async (id, status, result = null, error = null, leaseToken = null) => {
      const updated = await pool.query(
        `UPDATE background_jobs
            SET status = $2, result = $3, error = $4, updated_at = NOW()
          WHERE id = $1 AND status IN ('processing', 'executing')
            AND $5::uuid IS NOT NULL AND lease_token = $5::uuid
          RETURNING id`,
        [id, status, result ? JSON.stringify(result) : null, error, leaseToken],
      );
      return updated.rowCount > 0;
    },
  };
  const harness = await createDisposablePostgres(t, routeDependencies, { migrationPath: 'fresh' });
  pool = harness.pool;

  const unitId = USER.currentUnitId;
  const legalName = 'Razão Social da Unidade na Admissão XLSX';
  const replacementUnitId = '10000000-0000-4000-8000-000000000003';
  const secondUnitId = '10000000-0000-4000-8000-000000000004';
  const thirdUnitId = '10000000-0000-4000-8000-000000000005';
  const clientId = '10000000-0000-4000-8000-000000000006';
  const replacementClientId = '10000000-0000-4000-8000-000000000007';
  await pool.query(
    'INSERT INTO companies (id, razao_social, nome_fantasia) VALUES ($1, $2, $3)',
    [unitId, legalName, ''],
  );
  await pool.query(
    `INSERT INTO companies (id, razao_social, nome_fantasia)
     VALUES ($1, 'Segunda unidade XLSX', 'Unidade Secundária XLSX'),
            ($2, 'Terceira unidade XLSX', 'Unidade Terciária XLSX')`,
    [secondUnitId, thirdUnitId],
  );
  await pool.query(
    'INSERT INTO clients (id, name, document) VALUES ($1, $2, $3)',
    [clientId, 'Cliente da prévia da admissão', '00123456780'],
  );

  for (const [fantasyName, suffix, unitName, shouldResolve, changeAfterPreview, mode] of [
    ['', 'VAZIA', legalName, true],
    [null, 'NULA', legalName, true],
    [null, 'NAO-CADASTRADA', 'Unidade que não existe', false],
    [null, 'MISTO', legalName, true],
    ['Nome Fantasia Inicial', 'RENOMEADA', 'Nome Fantasia Inicial', true, 'renamed-and-reassigned'],
    ['Nome Fantasia Inicial', 'REATRIBUIDA-MULTI', 'Nome Fantasia Inicial', true, 'renamed-and-reassigned'],
    ['', 'CLIENTE-REATRIBUIDO', legalName, true, 'client-renamed-and-reassigned'],
    ['', 'REMOVIDA', legalName, true, 'deleted'],
    ['Nome Fantasia Inicial', 'RENOMEADA-CANCELA-TUDO', 'Nome Fantasia Inicial', true,
      'renamed-and-reassigned', 'abort_on_any_error'],
  ]) {
    await pool.query('DELETE FROM companies WHERE id = $1', [replacementUnitId]);
    await pool.query(
      `INSERT INTO companies (id, razao_social, nome_fantasia) VALUES ($1, $2, $3)
       ON CONFLICT (id) DO UPDATE SET razao_social = EXCLUDED.razao_social,
                                      nome_fantasia = EXCLUDED.nome_fantasia`,
      [unitId, legalName, fantasyName],
    );

    const contractNumber = `XLSX-ADMISSAO-UNIDADE-${suffix}`;
    const mixedBatch = suffix === 'MISTO';
    const multipleValidUnitsAfterChange = suffix === 'REATRIBUIDA-MULTI';
    const admissionRows = multipleValidUnitsAfterChange
      ? [
          { contract_number: `${contractNumber}-REATRIBUIDA`, unit_name: unitName },
          { contract_number: `${contractNumber}-SECUNDARIA`, unit_name: 'Unidade Secundária XLSX' },
          { contract_number: `${contractNumber}-TERCIARIA`, unit_name: 'Unidade Terciária XLSX' },
      ]
      : mixedBatch
        ? [
          { contract_number: `${contractNumber}-VALIDA`, unit_name: legalName },
          { contract_number: `${contractNumber}-INVALIDA`, unit_name: 'Unidade que não existe' },
        ]
        : [{ contract_number: contractNumber, client_name: 'Cliente da prévia da admissão', unit_name: unitName }];
    for (const row of admissionRows) row.client_name = 'Cliente da prévia da admissão';
    const workbook = new ExcelJS.Workbook();
    workbook.addWorksheet('Admissões').addRows([
      ['Número do Contrato', 'Nome do Cliente', 'Unidade'],
      ...admissionRows.map(row => [row.contract_number, row.client_name, row.unit_name]),
    ]);
    const bytes = Buffer.from(await workbook.xlsx.writeBuffer());
    const mapping = {
      admissions: [
        { fieldKey: 'contract_number', sheetColumn: 'Número do Contrato' },
        { fieldKey: 'client_name', sheetColumn: 'Nome do Cliente' },
        { fieldKey: 'unit_name', sheetColumn: 'Unidade' },
      ],
    };

    const upload = await fetch(`${harness.baseUrl}/api/import/upload`, {
      method: 'POST',
      headers: {
        'Content-Type': XLSX_MIME,
        'X-Import-Tables': JSON.stringify(['admissions']),
        'X-Import-Mapping': encodeImportMappingHeader(mapping),
        'X-Import-File-Name': encodeURIComponent(`admissao-unidade-${suffix.toLowerCase()}.xlsx`),
      },
      body: bytes,
    });
    assert.equal(upload.status, 202, await upload.clone().text());
    const { jobId } = await upload.json();

    const pending = await pool.query(
      'SELECT payload FROM background_jobs WHERE id = $1',
      [jobId],
    );
    assert.ok(pending.rows[0], 'o upload cria um job de preparação');
    const claimed = await pool.query(
      `UPDATE background_jobs
          SET status = 'processing', lease_token = gen_random_uuid(), updated_at = NOW()
        WHERE id = $1 AND status = 'pending'
        RETURNING lease_token`,
      [jobId],
    );
    assert.equal(claimed.rowCount, 1);

    await processDataImport({
      ...pending.rows[0].payload,
      _pgJobId: jobId,
      _pgLeaseToken: claimed.rows[0].lease_token,
    }, pool, {
      uploadImportObject: storeObject,
      downloadImportObject: readObject,
      deleteImportObject: deleteObject,
      updateJob: routeDependencies.updateJob,
      renewDataImportJobLease: async (id, token) => {
        const renewed = await pool.query(
          `UPDATE background_jobs SET updated_at = NOW()
            WHERE id = $1 AND status = 'processing' AND lease_token = $2::uuid
            RETURNING id`,
          [id, token],
        );
        return renewed.rows[0] || null;
      },
    });

    const preview = await fetch(`${harness.baseUrl}/api/import/job/${jobId}`);
    assert.equal(preview.status, 200);
    const previewResult = await preview.json();
    assert.equal(previewResult.status, 'completed');
    assert.deepEqual(
      previewResult.groups.map(group => [group.table, group.total, group.ok, group.error]),
      [[
        'admissions',
        admissionRows.length,
        mixedBatch ? 1 : (shouldResolve ? admissionRows.length : 0),
        mixedBatch ? 1 : (shouldResolve ? 0 : admissionRows.length),
      ]],
    );
    const admissionPreview = previewResult.groups.find(group => group.table === 'admissions');
    assert.deepEqual(
      admissionPreview.rows.map(row => row.status),
      mixedBatch
        ? ['ok', 'error']
        : Array(admissionRows.length).fill(shouldResolve ? 'ok' : 'error'),
      'a prévia deve mostrar o estado correto de cada admissão',
    );
    for (const row of admissionPreview.rows) {
      assert.equal(
        row.parentIds,
        undefined,
        'a identidade interna da unidade não deve ser exposta na prévia',
      );
    }
    const invalidPreviewRow = admissionPreview.rows.find(row => row.status === 'error');
    if (invalidPreviewRow) {
      assert.match(
        invalidPreviewRow.errors?.[0]?.message || '',
        /Unidade não encontrado/,
        'a prévia deve explicar que a unidade informada não está cadastrada',
      );
    }
    assert.equal(objects.size, 1, 'o worker remove o XLSX original e mantém somente os dados preparados');
    const preparedData = JSON.parse([...objects.values()][0].toString('utf8'));
    assert.deepEqual(
      preparedData.groups,
      [{
        table: 'admissions',
        rows: admissionRows,
      }],
      'a leitura e preparação do XLSX preservam o texto da unidade informado',
    );
    assert.deepEqual(
      preparedData.parentSnapshots.admissions.map(snapshot => snapshot?.unit_id),
      multipleValidUnitsAfterChange
        ? [unitId, secondUnitId, thirdUnitId]
        : (mixedBatch ? [unitId, undefined] : [shouldResolve ? unitId : undefined]),
      'os dados preparados preservam somente os IDs de unidade validados',
    );

    if (changeAfterPreview === 'renamed-and-reassigned') {
      await pool.query(
        'UPDATE companies SET nome_fantasia = $2 WHERE id = $1',
        [unitId, 'Unidade renomeada depois da prévia'],
      );
      await pool.query(
        'INSERT INTO companies (id, razao_social, nome_fantasia) VALUES ($1, $2, $3)',
        [replacementUnitId, 'Empresa substituta', unitName],
      );
    } else if (changeAfterPreview === 'deleted') {
      await pool.query('DELETE FROM companies WHERE id = $1', [unitId]);
    } else if (changeAfterPreview === 'client-renamed-and-reassigned') {
      await pool.query(
        'UPDATE clients SET name = $2 WHERE id = $1',
        [clientId, 'Cliente renomeado após a prévia'],
      );
      await pool.query(
        'INSERT INTO clients (id, name, document) VALUES ($1, $2, $3)',
        [replacementClientId, 'Cliente da prévia da admissão', '00987654320'],
      );
    }

    const execute = await fetch(`${harness.baseUrl}/api/import/execute`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        importJobId: jobId,
        stepUpToken: 'disposable-postgres-test',
        ...(mode ? { mode } : {}),
      }),
    });
    assert.equal(execute.status, 200, await execute.clone().text());
    const result = await execute.json();
    const shouldImport = shouldResolve && !changeAfterPreview;
    assert.equal(result.total, admissionRows.length, JSON.stringify(result));
    if (mode === 'abort_on_any_error') {
      assert.equal(result.aborted, true, JSON.stringify(result));
      assert.equal(result.inserted, 0, JSON.stringify(result));
      assert.equal(result.updated, 0, JSON.stringify(result));
      assert.equal(result.ignored, 0, JSON.stringify(result));
      assert.equal(result.inconsistent, 1, JSON.stringify(result));
      assert.ok(
        result.problems.some(problem =>
          problem.table === 'admissions'
          && problem.errors.some(error =>
            error.column === 'unit_name'
            && /unidade foi alterada desde a prévia/i.test(error.message || ''))),
        'a resposta de cancelamento deve identificar a unidade alterada desde a prévia',
      );
      assert.deepEqual(result.groups, [], 'nenhum grupo deve ser confirmado quando o lote é cancelado');
    } else {
      assert.equal(
        result.inserted,
        multipleValidUnitsAfterChange ? 2 : (mixedBatch ? 1 : (shouldImport ? 1 : 0)),
        JSON.stringify(result),
      );
      assert.equal(
        result.inconsistent,
        multipleValidUnitsAfterChange ? 1 : (mixedBatch ? 1 : (shouldImport ? 0 : 1)),
        JSON.stringify(result),
      );
    }
    if (changeAfterPreview && mode !== 'abort_on_any_error') {
      const expectedLinkError = changeAfterPreview === 'client-renamed-and-reassigned'
        ? /vínculo de "Cliente" mudou desde a prévia/i
        : /unidade foi alterada desde a prévia/i;
      const expectedErrorColumn = changeAfterPreview === 'client-renamed-and-reassigned'
        ? 'client_name'
        : 'unit_name';
      assert.ok(
        result.groups[0]?.errors[0]?.errors?.some(error =>
          error.column === expectedErrorColumn && expectedLinkError.test(error.message || '')),
        'a confirmação deve identificar o vínculo que mudou desde a prévia',
      );
    }

    if (multipleValidUnitsAfterChange) {
      const importedAdmissions = await pool.query(
        `SELECT contract_number, unit_id::text AS unit_id
           FROM admissions
          WHERE contract_number = ANY($1::text[])
          ORDER BY contract_number`,
        [admissionRows.map(row => row.contract_number)],
      );
      assert.deepEqual(
        importedAdmissions.rows,
        [
          { contract_number: admissionRows[1].contract_number, unit_id: secondUnitId },
          { contract_number: admissionRows[2].contract_number, unit_id: thirdUnitId },
        ],
        'a admissão reatribuída deve ser rejeitada e as outras devem ser gravadas com os IDs das unidades da prévia',
      );
      assert.deepEqual(
        {
          inserted: result.groups[0]?.inserted,
          inconsistent: result.groups[0]?.inconsistent,
          errorRows: result.groups[0]?.errors.map(error => error.row),
        },
        { inserted: 2, inconsistent: 1, errorRows: [1] },
        'os totais do grupo devem refletir duas admissões gravadas e uma unidade alterada',
      );
    } else if (mixedBatch) {
      const importedAdmissions = await pool.query(
        `SELECT contract_number, unit_id::text AS unit_id
           FROM admissions
          WHERE contract_number = ANY($1::text[])
          ORDER BY contract_number`,
        [admissionRows.map(row => row.contract_number)],
      );
      assert.deepEqual(
        importedAdmissions.rows,
        [{ contract_number: admissionRows[0].contract_number, unit_id: unitId }],
        'somente a admissão válida deve ser gravada e vinculada à unidade cadastrada',
      );
    } else {
      const importedAdmission = await pool.query(
        'SELECT unit_id::text AS unit_id FROM admissions WHERE contract_number = $1',
        [contractNumber],
      );
      assert.deepEqual(
        importedAdmission.rows,
        shouldImport && mode !== 'abort_on_any_error' ? [{ unit_id: unitId }] : [],
        shouldImport && mode !== 'abort_on_any_error'
          ? `a admissão deve receber o unit_id correto quando o nome fantasia é ${JSON.stringify(fantasyName)}`
          : 'a admissão não pode ser gravada quando o vínculo da unidade ficou ausente ou mudou após a prévia',
      );
    }
    assert.equal(objects.size, 0, 'os objetos temporários são removidos após a confirmação');
    // Each scenario reuses the same units. Remove only this scenario's disposable
    // admissions so the later "deleted after preview" case has an unreferenced
    // parent; deleting a unit still referenced by earlier cases is now forbidden.
    await pool.query('DELETE FROM admissions WHERE contract_number = ANY($1::text[])',
      [admissionRows.map(row => row.contract_number)]);
  }
});

test('a execução traduz erros de tamanho do banco e identifica todos os campos excedidos', {
  timeout: 120_000,
}, async t => {
  const { baseUrl, pool } = await createDisposablePostgres(t, {}, { migrationPath: 'fresh' });
  const rgAtLimit = '12345678901234567890123456789012345';
  assert.equal([...rgAtLimit].length, 35);

  const response = await fetch(`${baseUrl}/api/import/execute`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      stepUpToken: 'disposable-postgres-test',
      groups: [{
        table: 'clients',
        rows: [
          {
            name: 'Cliente com campos excedidos',
            document: '123456789012345678901',
            rg: '123456789012345678901234567890123456',
          },
          { name: 'Cliente com RG no limite', document: '00123456789', rg: rgAtLimit },
        ],
      }],
    }),
  });
  assert.equal(response.status, 200, await response.clone().text());
  const result = await response.json();
  assert.equal(result.inserted, 1, JSON.stringify(result));
  assert.equal(result.inconsistent, 1, JSON.stringify(result));
  const errors = result.groups[0].errors[0].errors;
  assert.deepEqual(errors.map(error => error.column), ['document', 'rg']);
  assert.match(errors[0].message, /excede o limite de 20 caracteres/i);
  assert.match(errors[1].message, /excede o limite de 35 caracteres/i);
  assert.ok(errors.every(error => !/value too long|character varying/i.test(error.message)));
  const imported = await pool.query('SELECT rg FROM clients WHERE name = $1', ['Cliente com RG no limite']);
  assert.equal(imported.rows[0].rg, rgAtLimit);
});

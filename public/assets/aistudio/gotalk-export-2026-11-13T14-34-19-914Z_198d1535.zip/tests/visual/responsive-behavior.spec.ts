import { expect, test } from '@playwright/test';
import {
  closeHelpIfOpen,
  expectNoPageClipping,
  mockApplication,
  openMobileMenuIfNeeded,
  RESPONSIVE_WIDTHS,
  visualUser,
} from './fixtures';

test.use({ video: 'off' });

test.describe('dimensões responsivas autorizadas', () => {
  test('Clientes mantém edição, tabela local e modal alcançáveis em celular e notebook', async ({ page }) => {
    const clientId = 'CLI-RESPONSIVE';
    const attachments = Array.from({ length: 18 }, (_, index) => ({
      id: `responsive-attachment-${index + 1}`,
      clientId,
      clientName: 'Cliente de Exemplo',
      originalFilename: `comprovante-responsivo-${String(index + 1).padStart(2, '0')}.txt`,
      mimeType: 'text/plain',
      fileSize: 1024,
      module: 'GENERAL',
      category: 'OUTRO',
      aclProtected: true,
    }));
    await mockApplication(page, 'light', true, 'institutional', {
      clients: [{
        id: clientId,
        name: 'Cliente de Exemplo',
        type: 'FISICA',
        natureza: 'C',
        document: '123.456.789-00',
        phone: '(11) 99999-0001',
        city: 'São Paulo',
        state: 'SP',
      }],
    });
    await page.route('**/api/client-attachments/**', route => {
      const path = new URL(route.request().url()).pathname;
      if (path === '/api/client-attachments/') {
        return route.fulfill({ json: { data: attachments, total: attachments.length } });
      }
      if (path.endsWith('/acl/options')) {
        return route.fulfill({ json: { data: { items: [], selected: [] } } });
      }
      if (path.endsWith(`/acl/legacy/${clientId}/impact`)) {
        return route.fulfill({ json: { data: { clientId, legacyCount: 0 } } });
      }
      return route.fulfill({ json: { data: {} } });
    });

    for (const viewport of [
      { width: 360, height: 640 },
      { width: 390, height: 844 },
      { width: 1280, height: 800 },
      { width: 1366, height: 768 },
    ]) {
      await page.setViewportSize(viewport);
      await page.goto('/', { waitUntil: 'domcontentloaded' });
      await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
      await closeHelpIfOpen(page);
      await openMobileMenuIfNeeded(page, viewport.width);

      const navigation = page.getByRole('navigation');
      await navigation.getByRole('button', { name: 'Cadastros Comuns', exact: true }).click();
      await navigation.getByRole('button', { name: 'Clientes', exact: true }).click();
      await expect(page.getByRole('heading', { name: 'Cadastro de Clientes' })).toBeVisible();
      const clientsTable = page.locator('table.operational-grid');
      const tableScroller = page.locator('.grid-body-scroll').filter({ has: clientsTable });
      await expect(clientsTable.getByRole('columnheader', { name: 'Descrição (Nome)' })).toBeVisible();
      await expect(tableScroller).toHaveCSS('overflow-x', 'auto');
      const tableMetrics = await tableScroller.evaluate(element => ({
        clientWidth: element.clientWidth,
        scrollWidth: element.scrollWidth,
      }));
      if (viewport.width === 360) expect(tableMetrics.scrollWidth).toBeGreaterThan(tableMetrics.clientWidth);
      await expectNoPageClipping(page);

      const clientRow = clientsTable.locator('tbody tr').filter({ hasText: 'Cliente de Exemplo' });
      await clientRow.getByRole('button', { name: 'Editar', exact: true }).click();
      await expect(page.getByRole('heading', { name: 'Editando Cliente' })).toBeVisible();
      await expect(page.getByText('01. Natureza', { exact: true })).toBeVisible();
      for (const label of ['02. Descrição (Nome / Razão Social)', '03. CPF', '05. Telefone *']) {
        const field = page.locator('label').filter({ hasText: label }).locator('..').locator('input');
        await expect(field).toBeVisible();
        const geometry = await field.boundingBox();
        expect(geometry!.x).toBeGreaterThanOrEqual(0);
        expect(geometry!.x + geometry!.width).toBeLessThanOrEqual(viewport.width);
      }
      await expectNoPageClipping(page);

      const save = page.getByRole('button', { name: /Salvar Alterações/ });
      await save.scrollIntoViewIfNeeded();
      await expect(save).toBeInViewport();
      await expect(page.getByText('17. Anotações', { exact: true })).toBeVisible();
      await expectNoPageClipping(page);
      await page.getByRole('button', { name: 'Voltar', exact: true }).scrollIntoViewIfNeeded();
      await page.getByRole('button', { name: 'Voltar', exact: true }).click();

      const rowAfterReturn = clientsTable.locator('tbody tr').filter({ hasText: 'Cliente de Exemplo' });
      await rowAfterReturn.getByRole('button', { name: 'Excluir', exact: true }).click();
      const dialog = page.getByRole('dialog', { name: 'Excluir cliente', exact: true });
      await expect(dialog).toBeVisible();
      await dialog.getByRole('tab', { name: 'Documentos', exact: true }).click();
      await expect(dialog.getByText('Documentos armazenados', { exact: true })).toBeVisible();
      await expect(dialog.getByText('comprovante-responsivo-18.txt', { exact: true })).toBeVisible();
      await expectNoPageClipping(page);

      const modalMetrics = await dialog.evaluate(element => ({
        clientHeight: element.clientHeight,
        scrollHeight: element.scrollHeight,
        overflowY: getComputedStyle(element).overflowY,
      }));
      expect(modalMetrics.overflowY).toMatch(/auto|scroll/);
      expect(modalMetrics.scrollHeight).toBeGreaterThan(modalMetrics.clientHeight);
      await dialog.evaluate(element => { element.scrollTop = element.scrollHeight; });
      const cancel = dialog.getByRole('button', { name: 'Cancelar', exact: true });
      await expect(cancel).toBeInViewport();
      await expectNoPageClipping(page);
      await cancel.click();
      await expect(dialog).not.toBeVisible();
    }
  });

  test('login permanece utilizável em todas as larguras requeridas', async ({ page }) => {
    await mockApplication(page, 'light', false);

    for (const width of RESPONSIVE_WIDTHS) {
      await page.setViewportSize({ width, height: width < 640 ? 720 : 800 });
      await page.goto('/');

      const email = page.getByPlaceholder('seu.nome@finance.com');
      await expect(email, `campo de login em ${width}px`).toBeVisible();
      await expect(email).toHaveCSS('min-height', /4[0-9]px|46px/);
      await expect(page.getByRole('region', { name: 'Desafio de seleção de fotos' })).toHaveCount(0);
      await expectNoPageClipping(page);
    }
  });

  test('desafio de fotos aparece na etapa 2FA após o captcha e as credenciais', async ({ page }) => {
    await mockApplication(page, 'light', false);
    const challenge = {
      id: 'login-mfa-photo-test',
      instruction: 'Selecione todas as fotos de teste.',
      images: Array.from({ length: 9 }, (_, index) => ({
        id: `login-mfa-photo-${index + 1}`,
        src: `/challenge-photos/photo-${String(index + 1).padStart(2, '0')}.jpg`,
      })),
    };
    let mfaRequest: Record<string, unknown> | null = null;

    await page.route('**/api/auth/login', route => route.fulfill({
      json: {
        mfaRequired: true, mfaToken: 'pending-mfa-test', photoChallenge: challenge,
        attemptNumber: 1, maxAttempts: 3, expiresAt: '2026-09-19T14:32:00-03:00',
      },
    }));
    let mfaCalls = 0;
    await page.route('**/api/auth/mfa/verify', async route => {
      mfaRequest = route.request().postDataJSON() as Record<string, unknown>;
      mfaCalls += 1;
      if (mfaCalls > 1) {
        await route.fulfill({ json: { user: { ...visualUser('light'), allowedUnitIds: [] } } });
        return;
      }
      await route.fulfill({ status: 401, json: {
        error: 'DESAFIO_FOTOS_INVALIDO', mfaToken: 'pending-mfa-test-2', photoChallenge: challenge,
        attemptNumber: 2, maxAttempts: 3, expiresAt: '2026-09-19T14:32:00-03:00',
      } });
    });

    await page.goto('/');
    await page.getByPlaceholder('seu.nome@finance.com').fill('admin@example.test');
    await page.locator('input[type="password"]').fill('Senha-Teste-2026!');
    await page.getByPlaceholder('?').fill('2');
    await expect(page.getByRole('region', { name: 'Desafio de seleção de fotos' })).toHaveCount(0);
    await page.getByRole('button', { name: 'Entrar' }).click();

    await expect(page.getByText('Verificação em dois fatores ativa')).toBeVisible();
    const photoRegion = page.getByRole('region', { name: 'Desafio de fotos para concluir o login' });
    await expect(photoRegion).toBeVisible();
    for (let index = 1; index <= 2; index += 1) {
      await photoRegion.getByRole('button', { name: `Imagem candidata ${index}` }).click();
    }
    await expect(page.locator('input[autocomplete="one-time-code"]')).toHaveCount(0);
    await expect(page.getByRole('checkbox', { name: 'Sou Humano', exact: true })).not.toBeChecked();
    await expect(page.getByRole('checkbox', { name: 'Sou Humano', exact: true })).toBeDisabled();
    await page.waitForTimeout(500);
    expect(mfaCalls).toBe(0);
    await photoRegion.getByRole('button', { name: 'Imagem candidata 3', exact: true }).click();
    await photoRegion.getByRole('button', { name: 'Imagem candidata 3', exact: true }).click();
    await page.waitForTimeout(500);
    expect(mfaCalls).toBe(0);
    await photoRegion.getByRole('button', { name: 'Imagem candidata 3', exact: true }).click();
    await expect(page.getByText('Seleção de fotos inválida. A tentativa foi registrada e o desafio foi atualizado.')).toBeVisible();
    await expect(page.getByText('Tentativa 2 de 3', { exact: true })).toBeVisible();
    expect(mfaRequest).toMatchObject({
      mfaToken: 'pending-mfa-test',
      photoChallengeId: 'login-mfa-photo-test',
      photoSelections: ['login-mfa-photo-1', 'login-mfa-photo-2', 'login-mfa-photo-3'],
    });
    expect(mfaRequest).not.toHaveProperty('token');
    for (let index = 1; index <= 3; index += 1) {
      await photoRegion.getByRole('button', { name: `Imagem candidata ${index}` }).click();
    }
    await expect(page.getByRole('checkbox', { name: 'Sou Humano', exact: true })).toBeChecked();
    await expect(page.locator('.login-panel-content')).toHaveCount(0);
    await expect(page.getByRole('button', { name: 'SAIR', exact: true })).toBeVisible();
    expect(mfaCalls).toBe(2);
  });

  test('login desktop cabe inteiro sem barras internas em alturas usuais', async ({ page }) => {
    await mockApplication(page, 'light', false);

    for (const viewport of [
      { width: 1024, height: 768 },
      { width: 1366, height: 768 },
      { width: 1440, height: 900 },
    ]) {
      await page.setViewportSize(viewport);
      await page.goto('/');
      const login = page.locator('.login-panel-content');
      await expect(login).toBeVisible();
      await expect(page.getByRole('heading', { name: 'Acesso ao Sistema' })).toBeInViewport();
      await expect(page.getByPlaceholder('seu.nome@finance.com')).toBeInViewport();
      await expect(page.getByRole('button', { name: /entrar/i })).toBeInViewport();
      const metrics = await login.evaluate(el => ({
        clientHeight: el.clientHeight,
        scrollHeight: el.scrollHeight,
        overflowY: getComputedStyle(el).overflowY,
      }));
      expect(metrics.scrollHeight).toBeLessThanOrEqual(metrics.clientHeight + 1);
      expect(metrics.overflowY).not.toMatch(/auto|scroll/);
    }
  });

  test('login mobile mantém campos visíveis e pode rolar somente a página', async ({ page }) => {
    await mockApplication(page, 'light', false);
    await page.setViewportSize({ width: 390, height: 800 });
    await page.goto('/');
    await expect(page.getByPlaceholder('seu.nome@finance.com')).toBeVisible();
    await expect(page.getByPlaceholder('seu.nome@finance.com')).toHaveCSS('font-size', '16px');
    await expect(page.getByRole('button', { name: /entrar/i })).toBeVisible();
  });

  test('shell autenticado usa densidade mensurável sem perder alvos de toque', async ({ page }) => {
    await mockApplication(page, 'light');
    await page.setViewportSize({ width: 1366, height: 768 });
    await page.goto('/');

    const shell = page.locator('[data-visual-shell="true"]');
    const main = page.locator('.dashboard-main');
    const topbar = page.locator('.dashboard-topbar');
    const sidebar = page.locator('.dashboard-sidebar');
    await expect(shell).toBeVisible();
    await expect(main).toBeVisible();

    await expect.poll(() => main.evaluate(el => getComputedStyle(el).paddingTop)).toBe('20px');
    await expect.poll(() => topbar.evaluate(el => el.getBoundingClientRect().height)).toBe(52);
    await expect.poll(() => sidebar.evaluate(el => el.getBoundingClientRect().width)).toBe(256);
    const controls = await topbar.locator('button:visible').evaluateAll(buttons =>
      buttons.map(button => button.getBoundingClientRect().height),
    );
    expect(controls.length).toBeGreaterThan(0);
    expect(Math.min(...controls)).toBeGreaterThanOrEqual(40);

    await page.setViewportSize({ width: 1366, height: 720 });
    await expect.poll(() => main.evaluate(el => getComputedStyle(el).paddingTop)).toBe('16px');
    await expect.poll(() => topbar.evaluate(el => el.getBoundingClientRect().height)).toBe(48);
  });

  test('preferências de largura e altura são independentes e restauráveis', async ({ page }) => {
    await mockApplication(page, 'light');
    await page.setViewportSize({ width: 1366, height: 768 });
    await page.goto('/');

    const main = page.locator('.dashboard-main');
    const topbar = page.locator('.dashboard-topbar');
    await page.getByTitle('Preferências visuais').click();

    const width = page.getByRole('slider', { name: 'Largura' });
    const height = page.getByRole('slider', { name: 'Altura' });
    await expect(width).toHaveValue('100');
    await expect(height).toHaveValue('100');

    await width.fill('115');
    await expect(page.locator('html')).toHaveAttribute('data-width-scale', '115');
    await expect(page.locator('html')).toHaveAttribute('data-height-scale', '100');
    await expect.poll(() => main.evaluate(el => getComputedStyle(el).paddingLeft)).toBe('23px');
    await expect.poll(() => topbar.evaluate(el => el.getBoundingClientRect().height)).toBe(52);

    await height.fill('85');
    await expect(page.locator('html')).toHaveAttribute('data-width-scale', '115');
    await expect(page.locator('html')).toHaveAttribute('data-height-scale', '85');
    await expect.poll(() => topbar.evaluate(el => el.getBoundingClientRect().height)).toBeCloseTo(44.2, 1);

    await page.getByRole('button', { name: 'Restaurar dimensões' }).click();
    await expect(width).toHaveValue('100');
    await expect(height).toHaveValue('100');
    await expect(page.locator('html')).toHaveAttribute('data-width-scale', '100');
    await expect(page.locator('html')).toHaveAttribute('data-height-scale', '100');
  });

  test('escala de grades exige opt-in e preserva tabelas compactas', async ({ page }) => {
    await mockApplication(page, 'light');
    await page.setViewportSize({ width: 1366, height: 768 });
    await page.goto('/');
    await page.locator('[data-visual-shell="true"]').evaluate(shell => {
      shell.insertAdjacentHTML('beforeend', `
        <style>.test-compact-cell { padding: 8px 12px; }</style>
        <table data-testid="compact-grid" class="operational-grid"><tbody><tr><td class="test-compact-cell">Compacta</td></tr></tbody></table>
        <table data-testid="scaled-grid" class="operational-grid visual-dimension-grid"><tbody><tr><td class="test-compact-cell">Escalonada</td></tr></tbody></table>
        <table data-testid="data-grid-typography" class="data-grid-typography"><tbody><tr><td class="text-sm">Dados</td></tr></tbody></table>
      `);
    });

    const compactCell = page.locator('[data-testid="compact-grid"] td');
    const scaledCell = page.locator('[data-testid="scaled-grid"] td');
    const dataGridCell = page.locator('[data-testid="data-grid-typography"] td');
    await expect(compactCell).toHaveCSS('padding-left', '12px');
    await expect(compactCell).toHaveCSS('padding-top', '8px');
    await expect(scaledCell).toHaveCSS('padding-left', '24px');
    await expect(scaledCell).toHaveCSS('padding-top', '12px');
    await expect(scaledCell).toHaveCSS('font-family', 'Arial, sans-serif');
    await expect(scaledCell).toHaveCSS('font-size', '12px');
    await expect(dataGridCell).toHaveCSS('font-family', 'Arial, sans-serif');
    await expect(dataGridCell).toHaveCSS('font-size', '12px');

    await page.getByTitle('Preferências visuais').click();
    await page.getByRole('slider', { name: 'Largura' }).fill('115');
    await page.getByRole('slider', { name: 'Altura' }).fill('85');
    await expect(compactCell).toHaveCSS('padding-left', '12px');
    await expect(compactCell).toHaveCSS('padding-top', '8px');
    await expect(scaledCell).toHaveCSS('padding-left', '27.6px');
    await expect(scaledCell).toHaveCSS('padding-top', '10.2px');
  });

  test('grids e modais de dados acompanham o recolhimento do menu e o rodapé não quebra rótulos', async ({ page }) => {
    await mockApplication(page, 'light');
    await page.setViewportSize({ width: 2400, height: 900 });
    await page.goto('/', { waitUntil: 'domcontentloaded' });

    const shell = page.locator('[data-visual-shell="true"]');
    await shell.evaluate(element => {
      const sidebar = element.querySelector<HTMLElement>('.dashboard-sidebar')!;
      const main = element.querySelector<HTMLElement>('.dashboard-main')!;
      sidebar.style.width = '256px';
      sidebar.style.flex = '0 0 256px';
      element.setAttribute('data-sidebar-collapsed', 'false');
      main.insertAdjacentHTML('beforeend', `
        <section data-testid="grid-width-probe" data-grid-density="compact" style="width:100%">
          <table class="data-grid-typography"><tbody><tr><td>Dados</td></tr></tbody></table>
          <div data-testid="grid-footer-probe" data-pagination="compact" class="flex items-center justify-between" style="width:520px">
            <div data-pagination-layout class="flex items-center justify-between gap-3">
              <div class="flex items-center gap-4">
                <p data-pagination-summary>Mostrando 1 a 8 de 8 registros</p>
                <div data-pagination-page-size class="flex items-center gap-2">
                  <span data-pagination-page-size-label>Exibir:</span>
                  <select data-pagination-page-size-select class="w-16"><option>10</option></select>
                </div>
              </div>
              <div data-pagination-controls class="flex items-center gap-1">
                <button>‹</button><button>1</button><button>›</button>
              </div>
            </div>
          </div>
        </section>
        <section data-testid="financial-width-probe" class="financial-management-dashboard" style="width:100%">
          <div>Gerenciamento Financeiro</div>
        </section>
      `);
      const modal = document.createElement('div');
      modal.dataset.testid = 'grid-modal-width-probe';
      modal.dataset.gridModalSize = '2xl';
      modal.className = 'w-full max-w-2xl';
      modal.style.position = 'fixed';
      modal.style.width = '100%';
      element.appendChild(modal);
    });

    const grid = page.getByTestId('grid-width-probe');
    const financialScreen = page.getByTestId('financial-width-probe');
    const modal = page.getByTestId('grid-modal-width-probe');
    const initialGridWidth = await grid.evaluate(element => Math.round(element.getBoundingClientRect().width));
    const initialFinancialWidth = await financialScreen.evaluate(element => Math.round(element.getBoundingClientRect().width));
    const initialModalMaxWidth = await modal.evaluate(element => parseFloat(getComputedStyle(element).maxWidth));
    expect(initialModalMaxWidth).toBe(672);

    await shell.evaluate(element => {
      const sidebar = element.querySelector<HTMLElement>('.dashboard-sidebar')!;
      sidebar.style.width = '64px';
      sidebar.style.flex = '0 0 64px';
      element.setAttribute('data-sidebar-collapsed', 'true');
    });

    await expect.poll(
      () => grid.evaluate(element => Math.round(element.getBoundingClientRect().width)),
    ).toBe(initialGridWidth + 192);
    await expect.poll(
      () => financialScreen.evaluate(element => Math.round(element.getBoundingClientRect().width)),
    ).toBe(initialFinancialWidth + 192);
    await expect.poll(
      () => modal.evaluate(element => parseFloat(getComputedStyle(element).maxWidth)),
    ).toBe(initialModalMaxWidth + 192);
    await expect(page.locator('[data-pagination-summary]')).toHaveCSS('white-space', 'nowrap');
    await expect(page.locator('[data-pagination-page-size-label]')).toHaveCSS('white-space', 'nowrap');
    await expect(page.locator('[data-pagination-page-size-select]')).toHaveCSS('width', '64px');
    await expect(page.getByTestId('grid-footer-probe')).toHaveCSS('min-height', '44px');
  });

  test('Gerenciamento Financeiro soma saldos textuais e mantém rótulos e valores dentro dos cartões', async ({ page }) => {
    await mockApplication(page, 'light');
    await page.setViewportSize({ width: 1024, height: 800 });

    const receivableTitles = [
      {
        id: 'visual-title-1',
        description: 'Título visual 1',
        categoryId: 'visual-category',
        documentTypeId: 'visual-document',
        bearerId: 'visual-bearer',
        status: 'ABERTO',
        clientId: 'visual-client',
        clientName: 'Cliente Visual',
        issueDate: '2026-08-01',
        dueDate: '2026-08-15',
        originalValue: '1.234,56',
        currentBalance: '1.234,56',
        documentNumber: 'VIS-001',
        source: 'FINANCEIRO',
        type: 'RECEBER',
        titleScope: 'RECEBER',
      },
      {
        id: 'visual-title-2',
        description: 'Título visual 2',
        categoryId: 'visual-category',
        documentTypeId: 'visual-document',
        bearerId: 'visual-bearer',
        status: 'PARCIAL',
        clientId: 'visual-client',
        clientName: 'Cliente Visual',
        issueDate: '2026-09-01',
        dueDate: '2026-10-01',
        originalValue: '388.89',
        currentBalance: '388.89',
        documentNumber: 'VIS-002',
        source: 'FINANCEIRO',
        type: 'RECEBER',
        titleScope: 'RECEBER',
      },
    ];
    await page.route('**/api/financial-titles**', route => route.fulfill({
      json: { data: receivableTitles, total: receivableTitles.length, page: 1, totalPages: 1 },
    }));

    await page.goto('/', { waitUntil: 'commit' });
    await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
    const navigation = page.getByRole('navigation');
    await navigation.getByRole('button', { name: 'Financeiro', exact: true }).click();
    await navigation.getByRole('button', { name: 'Gerenciamento', exact: true }).click();

    const dashboard = page.locator('.financial-management-dashboard');
    await expect(dashboard).toBeVisible();
    const receivableCard = dashboard.getByText('A Receber (Aberto)', { exact: true }).locator('xpath=../..');
    const overdueCard = dashboard.getByText('Vencidos', { exact: true }).first().locator('xpath=../..');
    const receivableAmount = receivableCard.locator('p').nth(1);
    await expect(receivableAmount).toHaveText('1.623,45');
    await expect(overdueCard.locator('p').nth(1)).toHaveText('1.234,56');

    const amountMetrics = await receivableAmount.evaluate(element => ({
      scrollWidth: element.scrollWidth,
      clientWidth: element.clientWidth,
    }));
    expect(amountMetrics.scrollWidth).toBeLessThanOrEqual(amountMetrics.clientWidth);

    for (const label of ['Resumo', 'Extrato Geral', 'Indicadores']) {
      const tab = dashboard.getByRole('button', { name: label, exact: true });
      await expect(tab).toHaveCSS('white-space', 'nowrap');
      const tabMetrics = await tab.evaluate(element => ({
        scrollWidth: element.scrollWidth,
        clientWidth: element.clientWidth,
      }));
      expect(tabMetrics.scrollWidth, `rótulo da aba ${label}`).toBeLessThanOrEqual(tabMetrics.clientWidth);
    }
  });

  test('Gráficos Financeiros aplicam filtros e permitem selecionar os visuais', async ({ page }) => {
    test.setTimeout(90_000);
    await mockApplication(page, 'light', true, 'institutional', {
      bankAccounts: [
        { id: 'ACCOUNT-001', description: 'Conta Principal', currentBalance: '5.000,00' },
        { id: 'ACCOUNT-002', description: 'Conta Secundária', currentBalance: '3.000,00' },
        { id: 'ACCOUNT-003', description: 'Conta com movimentos internos', currentBalance: '0,00' },
      ],
    });
    await page.setViewportSize({ width: 1024, height: 800 });

    const receivableTitles = [
      {
        id: 'chart-title-open',
        description: 'Título em aberto',
        categoryId: 'visual-category',
        documentTypeId: 'visual-document',
        bearerId: 'visual-bearer',
        status: 'ABERTO',
        clientId: 'CLI-001',
        clientName: 'Cliente de Exemplo',
        issueDate: '2026-09-01',
        dueDate: '2026-09-15',
        originalValue: '1.000,00',
        currentBalance: '1.000,00',
        documentNumber: 'CHART-001',
        source: 'MANUAL',
        type: 'PADRAO',
        titleScope: 'RECEBER',
        bankAccountId: 'ACCOUNT-001',
      },
      {
        id: 'chart-title-paid',
        description: 'Título liquidado',
        categoryId: 'visual-category',
        documentTypeId: 'visual-document',
        bearerId: 'visual-bearer',
        status: 'PAGO',
        clientId: 'CLI-002',
        clientName: 'Empresa Demonstração',
        issueDate: '2026-09-01',
        dueDate: '2026-09-18',
        originalValue: '700,00',
        currentBalance: '0,00',
        documentNumber: 'CHART-002',
        source: 'MANUAL',
        type: 'PADRAO',
        titleScope: 'RECEBER',
        bankAccountId: 'ACCOUNT-001',
      },
    ];
    const movements = [
      {
        id: 'chart-movement-credit',
        date: '2026-09-10',
        description: 'Entrada de teste',
        value: '1.000,00',
        type: 'CREDITO',
        origin: 'BAIXA_RECEBER',
        bankAccountId: 'ACCOUNT-001',
        titleId: 'chart-title-open',
      },
      {
        id: 'chart-movement-debit',
        date: '2026-09-11',
        description: 'Saída de teste',
        value: '250,00',
        type: 'DEBITO',
        origin: 'BAIXA_PAGAR',
        bankAccountId: 'ACCOUNT-001',
        titleId: 'chart-title-open',
      },
      {
        id: 'chart-movement-second-account',
        date: '2026-09-10',
        description: 'Entrada em outra conta',
        value: '9.000,00',
        type: 'CREDITO',
        origin: 'BAIXA_RECEBER',
        bankAccountId: 'ACCOUNT-002',
        titleId: 'chart-title-paid',
      },
      {
        id: 'chart-movement-transfer-out',
        date: '2026-09-10',
        description: 'Transferência de saída',
        value: '400,00',
        type: 'DEBITO',
        origin: 'TRANSFERENCIA',
        bankAccountId: 'ACCOUNT-003',
      },
      {
        id: 'chart-movement-transfer-in',
        date: '2026-09-10',
        description: 'Transferência de entrada',
        value: '400,00',
        type: 'CREDITO',
        origin: 'TRANSFERENCIA',
        bankAccountId: 'ACCOUNT-002',
      },
      {
        id: 'chart-movement-deposit',
        date: '2026-09-10',
        description: 'Depósito interno',
        value: '300,00',
        type: 'CREDITO',
        origin: 'DEPOSITO',
        bankAccountId: 'ACCOUNT-003',
      },
      {
        id: 'chart-movement-withdrawal',
        date: '2026-09-10',
        description: 'Saque',
        value: '100,00',
        type: 'DEBITO',
        origin: 'SAQUE',
        bankAccountId: 'ACCOUNT-003',
      },
    ];

    await page.route('**/api/financial-titles**', route => route.fulfill({
      json: { data: receivableTitles, total: receivableTitles.length, page: 1, totalPages: 1 },
    }));
    await page.route('**/api/bank-movements**', route => route.fulfill({
      json: { data: movements, total: movements.length, page: 1, totalPages: 1 },
    }));

    await page.goto('/', { waitUntil: 'commit' });
    await expect(page.locator('[data-visual-shell="true"]')).toBeVisible({ timeout: 30_000 });
    const navigation = page.getByRole('navigation');
    await navigation.getByRole('button', { name: 'Financeiro', exact: true }).click();
    await navigation.getByRole('button', { name: 'Gerenciamento', exact: true }).click();

    const dashboard = page.locator('.financial-management-dashboard');
    await dashboard.getByRole('button', { name: 'Gráficos Financeiros', exact: true }).click();
    await expect(dashboard.getByRole('heading', { name: 'Filtros dos gráficos' })).toBeVisible();

    const accountFilter = dashboard.getByLabel('Conta bancária');
    await expect(accountFilter).toBeVisible();
    await expect(accountFilter.locator('option').first()).toHaveText('Todas as contas');
    const kpis = dashboard.locator('[aria-label="Indicadores financeiros"]');
    const inflows = kpis.locator('article').filter({ hasText: 'Entradas bancárias' });
    const outflows = kpis.locator('article').filter({ hasText: 'Saídas bancárias' });

    await expect(inflows.locator('p').nth(1)).toHaveText('10.700,00');
    await expect(outflows.locator('p').nth(1)).toHaveText('750,00');

    const clientFilter = dashboard.getByLabel('Cliente');
    await clientFilter.selectOption('CLI-001');
    await expect(inflows.locator('p').nth(1)).toHaveText('1.000,00');
    await expect(outflows.locator('p').nth(1)).toHaveText('250,00');
    await clientFilter.selectOption('CLI-002');
    await expect(inflows.locator('p').nth(1)).toHaveText('9.000,00');
    await expect(outflows.locator('p').nth(1)).toHaveText('0,00');
    await clientFilter.selectOption('');

    const statusFilter = dashboard.getByLabel('Situação do título');
    await statusFilter.selectOption('PAGO');
    await expect(inflows.locator('p').nth(1)).toHaveText('9.000,00');
    await expect(outflows.locator('p').nth(1)).toHaveText('0,00');
    await statusFilter.selectOption('ABERTO');
    await expect(inflows.locator('p').nth(1)).toHaveText('1.000,00');
    await expect(outflows.locator('p').nth(1)).toHaveText('250,00');
    await statusFilter.selectOption('');

    await accountFilter.selectOption('ACCOUNT-002');
    await expect(inflows.locator('p').nth(1)).toHaveText('9.400,00');
    await expect(outflows.locator('p').nth(1)).toHaveText('0,00');

    await accountFilter.selectOption('ACCOUNT-001');
    await clientFilter.selectOption('CLI-001');
    await statusFilter.selectOption('ABERTO');

    await expect(inflows.locator('p').nth(1)).toHaveText('1.000,00');
    await expect(outflows.locator('p').nth(1)).toHaveText('250,00');
    await expect(kpis.locator('article').filter({ hasText: 'Resultado do período' }).locator('p').nth(1)).toHaveText('750,00');
    await expect(kpis.locator('article').filter({ hasText: 'A receber em aberto' }).locator('p').nth(1)).toHaveText('1.000,00');
    await expect(kpis.locator('article').filter({ hasText: 'Saldo atual em contas' }).locator('p').nth(1)).toHaveText('5.000,00');
    await expect(dashboard.locator('canvas')).toHaveCount(6);
    const pieCard = dashboard.getByRole('heading', { name: 'Títulos a receber por situação' }).locator('xpath=../../..');
    await expect(pieCard).toContainText('1 ·');
    await expect(pieCard).toContainText('1.000,00');
    const flowCard = dashboard.getByRole('heading', { name: 'Composição do fluxo' }).locator('xpath=../../..');
    await expect(flowCard.getByText('1.250,00', { exact: false })).toBeVisible();

    await dashboard.getByLabel('Período').selectOption('custom');
    await dashboard.getByRole('textbox', { name: 'De' }).fill('2026-09-10');
    await dashboard.getByRole('textbox', { name: 'Até' }).fill('2026-09-10');
    await expect(outflows.locator('p').nth(1)).toHaveText('0,00');

    const pieToggle = dashboard.getByRole('button', { name: 'Gráfico de pizza' });
    await expect(pieToggle).toHaveAttribute('aria-pressed', 'true');
    await pieToggle.click();
    await expect(pieToggle).toHaveAttribute('aria-pressed', 'false');
    await expect(dashboard.getByRole('heading', { name: 'Títulos a receber por situação' })).toBeHidden();
    await expect(dashboard.getByRole('heading', { name: 'Entradas, saídas e resultado' })).toBeVisible();

    await clientFilter.selectOption('');
    await statusFilter.selectOption('');
    await accountFilter.selectOption('ACCOUNT-003');
    await expect(inflows.locator('p').nth(1)).toHaveText('300,00');
    await expect(outflows.locator('p').nth(1)).toHaveText('500,00');
    const operationalChart = dashboard.getByRole('heading', { name: 'Receitas e despesas operacionais ao longo do tempo' }).locator('xpath=../../..');
    await expect(operationalChart).toContainText('Nenhuma receita ou despesa operacional no recorte selecionado.');
  });

  test('isolamento de seletores preserva tabelas estáticas dentro de uma grade compacta', async ({ page }) => {
    await mockApplication(page, 'light');
    await page.setViewportSize({ width: 1366, height: 768 });
    await page.goto('/');
    await page.locator('[data-visual-shell="true"]').evaluate(shell => {
      shell.insertAdjacentHTML('beforeend', `
        <div data-grid-density="compact">
          <table data-testid="isolation-operational" class="operational-grid"><tbody><tr><td>
            Operacional
            <div data-testid="nested-modal">
              <table style="font-size: 11px; font-family: serif"><tbody><tr><td style="padding: 20px 18px">Modal</td></tr></tbody></table>
              <button style="height: 24px; min-height: 24px">Fechar</button>
            </div>
          </td></tr></tbody></table>
          <table data-testid="isolation-static" data-grid-variant="static-preview" style="font-size: 13px; font-family: serif"><tbody><tr><td style="padding: 20px 18px">Relatório</td></tr></tbody></table>
          <table data-testid="isolation-preserved" class="operational-grid" data-grid-typography="preserve" style="font-size: 13px; font-family: serif"><tbody><tr><td>Formulário</td></tr></tbody></table>
          <div class="grid-search"><input data-testid="compact-search" placeholder="Buscar registros"></div>
          <input data-testid="outside-search" style="border: 2px solid red" placeholder="Busca externa">
        </div>
      `);
    });

    const operationalCell = page.locator('[data-testid="isolation-operational"] > tbody > tr > td');
    await expect(operationalCell).toHaveCSS('font-family', 'Arial, sans-serif');
    await expect(operationalCell).toHaveCSS('font-size', '12px');
    await expect(operationalCell).toHaveCSS('padding-left', '6.4px');
    await expect(page.locator('[data-testid="isolation-static"] td')).toHaveCSS('font-size', '13px');
    await expect(page.locator('[data-testid="isolation-static"] td')).toHaveCSS('padding-left', '18px');
    await expect(page.locator('[data-testid="isolation-static"] td')).toHaveCSS('padding-top', '20px');
    await expect(page.locator('[data-testid="isolation-preserved"] td')).toHaveCSS('font-size', '13px');
    await expect(page.locator('[data-testid="isolation-preserved"] td')).toHaveCSS('font-family', 'serif');
    await expect(page.locator('[data-testid="nested-modal"] td')).toHaveCSS('font-size', '11px');
    await expect(page.locator('[data-testid="nested-modal"] td')).toHaveCSS('padding-left', '18px');
    await expect(page.locator('[data-testid="nested-modal"] button')).toHaveCSS('min-height', '24px');
    await expect(page.getByTestId('compact-search')).toHaveCSS('border-left-width', '0px');
    await page.getByTestId('compact-search').focus();
    await expect(page.getByTestId('compact-search')).toHaveCSS('outline-width', '2px');
    await expect(page.getByTestId('outside-search')).toHaveCSS('border-left-width', '2px');
  });

  test('contrato de grade virtual compacta mantém texto, rolagem e alvo móvel', async ({ page }) => {
    await mockApplication(page, 'light');
    await page.setViewportSize({ width: 390, height: 800 });
    await page.goto('/');
    await page.locator('[data-visual-shell="true"]').evaluate(shell => {
      shell.insertAdjacentHTML('beforeend', `
        <div data-grid-density="compact" class="compact-virtual-grid" data-testid="virtual-contract">
          <div class="compact-virtual-row"><div role="button" tabindex="0" class="compact-grid-sort-control" data-testid="virtual-sort">Ordenar</div></div>
          <div class="grid-body-scroll" style="position: relative; height: 80px">
            <div class="compact-virtual-row" data-testid="virtual-row-one" style="position: absolute; top: 0; height: 40px"><span class="text-sm" data-testid="virtual-cell">Item com texto longo que deve permanecer em uma linha</span><button data-testid="virtual-action">Editar</button><span><label class="compact-checkbox-target" data-testid="virtual-checkbox-target"><input type="checkbox" aria-label="Selecionar item"></label></span><span data-testid="nested-actions"><div><button>1</button><button>2</button><button>3</button><button data-testid="last-nested-action">4</button></div></span></div>
            <div class="compact-virtual-row" data-testid="virtual-row-two" style="position: absolute; top: 40px; height: 40px"><span>Segundo item</span></div>
          </div>
          <div data-pagination="compact"><button>1</button></div>
        </div>
      `);
    });
    const grid = page.getByTestId('virtual-contract');
    await expect(grid.locator('.grid-body-scroll')).toHaveCSS('overflow-y', 'auto');
    await expect(page.getByTestId('virtual-cell')).toHaveCSS('font-family', 'Arial, sans-serif');
    await expect(page.getByTestId('virtual-cell')).toHaveCSS('font-size', '12px');
    await expect(page.getByTestId('virtual-cell')).toHaveCSS('white-space', 'nowrap');
    await expect(page.getByTestId('virtual-row-one')).toHaveCSS('height', '40px');
    const geometry = await grid.evaluate(el => {
      const first = el.querySelector('[data-testid="virtual-row-one"]')!.getBoundingClientRect();
      const second = el.querySelector('[data-testid="virtual-row-two"]')!.getBoundingClientRect();
      const action = el.querySelector('[data-testid="virtual-action"]')!.getBoundingClientRect();
      const checkbox = el.querySelector('[data-testid="virtual-checkbox-target"]')!.getBoundingClientRect();
      const nested = el.querySelector('[data-testid="nested-actions"]')!.getBoundingClientRect();
      const lastNestedAction = el.querySelector('[data-testid="last-nested-action"]')!.getBoundingClientRect();
      const sort = el.querySelector('[data-testid="virtual-sort"]')!.getBoundingClientRect();
      return { firstBottom: first.bottom, secondTop: second.top, actionWidth: action.width, actionHeight: action.height, checkboxWidth: checkbox.width, checkboxHeight: checkbox.height, nestedRight: nested.right, lastNestedRight: lastNestedAction.right, sortHeight: sort.height };
    });
    expect(geometry.firstBottom).toBe(geometry.secondTop);
    expect(geometry.actionWidth).toBeGreaterThanOrEqual(40);
    expect(geometry.actionHeight).toBeGreaterThanOrEqual(40);
    expect(geometry.checkboxWidth).toBeGreaterThanOrEqual(40);
    expect(geometry.checkboxHeight).toBeGreaterThanOrEqual(40);
    expect(geometry.nestedRight).toBeGreaterThanOrEqual(geometry.lastNestedRight);
    expect(geometry.sortHeight).toBeGreaterThanOrEqual(40);
    await expect(grid.locator('[data-pagination="compact"]')).toBeVisible();
  });

  test('cadastro de cargos usa grade compacta com rolagem própria e paginação visível', async ({ page }) => {
    await mockApplication(page, 'light');
    await page.setViewportSize({ width: 1366, height: 768 });
    await page.goto('/');
    await page.getByRole('button', { name: 'Cadastros Comuns', exact: true }).click();
    await page.getByRole('button', { name: 'Cargos', exact: true }).click();

    const panel = page.locator('[data-grid-density="compact"]');
    await expect(panel).toBeVisible();
    const grid = panel.locator('table.operational-grid');
    await expect(grid.locator('tbody tr')).toHaveCount(10);
    await expect(panel.locator('[data-pagination="compact"]')).toBeVisible();
    const search = panel.locator('input[placeholder="Buscar por nome..."]');
    await expect(search).toHaveCSS('font-family', 'Arial, sans-serif');
    await expect(search).toHaveCSS('font-size', '9px');
    await expect(search).toHaveCSS('border-left-width', '0px');

    const metrics = await panel.evaluate(el => {
      const body = el.querySelector('.grid-body-scroll')!;
      const pagination = el.querySelector('[data-pagination="compact"]')!;
      return {
        bodyHeight: body.getBoundingClientRect().height,
        bodyScroll: getComputedStyle(body).overflowY,
        paginationTop: pagination.getBoundingClientRect().top,
        panelBottom: el.getBoundingClientRect().bottom,
      };
    });
    expect(metrics.bodyScroll).toMatch(/auto|scroll/);
    expect(metrics.bodyHeight).toBeGreaterThan(300);
    expect(metrics.panelBottom - metrics.paginationTop).toBeLessThan(90);

    await page.setViewportSize({ width: 390, height: 800 });
    await expect.poll(
      () => panel.locator('button').first().evaluate(button => button.getBoundingClientRect().height),
    ).toBeGreaterThanOrEqual(40);
    await expectNoPageClipping(page);
  });

  test('a última mudança de dimensão continua persistida com respostas lentas', async ({ page }) => {
    await mockApplication(page, 'light');
    await page.setViewportSize({ width: 1366, height: 768 });
    await page.goto('/');
    await page.getByTitle('Preferências visuais').click();

    const width = page.getByRole('slider', { name: 'Largura' });
    await width.fill('115');
    await width.fill('85');
    await expect(width).toHaveValue('85');
    await page.waitForTimeout(250);

    await page.reload();
    await page.getByTitle('Preferências visuais').click();
    await expect(page.getByRole('slider', { name: 'Largura' })).toHaveValue('85');
  });

  test('hover escuro mantém fundo legível sem apagar cores semânticas', async ({ page }) => {
    await mockApplication(page, 'dark');
    await page.setViewportSize({ width: 1024, height: 768 });
    await page.goto('/');
    await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
    await page.evaluate(() => {
      const shell = document.querySelector('[data-visual-shell="true"]');
      if (!shell) throw new Error('Shell visual não encontrado');
      shell.insertAdjacentHTML('beforeend', `
        <table data-testid="dark-hover-grid"><tbody><tr>
          <td class="text-gray-900">Registro</td>
          <td><button class="text-blue-600">Editar</button></td>
          <td><span class="bg-green-100 text-green-700">Ativo</span></td>
        </tr></tbody></table>
      `);
    });
    const row = page.locator('[data-testid="dark-hover-grid"] tr');
    const edit = row.getByRole('button', { name: 'Editar' });
    const status = row.getByText('Ativo');
    const statusColorBefore = await status.evaluate(el => getComputedStyle(el).color);

    await row.hover();
    await expect.poll(() => row.locator('td').first().evaluate(el => getComputedStyle(el).backgroundColor))
      .toBe('rgb(43, 64, 51)');
    await expect(edit).toHaveCSS('color', 'rgb(191, 219, 254)');
    await expect(status).toHaveCSS('color', statusColorBefore);
  });

  test('shell mobile preserva drawer, caps e controles acessíveis', async ({ page }) => {
    await mockApplication(page, 'light');
    await page.setViewportSize({ width: 390, height: 800 });
    await page.goto('/');
    await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
    await expect(page.getByTitle('Menu', { exact: true })).toBeVisible();
    const main = page.locator('.dashboard-main');
    await expect.poll(() => main.evaluate(el => getComputedStyle(el).paddingTop)).toBe('16px');
    await page.getByTitle('Menu', { exact: true }).click();
    await expect(page.locator('aside')).toBeInViewport();
    const close = page.getByTitle('Fechar menu');
    await expect(close).toBeVisible();
    expect((await close.boundingBox())?.height).toBeGreaterThanOrEqual(40);
  });

  test('shell troca drawer por sidebar exatamente em 900px', async ({ page }) => {
    await mockApplication(page, 'light');

    for (const width of RESPONSIVE_WIDTHS) {
      await page.setViewportSize({ width, height: 800 });
      await page.goto('/');
      await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();
      await expectNoPageClipping(page);

      const menu = page.getByTitle('Menu', { exact: true });
      if (width < 900) {
        await expect(menu, `hambúrguer em ${width}px`).toBeVisible();
        const obscuredTargets = await page.locator('.dashboard-topbar button:visible:not(:disabled)').evaluateAll(buttons =>
          buttons
            .filter(button => {
              const rect = button.getBoundingClientRect();
              const hit = document.elementFromPoint(rect.left + rect.width / 2, rect.top + rect.height / 2);
              return !hit || !button.contains(hit);
            })
            .map(button => button.getAttribute('title') || button.textContent?.trim() || 'controle sem nome'),
        );
        expect(obscuredTargets, `controles do cabeçalho sobrepostos em ${width}px`).toEqual([]);
        await menu.click();
        await expect(page.locator('aside')).toBeInViewport();
        await page.getByTitle('Fechar menu').click();
      } else {
        await expect(menu, `sem drawer em ${width}px`).toHaveCount(0);
        const sidebar = page.locator('aside');
        await expect(sidebar).toBeInViewport();
        expect(await sidebar.evaluate(el => el.getBoundingClientRect().width)).toBe(256);
      }

      const mainChildWidth = await page.locator('.dashboard-main > *').first().evaluate(
        el => el.getBoundingClientRect().width,
      );
      expect(mainChildWidth).toBeLessThanOrEqual(width < 640 ? 448 : width < 900 ? 672 : 1280);
    }
  });

  test('preserva estado da sidebar ao cruzar 900px ao vivo', async ({ page }) => {
    await page.setViewportSize({ width: 900, height: 800 });
    await mockApplication(page, 'light');
    await page.goto('/');
    const sidebar = page.locator('aside');
    await expect(sidebar).toBeInViewport();
    await expect.poll(() => sidebar.evaluate(el => el.getBoundingClientRect().width)).toBe(256);

    await page.getByTitle('Recolher menu').click();
    await expect.poll(() => sidebar.evaluate(el => el.getBoundingClientRect().width)).toBe(64);
    await page.setViewportSize({ width: 899, height: 800 });
    await expect(page.getByTitle('Menu', { exact: true })).toBeVisible();
    await expect.poll(() => sidebar.evaluate(el => el.getBoundingClientRect().right)).toBeLessThanOrEqual(0);

    await page.setViewportSize({ width: 900, height: 800 });
    await expect(page.getByTitle('Menu', { exact: true })).toHaveCount(0);
    await expect.poll(() => sidebar.evaluate(el => el.getBoundingClientRect().width)).toBe(64);
    await expect(sidebar).toBeInViewport();
  });

  for (const width of [320, 640, 899, 900, 1920]) {
    test(`modal e tabela permanecem utilizáveis em ${width}px`, async ({ page }) => {
      await page.setViewportSize({ width, height: 720 });
      await mockApplication(page, 'light');
      await page.goto('/');
      await expect(page.locator('[data-visual-shell="true"]')).toBeVisible();

      await openMobileMenuIfNeeded(page, width);
      await page.getByRole('button', { name: 'Conversas WhatsApp', exact: true }).click();
      const tableScroll = page.locator('[data-testid="conversas-table-scroll"]');
      await expect(tableScroll).toBeVisible();
      const table = page.locator('[data-testid="conversas-table"]');
      await expect(table).toBeVisible();
      await expect(table.getByRole('columnheader', { name: 'Data/Hora' })).toBeVisible();
      await expect(table.locator('tbody')).toContainText('Cliente de Exemplo');
      await expect(table.locator('tbody tr.cursor-pointer').first()).toBeVisible();
      const scrollMetrics = await tableScroll.evaluate(el => ({
        overflowX: getComputedStyle(el).overflowX,
      }));
      expect(scrollMetrics.overflowX).toMatch(/auto|scroll/);

      await page.getByRole('button', { name: 'Nova mensagem' }).click();
      const dialog = page.getByRole('dialog');
      await expect(dialog).toBeVisible();
      const dialogBox = await dialog.boundingBox();
      expect(dialogBox).not.toBeNull();
      expect(dialogBox!.width).toBeLessThanOrEqual(width - (width < 640 ? 16 : 32) + 1);
      expect(dialogBox!.height).toBeLessThanOrEqual(720 * 0.92 + 1);
      await expect(dialog.getByRole('button', { name: /enviar/i })).toBeVisible();
      await expectNoPageClipping(page);
    });
  }
});
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { mkdir, mkdtemp, readFile, rm } from 'node:fs/promises';
import path from 'node:path';
import { tmpdir } from 'node:os';
import test from 'node:test';
import { createServer } from 'node:http';
import express from 'express';
import ExcelJS from 'exceljs';
import pg from 'pg';
import XLSX from 'xlsx';
import {
  encodeImportMappingHeader,
  getOptionalImportFieldsWithoutValues,
  getUnmappedImportHeaders,
  parseImportMappingHeader,
  readImportSpreadsheet,
} from '../utils/importSpreadsheet.js';
import ts from 'typescript';
import { createDataImportRoutes, parseImportNumber, parseXlsxImport, getImportRowOrder } from '../server/routes/dataImport.js';

const XLSX_MIME = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';
const { Pool } = pg;
const USER = {
  id: 'workbook-test-admin',
  isAdmin: true,
  currentUnitId: 'unit-current-test',
  name: 'Workbook test',
};
const UNIT_SCOPED_TABLES = new Set(['collaborators', 'admissions', 'legal_processes', 'financial_titles']);
const EXCLUDED_COLUMNS = {
  clients: ['id', 'created_at', 'updated_at', 'blocked_at', 'blocked_by', 'gotalk_contact_id', 'gotalk_channel_id'],
  collaborators: ['id', 'created_at', 'updated_at'],
  banks: ['id', 'created_at', 'updated_at'],
  bank_contacts: ['id', 'created_at'],
  bank_services: ['id'],
  products: ['id', 'created_at', 'updated_at'],
  chart_of_accounts: ['id', 'is_system', 'updated_at'],
  admissions: ['id', 'created_at', 'updated_at'],
  legal_processes: ['id', 'created_at', 'updated_at'],
  financial_titles: [
    'id', 'recurrence_id', 'invoice_group_id', 'origin_title_ids',
    'protest_release_user', 'protest_release_date', 'protest_release_reason',
    'provision_release_user', 'provision_release_date', 'provision_release_reason',
    'creation_date', 'updated_at', 'negotiation_id',
  ],
};

test('CSV UTF-8 preserves accents, leading zeros and quoted separators through the XLSX importer', async () => {
  const csv = '\uFEFFNome / Razão Social;Tipo;CPF / CNPJ;Observações\r\n"João; da Silva";FISICA;01234567890;"ação, revisão"\r\n';
  const workbook = readImportSpreadsheet(XLSX, new Uint8Array(Buffer.from(csv, 'utf8')), 'clientes.csv');
  const converted = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
  const mappings = { clients: [
    { fieldKey: 'name', sheetColumn: 'Nome / Razão Social' },
    { fieldKey: 'type', sheetColumn: 'Tipo' },
    { fieldKey: 'document', sheetColumn: 'CPF / CNPJ' },
    { fieldKey: 'notes', sheetColumn: 'Observações' },
  ] };
  const groups = await parseXlsxImport(converted, ['clients'], mappings);
  assert.deepEqual(groups, [{ table: 'clients', rows: [{
    name: 'João; da Silva', type: 'FISICA', document: '01234567890', notes: 'ação, revisão',
  }] }]);
});

test('import mapping headers preserve UTF-8 labels and accept legacy JSON headers', () => {
  const mapping = {
    clients: [{ fieldKey: 'name', sheetColumn: 'Nome / Razão Social' }],
    legal_processes: [{ fieldKey: 'tags', sheetColumn: 'Marcadores (JSON)' }],
  };
  const encoded = encodeImportMappingHeader(mapping);
  assert.match(encoded, /^%7B/i);
  assert.deepEqual(parseImportMappingHeader(encoded), mapping);
  assert.deepEqual(parseImportMappingHeader(JSON.stringify(mapping)), mapping);
});

test('separa cabeçalhos ignorados de campos opcionais sem valores', () => {
  const headers = ['Nome', 'Observações', 'Coluna extra'];
  const fields = [
    { key: 'name', label: 'Nome', required: true },
    { key: 'notes', label: 'Observações', required: false },
    { key: 'email', label: 'E-mail', required: false },
  ];
  const mapping = [
    { fieldKey: 'name', sheetColumn: 'Nome' },
    { fieldKey: 'notes', sheetColumn: 'Observações' },
    { fieldKey: 'email', sheetColumn: '' },
  ];
  const rows = [{ Nome: 'Cliente', Observações: '  ' }];

  assert.deepEqual(getUnmappedImportHeaders(headers, mapping), ['Coluna extra']);
  assert.deepEqual(getOptionalImportFieldsWithoutValues(fields, mapping, rows), ['Observações', 'E-mail']);
});

test('self-related imports order parents first without changing row identities and reject cycles', () => {
  const hierarchy = getImportRowOrder('chart_of_accounts', [
    { code: '1.1.1', parent_code: '1.1' },
    { code: '1', parent_code: '' },
    { code: '1.1', parent_code: '1' },
  ]);
  assert.deepEqual(hierarchy.indices, [1, 2, 0]);
  assert.equal(hierarchy.cyclic.size, 0);
  const cycle = getImportRowOrder('financial_titles', [
    { document_number: 'A', parent_document_number: 'B' },
    { document_number: 'B', parent_document_number: 'A' },
    { document_number: 'C', parent_document_number: '' },
  ]);
  assert.deepEqual(cycle.indices, [2, 0, 1]);
  assert.deepEqual([...cycle.cyclic], [0, 1]);
});

async function loadFrontendCatalog() {
  const source = await readFile(new URL('../utils/importConfig.ts', import.meta.url), 'utf8');
  const compiled = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.ESNext, target: ts.ScriptTarget.ES2022 },
  }).outputText;
  const moduleUrl = `data:text/javascript;base64,${Buffer.from(compiled).toString('base64')}`;
  const frontendCatalog = await import(moduleUrl);
  return {
    tables: frontendCatalog.IMPORT_TABLES,
    getTablesForSelection: frontendCatalog.getImportTablesForSelection,
  };
}

async function loadBackendDatabaseMappings() {
  const source = await readFile(new URL('../server/routes/dataImport.js', import.meta.url), 'utf8');
  const file = ts.createSourceFile('dataImport.js', source, ts.ScriptTarget.Latest, true, ts.ScriptKind.JS);
  const propertyValue = (object, key) => {
    if (!object || !ts.isObjectLiteralExpression(object)) return undefined;
    const item = object.properties.find(property => ts.isPropertyAssignment(property)
      && property.name.getText().replace(/['"]/g, '') === key);
    return item?.initializer;
  };
  const nameValue = node => node && (ts.isIdentifier(node) || ts.isStringLiteralLike(node))
    ? node.text
    : undefined;
  const arrayValues = node => node && ts.isArrayLiteralExpression(node) ? node.elements : [];

  let schema;
  for (const statement of file.statements) {
    if (!ts.isVariableStatement(statement)) continue;
    for (const declaration of statement.declarationList.declarations) {
      if (declaration.name.getText() === 'IMPORT_SCHEMA') schema = declaration.initializer;
    }
  }
  assert.ok(schema, 'server import schema should be statically defined');
  return new Map(schema.properties.map(table => {
    const key = nameValue(table.name);
    return [key, {
      foreignKeys: arrayValues(propertyValue(table.initializer, 'fkColumns')).map(nameValue),
      parentLinks: arrayValues(propertyValue(table.initializer, 'parentLinks')).map(link => ({
          childKey: nameValue(propertyValue(link, 'childKey')),
        parentTable: nameValue(propertyValue(link, 'parentTable')),
        fkColumn: nameValue(propertyValue(link, 'fkColumn')),
        parentKey: nameValue(propertyValue(link, 'parentKey')),
        parentKeySql: nameValue(propertyValue(link, 'parentKeySql')),
      })),
    }];
  }));
}

function createFakePool(schemaRef) {
  const queries = [];
  return {
    queries,
    async connect() {
      return {
        async query(sql, params = []) {
          queries.push({ sql, params });
          if (/^(BEGIN|COMMIT|ROLLBACK)/.test(sql)) return { rows: [] };
          const tableKey = sql.match(/FROM "([^"]+)" AS t/)?.[1];
          assert.ok(tableKey, `Export query must name a whitelisted table: ${sql}`);

          const cfg = schemaRef.current.get(tableKey);
          assert.ok(cfg, `Unexpected table in export query: ${tableKey}`);
          const configuredRows = schemaRef.exportRowsByTable?.get(tableKey);
          const unitScoped = /t\."unit_id"::text = \$1 AND t\."id"::text > \$2/.test(sql);
          const cursorParam = unitScoped ? 1 : 0;
          const unitId = unitScoped ? params[0] : null;
          const cursor = params[cursorParam];
          const page = configuredRows
            ? configuredRows
              .filter(row => String(row.__export_id) > String(cursor))
              .filter(row => !unitScoped || String(row.unit_id) === String(unitId))
              .slice(0, 1000)
            : cursor === '' ? [undefined] : [];
          return {
            rows: page.map(configuredRow => {
              const row = { __export_id: configuredRow?.__export_id || `id-${tableKey}` };
              for (const field of cfg.fields) {
                if (field.type === 'number') row[field.key] = 1234.56;
                else if (field.type === 'boolean') row[field.key] = false;
                else if (field.type === 'date') row[field.key] = '2026-10-01';
                else if (field.type === 'select') row[field.key] = field.options?.[0] || null;
                else if (field.required) row[field.key] = `fixture-${tableKey}-${field.key}`;
                else row[field.key] = field.virtual ? `resolved-${tableKey}-${field.key}` : null;
              }
              Object.assign(row, configuredRow);
              for (const field of cfg.fields) {
                const source = field.profileSource || field.exportSource;
                if (!source) continue;
                const parentRows = schemaRef.parentRowsByTable?.get('clients')
                  || schemaRef.exportRowsByTable?.get('clients')
                  || [];
                const parent = parentRows.find(candidate =>
                  String(candidate.id ?? candidate.__export_id) === String(row[source.fkColumn]));
                row[field.key] = parent?.[source.column] ?? null;
              }
              for (const field of cfg.fields.filter(candidate => candidate.virtual)) {
                const tableLinks = schemaRef.parentLinksByTable?.get(tableKey)?.parentLinks || [];
                const link = tableLinks.find(candidate => candidate.childKey === field.key);
                if (!link) continue;

                const parentRows = schemaRef.parentRowsByTable?.get(link.parentTable)
                  || schemaRef.exportRowsByTable?.get(link.parentTable)
                  || [];
                const parent = parentRows.find(candidate =>
                  String(candidate.id ?? candidate.__export_id) === String(row[link.fkColumn]));
                if (!parent) {
                  row[field.key] = null;
                  continue;
                }

                if (link.parentKey) {
                  row[field.key] = parent[link.parentKey] ?? null;
                } else {
                  const columns = link.parentKeySql?.match(
                    /COALESCE\(\s*(?:NULLIF\(\s*)?([a-z_]+)\s*(?:,\s*''\s*\))?\s*,\s*([a-z_]+)\s*\)/i,
                  );
                  row[field.key] = columns
                    ? parent[columns[1]] || parent[columns[2]] || null
                    : null;
                }
              }
              return row;
            }),
          };
        },
        release() {},
      };
    },
  };
}

async function startHarness() {
  const schemaRef = { current: new Map() };
  const pool = createFakePool(schemaRef);
  const app = express();
  app.use(express.json());
  app.use('/api/import', (req, _res, next) => {
    req.currentUser = USER;
    next();
  }, createDataImportRoutes(pool));
  const server = createServer(app);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const address = server.address();
  return {
    pool,
    baseUrl: `http://127.0.0.1:${address.port}`,
    setSchemaByKey(schema) { schemaRef.current = schema; },
    setExportRowsByTable(rowsByTable) { schemaRef.exportRowsByTable = rowsByTable; },
    setParentLinksByTable(linksByTable) { schemaRef.parentLinksByTable = linksByTable; },
    setParentRowsByTable(rowsByTable) { schemaRef.parentRowsByTable = rowsByTable; },
    close: () => new Promise((resolve, reject) => {
      server.close(error => error ? reject(error) : resolve());
      server.closeAllConnections();
    }),
  };
}

test('layout e importação leem apenas as abas selecionadas e seguem a ordem de dependência', async t => {
  const harness = await startHarness();
  t.after(() => harness.close());
  const { tables: frontendTables, getTablesForSelection } = await loadFrontendCatalog();
  const tableByKey = new Map(frontendTables.map(table => [table.key, table]));

  const admissionSelection = getTablesForSelection('admissions');
  assert.deepEqual(admissionSelection, ['admissions']);
  assert.deepEqual(getTablesForSelection('clients'), ['clients']);
  const relatedAdmissionSelection = getTablesForSelection('admissions', ['collaborators', 'banks', 'clients']);
  assert.deepEqual(relatedAdmissionSelection, [
    'clients', 'collaborators', 'banks', 'admissions',
  ]);

  const response = await fetch(`${harness.baseUrl}/api/import/layout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tables: relatedAdmissionSelection }),
  });
  assert.equal(response.status, 200);
  const workbook = new ExcelJS.Workbook();
  const workbookBytes = Buffer.from(await response.arrayBuffer());
  await workbook.xlsx.load(workbookBytes);
  assert.deepEqual(
    workbook.worksheets.map(sheet => sheet.name),
    ['Clientes', 'Colaboradores', 'Bancos', 'Admissões'],
    'the layout follows parent-first import precedence',
  );
  assert.deepEqual(
    workbook.getWorksheet('Clientes').getRow(1).values.slice(1),
    tableByKey.get('clients').fields.map(field => field.label),
    'the client sheet must expose all current client registration fields',
  );
  assert.deepEqual(
    workbook.getWorksheet('Admissões').getRow(1).values.slice(1),
    tableByKey.get('admissions').fields.map(field => field.label),
    'admission fields include the client and holder profile projections',
  );
  const admissionKeys = new Set(tableByKey.get('admissions').fields.map(field => field.key));
  assert.ok(admissionKeys.has('client_document'), 'admissions should expose the responsible client document');
  assert.ok(admissionKeys.has('titular_client_document'), 'admissions should expose the holder document');
  for (const prefix of ['client', 'titular']) {
    for (const suffix of ['address', 'number', 'complement', 'district', 'city', 'state', 'cep', 'notes']) {
      assert.ok(admissionKeys.has(`${prefix}_${suffix}`), `${prefix} ${suffix} should be present in the admissions layout`);
    }
  }

  const clientFields = tableByKey.get('clients').fields;
  workbook.getWorksheet('Clientes').addRow(clientFields.map(field => ({
    name: 'Responsável do contrato',
    document: '00123456789',
    phone: '11999990001',
  }[field.key] || '')));
  workbook.getWorksheet('Clientes').addRow(clientFields.map(field => ({
    name: 'Titular do contrato',
    document: '00987654321',
    phone: '11999990002',
  }[field.key] || '')));
  const collaboratorFields = tableByKey.get('collaborators').fields;
  workbook.getWorksheet('Colaboradores').addRow(collaboratorFields.map(field => ({
    name: 'Consultor de exemplo',
    role: 'Consultor',
    active: 'sim',
  }[field.key] || '')));
  const bankFields = tableByKey.get('banks').fields;
  workbook.getWorksheet('Bancos').addRow(bankFields.map(field => ({
    name: 'Banco de exemplo',
    febraban_code: '237',
    code: '237',
    status: 'ATIVO',
  }[field.key] || '')));

  const admissionFields = tableByKey.get('admissions').fields;
  workbook.getWorksheet('Admissões').addRow(admissionFields.map(field => ({
    client_name: 'Responsável do contrato',
    client_document: '00123456789',
    titular_client_name: 'Titular do contrato',
    titular_client_document: '00987654321',
    contract_number: 'ADM-CLIENTES-AUTO-001',
    client_address: 'Rua do responsável',
    client_number: '11',
    client_complement: 'Casa',
    client_district: 'Centro',
    client_city: 'Campinas',
    client_state: 'SP',
    client_cep: '13000001',
    client_notes: 'Observação do responsável',
    titular_address: 'Rua do titular',
    titular_number: '22',
    titular_complement: 'Apto',
    titular_district: 'Jardim',
    titular_city: 'Santos',
    titular_state: 'SP',
    titular_cep: '11000002',
    titular_notes: 'Observação do titular',
  }[field.key] || '')));
  const populatedWorkbook = Buffer.from(await workbook.xlsx.writeBuffer());
  const admissionOnlyGroups = await parseXlsxImport(populatedWorkbook, ['admissions'], {
    admissions: admissionFields.map(field => ({
      fieldKey: field.key,
      sheetColumn: field.label,
    })),
  });
  assert.deepEqual(
    admissionOnlyGroups.map(group => group.table),
    ['admissions'],
    'with one principal table selected, the other workbook tabs are ignored',
  );
  const admissionOnlyRow = admissionOnlyGroups[0].rows[0];
  assert.equal(admissionOnlyRow.client_name, 'Responsável do contrato');
  assert.equal(admissionOnlyRow.client_document, '00123456789');
  assert.equal(admissionOnlyRow.titular_client_name, 'Titular do contrato');
  assert.equal(admissionOnlyRow.titular_client_document, '00987654321');
  assert.equal(admissionOnlyRow.client_address, 'Rua do responsável');
  assert.equal(admissionOnlyRow.titular_cep, '11000002');

  const mappings = Object.fromEntries(
    ['clients', 'collaborators', 'banks', 'admissions'].map(key => [
      key,
      tableByKey.get(key).fields.map(field => ({ fieldKey: field.key, sheetColumn: field.label })),
    ]),
  );
  const allRelatedGroups = await parseXlsxImport(
    populatedWorkbook,
    ['admissions', 'banks', 'collaborators', 'clients'],
    mappings,
  );
  const parsedByTable = new Map(allRelatedGroups.map(group => [group.table, group]));
  assert.deepEqual(
    allRelatedGroups.map(group => group.table),
    ['clients', 'collaborators', 'banks', 'admissions'],
    'selected tabs are parsed in dependency order even if the request is principal-first',
  );
  assert.deepEqual(parsedByTable.get('clients').rows.map(row => [row.name, row.document]), [
    ['Responsável do contrato', '00123456789'],
    ['Titular do contrato', '00987654321'],
  ], 'the client sheet is parsed when explicitly selected');
  assert.equal(parsedByTable.get('collaborators').rows[0].name, 'Consultor de exemplo');
  assert.equal(parsedByTable.get('banks').rows[0].name, 'Banco de exemplo');
  assert.equal(parsedByTable.get('admissions').rows[0].client_name, 'Responsável do contrato');
  assert.equal(parsedByTable.get('admissions').rows[0].client_document, '00123456789');
  assert.equal(parsedByTable.get('admissions').rows[0].titular_client_name, 'Titular do contrato');
  assert.equal(parsedByTable.get('admissions').rows[0].titular_client_document, '00987654321');
  assert.equal(parsedByTable.get('admissions').rows[0].client_address, 'Rua do responsável');
  assert.equal(parsedByTable.get('admissions').rows[0].titular_cep, '11000002');

  const uiSelectionResponse = await fetch(`${harness.baseUrl}/api/import/layout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tables: admissionSelection }),
  });
  assert.equal(uiSelectionResponse.status, 200);
  const uiSelectionWorkbook = new ExcelJS.Workbook();
  await uiSelectionWorkbook.xlsx.load(Buffer.from(await uiSelectionResponse.arrayBuffer()));
  assert.deepEqual(
    uiSelectionWorkbook.worksheets.map(sheet => sheet.name),
    ['Admissões'],
    'the exact table list derived for the interface produces only the principal sheet',
  );

  const unrelatedSelection = getTablesForSelection('products');
  assert.deepEqual(unrelatedSelection, ['products']);
  const unrelatedResponse = await fetch(`${harness.baseUrl}/api/import/layout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tables: unrelatedSelection }),
  });
  assert.equal(unrelatedResponse.status, 200);
  const unrelatedWorkbook = new ExcelJS.Workbook();
  await unrelatedWorkbook.xlsx.load(Buffer.from(await unrelatedResponse.arrayBuffer()));
  assert.deepEqual(unrelatedWorkbook.worksheets.map(sheet => sheet.name), ['Produtos']);
});

test('importação antiga de Admissões ignora a linha de instruções e não cria grupo vazio de Clientes', async () => {
  const { tables } = await loadFrontendCatalog();
  const admissionFields = tables.find(table => table.key === 'admissions').fields;
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Admissões');
  sheet.addRow(admissionFields.map(field => field.label));
  const oldInstructionRow = sheet.addRow(admissionFields.map(() => 'Preencha esta coluna conforme as instruções do layout'));
  oldInstructionRow.font = { italic: true, size: 9 };
  oldInstructionRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF3F4F6' } };
  sheet.addRow(admissionFields.map(field => ({
    client_name: 'Cliente histórico',
    contract_number: 'ADM-LEGADO-001',
  }[field.key] || '')));

  const parsed = await parseXlsxImport(
    Buffer.from(await workbook.xlsx.writeBuffer()),
    ['admissions', 'clients'],
    { admissions: admissionFields.map(field => ({ fieldKey: field.key, sheetColumn: field.label })) },
  );

  assert.deepEqual(parsed.map(group => group.table), ['admissions']);
  assert.equal(parsed[0].rows.length, 1, 'the instruction row must not become an admission');
  assert.equal(parsed[0].rows[0].client_name, 'Cliente histórico');
  assert.equal(parsed[0].rows[0].contract_number, 'ADM-LEGADO-001');
});

test('aba genérica única continua servindo como Admissões sem importar uma aba Clientes inexistente', async () => {
  const { tables } = await loadFrontendCatalog();
  const admissionFields = tables.find(table => table.key === 'admissions').fields;
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Planilha1');
  sheet.addRow(admissionFields.map(field => field.label));
  sheet.addRow(admissionFields.map(field => ({
    contract_number: 'ADM-GENERICA-001',
    client_name: 'Cliente sem cadastro',
  }[field.key] || '')));

  const parsed = await parseXlsxImport(
    Buffer.from(await workbook.xlsx.writeBuffer()),
    ['admissions'],
    { admissions: admissionFields.map(field => ({ fieldKey: field.key, sheetColumn: field.label })) },
  );

  assert.deepEqual(parsed.map(group => group.table), ['admissions']);
  assert.equal(parsed[0].rows.length, 1);
  assert.equal(parsed[0].rows[0].contract_number, 'ADM-GENERICA-001');
  assert.equal(parsed[0].rows[0].client_name, 'Cliente sem cadastro');
});

test('Excel model and data export match the importer catalog', async t => {
  const harness = await startHarness();
  t.after(() => harness.close());

  const { tables: frontendTables } = await loadFrontendCatalog();
  const schemaResponse = await fetch(`${harness.baseUrl}/api/import/schema`);
  assert.equal(schemaResponse.status, 200);
  const { tables: backendTables } = await schemaResponse.json();
  const schemaByKey = new Map(backendTables.map(table => [table.key, table]));
  harness.setSchemaByKey(schemaByKey);
  const expectedClientNames = Array.from({ length: 1017 }, (_, index) =>
    `Cliente de exportação ${String(index + 1).padStart(4, '0')}`);
  const clientExportRows = expectedClientNames.map((name, index) => ({
    __export_id: `client-${String(index + 1).padStart(4, '0')}`,
    id: `client-${String(index + 1).padStart(4, '0')}`,
    name,
    document: String(10000000000 + index).padStart(11, '0'),
    address: `Rua de exportação ${index + 1}`,
    number: String(index + 1),
    complement: `Complemento ${index + 1}`,
    district: `Bairro ${index + 1}`,
    city: `Cidade ${index + 1}`,
    state: 'SP',
    cep: String(10000000 + index).padStart(8, '0'),
    notes: `Observação ${index + 1}`,
  }));
  harness.setExportRowsByTable(new Map([['clients', clientExportRows]]));
  const schemaContract = JSON.parse(await readFile(new URL('../schema-contract.json', import.meta.url), 'utf8'));
  const databaseColumns = new Map();
  const databaseColumnTypes = new Map();
  for (const column of schemaContract.columns) {
    if (column.schema !== 'public') continue;
    if (!databaseColumns.has(column.table)) databaseColumns.set(column.table, new Set());
    databaseColumns.get(column.table).add(column.name);
    if (!databaseColumnTypes.has(column.table)) databaseColumnTypes.set(column.table, new Map());
    databaseColumnTypes.get(column.table).set(column.name, column.type);
  }
  const backendMappings = await loadBackendDatabaseMappings();
  const otherUnitId = 'unit-other-test';
  const otherUnitName = 'Outra unidade';
  let activeAdmissionIndex = 0;
  const allAdmissionRows = Array.from({ length: 1024 }, (_, index) => {
    const sequence = index + 1;
    const isOtherUnit = sequence % 64 === 0;
    const clientIndex = isOtherUnit ? sequence - 1 : activeAdmissionIndex++;
    return {
      __export_id: `admission-${String(sequence).padStart(4, '0')}`,
      contract_number: `Contrato de exportação ${String(sequence).padStart(4, '0')}`,
      client_id: `client-${String(clientIndex + 1).padStart(4, '0')}`,
      titular_client_id: `client-${String(clientIndex + 1).padStart(4, '0')}`,
      unit_id: isOtherUnit ? otherUnitId : USER.currentUnitId,
    };
  });
  const expectedAdmissionRows = allAdmissionRows.filter(row => row.unit_id === USER.currentUnitId);
  const expectedAdmissionClientNames = expectedAdmissionRows.map(row =>
    clientExportRows.find(client => client.id === row.titular_client_id).name);
  assert.ok(expectedAdmissionRows.length > 1000, 'active-unit admissions should cross the export page boundary');
  const expectedUnitName = 'Unidade da exportação';
  harness.setExportRowsByTable(new Map([
    ['clients', clientExportRows],
    ['admissions', allAdmissionRows],
  ]));
  harness.setParentLinksByTable(backendMappings);
  harness.setParentRowsByTable(new Map([['companies', [{
    id: USER.currentUnitId,
    nome_fantasia: expectedUnitName,
    razao_social: 'Razão social da unidade de exportação',
  }, {
    id: otherUnitId,
    nome_fantasia: otherUnitName,
    razao_social: 'Razão social da outra unidade',
  }]]]));

  assert.equal(frontendTables.length, 10);
  assert.equal(backendTables.length, 10);
  assert.deepEqual(new Set(frontendTables.map(table => table.key)), new Set(backendTables.map(table => table.key)));

  for (const frontend of frontendTables) {
    const backend = schemaByKey.get(frontend.key);
    const physicalColumns = databaseColumns.get(frontend.key);
    assert.ok(physicalColumns, `${frontend.key} should exist in the development schema contract`);
    assert.equal(frontend.label, backend.label, `${frontend.key} label`);
    assert.deepEqual(frontend.dedupKeys, backend.dedupKeys, `${frontend.key} duplicate keys`);
    assert.deepEqual(
      frontend.fields.map(({ key, label, type, required, virtual, hint, options }) => ({
        key, label, type, required, virtual: virtual || false, hint: hint || '', options: options || [],
      })),
      backend.fields.map(({ key, label, type, required, virtual, hint, options }) => ({
        key, label, type, required, virtual: virtual || false, hint: hint || '', options: options || [],
      })),
      `${frontend.key} import field definitions`,
    );
    for (const field of backend.fields.filter(field => !field.virtual)) {
      assert.ok(physicalColumns.has(field.key), `${frontend.key}.${field.key} must exist in the development schema`);
    }
    const mapping = backendMappings.get(frontend.key);
    assert.ok(mapping, `${frontend.key} should have database mapping metadata`);
    for (const foreignKey of mapping.foreignKeys) {
      assert.ok(physicalColumns.has(foreignKey), `${frontend.key}.${foreignKey} must exist in the development schema`);
    }
    for (const link of mapping.parentLinks) {
      const parentColumns = databaseColumns.get(link.parentTable);
      assert.ok(physicalColumns.has(link.fkColumn), `${frontend.key}.${link.fkColumn} must exist in the development schema`);
      assert.ok(parentColumns?.has('id'), `${link.parentTable}.id must exist in the development schema`);
      if (link.parentKey) {
        assert.ok(parentColumns.has(link.parentKey), `${link.parentTable}.${link.parentKey} must exist in the development schema`);
      }
      if (link.parentKeySql) {
        const referencedColumns = link.parentKeySql.match(/[a-z_][a-z0-9_]*/gi) || [];
        for (const column of referencedColumns.filter(name => !['coalesce', 'nullif'].includes(name.toLowerCase()))) {
          assert.ok(parentColumns.has(column), `${link.parentTable}.${column} must exist in the development schema`);
        }
      }
    }
    if (UNIT_SCOPED_TABLES.has(frontend.key)) {
      assert.ok(physicalColumns.has('unit_id'), `${frontend.key} export must be scoped by unit_id`);
    }
    const coveredColumns = new Set([
      ...backend.fields.filter(field => !field.virtual).map(field => field.key),
      ...mapping.foreignKeys,
      ...mapping.parentLinks.map(link => link.fkColumn),
    ]);
    const excluded = new Set(EXCLUDED_COLUMNS[frontend.key] || []);
    for (const column of physicalColumns) {
      assert.ok(
        coveredColumns.has(column) || excluded.has(column),
        `${frontend.key}.${column} must be mapped or explicitly excluded from business-data import/export`,
      );
    }
  }

  const layoutResponse = await fetch(`${harness.baseUrl}/api/import/layout`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tables: frontendTables.map(table => table.key) }),
  });
  assert.equal(layoutResponse.status, 200);
  assert.match(layoutResponse.headers.get('content-type'), new RegExp(XLSX_MIME));
  const layoutBook = new ExcelJS.Workbook();
  await layoutBook.xlsx.load(Buffer.from(await layoutResponse.arrayBuffer()));
  assert.deepEqual(layoutBook.worksheets.map(sheet => sheet.name), backendTables.map(table => table.label));

  let hasChoiceValidation = false;
  for (const table of backendTables) {
    const sheet = layoutBook.getWorksheet(table.label);
    assert.deepEqual(sheet.getRow(1).values.slice(1), table.fields.map(field => field.label), `${table.key} template headers`);
    const hintValues = sheet.getRow(2).values.slice(1);
    if (table.fields.some(field => field.required)) {
      assert.ok(
        table.fields.some((field, index) => field.required && String(hintValues[index]).startsWith('[OBRIGATÓRIO]')),
        `${table.key} required fields should be marked in the template`,
      );
    }
    const validations = sheet.dataValidations.model;
    hasChoiceValidation ||= Object.values(validations).some(validation => validation.type === 'list');
  }
  assert.equal(hasChoiceValidation, true, 'select and boolean fields should have Excel choices');

  const exportResponse = await fetch(`${harness.baseUrl}/api/import/export`, { method: 'POST' });
  assert.equal(exportResponse.status, 200);
  assert.match(exportResponse.headers.get('content-type'), new RegExp(XLSX_MIME));
  assert.match(exportResponse.headers.get('content-disposition'), /dados_importacao\.xlsx/);
  const dataBook = new ExcelJS.Workbook();
  const exportedBuffer = Buffer.from(await exportResponse.arrayBuffer());
  await dataBook.xlsx.load(exportedBuffer);
  assert.deepEqual(dataBook.worksheets.map(sheet => sheet.name), backendTables.map(table => table.label));

  for (const table of backendTables) {
    const sheet = dataBook.getWorksheet(table.label);
    assert.deepEqual(sheet.getRow(1).values.slice(1), table.fields.map(field => field.label), `${table.key} export headers`);
    if (table.key === 'clients') {
      const nameColumn = table.fields.findIndex(field => field.key === 'name') + 1;
      const exportedNames = Array.from({ length: sheet.rowCount - 1 }, (_, index) =>
        sheet.getRow(index + 2).getCell(nameColumn).value);
      assert.equal(sheet.rowCount - 1, expectedClientNames.length, 'all client pages should be present in the XLSX');
      assert.deepEqual(exportedNames, expectedClientNames, 'client rows should retain their order across pages');
      assert.equal(new Set(exportedNames).size, expectedClientNames.length, 'client rows should not be duplicated');
    }
    if (table.key === 'admissions') {
      const clientField = table.fields.find(field => field.key === 'titular_client_name');
      const unitField = table.fields.find(field => field.key === 'unit_name');
      assert.equal(clientField?.virtual, true, 'admissions should expose its linked client as a virtual import field');
      assert.equal(unitField?.virtual, true, 'admissions should expose its linked unit as a virtual import field');
      const clientColumn = table.fields.findIndex(field => field.key === clientField.key) + 1;
      const unitColumn = table.fields.findIndex(field => field.key === unitField.key) + 1;
      const exportedClientNames = Array.from({ length: sheet.rowCount - 1 }, (_, index) =>
        sheet.getRow(index + 2).getCell(clientColumn).value);
      const exportedUnitNames = Array.from({ length: sheet.rowCount - 1 }, (_, index) =>
        sheet.getRow(index + 2).getCell(unitColumn).value);
      assert.equal(sheet.rowCount - 1, expectedAdmissionRows.length, 'all admission pages should be present in the XLSX');
      assert.deepEqual(exportedClientNames, expectedAdmissionClientNames, 'linked clients should remain correct on every admission page');
      assert.deepEqual(
        Array.from({ length: sheet.rowCount - 1 }, (_, index) =>
          sheet.getRow(index + 2).getCell(table.fields.findIndex(field => field.key === 'client_name') + 1).value),
        expectedAdmissionRows.map(row => clientExportRows.find(client => client.id === row.client_id).name),
        'the responsible client name should be projected from clients.client_id',
      );
      for (const [fieldKey, fkColumn] of [
        ['client_document', 'client_id'],
        ['titular_client_document', 'titular_client_id'],
      ]) {
        const documentColumn = table.fields.findIndex(field => field.key === fieldKey) + 1;
        assert.deepEqual(
          Array.from({ length: sheet.rowCount - 1 }, (_, index) =>
            sheet.getRow(index + 2).getCell(documentColumn).value),
          expectedAdmissionRows.map(row =>
            clientExportRows.find(client => client.id === row[fkColumn]).document),
          `${fieldKey} should export the document from the linked client without exposing internal IDs`,
        );
      }
      for (const field of table.fields.filter(candidate => candidate.profileSource)) {
        const column = table.fields.findIndex(candidate => candidate.key === field.key) + 1;
        const sourceFk = field.profileSource.fkColumn;
        const sourceColumn = field.profileSource.column;
        const expectedValues = expectedAdmissionRows.map(row => {
          const parentId = row[sourceFk];
          return clientExportRows.find(client => client.id === parentId)?.[sourceColumn] ?? null;
        });
        assert.deepEqual(
          Array.from({ length: sheet.rowCount - 1 }, (_, index) => sheet.getRow(index + 2).getCell(column).value),
          expectedValues,
          `${field.label} should be projected from the linked clients row`,
        );
      }
      assert.deepEqual(
        exportedClientNames.slice(998, 1002),
        expectedAdmissionClientNames.slice(998, 1002),
        'linked clients should remain in order immediately before and after the page boundary',
      );
      assert.notEqual(exportedClientNames[999], exportedClientNames[1000],
        'the two sides of the page boundary should retain their distinct client links');
      assert.deepEqual(exportedUnitNames, Array(expectedAdmissionRows.length).fill(expectedUnitName),
        'linked unit should remain correct on every admission page');
    }
    const dataRow = sheet.getRow(2);
    const numberIndex = table.fields.findIndex(field => field.type === 'number');
    if (numberIndex >= 0) {
      assert.equal(dataRow.getCell(numberIndex + 1).value, 1234.56, `${table.key} number cell`);
    }
  }
  const mappings = Object.fromEntries(backendTables.map(table => [
    table.key,
    table.fields.map(field => ({ fieldKey: field.key, sheetColumn: field.label })),
  ]));
  const parsedExport = await parseXlsxImport(exportedBuffer, backendTables.map(table => table.key), mappings);
  assert.equal(parsedExport.length, backendTables.length, 'exported workbook should be readable by the importer');
  for (const group of parsedExport) {
    const table = schemaByKey.get(group.table);
    assert.equal(Object.keys(group.rows[0]).length, table.fields.length, `${group.table} import mapping coverage`);
  }
  const importedClients = parsedExport.find(group => group.table === 'clients');
  assert.equal(importedClients.rows.length, expectedClientNames.length, 'importer should read every exported client row');
  assert.deepEqual(
    importedClients.rows.map(row => row.name),
    expectedClientNames,
    'importer catalog mapping should preserve the exported client order',
  );
  const importedAdmissions = parsedExport.find(group => group.table === 'admissions');
  assert.equal(importedAdmissions.rows.length, expectedAdmissionRows.length);
  assert.deepEqual(
    importedAdmissions.rows.map(row => row.titular_client_name),
    expectedAdmissionClientNames,
    'virtual client fields should remain mapped by the importer catalog across pages',
  );
  assert.deepEqual(
    importedAdmissions.rows.map(row => row.unit_name),
    Array(expectedAdmissionRows.length).fill(expectedUnitName),
    'virtual unit fields should remain mapped by the importer catalog across pages',
  );

  const exportQueries = harness.pool.queries.filter(query => query.sql.startsWith('SELECT'));
  assert.equal(exportQueries.length, backendTables.length + 2,
    'second pages for clients and admissions should issue one additional query each');
  const clientPageQueries = exportQueries.filter(query => query.sql.includes('FROM "clients" AS t'));
  assert.equal(clientPageQueries.length, 2, 'clients should be retrieved in two pages');
  assert.equal(clientPageQueries[0].params.at(-1), '');
  assert.equal(clientPageQueries[1].params.at(-1), 'client-1000', 'second page should continue after the last first-page id');
  const admissionPageQueries = exportQueries.filter(query => query.sql.includes('FROM "admissions" AS t'));
  assert.equal(admissionPageQueries.length, 2, 'admissions should be retrieved in two pages');
  assert.equal(admissionPageQueries[0].params[0], USER.currentUnitId);
  assert.equal(admissionPageQueries[0].params.at(-1), '');
  assert.equal(admissionPageQueries[1].params.at(-1), expectedAdmissionRows[999].__export_id,
    'second admission page should continue after the last first-page id');
  for (const { sql, params } of exportQueries) {
    const tableKey = sql.match(/FROM "([^"]+)" AS t/)?.[1];
    const isUnitScoped = UNIT_SCOPED_TABLES.has(tableKey);
    assert.equal(sql.includes('t."unit_id"::text = $1'), isUnitScoped, `${tableKey} unit scope`);
    if (isUnitScoped) assert.equal(params[0], USER.currentUnitId, `${tableKey} active unit`);

    const table = backendTables.find(candidate => candidate.key === tableKey);
    for (const link of backendMappings.get(tableKey).parentLinks) {
      const fieldIndex = table.fields.findIndex(field => link.childKey === field.key && field.virtual);
      if (fieldIndex < 0) continue;
      const fkType = databaseColumnTypes.get(tableKey)?.get(link.fkColumn);
      const parentIdType = databaseColumnTypes.get(link.parentTable)?.get('id');
      const join = fkType === parentIdType
        ? `"parent_${fieldIndex}".id = t."${link.fkColumn}"`
        : `("parent_${fieldIndex}".id)::text = (t."${link.fkColumn}")::text`;
      assert.ok(sql.includes(join), `${tableKey}.${link.fkColumn} export join should match ${fkType} to ${parentIdType}`);
    }
    for (const [index, field] of table.fields.entries()) {
      const source = field.profileSource || field.exportSource;
      if (!source) continue;
      const join = `"profile_${index}".id = t."${source.fkColumn}"`;
      assert.ok(sql.includes(join), `${tableKey}.${field.key} should join its client profile by ${source.fkColumn}`);
    }
  }
});

test('exportação paginada mantém um único snapshot quando clientes mudam no PostgreSQL', {
  timeout: 120_000,
}, async t => {
  const postgresDir = await mkdtemp(path.join(tmpdir(), 'data-import-export-snapshot-'));
  const socketDir = path.join(postgresDir, 'socket');
  const dataDir = path.join(postgresDir, 'data');
  const port = 20_000 + Math.floor(Math.random() * 20_000);
  let postgresStarted = false;
  let pool;
  let server;
  t.after(async () => {
    if (server) {
      await new Promise(resolve => {
        server.close(() => resolve());
        server.closeAllConnections();
      });
    }
    if (pool) await pool.end();
    if (postgresStarted) {
      execFileSync('pg_ctl', ['-D', dataDir, '-m', 'immediate', '-w', 'stop'], { stdio: 'ignore' });
    }
    await rm(postgresDir, { recursive: true, force: true });
  });

  await mkdir(socketDir, { recursive: true });
  execFileSync('initdb', ['-D', dataDir, '-A', 'trust', '-U', 'postgres', '--no-locale'], { stdio: 'ignore' });
  execFileSync('pg_ctl', [
    '-D', dataDir, '-o', `-F -k ${socketDir} -p ${port}`, '-w', 'start',
  ], { stdio: 'ignore' });
  postgresStarted = true;

  pool = new Pool({
    host: socketDir,
    port,
    user: 'postgres',
    database: 'postgres',
    max: 3,
  });
  await pool.query(`
    CREATE TABLE clients (
      id UUID PRIMARY KEY,
      name TEXT NOT NULL,
      type TEXT,
      document TEXT,
      rg TEXT,
      phone TEXT,
      phone2 TEXT,
      is_whatsapp BOOLEAN,
      email TEXT,
      profession TEXT,
      marital_status TEXT,
      birth_date DATE,
      cep TEXT,
      address TEXT,
      number TEXT,
      complement TEXT,
      district TEXT,
      city TEXT,
      state TEXT,
      natureza TEXT,
      blocked BOOLEAN,
      block_status TEXT,
      block_reason TEXT,
      notes TEXT
    );
    INSERT INTO clients (id, name)
    SELECT ('10000000-0000-4000-8000-' || lpad(to_hex(n), 12, '0'))::uuid,
           'Cliente original ' || lpad(n::text, 4, '0')
      FROM generate_series(1, 1005) AS n;
  `);

  let resolveFirstPage;
  let allowExportToContinue;
  const firstPageFetched = new Promise(resolve => { resolveFirstPage = resolve; });
  const continueExport = new Promise(resolve => { allowExportToContinue = resolve; });
  let interceptedClientPage = false;
  let transactionIsolation;
  const exportPool = {
    async connect() {
      const client = await pool.connect();
      return {
        async query(sql, params) {
          const isTransactionCommand = /^(BEGIN|COMMIT|ROLLBACK)/i.test(sql);
          const isClientExportPage = sql.includes('FROM "clients" AS t');
          if (!isTransactionCommand && sql.startsWith('SELECT') && !isClientExportPage) {
            return { rows: [] };
          }
          const result = await client.query(sql, params);
          if (/^BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY$/i.test(sql)) {
            transactionIsolation = (await client.query('SHOW transaction_isolation')).rows[0].transaction_isolation;
          }
          if (!interceptedClientPage && isClientExportPage) {
            interceptedClientPage = true;
            resolveFirstPage();
            await continueExport;
          }
          return result;
        },
        release() { client.release(); },
      };
    },
  };

  const app = express();
  app.use('/api/import', (req, _res, next) => {
    req.currentUser = USER;
    next();
  }, createDataImportRoutes(exportPool));
  server = createServer(app);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const exportUrl = `http://127.0.0.1:${server.address().port}/api/import/export`;

  const exportPromise = fetch(exportUrl, { method: 'POST' });
  try {
    await firstPageFetched;
    assert.equal(transactionIsolation, 'repeatable read', 'the export must actually run under PostgreSQL REPEATABLE READ');

    const updatedId = '10000000-0000-4000-8000-0000000003e9';
    const deletedId = '10000000-0000-4000-8000-0000000003ea';
    const insertedId = '10000000-0000-4000-8000-0000000003ee';
    await pool.query('UPDATE clients SET name = $2 WHERE id = $1', [updatedId, 'Cliente alterado durante a exportação']);
    await pool.query('DELETE FROM clients WHERE id = $1', [deletedId]);
    await pool.query('INSERT INTO clients (id, name) VALUES ($1, $2)', [
      insertedId, 'Cliente inserido durante a exportação',
    ]);
  } finally {
    allowExportToContinue();
  }

  const response = await exportPromise;
  assert.equal(response.status, 200, await response.clone().text());
  assert.match(response.headers.get('content-type'), new RegExp(XLSX_MIME));
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(Buffer.from(await response.arrayBuffer()));
  const sheet = workbook.getWorksheet('Clientes');
  assert.ok(sheet, 'the export should include the clients worksheet');
  const nameColumn = sheet.getRow(1).values.indexOf('Nome / Razão Social');
  assert.ok(nameColumn > 0, 'the clients worksheet should include the name column');
  const exportedNames = Array.from({ length: sheet.rowCount - 1 }, (_, index) =>
    sheet.getRow(index + 2).getCell(nameColumn).value);
  const expectedNames = Array.from({ length: 1005 }, (_, index) =>
    `Cliente original ${String(index + 1).padStart(4, '0')}`);

  assert.equal(sheet.rowCount - 1, 1005, 'every row from the original snapshot should be exported');
  assert.deepEqual(exportedNames, expectedNames, 'all pages must contain original values without gaps or mixed versions');
  assert.equal(new Set(exportedNames).size, expectedNames.length, 'pagination must not duplicate rows');
  assert.equal(exportedNames.includes('Cliente alterado durante a exportação'), false);
  assert.equal(exportedNames.includes('Cliente inserido durante a exportação'), false);
  assert.equal(exportedNames.includes('Cliente original 1002'), true,
    'a row deleted after the first page was read must still exist in the snapshot');
});

test('exportação PostgreSQL preserva vínculos de clientes e unidades depois da página de 1.000', {
  timeout: 120_000,
}, async t => {
  const postgresDir = await mkdtemp(path.join(tmpdir(), 'data-import-export-links-'));
  const socketDir = path.join(postgresDir, 'socket');
  const dataDir = path.join(postgresDir, 'data');
  const port = 20_000 + Math.floor(Math.random() * 20_000);
  let postgresStarted = false;
  let pool;
  let server;
  t.after(async () => {
    if (server) {
      await new Promise(resolve => {
        server.close(() => resolve());
        server.closeAllConnections();
      });
    }
    if (pool) await pool.end();
    if (postgresStarted) {
      execFileSync('pg_ctl', ['-D', dataDir, '-m', 'immediate', '-w', 'stop'], { stdio: 'ignore' });
    }
    await rm(postgresDir, { recursive: true, force: true });
  });

  await mkdir(socketDir, { recursive: true });
  execFileSync('initdb', ['-D', dataDir, '-A', 'trust', '-U', 'postgres', '--no-locale'], { stdio: 'ignore' });
  execFileSync('pg_ctl', [
    '-D', dataDir, '-o', `-F -k ${socketDir} -p ${port}`, '-w', 'start',
  ], { stdio: 'ignore' });
  postgresStarted = true;

  pool = new Pool({
    host: socketDir,
    port,
    user: 'postgres',
    database: 'postgres',
    max: 3,
  });

  const schemaContract = JSON.parse(await readFile(new URL('../schema-contract.json', import.meta.url), 'utf8'));
  const sqlIdentifier = value => `"${String(value).replace(/"/g, '""')}"`;
  const tables = ['clients', 'admissions', 'companies', 'banks', 'collaborators', 'series', 'modalities'];
  for (const table of tables) {
    const columns = schemaContract.columns.filter(column => column.schema === 'public' && column.table === table);
    assert.ok(columns.some(column => column.name === 'id'), `${table} must have its contracted id column`);
    const definitions = columns.map(column =>
      `${sqlIdentifier(column.name)} ${column.type}${column.name === 'id' ? ' PRIMARY KEY' : ''}`);
    await pool.query(`CREATE TABLE ${sqlIdentifier(table)} (${definitions.join(', ')})`);
  }

  const unitId = '40000000-0000-4000-8000-000000000001';
  const expectedUnitName = 'Razão social oficial da unidade';
  await pool.query(
    `INSERT INTO companies (id, nome_fantasia, razao_social) VALUES ($1, '', $2)`,
    [unitId, expectedUnitName],
  );
  await pool.query(`
    INSERT INTO clients (id, name, type)
    SELECT ('20000000-0000-4000-8000-' || lpad(to_hex(n), 12, '0'))::uuid,
           'Cliente PostgreSQL ' || lpad(n::text, 4, '0'),
           'FISICA'
      FROM generate_series(1, 1005) AS n
  `);
  await pool.query(`
    INSERT INTO admissions (
      id, unit_id, client_id, titular_client_id, client_name, contract_number, status
    )
    SELECT ('30000000-0000-4000-8000-' || lpad(to_hex(n), 12, '0'))::uuid,
           $1,
           ('20000000-0000-4000-8000-' || lpad(to_hex(n), 12, '0'))::uuid,
           ('20000000-0000-4000-8000-' || lpad(to_hex(n), 12, '0'))::uuid,
           'Cliente PostgreSQL ' || lpad(n::text, 4, '0'),
           'Contrato PostgreSQL ' || lpad(n::text, 4, '0'),
           'PENDENTE'
      FROM generate_series(1, 1005) AS n
  `, [unitId]);

  const exportQueries = [];
  const exportPool = {
    async connect() {
      const client = await pool.connect();
      return {
        async query(sql, params) {
          if (sql.startsWith('SELECT') && !sql.includes('FROM "clients" AS t')
            && !sql.includes('FROM "admissions" AS t')) {
            return { rows: [] };
          }
          if (sql.startsWith('SELECT')) exportQueries.push({ sql, params });
          return client.query(sql, params);
        },
        release() { client.release(); },
      };
    },
  };
  const app = express();
  app.use('/api/import', (req, _res, next) => {
    req.currentUser = { ...USER, currentUnitId: unitId };
    next();
  }, createDataImportRoutes(exportPool));
  server = createServer(app);
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));

  const response = await fetch(`http://127.0.0.1:${server.address().port}/api/import/export`, {
    method: 'POST',
  });
  assert.equal(response.status, 200, await response.clone().text());
  const exportedBuffer = Buffer.from(await response.arrayBuffer());
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(exportedBuffer);

  const admissionSheet = workbook.getWorksheet('Admissões');
  assert.ok(admissionSheet, 'the export should include admissions');
  assert.equal(admissionSheet.rowCount - 1, 1005, 'all related admissions should be exported');
  const admissionHeaders = admissionSheet.getRow(1).values.slice(1);
  const clientNameColumn = admissionHeaders.indexOf('Cliente Titular') + 1;
  const unitNameColumn = admissionHeaders.indexOf('Unidade') + 1;
  assert.ok(clientNameColumn > 0, 'the admissions export should include the linked client name');
  assert.ok(unitNameColumn > 0, 'the admissions export should include the linked unit name');
  const boundaryRows = [999, 1000, 1001];
  for (const rowNumber of boundaryRows) {
    const expectedClientName = `Cliente PostgreSQL ${String(rowNumber).padStart(4, '0')}`;
    assert.equal(
      admissionSheet.getRow(rowNumber + 1).getCell(clientNameColumn).value,
      expectedClientName,
      `the client JOIN should return the correct name on admission row ${rowNumber}`,
    );
    assert.equal(
      admissionSheet.getRow(rowNumber + 1).getCell(unitNameColumn).value,
      expectedUnitName,
      `the UUID-to-text unit JOIN should return the correct name on admission row ${rowNumber}`,
    );
  }

  const admissionsQueries = exportQueries.filter(query => query.sql.includes('FROM "admissions" AS t'));
  assert.equal(admissionsQueries.length, 2, 'PostgreSQL should execute the admission export in two pages');
  assert.equal(admissionsQueries[0].params.at(-1), '');
  assert.equal(admissionsQueries[1].params.at(-1), '30000000-0000-4000-8000-0000000003e8');
  const unitJoinAlias = `parent_${unitNameColumn - 1}`;
  assert.ok(admissionsQueries[0].sql.includes(
    `("${unitJoinAlias}".id)::text = (t."unit_id")::text`,
  ),
    'the unit link should execute the UUID-to-text comparison in PostgreSQL');

  const importMappings = Object.fromEntries([
    ['clients', []],
    ['admissions', [{
    fieldKey: 'titular_client_name',
    sheetColumn: 'Cliente Titular',
  }, {
    fieldKey: 'unit_name',
    sheetColumn: 'Unidade',
  }]],
  ]);
  const parsedImport = await parseXlsxImport(exportedBuffer, ['admissions', 'clients'], importMappings);
  const parsedAdmissions = parsedImport.find(group => group.table === 'admissions');
  const parsedClients = parsedImport.find(group => group.table === 'clients');
  assert.equal(parsedAdmissions.rows.length, 1005, 'the importer should read every paginated admission row');
  assert.equal(parsedClients.rows.length, 1005,
    'explicitly selecting Clients should read its sheet alongside Admissions');
  for (const rowNumber of boundaryRows) {
    const imported = parsedAdmissions.rows[rowNumber - 1];
    assert.equal(imported.titular_client_name, `Cliente PostgreSQL ${String(rowNumber).padStart(4, '0')}`);
    assert.equal(imported.unit_name, expectedUnitName);
  }
});

test('import number parsing accepts Brazilian and Excel decimal formats', () => {
  assert.equal(parseImportNumber('1.234,56'), 1234.56);
  assert.equal(parseImportNumber('1,234.56'), 1234.56);
  assert.equal(parseImportNumber('1234.56'), 1234.56);
  assert.equal(parseImportNumber('1234,56'), 1234.56);
  assert.equal(parseImportNumber('1.234'), 1234);
  assert.equal(parseImportNumber('valor inválido'), null);
});

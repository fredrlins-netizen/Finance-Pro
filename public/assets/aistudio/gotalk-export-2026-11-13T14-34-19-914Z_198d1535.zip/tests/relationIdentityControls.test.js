import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import test from 'node:test';

test('seletores jurídicos e bancários enviam IDs, mantendo rótulos apenas para exibição', async () => {
  const legal = await readFile(new URL('../components/juridico/LegalPanel.tsx', import.meta.url), 'utf8');
  assert.match(legal, /value=\{currentProcess\.admissionId \|\| ''\}/);
  assert.match(legal, /option key=\{adm\.id\} value=\{adm\.id\}/);
  assert.doesNotMatch(legal, /option key=\{adm\.id\} value=\{adm\.contractNumber\}/);
  const deals = await readFile(new URL('../components/comercial/NegotiationPanel.tsx', import.meta.url), 'utf8');
  assert.match(deals, /bank_id: formData\.bankId \|\| null/);
  assert.match(deals, /option key=\{bank\.id\} value=\{bank\.id\}/);
});

test('sincronização de operadores e canais não reconstrói vínculos por nome', async () => {
  const poller = await readFile(new URL('../server/services/gotalkPoller.js', import.meta.url), 'utf8');
  const operators = poller.slice(poller.indexOf('async function importOperators('), poller.indexOf('// ── Strategy 0:'));
  assert.match(operators, /if \(opRow\.collaborator_id\) continue/);
  assert.match(operators, /findUniqueCollaboratorByPhone\(dbClient, phone\)/);
  assert.doesNotMatch(operators, /wordOverlapScore|LOWER\(name\)|normalizeNameForMatch/);
  const routes = await readFile(new URL('../server/routes/gotalk.js', import.meta.url), 'utf8');
  const channelScan = routes.slice(routes.indexOf("router.post('/channels/scan-all'"));
  assert.match(channelScan, /WHERE channel_id = \$1/);
  assert.match(channelScan, /byPhone\.rows\.length === 1/);
  assert.doesNotMatch(channelScan, /LOWER\(name\)|byName/);
});

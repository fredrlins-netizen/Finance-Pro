import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { createBoundedPollerScheduler } from '../whatsapp-worker/services/boundedPollerScheduler.js';

const deferred = () => {
  let resolve, reject;
  const promise = new Promise((ok, fail) => { resolve = ok; reject = fail; });
  return { promise, resolve, reject };
};
const tick = () => new Promise(resolve => setImmediate(resolve));

test('nove tarefas usam no máximo duas vagas e intervalos repetidos não acumulam cópias', async () => {
  const scheduler = createBoundedPollerScheduler();
  const gates = Array.from({ length: 9 }, deferred);
  const started = [];
  let simultaneous = 0, peak = 0;
  const tasks = gates.map((gate, index) => scheduler.submit(`task-${index}`, async () => {
    started.push(index);
    peak = Math.max(peak, ++simultaneous);
    await gate.promise;
    simultaneous--;
  }));
  await tick();
  for (let interval = 0; interval < 100; interval++) {
    for (let index = 0; index < 9; index++) {
      assert.equal(scheduler.submit(`task-${index}`, () => assert.fail('cópia repetida')), tasks[index]);
    }
  }
  assert.deepEqual(started, [0, 1]);
  assert.equal(scheduler.activeCount, 2);
  assert.equal(scheduler.pendingCount, 7);
  for (const gate of gates) {
    gate.resolve();
    await tick();
  }
  await Promise.all(tasks);
  assert.equal(peak, 2);
  assert.deepEqual(started, [0, 1, 2, 3, 4, 5, 6, 7, 8]);
  assert.equal(scheduler.activeCount, 0);
  assert.equal(scheduler.pendingCount, 0);
});

test('erro libera a vaga e a tarefa pode ser agendada novamente', async () => {
  const scheduler = createBoundedPollerScheduler({ concurrency: 1 });
  const failure = scheduler.submit('falha', () => { throw new Error('DB indisponível'); });
  const next = scheduler.submit('seguinte', () => 'ok');
  await assert.rejects(failure, /DB indisponível/);
  assert.equal(await next, 'ok');
  assert.equal(await scheduler.submit('falha', () => 'recuperada'), 'recuperada');
  assert.equal(scheduler.activeCount, 0);
});

test('parada descarta pendências sem interromper o lote ativo e permite reinício', async () => {
  const scheduler = createBoundedPollerScheduler({ concurrency: 1 });
  const gate = deferred();
  const active = scheduler.submit('ativo', () => gate.promise);
  const pending = scheduler.submit('pendente', () => assert.fail('executou após parar'));
  await tick();
  assert.equal(scheduler.cancelPending(), 1);
  assert.equal(await pending, undefined);
  assert.equal(scheduler.activeCount, 1);
  gate.resolve();
  await active;
  assert.equal(await scheduler.submit('pendente', () => 'reiniciada'), 'reiniciada');
});

// Execute the actual poller's lifecycle with isolated timers, auth and database.
// No credentials, network, database records or real timers are used.
const serverEntry = new URL('../server/index.js', import.meta.url);
const runtimeImport = readFileSync(serverEntry, 'utf8')
  .match(/import \{ startPoller as startGotalkPoller \} from '([^']+)'/)[1];
const pollerVariants = [
  { url: new URL('../server/services/gotalkPoller.js', import.meta.url), initial: 2, timers: 4 },
  { url: new URL(runtimeImport, serverEntry), initial: 1, timers: 5 },
];

function isolatedPoller(authenticate, url) {
  const timers = new Map(), errors = [];
  let id = 0;
  const sandbox = {
    createBoundedPollerScheduler, authenticate,
    syncAllChannels: async () => {},
    getChannelId: async () => 'fixture-channel',
    gotalkFetch: async () => ({ ok: true, json: async () => [] }),
    transcribeAudio: async () => null,
    emitGotalkNewMessage() {}, emitGotalkAckUpdate() {},
    process: { env: { GOTALK_LOGIN: 'fixture', GOTALK_PASSWORD: 'fixture' } },
    console: { log() {}, warn() {}, error: (...args) => errors.push(args) },
    setInterval: (fn, ms) => { timers.set(++id, { fn, ms, interval: true }); return id; },
    setTimeout: (fn, ms) => { timers.set(++id, { fn, ms, interval: false }); return id; },
    clearInterval: handle => timers.delete(handle),
  };
  const source = readFileSync(url, 'utf8')
    .replace(/^import .*;$/gm, '')
    .replace(/export\s*\{[\s\S]*?\};\s*$/, 'globalThis.api = { startPoller, stopPoller };');
  vm.runInNewContext(source, sandbox);
  return { api: sandbox.api, timers, errors };
}

test('autenticação concluída após parar não recria agendamentos nem retentativas', async () => {
  for (const variant of pollerVariants) {
  for (const fail of [false, true]) {
    const auth = deferred();
    const { api, timers, errors } = isolatedPoller(() => auth.promise, variant.url);
    api.startPoller({});
    api.stopPoller();
    if (fail) auth.reject(new Error('fixture auth error'));
    else auth.resolve();
    await tick();
    assert.equal(timers.size, 0);
    assert.equal(errors.length, 0);
  }
  }
});

test('poller real limita os ciclos distintos e remove agendamentos e fila ao parar', async () => {
  for (const variant of pollerVariants) {
  const { api, timers, errors } = isolatedPoller(async () => {}, variant.url);
  const gate = deferred();
  let databaseStarts = 0, connects = 0, queries = 0;
  const client = { query: async () => { queries++; return { rows: [] }; }, release() {} };
  const pool = {
    async connect() { connects++; databaseStarts++; await gate.promise; return client; },
    async query() { queries++; databaseStarts++; await gate.promise; return { rows: [] }; },
  };
  api.startPoller(pool);
  await tick();
  assert.equal(databaseStarts, variant.initial);
  assert.equal(timers.size, variant.timers);
  for (const [handle, timer] of [...timers]) {
    if (!timer.interval) { timers.delete(handle); timer.fn(); }
  }
  await tick();
  assert.equal(databaseStarts, 2, 'ciclos médio, baixo e horário aguardam as duas vagas');
  api.stopPoller();
  assert.equal(timers.size, 0);
  gate.resolve();
  await tick();
  await tick();
  assert.equal(databaseStarts, 2, 'tarefas pendentes não acessam o banco após a parada');
  assert.equal(connects, 1);
  assert.equal(queries, 2);
  assert.deepEqual(errors, []);
  }
});

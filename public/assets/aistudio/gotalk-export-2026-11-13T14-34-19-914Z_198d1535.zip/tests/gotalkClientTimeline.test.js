import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { once } from 'node:events';
import { mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import path from 'node:path';
import test from 'node:test';
import express from 'express';
import pg from 'pg';
import { createGotalkRoutes } from '../server/routes/gotalk.js';

const { Client: PgClient } = pg;

test('GET /api/gotalk/client-timeline entrega a transcrição de mensagens de áudio', async t => {
  const transcript = 'Olá, esta é a transcrição do áudio.';
  const queries = [];
  const pool = {
    async query(sql, params) {
      queries.push({ sql, params });
      if (sql.includes('COUNT(*)')) return { rows: [{ count: '1' }] };
      return {
        rows: [{
          message_id: '40000000-0000-4000-8000-000000000001',
          phone_number: '5581999999999',
          message_type: 'audio',
          body: null,
          audio_transcript: transcript,
          sent_at: '2026-09-21T12:00:00.000Z',
        }],
      };
    },
  };

  const app = express();
  app.use('/api/gotalk', createGotalkRoutes(pool));
  const server = app.listen(0);
  t.after(() => server.close());
  await once(server, 'listening');

  const { port } = server.address();
  const response = await fetch(
    `http://127.0.0.1:${port}/api/gotalk/client-timeline?phone=5581999999999`,
  );
  const payload = await response.json();

  assert.equal(response.status, 200);
  assert.equal(payload.messages.length, 1);
  assert.equal(payload.messages[0].audio_transcript, transcript);
  assert.equal(payload.total, 1);
  assert.equal(queries.length, 2);
  assert.match(queries[0].sql, /FROM v_gotalk_client_timeline/);
});

for (const { order, sqlOrder } of [
  { order: 'asc', sqlOrder: 'ASC' },
  { order: 'desc', sqlOrder: 'DESC' },
]) {
  test(`GET /api/gotalk/client-timeline preserva paginação em ordem ${order}`, async t => {
    const queries = [];
    const pool = {
      async query(sql, params) {
        queries.push({ sql, params });
        if (sql.includes('COUNT(*)')) return { rows: [{ count: '37' }] };
        return {
          rows: [{
            message_id: `40000000-0000-4000-8000-00000000000${order === 'asc' ? '2' : '3'}`,
            phone_number: '5581999999999',
            message_type: 'text',
            body: `Mensagem em ordem ${order}`,
            sent_at: '2026-09-21T12:00:00.000Z',
          }],
        };
      },
    };

    const app = express();
    app.use('/api/gotalk', createGotalkRoutes(pool));
    const server = app.listen(0);
    t.after(() => server.close());
    await once(server, 'listening');

    const { port } = server.address();
    const response = await fetch(
      `http://127.0.0.1:${port}/api/gotalk/client-timeline?phone=5581999999999&order=${order}&limit=7&offset=14`,
    );
    const payload = await response.json();

    assert.equal(response.status, 200);
    assert.deepEqual(payload.messages, [{
      message_id: `40000000-0000-4000-8000-00000000000${order === 'asc' ? '2' : '3'}`,
      phone_number: '5581999999999',
      message_type: 'text',
      body: `Mensagem em ordem ${order}`,
      sent_at: '2026-09-21T12:00:00.000Z',
    }]);
    assert.equal(payload.total, 37);
    assert.equal(payload.limit, 7);
    assert.equal(payload.offset, 14);
    assert.equal(queries.length, 2);
    assert.match(queries[0].sql, new RegExp(`ORDER BY sent_at ${sqlOrder}, message_id ${sqlOrder}\\s+LIMIT \\$2 OFFSET \\$3`));
    assert.deepEqual(queries[0].params, ['99999999', 7, 14]);
    assert.deepEqual(queries[1].params, ['99999999']);
  });
}



for (const { order, sqlOrder, ids } of [
  { order: 'asc', sqlOrder: 'ASC', ids: ['001', '002', '003', '004'] },
  { order: 'desc', sqlOrder: 'DESC', ids: ['004', '003', '002', '001'] },
]) {
  test(`GET /api/gotalk/client-timeline não repete mensagens com horários iguais em ordem ${order}`, async t => {
    const queries = [];
    const pool = {
      async query(sql, params) {
        queries.push({ sql, params });
        if (sql.includes('COUNT(*)')) return { rows: [{ count: '4' }] };

        const offset = params[2];
        return {
          rows: ids.slice(offset, offset + params[1]).map(id => ({
            message_id: `40000000-0000-4000-8000-000000000${id}`,
            sent_at: '2026-09-21T12:00:00.000Z',
          })),
        };
      },
    };

    const app = express();
    app.use('/api/gotalk', createGotalkRoutes(pool));
    const server = app.listen(0);
    t.after(() => server.close());
    await once(server, 'listening');

    const { port } = server.address();
    const baseUrl = `http://127.0.0.1:${port}/api/gotalk/client-timeline?phone=5581999999999&order=${order}&limit=2`;
    const firstPage = await (await fetch(`${baseUrl}&offset=0`)).json();
    const secondPage = await (await fetch(`${baseUrl}&offset=2`)).json();
    const firstIds = firstPage.messages.map(message => message.message_id);
    const secondIds = secondPage.messages.map(message => message.message_id);

    assert.deepEqual(firstIds, ids.slice(0, 2).map(id => `40000000-0000-4000-8000-000000000${id}`));
    assert.deepEqual(secondIds, ids.slice(2).map(id => `40000000-0000-4000-8000-000000000${id}`));
    assert.deepEqual(firstIds.filter(id => secondIds.includes(id)), []);
    assert.match(
      queries[0].sql,
      new RegExp(`ORDER BY sent_at ${sqlOrder}, message_id ${sqlOrder}\\s+LIMIT \\$2 OFFSET \\$3`),
    );
    assert.match(
      queries[2].sql,
      new RegExp(`ORDER BY sent_at ${sqlOrder}, message_id ${sqlOrder}\\s+LIMIT \\$2 OFFSET \\$3`),
    );
  });
}

for (const { order, sqlOrder, comparison, ids } of [
  { order: 'asc', sqlOrder: 'ASC', comparison: '>', ids: ['001', '002', '003', '004'] },
  { order: 'desc', sqlOrder: 'DESC', comparison: '<', ids: ['004', '003', '002', '001'] },
]) {
  test(`GET /api/gotalk/client-timeline usa cursor estável em ordem ${order} após inserção concorrente`, async t => {
    const sentAt = '2026-09-21T12:00:00.000Z';
    const messages = ids.map(id => ({
      message_id: `40000000-0000-4000-8000-000000000${id}`,
      sent_at: sentAt,
    }));
    const queries = [];
    const pool = {
      async query(sql, params) {
        queries.push({ sql, params });
        if (sql.includes('COUNT(*)')) return { rows: [{ count: String(messages.length) }] };
        if (params.length === 3) return { rows: messages.slice(0, params[1]) };

        const cursorId = params[2];
        const cursorIndex = messages.findIndex(message => message.message_id === cursorId);
        return { rows: messages.slice(cursorIndex + 1, cursorIndex + 1 + params[3]) };
      },
    };

    const app = express();
    app.use('/api/gotalk', createGotalkRoutes(pool));
    const server = app.listen(0);
    t.after(() => server.close());
    await once(server, 'listening');

    const { port } = server.address();
    const baseUrl = `http://127.0.0.1:${port}/api/gotalk/client-timeline?phone=5581999999999&order=${order}&limit=2`;
    const firstPage = await (await fetch(baseUrl)).json();

    // Uma mensagem nova no início da ordenação deslocaria uma segunda página por offset.
    messages.unshift({
      message_id: order === 'asc'
        ? '40000000-0000-4000-8000-000000000000'
        : '40000000-0000-4000-8000-000000000999',
      sent_at: sentAt,
    });

    const secondPage = await (
      await fetch(`${baseUrl}&cursor=${encodeURIComponent(firstPage.next_cursor)}&direction=next`)
    ).json();
    const firstIds = firstPage.messages.map(message => message.message_id);
    const secondIds = secondPage.messages.map(message => message.message_id);

    assert.deepEqual(firstIds, ids.slice(0, 2).map(id => `40000000-0000-4000-8000-000000000${id}`));
    assert.deepEqual(secondIds, ids.slice(2).map(id => `40000000-0000-4000-8000-000000000${id}`));
    assert.deepEqual(firstIds.filter(id => secondIds.includes(id)), []);
    assert.match(
      queries[2].sql,
      new RegExp(`\\(sent_at, message_id\\) \\${comparison} \\(\\$2::timestamptz, \\$3\\)[\\s\\S]*ORDER BY sent_at ${sqlOrder}, message_id ${sqlOrder}[\\s\\S]*LIMIT \\$4`),
    );
    assert.deepEqual(queries[2].params, [
      '99999999',
      sentAt,
      `40000000-0000-4000-8000-000000000${ids[1]}`,
      2,
    ]);
    assert.equal(secondPage.offset, null);
    assert.ok(secondPage.previous_cursor);
    assert.ok(secondPage.next_cursor);
  });
}

test('GET /api/gotalk/client-timeline pagina timestamps iguais sem repetir ou omitir no PostgreSQL', { timeout: 60_000 }, async t => {
  const postgresDir = await mkdtemp(path.join(tmpdir(), 'gotalk-timeline-pg-'));
  const socketDir = path.join(postgresDir, 'socket');
  const dataDir = path.join(postgresDir, 'data');
  const port = 20_000 + Math.floor(Math.random() * 20_000);
  let postgresStarted = false;
  let database;
  let server;

  t.after(async () => {
    if (server) await new Promise(resolve => server.close(resolve));
    if (database) await database.end();
    if (postgresStarted) {
      execFileSync('pg_ctl', ['-D', dataDir, '-m', 'immediate', '-w', 'stop'], { stdio: 'ignore' });
    }
    await rm(postgresDir, { recursive: true, force: true });
  });

  execFileSync('mkdir', ['-p', socketDir]);
  execFileSync('initdb', ['-D', dataDir, '-A', 'trust', '-U', 'postgres', '--no-locale'], { stdio: 'ignore' });
  execFileSync('pg_ctl', [
    '-D', dataDir,
    '-o', `-F -k ${socketDir} -p ${port}`,
    '-w',
    'start',
  ], { stdio: 'ignore' });
  postgresStarted = true;

  database = new PgClient({
    host: socketDir,
    port,
    user: 'postgres',
    database: 'postgres',
  });
  await database.connect();
  await database.query(`
    CREATE TABLE gotalk_messages (
      id UUID PRIMARY KEY,
      phone_number VARCHAR(30) NOT NULL,
      sent_at TIMESTAMPTZ NOT NULL
    );
    CREATE VIEW v_gotalk_client_timeline AS
    SELECT id AS message_id, phone_number, sent_at
    FROM gotalk_messages;
  `);

  const sentAt = '2026-09-21T12:00:00.000Z';
  const ascendingIds = ['001', '002', '003', '004', '005']
    .map(suffix => `40000000-0000-4000-8000-000000000${suffix}`);
  for (const id of ascendingIds) {
    await database.query(
      `INSERT INTO gotalk_messages (id, phone_number, sent_at)
       VALUES ($1, $2, $3)`,
      [id, '5581999999999', sentAt],
    );
  }

  const app = express();
  app.use('/api/gotalk', createGotalkRoutes(database));
  server = app.listen(0);
  await once(server, 'listening');
  const { port: appPort } = server.address();

  for (const { order, expectedIds } of [
    { order: 'asc', expectedIds: ascendingIds },
    { order: 'desc', expectedIds: [...ascendingIds].reverse() },
  ]) {
    const receivedIds = [];
    let cursor = null;

    do {
      const url = new URL(`http://127.0.0.1:${appPort}/api/gotalk/client-timeline`);
      url.searchParams.set('phone', '5581999999999');
      url.searchParams.set('order', order);
      url.searchParams.set('limit', '2');
      if (cursor) {
        url.searchParams.set('cursor', cursor);
        url.searchParams.set('direction', 'next');
      }

      const response = await fetch(url);
      const page = await response.json();
      assert.equal(response.status, 200);
      assert.equal(page.total, ascendingIds.length);
      receivedIds.push(...page.messages.map(message => message.message_id));
      cursor = page.messages.length === 2 ? page.next_cursor : null;
    } while (cursor);

    assert.deepEqual(receivedIds, expectedIds);
    assert.equal(new Set(receivedIds).size, ascendingIds.length);
  }
});

test('GET /api/gotalk/client-timeline busca a página anterior e preserva a ordem solicitada', async t => {
  const queries = [];
  const rows = [
    { message_id: '40000000-0000-4000-8000-000000000002', sent_at: '2026-09-21T12:00:00.000Z' },
    { message_id: '40000000-0000-4000-8000-000000000001', sent_at: '2026-09-21T12:00:00.000Z' },
  ];
  const cursor = Buffer.from(JSON.stringify({
    sent_at: '2026-09-21T12:00:00.000Z',
    message_id: '40000000-0000-4000-8000-000000000003',
  })).toString('base64url');
  const pool = {
    async query(sql, params) {
      queries.push({ sql, params });
      if (sql.includes('COUNT(*)')) return { rows: [{ count: '4' }] };
      return { rows };
    },
  };

  const app = express();
  app.use('/api/gotalk', createGotalkRoutes(pool));
  const server = app.listen(0);
  t.after(() => server.close());
  await once(server, 'listening');

  const { port } = server.address();
  const response = await fetch(
    `http://127.0.0.1:${port}/api/gotalk/client-timeline?phone=5581999999999&order=asc&limit=2&direction=previous&cursor=${cursor}`,
  );
  const payload = await response.json();

  assert.equal(response.status, 200);
  assert.deepEqual(payload.messages.map(message => message.message_id), [
    '40000000-0000-4000-8000-000000000001',
    '40000000-0000-4000-8000-000000000002',
  ]);
  assert.match(queries[0].sql, /\(sent_at, message_id\) < \(\$2::timestamptz, \$3\)/);
  assert.match(queries[0].sql, /ORDER BY sent_at DESC, message_id DESC[\s\S]*LIMIT \$4/);
});

test('GET /api/gotalk/client-timeline rejeita cursor inválido', async t => {
  const pool = { query: async () => assert.fail('cursor inválido não deve consultar o banco') };
  const app = express();
  app.use('/api/gotalk', createGotalkRoutes(pool));
  const server = app.listen(0);
  t.after(() => server.close());
  await once(server, 'listening');

  const { port } = server.address();
  const response = await fetch(
    `http://127.0.0.1:${port}/api/gotalk/client-timeline?phone=5581999999999&cursor=invalido`,
  );

  assert.equal(response.status, 400);
  assert.deepEqual(await response.json(), { error: 'Cursor inválido.' });
});

test('Prospecção avança o cursor antigo sem sobrescrevê-lo em atualizações em tempo real', async () => {
  const source = await readFile(
    new URL('../components/comercial/ProspeccaoPanel.tsx', import.meta.url),
    'utf8',
  );
  const loadOlderBlock = source.slice(
    source.indexOf('const loadOlderTimeline = useCallback'),
    source.indexOf('const hasMoreOlderTimeline'),
  );
  const refreshBlock = source.slice(
    source.indexOf('const refreshTimeline = useCallback'),
    source.indexOf('const loadOlderTimeline = useCallback'),
  );

  assert.match(
    loadOlderBlock,
    /order=desc&direction=next&cursor=\$\{encodeURIComponent\(timelineNextCursor\)\}/,
  );
  assert.doesNotMatch(loadOlderBlock, /offset=/);
  assert.match(
    loadOlderBlock,
    /setTimelineNextCursor\(typeof d\.next_cursor === 'string' \? d\.next_cursor : null\)/,
  );
  assert.doesNotMatch(refreshBlock, /setTimelineNextCursor\(/);
});

# Changelog de Mudanças Significativas

*Arquivo histórico. Para o estado atual, consulte o código-fonte e `replit.md`.*

## Task #59 — Security Hardening (COMPLETED)
- Bcrypt, JWT `httpOnly`/`SameSite=strict`, remoção de credenciais hardcoded, CSP

## Task #60 — Performance (COMPLETED)
- Lazy loading, índices GIN/trigram, virtualização `react-window`, paginação client-side

## Task #61 — Scalability (COMPLETED)
- Memoização de contextos, deduplicação de requests, cache limitado a 50 entradas, Page Visibility API

## Task #78 — Segurança e Índices no Banco (COMPLETED)
- Remoção de `DB_CONFIG` do frontend, auditoria `/api/sql`, índices faltantes (migration 021)

## Task #79 — Ficha de Admissão nos 6 módulos (COMPLETED)
- `AdmissionViewerModal`, `GET /api/admissions/:id/attachments`, migration RBAC 022/023

## Task #82/#83 — Deploy Autoscale (COMPLETED)
- Single port, Worker embedded em produção, `npm run start`

## Task #88 — Redis para Produção (COMPLETED)
- IORedis unificado, adapter Socket.io, graceful shutdown, health-check

## Task #209 — Hardening Completo (COMPLETED)
- HTTP compression, PWA API cache `NetworkOnly`, auto-unlock de conta, DB pool 100

## Task #212 — Configuração, Segurança e Validação (COMPLETED)
- `validateEnv()` com tabela auditada, CORS hardening, role restrita `app_user`, VITE_* audit

## Task #308 — Prospecção WhatsApp fixes (COMPLETED)
- Fix `v_gotalk_client_timeline` (DROP+CREATE VIEW), deduplicação de contatos por telefone base, `last_inbound_at` para visibilidade de webhook parado

## Bug Fixes (Mar 2026)
- **FK empty string → null**: `sanitizeFkValue()` no `crudFactory.js`, `legalProcesses.js`, `admissions.js`, `AdmissionPanel.tsx`, `LegalTrackingPanel.tsx`, `CollaboratorsPanel.tsx`
- **Datas**: `birthDate` de `type="date"` para `type="text"` com máscara DD/MM/AAAA
- **BanksPanel**: Fix blank screen (inicialização `services: []` + fetch async)
- **Febraban**: Tabela de referência via BrasilAPI, dropdown no cadastro de bancos

## Refatorações
- **FinancialPanel**: 3,774 → 400 linhas (extraído `AccountsReceivableManager`, `CadastrosFinanceirosPanel`, `CollectionPanel`, `DepartamentosPanel`)
- **AdmissionPanel**: 1,720 → 867 linhas (extraído `AdmissionFormView`, `AdmissionPrintView`, `AdmissionRow`, `utils/admissionVariables.ts`, `ErrorBoundary`)
- **SettingsPanel**: Em progresso (extraído `UnitsTab`, `UsersTab`)

## Seed Data (Mar 2026)
- 1 empresa, 5 bancos, 3 departamentos, 5 modalidades, 2 séries, 1 conta, 5 colaboradores, 10 clientes, 3 usuários
- 8 admissões, 4 agendamentos, 55 títulos financeiros, 37 baixas, 17 movimentações bancárias
- 3 processos jurídicos, 13 movimentações, 3 prazos
- 11 templates de relatórios pré-seedados

## Report Builder (2026-03)
- Schema explorer, layout designer, 5 tipos de gráfico (bar/pizza/linha/mista), subrelatórios, exportação (PDF/Excel/Word/CSV/HTML), permissões por usuário/grupo

## Acompanhamento Jurídico (2026-03)
- Dashboard, CRUD de processos, editor TinyMCE, timeline, prazos/audiências com notificações automáticas, integração com templates de formulários

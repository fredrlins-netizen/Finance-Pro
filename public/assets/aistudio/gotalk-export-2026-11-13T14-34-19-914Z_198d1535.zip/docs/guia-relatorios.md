# Manual Completo do Gerador de Relatórios - FinancePro Assessoria

## Sumário

1. [Visão Geral do Módulo](#1-visão-geral-do-módulo)
2. [Tela Principal e Navegação](#2-tela-principal-e-navegação)
3. [Aba Fonte de Dados](#3-aba-fonte-de-dados)
   - 3.1 [Modo Visual](#31-modo-visual)
   - 3.2 [Modo SQL](#32-modo-sql)
   - 3.3 [Preview de Dados](#33-preview-de-dados)
4. [Aba Layout](#4-aba-layout)
   - 4.1 [Cabeçalho](#41-cabeçalho)
   - 4.2 [Colunas do Detalhe](#42-colunas-do-detalhe)
   - 4.3 [Agrupamento e Quebras](#43-agrupamento-e-quebras)
   - 4.4 [Rodapé](#44-rodapé)
   - 4.5 [Configurações Gerais](#45-configurações-gerais)
5. [Aba Gráficos](#5-aba-gráficos)
   - 5.1 [Tipos de Gráfico](#51-tipos-de-gráfico)
   - 5.2 [Configuração dos Eixos](#52-configuração-dos-eixos)
   - 5.3 [Opções Visuais e Paletas](#53-opções-visuais-e-paletas)
   - 5.4 [Posicionamento e Tamanho](#54-posicionamento-e-tamanho)
6. [Aba Sub-relatórios](#6-aba-sub-relatórios)
   - 6.1 [Resumo Automático](#61-resumo-automático)
   - 6.2 [Query Independente](#62-query-independente)
   - 6.3 [Colunas e Totalizadores](#63-colunas-e-totalizadores)
7. [Aba Preview e Execução](#7-aba-preview-e-execução)
   - 7.1 [Filtros Dinâmicos](#71-filtros-dinâmicos)
   - 7.2 [Geração do Relatório](#72-geração-do-relatório)
   - 7.3 [Exportação](#73-exportação)
8. [Salvando e Gerenciando Relatórios](#8-salvando-e-gerenciando-relatórios)
   - 8.1 [Modal de Salvamento](#81-modal-de-salvamento)
   - 8.2 [Controle de Acesso](#82-controle-de-acesso)
   - 8.3 [Árvore de Relatórios](#83-árvore-de-relatórios)
9. [Modelos de Relatórios Possíveis](#9-modelos-de-relatórios-possíveis)
   - 9.1 [Relatório de Tabela Simples (Cadastro)](#91-relatório-de-tabela-simples-cadastro)
   - 9.2 [Relatório com JOIN entre Tabelas](#92-relatório-com-join-entre-tabelas)
   - 9.3 [Relatório com Agrupamento (GROUP BY)](#93-relatório-com-agrupamento-group-by)
   - 9.4 [Relatório com Gráfico de Barras](#94-relatório-com-gráfico-de-barras)
   - 9.5 [Relatório com Gráfico de Pizza/Rosca](#95-relatório-com-gráfico-de-pizzarosca)
   - 9.6 [Relatório com Gráfico de Linhas/Área](#96-relatório-com-gráfico-de-linhasárea)
   - 9.7 [Relatório com Gráfico Misto (Barras + Linhas)](#97-relatório-com-gráfico-misto-barras--linhas)
   - 9.8 [Relatório com Barras Empilhadas (Stacked)](#98-relatório-com-barras-empilhadas-stacked)
   - 9.9 [Relatório Somente Gráficos](#99-relatório-somente-gráficos)
   - 9.10 [Relatório com Sub-relatório de Resumo](#910-relatório-com-sub-relatório-de-resumo)
   - 9.11 [Relatório com Sub-relatório de Query](#911-relatório-com-sub-relatório-de-query)
   - 9.12 [Relatório Misto Completo (Tabela + Gráficos + Sub-relatório)](#912-relatório-misto-completo-tabela--gráficos--sub-relatório)
   - 9.13 [Relatório com CTE (WITH)](#913-relatório-com-cte-with)
   - 9.14 [Relatório Comparativo (Período x Período)](#914-relatório-comparativo-período-x-período)
   - 9.15 [Relatório de Ranking (TOP N)](#915-relatório-de-ranking-top-n)
   - 9.16 [Relatório de Aging (Vencimentos por Faixa)](#916-relatório-de-aging-vencimentos-por-faixa)
   - 9.17 [Relatório com Múltiplos Gráficos](#917-relatório-com-múltiplos-gráficos)
   - 9.18 [Relatório com Múltiplos Sub-relatórios](#918-relatório-com-múltiplos-sub-relatórios)
   - 9.19 [Relatório com Filtros Dinâmicos Parametrizados](#919-relatório-com-filtros-dinâmicos-parametrizados)
   - 9.20 [Relatório Mobile (Layout Mobile)](#920-relatório-mobile-layout-mobile)
   - 9.21 [Relatório de Admissões com Responsável e Titular](#921-relatório-de-admissões-com-responsável-e-titular)
10. [Referência Completa de Tabelas](#10-referência-completa-de-tabelas)
11. [Referência de Operadores SQL](#11-referência-de-operadores-sql)
12. [Dicas, Boas Práticas e Solução de Problemas](#12-dicas-boas-práticas-e-solução-de-problemas)

---

## 1. Visão Geral do Módulo

O Gerador de Relatórios (Report Builder) é o módulo do FinancePro Assessoria que permite criar relatórios totalmente personalizados utilizando consultas SQL no banco de dados PostgreSQL. Ele está acessível no menu **Relatórios > Relatórios Gerais**.

O módulo oferece:

- Construção visual ou manual de consultas SQL
- Configuração completa de layout (cabeçalho, colunas, rodapé, margens)
- Gráficos interativos (barras, pizza, linhas, mistos, área, rosca)
- Sub-relatórios (resumo automático ou query independente)
- Agrupamento de dados com subtotais
- Filtros dinâmicos parametrizáveis
- Exportação para PDF, Excel, Word, CSV, HTML e impressão direta
- Controle de acesso por usuário e grupo
- Templates salvos organizados por categoria

O sistema aceita apenas consultas de leitura (SELECT/WITH). Comandos de escrita (INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, CREATE) são bloqueados automaticamente por segurança.

---

## 2. Tela Principal e Navegação

### Barra de Ferramentas Superior

Ao abrir o módulo, a barra de ferramentas superior oferece as seguintes ações:

| Botão | Função |
|---|---|
| **Novo** | Cria um novo relatório em branco, resetando todas as configurações |
| **Salvar** | Abre o modal de salvamento para nomear, categorizar e definir permissões |
| **Excluir** | Remove o relatório atualmente selecionado (desativação lógica) |
| **Conteúdo** | Alterna o modo de conteúdo: Dados / Gráficos / Ambos |
| **Layout** | Define o layout de destino: Responsivo / Web / Mobile |

### Painel Lateral Esquerdo (Árvore de Relatórios)

A árvore lateral exibe todos os templates salvos, organizados por categoria:

- Categorias disponíveis: Cadastrais, Financeiro, Comercial, Jurídico, Negociação, Cobrança, Administrativo, Outros
- As categorias iniciam recolhidas e podem ser expandidas com clique
- Relatórios com restrição de acesso exibem um ícone de cadeado
- Ao clicar em um relatório, ele é carregado no builder com todas as suas configurações

### Abas Principais

O builder possui 5 abas de configuração, acessíveis na parte superior da área de trabalho:

1. **Fonte de Dados** - Define a consulta SQL que busca os dados
2. **Layout** - Configura a aparência visual do relatório
3. **Gráficos** - Adiciona e configura visualizações gráficas
4. **Sub-relatórios** - Adiciona seções complementares de dados
5. **Preview** - Executa o relatório e permite exportação

---

## 3. Aba Fonte de Dados

A aba Fonte de Dados é onde você define **de onde vêm os dados** do relatório. Existem dois modos disponíveis:

### 3.1 Modo Visual

O modo visual permite construir a consulta sem escrever SQL, através de uma interface gráfica composta por 4 seções:

#### A. Explorador de Schema (Schema Explorer)

Exibe todas as tabelas do banco de dados com seus campos:

- **Busca**: Campo de texto para filtrar tabelas por nome
- **Seleção de tabelas**: Clique na tabela para expandir e ver suas colunas
- **Seleção de colunas**: Marque os checkboxes das colunas que deseja incluir no relatório
- **Tipos de dados**: Cada coluna exibe um badge colorido com seu tipo (varchar, integer, uuid, numeric, date, boolean, etc.)

**Como usar:**
1. Localize a tabela desejada (use a busca se necessário)
2. Clique no nome da tabela para expandir
3. Marque as colunas que deseja incluir no relatório
4. Repita para outras tabelas se necessário

#### B. Construtor de JOINs (Join Builder)

Aparece automaticamente quando duas ou mais tabelas são selecionadas. Permite definir como as tabelas se relacionam:

- **Sugestão automática**: O sistema tenta sugerir JOINs baseados nas chaves estrangeiras detectadas no banco
- **Configuração manual**: Cada JOIN requer:
  - **Tabela esquerda**: Selecione dentre as tabelas ativas
  - **Coluna esquerda**: Nome da coluna de ligação
  - **Tipo de JOIN**: INNER JOIN, LEFT JOIN ou RIGHT JOIN
  - **Tabela direita**: Selecione dentre as tabelas ativas
  - **Coluna direita**: Nome da coluna de ligação

**Tipos de JOIN disponíveis:**

| Tipo | Descrição | Quando usar |
|---|---|---|
| **INNER JOIN** | Retorna apenas registros que existem em ambas as tabelas | Quando quer somente dados que têm correspondência nas duas tabelas |
| **LEFT JOIN** | Retorna todos da tabela esquerda, mesmo sem correspondência na direita | Quando quer todos os registros da primeira tabela, mesmo os que não têm dados na segunda |
| **RIGHT JOIN** | Retorna todos da tabela direita, mesmo sem correspondência na esquerda | Inverso do LEFT JOIN |

#### C. Construtor de Filtros (Where Builder)

Permite adicionar condições de filtro à consulta:

- **Campo**: Escolha dentre as colunas selecionadas no Schema Explorer
- **Operador**: Selecione o tipo de comparação:
  - `=` (igual)
  - `!=` (diferente)
  - `>` (maior que)
  - `<` (menor que)
  - `>=` (maior ou igual)
  - `<=` (menor ou igual)
  - `LIKE` (contém texto, use % como coringa)
  - `IN` (está na lista)
  - `BETWEEN` (entre dois valores)
  - `IS NULL` (é nulo/vazio)
  - `IS NOT NULL` (não é nulo)
- **Valor**: Pode ser um valor fixo ou um parâmetro dinâmico usando `{{nome_do_parametro}}` (destacado em âmbar)
- **Conector lógico**: Escolha `AND` (E) ou `OR` (OU) entre múltiplas condições

#### D. Ordenação e Agrupamento

- **ORDER BY**: Adicione uma ou mais colunas para definir a ordenação dos resultados
- **GROUP BY**: Adicione colunas para agrupar os resultados (necessário quando usa funções de agregação como SUM, COUNT, AVG)

O SQL é gerado automaticamente em tempo real conforme você faz as seleções.

---

### 3.2 Modo SQL

O modo SQL é destinado a consultas avançadas que o modo visual não consegue representar (CTEs, subqueries, UNION, funções de janela, etc.):

- **Editor de texto**: Área ampla para escrever a consulta SQL diretamente
- **Histórico**: Mantém as últimas 10 consultas executadas com sucesso
  - Clique em uma entrada do histórico para restaurar aquela consulta no editor
- **Execução**: Botão "Executar Preview" para validar e visualizar os dados

**Importante:** O sistema aceita apenas SELECT e WITH (CTE). Qualquer comando de escrita será bloqueado.

---

### 3.3 Preview de Dados

Disponível em ambos os modos, o preview exibe:

- **Indicadores de status**: Spinner de carregamento, mensagens de erro com detalhes do banco, ou estado "sem resultados"
- **Metadados de execução**: Número de registros retornados e tempo de execução em milissegundos
- **Tabela de dados**: Grade rolável com os resultados
  - Valores NULL são exibidos em itálico
  - Conteúdo longo é truncado automaticamente
  - Objetos JSON são convertidos para string
- **Limite**: O preview é limitado a 50 registros para performance

Quando o preview é executado, o sistema detecta automaticamente as colunas disponíveis e as propaga para as abas de Layout e Gráficos.

---

## 4. Aba Layout

A aba Layout configura toda a aparência visual do relatório. Ela é dividida em 5 seções recolhíveis:

### 4.1 Cabeçalho

Configurações do topo do relatório:

| Campo | Descrição | Exemplo |
|---|---|---|
| **Título** | Texto principal do relatório | "Relatório de Clientes" |
| **Subtítulo** | Descrição complementar (opcional) | "Todos os clientes ativos do sistema" |
| **Logotipo** | Upload de imagem (URL ou arquivo Base64) | Logo da empresa |
| **Mostrar Logo** | Liga/desliga a exibição do logotipo (ativado automaticamente ao fazer upload) | Sim/Não |
| **Alinhamento** | Posição do cabeçalho na página | Esquerda / Centro / Direita |
| **Mostrar Data** | Exibe a data de geração do relatório | Sim/Não |

---

### 4.2 Colunas do Detalhe

Cada coluna detectada na consulta SQL pode ser configurada individualmente:

| Campo | Descrição | Opções |
|---|---|---|
| **Visível** | Se a coluna será exibida ou oculta no relatório | Liga/Desliga |
| **Rótulo (Label)** | Nome exibido no cabeçalho da tabela | Texto livre |
| **Largura** | Largura da coluna em percentual ou "auto" | Ex: "15%", "auto" |
| **Alinhamento** | Alinhamento horizontal do conteúdo | Esquerda / Centro / Direita |
| **Formato** | Formatação automática aplicada ao valor | Ver tabela abaixo |
| **Ordem** | Botões de seta para mover a coluna para cima/baixo | Setas |

**Formatos de coluna disponíveis:**

| Formato | Código | Exemplo de saída |
|---|---|---|
| Texto | `text` | João da Silva |
| Número | `number` | 1.234,56 |
| Moeda BRL | `currency_brl` | R$ 1.500,00 |
| Data | `date` | 07/03/2026 |
| CPF/CNPJ | `cpf_cnpj` | 123.456.789-00 ou 12.345.678/0001-99 |
| Percentual | `percent` | 85,50% |

**Como funciona a formatação:**
- `currency_brl`: Converte número para formato brasileiro com R$ e 2 casas decimais
- `date`: Converte data ISO para formato DD/MM/AAAA
- `cpf_cnpj`: Detecta automaticamente se é CPF (11 dígitos) ou CNPJ (14 dígitos) e aplica a máscara
- `percent`: Adiciona o símbolo % com 2 casas decimais
- `number`: Aplica separadores de milhar e 2 casas decimais no padrão brasileiro

---

### 4.3 Agrupamento e Quebras

Permite organizar os dados em grupos visuais com subtotais:

| Campo | Descrição |
|---|---|
| **Campos para agrupar** | Seleção do(s) campo(s) que definem o grupo. Cada valor distinto cria uma seção separada |
| **Template do cabeçalho do grupo** | Texto que aparece no cabeçalho de cada grupo. Use `{campo}` para inserir valores dinamicamente. Ex: `Cliente: {Nome}` |
| **Exibir subtotais** | Liga/desliga a exibição de totais por grupo |
| **Totalizadores** | Para cada coluna numérica, escolha a operação de totalização por grupo |

**Operações de totalização disponíveis:**

| Operação | Código | Descrição |
|---|---|---|
| Nenhum | `nenhum` | Sem totalização |
| Soma | `soma` | Soma de todos os valores do grupo |
| Contagem | `contagem` | Quantidade de registros no grupo |
| Média | `media` | Média aritmética dos valores |
| Mínimo | `min` | Menor valor do grupo |
| Máximo | `max` | Maior valor do grupo |

**Exemplo prático:**
Se o relatório lista títulos financeiros e você agrupa por "Cliente", cada cliente terá seus títulos listados em uma seção separada, com uma barra de cabeçalho azul mostrando o nome do cliente e, opcionalmente, o total de valores daquele grupo.

---

### 4.4 Rodapé

Configurações do rodapé do relatório:

| Campo | Descrição |
|---|---|
| **Exibir totalizadores gerais** | Liga/desliga os totais gerais (de todo o relatório, não apenas do grupo) |
| **Totalizadores** | Mesmas operações disponíveis no agrupamento (soma, contagem, média, min, max), aplicadas ao total geral |
| **Exibir "Página X de Y"** | Mostra a paginação no rodapé |
| **Exibir data/hora** | Mostra a data e hora de geração no rodapé |
| **Texto personalizado** | Texto livre exibido no rodapé de cada página. Ex: "Documento confidencial - FinancePro Assessoria" |

---

### 4.5 Configurações Gerais

Opções que afetam todo o relatório:

| Campo | Opções | Descrição |
|---|---|---|
| **Orientação** | Retrato / Paisagem | Direção da página. Paisagem é recomendado para relatórios com muitas colunas |
| **Tamanho do papel** | A4 / Carta (Letter) / Ofício (Legal) | Dimensões da página para impressão e PDF |
| **Margens** | Superior / Inferior / Esquerda / Direita | Valores em milímetros |
| **Tamanho da fonte** | 8, 9, 10, 11, 12, 14 | Tamanho em pontos. Fontes menores cabem mais dados |
| **Linhas zebradas** | Liga/Desliga | Alternância de cor de fundo nas linhas (cinza claro / branco) para facilitar a leitura |
| **Layout de destino** | Responsivo / Web / Mobile | Como o relatório se adapta ao dispositivo |

**Layouts de destino:**

| Layout | Comportamento |
|---|---|
| **Responsivo** | Adapta automaticamente: tabela no desktop, cards empilhados no mobile |
| **Web** | Largura fixa, otimizado para telas de computador |
| **Mobile** | Colunas empilhadas em formato card, fontes maiores, otimizado para smartphones (360px) |

---

## 5. Aba Gráficos

Permite adicionar uma ou mais visualizações gráficas ao relatório. Cada gráfico é configurado individualmente e pode ser reordenado ou removido.

### 5.1 Tipos de Gráfico

O sistema suporta 4 tipos principais, cada um com subtipos:

| Tipo Principal | Subtipo | Descrição | Melhor para |
|---|---|---|---|
| **Barra** (`bar`) | Vertical | Barras verticais lado a lado | Comparação entre categorias |
| **Barra** (`bar`) | Horizontal | Barras horizontais | Rankings, nomes longos |
| **Barra** (`bar`) | Empilhada (Stacked) | Barras empilhadas mostrando composição | Composição de categorias |
| **Pizza** (`pie`) | Pizza | Círculo completo dividido em fatias | Distribuição percentual |
| **Pizza** (`pie`) | Rosca (Donut) | Pizza com furo no centro | Distribuição com destaque visual |
| **Linhas** (`line`) | Linha | Pontos conectados por linhas | Tendências ao longo do tempo |
| **Linhas** (`line`) | Área | Linha com preenchimento abaixo | Volume/acumulado temporal |
| **Misto** (`mixed`) | - | Combina barras e linhas no mesmo gráfico | Comparar métricas diferentes |

---

### 5.2 Configuração dos Eixos

Cada gráfico precisa de mapeamento de dados:

**Eixo X (Campo X):**
- Selecione a coluna que define as categorias ou períodos
- Ex: "Mês", "Status", "Cliente", "Período"

**Eixo Y (Séries):**
Você pode adicionar uma ou mais séries (campos numéricos). Para cada série:

| Campo | Descrição |
|---|---|
| **Campo** | Nome da coluna numérica dos dados |
| **Operação** | Como agregar os valores: Direto (sem agregação), Soma, Contagem ou Média |
| **Cor** | Cor hexadecimal da série |
| **Tipo de série** (apenas gráfico Misto) | Forçar como Barra ou Linha |
| **Eixo secundário** (apenas gráfico Misto) | Usar eixo Y da direita (útil para escalas diferentes) |

**Operações do Eixo Y:**

| Operação | Código | Descrição |
|---|---|---|
| Direto | `direto` | Usa o valor como está, sem agregação |
| Soma | `soma` | Soma os valores por categoria do eixo X |
| Contagem | `contagem` | Conta os registros por categoria |
| Média | `media` | Calcula a média por categoria |

---

### 5.3 Opções Visuais e Paletas

| Opção | Descrição |
|---|---|
| **Título** | Texto exibido acima do gráfico |
| **Exibir legenda** | Mostra/oculta a legenda na parte inferior |
| **Exibir valores** | Mostra os números sobre as barras/fatias/pontos |
| **Exibir grade** | Mostra/oculta as linhas de fundo (para gráficos com eixos) |
| **Paleta de cores** | Conjunto de cores predefinido |

**Paletas de cores disponíveis:**

| Paleta | Cores | Recomendação |
|---|---|---|
| **Padrão** | Azul, vermelho, verde, amarelo, roxo, rosa, ciano, laranja | Uso geral, boa distinção |
| **Pastel** | Tons suaves das cores padrão | Relatórios impressos, apresentações suaves |
| **Escuro** | Tons escuros e profundos | Alto contraste, apresentações em tela |
| **Monocromático** | Gradiente de tons de azul | Foco em uma dimensão, visual limpo |

As cores da paleta são aplicadas automaticamente em sequência. Cada série Y também pode ter sua cor individual definida manualmente.

---

### 5.4 Posicionamento e Tamanho

| Campo | Opções | Descrição |
|---|---|---|
| **Posição** | Antes / Depois | Onde o gráfico aparece em relação à tabela de dados |
| **Largura** | 100% / 50% | Tela cheia ou meia tela (permite 2 gráficos lado a lado) |

**Dica:** Use largura 50% para colocar dois gráficos lado a lado, como um gráfico de barras e uma pizza.

---

## 6. Aba Sub-relatórios

Sub-relatórios são seções adicionais de dados exibidas abaixo do relatório principal. Você pode adicionar quantos sub-relatórios desejar.

### 6.1 Resumo Automático

Tipo: `summary`

Gera automaticamente um agrupamento e totalização dos dados do relatório principal, sem necessidade de SQL adicional.

**Configuração:**
- **Campo de agrupamento**: Escolha por qual coluna agrupar os dados do relatório principal
- **Operações**: Para cada coluna numérica, defina uma operação:

| Operação | Código | Descrição |
|---|---|---|
| Soma | `sum` | Soma dos valores |
| Contagem | `count` | Quantidade de registros |
| Média | `avg` | Média aritmética |
| Mínimo | `min` | Menor valor |
| Máximo | `max` | Maior valor |

**Exemplo:** Se o relatório principal lista títulos financeiros por cliente, um resumo automático agrupado por "Status" pode mostrar automaticamente quantos títulos estão em cada status e o valor total de cada um.

---

### 6.2 Query Independente

Tipo: `query`

Executa uma consulta SQL separada e independente do relatório principal. Ideal para mostrar dados complementares ou uma perspectiva diferente.

**Configuração:**
- **SQL**: Editor de texto para a consulta SELECT
- **Teste**: Botão "Testar Query" que executa e mostra os primeiros 10 resultados
- **Parâmetros**: Suporta placeholders `{{nome_do_filtro}}` que se conectam aos filtros do relatório principal

**Exemplo:** O relatório principal mostra detalhamento por cliente. O sub-relatório de query pode mostrar um resumo mensal de comportamento financeiro com uma consulta completamente diferente.

---

### 6.3 Colunas e Totalizadores

Para ambos os tipos, cada sub-relatório permite configurar:

**Colunas:**

| Campo | Descrição |
|---|---|
| **Campo (Field)** | Nome da coluna no resultado da query |
| **Rótulo (Label)** | Nome exibido no cabeçalho da tabela |
| **Formato** | Nenhum, Texto, Número, Moeda (R$), Percentual (%), Data, Data/Hora |
| **Alinhamento** | Esquerda, Centro, Direita |
| **Largura** | Percentual da largura total |

**Formatos disponíveis nos sub-relatórios:**

| Formato | Código |
|---|---|
| Nenhum | (vazio) |
| Texto | `text` |
| Número | `number` |
| Moeda (R$) | `currency` |
| Percentual (%) | `percent` |
| Data | `date` |
| Data/Hora | `datetime` |

**Totalizadores:**
Cada coluna numérica pode ter uma operação de totalização no rodapé do sub-relatório (soma, contagem, média, mínimo, máximo).

---

## 7. Aba Preview e Execução

A aba Preview é onde o relatório é efetivamente executado e renderizado.

### 7.1 Filtros Dinâmicos

Se a consulta SQL contém placeholders (`{{nome}}` ou `:nome`), o sistema gera automaticamente campos de entrada para o usuário preencher antes de executar o relatório.

**Tipos de filtro:**

| Tipo | Uso | Exemplo |
|---|---|---|
| `text` | Busca por texto livre | Nome do cliente |
| `date` | Seleção de data | Data início, Data fim |
| `number` | Valor numérico | Valor mínimo |
| `select` | Lista de opções predefinidas | Status, Tipo |

**Como definir filtros na consulta SQL:**

```sql
SELECT * FROM clients
WHERE name ILIKE '%' || {{busca_nome}} || '%'
  AND created_at >= {{data_inicio}}
  AND created_at <= {{data_fim}}
```

Os parâmetros `{{busca_nome}}`, `{{data_inicio}}` e `{{data_fim}}` serão automaticamente detectados e apresentados como campos de entrada na tela de preview.

O sistema substitui os placeholders por parâmetros posicionais ($1, $2, $3) antes de enviar ao banco, garantindo segurança contra SQL injection.

---

### 7.2 Geração do Relatório

1. Preencha os filtros dinâmicos (se houver)
2. Clique em **"Gerar Relatório"**
3. O sistema executa a consulta principal e todas as queries de sub-relatórios em sequência
4. O resultado é renderizado no componente `ReportRenderer` com:
   - Cabeçalho com título, subtítulo, logo e data
   - Gráficos posicionados "antes" da tabela (se configurados)
   - Tabela principal com formatação, agrupamento e subtotais
   - Gráficos posicionados "depois" da tabela (se configurados)
   - Sub-relatórios (cada um com sua própria tabela)
   - Rodapé com totais, paginação, data/hora e texto personalizado

A contagem de registros é exibida após a execução.

---

### 7.3 Exportação

Após gerar o relatório, os seguintes botões de exportação ficam disponíveis:

| Formato | Botão | Descrição | Inclui |
|---|---|---|---|
| **Imprimir** | Imprimir | Abre janela de impressão do navegador | Cabeçalho + dados + sub-relatórios |
| **PDF** | PDF | Gera arquivo PDF formatado (via pdfmake) | Cabeçalho + tabela + sub-relatórios |
| **Excel** | Excel | Gera planilha .xlsx (via exceljs) | Dados na aba principal + sub-relatórios em **abas separadas** |
| **Word** | Word | Gera documento .doc | Cabeçalho + tabela + sub-relatórios em HTML |
| **CSV** | CSV | Gera arquivo texto com separador ponto-e-vírgula | **Apenas dados da tabela principal** (sem gráficos/sub-relatórios) |
| **HTML** | HTML | Gera página HTML standalone | Tudo (cabeçalho, dados, sub-relatórios, estilos) |

**Detalhes importantes de cada formato:**

- **PDF**: Inclui cabeçalho com título/subtítulo, tabela formatada com cores zebradas, sub-relatórios e rodapé. Respeita orientação (retrato/paisagem) e tamanho do papel
- **Excel**: Sub-relatórios são colocados em planilhas (sheets) separadas, nomeadas pelo título do sub-relatório. Dados numéricos mantêm o formato para cálculos
- **Word**: Gera HTML com namespaces XML do Word para compatibilidade com Microsoft Word
- **CSV**: Usa ponto-e-vírgula (;) como separador e inclui BOM UTF-8 para compatibilidade com Excel em português. Apenas dados da tabela principal
- **HTML**: Arquivo HTML completo e autossuficiente com estilos inline

---

## 8. Salvando e Gerenciando Relatórios

### 8.1 Modal de Salvamento

Ao clicar em **Salvar**, o modal oferece os seguintes campos:

| Campo | Obrigatório | Descrição |
|---|---|---|
| **Nome** | Sim | Nome do relatório (deve ser preenchido) |
| **Descrição** | Não | Texto descritivo do propósito do relatório |
| **Categoria** | Sim | Classificação do relatório (padrão: Outros) |
| **Layout** | Sim | Responsivo, Web ou Mobile |
| **Conteúdo** | Sim | Dados, Gráficos ou Ambos |
| **Usuários Permitidos** | Não | Lista de usuários que podem ver este relatório |
| **Grupos Permitidos** | Não | Lista de grupos que podem ver este relatório |

**Categorias disponíveis:**
Cadastrais, Financeiro, Comercial, Jurídico, Negociação, Cobrança, Administrativo, Outros

---

### 8.2 Controle de Acesso

O sistema de permissões funciona assim:

- **Sem restrição** (padrão): Se nenhum usuário e nenhum grupo for selecionado, **todos** os usuários podem ver o relatório
- **Restrição por usuário**: Somente os usuários marcados podem ver
- **Restrição por grupo**: Somente membros dos grupos marcados podem ver
- **Combinação**: Se ambos forem definidos, usuários que estejam em qualquer uma das listas têm acesso
- **Administradores**: Usuários com perfil ADMIN sempre veem todos os relatórios, independente das restrições

Relatórios com restrição são exibidos com um ícone de cadeado na árvore lateral.

---

### 8.3 Árvore de Relatórios

A árvore de relatórios no painel lateral organiza os templates por categoria:

- **Criar novo**: Clique em "Novo" na barra de ferramentas
- **Abrir existente**: Clique no nome do relatório na árvore
- **Editar**: Abra o relatório, faça as alterações e clique em "Salvar"
- **Excluir**: Abra o relatório e clique em "Excluir" (desativação lógica - pode ser recuperado)

---

## 9. Modelos de Relatórios Possíveis

A seguir, todos os modelos de relatórios que podem ser criados com o Report Builder, com instruções passo a passo e exemplos de SQL.

---

### 9.1 Relatório de Tabela Simples (Cadastro)

**O que é:** Consulta SELECT direta em uma única tabela, sem JOINs.

**Quando usar:** Listagem de cadastros, inventários, catálogos.

**Passo a passo:**
1. Aba **Fonte de Dados** > Modo Visual: selecione a tabela e as colunas desejadas. Ou Modo SQL, escreva o SELECT
2. Aba **Layout**: configure rótulos das colunas, formatos (CPF, moeda, data), alinhamento
3. Aba **Preview**: execute e exporte

**Exemplo SQL - Cadastro de Clientes:**
```sql
SELECT
  c.name AS "Nome",
  c.document AS "CPF/CNPJ",
  c.phone AS "Telefone",
  c.email AS "E-mail",
  c.city AS "Cidade",
  c.state AS "UF",
  c.type AS "Tipo",
  TO_CHAR(c.created_at, 'DD/MM/YYYY') AS "Data Cadastro"
FROM clients c
ORDER BY c.name
```

**Configuração recomendada:**
- Modo de conteúdo: Dados
- Orientação: Paisagem (para muitas colunas)
- Formato da coluna CPF/CNPJ: `cpf_cnpj`
- Rodapé: Contagem total de registros

**Outros exemplos de tabela simples:**

```sql
-- Listagem de Colaboradores
SELECT name AS "Nome", job_title AS "Cargo", phone AS "Telefone",
       email AS "E-mail", city AS "Cidade", state AS "UF"
FROM collaborators ORDER BY name

-- Listagem de Bancos Ativos
SELECT name AS "Banco", febraban_code AS "Código FEBRABAN", status AS "Status"
FROM banks WHERE status = 'ATIVO' ORDER BY name

-- Listagem de Contas Bancárias
SELECT description AS "Descrição", bank_name AS "Banco", agency AS "Agência",
       account_number AS "Conta", current_balance AS "Saldo", status AS "Status"
FROM bank_accounts ORDER BY description
```

---

### 9.2 Relatório com JOIN entre Tabelas

**O que é:** Consulta que combina dados de duas ou mais tabelas relacionadas.

**Quando usar:** Sempre que precisar exibir informações que estão em tabelas diferentes mas se relacionam (ex: cliente + seus títulos financeiros).

**Passo a passo - Modo Visual:**
1. Aba **Fonte de Dados** > selecione as duas tabelas no Schema Explorer
2. O Join Builder aparecerá automaticamente - configure o tipo e as colunas de ligação
3. Selecione as colunas desejadas de ambas as tabelas
4. Execute o preview para verificar

**Passo a passo - Modo SQL:**
1. Escreva o SELECT com INNER JOIN ou LEFT JOIN
2. Execute o preview

**Exemplo SQL - Cliente x Financeiro:**
```sql
SELECT
  c.name AS "Cliente",
  c.document AS "CPF/CNPJ",
  ft.title_scope AS "Tipo",
  ft.description AS "Descrição",
  ft.value AS "Valor",
  ft.status AS "Status",
  TO_CHAR(ft.issue_date, 'DD/MM/YYYY') AS "Emissão",
  TO_CHAR(ft.due_date, 'DD/MM/YYYY') AS "Vencimento"
FROM clients c
INNER JOIN financial_titles ft ON ft.client_id = c.id
ORDER BY c.name, ft.due_date
```

**Configuração recomendada:**
- Agrupamento por "Cliente" para organizar títulos por cliente
- Subtotais com soma do campo "Valor"
- Formato de coluna: `currency_brl` para Valor, `cpf_cnpj` para CPF/CNPJ

**Outros exemplos de JOIN:**

```sql
-- Admissões com dados do Banco
SELECT c.name AS "Cliente", b.name AS "Banco", a.contract_number AS "Contrato",
       a.status AS "Status", a.financed_amount AS "Valor Financiado",
       TO_CHAR(a.date, 'DD/MM/YYYY') AS "Data Admissão"
FROM admissions a
INNER JOIN clients c ON c.id = a.client_id
LEFT JOIN banks b ON b.id = a.bank_id
ORDER BY a.date DESC

-- Títulos com Portador
SELECT ft.description AS "Título", c.name AS "Cliente", br.name AS "Portador",
       ft.value AS "Valor", ft.status AS "Status",
       TO_CHAR(ft.due_date, 'DD/MM/YYYY') AS "Vencimento"
FROM financial_titles ft
INNER JOIN clients c ON c.id = ft.client_id
LEFT JOIN bearers br ON br.id = ft.bearer_id
ORDER BY ft.due_date

-- Admissões com Responsável e Titular (JOIN duplo na tabela clients)
SELECT a.contract_number AS "Contrato",
       TO_CHAR(a.date, 'DD/MM/YYYY') AS "Data Admissão",
       a.status AS "Status",
       resp.name AS "Responsável - Nome",
       resp.document AS "Responsável - CPF/CNPJ",
       resp.phone AS "Responsável - Telefone",
       resp.email AS "Responsável - Email",
       resp.city AS "Responsável - Cidade",
       resp.state AS "Responsável - UF",
       tit.name AS "Titular - Nome",
       tit.document AS "Titular - CPF/CNPJ",
       tit.phone AS "Titular - Telefone",
       tit.email AS "Titular - Email",
       tit.city AS "Titular - Cidade",
       tit.state AS "Titular - UF"
FROM admissions a
LEFT JOIN clients resp ON resp.id = a.client_id
LEFT JOIN clients tit ON tit.id = a.titular_client_id
ORDER BY a.date DESC

-- Movimentações Bancárias com Conta
SELECT ba.description AS "Conta", bm.type AS "Tipo",
       bm.value AS "Valor", bm.history AS "Histórico",
       TO_CHAR(bm.date, 'DD/MM/YYYY') AS "Data"
FROM bank_movements bm
INNER JOIN bank_accounts ba ON ba.id = bm.bank_account_id
ORDER BY bm.date DESC
```

---

### 9.3 Relatório com Agrupamento (GROUP BY)

**O que é:** Consulta que consolida e totaliza dados usando funções de agregação SQL.

**Quando usar:** Resumos gerenciais, totalizações por cliente/período/status, análises quantitativas.

**Funções de agregação SQL:**

| Função | Descrição | Exemplo |
|---|---|---|
| `COUNT(*)` | Conta registros | `COUNT(*)` ou `COUNT(DISTINCT a.id)` |
| `SUM(campo)` | Soma valores | `SUM(ft.value)` |
| `AVG(campo)` | Calcula média | `AVG(ft.value)` |
| `MIN(campo)` | Menor valor | `MIN(ft.due_date)` |
| `MAX(campo)` | Maior valor | `MAX(ft.value)` |
| `ROUND(valor, casas)` | Arredonda | `ROUND(AVG(ft.value), 2)` |
| `COALESCE(valor, padrão)` | Substitui NULL | `COALESCE(SUM(ft.value), 0)` |

**Exemplo SQL - Resumo por Cliente (3 tabelas):**
```sql
SELECT
  c.name AS "Cliente",
  c.document AS "CPF/CNPJ",
  c.city AS "Cidade",
  COUNT(DISTINCT a.id) AS "Qtd Admissões",
  COUNT(DISTINCT ft.id) AS "Qtd Títulos",
  COALESCE(SUM(ft.value), 0) AS "Total a Receber",
  COALESCE(SUM(CASE WHEN ft.status = 'PAGO' THEN ft.value ELSE 0 END), 0) AS "Total Recebido",
  COALESCE(SUM(CASE WHEN ft.status = 'ABERTO' THEN ft.value ELSE 0 END), 0) AS "Total em Aberto"
FROM clients c
LEFT JOIN admissions a ON a.client_id = c.id
LEFT JOIN financial_titles ft ON ft.client_id = c.id AND ft.title_scope = 'RECEBER'
GROUP BY c.id, c.name, c.document, c.city
HAVING COUNT(DISTINCT a.id) > 0 OR COUNT(DISTINCT ft.id) > 0
ORDER BY c.name
```

**Dicas para agrupamento:**
- Use `COALESCE(SUM(...), 0)` para evitar valores NULL quando não há dados
- Use `COUNT(DISTINCT ...)` quando JOINs podem multiplicar registros
- Use `HAVING` para filtrar grupos (diferente de WHERE que filtra linhas antes da agregação)
- Use `CASE WHEN` dentro de SUM para somas condicionais

**Outros exemplos de GROUP BY:**

```sql
-- Resumo Financeiro por Mês
SELECT
  TO_CHAR(ft.due_date, 'YYYY-MM') AS "Período",
  ft.title_scope AS "Tipo",
  COUNT(*) AS "Qtd Títulos",
  SUM(ft.value) AS "Valor Total",
  SUM(CASE WHEN ft.status = 'PAGO' THEN ft.value ELSE 0 END) AS "Pago",
  SUM(CASE WHEN ft.status = 'ABERTO' THEN ft.value ELSE 0 END) AS "Em Aberto"
FROM financial_titles ft
WHERE ft.due_date IS NOT NULL
GROUP BY TO_CHAR(ft.due_date, 'YYYY-MM'), ft.title_scope
ORDER BY "Período" DESC

-- Admissões por Status
SELECT a.status AS "Status", COUNT(*) AS "Quantidade",
       COUNT(DISTINCT a.client_id) AS "Clientes Únicos"
FROM admissions a
GROUP BY a.status
ORDER BY "Quantidade" DESC
```

---

### 9.4 Relatório com Gráfico de Barras

**O que é:** Relatório que inclui gráfico de barras (verticais, horizontais ou empilhadas).

**Quando usar:** Comparação de valores entre categorias, volumes por período.

**Passo a passo:**
1. Aba **Fonte de Dados**: escreva uma consulta que retorne categorias e valores numéricos
2. Aba **Gráficos**: clique em "Adicionar Gráfico"
3. Selecione tipo **Barra** e subtipo (Vertical/Horizontal/Empilhada)
4. Configure Eixo X: campo das categorias
5. Configure Eixo Y: campo dos valores + operação (Soma/Contagem/Média/Direto)
6. Configure título, legenda e paleta

**Exemplo SQL:**
```sql
SELECT
  TO_CHAR(a.date, 'YYYY-MM') AS "Período",
  COUNT(*) AS "Quantidade",
  COALESCE(SUM(CAST(NULLIF(a.financed_amount, '') AS NUMERIC)), 0) AS "Valor Total"
FROM admissions a
WHERE a.date IS NOT NULL
GROUP BY TO_CHAR(a.date, 'YYYY-MM')
ORDER BY "Período"
```

**Configuração do gráfico:**
- Tipo: Barra > Vertical
- Eixo X: "Período"
- Eixo Y: "Quantidade" (operação: Direto)
- Posição: Antes da tabela
- Largura: 100%
- Valores sobre barras: Ligado

---

### 9.5 Relatório com Gráfico de Pizza/Rosca

**O que é:** Gráfico circular que mostra proporções/distribuição.

**Quando usar:** Distribuição percentual, participação por categoria.

**Exemplo SQL:**
```sql
SELECT
  a.status AS "Status",
  COUNT(*) AS "Quantidade"
FROM admissions a
GROUP BY a.status
ORDER BY "Quantidade" DESC
```

**Configuração do gráfico:**
- Tipo: Pizza > Pizza (ou Rosca/Donut)
- Eixo X: "Status"
- Eixo Y: "Quantidade" (operação: Direto)
- Largura: 50% (permite colocar dois gráficos lado a lado)
- Legenda: Ligada
- Valores: Ligados

**Diferença Pizza vs Rosca:**
- **Pizza**: Círculo completo preenchido - melhor para poucas categorias (3-6)
- **Rosca (Donut)**: Com furo no centro - visual mais moderno, funciona bem com mais categorias

---

### 9.6 Relatório com Gráfico de Linhas/Área

**O que é:** Gráfico que mostra evolução temporal ou tendências.

**Quando usar:** Análise de tendências, evolução de métricas ao longo do tempo.

**Exemplo SQL:**
```sql
SELECT
  TO_CHAR(ft.due_date, 'YYYY-MM') AS "Mês",
  SUM(ft.value) AS "Valor Total",
  COUNT(*) AS "Qtd Títulos"
FROM financial_titles ft
WHERE ft.title_scope = 'RECEBER' AND ft.due_date IS NOT NULL
GROUP BY TO_CHAR(ft.due_date, 'YYYY-MM')
ORDER BY "Mês"
```

**Configuração - Gráfico de Linha:**
- Tipo: Linhas > Linha
- Eixo X: "Mês"
- Eixo Y: "Valor Total" (operação: Direto)
- Grade: Ligada

**Configuração - Gráfico de Área:**
- Tipo: Linhas > Área
- Mesma configuração, mas com preenchimento abaixo da linha
- Útil para mostrar volume acumulado

---

### 9.7 Relatório com Gráfico Misto (Barras + Linhas)

**O que é:** Combina barras e linhas no mesmo gráfico, permitindo comparar métricas de escalas diferentes.

**Quando usar:** Quando precisa mostrar duas métricas diferentes (ex: valor total em barras + ticket médio em linha).

**Exemplo SQL:**
```sql
SELECT
  TO_CHAR(ft.due_date, 'YYYY-MM') AS "Período",
  SUM(ft.value) AS "Valor Total",
  COUNT(*) AS "Qtd Títulos",
  ROUND(AVG(ft.value), 2) AS "Ticket Médio"
FROM financial_titles ft
WHERE ft.due_date IS NOT NULL AND ft.title_scope = 'RECEBER'
GROUP BY TO_CHAR(ft.due_date, 'YYYY-MM')
ORDER BY "Período"
```

**Configuração do gráfico misto:**
- Tipo: Misto
- Eixo X: "Período"
- Série 1: "Valor Total" (operação: Direto, tipo: Barra, cor: azul)
- Série 2: "Ticket Médio" (operação: Direto, tipo: Linha, eixo secundário: Sim, cor: vermelho)

O eixo secundário (direita) é essencial quando as escalas são muito diferentes (ex: R$ milhares vs R$ centenas).

---

### 9.8 Relatório com Barras Empilhadas (Stacked)

**O que é:** Barras onde cada categoria mostra a composição interna empilhada.

**Quando usar:** Mostrar a composição de cada período/categoria (ex: por mês, ver quantas admissões de cada status).

**Exemplo SQL:**
```sql
SELECT
  TO_CHAR(a.date, 'YYYY-MM') AS "Período",
  a.status AS "Status",
  COUNT(*) AS "Quantidade"
FROM admissions a
WHERE a.date IS NOT NULL
GROUP BY TO_CHAR(a.date, 'YYYY-MM'), a.status
ORDER BY "Período"
```

**Configuração:**
- Tipo: Barra > Empilhada (Stacked)
- Eixo X: "Período"
- Eixo Y: "Quantidade" (operação: Soma)
- As diferentes categorias de "Status" formarão as camadas empilhadas

---

### 9.9 Relatório Somente Gráficos

**O que é:** Relatório que exibe apenas gráficos, sem tabela de dados.

**Quando usar:** Dashboards visuais, apresentações, painéis gerenciais.

**Como configurar:**
1. No modal de salvamento ou na barra de ferramentas, defina o Conteúdo como **"Gráficos"**
2. Configure um ou mais gráficos na aba Gráficos
3. A tabela de dados será ocultada, mostrando apenas as visualizações

---

### 9.10 Relatório com Sub-relatório de Resumo

**O que é:** Relatório principal + resumo automático gerado a partir dos mesmos dados.

**Quando usar:** Quando quer um detalhamento seguido de um resumo consolidado.

**Passo a passo:**
1. Configure o relatório principal normalmente
2. Aba **Sub-relatórios** > Adicionar Sub-relatório
3. Selecione tipo **Resumo Automático**
4. Escolha o campo de agrupamento (ex: "Status")
5. Configure as operações (Soma, Contagem, etc.) para as colunas numéricas

**Exemplo:** Relatório principal lista todos os títulos financeiros detalhados. O sub-relatório de resumo agrupa por "Status" e mostra: ABERTO (5 títulos, R$ 10.000), PAGO (12 títulos, R$ 35.000), etc.

---

### 9.11 Relatório com Sub-relatório de Query

**O que é:** Relatório principal + uma ou mais consultas SQL independentes exibidas abaixo.

**Quando usar:** Quando quer mostrar perspectivas complementares que requerem consultas diferentes.

**Passo a passo:**
1. Configure o relatório principal
2. Aba **Sub-relatórios** > Adicionar Sub-relatório
3. Selecione tipo **Query Independente**
4. Escreva a consulta SQL do sub-relatório
5. Clique em "Testar Query" para validar
6. Configure as colunas (rótulos, formatos, alinhamento)
7. Adicione totalizadores se necessário

**Exemplo de SQL para sub-relatório:**
```sql
SELECT
  TO_CHAR(ft.due_date, 'YYYY-MM') AS "Período",
  COUNT(*) AS "Qtd Títulos",
  SUM(ft.value) AS "Valor Total",
  SUM(CASE WHEN ft.status = 'PAGO' THEN ft.value ELSE 0 END) AS "Recebido",
  SUM(CASE WHEN ft.status = 'ABERTO' THEN ft.value ELSE 0 END) AS "Em Aberto",
  ROUND(
    CASE WHEN SUM(ft.value) > 0
      THEN (SUM(CASE WHEN ft.status = 'PAGO' THEN ft.value ELSE 0 END) / SUM(ft.value)) * 100
      ELSE 0
    END, 2
  ) AS "% Recebido"
FROM financial_titles ft
WHERE ft.title_scope = 'RECEBER' AND ft.due_date IS NOT NULL
GROUP BY TO_CHAR(ft.due_date, 'YYYY-MM')
ORDER BY "Período" DESC
LIMIT 12
```

---

### 9.12 Relatório Misto Completo (Tabela + Gráficos + Sub-relatório)

**O que é:** O modelo mais completo, combinando todos os recursos disponíveis.

**Quando usar:** Relatórios executivos, visão 360 graus de um assunto.

**Passo a passo:**
1. Aba **Fonte de Dados**: consulta SQL com JOINs entre múltiplas tabelas
2. Aba **Layout**: agrupamento por cliente/período, subtotais, formatação completa
3. Aba **Gráficos**: adicione gráfico de barras + pizza
4. Aba **Sub-relatórios**: adicione sub-relatório de query com perspectiva complementar
5. Configure o Conteúdo como **"Ambos"** (dados + gráficos)
6. Aba **Preview**: execute e valide

**Exemplo SQL principal:**
```sql
SELECT
  c.name AS "Cliente",
  c.document AS "CPF/CNPJ",
  c.phone AS "Telefone",
  a.contract_number AS "Nº Contrato",
  a.status AS "Status Admissão",
  TO_CHAR(a.date, 'DD/MM/YYYY') AS "Data Admissão",
  ft.description AS "Título",
  ft.value AS "Valor",
  ft.status AS "Status Título",
  TO_CHAR(ft.due_date, 'DD/MM/YYYY') AS "Vencimento"
FROM clients c
INNER JOIN admissions a ON a.client_id = c.id
LEFT JOIN financial_titles ft ON ft.client_id = c.id AND ft.title_scope = 'RECEBER'
ORDER BY c.name, a.date DESC, ft.due_date
```

**Configurações combinadas:**
- Layout: Agrupamento por "Cliente", subtotais de "Valor"
- Gráfico 1: Barras - Valor por Vencimento (posição: depois)
- Gráfico 2: Pizza - Distribuição por Status Título (posição: depois, largura: 50%)
- Sub-relatório: Query de comportamento financeiro mensal
- Conteúdo: Ambos
- Rodapé: Soma total + contagem + texto personalizado

---

### 9.13 Relatório com CTE (WITH)

**O que é:** Usa Common Table Expressions para dividir consultas complexas em etapas legíveis.

**Quando usar:** Consultas que precisam de múltiplos passos de cálculo ou que ficam difíceis de ler com subqueries inline.

**Exemplo SQL:**
```sql
WITH clientes_ativos AS (
  SELECT c.id, c.name, c.document
  FROM clients c
  WHERE EXISTS (SELECT 1 FROM admissions a WHERE a.client_id = c.id)
),
resumo_financeiro AS (
  SELECT
    ft.client_id,
    COUNT(*) AS total_titulos,
    SUM(ft.value) AS valor_total,
    SUM(CASE WHEN ft.status = 'PAGO' THEN ft.value ELSE 0 END) AS valor_pago
  FROM financial_titles ft
  WHERE ft.title_scope = 'RECEBER'
  GROUP BY ft.client_id
)
SELECT
  ca.name AS "Cliente",
  ca.document AS "CPF/CNPJ",
  COALESCE(rf.total_titulos, 0) AS "Total Títulos",
  COALESCE(rf.valor_total, 0) AS "Valor Total",
  COALESCE(rf.valor_pago, 0) AS "Valor Pago",
  COALESCE(rf.valor_total - rf.valor_pago, 0) AS "Saldo Devedor"
FROM clientes_ativos ca
LEFT JOIN resumo_financeiro rf ON rf.client_id = ca.id
ORDER BY ca.name
```

**Dica:** CTEs são executadas no modo SQL. O modo visual não gera CTEs automaticamente.

---

### 9.14 Relatório Comparativo (Período x Período)

**O que é:** Compara valores entre períodos diferentes na mesma linha.

**Quando usar:** Análise semestral, trimestral ou mensal comparativa.

**Exemplo SQL:**
```sql
SELECT
  c.name AS "Cliente",
  COALESCE(SUM(CASE
    WHEN ft.due_date BETWEEN '2026-01-01' AND '2026-06-30'
    THEN ft.value ELSE 0
  END), 0) AS "1º Semestre",
  COALESCE(SUM(CASE
    WHEN ft.due_date BETWEEN '2026-07-01' AND '2026-12-31'
    THEN ft.value ELSE 0
  END), 0) AS "2º Semestre",
  COALESCE(SUM(ft.value), 0) AS "Total Anual"
FROM clients c
INNER JOIN financial_titles ft ON ft.client_id = c.id
WHERE ft.title_scope = 'RECEBER'
  AND ft.due_date BETWEEN '2026-01-01' AND '2026-12-31'
GROUP BY c.id, c.name
ORDER BY "Total Anual" DESC
```

**Configuração recomendada:**
- Formato: `currency_brl` para todas as colunas de valor
- Rodapé: Soma de cada coluna
- Gráfico misto: Barras para 1º/2º semestre + linha para Total

---

### 9.15 Relatório de Ranking (TOP N)

**O que é:** Lista os N maiores/menores registros por algum critério.

**Quando usar:** Top 10 clientes, piores inadimplentes, maiores receitas.

**Exemplo SQL:**
```sql
SELECT
  ROW_NUMBER() OVER (ORDER BY COALESCE(SUM(ft.value), 0) DESC) AS "Ranking",
  c.name AS "Cliente",
  COUNT(DISTINCT a.id) AS "Total Admissões",
  COALESCE(SUM(ft.value), 0) AS "Valor Total"
FROM clients c
LEFT JOIN admissions a ON a.client_id = c.id
LEFT JOIN financial_titles ft ON ft.client_id = c.id AND ft.title_scope = 'RECEBER'
GROUP BY c.id, c.name
ORDER BY "Valor Total" DESC
LIMIT 20
```

**Dica:** Use `ROW_NUMBER() OVER (ORDER BY ...)` para numerar automaticamente o ranking.

---

### 9.16 Relatório de Aging (Vencimentos por Faixa)

**O que é:** Classifica títulos em aberto por faixas de atraso.

**Quando usar:** Análise de inadimplência, gestão de cobrança.

**Exemplo SQL:**
```sql
SELECT
  c.name AS "Cliente",
  COUNT(CASE WHEN ft.due_date >= CURRENT_DATE THEN 1 END) AS "A Vencer",
  COUNT(CASE WHEN ft.due_date < CURRENT_DATE
    AND ft.due_date >= CURRENT_DATE - 30 THEN 1 END) AS "1-30 dias",
  COUNT(CASE WHEN ft.due_date < CURRENT_DATE - 30
    AND ft.due_date >= CURRENT_DATE - 60 THEN 1 END) AS "31-60 dias",
  COUNT(CASE WHEN ft.due_date < CURRENT_DATE - 60
    AND ft.due_date >= CURRENT_DATE - 90 THEN 1 END) AS "61-90 dias",
  COUNT(CASE WHEN ft.due_date < CURRENT_DATE - 90 THEN 1 END) AS "90+ dias",
  SUM(ft.value) AS "Total em Aberto"
FROM clients c
INNER JOIN financial_titles ft ON ft.client_id = c.id
WHERE ft.title_scope = 'RECEBER' AND ft.status = 'ABERTO'
GROUP BY c.id, c.name
HAVING COUNT(*) > 0
ORDER BY "Total em Aberto" DESC
```

**Configuração recomendada:**
- Formato numérico para colunas de contagem
- Formato `currency_brl` para Total em Aberto
- Gráfico de barras empilhadas por faixa

---

### 9.17 Relatório com Múltiplos Gráficos

**O que é:** Um relatório com dois ou mais gráficos diferentes usando os mesmos dados.

**Quando usar:** Múltiplas perspectivas visuais do mesmo conjunto de dados.

**Como configurar:**
1. Na aba **Gráficos**, clique em "Adicionar Gráfico" múltiplas vezes
2. Configure cada gráfico com tipo, eixos e visual diferentes
3. Use a reordenação (setas para cima/baixo) para definir a ordem de exibição
4. Use largura 50% para colocar gráficos lado a lado

**Exemplo de combinação:**
- Gráfico 1: Barras verticais - Volume por período (largura: 100%, posição: antes)
- Gráfico 2: Pizza - Distribuição por status (largura: 50%, posição: antes)
- Gráfico 3: Rosca - Distribuição por tipo (largura: 50%, posição: antes)

Os gráficos de largura 50% posicionados na mesma posição (antes/depois) ficam lado a lado automaticamente.

---

### 9.18 Relatório com Múltiplos Sub-relatórios

**O que é:** Relatório principal com dois ou mais sub-relatórios complementares.

**Quando usar:** Relatórios gerenciais que precisam de múltiplas visões de apoio.

**Como configurar:**
1. Na aba **Sub-relatórios**, adicione múltiplos sub-relatórios
2. Cada sub-relatório pode ser de tipo diferente (Resumo ou Query)
3. Use o botão de reordenação para definir a ordem de exibição

**Exemplo de combinação:**
- Sub-relatório 1 (Query): Resumo mensal de receitas
- Sub-relatório 2 (Query): Top 10 clientes por valor
- Sub-relatório 3 (Resumo): Totalização automática por status

Na exportação Excel, cada sub-relatório vira uma aba separada da planilha.

---

### 9.19 Relatório com Filtros Dinâmicos Parametrizados

**O que é:** Relatório cujos dados são filtrados por parâmetros informados pelo usuário na hora da execução.

**Quando usar:** Relatórios que precisam ser flexíveis (mesmo template, diferentes critérios).

**Como configurar os filtros:**

1. Na consulta SQL, use placeholders `{{nome}}`:

```sql
SELECT
  c.name AS "Cliente",
  ft.value AS "Valor",
  ft.status AS "Status",
  TO_CHAR(ft.due_date, 'DD/MM/YYYY') AS "Vencimento"
FROM clients c
INNER JOIN financial_titles ft ON ft.client_id = c.id
WHERE ft.title_scope = 'RECEBER'
  AND ft.due_date >= {{data_inicio}}
  AND ft.due_date <= {{data_fim}}
  AND ({{status}} = '' OR ft.status = {{status}})
ORDER BY ft.due_date
```

2. Na aba Preview, os campos aparecerão automaticamente para preenchimento
3. Configure os metadados dos filtros (tipo, rótulo, valor padrão)

**Tipos de filtro e seus usos:**

| Tipo | Quando usar | Exemplo no SQL |
|---|---|---|
| `text` | Busca parcial por nome | `name ILIKE '%' \|\| {{busca}} \|\| '%'` |
| `date` | Seleção de período | `due_date >= {{data_inicio}}` |
| `number` | Valor numérico | `value >= {{valor_minimo}}` |
| `select` | Lista fechada | `status = {{status}}` |

---

### 9.21 Relatório de Admissões com Responsável e Titular

**O que é:** Relatório que exibe dados tanto do Responsável quanto do Titular de uma admissão, usando JOIN duplo na mesma tabela `clients`.

**Quando usar:** Quando a admissão possui um responsável (client_id) e um titular do contrato (titular_client_id) e é necessário exibir os dados de ambos.

**Técnica:** A tabela `admissions` possui dois campos de FK para `clients`: `client_id` (Responsável) e `titular_client_id` (Titular). Para trazer dados de ambos na mesma consulta, faça dois LEFT JOINs com aliases diferentes:

```sql
SELECT
  a.contract_number AS "Contrato",
  TO_CHAR(a.date, 'DD/MM/YYYY') AS "Data Admissão",
  a.status AS "Status",
  a.financed_amount AS "Valor Financiado",
  -- Dados do Responsável
  resp.name AS "Responsável - Nome",
  resp.document AS "Responsável - CPF/CNPJ",
  resp.phone AS "Responsável - Telefone",
  resp.email AS "Responsável - Email",
  resp.city AS "Responsável - Cidade",
  resp.state AS "Responsável - UF",
  -- Dados do Titular
  tit.name AS "Titular - Nome",
  tit.document AS "Titular - CPF/CNPJ",
  tit.phone AS "Titular - Telefone",
  tit.email AS "Titular - Email",
  tit.city AS "Titular - Cidade",
  tit.state AS "Titular - UF"
FROM admissions a
LEFT JOIN clients resp ON resp.id = a.client_id
LEFT JOIN clients tit ON tit.id = a.titular_client_id
ORDER BY a.date DESC
```

**Configuração recomendada:**
- Modo SQL (o modo visual não suporta aliases de tabela)
- Formato `cpf_cnpj` para as colunas de CPF/CNPJ do responsável e titular
- Use LEFT JOIN (não INNER JOIN) para que admissões sem titular preenchido não sejam omitidas
- Use COALESCE para substituir NULLs quando o titular não for informado: `COALESCE(tit.name, 'Não informado')`

---

### 9.20 Relatório Mobile (Layout Mobile)

**O que é:** Relatório otimizado para visualização em smartphones.

**Quando usar:** Quando os usuários acessam pelo celular via PWA.

**Como configurar:**
1. Na barra de ferramentas ou no modal de salvamento, defina o Layout como **"Mobile"**
2. O relatório será renderizado em formato de cards empilhados (320-360px de largura)
3. Fontes maiores para leitura em tela pequena
4. Colunas empilhadas verticalmente em vez de lado a lado

**Dica:** Para relatórios mobile, limite o número de colunas (4-6 no máximo) para uma boa experiência.

---

## 10. Referência Completa de Tabelas

### Tabelas Principais e Seus Campos

#### clients (Clientes)
| Campo | Tipo | Descrição |
|---|---|---|
| id | UUID | Identificador único |
| name | VARCHAR(255) | Nome completo |
| type | VARCHAR(10) | FISICA ou JURIDICA |
| document | VARCHAR(20) | CPF ou CNPJ |
| rg | VARCHAR(20) | RG |
| phone / phone2 | VARCHAR(30) | Telefones |
| is_whatsapp | BOOLEAN | Se o telefone é WhatsApp |
| email | VARCHAR(255) | E-mail |
| profession | VARCHAR(100) | Profissão |
| marital_status | VARCHAR(50) | Estado civil |
| birth_date | DATE | Data de nascimento |
| cep | VARCHAR(12) | CEP |
| address / number / complement | VARCHAR | Endereço |
| district / city / state | VARCHAR | Bairro / Cidade / UF |
| notes | TEXT | Observações |
| created_at / updated_at | TIMESTAMPTZ | Datas de criação/atualização |

#### admissions (Admissões/Comercial)
| Campo | Tipo | Descrição |
|---|---|---|
| id | UUID | Identificador único |
| date | TIMESTAMPTZ | Data da admissão |
| client_id | UUID | FK para clients (Responsável) |
| titular_client_id | UUID | FK para clients (Titular do contrato) |
| client_name | VARCHAR(255) | Nome do cliente (cache) |
| bank_id | UUID | FK para banks |
| collaborator_id | UUID | FK para collaborators |
| series_id | UUID | FK para series |
| modality_id | UUID | FK para modalities |
| contract_number | VARCHAR(50) | Número do contrato |
| total_installments | VARCHAR(10) | Total de parcelas |
| paid_installments | VARCHAR(10) | Parcelas pagas |
| overdue_installments | VARCHAR(10) | Parcelas em atraso |
| financed_amount | VARCHAR(30) | Valor financiado |
| installment_value | VARCHAR(30) | Valor da parcela |
| status | VARCHAR(30) | PENDENTE, NEGOCIACAO, APROVADA, ANALISE CLIENTE, REPROVADA, AUDITADA, FINALIZADA, CONCLUIDO, RETORNO AUDITORIA |
| vehicle_* | VARCHAR | Dados do veículo (marca, modelo, cor, ano, placa, chassi, renavam) |

#### financial_titles (Títulos Financeiros)
| Campo | Tipo | Descrição |
|---|---|---|
| id | UUID | Identificador único |
| title_scope | VARCHAR(10) | RECEBER ou PAGAR |
| description | VARCHAR(255) | Descrição do título |
| value | NUMERIC(18,2) | Valor do título |
| original_value | NUMERIC(18,2) | Valor original |
| current_balance | NUMERIC(18,2) | Saldo atual |
| status | VARCHAR(30) | ABERTO, PAGO, PARCIAL, CANCELADO, AGRUPADO, etc. |
| client_id | UUID | FK para clients |
| client_name | VARCHAR(255) | Nome do cliente (cache) |
| issue_date | DATE | Data de emissão |
| due_date | DATE | Data de vencimento |
| document_number | VARCHAR(50) | Número do documento |
| source | VARCHAR(20) | MANUAL, AUDITORIA, RECORRENCIA, IMPORTACAO, BAIXA EM LOTE |
| type | VARCHAR(20) | PADRAO, ADIANTAMENTO, DEVOLUCAO, FATURA |
| installment_number | INTEGER | Número da parcela |
| total_installments | INTEGER | Total de parcelas |
| interest_value / discount_value / penalty_value | NUMERIC | Juros/desconto/multa |

#### title_settlements (Baixas/Liquidações)
| Campo | Tipo | Descrição |
|---|---|---|
| id | UUID | Identificador único |
| title_id | UUID | FK para financial_titles |
| date | DATE | Data da baixa |
| amount | NUMERIC(18,2) | Valor liquidado |
| interest / penalty / discount | NUMERIC | Juros/multa/desconto |
| source | VARCHAR(50) | Origem da baixa |
| history | TEXT | Histórico |

#### banks (Bancos)
| Campo | Tipo | Descrição |
|---|---|---|
| id | UUID | Identificador |
| name | VARCHAR(200) | Nome do banco |
| febraban_code | VARCHAR(10) | Código FEBRABAN |
| status | VARCHAR(10) | ATIVO ou INATIVO |

#### bank_accounts (Contas Bancárias)
| Campo | Tipo | Descrição |
|---|---|---|
| id | UUID | Identificador |
| description | VARCHAR(200) | Descrição |
| account_type | VARCHAR(20) | CORRENTE, POUPANCA, INVESTIMENTO, CAIXA |
| bank_name | VARCHAR(200) | Nome do banco |
| agency / account_number | VARCHAR | Agência e número |
| current_balance | NUMERIC(18,2) | Saldo atual |
| status | VARCHAR(10) | ATIVA ou INATIVA |

#### bank_movements (Movimentações Bancárias)
| Campo | Tipo | Descrição |
|---|---|---|
| id | UUID | Identificador |
| bank_account_id | UUID | FK para bank_accounts |
| type | VARCHAR(10) | CREDITO ou DEBITO |
| value | NUMERIC(18,2) | Valor |
| date | DATE | Data |
| history | TEXT | Histórico |

#### collaborators (Colaboradores)
| Campo | Tipo | Descrição |
|---|---|---|
| id | UUID | Identificador |
| name | VARCHAR(200) | Nome |
| job_title | VARCHAR(100) | Cargo |
| phone | VARCHAR(30) | Telefone |
| email | VARCHAR(255) | E-mail |

#### negotiations (Negociações)
| Campo | Tipo | Descrição |
|---|---|---|
| id | UUID | Identificador |
| client_id | UUID | FK para clients |
| status | VARCHAR | Status da negociação |

#### modalities (Modalidades)
| Campo | Tipo | Descrição |
|---|---|---|
| id | UUID | Identificador |
| type | VARCHAR(50) | Tipo |
| description | VARCHAR(255) | Descrição |

### Relacionamentos entre Tabelas (para JOINs)

```
clients.id          = admissions.client_id          (Responsável)
clients.id          = admissions.titular_client_id  (Titular)
clients.id          = financial_titles.client_id
clients.id          = negotiations.client_id
admissions.bank_id  = banks.id
admissions.collaborator_id = collaborators.id
admissions.modality_id = modalities.id
financial_titles.bearer_id = bearers.id
financial_titles.department_id = departments.id
financial_titles.category_id = chart_of_accounts.id
financial_titles.bank_account_id = bank_accounts.id
title_settlements.title_id = financial_titles.id
bank_movements.bank_account_id = bank_accounts.id
bank_accounts.bank_id = banks.id
```

---

## 11. Referência de Operadores SQL

### Operadores de Comparação (WHERE Builder)

| Operador | Significado | Exemplo |
|---|---|---|
| `=` | Igual | `status = 'ABERTO'` |
| `!=` | Diferente | `status != 'CANCELADO'` |
| `>` | Maior que | `value > 1000` |
| `<` | Menor que | `value < 5000` |
| `>=` | Maior ou igual | `due_date >= '2026-01-01'` |
| `<=` | Menor ou igual | `due_date <= '2026-12-31'` |
| `LIKE` | Contém texto (% = coringa) | `name LIKE '%Silva%'` |
| `ILIKE` | LIKE sem diferenciar maiúsculas | `name ILIKE '%silva%'` |
| `IN` | Está na lista | `status IN ('ABERTO', 'PARCIAL')` |
| `BETWEEN` | Entre dois valores | `due_date BETWEEN '2026-01-01' AND '2026-06-30'` |
| `IS NULL` | É nulo/vazio | `email IS NULL` |
| `IS NOT NULL` | Não é nulo | `phone IS NOT NULL` |

### Funções SQL Úteis

| Função | Uso | Exemplo |
|---|---|---|
| `TO_CHAR(data, formato)` | Formata data como texto | `TO_CHAR(created_at, 'DD/MM/YYYY')` |
| `COALESCE(valor, padrão)` | Substitui NULL por um valor padrão | `COALESCE(email, 'Não informado')` |
| `NULLIF(valor, comparação)` | Retorna NULL se valor = comparação | `NULLIF(phone, '')` |
| `CAST(valor AS tipo)` | Converte tipo | `CAST(financed_amount AS NUMERIC)` |
| `CASE WHEN ... THEN ... END` | Condicional | `CASE WHEN status = 'PAGO' THEN 'Sim' ELSE 'Não' END` |
| `CURRENT_DATE` | Data atual | `due_date < CURRENT_DATE` |
| `NOW()` | Data e hora atual | `created_at >= NOW() - INTERVAL '30 days'` |
| `INTERVAL` | Intervalo de tempo | `NOW() - INTERVAL '7 days'` |
| `ROW_NUMBER() OVER (...)` | Numeração sequencial | `ROW_NUMBER() OVER (ORDER BY value DESC)` |
| `EXTRACT(parte FROM data)` | Extrai parte da data | `EXTRACT(MONTH FROM due_date)` |

### Formatos de TO_CHAR para Datas

| Formato | Exemplo de Saída |
|---|---|
| `'DD/MM/YYYY'` | 07/03/2026 |
| `'DD/MM/YYYY HH24:MI'` | 07/03/2026 14:30 |
| `'YYYY-MM'` | 2026-03 |
| `'YYYY'` | 2026 |
| `'Month'` | March |
| `'Day'` | Saturday |
| `'TMMonth'` | Março (em português se locale configurado) |

---

## 12. Dicas, Boas Práticas e Solução de Problemas

### Boas Práticas

1. **Use aliases descritivos**: Sempre use `AS "Nome Legível"` com aspas duplas para nomes com acentos ou espaços
2. **Teste antes de salvar**: Use o Preview para verificar dados antes de salvar o template
3. **Evite SELECT ***: Selecione apenas as colunas necessárias
4. **Use COALESCE**: `COALESCE(campo, 0)` ou `COALESCE(campo, 'N/A')` evitam espaços em branco
5. **Paisagem para muitas colunas**: Relatórios com mais de 6 colunas ficam melhor em orientação paisagem
6. **Fonte menor para mais dados**: Use fonte 9 ou 10 para relatórios com muitas colunas
7. **Combine gráficos com tabelas**: Use conteúdo "Ambos" para dar contexto visual aos números
8. **Limite sub-relatórios**: Use LIMIT nos sub-relatórios para evitar consultas pesadas
9. **Use filtros para relatórios grandes**: Filtros por período evitam retornar milhares de registros
10. **Agrupe quando possível**: O agrupamento visual organiza os dados e facilita a leitura

### Solução de Problemas Comuns

| Problema | Causa | Solução |
|---|---|---|
| "Apenas consultas SELECT são permitidas" | SQL contém comando de escrita | Use apenas SELECT ou WITH. Remova INSERT/UPDATE/DELETE |
| Valores NULL na tabela | Campo sem dados | Use COALESCE: `COALESCE(campo, 0)` ou `COALESCE(campo, '-')` |
| Dados duplicados no JOIN | JOIN multiplica registros | Use COUNT(DISTINCT) ou revise as condições do JOIN |
| Gráfico não renderiza | Campos X ou Y não configurados | Verifique se selecionou campos para eixo X e adicionou pelo menos uma série Y |
| Preview mostra 0 registros | Filtro muito restritivo ou dados inexistentes | Remova ou ajuste condições WHERE |
| Coluna não aparece | Visibilidade desligada | Na aba Layout, verifique se a coluna está marcada como visível |
| Formato não aplicado | Formato errado selecionado | Verifique se a coluna contém o tipo de dado esperado (número para currency, data para date) |
| Erro de tipo no CAST | Tentando converter texto não-numérico | Use `NULLIF(campo, '')` antes do CAST: `CAST(NULLIF(campo, '') AS NUMERIC)` |
| Sub-relatório vazio | Query retorna 0 registros | Teste a query do sub-relatório isoladamente |
| Exportação PDF com colunas cortadas | Muitas colunas para o tamanho do papel | Use orientação paisagem ou reduza colunas visíveis |

### Segurança

- O sistema bloqueia automaticamente qualquer comando de escrita (INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, CREATE)
- Apenas SELECT e WITH (CTE) são permitidos
- Parâmetros de filtro são enviados como parâmetros posicionais ($1, $2, etc.), prevenindo SQL injection
- O controle de acesso por usuário/grupo garante que relatórios sensíveis sejam vistos apenas por pessoas autorizadas
- Administradores (ADMIN) têm acesso a todos os relatórios independente das restrições

# Matriz de validação responsiva

Use esta matriz depois de alterações visuais. A aplicação deve ser verificada com
zoom de 100%, nos modos claro e escuro, sem preferências de layout por usuário.

## Viewports aprovadas

| Perfil | Viewport | Navegação esperada |
| --- | --- | --- |
| Monitor 19" | 1920 × 1080 | Sidebar fixa; conteúdo usa a largura disponível |
| Notebook 13" | 1366 × 768 | Sidebar fixa/retrátil; cabeçalho sem colisões |
| Tablet paisagem | 1024 × 768 | Sidebar fixa/retrátil; conteúdo e modais roláveis |
| Tablet retrato | 768 × 1024 | Menu em overlay; conteúdo em uma coluna quando necessário |
| Smartphone 5" | 360 × 800 | Menu em overlay; ações empilhadas e alvos de toque confortáveis |

## Famílias de tela

Em cada viewport, validar:

- **Login:** login, recuperação, MFA, seleção de unidade e mensagens de bloqueio.
- **Shell:** menu, submenus, seletor de unidade, preferências visuais, ajuda,
  treinamento, logout e troca entre módulos.
- **Cadastros e configurações:** abas, filtros, formulários longos, câmera,
  matrizes de permissão, tabelas, paginação e ações de salvar/cancelar.
- **Operação:** Comercial, Financeiro, Cobrança, Jurídico, Agenda, Relatórios e
  Auditoria, incluindo gráficos e tabelas densas.
- **Prospecção:** lista de contatos e Dashboard devem manter filtros compactos,
  painéis com `data-testid` estáveis, tabelas roláveis internamente e paginação
  acessível em 1366 × 768. A troca Contatos/Dashboard não deve criar rolagem
  horizontal na página.
- **Comunicação:** Mensagens, Conversas, WhatsApp, anexos, mídia, editores e
  retorno da conversa para a lista.
- **Overlays:** modais, drawers, menus, seletores, ajuda e treinamento.

## Critérios de aprovação

- Não há rolagem horizontal na página. Tabelas densas podem ter rolagem
  horizontal dentro de um contêiner visível.
- Em 1366 × 768, Prospecção e Conversas preservam cabeçalhos e filtros no
  viewport; a lista/tabela usa rolagem interna e os controles de paginação ficam
  disponíveis sem ampliar a página.
- Nenhum controle, título ou ação principal fica cortado ou encoberto.
- Modais respeitam a viewport, mantêm cabeçalho/ações acessíveis e rolam o
  conteúdo interno.
- Campos preservam rótulos e recebem foco sem serem cobertos pelo teclado
  virtual.
- Botões e itens de navegação usados por toque têm área mínima confortável.
- Texto de tabelas não é reduzido para compensar falta de espaço.
- Claro e escuro mantêm contraste, bordas, estados de foco e imagens legíveis.
- Com zoom de 200%, o fluxo continua operável por teclado e sem perda de
  conteúdo essencial.

## Sequência de regressão

1. Abra as ferramentas responsivas do navegador e selecione uma viewport.
2. Faça login e percorra todas as famílias acima.
3. Repita nos modos claro e escuro.
4. No tablet, repita após alternar retrato/paisagem.
5. No smartphone, abra um formulário e uma conversa com o teclado virtual.
6. Use `Tab`, `Shift+Tab`, `Enter` e `Escape` nos controles e overlays.
7. Registre qualquer falha com viewport, tema, módulo e ação executada.

Antes de entregar, execute também:

```bash
npm run test:visual
npm run build
git diff --check
```

## Regressão visual automatizada

A suíte Playwright em `tests/visual` cobre login, shell autenticado, formulário,
tabela, modal e conversa, sem credenciais reais. As respostas de autenticação e
dados são interceptadas com fixtures determinísticas.

- `npm run test:visual`: compara as capturas com as referências versionadas.
- `npm run test:visual:update`: atualiza as referências após uma mudança visual
  intencional e revisada.
- Em falhas, consulte `playwright-report/` e `test-results/visual/` para a
  captura atual, diferença, referência, trace e vídeo retidos.

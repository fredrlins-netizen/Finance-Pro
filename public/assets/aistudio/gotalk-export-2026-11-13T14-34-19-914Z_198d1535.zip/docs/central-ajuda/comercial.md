# Módulo Comercial

> Segue o [`PADRAO-DE-SAIDA.md`](./PADRAO-DE-SAIDA.md). Termos do negócio em [`glossario.md`](./glossario.md).

## Conceito do módulo

O **Comercial** cuida da entrada e do fechamento de contratos. Reúne três fluxos:

- **Admissão / Ficha de contrato:** o cadastro do contrato do cliente — o fluxo mais crítico
  do sistema, pois alimenta financeiro, jurídico e cobrança.
- **Negociação comercial (Kanban):** acompanhamento das oportunidades por etapa, do primeiro
  contato ao fechamento.
- **Prospecção:** captação e atendimento de leads, integrada ao WhatsApp.

A admissão conecta cliente + modalidade + banco/serviço + valores, gerando as parcelas e os
documentos do contrato.

## Mapa de prints

| Tela | Slug | Caminho |
|---|---|---|
| Painel de Admissões | `admissao` | `public/help-screenshots/admissao.jpg` |
| Negociação Comercial (Kanban) | `negociacao-kanban` | `public/help-screenshots/negociacao-kanban.jpg` |

> **Prospecção:** ainda sem print dedicado em `public/help-screenshots/`. Capturar
> `prospeccao.jpg` (lista de leads + janela de conversa) quando for documentar a tela em detalhe.

---

## Parte A — Artigos da Base de Conhecimento IA

### Artigo 1

- **title:** Admissão: como criar e preencher a ficha de contrato do cliente
- **category:** Admissão
- **termos de busca:** admissão, ficha de contrato, novo contrato, admitir cliente, modalidade, banco
- **active:** true

#### content (HTML)

```html
<h3>O que é a Admissão</h3>
<p>A admissão é o registro do contrato do cliente na assessoria. É o ponto de partida do
atendimento: a partir dela nascem as parcelas financeiras, os processos jurídicos e as ações
de cobrança.</p>
<h3>Como criar uma admissão</h3>
<ol>
  <li>Abra <strong>Atendimento &gt; Comercial &gt; Admissão</strong> e clique em <strong>Nova Admissão</strong>.</li>
  <li>Selecione o <strong>cliente</strong> (ou cadastre na hora). Verifique se o titular está correto.</li>
  <li>Escolha a <strong>modalidade</strong> (Veículos, Cartões, Consignado, Empréstimos, Outros) e o <strong>banco/serviço</strong>.</li>
  <li>Informe os <strong>valores</strong>: valor do contrato, honorários, número de parcelas, vencimento e forma de pagamento.</li>
  <li>Revise a <strong>ficha</strong> e salve. As parcelas e documentos são gerados conforme a configuração.</li>
</ol>
<h3>Campos principais da ficha</h3>
<ul>
  <li><strong>Cliente / Titular:</strong> quem assina o contrato.</li>
  <li><strong>Modalidade:</strong> o tipo de serviço/dívida tratada.</li>
  <li><strong>Banco / Serviço:</strong> instituição e percentual de negociação.</li>
  <li><strong>Valores:</strong> contrato, honorários, parcelas, entrada e vencimento.</li>
  <li><strong>Status:</strong> situação do contrato (em andamento, concluído, cancelado).</li>
</ul>
<h3>Dica</h3>
<p>Cancelar uma admissão afeta os títulos financeiros vinculados (cancelamento em cascata).
Confira o impacto antes de confirmar.</p>
```

### Artigo 2

- **title:** Negociação Comercial: acompanhar oportunidades no Kanban
- **category:** Comercial
- **termos de busca:** negociação comercial, kanban, funil, oportunidade, etapa, fechamento
- **active:** true

#### content (HTML)

```html
<h3>Para que serve</h3>
<p>O painel de Negociação Comercial mostra as oportunidades em um quadro <strong>Kanban</strong>,
organizado por etapas do funil de vendas.</p>
<h3>Como usar</h3>
<ol>
  <li>Abra <strong>Atendimento &gt; Comercial &gt; Negociação</strong>.</li>
  <li>Cada cartão é uma oportunidade. <strong>Arraste</strong> o cartão entre as colunas para mudar a etapa.</li>
  <li>Clique no cartão para ver detalhes, registrar contatos e atualizar valores.</li>
</ol>
<h3>O que observar</h3>
<ul>
  <li><strong>Colunas/etapas:</strong> do primeiro contato à conclusão.</li>
  <li><strong>Valor da oportunidade:</strong> potencial de receita.</li>
  <li><strong>Responsável:</strong> colaborador que conduz a negociação.</li>
</ul>
```

### Artigo 3

- **title:** Prospecção: captar leads e atender pelo WhatsApp
- **category:** Comercial
- **termos de busca:** prospecção, lead, captação, WhatsApp, atendimento, conversa
- **active:** true

#### content (HTML)

```html
<h3>O que é a Prospecção</h3>
<p>A prospecção concentra os leads (possíveis clientes) e o atendimento inicial, integrado ao
WhatsApp. Permite conversar, qualificar o lead e transformá-lo em cliente/admissão.</p>
<h3>Fluxo básico</h3>
<ol>
  <li>Receba/registre o lead e abra a conversa.</li>
  <li>Atenda pelo WhatsApp dentro da própria tela, registrando o andamento.</li>
  <li>Qualificado o lead, cadastre o cliente e/ou crie a admissão e o agendamento.</li>
</ol>
<h3>Boas práticas</h3>
<p>Mantenha o canal/unidade corretos e registre o resultado de cada contato para alimentar os
indicadores de prospecção.</p>
```

---

## Parte B — Tópicos da Central de Ajuda

| id | Tela |
|---|---|
| `com_admissao` | Painel de Admissões |
| `com_negociacao` | Painel de Negociação Comercial (Kanban) |

> **Lacuna:** não há tópico dedicado de **Prospecção** em `HelpContentData.ts`. Criar
> `com_prospeccao` (menuPath `Atendimento > Comercial > Prospecção`) ao capturar o print.

> **Privacidade (LGPD):** usar somente dados de exemplo; mascarar dados reais nos prints.

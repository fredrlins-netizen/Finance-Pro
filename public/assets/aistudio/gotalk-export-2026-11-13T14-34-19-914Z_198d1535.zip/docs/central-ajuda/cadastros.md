# Módulo Cadastros

> Segue o [`PADRAO-DE-SAIDA.md`](./PADRAO-DE-SAIDA.md). Termos do negócio em [`glossario.md`](./glossario.md).

## Conceito do módulo

Os **Cadastros** são a base de dados de todo o CRM. É aqui que se registram as pessoas e os
itens que todos os outros módulos reutilizam: **clientes, colaboradores, cargos,
departamentos, bancos, modalidades, produtos** e **séries** de numeração. Sem esses
registros, não é possível criar admissões, lançar contas, agendar atendimentos ou cobrar.

Regra geral das telas de cadastro: uma **lista** com busca/filtros, um botão **Novo**, e um
**modal** para incluir/editar. Quase tudo respeita a **unidade ativa** e o status
**ATIVO/INATIVO** (inativos somem das listas de seleção, mas ficam no histórico).

## Mapa de prints

Prints canônicos reutilizados de `public/help-screenshots/` (referenciados como `/help-screenshots/<slug>.jpg`):

| Tela | Slug | Caminho |
|---|---|---|
| Clientes | `cad-clientes` | `public/help-screenshots/cad-clientes.jpg` |
| Colaboradores | `cad-colaboradores` | `public/help-screenshots/cad-colaboradores.jpg` |
| Cargos | `cad-cargos` | `public/help-screenshots/cad-cargos.jpg` |
| Departamentos | `cad-departamentos` | `public/help-screenshots/cad-departamentos.jpg` |
| Bancos | `cad-bancos` | `public/help-screenshots/cad-bancos.jpg` |
| Modalidades | `cad-modalidades` | `public/help-screenshots/cad-modalidades.jpg` |
| Produtos | `cad-produtos` | `public/help-screenshots/cad-produtos.jpg` |
| Séries/Números | `cad-series` | `public/help-screenshots/cad-series.jpg` |

---

## Parte A — Artigos da Base de Conhecimento IA

### Artigo 1

- **title:** Cadastro de Clientes: incluir, editar e buscar pessoa física e jurídica
- **category:** Geral
- **termos de busca:** cliente, cadastrar cliente, CPF, CNPJ, pessoa física, jurídica, editar cliente
- **active:** true

#### content (HTML)

```html
<h3>O que é o Cadastro de Clientes</h3>
<p>É onde você registra todas as pessoas e empresas atendidas pela assessoria. O cliente
cadastrado fica disponível para admissões, agendamentos, cobranças e processos.</p>
<h3>Como cadastrar um novo cliente</h3>
<ol>
  <li>Abra <strong>Cadastros &gt; Clientes</strong> e clique em <strong>Novo</strong>.</li>
  <li>Escolha o tipo: <strong>Pessoa Física</strong> (CPF) ou <strong>Pessoa Jurídica</strong> (CNPJ).</li>
  <li>Preencha nome/razão social, documento, telefone, e-mail e endereço. O CEP pode preencher o endereço automaticamente.</li>
  <li>Marque <strong>WhatsApp</strong> se o telefone for desse aplicativo.</li>
  <li>Salve. O cliente passa a aparecer nas buscas dos outros módulos.</li>
</ol>
<h3>Como buscar e editar</h3>
<p>Use o campo de busca por nome ou documento. Clique no cliente para abrir e editar.
Clientes marcados como inativos não aparecem nas listas de seleção, mas seguem no histórico.</p>
<h3>Campos principais</h3>
<ul>
  <li><strong>Tipo:</strong> Física (CPF) ou Jurídica (CNPJ).</li>
  <li><strong>Documento:</strong> CPF ou CNPJ, conforme o tipo.</li>
  <li><strong>Telefone / WhatsApp:</strong> contato; marque se for WhatsApp.</li>
  <li><strong>Endereço:</strong> CEP, logradouro, número, complemento, bairro, cidade, UF.</li>
  <li><strong>Observações:</strong> anotações livres sobre o cliente.</li>
</ul>
```

### Artigo 2

- **title:** Cadastros de apoio: Colaboradores, Cargos e Departamentos
- **category:** Geral
- **termos de busca:** colaborador, funcionário, cargo, departamento, equipe
- **active:** true

#### content (HTML)

```html
<h3>Para que servem</h3>
<p>Esses cadastros definem a estrutura interna da empresa, usada em agenda, comercial e
cobrança.</p>
<ul>
  <li><strong>Colaboradores:</strong> funcionários da assessoria (atendentes, gerentes). Têm cargo, contato e endereço. São usados em admissões, agenda e cobrança.</li>
  <li><strong>Cargos:</strong> a função do colaborador (ex.: Gerente Comercial). Pode definir se o cargo participa do rodízio da agenda.</li>
  <li><strong>Departamentos:</strong> os setores da empresa (ex.: Administrativo, Comercial, Jurídico), com responsável.</li>
</ul>
<h3>Como cadastrar</h3>
<p>Em cada tela, clique em <strong>Novo</strong>, preencha os campos e salve. Use o status
ATIVO/INATIVO para controlar quem aparece nas seleções.</p>
```

### Artigo 3

- **title:** Cadastro de Bancos, Modalidades, Produtos e Séries
- **category:** Geral
- **termos de busca:** banco, FEBRABAN, modalidade, produto, série, numeração, contrato
- **active:** true

#### content (HTML)

```html
<h3>Bancos</h3>
<p>Cadastre as instituições financeiras com nome, código FEBRABAN e os serviços oferecidos
(cada serviço pode ter um percentual de negociação). Usados nas admissões e recálculos.</p>
<h3>Modalidades</h3>
<p>São os tipos de dívida/serviço trabalhados: Veículos, Cartões, Consignado, Empréstimos e
Outros. A modalidade classifica a admissão.</p>
<h3>Produtos</h3>
<p>Itens e serviços oferecidos, usados em contratos e cobranças.</p>
<h3>Séries / Números</h3>
<p>Definem a numeração sequencial de documentos (ex.: contratos, procurações). Cada série
tem uma <strong>sigla</strong> e um <strong>número geral</strong>; também é possível controlar
a numeração por unidade.</p>
```

---

## Parte B — Tópicos da Central de Ajuda

Já existem em `components/help/HelpContentData.ts` (reutilizar; complementar se faltar campo):

| id | Tela |
|---|---|
| `cad_clientes` | Cadastro de Clientes |
| `cad_colaboradores` | Cadastro de Colaboradores |
| `cad_cargos` | Cadastro de Cargos |
| `cad_departamentos` | Cadastro de Departamentos |
| `cad_bancos` | Cadastro de Bancos |
| `cad_modalidades` | Cadastro de Modalidades |
| `cad_produtos` | Cadastro de Produtos e Serviços |
| `cad_series` | Cadastro de Séries e Numeração |

> **Privacidade (LGPD):** prints usam apenas dados de exemplo do sistema ("CARLOS ALBERTO DE
> NOBREGA", "TRANSPORTES RAPIDÃO LTDA"). Mascarar qualquer dado real antes de publicar.

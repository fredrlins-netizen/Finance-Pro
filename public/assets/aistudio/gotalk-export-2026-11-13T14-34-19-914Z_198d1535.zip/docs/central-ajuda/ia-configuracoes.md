# Módulos IA (Assistente Léo) e Configurações

> Segue o [`PADRAO-DE-SAIDA.md`](./PADRAO-DE-SAIDA.md). Termos do negócio em [`glossario.md`](./glossario.md).

## Conceito dos módulos

- **IA — Assistente Léo (Gemini):** ajuda dentro do sistema. Responde dúvidas usando a
  **Base de Conhecimento IA**, ajuda em análises de dados, resumo de relatórios e auditoria.
- **Configurações:** o painel de administração do sistema, com as abas **Portal** (aparência),
  **Unidades**, **Usuários e Grupos de Acesso**, **E-mails**, **Integrações de API**,
  **Auditoria**, **Escala de Trabalho**, **Mensagens GoTalk**, **Importação**, **Central de
  Ajuda** e **Base de Conhecimento IA**.

> **Meta:** este módulo inclui o artigo que explica como manter a própria Central de Ajuda e a
> Base de Conhecimento IA — ou seja, como alimentar o Léo.

## Como o Léo encontra a resposta (resumo do RAG)

Detalhe completo em [`PADRAO-DE-SAIDA.md`](./PADRAO-DE-SAIDA.md). Em resumo: a pergunta é
quebrada em palavras (3+ letras); cada artigo é pontuado, com **forte peso no título**
(efeito ~4×) e peso menor em categoria/conteúdo; os **5 melhores** artigos vão ao Léo, com o
HTML removido e o conteúdo truncado em ~3.000 caracteres. Por isso, **bons títulos** e o
**essencial no começo** do artigo são decisivos.

## Mapa de prints

| Tela | Slug | Caminho |
|---|---|---|
| Configurações — Portal | `settings-portal` | `public/help-screenshots/settings-portal.jpg` |
| Configurações — Unidades | `settings-unidades` | `public/help-screenshots/settings-unidades.jpg` |
| Configurações — Usuários | `settings-usuarios` | `public/help-screenshots/settings-usuarios.jpg` |
| Configurações — E-mails | `settings-emails` | `public/help-screenshots/settings-emails.jpg` |
| Configurações — API | `settings-api` | `public/help-screenshots/settings-api.jpg` |
| Configurações — Auditoria | `settings-audit` | `public/help-screenshots/settings-audit.jpg` |
| Configurações — Escala de Trabalho | `settings-escala` | `public/help-screenshots/settings-escala.jpg` |
| Configurações — Central de Ajuda | `settings-help` | `public/help-screenshots/settings-help.jpg` |
| Configurações — Mensagens GoTalk | `settings-gotalk` | `public/help-screenshots/settings-gotalk.jpg` |

> **Lacunas:** sem print do **chat do Léo**, da aba **Base de Conhecimento IA** e da aba
> **Importação**. Capturar `ia-leo.jpg`, `settings-base-conhecimento.jpg` e `settings-importacao.jpg`.

---

## Parte A — Artigos da Base de Conhecimento IA

### Artigo 1

- **title:** Assistente Léo (IA): como tirar dúvidas dentro do sistema
- **category:** Configurações
- **termos de busca:** Léo, assistente, IA, inteligência artificial, ajuda, dúvida, Gemini, chat
- **active:** true

#### content (HTML)

```html
<h3>O que é o Léo</h3>
<p>O Léo é o assistente de inteligência artificial do sistema. Ele responde dúvidas sobre como
usar o CRM, baseando-se na Base de Conhecimento cadastrada.</p>
<h3>Como usar</h3>
<ol>
  <li>Abra o assistente <strong>Léo</strong>.</li>
  <li>Escreva sua dúvida em linguagem normal (ex.: "como dou baixa em uma conta a receber?").</li>
  <li>O Léo busca os artigos mais relevantes e responde com base neles.</li>
</ol>
<h3>Quando o Léo não sabe</h3>
<p>Se não houver artigo sobre o tema, o Léo pode não responder com precisão. Nesse caso, vale
cadastrar um artigo novo na Base de Conhecimento (ver artigo específico).</p>
```

### Artigo 2

- **title:** Configurações: Unidades, Usuários e Grupos de Acesso
- **category:** Configurações
- **termos de busca:** configurações, unidade, usuário, grupo de acesso, permissão, perfil, senha
- **active:** true

#### content (HTML)

```html
<h3>Unidades</h3>
<p>Cadastre as unidades/filiais da empresa. A unidade ativa filtra dados em quase todo o
sistema (agenda, financeiro, cobrança).</p>
<h3>Usuários e Grupos de Acesso</h3>
<ol>
  <li>Abra <strong>Configurações &gt; Usuários</strong>.</li>
  <li>Crie o usuário com nome, e-mail e <strong>grupo de acesso</strong> (perfil de permissões).</li>
  <li>O grupo define o que cada pessoa pode ver e fazer (menus e ações).</li>
</ol>
<h3>Outras abas úteis</h3>
<ul>
  <li><strong>Portal:</strong> aparência (logo, cores).</li>
  <li><strong>E-mails / API:</strong> integrações de envio e serviços externos.</li>
  <li><strong>Escala de Trabalho:</strong> turnos e disponibilidade da equipe.</li>
  <li><strong>Auditoria:</strong> registro de quem fez o quê no sistema.</li>
</ul>
```

### Artigo 3

- **title:** Importação de dados: trazer cadastros por planilha
- **category:** Configurações
- **termos de busca:** importação, importar, planilha, Excel, CSV, migração, dados, clientes
- **active:** true

#### content (HTML)

```html
<h3>Para que serve</h3>
<p>A Importação traz dados em massa (ex.: clientes) a partir de uma planilha, evitando o
cadastro manual um a um.</p>
<h3>Como importar</h3>
<ol>
  <li>Abra a aba <strong>Importação</strong> em Configurações.</li>
  <li>Envie a <strong>planilha</strong> e selecione quais colunas correspondem a quais campos.</li>
  <li>Revise a prévia, corrija erros apontados e confirme a importação.</li>
</ol>
<h3>Dica de segurança</h3>
<p>Importações grandes podem exigir confirmação extra (passo de verificação). Confira sempre a
prévia antes de confirmar — em caso de erro, a importação pode ser abortada por inteiro.</p>
```

### Artigo 4 (meta)

- **title:** Como manter a Central de Ajuda e a Base de Conhecimento do Léo
- **category:** Configurações
- **termos de busca:** base de conhecimento, artigo, central de ajuda, cadastrar artigo, treinar Léo, IA, tópico
- **active:** true

#### content (HTML)

```html
<h3>Duas ferramentas, dois objetivos</h3>
<ul>
  <li><strong>Central de Ajuda:</strong> os textos e prints que o usuário lê na tela de ajuda.</li>
  <li><strong>Base de Conhecimento IA:</strong> os artigos que o assistente <strong>Léo</strong> usa para responder.</li>
</ul>
<h3>Como cadastrar um artigo da Base de Conhecimento</h3>
<ol>
  <li>Abra <strong>Configurações &gt; Base de Conhecimento IA</strong> e clique em <strong>Novo</strong>.</li>
  <li>Escreva um <strong>título</strong> claro e cheio dos termos que o usuário usaria na pergunta — o título tem o maior peso na busca do Léo.</li>
  <li>Escolha a <strong>categoria</strong> correta.</li>
  <li>No <strong>conteúdo</strong>, coloque o essencial logo no começo (o texto é truncado). Pode anexar até 3 imagens.</li>
  <li>Deixe o artigo <strong>ativo</strong> e salve.</li>
</ol>
<h3>Boas práticas</h3>
<ul>
  <li>Um título objetivo por tarefa (ex.: "Contas a Receber: dar baixa e emitir fatura").</li>
  <li>Texto que faça sentido sem formatação (o HTML é removido antes de ir ao Léo).</li>
  <li>Use os termos reais do usuário, não só o nome técnico da tela.</li>
</ul>
```

---

## Parte B — Tópicos da Central de Ajuda

| id | Tela |
|---|---|
| `settings_portal` | Configurações do Portal (Aparência) |
| `settings_units` | Gestão de Unidades |
| `settings_users` | Gestão de Usuários e Grupos de Acesso |
| `settings_emails` | Configurações de E-mail |
| `settings_api` | Integrações de API |
| `settings_audit` | Log de Auditoria (Configurações) |
| `settings_escala` | Escala de Trabalho |
| `settings_help` | Central de Ajuda (Administração) |
| `settings_gotalk` | Mensagens GoTalk (Configurações) |

> **Lacunas:** criar tópicos para o **chat do Léo** (`ia_leo`), a aba **Base de Conhecimento IA**
> (`settings_base_conhecimento`) e a aba **Importação** (`settings_importacao`).

> **Privacidade (LGPD):** mascarar dados reais (usuários, e-mails, chaves de API) nos prints.

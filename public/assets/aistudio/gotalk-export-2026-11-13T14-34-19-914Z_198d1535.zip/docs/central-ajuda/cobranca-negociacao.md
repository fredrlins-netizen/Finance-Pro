# Módulos Cobrança e Negociação

> Segue o [`PADRAO-DE-SAIDA.md`](./PADRAO-DE-SAIDA.md). Termos do negócio em [`glossario.md`](./glossario.md).

## Conceito dos módulos

A **Cobrança** organiza o trabalho de recuperar valores em atraso, com dois pontos de vista:

- **Visão do Coordenador:** acompanha metas, distribui carteiras e mede a performance da equipe.
- **Visão Operacional:** a tela do operador, com os títulos/clientes para contatar e registrar
  o resultado de cada cobrança.

A **Negociação (Financeira)** trata das propostas de acordo com o cliente para quitar dívidas
(parcelamento, desconto), do registro da proposta até o fechamento.

> Não confundir com a **Negociação Comercial** (Kanban de vendas), documentada no módulo Comercial.

## Mapa de prints

| Tela | Slug | Caminho |
|---|---|---|
| Cobrança — Visão do Coordenador | `fin-cob-coordenador` | `public/help-screenshots/fin-cob-coordenador.jpg` |
| Cobrança — Visão Operacional | `fin-cob-operacional` | `public/help-screenshots/fin-cob-operacional.jpg` |
| Negociação Financeira | `fin-negociacao` | `public/help-screenshots/fin-negociacao.jpg` |

---

## Parte A — Artigos da Base de Conhecimento IA

### Artigo 1

- **title:** Cobrança Operacional: trabalhar a carteira e registrar contatos
- **category:** Cobrança
- **termos de busca:** cobrança, operacional, carteira, contato, atraso, inadimplência, registrar cobrança
- **active:** true

#### content (HTML)

```html
<h3>O que é a Visão Operacional</h3>
<p>É a tela de quem faz a cobrança no dia a dia. Mostra os clientes/títulos da sua carteira que
precisam de contato, priorizados por atraso.</p>
<h3>Como trabalhar a carteira</h3>
<ol>
  <li>Abra <strong>Financeiro &gt; Cobrança &gt; Operacionais</strong>.</li>
  <li>Selecione o cliente/título e faça o contato (telefone, WhatsApp).</li>
  <li>Registre o <strong>resultado</strong> (promessa de pagamento, acordo, sem contato) e a próxima ação.</li>
  <li>Se houver acordo, encaminhe para <strong>Negociação</strong>.</li>
</ol>
<h3>O que observar</h3>
<ul>
  <li><strong>Dias em atraso:</strong> prioridade do contato.</li>
  <li><strong>Histórico:</strong> contatos e promessas anteriores.</li>
  <li><strong>Status do título:</strong> em aberto, em acordo, pago.</li>
</ul>
```

### Artigo 2

- **title:** Cobrança do Coordenador: metas, carteiras e performance da equipe
- **category:** Cobrança
- **termos de busca:** coordenador, meta, equipe, performance, distribuir carteira, indicadores cobrança
- **active:** true

#### content (HTML)

```html
<h3>Para que serve</h3>
<p>A Visão do Coordenador dá o panorama da operação de cobrança: resultados por operador,
metas e distribuição de carteiras.</p>
<h3>Como usar</h3>
<ol>
  <li>Abra <strong>Financeiro &gt; Cobrança &gt; Coordenadores</strong>.</li>
  <li>Acompanhe os <strong>indicadores</strong> (recuperado, em aberto, metas atingidas).</li>
  <li>Distribua ou rebalanceie as <strong>carteiras</strong> entre os operadores.</li>
  <li>Defina e acompanhe <strong>metas</strong> por período.</li>
</ol>
```

### Artigo 3

- **title:** Negociação Financeira: registrar propostas e fechar acordos
- **category:** Negociação
- **termos de busca:** negociação, acordo, proposta, parcelamento, desconto, quitação, dívida
- **active:** true

#### content (HTML)

```html
<h3>O que é</h3>
<p>A Negociação registra as propostas de acordo com o cliente para quitar valores em atraso —
parcelamento e descontos — até o fechamento.</p>
<h3>Como negociar</h3>
<ol>
  <li>Abra <strong>Financeiro &gt; Negociação</strong> e selecione o cliente/dívida.</li>
  <li>Monte a <strong>proposta</strong>: valor total, entrada, número de parcelas e desconto.</li>
  <li>Registre a resposta do cliente; ao aceitar, <strong>feche o acordo</strong>.</li>
  <li>O acordo gera os títulos financeiros conforme o parcelamento combinado.</li>
</ol>
<h3>Dica</h3>
<p>Acordos cancelados/quebrados devem ser registrados para manter o histórico e reabrir a
cobrança quando necessário.</p>
```

---

## Parte B — Tópicos da Central de Ajuda

| id | Tela |
|---|---|
| `fin_cob_coordenador` | Cobrança - Visão do Coordenador |
| `fin_cob_operacional` | Cobrança - Visão Operacional |
| `fin_negociacao` | Negociação Financeira |

> **Privacidade (LGPD):** mascarar nomes, valores e telefones reais nos prints; usar exemplos.

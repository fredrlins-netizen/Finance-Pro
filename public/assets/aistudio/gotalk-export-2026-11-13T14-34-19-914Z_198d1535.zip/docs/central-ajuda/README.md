# Documentação Operacional — Central de Ajuda & Base de Conhecimento IA

Esta pasta reúne o material operacional do **FinancePro Assessoria** que alimenta duas áreas do sistema:

| Destino | Onde aparece | Formato técnico | Quem edita |
|---|---|---|---|
| **Central de Ajuda** | Configurações → aba "Central de Ajuda" | `HelpTopic` (ver `components/help/HelpContentData.ts`) | Admin |
| **Base de Conhecimento IA** (assistente Léo) | Configurações → aba "Base de Conhecimento IA" | Artigo `leo_knowledge_articles` (HTML) | Admin |

> **Importante:** o material aqui é **revisável em Markdown**. Nada é inserido no banco automaticamente. Depois de revisado, o conteúdo é colado manualmente nas abas correspondentes do sistema.

## Estrutura da pasta

```
docs/central-ajuda/
├── README.md             ← este índice
├── 00-visao-geral.md     ← conceito do sistema + mapa de módulos
├── glossario.md          ← termos do negócio (vira artigo "Geral" do Léo)
├── _PROMPT-MODELO.md      ← prompt reutilizável para documentar cada módulo
├── PADRAO-DE-SAIDA.md     ← schema exato dos artigos e tópicos + regras técnicas
├── prints/               ← prints de apoio gerados durante a documentação
└── <modulo>.md           ← um arquivo por módulo (tarefas #335–#343)
```

## Estado atual (ponto de partida)

A **Central de Ajuda já está em uso e bastante completa**: existem **44 tópicos** em
`components/help/HelpContentData.ts`, cada um com um print correspondente em
`public/help-screenshots/<slug>.jpg`.

Consequências para as tarefas de módulo:

- **Reaproveite os prints existentes** em `public/help-screenshots/` sempre que possível,
  em vez de tirar novos. Tire prints novos só quando a tela mudou ou não há cobertura.
- Ao documentar um módulo, **compare** o tópico já existente em `HelpContentData.ts` com
  o que falta. O foco principal das tarefas é alimentar a **Base de Conhecimento IA**, que
  hoje tem cobertura menor que a Central de Ajuda.
- Prints **novos** ficam em `docs/central-ajuda/prints/` para revisão; quando aprovados e
  destinados à Central de Ajuda, são copiados para `public/help-screenshots/` com o slug
  correto.

## Como usar este material

1. Cada tarefa de módulo (#335–#343) produz um arquivo `<modulo>.md` nesta pasta,
   seguindo o `PADRAO-DE-SAIDA.md`.
2. Cada arquivo de módulo contém **duas seções de entrega**:
   - **Parte A — Artigo da Base de Conhecimento IA** (título, categoria, termos de busca, conteúdo).
   - **Parte B — Tópico(s) da Central de Ajuda** (id, menuPath, título, resumo, conteúdo, keywords).
3. O revisor cola a Parte A na aba "Base de Conhecimento IA" e a Parte B em `HelpContentData.ts`
   (ou na aba de Central de Ajuda, conforme o fluxo do projeto).

## Fila de documentação

| Tarefa | Módulo | Arquivo | Status |
|---|---|---|---|
| #334 | Fundação (este material) | (vários) | ✅ concluído |
| #335 | Cadastros | `cadastros.md` | ✅ concluído |
| #336 | Comercial (Admissão / Prospecção) | `comercial.md` | ✅ concluído |
| #337 | Financeiro | `financeiro.md` | ✅ concluído |
| #338 | Jurídico | `juridico.md` | ✅ concluído |
| #339 | Cobrança e Negociação | `cobranca-negociacao.md` | ✅ concluído |
| #340 | Agenda | `agenda.md` | ✅ concluído |
| #341 | Mensagens e WhatsApp | `mensagens-whatsapp.md` | ✅ concluído |
| #342 | Relatórios e Formulários | `relatorios.md` | ✅ concluído |
| #343 | IA e Configurações | `ia-configuracoes.md` | ✅ concluído |

### Tratamento dos prints

Os prints já existem em `public/help-screenshots/` (44 imagens, ~5,6 MB) e cobrem a maioria
das telas. Para evitar duplicar binários, cada arquivo de módulo traz um **"Mapa de prints"**
que referencia o print canônico (`public/help-screenshots/<slug>.jpg`) em vez de copiá-lo. Onde
ainda não há cobertura (ex.: Prospecção, Conversas WhatsApp, chat do Léo, abas Importação e
Base de Conhecimento), o documento registra a **lacuna** e o slug sugerido para captura futura.

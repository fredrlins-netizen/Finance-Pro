# Glossário — Termos do FinancePro

> Documento-fonte para o artigo **"Glossário de Termos"** (categoria **Geral**) da Base de
> Conhecimento IA. Mantém um vocabulário único para toda a documentação dos módulos.

## Como usar este glossário

- Sempre que um documento de módulo usar um destes termos, **não redefina** — referencie aqui.
- Mantenha as definições em **linguagem simples**, como se explicasse para um usuário novo.

---

## Termos gerais

- **Unidade:** filial ou escritório da assessoria. A maioria das telas é filtrada pela
  unidade ativa, escolhida no seletor no topo da tela.
- **Colaborador:** funcionário da assessoria cadastrado no sistema (atendente, gerente, etc.).
- **Usuário:** uma conta de acesso ao sistema. Tem login, senha, perfil e permissões.
- **Grupo de acesso / Permissão:** define o que cada usuário pode **ver** e **fazer**.
- **Status ATIVO / INATIVO:** indica se um cadastro está em uso. Inativos não aparecem nas
  listas de seleção, mas permanecem no histórico.

## Cadastros

- **Cliente:** pessoa física ou jurídica atendida pela assessoria.
- **Modalidade:** tipo de dívida/serviço trabalhado (ex.: Veículos, Cartões, Consignado,
  Empréstimos).
- **Produto:** item ou serviço oferecido, usado em contratos e cobranças.
- **Série:** numeração sequencial de documentos (ex.: contratos, procurações). Cada série
  tem uma sigla e um número geral.
- **Cargo:** função do colaborador (ex.: Gerente Comercial).
- **Departamento:** setor da empresa (ex.: Administrativo, Comercial, Jurídico).
- **Banco:** instituição financeira cadastrada, com código FEBRABAN e serviços/percentuais
  de negociação.

## Comercial

- **Admissão:** o contrato do cliente com a assessoria. É o registro central que liga
  cliente, banco, modalidade, colaborador e valores.
- **Ficha de contrato:** detalhamento completo de uma admissão.
- **Recálculo / Cenário de recálculo:** simulação que mostra quanto o cliente economiza ao
  renegociar — com nova parcela, nova dívida e valor da economia.
- **Prospecção:** etapa de captação e primeiro contato com possíveis clientes.
- **Negociação Comercial:** tratativas comerciais com o cliente antes/depois da admissão.

## Financeiro

- **Contas a Receber:** valores que a empresa tem para receber (honorários, parcelas).
- **Contas a Pagar:** valores que a empresa precisa pagar (despesas, fornecedores).
- **Baixa:** registrar que uma conta foi quitada — recebida (a receber) ou paga (a pagar).
- **Portador:** quem "carrega" a cobrança — uma carteira local ou um banco (ex.: Cobrança BB).
- **Tipo de documento:** classificação do título financeiro (Nota Fiscal, Boleto, Recibo,
  Duplicata). Pode ser fiscal e exigir número.
- **Plano de Contas:** estrutura em árvore que classifica receitas e despesas por categoria
  (ex.: 1.01.01 Honorários de Consultoria). Contas analíticas recebem lançamentos; contas
  sintéticas apenas agrupam.
- **Conta Corrente:** contas bancárias da empresa e seus movimentos.
- **Conciliação Bancária:** conferência entre os lançamentos do sistema e o extrato do banco.
- **Fatura:** agrupamento de valores a cobrar do cliente.
- **Parcela recorrente:** cobrança que se repete automaticamente em intervalos definidos.
- **Fornecedor:** quem fornece produtos/serviços à empresa (usado em Contas a Pagar).

## Cobrança e Negociação

- **Operacional (Cobrança):** visão do operador que trabalha as parcelas em atraso no dia a dia.
- **Coordenador (Cobrança):** visão de coordenação, com metas e acompanhamento da equipe.
- **Meta:** objetivo de recuperação/valor a ser atingido por operador ou equipe.
- **Proposta de acordo:** oferta de renegociação registrada para um cliente em atraso.
- **Negociação Financeira:** renegociação de valores em aberto no módulo Financeiro.

## Jurídico

- **Processo:** ação judicial acompanhada pelo sistema (do cliente ou da empresa).
- **Prazo:** data-limite para uma providência processual.
- **Audiência:** sessão marcada na Justiça, acompanhada com data e notificação.

## Agenda, Mensagens e WhatsApp

- **Agendamento:** atendimento marcado com cliente, colaborador, serviço, data e horário.
- **Rodízio de colaboradores:** distribuição automática de atendimentos entre a equipe.
- **Mensagens (chat interno):** conversas entre colaboradores dentro do sistema, com
  status de entrega/lido, anexos e grupos.
- **Conversas (WhatsApp):** atendimento ao cliente pelo WhatsApp via integração multi-canal.
- **Canal:** uma conexão de WhatsApp configurada para envio/recebimento de mensagens.

## Relatórios, Formulários e IA

- **Report Builder / Gerador de Relatórios:** ferramenta para montar relatórios com filtros,
  gráficos, subrelatórios e exportação (PDF/Excel/Word/CSV).
- **Formulário:** documento configurável com variáveis dinâmicas (ex.: dados do cliente),
  vinculado a módulos como Admissão e Jurídico.
- **Variável dinâmica:** campo que é preenchido automaticamente com dados do sistema
  (ex.: `{{cliente.nome}}`).
- **Léo:** assistente de IA do sistema. Responde dúvidas sobre o FinancePro usando a Base de
  Conhecimento e ajuda a analisar dados e relatórios.
- **Base de Conhecimento IA:** conjunto de artigos que o Léo consulta para responder.
- **Auditoria:** registro e revisão de ações e dados para conferência e conformidade.

# Visão Geral — O que é o FinancePro Assessoria

> Documento-fonte para o artigo **"Visão Geral do Sistema"** (categoria **Geral**) da Base de Conhecimento IA e para o tópico introdutório da Central de Ajuda.

## O que é

O **FinancePro Assessoria** é um sistema completo de gestão (CRM) feito para **assessorias
financeiras** — empresas que ajudam clientes a renegociar e revisar dívidas (financiamentos
de veículos, cartões de crédito, consignados, empréstimos) e a acompanhar processos
jurídicos relacionados.

Em um único lugar, a equipe consegue: cadastrar clientes, registrar contratos (admissões),
calcular cenários de renegociação, controlar o que a empresa tem a receber e a pagar,
acompanhar cobranças e processos na Justiça, agendar atendimentos, conversar com clientes
pelo WhatsApp e gerar relatórios.

## Para quem serve

| Perfil | O que faz no sistema |
|---|---|
| **Atendente / Comercial** | Cadastra clientes, registra admissões, monta cenários de recálculo, negocia. |
| **Financeiro** | Lança contas a receber/pagar, dá baixas, concilia banco, gera faturas. |
| **Cobrança** | Acompanha parcelas em atraso, registra contatos e propostas, bate metas. |
| **Jurídico** | Acompanha processos, prazos e audiências do cliente e da empresa. |
| **Coordenador / Administrador** | Configura unidades, usuários, permissões, metas e relatórios. |

## Mapa de módulos e como se conectam

O fluxo típico de um cliente atravessa vários módulos, nesta ordem aproximada:

```
        Cadastros (Cliente)
              │
              ▼
   Comercial → Admissão (contrato) ──► Recálculo (cenários de economia)
              │                              │
              │                              ▼
              │                        Negociação Comercial
              ▼
   Financeiro (Contas a Receber: honorários/parcelas)
              │
              ▼
   Cobrança (parcelas em atraso, propostas) ◄──► Negociação Financeira
              │
              ▼
   Jurídico (processos, prazos, audiências) — quando há ação judicial

  Em paralelo, dão suporte a todo o fluxo:
  Agenda · Mensagens internas · WhatsApp · Relatórios · IA (Léo) · Configurações
```

### Resumo de cada módulo

| Módulo | Para que serve |
|---|---|
| **Cadastros** | Base de dados do sistema: clientes, colaboradores, bancos, modalidades, produtos, séries, cargos, departamentos, unidades. |
| **Comercial** | Admissões (contratos), recálculos de dívida, prospecção e negociação comercial. |
| **Financeiro** | Contas a receber e a pagar, baixas, faturas, parcelas recorrentes, conta corrente e conciliação bancária. |
| **Jurídico** | Acompanhamento de processos (do cliente e da empresa), prazos, audiências e notificações. |
| **Cobrança / Negociação** | Painéis operacional e de coordenação, metas, registro de contatos e propostas de acordo. |
| **Agenda** | Agendamento de atendimentos com filtro por unidade, rodízio de colaboradores e arrastar-e-soltar. |
| **Mensagens** | Chat interno em tempo real entre os colaboradores (estilo WhatsApp), com entrega/lido, anexos e grupos. |
| **WhatsApp (Conversas)** | Atendimento ao cliente pelo WhatsApp via integração multi-canal, com webhook e histórico. |
| **Relatórios** | Gerador de relatórios com filtros, gráficos e exportação (PDF/Excel/Word/CSV), além de formulários. |
| **IA (Léo)** | Assistente que tira dúvidas sobre o sistema e analisa dados, usando a Base de Conhecimento. |
| **Configurações** | Unidades, usuários, permissões, e-mail, integrações, auditoria, importação e Central de Ajuda. |

## Conceitos-chave para entender o todo

- **Unidade:** cada filial/escritório. Quase tudo é filtrado por unidade; o usuário escolhe
  a unidade ativa no topo da tela.
- **Admissão:** o "contrato" do cliente com a assessoria — ponto de partida do trabalho.
- **Recálculo:** simulação de quanto o cliente economiza renegociando a dívida.
- **Baixa:** ato de registrar que uma conta foi paga (recebida ou paga).
- **Permissões:** o que cada usuário pode ver e fazer é definido por grupos de acesso.

> Os termos acima e outros estão detalhados em [`glossario.md`](./glossario.md).

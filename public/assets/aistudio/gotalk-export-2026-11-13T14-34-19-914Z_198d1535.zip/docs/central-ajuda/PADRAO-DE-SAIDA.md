# Padrão de Saída — Schema dos Artigos e Tópicos

> Toda tarefa de módulo (#335–#343) deve produzir o material **exatamente** neste formato.
> Assim o conteúdo entra sem retrabalho na **Base de Conhecimento IA** e na **Central de Ajuda**.

Cada arquivo `docs/central-ajuda/<modulo>.md` tem **duas partes de entrega**:

- **Parte A** → cola na aba **Base de Conhecimento IA** (assistente Léo).
- **Parte B** → cola em `components/help/HelpContentData.ts` (Central de Ajuda).

---

## Parte A — Artigo da Base de Conhecimento IA

Campos do artigo (tabela `leo_knowledge_articles`, rotas em `server/routes/leoKnowledge.js`):

| Campo | Regra técnica | Como preencher |
|---|---|---|
| **title** | Texto, **≤ 255 caracteres**, obrigatório | Coloque aqui as **palavras-chave mais buscadas** (palavras no título dominam o ranking — ver regras de RAG abaixo). |
| **category** | Uma das categorias válidas (lista abaixo) | Escolha a que melhor representa o módulo. |
| **content** | HTML, **≤ 100.000 caracteres**, obrigatório | Conteúdo em passos. HTML simples (`<h3>`, `<p>`, `<ul>`, `<strong>`). |
| **images** | Até **3 imagens**, JPEG/PNG/WEBP, **≤ 2 MB** cada (base64) | Opcional. Prints de apoio com dados mascarados. |
| **active** | Booleano | `true` para o artigo ficar disponível ao Léo. |

### Categorias válidas

```
Geral · Admissão · Agenda · Financeiro · Jurídico · Cobrança ·
Negociação · Relatórios · Configurações · Comercial · Auditoria ·
Mensagens · WhatsApp
```

### Como o Léo encontra o artigo (regras de RAG)

Definidas em `server/services/trainingKnowledge.js` (`scoreArticles`) e em
`server/routes/ai.js`. Escreva o artigo pensando nelas:

- A busca quebra a pergunta do usuário em **palavras com 3+ caracteres**.
- Para cada palavra, a pontuação soma duas contagens:
  1. ocorrências da palavra **no título × 3** (bônus de título);
  2. ocorrências da palavra no texto geral (`título + categoria + conteúdo`) × 1.
- **Na prática, palavras no título dominam o ranking:** elas pontuam pelo bônus (×3) **e**
  novamente pela contagem geral (×1) — efeito de cerca de **4× por ocorrência no título**.
  A **categoria também conta** (×1). Por isso, o título é o lugar mais valioso para os termos.
- Só os **5 artigos** com maior pontuação (e pontuação > 0) vão para o Léo.
- O **HTML é removido** antes de enviar ao modelo (`<[^>]*>` → espaço) — então o texto precisa
  fazer sentido como texto puro (não dependa de tabelas/estilos para o significado).
- O conteúdo enviado ao modelo é **truncado em ~3.000 caracteres por artigo**
  (`server/routes/ai.js`), então coloque o essencial **no começo**.
- No máximo **3 imagens** no total entre os artigos selecionados.

**Consequências práticas:**
- Título objetivo e cheio de termos reais (ex.: "Contas a Receber: lançar, dar baixa e emitir
  fatura"), não genérico ("Tela financeira").
- Repita os termos centrais nas **primeiras linhas** do conteúdo.
- Cada artigo cobre **um assunto**; assuntos diferentes = artigos diferentes (melhora o ranking).

### Modelo da Parte A

```markdown
## Parte A — Artigo da Base de Conhecimento IA

- **title:** Contas a Receber: lançar, dar baixa e emitir fatura
- **category:** Financeiro
- **termos de busca (devem aparecer no título/início):** receber, baixa, fatura, parcela, honorário
- **active:** true

### content (HTML)

<h3>O que é a tela de Contas a Receber</h3>
<p>...</p>
<h3>Como lançar uma conta a receber</h3>
<ol><li>...</li></ol>
<h3>Como dar baixa</h3>
<p>...</p>
```

---

## Parte B — Tópico(s) da Central de Ajuda

Formato `HelpTopic` (interface em `types.ts`; exemplos em `components/help/HelpContentData.ts`):

| Campo | Tipo | Como preencher |
|---|---|---|
| **id** | string | Identificador curto e único (ex.: `fin_receber`). |
| **menuPath** | string | Caminho/nome amigável da tela (ex.: "Financeiro › Contas a Receber"). |
| **title** | string | Título da tela (ex.: "Contas a Receber"). |
| **summary** | string | Uma frase do que a tela faz (aparece na lista de tópicos). |
| **content** | string (HTML) | Conteúdo completo. Começa com o `<img>` do print. |
| **keywords** | string[] | Termos de busca da Central de Ajuda. |

### Convenção do print na Central de Ajuda

- Prints publicados ficam em `public/help-screenshots/<slug>.jpg` e são referenciados como
  `/help-screenshots/<slug>.jpg`.
- Use o mesmo `<img>` dos tópicos existentes:

```html
<img src="/help-screenshots/<slug>.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
```

### Modelo da Parte B

```markdown
## Parte B — Tópico(s) da Central de Ajuda

{
    id: 'fin_receber',
    menuPath: 'Financeiro › Contas a Receber',
    title: 'Contas a Receber',
    summary: 'Tela para lançar valores a receber, dar baixa em pagamentos e emitir faturas.',
    content: `<img src="/help-screenshots/fin-receber.jpg" alt="" style="..." />
        <h3>Visão geral</h3>
        <p>...</p>
        <h3>Campos da tela</h3>
        <ul><li><strong>Cliente:</strong> ...</li></ul>
    `,
    keywords: ['receber', 'baixa', 'fatura', 'parcela', 'honorário', 'financeiro'],
}
```

---

## Regra de privacidade (LGPD) — vale para as duas partes

- **Nunca** use dados reais de clientes nos prints ou no texto: nomes, CPF/CNPJ, telefone,
  e-mail, endereço, valores sensíveis.
- Use os **dados de exemplo** já presentes no sistema (ex.: "CARLOS ALBERTO DE NOBREGA",
  "TRANSPORTES RAPIDÃO LTDA", CPF "123.456.789-00").
- Se um print capturar dado real, **mascare** antes de salvar (borrar/tarjar).

## Checklist antes de entregar um módulo

- [ ] Parte A com título rico em palavras-chave e categoria válida.
- [ ] Conteúdo em passos, com os termos centrais no começo.
- [ ] Parte B com `HelpTopic` completo (id único, print, keywords).
- [ ] Print reaproveitado de `public/help-screenshots/` ou novo em `docs/central-ajuda/prints/`.
- [ ] Nenhum dado real exposto (LGPD).
- [ ] Termos do negócio referenciados ao `glossario.md`, não redefinidos.

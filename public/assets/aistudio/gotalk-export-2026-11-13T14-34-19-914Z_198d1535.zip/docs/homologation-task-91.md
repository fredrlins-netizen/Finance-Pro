# Homologação de escala de anexos (task 91)

Este procedimento é deliberadamente isolado e **nunca deve ser executado em produção**.
Use um banco e um bucket privados de homologação, com credenciais de menor privilégio.

## Execução reproduzível

```sh
export NODE_ENV=development
export HOMOLOGATION_ISOLATED=true
export DATABASE_URL='postgres://.../homologation'
npm run homologation:generate -- --run-id h91-2025-01 --object-bytes 4096
npm run homologation:inventory -- --run-id h91-2025-01
HOMOLOGATION_BASE_URL=http://127.0.0.1:3001 npm run homologation:load -- --run-id h91-2025-01
npm run homologation:cleanup -- --run-id h91-2025-01 --confirm
```

O gerador cria exatamente 3.000 clientes, 300.000 índices e objetos privados,
e 1.000 identidades distribuídas deterministicamente (uma unidade permitida por
identidade) pelas unidades existentes. Cada cliente possui um título financeiro
na mesma unidade e cada anexo aponta para o título do próprio cliente; IDs são determinísticos
por run; reexecuções retomam por `batch_key/item_key` sem truncar tabelas. Tamanho
de objeto configurável fica limitado pelo schema (até 20 MiB). As credenciais são
gravadas em arquivo local com modo 0600 e nunca são impressas.

O runner faz login real em `/api/auth/login` para cada identidade (cookie de sessão,
sem Basic Auth), usa UUIDs reais do manifesto e testa list/content/download com autenticação individual e estágios
1/10/100/500/1000. O estágio de 1000 sustenta 15 minutos por padrão
(`HOMOLOGATION_SUSTAIN_MINUTES`), abortando quando a taxa de erro excede 5%.
Cada usuário virtual é independente, tem início escalonado e aguarda 20 segundos
entre ações por padrão (`HOMOLOGATION_THINK_TIME_MS`). Isso representa pessoas
lendo ou inspecionando documentos, evita rajadas sincronizadas artificiais e mantém
as 1.000 sessões ativas durante toda a sustentação. Para medir saturação de rajada,
defina `HOMOLOGATION_THINK_TIME_MS=0`; esse perfil é complementar e não substitui
o perfil de capacidade por usuários.
O JSON produzido contém p50/p95/p99 por list/content/download, classes de status,
vazão, erros e janela temporal. Um usuário admin isolado coleta automaticamente
`/api/homologation/metrics` (sistema, pool/DB, storage indexado e auditoria).
Cole no
relatório abaixo as métricas de sistema, PostgreSQL, storage e auditoria coletadas
pela observabilidade do ambiente; o harness não expõe segredos.
O gerador grava também um `EXPLAIN (ANALYZE, BUFFERS)` da consulta de inventário de
300 mil linhas. A aceitação exige >=99% de respostas 2xx válidas, zero 5xx/timeouts,
p95 <=1s e p99 <=2s no estágio sustentado de 1.000 usuários; `acceptance.passed`
no relatório é a avaliação objetiva. Os máximos dos ramp-ups menores continuam
registrados para diagnóstico, mas amostras pequenas não substituem o estágio final.

## Relatório

### Execução homologada

- Run ID: `h91-full-20260921014254`
- Janela definitiva: 2026-09-21 03:45:13–04:03:44 UTC
- Servidor: `NODE_ENV=production`, uma instância Node, mesmo entrypoint do deploy.
- PostgreSQL: banco exclusivo, migrations aplicadas antes do teste e role de runtime
  exclusiva, sem `SUPERUSER`, `CREATEDB` ou `CREATEROLE`.
- Object Storage: prefixo privado exclusivo
  `client-attachments/h91/<run-id>/`; nenhuma chave ou objeto real foi copiado.
- Integrações GoTalk externas desabilitadas. Redis não estava disponível; a auditoria
  de anexos usa a fila PostgreSQL criada para este caminho, portanto não dependeu do
  fallback em memória.
- Massa anterior à carga: 3.000 clientes, 300.000 anexos/objetos de 4 KiB e 1.000
  identidades. Inventário confirmou 300.000/300.000 e zero órfãos.

### Resultado por estágio

| Usuários | Requisições | req/s | p50 | p95 | p99 | 5xx/timeouts |
|---:|---:|---:|---:|---:|---:|---:|
| 1 | 2 | 0,05 | 13 ms | 1.032 ms | 1.032 ms | 0 |
| 10 | 17 | 0,34 | 171 ms | 881 ms | 881 ms | 0 |
| 100 | 166 | 3,30 | 194 ms | 479 ms | 752 ms | 0 |
| 500 | 826 | 16,32 | 194 ms | 582 ms | 738 ms | 0 |
| 1.000 (15 min) | 44.674 | 48,23 | 175 ms | 426 ms | 588 ms | 0 |

Na sustentação de 1.000 usuários:

- listagem: p50 10 ms, p95 17 ms, p99 62 ms;
- pré-visualização: p50 187 ms, p95 525 ms, p99 603 ms;
- download: p50 186 ms, p95 515 ms, p99 600 ms;
- 44.376 respostas válidas 2xx e 298 negativas 403 esperadas;
- 100% das requisições válidas retornaram 2xx, sem status inesperados;
- nenhum 5xx, timeout, OOM ou aborto;
- `acceptance.passed=true`.

O p95 de 1.032 ms no estágio de uma pessoa representa uma única observação de
armazenamento em uma amostra de duas requisições. Ele permanece no campo
`allStagesMaxP95`, mas a aceitação usa, conforme o requisito, o estágio final
sustentado e estatisticamente representativo.

### Sistema, banco, auditoria e armazenamento

- RSS: 149 MB antes e 195 MB ao final; heap usado: 44,8 MB antes e 41,9 MB ao final.
- CPU acumulada durante a janela: aproximadamente 155 s user + 34,7 s system,
  média de 17% de um core.
- Event loop final: média 20,2 ms, p95 20,9 ms, p99 22,4 ms; máximo isolado 591 ms.
- Pool final: 16 conexões, 16 ociosas, zero aguardando; zero consultas ativas acima
  de um segundo e zero locks não concedidos.
- Armazenamento, autorização e HTTP combinados no estágio final: preview p95 525 ms
  e download p95 515 ms.
- Auditoria: 30.149 acessos a conteúdo, 30.149 jobs concluídos, zero pendentes/falhos;
  drenagem final em 719 ms. A indisponibilidade e os retries são cobertos pelo
  worker durável e pelos testes automatizados.

### Planos sobre 300 mil registros

`EXPLAIN (ANALYZE, BUFFERS)` foi executado com IDs de usuário, unidade, cliente e
anexo da massa sintética:

- listagem autorizada: 1,314 ms, 51 linhas, usando
  `idx_client_attachments_client_cursor`;
- contagem autorizada: 1,017 ms, 100 linhas, usando index-only scan em
  `idx_client_attachments_client_target_cursor`;
- metadado para conteúdo: 0,035 ms, usando `client_attachments_pkey`;
- autorização do título/unidade: 0,066 ms, usando
  `idx_ft_composite_client_scope`;
- zero blocos lidos do disco nessa amostra aquecida; os buffers foram hits.

### Baseline, gargalo e capacidade

O baseline de rajada sem tempo de leitura (`HOMOLOGATION_THINK_TIME_MS=0`) fez
179.000 requisições no estágio de 1.000, a 197 req/s: p50 3,27 s, p95 4,04 s e
p99 4,27 s. Ele não atingiu o SLA, embora não tenha produzido erros.

A reutilização de uma única instância do cliente Object Storage por processo foi
validada com o mesmo perfil de rajada: 267,6 req/s, p95 3,33 s. O SDK instalado
não expõe URL assinada e a credencial gerenciada não possui `client_email` para
assinar diretamente; portanto, a entrega privada continua em streaming, sem
materializar o arquivo completo no heap.

A capacidade homologada é **1.000 sessões ativas com uma ação a cada 20 segundos**
(aproximadamente 48 req/s) para objetos de 4 KiB, com início escalonado. O perfil de
rajada documenta o limite de saturação e não deve ser apresentado como capacidade
com SLA.

### Limitações em relação ao autoscale

- Uma única instância foi usada; não há evidência acima de 1.000 usuários nem de
  balanceamento entre réplicas.
- Os objetos tinham 4 KiB; arquivos maiores estão fora do perfil homologado.
- O bucket é gerenciado pelo projeto; o isolamento foi feito por prefixo privado e
  inventário, não por um bucket adicional.
- Métricas de CPU/event loop são do processo e métricas PostgreSQL são do banco
  isolado; não representam ruído de vizinhos ou autoscale real.

### Limpeza

Execute `npm run homologation:cleanup -- --run-id <run-id> --confirm`. O comando
remove somente recursos marcados pela execução, exclui objetos com concorrência
limitada e falha se a verificação final encontrar metadados, objetos, usuários,
grupos ou jobs órfãos.

Na execução homologada, a limpeza removeu 300.000 objetos. A verificação interna
retornou `zeroOrphans=true` e zero clientes, usuários, grupos e jobs. Uma segunda
execução independente do inventário confirmou zero objetos, zero metadados e zero
órfãos antes da remoção do banco e da role temporários.
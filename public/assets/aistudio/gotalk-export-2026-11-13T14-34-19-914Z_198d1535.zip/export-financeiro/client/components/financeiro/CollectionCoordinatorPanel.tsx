import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { Client, Collaborator, Admission, AdmissionAttachment, AuditLog, FinancialRecord, TitleStatus, TitleType, Bank, Series, Modality } from '../../types';
import AuditLogButton from '../ui/AuditLogButton';
import AdmissionViewerModal from '../ui/AdmissionViewerModal';
import ConfirmDeleteModal from '../ui/ConfirmDeleteModal';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { formatCurrencyBRL } from '../../utils/currencyUtils';
import BlockedClientBanner from '../ui/BlockedClientBanner';
import { useKeyboardShortcut } from '../../contexts/KeyboardShortcutContext';
import { api, ApiError } from '../../services/apiService';

interface CollectionCoordinatorPanelProps {
    titles: FinancialRecord[];
    setTitles?: React.Dispatch<React.SetStateAction<FinancialRecord[]>>;
    clients: Client[];
    collaborators: Collaborator[];
    admissions: Admission[];
    auditLogs: AuditLog[];
    banks?: Bank[];
    series?: Series[];
    modalities?: Modality[];
    units?: { id: string; razaoSocial?: string; nomeFantasia?: string; name?: string; companyName?: string; [key: string]: any }[];
    GotalkChatPanel?: React.ComponentType<{ clientId: string; area: string; operatorName?: string }>;
    GotalkAttendanceViewer?: React.ComponentType<{ clientId: string; collaboratorId?: string; title: string }>;
}

const statusLabel = (status: string) => {
    const labels: Record<string, string> = { 'ABERTO': 'Em Aberto', 'PAGO': 'Liquidado', 'PARCIAL': 'Parcial', 'CANCELADO': 'Cancelado', 'AGRUPADO': 'Fatura Gerada', 'PROTESTADO': 'Protestado', 'PROVISAO': 'Provisão' };
    return labels[status] || status;
};

const collectionStatusLabel = (status?: string) => {
    const labels: Record<string, string> = { 'EM_DIA': 'Em Dia', 'COBRAR': 'Cobrar', 'NAO_COBRAR': 'Não Cobrar' };
    return labels[status || 'EM_DIA'] || status || 'Em Dia';
};

const collectionStatusColor = (status?: string) => {
    switch (status) {
        case 'COBRAR': return 'bg-amber-100 text-amber-800';
        case 'NAO_COBRAR': return 'bg-gray-100 text-gray-600';
        default: return 'bg-green-100 text-green-800';
    }
};

const agingDays = (dueDate: string) => {
    const due = new Date(dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    due.setHours(0, 0, 0, 0);
    const diff = Math.floor((today.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
};

const agingBucket = (days: number): string => {
    if (days <= 0) return 'A Vencer';
    if (days <= 30) return '1-30 dias';
    if (days <= 60) return '31-60 dias';
    if (days <= 90) return '61-90 dias';
    return '90+ dias';
};

const CollectionCoordinatorPanel: React.FC<CollectionCoordinatorPanelProps> = ({ titles, setTitles, clients, collaborators, admissions, auditLogs, banks = [], series = [], modalities = [], units = [], GotalkChatPanel, GotalkAttendanceViewer }) => {
    const { addToast, currentUser, temPermissao, validarPermissao, isLoggedAdmin } = useSecurity();
    const { logTransaction } = useAudit();
    const canExcluir = isLoggedAdmin || temPermissao('fin_cobranca_coord:EXCLUIR');
    const handleOpenAdmissionModal = useCallback((adm: Admission) => {
        if (!isLoggedAdmin && !temPermissao('com_admissao:VISUALIZAR')) {
            addToast('error', 'Acesso negado', 'Sem permissão para visualizar a Ficha de Admissão.');
            return;
        }
        setViewingAdmission(adm);
    }, [addToast, isLoggedAdmin, temPermissao]);
    const { registerFormActions, unregisterFormActions } = useKeyboardShortcut();

    const [deleteModal, setDeleteModal] = useState<{ title: string; message: string; onConfirm: () => Promise<void> } | null>(null);
    const [deleteLoading, setDeleteLoading] = useState(false);

    const handleDeleteConfirmed = useCallback(async () => {
        if (!deleteModal) return;
        setDeleteLoading(true);
        try {
            await deleteModal.onConfirm();
        } catch {
            // error toast already shown inside onConfirm
        } finally {
            setDeleteLoading(false);
            setDeleteModal(null);
        }
    }, [deleteModal]);

    const [activeMode, setActiveMode] = useState<'GRID' | 'DASHBOARD'>('GRID');
    const [selectedIds, setSelectedIds] = useState<string[]>([]);
    const [showAssignModal, setShowAssignModal] = useState(false);
    const [assignCollaboratorId, setAssignCollaboratorId] = useState('');
    const [showClientPanel, setShowClientPanel] = useState(false);
    const [selectedClientId, setSelectedClientId] = useState<string | null>(null);
    const [selectedCollaboratorId, setSelectedCollaboratorId] = useState<string | null>(null);
    const [viewingAdmission, setViewingAdmission] = useState<Admission | null>(null);
    const [clientPanelTab, setClientPanelTab] = useState<'dados' | 'whatsapp' | 'atendimentos'>('dados');

    const [filterClient, setFilterClient] = useState('');
    const [filterStatus, setFilterStatus] = useState('');
    const [filterCollectionStatus, setFilterCollectionStatus] = useState('');
    const [filterCollaborator, setFilterCollaborator] = useState('');
    const [filterDueDateStart, setFilterDueDateStart] = useState('');
    const [filterDueDateEnd, setFilterDueDateEnd] = useState('');
    const [filterAging, setFilterAging] = useState('');
    const [filterState, setFilterState] = useState('');
    const [showFilters, setShowFilters] = useState(false);

    const [editingTitle, setEditingTitle] = useState<FinancialRecord | null>(null);
    const [editForm, setEditForm] = useState<Partial<FinancialRecord>>({});
    const [isSavingEdit, setIsSavingEdit] = useState(false);

    const [sortColumn, setSortColumn] = useState<string>('dueDate');
    const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');

    const [dashboardFilterPeriodStart, setDashboardFilterPeriodStart] = useState('');
    const [dashboardFilterPeriodEnd, setDashboardFilterPeriodEnd] = useState('');
    const [dashboardFilterCollaborator, setDashboardFilterCollaborator] = useState('');
    const [dashboardCancelFilter, setDashboardCancelFilter] = useState(false);

    const [collectionNotes, setCollectionNotes] = useState<Array<{
        id: string; titleId: string; clientId: string; date: string; time: string;
        collaboratorId: string; collaboratorName: string; negotiationStatus: string;
        cancelRequest?: { admissionId: string; admissionContract: string; requestDate: string; notes: string };
    }>>(() => {
        try { return JSON.parse(localStorage.getItem('collection_notes_v1') || '[]'); } catch { return []; }
    });

    useEffect(() => {
        const onStorage = () => {
            try { setCollectionNotes(JSON.parse(localStorage.getItem('collection_notes_v1') || '[]')); } catch {}
        };
        window.addEventListener('storage', onStorage);
        return () => window.removeEventListener('storage', onStorage);
    }, []);

    const cancelNotes = useMemo(() => collectionNotes.filter(n => n.negotiationStatus === 'SOLICITA_CANCELAMENTO' && n.cancelRequest), [collectionNotes]);

    const collectionTitles = useMemo(() => {
        return titles.filter(t =>
            t.type === 'PADRAO' &&
            !['CANCELADO', 'AGRUPADO', 'PAGO', 'ADIANTAMENTO', 'ADIANTAMENTO_PARCIAL', 'DEVOLUCAO', 'DEVOLUCAO_VINCULADA', 'DEVOLUCAO_PARCIAL'].includes(t.status)
        );
    }, [titles]);

    const filteredTitles = useMemo(() => {
        let data = [...collectionTitles];

        if (filterClient) {
            const term = filterClient.toLowerCase();
            data = data.filter(t => t.clientName.toLowerCase().includes(term));
        }
        if (filterStatus) {
            data = data.filter(t => t.status === filterStatus);
        }
        if (filterCollectionStatus) {
            data = data.filter(t => (t.collectionStatus || 'EM_DIA') === filterCollectionStatus);
        }
        if (filterCollaborator) {
            data = data.filter(t => t.assignedCollaboratorId === filterCollaborator);
        }
        if (filterDueDateStart) {
            data = data.filter(t => t.dueDate >= filterDueDateStart);
        }
        if (filterDueDateEnd) {
            data = data.filter(t => t.dueDate <= filterDueDateEnd);
        }
        if (filterAging) {
            data = data.filter(t => {
                const days = agingDays(t.dueDate);
                const bucket = agingBucket(days);
                return bucket === filterAging;
            });
        }
        if (filterState) {
            data = data.filter(t => {
                const client = clients.find(c => c.id === t.clientId);
                return (client?.state || '').toUpperCase() === filterState.toUpperCase();
            });
        }

        data.sort((a, b) => {
            let valA: any = (a as any)[sortColumn];
            let valB: any = (b as any)[sortColumn];
            if (sortColumn === 'currentBalance' || sortColumn === 'originalValue') {
                valA = Number(valA) || 0;
                valB = Number(valB) || 0;
            }
            if (valA < valB) return sortDirection === 'asc' ? -1 : 1;
            if (valA > valB) return sortDirection === 'asc' ? 1 : -1;
            return 0;
        });

        return data;
    }, [collectionTitles, filterClient, filterStatus, filterCollectionStatus, filterCollaborator, filterDueDateStart, filterDueDateEnd, filterAging, filterState, clients, sortColumn, sortDirection]);

    const handleSort = (col: string) => {
        if (sortColumn === col) {
            setSortDirection(prev => prev === 'asc' ? 'desc' : 'asc');
        } else {
            setSortColumn(col);
            setSortDirection('asc');
        }
    };

    const toggleSelectAll = () => {
        if (selectedIds.length === filteredTitles.length) {
            setSelectedIds([]);
        } else {
            setSelectedIds(filteredTitles.map(t => t.id));
        }
    };

    const toggleSelect = (id: string) => {
        setSelectedIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
    };

    const handleBatchAssign = () => {
        if (!assignCollaboratorId) {
            addToast('warning', 'Atenção', 'Selecione um colaborador.');
            return;
        }
        if (selectedIds.length === 0) {
            addToast('warning', 'Atenção', 'Selecione pelo menos um título.');
            return;
        }
        const selectedTitles = titles.filter(t => selectedIds.includes(t.id));
        const hasBlockedClient = selectedTitles.some(t => {
            const client = clients.find(c => c.id === t.clientId);
            return client?.blocked === true;
        });
        if (hasBlockedClient) {
            addToast('warning', 'Cliente Bloqueado', 'Existem títulos de clientes bloqueados na seleção. Não é possível atribuir cobrança.');
            return;
        }

        setTitles?.(prev => prev.map(t => {
            if (selectedIds.includes(t.id)) {
                const updated = { ...t, assignedCollaboratorId: assignCollaboratorId, collectionStatus: 'COBRAR' as const };
                logTransaction('CONTA_RECEBER', t.id, t, updated);
                return updated;
            }
            return t;
        }));

        const collab = collaborators.find(c => c.id === assignCollaboratorId);
        addToast('success', 'Sucesso', `${selectedIds.length} título(s) atribuído(s) a ${collab?.name || 'colaborador'} com situação "Cobrar".`);
        setSelectedIds([]);
        setShowAssignModal(false);
        setAssignCollaboratorId('');
    };

    const handleDeleteTitle = (title: FinancialRecord) => {
        if (!validarPermissao('fin_cobranca_coord:EXCLUIR')) return;
        const client = clients.find(c => c.id === title.clientId);
        if (client?.blocked) {
            addToast('warning', 'Cliente Bloqueado', 'Cliente bloqueado — não é possível excluir este título.');
            return;
        }
        setDeleteModal({
            title: 'Excluir Título',
            message: `Excluir o título "${title.documentNumber}" de ${title.clientName}? Esta ação não pode ser desfeita.`,
            onConfirm: async () => {
                try {
                    await api.delete(`/api/financial-titles/${title.id}`);
                    setTitles?.(prev => prev.filter(t => t.id !== title.id));
                    logTransaction('CONTA_RECEBER', title.id, title, null);
                    addToast('success', 'Excluído', 'Título removido com sucesso.');
                } catch (err) {
                    const msg = err instanceof Error ? err.message : 'Não foi possível excluir o título.';
                    const details = err instanceof ApiError ? err.details : undefined;
                    addToast('error', 'Erro ao excluir', details ? `${msg}: ${details}` : msg);
                    throw err;
                }
            },
        });
    };

    const handleDeleteCancelNote = (noteId: string) => {
        if (!validarPermissao('fin_cobranca_coord:EXCLUIR')) return;
        setDeleteModal({
            title: 'Excluir Solicitação de Cancelamento',
            message: 'Excluir esta solicitação de cancelamento? Esta ação não pode ser desfeita.',
            onConfirm: async () => {
                try {
                    await api.delete(`/api/collection-notes/${noteId}`);
                    setCollectionNotes(prev => {
                        const updated = prev.filter(n => n.id !== noteId);
                        try { localStorage.setItem('collection_notes_v1', JSON.stringify(updated)); } catch {}
                        return updated;
                    });
                    addToast('success', 'Excluído', 'Solicitação de cancelamento excluída.');
                } catch {
                    addToast('error', 'Erro', 'Não foi possível excluir a solicitação.');
                }
            },
        });
    };

    const handleOpenEdit = (title: FinancialRecord) => {
        setEditingTitle(title);
        setEditForm({
            description: title.description,
            documentNumber: title.documentNumber,
            dueDate: title.dueDate,
            expectedDate: title.expectedDate || '',
            status: title.status,
            collectionStatus: title.collectionStatus || 'EM_DIA',
            assignedCollaboratorId: title.assignedCollaboratorId || '',
            interestValue: title.interestValue ?? 0,
            penaltyValue: title.penaltyValue ?? 0,
            discountValue: title.discountValue ?? 0,
        });
    };

    const handleSaveEdit = async () => {
        if (!editingTitle) return;
        if (!editForm.dueDate) {
            addToast('warning', 'Validação', 'Informe a data de vencimento.');
            return;
        }
        setIsSavingEdit(true);
        try {
            const payload = {
                ...editingTitle,
                ...editForm,
                titleScope: 'RECEBER',
            };
            const res = await api.put<{ data: FinancialRecord }>(`/api/financial-titles/${editingTitle.id}`, payload);
            const saved = res.data;
            const merged: FinancialRecord = {
                ...editingTitle,
                ...saved,
                settlements: editingTitle.settlements ?? saved.settlements ?? [],
            };
            setTitles?.(prev => prev.map(t => t.id === merged.id ? merged : t));
            logTransaction('CONTA_RECEBER', merged.id, editingTitle, merged);
            addToast('success', 'Sucesso', 'Lançamento atualizado com sucesso.');
            setEditingTitle(null);
            setEditForm({});
        } catch (err) {
            addToast('error', 'Erro', err instanceof Error ? err.message : 'Não foi possível salvar as alterações.');
        } finally {
            setIsSavingEdit(false);
        }
    };

    useEffect(() => {
        if (editingTitle) {
            registerFormActions(handleSaveEdit, () => { setEditingTitle(null); setEditForm({}); });
        } else if (showAssignModal) {
            registerFormActions(handleBatchAssign, () => { setShowAssignModal(false); setAssignCollaboratorId(''); });
        } else {
            unregisterFormActions();
        }
        return () => unregisterFormActions();
    }, [editingTitle, editForm, showAssignModal]);

    const handleOpenClientPanel = (clientId: string, collaboratorId?: string | null, openTab?: 'dados' | 'whatsapp' | 'atendimentos') => {
        setSelectedClientId(clientId);
        setSelectedCollaboratorId(collaboratorId ?? null);
        setClientPanelTab(openTab ?? 'dados');
        setShowClientPanel(true);
    };

    const selectedClient = useMemo(() => clients.find(c => c.id === selectedClientId), [clients, selectedClientId]);
    const clientAdmissions = useMemo(() => admissions.filter(a => a.clientId === selectedClientId), [admissions, selectedClientId]);

    const dashboardData = useMemo(() => {
        let data = collectionTitles;
        if (dashboardFilterPeriodStart) data = data.filter(t => t.dueDate >= dashboardFilterPeriodStart);
        if (dashboardFilterPeriodEnd) data = data.filter(t => t.dueDate <= dashboardFilterPeriodEnd);
        if (dashboardFilterCollaborator) data = data.filter(t => t.assignedCollaboratorId === dashboardFilterCollaborator);

        const totalTitles = data.length;
        const overdueTitles = data.filter(t => agingDays(t.dueDate) > 0);
        const overdueCount = overdueTitles.length;
        const totalBalance = data.reduce((sum, t) => sum + (Number(t.currentBalance) || 0), 0);
        const overdueBalance = overdueTitles.reduce((sum, t) => sum + (Number(t.currentBalance) || 0), 0);

        const taxaInadimplencia = totalTitles > 0 ? (overdueCount / totalTitles) * 100 : 0;

        const settledTitles = titles.filter(t => t.type === 'PADRAO' && t.status === 'PAGO');
        let settledInPeriod = settledTitles;
        if (dashboardFilterPeriodStart) settledInPeriod = settledInPeriod.filter(t => t.dueDate >= dashboardFilterPeriodStart);
        if (dashboardFilterPeriodEnd) settledInPeriod = settledInPeriod.filter(t => t.dueDate <= dashboardFilterPeriodEnd);
        const recoveredValue = settledInPeriod.reduce((sum, t) => sum + (Number(t.originalValue) || 0), 0);
        const totalPortfolio = totalBalance + recoveredValue;
        const taxaRecuperacao = totalPortfolio > 0 ? (recoveredValue / totalPortfolio) * 100 : 0;

        const avgBalance = totalTitles > 0 ? totalBalance / totalTitles : 0;
        const dailyRevenue = recoveredValue > 0 ? recoveredValue / 30 : 1;
        const dso = dailyRevenue > 0 ? Math.round(avgBalance / dailyRevenue * 30) : 0;

        const agingBuckets: Record<string, { count: number; balance: number }> = {
            'A Vencer': { count: 0, balance: 0 },
            '1-30 dias': { count: 0, balance: 0 },
            '31-60 dias': { count: 0, balance: 0 },
            '61-90 dias': { count: 0, balance: 0 },
            '90+ dias': { count: 0, balance: 0 },
        };
        data.forEach(t => {
            const days = agingDays(t.dueDate);
            const bucket = agingBucket(days);
            if (agingBuckets[bucket]) {
                agingBuckets[bucket].count++;
                agingBuckets[bucket].balance += (Number(t.currentBalance) || 0);
            }
        });

        const collabPerformance: Record<string, { name: string; assigned: number; balance: number }> = {};
        data.forEach(t => {
            const cId = t.assignedCollaboratorId || '__sem_atribuicao__';
            if (!collabPerformance[cId]) {
                const collab = collaborators.find(c => c.id === cId);
                collabPerformance[cId] = { name: collab?.name || 'Sem Atribuição', assigned: 0, balance: 0 };
            }
            collabPerformance[cId].assigned++;
            collabPerformance[cId].balance += (Number(t.currentBalance) || 0);
        });

        return {
            totalTitles,
            overdueCount,
            totalBalance,
            overdueBalance,
            taxaInadimplencia,
            taxaRecuperacao,
            dso,
            agingBuckets,
            collabPerformance,
            recoveredValue
        };
    }, [collectionTitles, titles, dashboardFilterPeriodStart, dashboardFilterPeriodEnd, dashboardFilterCollaborator, collaborators]);

    const maxBucketBalance = useMemo(() => {
        return Math.max(...Object.values(dashboardData.agingBuckets).map(b => b.balance), 1);
    }, [dashboardData.agingBuckets]);

    const maxCollabBalance = useMemo(() => {
        return Math.max(...Object.values(dashboardData.collabPerformance).map(c => c.balance), 1);
    }, [dashboardData.collabPerformance]);

    const sortIcon = (col: string) => {
        if (sortColumn !== col) return '↕';
        return sortDirection === 'asc' ? '↑' : '↓';
    };

    const totalFiltered = filteredTitles.reduce((s, t) => s + (Number(t.currentBalance) || 0), 0);

    return (
        <>
        <div className="h-full flex flex-col animate-fade-in">
            <div className="bg-moss-800 text-white px-8 py-5 flex items-center gap-4 rounded-t-2xl">
                <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                <div>
                    <h2 className="text-xl font-bold tracking-wide">Cobrança — Coordenadores</h2>
                    <p className="text-moss-200 text-sm">Gestão e atribuição de títulos para equipe de cobrança</p>
                </div>
            </div>

            <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center gap-4">
                <button
                    onClick={() => setActiveMode('GRID')}
                    className={`px-5 py-2 rounded-lg text-sm font-semibold transition-colors ${activeMode === 'GRID' ? 'bg-moss-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                >
                    Carteira de Títulos
                </button>
                <button
                    onClick={() => setActiveMode('DASHBOARD')}
                    className={`px-5 py-2 rounded-lg text-sm font-semibold transition-colors ${activeMode === 'DASHBOARD' ? 'bg-moss-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                >
                    Dashboard
                </button>
            </div>

            {activeMode === 'GRID' && (
                <div className="flex-1 bg-gray-50 p-6 overflow-auto">
                    <div className="flex items-center justify-between mb-4 gap-4 flex-wrap">
                        <div className="flex items-center gap-3 flex-wrap">
                            <input
                                type="text"
                                placeholder="Buscar cliente..."
                                className="rounded-lg border border-gray-300 px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none w-64"
                                value={filterClient}
                                onChange={e => setFilterClient(e.target.value)}
                            />
                            <button onClick={() => setShowFilters(!showFilters)} className="px-4 py-2.5 text-sm rounded-lg border border-gray-300 bg-white hover:bg-gray-50 transition-colors flex items-center gap-2">
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" /></svg>
                                Filtros
                            </button>
                            <span className="text-sm text-gray-500">{filteredTitles.length} título(s) | Saldo: {formatCurrencyBRL(totalFiltered)}</span>
                        </div>
                        <div className="flex items-center gap-3">
                            {selectedIds.length > 0 && (
                                <button
                                    onClick={() => setShowAssignModal(true)}
                                    className="px-5 py-2.5 text-sm rounded-lg bg-amber-600 text-white hover:bg-amber-700 transition-colors font-semibold flex items-center gap-2"
                                >
                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg>
                                    Atribuir ({selectedIds.length})
                                </button>
                            )}
                        </div>
                    </div>

                    {showFilters && (
                        <div className="bg-white rounded-xl border border-gray-200 p-5 mb-4 grid grid-cols-2 md:grid-cols-4 gap-4 shadow-sm">
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Status</label>
                                <select className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                                    <option value="">Todos</option>
                                    <option value="ABERTO">Em Aberto</option>
                                    <option value="PARCIAL">Parcial</option>
                                    <option value="PROTESTADO">Protestado</option>
                                    <option value="PROVISAO">Provisão</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Situação Cobrança</label>
                                <select className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterCollectionStatus} onChange={e => setFilterCollectionStatus(e.target.value)}>
                                    <option value="">Todos</option>
                                    <option value="EM_DIA">Em Dia</option>
                                    <option value="COBRAR">Cobrar</option>
                                    <option value="NAO_COBRAR">Não Cobrar</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Colaborador</label>
                                <select className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterCollaborator} onChange={e => setFilterCollaborator(e.target.value)}>
                                    <option value="">Todos</option>
                                    {collaborators.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Faixa de Atraso</label>
                                <select className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterAging} onChange={e => setFilterAging(e.target.value)}>
                                    <option value="">Todos</option>
                                    <option value="A Vencer">A Vencer</option>
                                    <option value="1-30 dias">1-30 dias</option>
                                    <option value="31-60 dias">31-60 dias</option>
                                    <option value="61-90 dias">61-90 dias</option>
                                    <option value="90+ dias">90+ dias</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Vencimento De</label>
                                <input type="date" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterDueDateStart} onChange={e => setFilterDueDateStart(e.target.value)} />
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Vencimento Até</label>
                                <input type="date" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterDueDateEnd} onChange={e => setFilterDueDateEnd(e.target.value)} />
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Estado (UF)</label>
                                <select
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none bg-white"
                                    value={filterState}
                                    onChange={e => setFilterState(e.target.value)}
                                >
                                    <option value="">Todos os estados</option>
                                    {[...new Set(
                                        collectionTitles
                                            .map(t => clients.find(c => c.id === t.clientId)?.state)
                                            .filter((s): s is string => !!s && s.trim() !== '')
                                            .map(s => s.toUpperCase().trim())
                                    )].sort().map(uf => (
                                        <option key={uf} value={uf}>{uf}</option>
                                    ))}
                                </select>
                            </div>
                            <div className="flex items-end">
                                <button onClick={() => { setFilterClient(''); setFilterStatus(''); setFilterCollectionStatus(''); setFilterCollaborator(''); setFilterDueDateStart(''); setFilterDueDateEnd(''); setFilterAging(''); setFilterState(''); }} className="px-4 py-2.5 text-sm rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-600">
                                    Limpar Filtros
                                </button>
                            </div>
                        </div>
                    )}

                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                        <div className="overflow-x-auto">
                            <table className="min-w-full text-sm">
                                <thead className="bg-gray-50 border-b border-gray-200">
                                    <tr>
                                        <th className="px-4 py-3 text-left">
                                            <input type="checkbox" className="w-4 h-4 rounded text-moss-600 focus:ring-moss-500" checked={selectedIds.length === filteredTitles.length && filteredTitles.length > 0} onChange={toggleSelectAll} />
                                        </th>
                                        <th className="px-4 py-3 text-left font-semibold text-gray-600 cursor-pointer select-none hover:text-moss-700" onClick={() => handleSort('clientName')}>Cliente {sortIcon('clientName')}</th>
                                        <th className="px-4 py-3 text-left font-semibold text-gray-600 cursor-pointer select-none hover:text-moss-700" onClick={() => handleSort('documentNumber')}>Documento {sortIcon('documentNumber')}</th>
                                        <th className="px-4 py-3 text-left font-semibold text-gray-600 cursor-pointer select-none hover:text-moss-700" onClick={() => handleSort('dueDate')}>Vencimento {sortIcon('dueDate')}</th>
                                        <th className="px-4 py-3 text-right font-semibold text-gray-600 cursor-pointer select-none hover:text-moss-700" onClick={() => handleSort('originalValue')}>Valor {sortIcon('originalValue')}</th>
                                        <th className="px-4 py-3 text-right font-semibold text-gray-600 cursor-pointer select-none hover:text-moss-700" onClick={() => handleSort('currentBalance')}>Saldo {sortIcon('currentBalance')}</th>
                                        <th className="px-4 py-3 text-center font-semibold text-gray-600">Atraso</th>
                                        <th className="px-4 py-3 text-center font-semibold text-gray-600">Status</th>
                                        <th className="px-4 py-3 text-center font-semibold text-gray-600">Sit. Cobrança</th>
                                        <th className="px-4 py-3 text-left font-semibold text-gray-600">Responsável</th>
                                        <th className="px-4 py-3 text-center font-semibold text-gray-600">Ações</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100">
                                    {filteredTitles.length === 0 && (
                                        <tr><td colSpan={11} className="px-6 py-12 text-center text-gray-400">Nenhum título encontrado.</td></tr>
                                    )}
                                    {filteredTitles.map(t => {
                                        const days = agingDays(t.dueDate);
                                        const isOverdue = days > 0;
                                        const collab = collaborators.find(c => c.id === t.assignedCollaboratorId);
                                        return (
                                            <tr key={t.id} className={`hover:bg-gray-50 transition-colors ${isOverdue ? 'bg-red-50/30' : ''}`}>
                                                <td className="px-4 py-3">
                                                    <input type="checkbox" className="w-4 h-4 rounded text-moss-600 focus:ring-moss-500" checked={selectedIds.includes(t.id)} onChange={() => toggleSelect(t.id)} />
                                                </td>
                                                <td className="px-4 py-3 font-medium text-gray-800 max-w-[200px] truncate">
                                                    <button onClick={() => handleOpenClientPanel(t.clientId)} className="text-left hover:text-moss-700 hover:underline transition-colors flex items-center gap-1.5" title="Ver dados do cliente">
                                                        {t.clientName}{(() => { const cl = clients.find(c => c.id === t.clientId); return cl?.blocked ? <BlockedClientBanner client={cl} compact /> : null; })()}
                                                    </button>
                                                </td>
                                                <td className="px-4 py-3 text-gray-600">{t.documentNumber}</td>
                                                <td className="px-4 py-3 text-gray-600">{new Date(t.dueDate + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                                                <td className="px-4 py-3 text-right text-blue-700 font-medium">{formatCurrencyBRL(t.originalValue)}</td>
                                                <td className="px-4 py-3 text-right font-semibold text-blue-800">{formatCurrencyBRL(t.currentBalance)}</td>
                                                <td className="px-4 py-3 text-center">
                                                    {isOverdue ? (
                                                        <span className="text-red-600 font-semibold">{days}d</span>
                                                    ) : (
                                                        <span className="text-green-600 text-xs">Em dia</span>
                                                    )}
                                                </td>
                                                <td className="px-4 py-3 text-center">
                                                    <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-semibold ${t.status === 'ABERTO' ? 'bg-blue-100 text-blue-800' : t.status === 'PARCIAL' ? 'bg-yellow-100 text-yellow-800' : t.status === 'PROTESTADO' ? 'bg-red-100 text-red-800' : 'bg-gray-100 text-gray-700'}`}>
                                                        {statusLabel(t.status)}
                                                    </span>
                                                </td>
                                                <td className="px-4 py-3 text-center">
                                                    <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-semibold ${collectionStatusColor(t.collectionStatus)}`}>
                                                        {collectionStatusLabel(t.collectionStatus)}
                                                    </span>
                                                </td>
                                                <td className="px-4 py-3 text-gray-600 max-w-[140px] truncate">{collab?.name || '—'}</td>
                                                <td className="px-4 py-3 text-center">
                                                    <div className="flex justify-center items-center gap-2">
                                                        <AuditLogButton entityId={t.id} entityName={t.clientName || t.documentNumber} logs={auditLogs} />
                                                        <button onClick={() => handleOpenEdit(t)} className="text-blue-600 hover:text-blue-800 transition-colors" title="Editar Lançamento">
                                                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                                                        </button>
                                                        <button onClick={() => handleOpenClientPanel(t.clientId)} className="text-moss-600 hover:text-moss-800 transition-colors" title="Dados do Cliente">
                                                            <svg className="w-5 h-5 inline" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                                                        </button>
                                                        {GotalkAttendanceViewer && (
                                                        <button onClick={() => handleOpenClientPanel(t.clientId, t.assignedCollaboratorId, 'atendimentos')} className="text-green-600 hover:text-green-800 transition-colors" title="Conversas GoTalk do atendente">
                                                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                                                        </button>
                                                        )}
                                                        {canExcluir && (
                                                            <button onClick={() => handleDeleteTitle(t)} className="text-red-500 hover:text-red-700 transition-colors" title="Excluir Título">
                                                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                                            </button>
                                                        )}
                                                    </div>
                                                </td>
                                            </tr>
                                        );
                                    })}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            )}

            {activeMode === 'DASHBOARD' && (
                <div className="flex-1 bg-gray-50 p-6 overflow-auto">
                    <div className="flex items-center gap-4 mb-6 flex-wrap">
                        <div>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Período De</label>
                            <input type="date" className="rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={dashboardFilterPeriodStart} onChange={e => setDashboardFilterPeriodStart(e.target.value)} />
                        </div>
                        <div>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Período Até</label>
                            <input type="date" className="rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={dashboardFilterPeriodEnd} onChange={e => setDashboardFilterPeriodEnd(e.target.value)} />
                        </div>
                        <div>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Colaborador</label>
                            <select className="rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={dashboardFilterCollaborator} onChange={e => setDashboardFilterCollaborator(e.target.value)}>
                                <option value="">Todos</option>
                                {collaborators.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                            <div className="flex items-center gap-3 mb-3">
                                <div className="w-10 h-10 rounded-lg bg-red-100 flex items-center justify-center">
                                    <svg className="w-5 h-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
                                </div>
                                <div>
                                    <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Taxa Inadimplência</p>
                                    <p className="text-2xl font-bold text-red-700">{dashboardData.taxaInadimplencia.toFixed(1)}%</p>
                                </div>
                            </div>
                            <p className="text-xs text-gray-400">{dashboardData.overdueCount} de {dashboardData.totalTitles} títulos vencidos</p>
                        </div>

                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                            <div className="flex items-center gap-3 mb-3">
                                <div className="w-10 h-10 rounded-lg bg-green-100 flex items-center justify-center">
                                    <svg className="w-5 h-5 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                </div>
                                <div>
                                    <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Taxa Recuperação</p>
                                    <p className="text-2xl font-bold text-green-700">{dashboardData.taxaRecuperacao.toFixed(1)}%</p>
                                </div>
                            </div>
                            <p className="text-xs text-gray-400">Recuperado: {formatCurrencyBRL(dashboardData.recoveredValue)}</p>
                        </div>

                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                            <div className="flex items-center gap-3 mb-3">
                                <div className="w-10 h-10 rounded-lg bg-blue-100 flex items-center justify-center">
                                    <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                </div>
                                <div>
                                    <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">DSO (Dias)</p>
                                    <p className="text-2xl font-bold text-blue-700">{dashboardData.dso}</p>
                                </div>
                            </div>
                            <p className="text-xs text-gray-400">Prazo médio de recebimento</p>
                        </div>

                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-5">
                            <div className="flex items-center gap-3 mb-3">
                                <div className="w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                                    <svg className="w-5 h-5 text-purple-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                </div>
                                <div>
                                    <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Saldo Total</p>
                                    <p className="text-2xl font-bold text-purple-700">{formatCurrencyBRL(dashboardData.totalBalance)}</p>
                                </div>
                            </div>
                            <p className="text-xs text-gray-400">Vencido: {formatCurrencyBRL(dashboardData.overdueBalance)}</p>
                        </div>
                    </div>

                    {/* Cancel Requests Card */}
                    {cancelNotes.length > 0 && (
                        <div className="mb-6">
                            <button onClick={() => setDashboardCancelFilter(p => !p)}
                                className={`w-full text-left border rounded-xl px-5 py-4 flex items-center justify-between transition-all ${dashboardCancelFilter ? 'bg-orange-100 border-orange-400 ring-2 ring-orange-300' : 'bg-orange-50 border-orange-200 hover:border-orange-400 hover:bg-orange-100'}`}>
                                <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-lg bg-orange-200 flex items-center justify-center shrink-0">
                                        <svg className="w-5 h-5 text-orange-700" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636"/></svg>
                                    </div>
                                    <div>
                                        <p className="text-sm font-bold text-orange-800 uppercase tracking-wider">Solicitações de Cancelamento Pendentes</p>
                                        <p className="text-xs text-orange-600">Solicitadas pela equipe operacional — requerem ação da coordenação</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-3">
                                    <span className="text-3xl font-black text-orange-700">{cancelNotes.length}</span>
                                    <svg className={`w-5 h-5 text-orange-500 transition-transform ${dashboardCancelFilter ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7"/></svg>
                                </div>
                            </button>

                            {dashboardCancelFilter && (
                                <div className="mt-3 space-y-2 max-h-96 overflow-y-auto pr-1">
                                    {cancelNotes.map(n => {
                                        const relTitle = titles.find(t => t.id === n.titleId);
                                        const collab = collaborators.find(c => c.id === n.collaboratorId);
                                        return (
                                            <div key={n.id} className="bg-white border border-orange-200 rounded-xl p-4 shadow-sm">
                                                <div className="flex items-start justify-between gap-3">
                                                    <div className="flex-1 min-w-0">
                                                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                                                            <span className="text-sm font-bold text-gray-800">{relTitle?.clientName || n.clientId}</span>
                                                            {relTitle && <span className="text-xs text-gray-500 font-mono bg-gray-100 px-1.5 py-0.5 rounded">{relTitle.documentNumber}</span>}
                                                        </div>
                                                        <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs text-gray-600">
                                                            <div><span className="text-gray-400">Operador:</span> <span className="font-semibold">{collab?.name || n.collaboratorName}</span></div>
                                                            <div><span className="text-gray-400">Data Solic.:</span> <span>{n.cancelRequest!.requestDate ? new Date(n.cancelRequest!.requestDate + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</span></div>
                                                            <div><span className="text-gray-400">Contrato:</span> <span className="font-semibold text-orange-700">{n.cancelRequest!.admissionContract || '—'}</span></div>
                                                            {relTitle && <div><span className="text-gray-400">Saldo:</span> <span className="font-semibold text-red-700">{formatCurrencyBRL(Number(relTitle.currentBalance))}</span></div>}
                                                        </div>
                                                        {n.cancelRequest!.notes && <p className="mt-1.5 text-xs italic text-gray-500 border-t border-gray-100 pt-1.5">{n.cancelRequest!.notes}</p>}
                                                    </div>
                                                    <div className="flex flex-col items-end gap-2 shrink-0">
                                                        <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-orange-100 text-orange-800 border border-orange-200 uppercase tracking-wide">Pendente</span>
                                                        {canExcluir && (
                                                            <button onClick={() => handleDeleteCancelNote(n.id)} className="text-red-400 hover:text-red-600 text-[10px] font-bold px-2 py-0.5 rounded hover:bg-red-50 border border-red-200 hover:border-red-400 transition-colors">Excluir</button>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    )}

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                            <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                                <div className="w-2 h-6 rounded-full bg-amber-500"></div>
                                Carteira por Faixa de Atraso
                            </h3>
                            <div className="space-y-3">
                                {Object.entries(dashboardData.agingBuckets).map(([bucket, data]) => (
                                    <div key={bucket} className="flex items-center gap-3">
                                        <span className="text-xs text-gray-500 w-20 text-right">{bucket}</span>
                                        <div className="flex-1 bg-gray-100 rounded-full h-6 overflow-hidden">
                                            <div
                                                className={`h-full rounded-full transition-all ${bucket === 'A Vencer' ? 'bg-green-400' : bucket === '1-30 dias' ? 'bg-yellow-400' : bucket === '31-60 dias' ? 'bg-orange-400' : bucket === '61-90 dias' ? 'bg-red-400' : 'bg-red-600'}`}
                                                style={{ width: `${Math.max((data.balance / maxBucketBalance) * 100, 2)}%` }}
                                            ></div>
                                        </div>
                                        <span className="text-xs text-gray-600 w-24 text-right font-medium">{formatCurrencyBRL(data.balance)}</span>
                                        <span className="text-xs text-gray-400 w-10 text-right">{data.count}</span>
                                    </div>
                                ))}
                            </div>
                        </div>

                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-6">
                            <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-4 flex items-center gap-2">
                                <div className="w-2 h-6 rounded-full bg-moss-500"></div>
                                Performance por Colaborador
                            </h3>
                            <div className="space-y-3">
                                {Object.entries(dashboardData.collabPerformance).map(([id, data]) => (
                                    <div key={id} className="flex items-center gap-3">
                                        <span className="text-xs text-gray-600 w-32 truncate text-right font-medium">{data.name}</span>
                                        <div className="flex-1 bg-gray-100 rounded-full h-6 overflow-hidden">
                                            <div
                                                className="h-full rounded-full bg-moss-500 transition-all"
                                                style={{ width: `${Math.max((data.balance / maxCollabBalance) * 100, 2)}%` }}
                                            ></div>
                                        </div>
                                        <span className="text-xs text-gray-600 w-24 text-right font-medium">{formatCurrencyBRL(data.balance)}</span>
                                        <span className="text-xs text-gray-400 w-10 text-right">{data.assigned} tít.</span>
                                    </div>
                                ))}
                                {Object.keys(dashboardData.collabPerformance).length === 0 && (
                                    <p className="text-sm text-gray-400 text-center py-4">Nenhum título na carteira.</p>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {showAssignModal && (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md mx-4 animate-fade-in">
                        <div className="bg-amber-600 text-white px-6 py-4 rounded-t-2xl flex items-center gap-3">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z" /></svg>
                            <div>
                                <h3 className="font-bold text-lg">Atribuir Colaborador</h3>
                                <p className="text-amber-100 text-sm">{selectedIds.length} título(s) selecionado(s)</p>
                            </div>
                        </div>
                        <div className="p-6">
                            <p className="text-sm text-gray-600 mb-4">Os títulos selecionados terão a situação de cobrança alterada para <strong>"Cobrar"</strong> e serão atribuídos ao colaborador escolhido.</p>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Colaborador Responsável</label>
                            <select className="w-full rounded-lg border border-gray-300 px-4 py-3 text-sm focus:ring-2 focus:ring-amber-500 outline-none" value={assignCollaboratorId} onChange={e => setAssignCollaboratorId(e.target.value)}>
                                <option value="">Selecione...</option>
                                {collaborators.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                            </select>
                        </div>
                        <div className="bg-gray-50 px-6 py-4 flex justify-end gap-3 rounded-b-2xl">
                            <button onClick={() => { setShowAssignModal(false); setAssignCollaboratorId(''); }} className="px-5 py-2.5 text-sm rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-600">Cancelar</button>
                            <button onClick={handleBatchAssign} className="px-5 py-2.5 text-sm rounded-lg bg-amber-600 text-white hover:bg-amber-700 font-semibold">Confirmar Atribuição</button>
                        </div>
                    </div>
                </div>
            )}

            {showClientPanel && selectedClient && (
                <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40" onClick={() => setShowClientPanel(false)}>
                    <div className="bg-white rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-2xl mx-0 sm:mx-4 max-h-[90vh] overflow-hidden flex flex-col animate-fade-in" onClick={e => e.stopPropagation()}>
                        <div className="bg-moss-800 text-white px-6 py-4 rounded-t-2xl flex items-center justify-between shrink-0">
                            <div className="flex items-center gap-3">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                                <div>
                                    <h3 className="font-bold text-lg">{selectedClient.name || 'Cliente'}</h3>
                                    <p className="text-moss-200 text-sm">Dados do Cliente — Somente Leitura</p>
                                </div>
                            </div>
                            <button onClick={() => setShowClientPanel(false)} className="text-white/70 hover:text-white">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                            </button>
                        </div>
                        {/* Tabs */}
                        <div className="flex border-b border-gray-200 shrink-0 bg-white px-4">
                            <button onClick={() => setClientPanelTab('dados')} className={`px-4 py-3 text-sm font-semibold border-b-2 transition-colors ${clientPanelTab === 'dados' ? 'border-moss-600 text-moss-700' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                                Dados
                            </button>
                            {GotalkChatPanel && (
                            <button onClick={() => setClientPanelTab('whatsapp')} className={`px-4 py-3 text-sm font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${clientPanelTab === 'whatsapp' ? 'border-green-600 text-green-700' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                                <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                                WhatsApp
                            </button>
                            )}
                            {GotalkAttendanceViewer && (
                            <button onClick={() => setClientPanelTab('atendimentos')} className={`px-4 py-3 text-sm font-semibold border-b-2 transition-colors flex items-center gap-1.5 ${clientPanelTab === 'atendimentos' ? 'border-green-600 text-green-700' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                                Atendimentos
                            </button>
                            )}
                        </div>
                        <div className="flex-1 overflow-auto">
                        {GotalkChatPanel && clientPanelTab === 'whatsapp' ? (
                            <div className="h-[60vh]">
                                <GotalkChatPanel clientId={selectedClient.id} area="COBRANCA_COORD" operatorName={currentUser?.name} />
                            </div>
                        ) : GotalkAttendanceViewer && clientPanelTab === 'atendimentos' ? (
                            <div className="h-[60vh]">
                                <GotalkAttendanceViewer clientId={selectedClient.id} collaboratorId={selectedCollaboratorId ?? undefined} title="Atendimentos GoTalk — Cobrança Coordenadores" />
                            </div>
                        ) : (
                        <div className="p-6 space-y-6">
                            {selectedClient.blocked && <BlockedClientBanner client={selectedClient} />}
                            <div className="bg-gray-50 rounded-xl p-5 border border-gray-200">
                                <h4 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-2">
                                    <div className="w-2 h-5 rounded-full bg-moss-500"></div>
                                    Dados Cadastrais
                                </h4>
                                <div className="grid grid-cols-2 gap-3 text-sm">
                                    <div><span className="text-gray-500">Nome/Razão:</span> <span className="font-medium text-gray-800">{selectedClient.name || '—'}</span></div>
                                    <div><span className="text-gray-500">CPF/CNPJ:</span> <span className="font-medium text-gray-800">{selectedClient.document || '—'}</span></div>
                                    <div><span className="text-gray-500">Telefone:</span> <span className="font-medium text-gray-800">{selectedClient.phone || '—'}</span></div>
                                    <div><span className="text-gray-500">E-mail:</span> <span className="font-medium text-gray-800">{selectedClient.email || '—'}</span></div>
                                    <div className="col-span-2"><span className="text-gray-500">Endereço:</span> <span className="font-medium text-gray-800">{selectedClient.address || '—'}, {selectedClient.city || ''} - {selectedClient.state || ''}</span></div>
                                </div>
                            </div>

                            <div className="bg-gray-50 rounded-xl p-5 border border-gray-200">
                                <h4 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-2">
                                    <div className="w-2 h-5 rounded-full bg-blue-500"></div>
                                    Títulos do Cliente ({collectionTitles.filter(t => t.clientId === selectedClientId).length})
                                </h4>
                                <div className="space-y-2 max-h-48 overflow-auto">
                                    {collectionTitles.filter(t => t.clientId === selectedClientId).map(t => (
                                        <div key={t.id} className="flex items-center justify-between bg-white rounded-lg px-4 py-2.5 border border-gray-100 text-sm">
                                            <span className="text-gray-700">{t.documentNumber} — {t.description}</span>
                                            <div className="flex items-center gap-3">
                                                <span className="text-blue-700 font-medium">{formatCurrencyBRL(t.currentBalance)}</span>
                                                <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${collectionStatusColor(t.collectionStatus)}`}>{collectionStatusLabel(t.collectionStatus)}</span>
                                            </div>
                                        </div>
                                    ))}
                                    {collectionTitles.filter(t => t.clientId === selectedClientId).length === 0 && (
                                        <p className="text-sm text-gray-400 text-center py-3">Nenhum título.</p>
                                    )}
                                </div>
                            </div>

                            {clientAdmissions.length > 0 && (
                                <div className="bg-gray-50 rounded-xl p-5 border border-gray-200">
                                    <h4 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-2">
                                        <div className="w-2 h-5 rounded-full bg-purple-500"></div>
                                        Admissões / Contratos ({clientAdmissions.length})
                                    </h4>
                                    <div className="space-y-3 max-h-64 overflow-auto">
                                        {clientAdmissions.map(adm => (
                                            <div key={adm.id} className="bg-white rounded-lg p-4 border border-gray-100">
                                                <div className="flex items-center justify-between mb-2">
                                                    <span className="font-semibold text-sm text-gray-800">Contrato: {adm.contractNumber || '—'}</span>
                                                    <div className="flex items-center gap-2">
                                                        <button onClick={() => handleOpenAdmissionModal(adm)} className="text-xs text-moss-600 hover:text-moss-800 bg-moss-50 hover:bg-moss-100 border border-moss-200 px-2.5 py-1 rounded-full font-semibold flex items-center gap-1 transition-colors">
                                                            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                                                            Ver Ficha
                                                        </button>
                                                        <span className={`text-xs px-2.5 py-1 rounded-full font-semibold ${adm.status === 'APROVADA' || adm.status === 'FINALIZADA' || adm.status === 'CONCLUIDO' ? 'bg-green-100 text-green-800' : adm.status === 'REPROVADA' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}`}>{adm.status}</span>
                                                    </div>
                                                </div>
                                                <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                                                    <div>Data: {adm.date ? new Date(adm.date + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</div>
                                                    <div>Parcelas: {adm.paidInstallments || 0}/{adm.totalInstallments || 0}</div>
                                                    <div>Valor Financiado: {adm.financedAmount || '—'}</div>
                                                    <div>Dia Vencimento: {adm.dueDay || '—'}</div>
                                                </div>
                                                {adm.attachments && adm.attachments.length > 0 && (
                                                    <div className="mt-3 pt-3 border-t border-gray-100">
                                                        <p className="text-xs font-semibold text-gray-500 mb-1">Anexos ({adm.attachments.length}):</p>
                                                        <div className="flex flex-wrap gap-2">
                                                            {adm.attachments.map((att: AdmissionAttachment) => (
                                                                <a key={att.id} href={att.fileData} download={att.fileName} className="text-xs text-moss-600 hover:text-moss-800 bg-moss-50 px-2 py-1 rounded flex items-center gap-1">
                                                                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                                                                    {att.title || att.fileName}
                                                                </a>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                                {adm.recalcScenarios && adm.recalcScenarios.length > 0 && (
                                                    <div className="mt-3 pt-3 border-t border-gray-100">
                                                        <p className="text-xs font-semibold text-gray-500 mb-1">Cenários de Recálculo ({adm.recalcScenarios.length}):</p>
                                                        <div className="space-y-1">
                                                            {adm.recalcScenarios.map(sc => (
                                                                <div key={sc.id} className="text-xs text-gray-600 bg-purple-50 rounded px-2 py-1">
                                                                    {sc.label}: Dívida {sc.originalDebt} → {sc.newDebt} (Economia: {sc.savings})
                                                                </div>
                                                            ))}
                                                        </div>
                                                    </div>
                                                )}
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            )}
                        </div>
                        )}
                        </div>
                    </div>
                </div>
            )}
        </div>

        {editingTitle && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">
                <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl mx-4 animate-fade-in flex flex-col max-h-[90vh]">
                    <div className="bg-blue-700 text-white px-6 py-4 rounded-t-2xl flex items-center justify-between">
                        <div className="flex items-center gap-3">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                            <div>
                                <h3 className="font-bold text-lg">Editar Lançamento</h3>
                                <p className="text-blue-100 text-sm">{editingTitle.clientName} — {editingTitle.documentNumber}</p>
                            </div>
                        </div>
                        <button onClick={() => { setEditingTitle(null); setEditForm({}); }} className="text-white/70 hover:text-white">
                            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>
                    <div className="overflow-y-auto p-6 space-y-5">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Nº Documento</label>
                                <input
                                    type="text"
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                    value={editForm.documentNumber ?? ''}
                                    onChange={e => setEditForm(f => ({ ...f, documentNumber: e.target.value }))}
                                />
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Vencimento <span className="text-red-500">*</span></label>
                                <input
                                    type="date"
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                    value={editForm.dueDate ?? ''}
                                    onChange={e => setEditForm(f => ({ ...f, dueDate: e.target.value }))}
                                />
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Previsão de Recebimento</label>
                                <input
                                    type="date"
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                    value={editForm.expectedDate ?? ''}
                                    onChange={e => setEditForm(f => ({ ...f, expectedDate: e.target.value }))}
                                />
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Status</label>
                                <select
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                    value={editForm.status ?? ''}
                                    onChange={e => setEditForm(f => ({ ...f, status: e.target.value as TitleStatus }))}
                                >
                                    <option value="ABERTO">Em Aberto</option>
                                    <option value="PARCIAL">Parcial</option>
                                    <option value="PROTESTADO">Protestado</option>
                                    <option value="PROVISAO">Provisão</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Situação de Cobrança</label>
                                <select
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                    value={editForm.collectionStatus ?? 'EM_DIA'}
                                    onChange={e => setEditForm(f => ({ ...f, collectionStatus: e.target.value as 'EM_DIA' | 'COBRAR' | 'NAO_COBRAR' }))}
                                >
                                    <option value="EM_DIA">Em Dia</option>
                                    <option value="COBRAR">Cobrar</option>
                                    <option value="NAO_COBRAR">Não Cobrar</option>
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Responsável</label>
                                <select
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                    value={editForm.assignedCollaboratorId ?? ''}
                                    onChange={e => setEditForm(f => ({ ...f, assignedCollaboratorId: e.target.value }))}
                                >
                                    <option value="">Sem atribuição</option>
                                    {collaborators.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                </select>
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Juros (R$)</label>
                                <input
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                    value={editForm.interestValue ?? 0}
                                    onChange={e => setEditForm(f => ({ ...f, interestValue: parseFloat(e.target.value) || 0 }))}
                                />
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Multa (R$)</label>
                                <input
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                    value={editForm.penaltyValue ?? 0}
                                    onChange={e => setEditForm(f => ({ ...f, penaltyValue: parseFloat(e.target.value) || 0 }))}
                                />
                            </div>
                            <div>
                                <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Desconto (R$)</label>
                                <input
                                    type="number"
                                    min="0"
                                    step="0.01"
                                    className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none"
                                    value={editForm.discountValue ?? 0}
                                    onChange={e => setEditForm(f => ({ ...f, discountValue: parseFloat(e.target.value) || 0 }))}
                                />
                            </div>
                        </div>
                        <div>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Histórico / Descrição</label>
                            <textarea
                                rows={3}
                                className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-blue-500 outline-none resize-none"
                                value={editForm.description ?? ''}
                                onChange={e => setEditForm(f => ({ ...f, description: e.target.value }))}
                            />
                        </div>
                        <div className="bg-blue-50 rounded-lg px-4 py-3 border border-blue-100 text-xs text-blue-700">
                            <strong>Valor original:</strong> {formatCurrencyBRL(editingTitle.originalValue)} &nbsp;|&nbsp;
                            <strong>Saldo:</strong> {formatCurrencyBRL(editingTitle.currentBalance)} &nbsp;|&nbsp;
                            <strong>Emissão:</strong> {new Date(editingTitle.issueDate + 'T00:00:00').toLocaleDateString('pt-BR')}
                        </div>
                    </div>
                    <div className="bg-gray-50 px-6 py-4 flex justify-end gap-3 rounded-b-2xl border-t border-gray-200">
                        <button onClick={() => { setEditingTitle(null); setEditForm({}); }} className="px-5 py-2.5 text-sm rounded-lg border border-gray-300 bg-white hover:bg-gray-50 text-gray-600" disabled={isSavingEdit}>Cancelar</button>
                        <button onClick={handleSaveEdit} disabled={isSavingEdit} className="px-5 py-2.5 text-sm rounded-lg bg-blue-700 text-white hover:bg-blue-800 font-semibold disabled:opacity-60 flex items-center gap-2">
                            {isSavingEdit ? (
                                <><svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg>Salvando...</>
                            ) : (
                                <>Salvar Alterações</>
                            )}
                        </button>
                    </div>
                </div>
            </div>
        )}

        {viewingAdmission && (() => {
            const admClient = clients.find(c => c.id === viewingAdmission.clientId);
            const admTitular = viewingAdmission.titularClientId ? clients.find(c => c.id === viewingAdmission.titularClientId) : undefined;
            const admBank = banks.find(b => b.id === viewingAdmission.bankId);
            const admModality = modalities.find(m => m.id === viewingAdmission.modalityId);
            const admCollab = collaborators.find(c => c.id === viewingAdmission.collaboratorId);
            const admSeries = series.find(s => s.id === viewingAdmission.seriesId);
            const admUnit = units.find(u => u.id === viewingAdmission.unitId);
            const unitName = admUnit?.nomeFantasia || admUnit?.razaoSocial || admUnit?.companyName || admUnit?.name || undefined;
            const seriesSigla = admSeries?.sigla || undefined;
            return (
                <AdmissionViewerModal
                    admission={viewingAdmission}
                    clientName={admClient?.name || viewingAdmission.clientName || viewingAdmission.clientId}
                    onClose={() => setViewingAdmission(null)}
                    client={admClient}
                    titular={admTitular}
                    bank={admBank}
                    modality={admModality ? { type: admModality.type, description: admModality.description } : undefined}
                    collaboratorName={admCollab?.name}
                    seriesSigla={seriesSigla}
                    unitName={unitName}
                />
            );
        })()}

        <ConfirmDeleteModal
            isOpen={!!deleteModal}
            title={deleteModal?.title ?? ''}
            message={deleteModal?.message ?? ''}
            isLoading={deleteLoading}
            onConfirm={handleDeleteConfirmed}
            onCancel={() => { if (!deleteLoading) setDeleteModal(null); }}
        />
        </>
    );
};

export default CollectionCoordinatorPanel;

import { Admission, Client, PortalConfig } from '../types';

export function getAdmissionVariables(data: Admission, config: PortalConfig): Record<string, string> {
  const client = config.clients.find(c => c.id === data.clientId);
  const bank = config.banks.find(b => b.id === data.bankId);
  const collaborator = config.collaborators.find(c => c.id === data.collaboratorId);
  const series = config.series?.find(s => s.id === data.seriesId);
  const modality = config.modalities?.find(m => m.id === data.modalityId);
  const unit = config.units?.find(u => u.id === data.unitId);

  return {
    id: data.id || '',
    date: data.date ? new Date(data.date).toLocaleDateString('pt-BR') : '',
    clientName: data.clientName || '',
    clientDocument: client?.document || '',
    clientPhone: client?.phone || '',
    clientEmail: client?.email || '',
    clientAddress: client?.address || '',
    clientCity: client?.city || '',
    clientState: client?.state || '',
    clientCep: client?.cep || '',
    clientBirthDate: client?.birthDate || '',
    clientRg: client?.rg || '',
    clientDistrict: client?.district || '',
    clientNumber: client?.number || '',
    clientComplement: client?.complement || '',
    bankName: bank?.name || '',
    collaboratorName: collaborator?.name || '',
    seriesName: series?.description || '',
    seriesSigla: series?.sigla || '',
    modalityName: modality?.description || '',
    modalityType: modality?.type || '',
    contractNumber: data.contractNumber || '',
    totalInstallments: data.totalInstallments || '',
    paidInstallments: data.paidInstallments || '',
    overdueInstallments: data.overdueInstallments || '',
    financedAmount: data.financedAmount || '',
    installmentValue: data.installmentValue || '',
    dueDay: data.dueDay || '',
    paymentType: data.paymentType || '',
    indicationType: data.indicationType || '',
    originType: data.originType || '',
    status: data.status || '',
    vehicleBrand: data.vehicleBrand || '',
    vehicleModel: data.vehicleModel || '',
    vehicleColor: data.vehicleColor || '',
    vehicleYear: data.vehicleYear || '',
    vehiclePlate: data.vehiclePlate || '',
    vehicleChassis: data.vehicleChassis || '',
    vehicleRenavam: data.vehicleRenavam || '',
    firstInstallmentDueDate: data.firstInstallmentDueDate || '',
    parcela1: data.parcela1 || '',
    parcela2: data.parcela2 || '',
    taxaCobranca: data.taxaCobranca || '',
    otherInfo1: data.otherInfo1 || '',
    otherInfo2: data.otherInfo2 || '',
    unitName: unit?.nomeFantasia || unit?.razaoSocial || '',
    unitCnpj: unit?.cnpj || '',
    unitEndereco: unit?.endereco || '',
    unitTelefone: unit?.telefone || '',
    unitCidade: unit?.cidade || '',
    unitEstado: unit?.estado || '',
  };
}

export function replaceTemplateVariables(
  html: string,
  data: Admission,
  clientObj: Client | null,
  config: PortalConfig
): string {
  const bank = config.banks.find(b => b.id === data.bankId);
  const collaborator = config.collaborators.find(c => c.id === data.collaboratorId);
  const series = config.series?.find(s => s.id === data.seriesId);
  const modality = config.modalities?.find(m => m.id === data.modalityId);
  const unit = config.units?.find(u => u.id === data.unitId) || config.companyInfo;
  const scenario = data.recalcScenarios?.[0];

  const parcelasAPagar = data.totalInstallments && data.paidInstallments
    ? String(Number(data.totalInstallments) - Number(data.paidInstallments))
    : '';

  const vars: Record<string, string> = {
    '{{cliente.id}}': clientObj?.id || '',
    '{{cliente.nome}}': clientObj?.name || data.clientName || '',
    '{{cliente.tipo}}': clientObj?.type || '',
    '{{cliente.documento}}': clientObj?.document || '',
    '{{cliente.rg}}': clientObj?.rg || '',
    '{{cliente.email}}': clientObj?.email || '',
    '{{cliente.telefone}}': clientObj?.phone || '',
    '{{cliente.telefone2}}': clientObj?.phone2 || '',
    '{{cliente.whatsapp}}': clientObj?.isWhatsapp ? 'Sim' : 'Não',
    '{{cliente.profissao}}': clientObj?.profession || '',
    '{{cliente.estado_civil}}': clientObj?.maritalStatus || '',
    '{{cliente.data_nascimento}}': clientObj?.birthDate ? new Date(clientObj.birthDate).toLocaleDateString('pt-BR') : '',
    '{{cliente.cep}}': clientObj?.cep || '',
    '{{cliente.endereco}}': clientObj?.address || '',
    '{{cliente.numero}}': clientObj?.number || '',
    '{{cliente.complemento}}': clientObj?.complement || '',
    '{{cliente.bairro}}': clientObj?.district || '',
    '{{cliente.cidade}}': clientObj?.city || '',
    '{{cliente.uf}}': clientObj?.state || '',
    '{{cliente.anotacoes}}': clientObj?.notes || '',
    '{{banco.id}}': bank?.id || '',
    '{{banco.nome}}': bank?.name || '',
    '{{colaborador.id}}': collaborator?.id || '',
    '{{colaborador.nome}}': collaborator?.name || '',
    '{{empresa.razao_social}}': unit?.razaoSocial || '',
    '{{empresa.cnpj}}': unit?.cnpj || '',
    '{{empresa.telefone}}': unit?.telefone || '',
    '{{empresa.email}}': unit?.email || '',
    '{{empresa.cep}}': unit?.cep || '',
    '{{empresa.endereco}}': unit?.endereco || '',
    '{{empresa.numero}}': unit?.numero || '',
    '{{empresa.complemento}}': unit?.complemento || '',
    '{{empresa.bairro}}': unit?.bairro || '',
    '{{empresa.cidade}}': unit?.cidade || '',
    '{{empresa.uf}}': unit?.estado || '',
    '{{empresa.taxa_minima}}': unit?.taxaMinima || '',
    '{{admissao.id}}': data.id || '',
    '{{admissao.data}}': data.date ? new Date(data.date).toLocaleDateString('pt-BR') : '',
    '{{admissao.cliente}}': data.clientName || '',
    '{{admissao.contrato}}': data.contractNumber || '',
    '{{admissao.total_parcelas}}': data.totalInstallments || '',
    '{{admissao.parcelas_pagas}}': data.paidInstallments || '',
    '{{admissao.parcelas_atraso}}': data.overdueInstallments || '',
    '{{admissao.parcelas_a_pagar}}': parcelasAPagar,
    '{{admissao.valor_financiado}}': data.financedAmount || '',
    '{{admissao.valor_parcela}}': data.installmentValue || '',
    '{{admissao.dia_vencimento}}': data.dueDay || '',
    '{{admissao.forma_pagamento}}': data.paymentType || '',
    '{{admissao.tipo_indicacao}}': data.indicationType || '',
    '{{admissao.tipo_origem}}': data.originType || '',
    '{{admissao.status}}': data.status || '',
    '{{admissao.taxa_administrativa}}': data.parcela1 || '',
    '{{admissao.parcela1}}': data.parcela1 || '',
    '{{admissao.parcela_inicial}}': data.parcela2 || '',
    '{{admissao.parcela2}}': data.parcela2 || '',
    '{{admissao.valor_boletos}}': data.taxaCobranca || '',
    '{{admissao.taxa_cobranca}}': data.taxaCobranca || '',
    '{{admissao.info1}}': data.otherInfo1 || '',
    '{{admissao.info2}}': data.otherInfo2 || '',
    '{{admissao.marca_veiculo}}': data.vehicleBrand || '',
    '{{admissao.modelo_veiculo}}': data.vehicleModel || '',
    '{{admissao.cor_veiculo}}': data.vehicleColor || '',
    '{{admissao.ano_veiculo}}': data.vehicleYear || '',
    '{{admissao.placa}}': data.vehiclePlate || '',
    '{{admissao.chassi}}': data.vehicleChassis || '',
    '{{admissao.renavam}}': data.vehicleRenavam || '',
    '{{admissao.primeiro_vencimento}}': data.firstInstallmentDueDate || '',
    '{{modalidade.id}}': modality?.id || '',
    '{{modalidade.tipo}}': modality?.type || '',
    '{{modalidade.descricao}}': modality?.description || '',
    '{{recalculo.parcelas_a_pagar}}': scenario?.installmentsToPay || parcelasAPagar,
    '{{recalculo.divida_original}}': scenario?.originalDebt || '',
    '{{recalculo.parcela}}': scenario?.installmentValue || '',
    '{{recalculo.divida}}': scenario?.newDebt || '',
    '{{recalculo.economia}}': scenario?.savings || '',
    '{{recalculo.dia_vencimento}}': scenario?.dueDay || '',
  };

  let result = html;
  for (const [key, val] of Object.entries(vars)) {
    result = result.split(key).join(val);
  }
  return result;
}

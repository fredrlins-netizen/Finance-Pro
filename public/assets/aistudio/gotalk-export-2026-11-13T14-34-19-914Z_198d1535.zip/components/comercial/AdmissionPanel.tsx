/**
 * TÍTULO: PAINEL DE ADMISSÃO (GESTÃO DE PROCESSOS E LEADS)
 * 
 * FuncionalIDADES ATUALIZADAS:
 * - Status do Processo: Dropdown com Pendente, Negociação, Aprovada, Análise Cliente, Reprovada, Auditada, Finalizada.
 * - Filtros Avançados: Adicionado filtro por Status na listagem (DataGrid).
 * - Automação pós-impressão: Status muda para NEGOCIAÇÃO automaticamente ao imprimir se estiver Pendente.
 * - Anexos: Campo para upload de arquivos com título digitável.
 * - Outras Informações: Campos Taxa Administrativa, Parcela 1 e Valor Boletos organizados antes das anotações.
 */

import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { sanitizeHtml } from '../../utils/sanitizeHtml';
import PizZip from 'pizzip';
import Docxtemplater from 'docxtemplater';
import { saveAs } from 'file-saver';
import { PortalConfig, Client, Bank, Collaborator, User, UserRole, Series, Modality, Admission, RecalcScenario, CompanyInfo, AdmissionStatus, FormTemplate, AuditRound } from '../../types';
import { useFormTemplates } from '../../hooks/useFormTemplates';
import Button from '../ui/Button';
import Input from '../ui/Input';
import { FixedSizeList } from 'react-window';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { checkDependencies, formatDependencyMessage } from '../../utils/dependencyCheck';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';
import { api, apiRequest } from '../../services/apiService';
import ErrorBoundary from '../shared/ErrorBoundary';
import PaginationBar from '../ui/PaginationBar';
import AdmissionPrintView from './AdmissionPrintView';
import AdmissionFormView from './AdmissionFormView';
import AdmissionRow from './AdmissionRow';
import { getAdmissionVariables, replaceTemplateVariables } from '../../utils/admissionVariables';

interface AdmissionRowItemData {
    paginatedAdmissions: Admission[];
    series: PortalConfig['series'];
    units: PortalConfig['units'];
    auditLogs: PortalConfig['auditLogs'];
    clientsWithGoTalk: Set<string>;
    onEdit: (adm: Admission) => void;
    onPreview: (adm: Admission) => void;
    onDelete: (adm: Admission) => void;
    canEdit: boolean;
    canDelete: boolean;
    canView: boolean;
}

// --- MAIN COMPONENT ---

type ViewMode = 'LIST' | 'FORM' | 'PREVIEW';

interface AdmissionPanelProps {
  config: PortalConfig;
  currentUser: User | null;
  onClose: () => void;
  initialData?: any;
  onRequestExternalAction?: (entity: 'CLIENT' | 'BANK' | 'COLLAB', currentFormData: any, idToEdit?: string, clientRole?: 'responsible' | 'holder') => void;
  onRefresh?: () => void;
}

const DEFAULT_RECALC_SCENARIOS = [
  { id: 'sc-1', label: 'Recálculo %', installmentsToPay: '', originalDebt: '', installmentValue: '', newDebt: '', savings: '', dueDay: '' },
  { id: 'sc-2', label: 'Recálculo %', installmentsToPay: '', originalDebt: '', installmentValue: '', newDebt: '', savings: '', dueDay: '' },
  { id: 'sc-3', label: 'Recálculo %', installmentsToPay: '', originalDebt: '', installmentValue: '', newDebt: '', savings: '', dueDay: '' },
];

const AdmissionPanel: React.FC<AdmissionPanelProps> = ({ 
    config, 
    currentUser,
    onClose, 
    initialData,
    onRequestExternalAction,
    onRefresh,
}) => {
  const { validarPermissao, temPermissao, addToast, isLoggedAdmin } = useSecurity();
  const canIncluir = temPermissao('com_admissao:INCLUIR');
  const canAlterar = temPermissao('com_admissao:ALTERAR');
  const canExcluir = temPermissao('com_admissao:EXCLUIR');
  const canVisualizar = temPermissao('com_admissao:VISUALIZAR') || temPermissao('com_admissao:ALTERAR') || temPermissao('com_admissao:IMPRIMIR');
  const { logTransaction } = useAudit();
  const { data: apiAdmissions, loading: apiLoading, error: apiError, create: apiCreate, update: apiUpdate, remove: apiRemove, refresh: apiRefresh, clearError: apiClearError, search: serverSearch, setFilters: serverSetFilters, currentPage: serverPage, totalPages: serverTotalPages, total: serverTotal, goToPage: serverGoToPage } = useEntityCRUD<Admission>('admissions', { pageSize: 50 });

  useEffect(() => {
      if (apiError) {
          addToast('error', 'Erro', apiError);
          apiClearError();
      }
  }, [apiError]);

  const admissionsList = useMemo(() => {
      if (!apiLoading) return apiAdmissions;
      return config.admissions || [];
  }, [apiAdmissions, apiLoading, config.admissions]);

  const [viewMode, setViewMode] = useState<ViewMode>('LIST');
  const [showExportModal, setShowExportModal] = useState(false);
  const [isExporting, setIsExporting] = useState(false);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>('');
  const [showTemplateSelector, setShowTemplateSelector] = useState(false);
  const DEFAULT_SERIES_KEY = 'invicta_default_series';
  const docxInputRef = useRef<HTMLInputElement>(null);

  // --- KEYBOARD NAVIGATION ---
  const handleKeyDown = (e: React.KeyboardEvent<HTMLElement>) => {
    const target = e.target as HTMLElement;
    const isRadioLabel = target.getAttribute('role') === 'radio';

    if (e.key === ' ' && isRadioLabel) {
        e.preventDefault(); 
        const radioInput = target.querySelector('input[type="radio"]') as HTMLInputElement;
        if (radioInput) {
            radioInput.click();
        }
        return;
    }

    if (e.key === 'Enter') {
        e.preventDefault();
        const container = target.closest('[data-form-container="true"]');
        if (!container) return;

        let focusableElements = Array.from(container.querySelectorAll<HTMLElement>(
            'input:not([disabled]):not([readonly]), select:not([disabled]), textarea:not([disabled]), [role="radio"]'
        )).filter(el => el.tabIndex !== -1);

        focusableElements.sort((a, b) => {
            const aScenarioIdx = a.getAttribute('data-scenario-idx');
            const bScenarioIdx = b.getAttribute('data-scenario-idx');
            if (aScenarioIdx !== null && bScenarioIdx !== null) {
                const aIdx = parseInt(aScenarioIdx);
                const bIdx = parseInt(bScenarioIdx);
                const aFieldIdx = parseInt(a.getAttribute('data-field-idx') || '0');
                const bFieldIdx = parseInt(b.getAttribute('data-field-idx') || '0');
                if (aIdx !== bIdx) return aIdx - bIdx;
                return aFieldIdx - bFieldIdx;
            }
            return a.compareDocumentPosition(b) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
        });
        
        const index = focusableElements.indexOf(target);
        if (index > -1 && index < focusableElements.length - 1) {
            focusableElements[index + 1].focus();
        }
    }
  };

  // --- MASK HELPERS ---
  const formatCurrencyBRL = (value: any) => {
    if (value === undefined || value === null || value === "") return "";
    let valStr = typeof value === 'number' ? value.toFixed(2) : String(value);
    const cleanValue = valStr.replace(/\D/g, "");
    if (!cleanValue) return "";
    const numberValue = parseFloat(cleanValue) / 100;
    return new Intl.NumberFormat('pt-BR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(numberValue);
  };

  const parseCurrencyBRL = (value: string): number => {
    if (!value) return 0;
    const clean = value.replace(/\./g, '').replace(',', '.');
    return parseFloat(clean) || 0;
  };

  const formatAdmissionData = (data: any) => {
    return {
        ...data,
        financedAmount: formatCurrencyBRL(data.financedAmount),
        installmentValue: formatCurrencyBRL(data.installmentValue),
        parcela1: formatCurrencyBRL(data.parcela1),
        parcela2: formatCurrencyBRL(data.parcela2),
        taxaCobranca: formatCurrencyBRL(data.taxaCobranca),
        desconto: formatCurrencyBRL(data.desconto),
        acrescimo: formatCurrencyBRL(data.acrescimo),
        recalcScenarios: (data.recalcScenarios || []).map((s: any) => ({
            ...s,
            originalDebt: formatCurrencyBRL(s.originalDebt),
            installmentValue: formatCurrencyBRL(s.installmentValue),
            newDebt: formatCurrencyBRL(s.newDebt),
            savings: formatCurrencyBRL(s.savings)
        })),
        attachments: data.attachments || []
    };
  };

  // --- STATE & EFFECTS ---
  const [clientsWithGoTalk, setClientsWithGoTalk] = useState<Set<string>>(new Set());

  useEffect(() => {
    api.get('/gotalk/attendances/clients-with-history').then(r => {
      if (r?.clientIds) setClientsWithGoTalk(new Set(r.clientIds));
    }).catch(() => {});
  }, []);

  const [searchTerm, setSearchTerm] = useState('');
  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    searchDebounceRef.current = setTimeout(() => { serverSearch(searchTerm); }, 300);
    return () => { if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current); };
  }, [searchTerm]);
  const [showFilters, setShowFilters] = useState(false);
  const [filterBank, setFilterBank] = useState('');
  const [filterCollaborator, setFilterCollaborator] = useState('');
  const [filterClientField, setFilterClientField] = useState('');
  const [filterStatus, setFilterStatus] = useState<string>('');
  const [filterDateStart, setFilterDateStart] = useState('');
  const [filterDateEnd, setFilterDateEnd] = useState('');
  const colFilterDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (colFilterDebounceRef.current) clearTimeout(colFilterDebounceRef.current);
    colFilterDebounceRef.current = setTimeout(() => {
      const filters: Record<string, string | number> = {};
      if (filterBank) filters.filter_bank_id = filterBank;
      if (filterCollaborator) filters.filter_collaborator_id = filterCollaborator;
      if (filterStatus) filters.filter_status = filterStatus;
      serverSetFilters(filters);
    }, 300);
    return () => { if (colFilterDebounceRef.current) clearTimeout(colFilterDebounceRef.current); };
  }, [filterBank, filterCollaborator, filterStatus]);
  const [sortConfig, setSortConfig] = useState<{ key: keyof Admission | 'clientName' | 'collaboratorName', direction: 'asc' | 'desc' | null }>({ key: 'date', direction: 'desc' });

  const [formData, setFormData] = useState<Admission>({
      id: '', date: new Date().toISOString(), clientId: '', clientName: '', bankId: '', collaboratorId: '', seriesId: localStorage.getItem(DEFAULT_SERIES_KEY) || '', modalityId: '', indicationType: 'INDICAÇÃO', originType: '', unitId: currentUser?.currentUnitId || '', tipoCliente: 'RESPONSÁVEL', contractNumber: '', totalInstallments: '', paidInstallments: '', overdueInstallments: '', financedAmount: '', installmentValue: '', dueDay: '', paymentType: '', 
      status: 'PENDENTE',
      vehicleBrand: '', vehicleModel: '', vehicleColor: '', vehicleYear: '', vehiclePlate: '', vehicleChassis: '', vehicleRenavam: '',
      recalcScenarios: [
          { id: 'sc-1', label: 'Recálculo %', installmentsToPay: '', originalDebt: '', installmentValue: '', newDebt: '', savings: '', dueDay: '' },
          { id: 'sc-2', label: 'Recálculo %', installmentsToPay: '', originalDebt: '', installmentValue: '', newDebt: '', savings: '', dueDay: '' },
          { id: 'sc-3', label: 'Recálculo %', installmentsToPay: '', originalDebt: '', installmentValue: '', newDebt: '', savings: '', dueDay: '' }
      ], 
      attachments: [],
      parcela1: '',
      parcela2: '',
      taxaCobranca: '',
      desconto: '',
      acrescimo: '',
      otherInfo1: '', otherInfo2: ''
  });

  const [selectedClient, setSelectedClient] = useState<Client | null>(null);
  const [selectedTitular, setSelectedTitular] = useState<Client | null>(null);
  const [bucketAttachmentCount, setBucketAttachmentCount] = useState(0);
  const [clientProfileError, setClientProfileError] = useState('');
  const [clientProfilesLoading, setClientProfilesLoading] = useState(false);
  const [profileRetry, setProfileRetry] = useState(0);
  const [admissionDetails, setAdmissionDetails] = useState<{ id: string; error?: string } | null>(null);
  const isAdmissionOpen = viewMode !== 'LIST';
  // Preserve main's fresh persisted FKs after imports, without restoring its
  // dependency on a global profile list. A subflow's draft FKs take precedence.
  useEffect(() => {
    if (!isAdmissionOpen || !formData.id) return;
    const id = formData.id;
    const controller = new AbortController();
    setAdmissionDetails(null);
    apiRequest<{ admission: Admission }>('/api/admission-clients', {
      params: { admissionId: id }, signal: controller.signal, retries: 1,
    }).then(({ admission: data }) => {
      if (controller.signal.aborted) return;
      if (data?.id !== id) throw new Error('Admissão indisponível');
      if (!initialData || initialData.id !== id) {
        setFormData(previous => previous.id === id ? {
          ...previous, clientId: data.clientId || '',
          titularClientId: data.titularClientId || undefined,
          clientName: data.clientName,
        } : previous);
      }
      setAdmissionDetails({ id });
    }).catch(() => {
      if (!controller.signal.aborted) setAdmissionDetails({
        id, error: 'Não foi possível carregar os dados do cliente e do titular. Tente novamente.',
      });
    });
    return () => controller.abort();
  }, [isAdmissionOpen, formData.id, initialData, currentUser?.currentUnitId, profileRetry]);
  const admissionDetailsReady = !formData.id
    || (admissionDetails?.id === formData.id && !admissionDetails.error);
  // Resolve only the two FKs. Never depend on the global configuration cache.
  useEffect(() => {
    setSelectedClient(null);
    setSelectedTitular(null);
    setClientProfileError('');
    setClientProfilesLoading(false);
    if (viewMode === 'LIST' || !admissionDetailsReady) return;
    const ids = [...new Set([formData.clientId, formData.titularClientId].filter(Boolean))];
    if (!ids.length) return;
    let active = true;
    const controller = new AbortController();
    setClientProfilesLoading(true);
    apiRequest<{ data: Client[] }>('/api/admission-clients', {
      params: { ids: ids.join(',') }, signal: controller.signal, retries: 1,
    }).then(result => {
      if (!active) return;
      setSelectedClient(result.data.find(c => c.id === formData.clientId) || null);
      setSelectedTitular(result.data.find(c => c.id === formData.titularClientId) || null);
      if (ids.some(id => !result.data.some(c => c.id === id))) {
        setClientProfileError('Cliente ou titular indisponível nesta unidade. Verifique suas permissões.');
      }
    }).catch(error => { if (active) setClientProfileError(error.message || 'Não foi possível carregar os perfis'); })
      .finally(() => { if (active) setClientProfilesLoading(false); });
    return () => { active = false; controller.abort(); };
  }, [viewMode, formData.clientId, formData.titularClientId, currentUser?.currentUnitId, initialData, admissionDetailsReady, profileRetry]);
  const [isDefaultSeries, setIsDefaultSeries] = useState(false);

  const savedAdmission = formData.id ? admissionsList.find(a => a.id === formData.id) : null;
  const isFormLocked = savedAdmission?.status === 'APROVADA';

  const hasStoredAdmissionDocuments = async () => {
      if (!formData.id || !formData.clientId) return false;
      const [bucket, legacy] = await Promise.all([
          api.get<{ total?: number }>('/api/client-attachments/', {
              clientId: formData.clientId, module: 'ADMISSION', targetType: 'ADMISSION', targetId: formData.id, limit: 1,
          }),
          api.get<{ data?: unknown[] }>(`/api/admissions/${encodeURIComponent(formData.id)}/attachments`, { metadataOnly: 1 }),
      ]);
      setBucketAttachmentCount(bucket.total || 0);
      return (bucket.total || 0) + (legacy.data?.length || 0) > 0;
  };

  const handleStatusChange = async (newStatus: string) => {
      if (newStatus === 'APROVADA') {
          try {
              if (!await hasStoredAdmissionDocuments()) {
                  addToast('warning', 'Validação', 'Para aprovar, salve a admissão e inclua pelo menos um arquivo na guia Documentos.');
                  return;
              }
          } catch {
              addToast('error', 'Validação', 'Não foi possível conferir os documentos da admissão. Tente novamente.');
              return;
          }
      }
      const hasOpenRound = formData.auditHistory && formData.auditHistory.length > 0
          ? !formData.auditHistory[formData.auditHistory.length - 1].response?.trim()
          : (formData.auditCritique ? !formData.auditResponse?.trim() : false);
      if (newStatus === 'APROVADA' && hasOpenRound) {
          addToast('warning', 'Validação', 'É obrigatório responder as críticas da auditoria antes de re-aprovar.');
          return;
      }
      let updatedScenarios = formData.recalcScenarios;
      if (newStatus === 'APROVADA') {
          const bank = config.banks.find(b => b.id === formData.bankId);
          updatedScenarios = calcScenariosFromBank(formData.recalcScenarios, bank, formData.modalityId);
          if (bank?.services?.length) {
              addToast('info', 'Recálculo Aplicado', `Cenários atualizados com taxas de ${bank.name}.`);
          }
      }
      setFormData({ ...formData, status: newStatus as AdmissionStatus, recalcScenarios: updatedScenarios });
  };

  useEffect(() => {
    if (viewMode === 'FORM') {
        const saved = localStorage.getItem(DEFAULT_SERIES_KEY);
        setIsDefaultSeries(formData.seriesId === saved && saved !== null);
    }
  }, [formData.seriesId, viewMode]);

  const handleToggleDefaultSeries = (checked: boolean) => {
    if (checked && formData.seriesId) {
        localStorage.setItem(DEFAULT_SERIES_KEY, formData.seriesId);
        setIsDefaultSeries(true);
        addToast('info', 'Série Padrão', 'Esta série foi definida como padrão para novas fichas.');
    } else {
        localStorage.removeItem(DEFAULT_SERIES_KEY);
        setIsDefaultSeries(false);
    }
  };

  const isVehicleModality = useMemo(() => {
      const modality = config.modalities.find(m => m.id === formData.modalityId);
      const containsVeiculo = (s?: string) => /ve[íi]culo/i.test(s || '');
      return containsVeiculo(modality?.type) || containsVeiculo(modality?.description);
  }, [formData.modalityId, config.modalities]);

  // --- BANCO SELECIONADO E LIMITE DE CENÁRIOS ---
  const selectedBank = useMemo(
      () => config.banks.find(b => b.id === formData.bankId),
      [formData.bankId, config.banks]
  );

  // Filtra os serviços do banco pela modalidade selecionada (Requisito 01 e 02)
  const filteredServices = useMemo(() => {
      if (!selectedBank?.services?.length) return [];
      if (formData.modalityId) {
          const byModality = selectedBank.services.filter(s => s.modalityId === formData.modalityId);
          if (byModality.length > 0) return byModality;
      }
      return selectedBank.services;
  }, [selectedBank, formData.modalityId]);

  const maxScenarios = filteredServices.length;

  // Ao trocar de banco ou modalidade, ajustar cenários para corresponder aos serviços filtrados
  // Requisito 01: Abrir os cenários automaticamente na mesma proporção dos serviços (banco + modalidade)
  useEffect(() => {
      if (!formData.bankId) return;
      const services = filteredServices;
      const max = services.length;
      if (max <= 0) return;
      setFormData(prev => {
          const current = prev.recalcScenarios;
          if (current.length === max) return prev;
          if (current.length > max) {
              return { ...prev, recalcScenarios: current.slice(0, max) };
          }
          // Adicionar cenários faltantes usando o label do serviço correspondente
          const newScenarios = [...current];
          for (let i = current.length; i < max; i++) {
              const svc = services[i];
              newScenarios.push({
                  id: 'sc-' + Date.now() + '-' + i,
                  label: svc ? `${svc.name}${svc.negotiationPercentage ? ` (${svc.negotiationPercentage}%)` : ''}` : 'Recálculo %',
                  installmentsToPay: '',
                  originalDebt: '',
                  installmentValue: '',
                  newDebt: '',
                  savings: '',
                  dueDay: '',
              });
          }
          return { ...prev, recalcScenarios: newScenarios };
      });
  }, [formData.bankId, formData.modalityId, filteredServices.length]);

  // --- FUNÇÃO REUTILIZÁVEL DE RECÁLCULO DE CENÁRIOS ---
  // Usa os serviços já filtrados pela modalidade (Requisito 02)
  const calcScenariosFromBank = (scenarios: RecalcScenario[], bank: import('../../types').Bank | undefined, modalityId?: string): RecalcScenario[] => {
      if (!bank?.services?.length) return scenarios;
      let services = bank.services;
      if (modalityId) {
          const byModality = bank.services.filter(s => s.modalityId === modalityId);
          if (byModality.length > 0) services = byModality;
      }
      return scenarios.map((scenario, i) => {
          const service = services[i];
          if (!service) return scenario;
          const origDebt = parseCurrencyBRL(scenario.originalDebt);
          const installments = parseInt(scenario.installmentsToPay) || 0;
          if (origDebt <= 0 || installments <= 0) return scenario;
          const pct = service.negotiationPercentage;
          const newDebt = origDebt * pct / 100;
          const installmentValue = newDebt / installments;
          const savings = origDebt - newDebt;
          return {
              ...scenario,
              label: `${service.name} (${pct}%)`,
              newDebt: formatCurrencyBRL(String(Math.round(newDebt * 100))),
              installmentValue: formatCurrencyBRL(String(Math.round(installmentValue * 100))),
              savings: formatCurrencyBRL(String(Math.round(savings * 100))),
          };
      });
  };

  useEffect(() => {
      if (initialData) {
          const formatted = formatAdmissionData(initialData);
          setFormData(prev => ({ ...prev, ...formatted }));
          setViewMode('FORM');
      }
  }, [initialData]);

  useEffect(() => {
      if (viewMode === 'FORM' && formData.seriesId && !formData.id) {
          const series = config.series.find(s => s.id === formData.seriesId);
          if (series) {
            const unitId = currentUser?.currentUnitId;
            const unitSpec = series.unitNumbering?.find(un => un.unitId === unitId);
            const nextNum = unitSpec ? (unitSpec.currentNumber + 1).toString() : (series.generalNumber + 1).toString();
            setFormData(prev => ({ ...prev, contractNumber: nextNum }));
          }
      }
  }, [formData.seriesId, config.series, viewMode, formData.id]);

  const handleUpdateScenario = (id: string, field: keyof RecalcScenario, value: string) => {
      let finalValue = value;
      if (['originalDebt', 'installmentValue', 'newDebt', 'savings'].includes(field)) {
          finalValue = formatCurrencyBRL(value);
      }
      setFormData(prev => ({
          ...prev,
          recalcScenarios: prev.recalcScenarios.map(s => s.id === id ? { ...s, [field]: finalValue } : s)
      }));
  };

  const handleFinalSubmit = async (keepOpen = false) => {
      if (clientProfilesLoading || clientProfileError || !selectedClient || (formData.titularClientId && !selectedTitular)) {
          addToast('warning', 'Clientes', clientProfileError || 'Aguarde o carregamento dos perfis de cliente e titular.');
          return;
      }
      if (!validarPermissao(formData.id ? 'com_admissao:ALTERAR' : 'com_admissao:INCLUIR')) return;
      if (isFormLocked) {
          addToast('warning', 'Bloqueado', 'Este processo está APROVADO e não pode ser editado.');
          return;
      }
      if (!formData.clientId || !formData.bankId || !formData.seriesId || !formData.unitId) {
          addToast('warning', 'Validação', 'Preencha os campos obrigatórios (Cliente, Banco, Série e Unidade).');
          return;
      }
      if (formData.status === 'APROVADA') {
          try {
              if (!await hasStoredAdmissionDocuments()) {
                  addToast('warning', 'Validação', 'Para aprovar, é necessário incluir pelo menos um documento na guia Documentos.');
                  return;
              }
          } catch (error) {
              addToast('error', 'Documentos', 'Não foi possível verificar os anexos. Confira a guia Documentos e tente novamente.');
              return;
          }
      }
      const hasSaveOpenRound = formData.auditHistory && formData.auditHistory.length > 0
          ? !formData.auditHistory[formData.auditHistory.length - 1].response?.trim()
          : (formData.auditCritique ? !formData.auditResponse?.trim() : false);
      if (formData.status === 'APROVADA' && hasSaveOpenRound) {
          addToast('warning', 'Validação', 'É obrigatório responder as críticas da auditoria antes de re-aprovar.');
          return;
      }
      if (formData.status === 'APROVADA' && !formData.recalcScenarios?.[0]?.newDebt) {
          addToast('warning', 'Atenção', 'Cenários de recálculo sem valores calculados — recomendado calcular antes de aprovar.');
      }
      let itemToSave = { ...formData };
      if (formData.auditHistory && formData.auditHistory.length > 0 && formData.auditResponse?.trim()) {
          const lastRound = formData.auditHistory[formData.auditHistory.length - 1];
          if (!lastRound.response) {
              const updatedHistory: AuditRound[] = formData.auditHistory.map((r, i, arr) =>
                  i === arr.length - 1 && !r.response
                      ? { ...r, response: formData.auditResponse || '', responseDate: new Date().toISOString(), respondedBy: 'Comercial' }
                      : r
              );
              itemToSave = { ...itemToSave, auditHistory: updatedHistory };
          }
      }
      const originalItem = formData.id ? admissionsList.find(a => a.id === formData.id) : null;

      const sanitizeFk = (v: string | undefined | null) => v === '' ? null : (v || null);
      const apiPayload = {
          date: itemToSave.date,
          client_id: sanitizeFk(itemToSave.clientId),
          client_name: itemToSave.clientName,
          bank_id: sanitizeFk(itemToSave.bankId),
          collaborator_id: sanitizeFk(itemToSave.collaboratorId),
          series_id: sanitizeFk(itemToSave.seriesId),
          modality_id: sanitizeFk(itemToSave.modalityId),
          contract_number: itemToSave.contractNumber,
          total_installments: itemToSave.totalInstallments,
          paid_installments: itemToSave.paidInstallments,
          overdue_installments: itemToSave.overdueInstallments,
          financed_amount: itemToSave.financedAmount,
          installment_value: itemToSave.installmentValue,
          due_day: itemToSave.dueDay,
          payment_type: itemToSave.paymentType,
          indication_type: itemToSave.indicationType,
          status: itemToSave.status,
          vehicle_brand: itemToSave.vehicleBrand,
          vehicle_model: itemToSave.vehicleModel,
          vehicle_color: itemToSave.vehicleColor,
          vehicle_year: itemToSave.vehicleYear,
          vehicle_plate: itemToSave.vehiclePlate,
          vehicle_chassis: itemToSave.vehicleChassis,
          vehicle_renavam: itemToSave.vehicleRenavam,
          is_electric_vehicle: itemToSave.isElectricVehicle,
          first_installment_due_date: itemToSave.firstInstallmentDueDate,
          has_bank_fee_included: itemToSave.hasBankFeeIncluded,
          is_third_party_contract: itemToSave.isThirdPartyContract,
          audit_critique: itemToSave.auditCritique,
          parcela1: itemToSave.parcela1,
          parcela2: itemToSave.parcela2,
          taxa_cobranca: itemToSave.taxaCobranca,
          other_info1: itemToSave.otherInfo1,
          other_info2: itemToSave.otherInfo2,
          unit_id: itemToSave.unitId || null,
          origin_type: itemToSave.originType || null,
          tipo_cliente: itemToSave.tipoCliente || 'RESPONSÁVEL',
          titular_client_id: sanitizeFk(itemToSave.titularClientId),
      };

      try {
          if (formData.id) {
              await apiUpdate(formData.id, apiPayload as any);
          } else {
              itemToSave.date = new Date().toISOString();
              apiPayload.date = itemToSave.date;
              const created = await apiCreate(apiPayload as any);
              itemToSave.id = created.id || itemToSave.id;
          }

          if (itemToSave.id) {
              const scenariosPayload = (itemToSave.recalcScenarios || []).map((s: any) => ({
                  label: s.label || '',
                  installmentsToPay: s.installmentsToPay || null,
                  originalDebt: s.originalDebt || null,
                  installmentValue: s.installmentValue || null,
                  newDebt: s.newDebt || null,
                  savings: s.savings || null,
                  dueDay: s.dueDay || null,
              }));
              fetch(`/api/admissions/${itemToSave.id}/recalc-scenarios`, {
                  method: 'PUT',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(scenariosPayload)
              }).catch(() => {});
          }

          let updatedSeriesList = config.series;
          if (!formData.id) {
              updatedSeriesList = config.series.map(s => {
                  if (s.id !== formData.seriesId) return s;
                  const newNum = parseInt(formData.contractNumber);
                  const unitId = currentUser?.currentUnitId;
                  const unitIdx = s.unitNumbering?.findIndex(un => un.unitId === unitId);
                  if (unitIdx !== undefined && unitIdx !== -1) {
                      const newUnitNumbering = [...s.unitNumbering];
                      newUnitNumbering[unitIdx] = { ...newUnitNumbering[unitIdx], currentNumber: newNum };
                      return { ...s, unitNumbering: newUnitNumbering };
                  } else return { ...s, generalNumber: newNum };
              });
              fetch('/api/settings/section', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: 'series', value: updatedSeriesList }) }).catch(() => {});
          }

          logTransaction('ADMISSAO', itemToSave.id, originalItem, itemToSave);
          addToast('success', 'Sucesso', 'Salvo com sucesso.');
          apiRefresh();
          onRefresh?.();
           if (keepOpen) {
             setFormData({ ...itemToSave });
             setViewMode('FORM');
           } else {
             setViewMode('LIST');
           }
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Erro ao salvar admissão.');
      }
  };

  const handlePrint = async () => {
      if (clientProfilesLoading || clientProfileError || !selectedClient || (formData.titularClientId && !selectedTitular)) {
          addToast('warning', 'Clientes', clientProfileError || 'Aguarde o carregamento dos perfis antes de imprimir.');
          return;
      }
      const bank = config.banks.find(b => b.id === formData.bankId);
      const updatedScenarios = calcScenariosFromBank(formData.recalcScenarios, bank);

      const updatedStatus: AdmissionStatus =
          formData.status === 'PENDENTE' ? 'NEGOCIAÇÃO' : formData.status;
      const updatedFormData = { ...formData, status: updatedStatus, recalcScenarios: updatedScenarios };
      setFormData(updatedFormData);

      if (formData.id && formData.status === 'PENDENTE') {
          try {
              await api.patch(`/api/admissions/${formData.id}/status`, { status: 'NEGOCIAÇÃO' });
              logTransaction('ADMISSAO', formData.id, formData, updatedFormData);
              apiRefresh();
          } catch {
          }
      }

      if (formData.status === 'PENDENTE')
          addToast('info', 'Status Atualizado', 'Status alterado para NEGOCIAÇÃO após emissão.');
      if (bank?.services?.length)
          addToast('success', 'Recálculo Aplicado', `Cenários calculados com serviços de ${bank.name}.`);

      window.print();
  };

  const handleExportDocx = async (templateBase64: string, templateName: string) => {
      if (clientProfilesLoading || clientProfileError || !selectedClient || (formData.titularClientId && !selectedTitular)) {
          addToast('warning', 'Clientes', clientProfileError || 'Aguarde o carregamento dos perfis antes de exportar.');
          return;
      }
      setIsExporting(true);
      try {
          const binaryString = atob(templateBase64);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
              bytes[i] = binaryString.charCodeAt(i);
          }

          const zip = new PizZip(bytes.buffer);
          const doc = new Docxtemplater(zip, {
              paragraphLoop: true,
              linebreaks: true,
              delimiters: { start: '{{', end: '}}' },
          });

          const variables = getAdmissionVariables(formData, config);
          doc.render(variables);

          const out = doc.getZip().generate({
              type: 'blob',
              mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
          });

          const fileName = `${formData.clientName || 'admissao'}_${formData.contractNumber || 'sem-contrato'}.docx`;
          saveAs(out, fileName);
          addToast('success', 'Exportado', 'Documento Word gerado com sucesso!');
          setShowExportModal(false);
      } catch (err: any) {
          console.error('Erro ao exportar DOCX:', err);
          if (err?.properties?.errors) {
              console.error('Detalhes:', JSON.stringify(err.properties.errors));
          }
          addToast('error', 'Erro', 'Erro ao gerar o documento. Verifique se o template usa as variáveis corretas (ex: {{clientName}}).');
      } finally {
          setIsExporting(false);
      }
  };

  const handleDirectDocxUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const fileName = file.name.toLowerCase();
      if (fileName.endsWith('.doc') && !fileName.endsWith('.docx')) {
          alert('O formato .doc (Word 97-2003) não é suportado.\n\nPor favor, abra o arquivo no Word e salve como .docx.');
          if (docxInputRef.current) docxInputRef.current.value = '';
          return;
      }

      if (!fileName.endsWith('.docx')) {
          alert('Por favor, selecione um arquivo .docx válido.');
          if (docxInputRef.current) docxInputRef.current.value = '';
          return;
      }

      setIsExporting(true);
      try {
          const arrayBuffer = await file.arrayBuffer();
          const uint8Array = new Uint8Array(arrayBuffer);
          let binary = '';
          for (let i = 0; i < uint8Array.length; i++) {
              binary += String.fromCharCode(uint8Array[i]);
          }
          const base64 = btoa(binary);
          await handleExportDocx(base64, file.name);
      } catch (err) {
          console.error('Erro ao processar arquivo:', err);
          addToast('error', 'Erro', 'Erro ao processar o arquivo.');
      } finally {
          if (docxInputRef.current) docxInputRef.current.value = '';
      }
  };

  const formsWithDocx = useMemo(() => {
      return (config.formTemplates || []).filter(f => f.docxTemplate);
  }, [config.formTemplates]);

  const { templates: admissionTemplates } = useFormTemplates('com_admissao', config.formTemplates || []);

  const TemplatePreviewContent = ({ template, data, clientObj }: { template: FormTemplate, data: Admission, clientObj: Client | null }) => {
      const headerHtml = replaceTemplateVariables(template.header || '', data, clientObj, config);
      const bodyHtml = replaceTemplateVariables(template.content || '', data, clientObj, config);
      const footerHtml = replaceTemplateVariables(template.footer || '', data, clientObj, config);

      return (
          <div className="template-preview-content" style={{ fontFamily: 'Arial, sans-serif', fontSize: '11px', color: '#000' }}>
              {headerHtml && <div dangerouslySetInnerHTML={{ __html: sanitizeHtml(headerHtml) }} style={{ marginBottom: '10px' }} />}
              <div dangerouslySetInnerHTML={{ __html: sanitizeHtml(bodyHtml) }} />
              {footerHtml && <div dangerouslySetInnerHTML={{ __html: sanitizeHtml(footerHtml) }} style={{ marginTop: '20px' }} />}
          </div>
      );
  };

  // --- LIST LOGIC ---
  const handleSort = (key: keyof Admission | 'clientName' | 'collaboratorName') => {
      let direction: 'asc' | 'desc' | null = 'asc';
      if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
      else if (sortConfig.key === key && sortConfig.direction === 'desc') direction = null;
      setSortConfig({ key: direction ? key : 'date', direction: direction || 'desc' });
  };

  const filteredAdmissions = useMemo(() => {
      let data = admissionsList;
      if (currentUser && currentUser.role !== UserRole.ADMIN) {
          const allowedUnits = currentUser.allowedUnitIds || [];
          if (allowedUnits.length > 0) {
              data = data.filter(a => !a.unitId || allowedUnits.includes(a.unitId));
          }
      }
      if (filterClientField) {
          const lower = filterClientField.toLowerCase();
          data = data.filter(a => (a.clientName || '').toLowerCase().includes(lower));
      }
      if (filterDateStart) data = data.filter(a => (a.date || '').split('T')[0] >= filterDateStart);
      if (filterDateEnd) data = data.filter(a => (a.date || '').split('T')[0] <= filterDateEnd);
      return data;
  }, [admissionsList, filterClientField, filterDateStart, filterDateEnd, currentUser]);

  const sortedAdmissions = useMemo(() => {
      const data = [...filteredAdmissions];
      if (sortConfig.key && sortConfig.direction) {
          data.sort((a, b) => {
              let valA: any;
              let valB: any;
              if (sortConfig.key === 'collaboratorName') {
                  valA = config.collaborators.find(c => c.id === a.collaboratorId)?.name || '';
                  valB = config.collaborators.find(c => c.id === b.collaboratorId)?.name || '';
              } else if (sortConfig.key === 'clientName') {
                  valA = a.clientName || '';
                  valB = b.clientName || '';
              } else {
                  valA = a[sortConfig.key as keyof Admission] || '';
                  valB = b[sortConfig.key as keyof Admission] || '';
              }
              if (typeof valA === 'string') valA = valA.toLowerCase();
              if (typeof valB === 'string') valB = valB.toLowerCase();
              if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
              if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
              return 0;
          });
      }
      return data;
  }, [filteredAdmissions, sortConfig, config.collaborators]);


  const handleActionAdmission = useCallback((adm: Admission, targetMode: ViewMode) => {
    if (targetMode === 'FORM' && !validarPermissao('com_admissao:ALTERAR')) return;
    const formatted = formatAdmissionData(adm);
    const recalcScenarios = (formatted.recalcScenarios && formatted.recalcScenarios.length > 0)
      ? formatted.recalcScenarios
      : DEFAULT_RECALC_SCENARIOS;
    setFormData({ ...formatted, recalcScenarios });
    setBucketAttachmentCount(0);
    setSelectedClient(null);
    setSelectedTitular(null);
    setViewMode(targetMode);
  }, [validarPermissao]);

  const handleEditAdmissionCb = useCallback((adm: Admission) => handleActionAdmission(adm, 'FORM'), [handleActionAdmission]);
  const handlePreviewAdmissionCb = useCallback((adm: Admission) => handleActionAdmission(adm, 'PREVIEW'), [handleActionAdmission]);
  const handleDeleteAdmissionCb = useCallback(async (adm: Admission) => {
    if (adm.status === 'APROVADA') return;
    if (!validarPermissao('com_admissao:EXCLUIR')) return;
    const depResult = checkDependencies('admission', adm.id, config);
    if (!depResult.canDelete) {
      addToast('warning', 'Exclusão Bloqueada', formatDependencyMessage(`a admissão "${adm.id}"`, depResult.dependencies));
      return;
    }
    if (window.confirm('Excluir?')) {
      try {
        await apiRemove(adm.id);
        logTransaction('ADMISSAO', adm.id, adm, null);
        addToast('success', 'Sucesso', 'Excluído.');
        apiRefresh();
      } catch {
        addToast('error', 'Erro', 'Falha ao excluir admissão.');
      }
    }
  }, [config, apiRemove, apiRefresh, validarPermissao, addToast, logTransaction]);

  const handleNewAdmissionLocal = () => {
    if (!validarPermissao('com_admissao:INCLUIR')) return;
    setBucketAttachmentCount(0);
    setFormData({
        id: '', date: new Date().toISOString(), clientId: '', clientName: '', bankId: '', collaboratorId: '', 
        seriesId: localStorage.getItem(DEFAULT_SERIES_KEY) || '', modalityId: '', indicationType: 'INDICAÇÃO', originType: '', unitId: currentUser?.currentUnitId || '',
        tipoCliente: 'RESPONSÁVEL',
        contractNumber: '', totalInstallments: '', paidInstallments: '', overdueInstallments: '', 
        financedAmount: '', installmentValue: '', dueDay: '', paymentType: '', 
        status: 'PENDENTE',
        vehicleBrand: '', vehicleModel: '', vehicleColor: '', vehicleYear: '', vehiclePlate: '', vehicleChassis: '', vehicleRenavam: '',
        recalcScenarios: [
            { id: 'sc-1', label: 'Recálculo %', installmentsToPay: '', originalDebt: '', installmentValue: '', newDebt: '', savings: '', dueDay: '' },
            { id: 'sc-2', label: 'Recálculo %', installmentsToPay: '', originalDebt: '', installmentValue: '', newDebt: '', savings: '', dueDay: '' },
            { id: 'sc-3', label: 'Recálculo %', installmentsToPay: '', originalDebt: '', installmentValue: '', newDebt: '', savings: '', dueDay: '' }
        ], 
        attachments: [],
        parcela1: '',
        parcela2: '',
        taxaCobranca: '',
        otherInfo1: '', otherInfo2: ''
    });
    setSelectedClient(null);
    setSelectedTitular(null);
    setViewMode('FORM');
  };

  const handleSaveForDocuments = () => { void handleFinalSubmit(true); };


  // --- VIEWS ---
  if (isAdmissionOpen && (!admissionDetailsReady || clientProfilesLoading || clientProfileError)) {
      return <div role={admissionDetails?.error ? 'alert' : 'status'} className="p-6 space-y-4">
          <p>{admissionDetails?.error || clientProfileError || 'Carregando perfis de cliente e titular...'}</p>
          {(admissionDetails?.error || clientProfileError) && (
            <Button onClick={() => setProfileRetry(value => value + 1)}>Tentar novamente</Button>
          )}
          <Button onClick={() => setViewMode('LIST')}>Voltar à lista</Button>
      </div>;
  }
  if (viewMode === 'PREVIEW') {
      const activeTemplate = admissionTemplates.find(t => t.id === selectedTemplateId);
      return (
          <>
              <div className="hidden print:block fixed inset-0 bg-white z-[9999] p-10 m-0">
                  <style>{`@page { size: A4; margin: 0; }`}</style>
                  {activeTemplate ? (
                      <TemplatePreviewContent template={activeTemplate} data={formData} clientObj={selectedClient} />
                  ) : (
                      <AdmissionPrintView data={formData} client={selectedClient} titular={selectedTitular} config={config} currentUserId={currentUser?.id} />
                  )}
              </div>
              <div className="fixed inset-0 z-[60] bg-gray-900 bg-opacity-95 flex flex-col items-center animate-fade-in no-print">
                   <div className="w-full bg-black text-white p-3 sm:p-4 flex flex-wrap gap-3 justify-between items-center border-b border-gray-700 shadow-xl">
                       <div className="flex items-center gap-2 sm:gap-4 min-w-0">
                          <button onClick={() => setViewMode('FORM')} className="hover:bg-white/10 p-2 rounded-full transition-colors"><svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" /></svg></button>
                           <h3 className="font-black tracking-tighter uppercase italic text-sm sm:text-xl truncate">Visualização do Documento</h3>
                      </div>
                       <div className="flex flex-wrap items-center justify-end gap-2 sm:gap-3 w-full sm:w-auto">
                           <div className="flex items-center gap-2 min-w-0 max-w-full">
                              <span className="text-xs text-gray-400 font-bold uppercase">Template:</span>
                              <select
                                  value={selectedTemplateId}
                                  onChange={(e) => setSelectedTemplateId(e.target.value)}
                                   className="bg-gray-800 text-white text-sm border border-gray-600 rounded-lg px-3 py-1.5 outline-none focus:border-moss-500 min-w-0 max-w-[55vw] sm:max-w-[220px]"
                              >
                                  <option value="">Ficha Padrão do Sistema</option>
                                  {admissionTemplates.map(t => (
                                      <option key={t.id} value={t.id}>{t.name}</option>
                                  ))}
                              </select>
                          </div>
                           <div className="hidden sm:block w-px h-6 bg-gray-600"></div>
                          <Button variant="outline" className="!w-auto !py-2 !px-6 border-white/30 text-white hover:bg-white/10" onClick={() => setViewMode('FORM')}>VOLTAR</Button>
                          <Button variant="primary" className="!w-auto !py-2 !px-8 bg-moss-600 hover:bg-moss-700 shadow-lg" onClick={handlePrint}>IMPRIMIR</Button>
                      </div>
                  </div>
                   <div className="flex-1 min-h-0 w-full overflow-auto overscroll-contain p-4 md:p-10 bg-gray-800">
                        <div className="bg-white w-[210mm] min-w-[210mm] min-h-[297mm] p-[15mm] shadow-2xl origin-top border border-gray-100 mx-auto">
                           {activeTemplate ? (
                               <TemplatePreviewContent template={activeTemplate} data={formData} clientObj={selectedClient} />
                           ) : (
                               <AdmissionPrintView data={formData} client={selectedClient} titular={selectedTitular} config={config} currentUserId={currentUser?.id} />
                           )}
                      </div>
                  </div>
              </div>
          </>
      );
  }

  if (viewMode === 'FORM') {
      return (
        <ErrorBoundary label="Formulário de Admissão">
          <AdmissionFormView
            formData={formData}
            setFormData={setFormData}
            selectedClient={selectedClient}
            setSelectedClient={setSelectedClient}
            selectedTitular={selectedTitular}
            setSelectedTitular={setSelectedTitular}
            config={config}
            isFormLocked={isFormLocked}
            isDefaultSeries={isDefaultSeries}
            handleToggleDefaultSeries={handleToggleDefaultSeries}
            handleStatusChange={handleStatusChange}
            handleUpdateScenario={handleUpdateScenario}
            handleFinalSubmit={() => { void handleFinalSubmit(); }}
            handleSaveForDocuments={handleSaveForDocuments}
            handlePrint={handlePrint}
            handleKeyDown={handleKeyDown}
            handleExportDocx={handleExportDocx}
            handleDirectDocxUpload={handleDirectDocxUpload}
            onRequestExternalAction={onRequestExternalAction}
            setViewMode={setViewMode}
            selectedTemplateId={selectedTemplateId}
            setSelectedTemplateId={setSelectedTemplateId}
            admissionTemplates={admissionTemplates}
            isVehicleModality={isVehicleModality}
            maxScenarios={maxScenarios}
            showExportModal={showExportModal}
            setShowExportModal={setShowExportModal}
            isExporting={isExporting}
            formsWithDocx={formsWithDocx}
            currentUserId={currentUser?.id}
            bucketAttachmentCount={bucketAttachmentCount}
            setBucketAttachmentCount={setBucketAttachmentCount}
            canMigrateLegacyAttachments={isLoggedAdmin}
            TemplatePreviewContent={TemplatePreviewContent}
          />
        </ErrorBoundary>
      );
  }


  return (
     <div className="flex flex-col h-full min-w-0 animate-fade-in w-full p-3 sm:p-4 md:p-8 overflow-y-auto compact-virtual-grid" data-grid-density="compact">
         <div className="flex flex-wrap gap-4 justify-between items-start mb-6 sm:mb-8">
             <div className="min-w-0"><h2 className="text-2xl sm:text-3xl font-black text-gray-900 tracking-tighter uppercase italic">Admissão de Processos</h2><p className="text-gray-500 text-sm font-medium">Gerencie e visualize as fichas de admissão cadastradas.</p></div>
            {canIncluir && <Button variant="new" className="!w-auto px-6 py-3 shadow-lg transform hover:scale-105 transition-all" onClick={handleNewAdmissionLocal}>Nova Ficha</Button>}
        </div>
         <div className="bg-white p-3 sm:p-6 rounded-xl shadow-sm border border-gray-200 mb-4 sm:mb-6 space-y-4 grid-search">
             <div className="flex flex-col sm:flex-row gap-3 sm:gap-4"><div className="flex-1 min-w-0"><Input label="" placeholder="Pesquisa rápida (Cliente, Nº Contrato, Documento ou Telefone)..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} containerClassName="!mb-0" icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>}/></div><Button variant="ghost" className={`!w-full sm:!w-auto border border-gray-200 ${showFilters ? 'bg-gray-100' : ''}`} onClick={() => setShowFilters(!showFilters)}>Filtros Avançados</Button></div>
            {showFilters && (
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-4 border-t border-gray-100 animate-fade-in-down">
                    <div><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Filtrar Cliente</label><input type="text" className="w-full border rounded-lg p-2.5 text-sm outline-none bg-gray-50 focus:bg-white focus:ring-2 focus:ring-moss-500" placeholder="Nome, CPF/CNPJ ou Fone" value={filterClientField} onChange={e => setFilterClientField(e.target.value)} /></div>
                    <div><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Banco Credor</label><select className="w-full border rounded-lg p-2.5 text-sm outline-none bg-gray-50 focus:bg-white" value={filterBank} onChange={e => setFilterBank(e.target.value)}><option value="">Todos os Bancos</option>{config.banks.map(b => <option key={b.id} value={b.id}>{b.name}</option>)}</select></div>
                    <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Status do Processo</label>
                        <select className="w-full border rounded-lg p-2.5 text-sm outline-none bg-gray-50 focus:bg-white" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                            <option value="">Todos os Status</option>
                            <option value="PENDENTE">Pendente</option>
                            <option value="NEGOCIAÇÃO">Negociação</option>
                            <option value="APROVADA">Aprovada</option>
                            <option value="ANÁLISE CLIENTE">Análise Cliente</option>
                            <option value="REPROVADA">Reprovada</option>
                            <option value="AUDITADA">Auditada</option>
                            <option value="FINALIZADA">Finalizada</option>
                            <option value="RETORNO AUDITORIA">Retorno Auditoria</option>
                        </select>
                    </div>
                    <div><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Consultor</label><select className="w-full border rounded-lg p-2.5 text-sm outline-none bg-gray-50 focus:bg-white" value={filterCollaborator} onChange={e => setFilterCollaborator(e.target.value)}><option value="">Todos os Consultores</option>{config.collaborators.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}</select></div>
                    <div><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Datas</label><div className="flex gap-2"><input type="date" className="w-full border rounded-lg p-2.5 text-xs bg-gray-50 outline-none" value={filterDateStart} onChange={e => setFilterDateStart(e.target.value)} /><input type="date" className="w-full border rounded-lg p-2.5 text-xs bg-gray-50 outline-none" value={filterDateEnd} onChange={e => setFilterDateEnd(e.target.value)} /></div></div>
                </div>
            )}
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex-1 flex flex-col">
             <div className="overflow-x-auto flex-1 flex flex-col min-h-0 grid-body-scroll">
                <div className="compact-virtual-row flex items-center bg-gray-50 border-b border-gray-200 flex-shrink-0" style={{ minWidth: '900px' }}>
                    <div role="button" tabIndex={0} className="compact-grid-sort-control px-6 py-4 w-28 flex-shrink-0 text-left text-xs font-bold text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onClick={() => handleSort('date')} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleSort('date'); } }}>Data {sortConfig.key === 'date' ? (sortConfig.direction === 'asc' ? '↑' : '↓') : '⇅'}</div>
                    <div role="button" tabIndex={0} className="compact-grid-sort-control px-6 py-4 w-36 flex-shrink-0 text-left text-xs font-bold text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onClick={() => handleSort('contractNumber')} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleSort('contractNumber'); } }}>Contrato {sortConfig.key === 'contractNumber' ? (sortConfig.direction === 'asc' ? '↑' : '↓') : '⇅'}</div>
                    <div role="button" tabIndex={0} className="compact-grid-sort-control px-6 py-4 flex-1 min-w-0 text-left text-xs font-bold text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onClick={() => handleSort('clientName')} onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handleSort('clientName'); } }}>Cliente {sortConfig.key === 'clientName' ? (sortConfig.direction === 'asc' ? '↑' : '↓') : '⇅'}</div>
                    <div className="px-6 py-4 w-28 flex-shrink-0 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Origem</div>
                    <div className="px-6 py-4 w-36 flex-shrink-0 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Unidade</div>
                    <div className="px-6 py-4 w-28 flex-shrink-0 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</div>
                    <div className="px-6 py-4 w-40 flex-shrink-0 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Ações</div>
                </div>
                {sortedAdmissions.length === 0 ? (
                    <div className="px-6 py-10 text-center text-gray-400">Nenhum processo encontrado.</div>
                ) : (
                    <FixedSizeList
                        height={Math.min(sortedAdmissions.length * 40, 520)}
                        itemCount={sortedAdmissions.length}
                         itemSize={40}
                        width="100%"
                        overscanCount={5}
                        itemData={{ paginatedAdmissions: sortedAdmissions, series: config.series, units: config.units, auditLogs: config.auditLogs, clientsWithGoTalk, onEdit: handleEditAdmissionCb, onPreview: handlePreviewAdmissionCb, onDelete: handleDeleteAdmissionCb, canEdit: canAlterar, canDelete: canExcluir, canView: canVisualizar } as AdmissionRowItemData}
                    >
                        {({ index, style, data }: { index: number; style: React.CSSProperties; data: AdmissionRowItemData }) => {
                            const adm = data.paginatedAdmissions[index];
                            return (
                                <AdmissionRow
                                    key={adm.id}
                                    adm={adm}
                                    style={style}
                                    seriesSigla={data.series.find(s => s.id === adm.seriesId)?.sigla || ''}
                                    unitName={data.units.find(u => u.id === adm.unitId)?.nomeFantasia || '—'}
                                    auditLogs={data.auditLogs || []}
                                    onEdit={data.onEdit}
                                    onPreview={data.onPreview}
                                    onDelete={data.onDelete}
                                    canEdit={data.canEdit}
                                    canDelete={data.canDelete}
                                    canView={data.canView}
                                    hasGoTalkHistory={adm.clientId ? data.clientsWithGoTalk.has(adm.clientId) : false}
                                />
                            );
                        }}
                    </FixedSizeList>
                )}
            </div>
            <PaginationBar currentPage={serverPage} totalPages={serverTotalPages} total={serverTotal} pageSize={50} onPageChange={serverGoToPage} loading={apiLoading} />
        </div>
    </div>
  );
};

export default AdmissionPanel;
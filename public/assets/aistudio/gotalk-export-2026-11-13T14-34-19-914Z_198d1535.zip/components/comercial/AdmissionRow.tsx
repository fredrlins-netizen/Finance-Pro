import React from 'react';
import { Admission } from '../../types';
import AuditLogButton from '../ui/AuditLogButton';

interface AdmissionRowProps {
  adm: Admission;
  seriesSigla: string;
  unitName: string;
  auditLogs: any[];
  onEdit: (adm: Admission) => void;
  onPreview: (adm: Admission) => void;
  onDelete: (adm: Admission) => void;
  canEdit: boolean;
  canDelete: boolean;
  canView: boolean;
  hasGoTalkHistory?: boolean;
  style?: React.CSSProperties;
}

const AdmissionRow = React.memo<AdmissionRowProps>(
  ({ adm, seriesSigla, unitName, auditLogs, onEdit, onPreview, onDelete, canEdit, canDelete, canView, hasGoTalkHistory, style }) => {
    const originBadge = adm.originType ? (
      <span className={`px-2 py-1 inline-flex text-[10px] font-black rounded-full uppercase ${
        adm.originType === 'PROSPECÇÃO' ? 'bg-cyan-100 text-cyan-700 border border-cyan-200' :
        adm.originType === 'PROPAGANDA' ? 'bg-orange-100 text-orange-700 border border-orange-200' :
        adm.originType === 'RECUPERAÇÃO' ? 'bg-purple-100 text-purple-700 border border-purple-200' :
        'bg-gray-100 text-gray-700 border border-gray-200'
      }`}>{adm.originType}</span>
    ) : <span className="text-xs text-gray-400">-</span>;

    const statusBadge = (
      <span className={`px-2 py-1 inline-flex text-[10px] font-black rounded-full uppercase ${
        adm.status === 'PENDENTE' ? 'bg-amber-100 text-amber-700 border border-amber-200' :
        adm.status === 'NEGOCIAÇÃO' ? 'bg-blue-100 text-blue-700 border border-blue-200' :
        adm.status === 'APROVADA' ? 'bg-green-100 text-green-700 border border-green-200' :
        adm.status === 'REPROVADA' ? 'bg-red-100 text-red-700 border border-red-200' :
        adm.status === 'RETORNO AUDITORIA' ? 'bg-red-800 text-white border border-red-900 shadow-sm animate-pulse' :
        adm.status === 'AUDITADA' ? 'bg-indigo-100 text-indigo-700 border border-indigo-200' :
        adm.status === 'FINALIZADA' ? 'bg-gray-600 text-white border border-gray-700' :
        'bg-gray-100 text-gray-700 border border-gray-200'
      }`}>{adm.status || 'PENDENTE'}</span>
    );

    return (
      <div style={style} className={`compact-virtual-row flex items-center border-b border-gray-100 hover:bg-gray-50 transition-colors ${adm.status === 'RETORNO AUDITORIA' ? 'bg-red-50 text-red-900 font-bold' : ''}`}>
        <div className="px-6 w-28 flex-shrink-0 text-sm text-gray-600 font-mono">{new Date(adm.date).toLocaleDateString('pt-BR')}</div>
        <div className="px-6 w-36 flex-shrink-0 text-sm font-bold text-moss-700 truncate">{seriesSigla} - {adm.contractNumber}</div>
        <div className="px-6 flex-1 min-w-0 text-sm text-gray-900 font-medium">
          <span className="flex items-center gap-1.5 truncate">
            {adm.clientName}
            {hasGoTalkHistory && (
              <span title="Possui histórico GoTalk" className="inline-flex shrink-0">
                <svg className="w-3.5 h-3.5 text-green-500" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              </span>
            )}
          </span>
        </div>
        <div className="px-6 w-28 flex-shrink-0">{originBadge}</div>
        <div className="px-6 w-36 flex-shrink-0 text-sm text-gray-600 truncate">{unitName}</div>
        <div className="px-6 w-28 flex-shrink-0">{statusBadge}</div>
        <div className="px-6 w-40 flex-shrink-0 text-right text-sm font-medium">
          <div className="flex justify-end gap-3">
            <AuditLogButton entityId={adm.id} entityName={adm.clientName || adm.id} logs={auditLogs} />
            {canEdit && <button onClick={() => onEdit(adm)} className="text-blue-600 hover:text-blue-900">Editar</button>}
            {canView && <button onClick={() => onPreview(adm)} className="text-moss-600 hover:text-moss-800 font-bold">Visualizar</button>}
            {canDelete && adm.status !== 'APROVADA' && <button onClick={() => onDelete(adm)} className="text-red-400 hover:text-red-600">Excluir</button>}
          </div>
        </div>
      </div>
    );
  }
);

export default AdmissionRow;

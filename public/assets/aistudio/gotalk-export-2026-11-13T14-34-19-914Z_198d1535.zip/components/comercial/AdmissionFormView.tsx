import React, { useRef, useState } from 'react';
import { Admission, Client, Bank, Collaborator, PortalConfig, FormTemplate, AuditRound } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';
import Alert from '../ui/Alert';
import ErrorBoundary from '../shared/ErrorBoundary';
import AdmissionPrintView from './AdmissionPrintView';
import GotalkChatPanel from '../gotalk/GotalkChatPanel';
import GotalkAttendanceViewer from '../gotalk/GotalkAttendanceViewer';
import { useSecurity } from '../../contexts/SecurityContext';
import ClientAttachmentsPanel from '../attachments/ClientAttachmentsPanel';
import LegacyAdmissionAttachmentsPanel from '../attachments/LegacyAdmissionAttachmentsPanel';
import { apiRequest } from '../../services/apiService';

interface SmartSelectProps<T> {
    options: T[];
    selectedId: string;
    onSelect: (id: string, option?: T) => void;
    remoteUnitId?: string;
    onAdd: () => void;
    onEdit: (id: string) => void;
    displayField: keyof T;
    searchKeys?: (keyof T)[];
    placeholder?: string;
    onKeyDown?: (e: React.KeyboardEvent<HTMLInputElement>) => void;
}

function SmartSelect<T extends { id: string }>({
    options, selectedId, onSelect, onAdd, onEdit, displayField, searchKeys, placeholder, onKeyDown, remoteUnitId
}: SmartSelectProps<T>) {
    const [searchTerm, setSearchTerm] = React.useState('');
    const [isOpen, setIsOpen] = React.useState(false);
    const wrapperRef = useRef<HTMLDivElement>(null);
    const selected = options.find(o => o.id === selectedId);
    const [remoteOptions, setRemoteOptions] = useState<T[]>([]);
    const [nextCursor, setNextCursor] = useState<string | null>(null);
    const [pageCursor, setPageCursor] = useState<string | null>(null);
    const [loading, setLoading] = useState(false);
    const [searchError, setSearchError] = useState('');
    React.useEffect(() => {
        if (remoteUnitId === undefined || !isOpen) return;
        setRemoteOptions([]);
        setNextCursor(null);
        setSearchError('');
        if (searchTerm.trim().length < 3) { setLoading(false); return; }
        let active = true;
        const controller = new AbortController();
        setLoading(true);
        const timer = setTimeout(() => {
            apiRequest<{ data: T[]; nextCursor: string | null }>('/api/admission-clients', {
                params: { search: searchTerm.trim(), cursor: pageCursor || undefined },
                signal: controller.signal, retries: 1,
            }).then(result => {
                if (active) { setRemoteOptions(result.data); setNextCursor(result.nextCursor); }
            }).catch(error => {
                if (active) setSearchError(error.message || 'Não foi possível pesquisar clientes');
            }).finally(() => { if (active) setLoading(false); });
        }, 300);
        return () => { active = false; clearTimeout(timer); controller.abort(); };
    }, [isOpen, searchTerm, pageCursor, remoteUnitId]);

    React.useEffect(() => {
        const handler = (e: MouseEvent) => {
            if (wrapperRef.current && !wrapperRef.current.contains(e.target as Node)) setIsOpen(false);
        };
        document.addEventListener('mousedown', handler);
        return () => document.removeEventListener('mousedown', handler);
    }, []);

    const filtered = remoteUnitId !== undefined ? remoteOptions : options.filter(o => {
        const keys = searchKeys || [displayField];
        return keys.some(k => String(o[k] || '').toLowerCase().includes(searchTerm.toLowerCase()));
    });

    return (
        <div ref={wrapperRef} className="relative">
            <div className="flex gap-1">
                <input
                    type="text"
                    className="flex-1 bg-white border border-gray-300 rounded-lg px-4 py-3 text-sm font-bold uppercase outline-none focus:ring-2 focus:ring-moss-500"
                    placeholder={placeholder || `Pesquisar...`}
                    value={isOpen ? searchTerm : (selected ? String(selected[displayField]) : '')}
                    onFocus={() => { setIsOpen(true); setSearchTerm(''); setPageCursor(null); }}
                    onChange={e => { setSearchTerm(e.target.value); setPageCursor(null); setRemoteOptions([]); setNextCursor(null); }}
                    onKeyDown={onKeyDown}
                />
                {selectedId && (
                    <button type="button" onClick={() => onEdit(selectedId)} title="Editar" className="px-2 text-gray-400 hover:text-moss-700 border border-gray-200 rounded-lg hover:border-moss-400 transition-colors text-xs">✏️</button>
                )}
                <button type="button" onClick={onAdd} title="Novo" className="px-2 text-gray-400 hover:text-emerald-700 border border-gray-200 rounded-lg hover:border-emerald-400 transition-colors text-xs">+</button>
            </div>
            {isOpen && (
                <div role="listbox" className="absolute z-50 w-full mt-1 bg-white border border-gray-200 rounded-xl shadow-2xl overflow-hidden max-h-56 overflow-y-auto">
                    {remoteUnitId !== undefined && (loading || searchError || searchTerm.trim().length < 3) ? (
                        <div role="status" className="px-4 py-3 text-sm text-gray-500">
                            {searchError || (loading ? 'Pesquisando...' : 'Digite pelo menos 3 caracteres')}
                        </div>
                    ) : filtered.length === 0 ? (
                        <div className="px-4 py-3 text-sm text-gray-400 text-center">Nenhum resultado encontrado</div>
                    ) : filtered.map(o => (
                        <button type="button" role="option" aria-selected={o.id === selectedId} key={o.id} className={`block w-full text-left px-4 py-3 text-sm cursor-pointer hover:bg-moss-50 transition-colors font-semibold uppercase ${o.id === selectedId ? 'bg-moss-100 text-moss-800' : 'text-gray-700'}`}
                            onClick={() => { onSelect(o.id, o); setIsOpen(false); setSearchTerm(''); }}>
                            {String(o[displayField])}
                            {remoteUnitId !== undefined && <span className="block text-xs font-normal">{String((o as any).document || '')}</span>}
                        </button>
                    ))}
                    {remoteUnitId !== undefined && nextCursor && !loading && !searchError && (
                        <button type="button" className="w-full px-4 py-3 text-sm" onClick={() => setPageCursor(nextCursor)}>Próximos resultados</button>
                    )}
                </div>
            )}
        </div>
    );
}

const parseCurrencyBRL = (value: string): number => {
    if (!value) return 0;
    const clean = value.replace(/\./g, '').replace(',', '.');
    return parseFloat(clean) || 0;
};

const formatCurrencyBRL = (value: any): string => {
    if (value === undefined || value === null || value === '') return '';
    let valStr = typeof value === 'number' ? value.toFixed(2) : String(value);
    const cleanValue = valStr.replace(/\D/g, '');
    if (!cleanValue) return '';
    const numberValue = parseFloat(cleanValue) / 100;
    return new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(numberValue);
};

export interface AdmissionFormViewProps {
    formData: Admission;
    setFormData: React.Dispatch<React.SetStateAction<Admission>>;
    selectedClient: Client | null;
    setSelectedClient: React.Dispatch<React.SetStateAction<Client | null>>;
    selectedTitular: Client | null;
    setSelectedTitular: React.Dispatch<React.SetStateAction<Client | null>>;
    config: PortalConfig;
    isFormLocked: boolean;
    isDefaultSeries: boolean;
    handleToggleDefaultSeries: (checked: boolean) => void;
    handleStatusChange: (val: string) => void;
    handleUpdateScenario: (id: string, field: string, value: string) => void;
    handleFinalSubmit: () => void;
    handleSaveForDocuments: () => void;
    handlePrint: () => void;
    handleKeyDown: (e: React.KeyboardEvent<HTMLElement>) => void;
    handleExportDocx: (template: string, name: string) => void;
    handleDirectDocxUpload: (e: React.ChangeEvent<HTMLInputElement>) => void;
    onRequestExternalAction?: (type: string, data: Admission, id?: string, clientRole?: 'responsible' | 'holder') => void;
    setViewMode: React.Dispatch<React.SetStateAction<'LIST' | 'FORM' | 'PREVIEW'>>;
    selectedTemplateId: string;
    setSelectedTemplateId: React.Dispatch<React.SetStateAction<string>>;
    admissionTemplates: FormTemplate[];
    isVehicleModality: boolean;
    maxScenarios: number;
    showExportModal: boolean;
    setShowExportModal: React.Dispatch<React.SetStateAction<boolean>>;
    isExporting: boolean;
    formsWithDocx: any[];
    currentUserId?: string;
    bucketAttachmentCount: number;
    setBucketAttachmentCount: (count: number) => void;
    canMigrateLegacyAttachments: boolean;
    TemplatePreviewContent: React.ComponentType<{ template: FormTemplate; data: Admission; clientObj: Client | null }>;
}

const AdmissionFormView: React.FC<AdmissionFormViewProps> = ({
    formData, setFormData, selectedClient, setSelectedClient, selectedTitular, setSelectedTitular, config,
    isFormLocked, isDefaultSeries, handleToggleDefaultSeries,
    handleStatusChange, handleUpdateScenario, handleFinalSubmit, handleSaveForDocuments, handlePrint, handleKeyDown,
    handleExportDocx, handleDirectDocxUpload,
    onRequestExternalAction, setViewMode,
    selectedTemplateId, setSelectedTemplateId, admissionTemplates,
    isVehicleModality, maxScenarios,
    showExportModal, setShowExportModal, isExporting, formsWithDocx,
    currentUserId, bucketAttachmentCount, setBucketAttachmentCount, canMigrateLegacyAttachments, TemplatePreviewContent,
}) => {
    const docxInputRef = useRef<HTMLInputElement>(null);
    const { currentUser, temPermissao } = useSecurity();
    const [admTab, setAdmTab] = useState<'form' | 'whatsapp' | 'atendimentos' | 'documentos'>('form');
    const [documentsRefreshKey, setDocumentsRefreshKey] = useState(0);

    const handleSelectClientLocal = (id: string, option?: Client) => {
        setFormData(prev => ({ ...prev, clientId: id }));
        const client = option;
        setSelectedClient(client || null);
        if (client) setFormData(prev => ({ ...prev, clientName: client.name }));
    };

    const handleSelectTitularLocal = (id: string, option?: Client) => {
        setFormData(prev => ({ ...prev, titularClientId: id }));
        const client = option;
        setSelectedTitular(client || null);
    };

    const hasTitular = !!formData.titularClientId && !!selectedTitular;

    const mergedVal = (respVal: string, titVal: string) => {
        if (!hasTitular || !titVal) return respVal || '';
        if (!respVal) return titVal;
        return `${respVal} / ${titVal}`;
    };

    const getClientAddress = (c: Client | null) => {
        if (!c) return '';
        return [(c as any).address, (c as any).number ? `Nº ${(c as any).number}` : null, (c as any).district, (c as any).city, (c as any).state ? `(${(c as any).state})` : null, (c as any).cep ? `CEP: ${(c as any).cep}` : null].filter(Boolean).join(', ');
    };

    const p1 = parseCurrencyBRL(formData.parcela1 || '');
    const p2 = parseCurrencyBRL(formData.parcela2 || '');
    const subtotal = p1 + p2;
    const desc = parseCurrencyBRL(formData.desconto || '');
    const acres = parseCurrencyBRL(formData.acrescimo || '');
    const total = subtotal - desc + acres;
    const custosEcon = parseCurrencyBRL(formData.recalcScenarios?.[0]?.savings || '') * 0.2;
    const fmtBRL = (v: number) => v > 0 ? v.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '';
    const selectedModality = config.modalities.find(m => m.id === formData.modalityId);
    const selectedModalityLabel = selectedModality?.description || selectedModality?.type || '';

    return (
        <div className="flex flex-col h-full w-full animate-fade-in bg-gray-50/50">

            {/* WhatsApp / Formulário tab bar */}
            {formData.clientId && (
                <div className="flex border-b border-gray-200 bg-white shrink-0 no-print">
                    <button onClick={() => setAdmTab('form')} className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-colors ${admTab === 'form' ? 'border-moss-600 text-moss-700' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>📋 Formulário</button>
                    <button onClick={() => setAdmTab('whatsapp')} className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-colors flex items-center gap-1.5 ${admTab === 'whatsapp' ? 'border-green-600 text-green-700' : 'border-transparent text-gray-500 hover:text-gray-700'}`}><svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg> WhatsApp</button>
                    <button onClick={() => setAdmTab('atendimentos')} className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-colors flex items-center gap-1.5 ${admTab === 'atendimentos' ? 'border-green-600 text-green-700' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                        Atendimentos
                    </button>
                    <button onClick={() => setAdmTab('documentos')} className={`px-5 py-2.5 text-xs font-bold border-b-2 transition-colors ${admTab === 'documentos' ? 'border-emerald-600 text-emerald-700' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                        Documentos ({bucketAttachmentCount})
                    </button>
                </div>
            )}

            {admTab === 'whatsapp' && formData.clientId ? (
                <div className="flex-1 overflow-hidden">
                    <GotalkChatPanel clientId={formData.clientId} area="ADMISSAO" operatorName={currentUser?.name} />
                </div>
            ) : admTab === 'atendimentos' && formData.clientId ? (
                <div className="flex-1 overflow-hidden">
                    <GotalkAttendanceViewer clientId={formData.clientId} title="Atendimentos GoTalk — Admissão" />
                </div>
            ) : admTab === 'documentos' && formData.clientId ? (
                <div className="flex-1 overflow-y-auto p-4 md:p-8" data-form-container="true">
                    {!formData.id ? (
                        <section className="mx-auto max-w-3xl rounded-xl border border-amber-200 bg-amber-50 p-5">
                            <h3 className="font-bold text-amber-950">Salve a admissão para anexar documentos</h3>
                            <p className="mt-1 text-sm text-amber-900">Depois do primeiro salvamento, os arquivos serão enviados ao BucketdaInvicta, na pasta do cliente dentro da unidade da ficha.</p>
                            <Button variant="primary" className="!w-auto mt-4" onClick={handleSaveForDocuments}>Salvar admissão e continuar</Button>
                        </section>
                    ) : (
                        <div className="mx-auto max-w-7xl space-y-4">
                            <p className="rounded-lg border border-blue-100 bg-blue-50 p-3 text-sm text-blue-900">
                                Os documentos ficam vinculados à unidade de origem. Usuários da Matriz podem consultar documentos de todas as unidades; as demais unidades visualizam somente seus próprios anexos, conforme a permissão de leitura de Admissões.
                            </p>
                            <LegacyAdmissionAttachmentsPanel
                                admissionId={formData.id}
                                canMigrate={canMigrateLegacyAttachments}
                                refreshKey={documentsRefreshKey}
                                onMigrated={() => setDocumentsRefreshKey(value => value + 1)}
                            />
                            <ClientAttachmentsPanel
                                key={`${formData.id}-${documentsRefreshKey}`}
                                clientId={formData.clientId}
                                module="ADMISSION"
                                targetType="ADMISSION"
                                targetId={formData.id}
                                compact
                                allowUpload={!isFormLocked && (temPermissao('com_admissao:ALTERAR') || temPermissao('com_admissao:EDITAR'))}
                                onCountChange={setBucketAttachmentCount}
                            />
                            <div className="flex justify-end border-t pt-4 no-print">
                                <Button variant="ghost" className="!w-auto" onClick={() => setAdmTab('form')}>Voltar ao formulário</Button>
                            </div>
                        </div>
                    )}
                </div>
            ) : (
            <div className="flex-1 overflow-y-auto p-4 md:p-8" data-form-container="true">

            <div className="hidden print:block fixed inset-0 bg-white z-[9999] p-10 m-0">
                <style>{`@page { size: A4; margin: 0; }`}</style>
                {(() => {
                    const tpl = admissionTemplates.find(t => t.id === selectedTemplateId);
                    return tpl
                        ? <TemplatePreviewContent template={tpl} data={formData} clientObj={selectedClient} />
                        : <AdmissionPrintView data={formData} client={selectedClient} config={config} currentUserId={currentUserId} />;
                })()}
            </div>

            {isFormLocked && (
                <div className="mb-6 no-print">
                    <Alert type="warning" title="PROCESSO APROVADO — SOMENTE LEITURA">
                        <p className="text-sm mt-1">Este processo foi aprovado e está bloqueado para edição. Apenas a Auditoria pode devolver o processo alterando o status para <strong>Retorno Auditoria</strong>.</p>
                    </Alert>
                </div>
            )}

            {((formData.status === 'REPROVADA' || formData.status === 'RETORNO AUDITORIA') && (formData.auditCritique || (formData.auditHistory && formData.auditHistory.length > 0))) && (
                <ErrorBoundary label="Histórico de Auditoria">
                <div className="mb-6 no-print">
                    <div className="bg-red-50 border-2 border-red-300 rounded-xl p-5 shadow-sm">
                        <div className="flex items-center gap-2 mb-4">
                            <svg className="w-5 h-5 text-red-700" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" /></svg>
                            <h4 className="text-sm font-black text-red-800 uppercase tracking-wider">Processo Devolvido pela Auditoria</h4>
                        </div>
                        {(formData.auditHistory && formData.auditHistory.length > 0) ? (
                            <div className="space-y-4">
                                {formData.auditHistory.map((round: AuditRound) => {
                                    const isLastOpen = formData.auditHistory![formData.auditHistory!.length - 1].id === round.id && !round.response;
                                    return (
                                        <div key={round.id} className="border border-gray-200 rounded-lg overflow-hidden shadow-sm">
                                            <div className="bg-gray-100 px-3 py-1.5 flex justify-between items-center border-b border-gray-200">
                                                <span className="text-[9px] font-black text-gray-600 uppercase tracking-wider">Round {round.roundNumber}</span>
                                                <span className="text-[8px] text-gray-400">{new Date(round.critiqueDate).toLocaleString('pt-BR')}</span>
                                            </div>
                                            <div className="bg-red-50 px-3 py-2 border-b border-red-100">
                                                <p className="text-[9px] font-black text-red-600 uppercase tracking-wider mb-1">Critica - {round.critiquedBy || 'Auditoria'}</p>
                                                <p className="text-sm text-red-900 whitespace-pre-wrap leading-relaxed">{round.critique}</p>
                                            </div>
                                            {round.response ? (
                                                <div className="bg-blue-50 px-3 py-2">
                                                    <p className="text-[9px] font-black text-blue-600 uppercase tracking-wider mb-1">Resposta - {round.respondedBy || 'Comercial'} {round.responseDate ? '- ' + new Date(round.responseDate).toLocaleString('pt-BR') : ''}</p>
                                                    <p className="text-sm text-blue-900 whitespace-pre-wrap leading-relaxed">{round.response}</p>
                                                </div>
                                            ) : isLastOpen ? (
                                                <div className="bg-white px-3 py-3">
                                                    <label className="text-[9px] font-bold text-red-700 uppercase tracking-wider mb-1.5 block">Sua Resposta (obrigatorio para re-aprovar):</label>
                                                    <textarea
                                                        className="w-full border-2 border-red-200 rounded-lg p-3 text-sm outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100 min-h-[80px] resize-y bg-white placeholder-red-300"
                                                        placeholder="Descreva as correcoes realizadas e justificativas para cada critica apontada..."
                                                        value={formData.auditResponse || ''}
                                                        onChange={(e) => setFormData({ ...formData, auditResponse: e.target.value })}
                                                    />
                                                    {!formData.auditResponse?.trim() && <p className="text-[9px] text-red-500 font-bold mt-1 uppercase">* Preencha a resposta antes de alterar o status para Aprovada.</p>}
                                                </div>
                                            ) : (
                                                <div className="bg-yellow-50 px-3 py-2">
                                                    <p className="text-[9px] font-bold text-yellow-600 uppercase tracking-wider italic">Aguardando resposta do Comercial...</p>
                                                </div>
                                            )}
                                        </div>
                                    );
                                })}
                            </div>
                        ) : (
                            <>
                                <div className="bg-white border border-red-200 rounded-lg p-4 mb-4">
                                    <p className="text-[10px] font-bold text-red-600 uppercase tracking-wider mb-1">Criticas da Auditoria:</p>
                                    <p className="text-sm text-red-900 whitespace-pre-wrap leading-relaxed">{formData.auditCritique}</p>
                                </div>
                                <div>
                                    <label className="text-[10px] font-bold text-red-700 uppercase tracking-wider mb-1.5 block">Resposta do Comercial (obrigatorio para re-aprovar):</label>
                                    <textarea
                                        className="w-full border-2 border-red-200 rounded-lg p-3 text-sm outline-none focus:border-red-400 focus:ring-2 focus:ring-red-100 min-h-[80px] resize-y bg-white placeholder-red-300"
                                        placeholder="Descreva as correcoes realizadas e justificativas para cada critica apontada..."
                                        value={formData.auditResponse || ''}
                                        onChange={(e) => setFormData({ ...formData, auditResponse: e.target.value })}
                                    />
                                    {!formData.auditResponse?.trim() && <p className="text-[9px] text-red-500 font-bold mt-1 uppercase">* Preencha a resposta antes de alterar o status para Aprovada.</p>}
                                </div>
                            </>
                        )}
                    </div>
                </div>
                </ErrorBoundary>
            )}

            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4 no-print">
                <div>
                    <h2 className="text-3xl font-black text-gray-900 tracking-tighter uppercase italic">{formData.id ? 'Editar Ficha' : 'Nova Admissão'}</h2>
                    <p className="text-gray-500 text-sm font-medium">Preencha os dados do novo processo financeiro.</p>
                </div>
                <div className="flex items-center gap-3">
                    <Button variant="ghost" onClick={() => setViewMode('LIST')} className="!w-auto px-4 font-bold text-gray-500 hover:text-gray-900 transition-colors">Voltar para Lista</Button>
                    <div className="flex items-center bg-white rounded-lg shadow-sm border border-gray-200 p-1 gap-1">
                        <select
                            value={selectedTemplateId}
                            onChange={(e) => setSelectedTemplateId(e.target.value)}
                            className="text-xs font-bold text-gray-600 bg-gray-50 border border-gray-200 rounded-md px-3 py-2 outline-none focus:ring-2 focus:ring-moss-500 min-w-[200px]"
                        >
                            <option value="">Ficha Padrão</option>
                            {admissionTemplates.map(t => (
                                <option key={t.id} value={t.id}>{t.name}</option>
                            ))}
                        </select>
                        <div className="w-px h-6 bg-gray-200"></div>
                        <button onClick={() => setViewMode('PREVIEW')} className="px-4 py-2 text-xs font-bold text-moss-700 hover:bg-moss-50 rounded-md transition-all flex items-center gap-2">
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                            VISUALIZAR
                        </button>
                        <div className="w-px h-6 bg-gray-200"></div>
                        <button onClick={handlePrint} className="px-4 py-2 text-xs font-bold text-moss-700 hover:bg-moss-50 rounded-md transition-all flex items-center gap-2">
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 17h2a2 2 0 002-2v-4a2 2 0 00-2-2H5a2 2 0 00-2 2v4a2 2 0 002 2h2m2 4h6a2 2 0 002-2v-4a2 2 0 00-2-2H9a2 2 0 00-2 2v4a2 2 0 002 2zm8-12V5a2 2 0 00-2-2H9a2 2 0 00-2 2v4h10z" /></svg>
                            IMPRIMIR
                        </button>
                        <div className="w-px h-6 bg-gray-200"></div>
                        <button onClick={() => setShowExportModal(true)} className="px-4 py-2 text-xs font-bold text-blue-700 hover:bg-blue-50 rounded-md transition-all flex items-center gap-2">
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                            EXPORTAR WORD
                        </button>
                    </div>
                    <div className="bg-moss-800 text-white px-6 py-3 rounded-xl shadow-lg flex flex-col items-center min-w-[140px]">
                        <span className="text-[10px] font-bold text-moss-300 uppercase tracking-widest">Nº Contrato</span>
                        <span className="text-2xl font-black font-mono tracking-tighter">{formData.contractNumber || '----'}</span>
                    </div>
                </div>
            </div>

            <fieldset disabled={isFormLocked} className={`max-w-7xl mx-auto w-full no-print pb-20 ${isFormLocked ? 'opacity-75 pointer-events-auto' : ''}`}>

                <ErrorBoundary label="01. Dados do Cliente">
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                    <h3 className="text-sm font-bold text-moss-700 uppercase tracking-widest mb-4 flex items-center gap-2">01. Dados do Cliente</h3>
                    <div className="flex items-center gap-6 mb-4" role="radiogroup" aria-label="Tipo do Cliente">
                        <label className="flex items-center gap-2 cursor-pointer focus:ring-2 focus:ring-moss-500 rounded px-1 outline-none" role="radio" tabIndex={0} onKeyDown={handleKeyDown}><input type="radio" name="tipoCliente" value="RESPONSÁVEL" checked={formData.tipoCliente === 'RESPONSÁVEL' || !formData.tipoCliente} onChange={() => setFormData(prev => ({ ...prev, tipoCliente: 'RESPONSÁVEL' }))} className="text-moss-600 focus:ring-moss-500" tabIndex={-1} /><span className="text-xs font-bold">Responsável</span></label>
                        <label className="flex items-center gap-2 cursor-pointer focus:ring-2 focus:ring-moss-500 rounded px-1 outline-none" role="radio" tabIndex={0} onKeyDown={handleKeyDown}><input type="radio" name="tipoCliente" value="TITULAR" checked={formData.tipoCliente === 'TITULAR'} onChange={e => setFormData({ ...formData, tipoCliente: e.target.value as 'RESPONSÁVEL' | 'TITULAR' })} className="text-moss-600 focus:ring-moss-500" tabIndex={-1} /><span className="text-xs font-bold">Titular</span></label>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                        <div className="md:col-span-1">
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Unidade <span className="text-red-500">*</span></label>
                            <select className={`w-full border rounded-lg px-4 py-3 text-sm font-bold uppercase outline-none ${formData.unitId ? 'bg-emerald-50 border-emerald-300 text-emerald-700 focus:ring-emerald-500 focus:border-emerald-500' : 'bg-red-50 border-red-300 text-red-700 focus:ring-red-500 focus:border-red-500'}`} value={formData.unitId || ''} onChange={(e) => { const unit = config.units.find(u => u.id === e.target.value); setFormData(prev => ({ ...prev, unitId: e.target.value, parcela1: prev.parcela1 || unit?.taxaMinima || prev.parcela1 })); }} onKeyDown={handleKeyDown}>
                                <option value="">Selecione...</option>
                                {config.units.map(u => <option key={u.id} value={u.id}>{u.nomeFantasia || u.razaoSocial || u.cnpj}</option>)}
                            </select>
                            {!formData.unitId && <p className="text-[9px] text-red-500 font-bold mt-1.5 uppercase leading-tight">* Obrigatório</p>}
                        </div>
                        <div className="md:col-span-1">
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Status</label>
                            <select className={`w-full border rounded-lg px-4 py-3 text-sm font-bold uppercase outline-none ${isFormLocked ? 'bg-green-100 border-green-400 text-green-800 cursor-not-allowed' : 'bg-blue-50 border-blue-300 text-blue-700 focus:ring-blue-500 focus:border-blue-500'}`} value={formData.status} onChange={(e) => handleStatusChange(e.target.value)} onKeyDown={handleKeyDown} disabled={isFormLocked}>
                                <option value="PENDENTE">Pendente</option>
                                <option value="NEGOCIAÇÃO">Negociação</option>
                                <option value="APROVADA">Aprovada</option>
                                <option value="ANÁLISE CLIENTE">Análise Cliente</option>
                                <option value="REPROVADA">Reprovada</option>
                                <option value="RETORNO AUDITORIA">Retorno Auditoria</option>
                            </select>
                            {isFormLocked ? <p className="text-[9px] text-green-700 font-bold mt-1.5 uppercase leading-tight">Aprovado — somente leitura.</p> : <p className="text-[9px] text-blue-600 font-bold mt-1.5 uppercase leading-tight">* Muda após imprimir.</p>}
                        </div>
                        <div className="md:col-span-1">
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Origem</label>
                            <select className="w-full bg-purple-50 border border-purple-300 rounded-lg px-4 py-3 text-sm font-bold uppercase text-purple-700 focus:ring-purple-500 focus:border-purple-500 outline-none" value={formData.originType || ''} onChange={(e) => setFormData({ ...formData, originType: e.target.value })} onKeyDown={handleKeyDown}>
                                <option value="">Selecione...</option>
                                <option value="PROSPECÇÃO">Prospecção</option>
                                <option value="PROPAGANDA">Propaganda</option>
                                <option value="RECUPERAÇÃO">Recuperação</option>
                            </select>
                        </div>
                        <div className="md:col-span-2">
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Nome ou Razão Social</label>
                            <SmartSelect<Client>
                                options={selectedClient ? [selectedClient] : []}
                                remoteUnitId={currentUser?.currentUnitId || ''}
                                selectedId={formData.clientId}
                                onSelect={handleSelectClientLocal}
                                onAdd={() => onRequestExternalAction?.('CLIENT', formData)}
                                onEdit={(id) => onRequestExternalAction?.('CLIENT', formData, id)}
                                displayField="name"
                                searchKeys={['name', 'document', 'phone'] as any}
                                placeholder="Pesquise por nome, CPF/CNPJ ou telefone..."
                                onKeyDown={handleKeyDown}
                            />
                        </div>
                        {(formData.tipoCliente === 'TITULAR' || !!formData.titularClientId) && (
                            <div className="md:col-span-2">
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Titular</label>
                                <SmartSelect<Client>
                                    options={selectedTitular ? [selectedTitular] : []}
                                    remoteUnitId={currentUser?.currentUnitId || ''}
                                    selectedId={formData.titularClientId || ''}
                                    onSelect={handleSelectTitularLocal}
                                    onAdd={() => onRequestExternalAction?.('CLIENT', formData, undefined, 'holder')}
                                    onEdit={(id) => onRequestExternalAction?.('CLIENT', formData, id, 'holder')}
                                    displayField="name"
                                    searchKeys={['name', 'document', 'phone'] as any}
                                    placeholder="Pesquise o Titular por nome, CPF/CNPJ ou telefone..."
                                    onKeyDown={handleKeyDown}
                                />
                            </div>
                        )}
                        {hasTitular && (
                            <div className="md:col-span-5"><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Nome (Responsável / Titular)</label><input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-sm font-semibold text-gray-700 uppercase" readOnly value={mergedVal(selectedClient?.name || '', selectedTitular?.name || '')} /></div>
                        )}
                        <div className="md:col-span-2"><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">CPF / CNPJ</label><input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-sm font-semibold text-gray-700 uppercase" readOnly value={mergedVal(selectedClient?.document || '', selectedTitular?.document || '')} /></div>
                        <div className="md:col-span-1"><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">RG</label><input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-sm font-semibold text-gray-700 uppercase" readOnly value={mergedVal(selectedClient?.rg || '', selectedTitular?.rg || '')} /></div>
                        <div className="md:col-span-1"><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Telefone</label><input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-sm font-semibold text-gray-700 uppercase" readOnly value={mergedVal(selectedClient?.phone || '', selectedTitular?.phone || '')} /></div>
                        <div className="md:col-span-1"><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Profissão</label><input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-sm font-semibold text-gray-700 uppercase" readOnly value={mergedVal((selectedClient as any)?.profession || '', (selectedTitular as any)?.profession || '')} /></div>
                        <div className="md:col-span-1"><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Estado Civil</label><input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-sm font-semibold text-gray-700 uppercase" readOnly value={mergedVal((selectedClient as any)?.maritalStatus || '', (selectedTitular as any)?.maritalStatus || '')} /></div>
                        <div className="md:col-span-1"><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Data de Nasc.</label><input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-sm font-semibold text-gray-700" readOnly value={(selectedClient as any)?.birthDate ? new Date((selectedClient as any).birthDate).toLocaleDateString('pt-BR') : ''} /></div>
                        <div className="md:col-span-3"><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Endereço</label><input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-sm font-semibold text-gray-700 uppercase" readOnly value={mergedVal(getClientAddress(selectedClient), getClientAddress(selectedTitular))} /></div>
                        <div className="md:col-span-2"><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">E-mail</label><input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-sm font-semibold text-gray-700" readOnly value={mergedVal((selectedClient as any)?.email || '', (selectedTitular as any)?.email || '')} /></div>
                    </div>
                </div>
                </ErrorBoundary>

                <ErrorBoundary label="02. Informações da Negociação">
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                    <h3 className="text-sm font-bold text-moss-700 uppercase tracking-widest mb-4 flex items-center gap-2">02. Informações da Negociação</h3>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <div><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Banco</label><SmartSelect<Bank> options={config.banks} selectedId={formData.bankId} onSelect={(id) => setFormData({ ...formData, bankId: id })} onAdd={() => onRequestExternalAction?.('BANK', formData)} onEdit={(id) => onRequestExternalAction?.('BANK', formData, id)} displayField="name" onKeyDown={handleKeyDown} /></div>
                        <div><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Consultor</label><SmartSelect<Collaborator> options={config.collaborators} selectedId={formData.collaboratorId} onSelect={(id) => setFormData({ ...formData, collaboratorId: id })} onAdd={() => onRequestExternalAction?.('COLLAB', formData)} onEdit={(id) => onRequestExternalAction?.('COLLAB', formData, id)} displayField="name" onKeyDown={handleKeyDown} /></div>
                        <div><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Modalidade</label><select className="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-sm font-bold uppercase" value={formData.modalityId} onChange={(e) => setFormData({ ...formData, modalityId: e.target.value })} onKeyDown={handleKeyDown}><option value="">Selecione...</option>{config.modalities.map(m => <option key={m.id} value={m.id}>{m.description || m.type}</option>)}</select></div>
                        <div>
                            <div className="flex justify-between items-center mb-1.5"><label className="block text-xs font-bold text-gray-500 uppercase ml-1">Série</label><label className="flex items-center gap-1.5 cursor-pointer group"><input type="checkbox" className="h-3.5 w-3.5 text-moss-600 rounded focus:ring-moss-500 border-gray-300" checked={isDefaultSeries} onChange={(e) => handleToggleDefaultSeries(e.target.checked)} tabIndex={-1} /><span className={`text-[10px] font-bold uppercase transition-colors ${isDefaultSeries ? 'text-moss-700' : 'text-gray-400 group-hover:text-gray-600'}`}>Padrão</span></label></div>
                            <select className="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-sm font-bold uppercase" value={formData.seriesId} onChange={(e) => setFormData({ ...formData, seriesId: e.target.value })} tabIndex={-1}><option value="">Selecione...</option>{config.series.map(s => <option key={s.id} value={s.id}>{s.sigla} - {s.description}</option>)}</select>
                        </div>
                        <div className="md:col-span-2">
                            <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Indicação / Captação</label>
                            <div className="flex items-center gap-4 bg-gray-50 p-3 rounded-lg border border-gray-200 h-[50px]">
                                <label className="flex items-center gap-2 cursor-pointer focus:ring-2 focus:ring-moss-500 rounded px-1 outline-none" role="radio" tabIndex={0} onKeyDown={handleKeyDown}><input type="radio" name="indication" value="INDICAÇÃO" checked={formData.indicationType === 'INDICAÇÃO' || formData.indicationType === 'INDICACAO'} onChange={e => setFormData({ ...formData, indicationType: e.target.value })} className="text-moss-600 focus:ring-moss-500" tabIndex={-1} /><span className="text-xs font-bold">Indicação</span></label>
                                <label className="flex items-center gap-2 cursor-pointer focus:ring-2 focus:ring-moss-500 rounded px-1 outline-none" role="radio" tabIndex={0} onKeyDown={handleKeyDown}><input type="radio" name="indication" value="RÁDIO" checked={formData.indicationType === 'RÁDIO' || formData.indicationType === 'RADIO'} onChange={e => setFormData({ ...formData, indicationType: e.target.value })} className="text-moss-600 focus:ring-moss-500" tabIndex={-1} /><span className="text-xs font-bold">Rádio</span></label>
                                <label className="flex items-center gap-2 cursor-pointer focus:ring-2 focus:ring-moss-500 rounded px-1 outline-none" role="radio" tabIndex={0} onKeyDown={handleKeyDown}><input type="radio" name="indication" value="OUTRO" checked={formData.indicationType !== 'INDICAÇÃO' && formData.indicationType !== 'INDICACAO' && formData.indicationType !== 'RÁDIO' && formData.indicationType !== 'RADIO'} onChange={() => setFormData({ ...formData, indicationType: '' })} className="text-moss-600 focus:ring-moss-500" tabIndex={-1} /><span className="text-xs font-bold">Outro</span></label>
                                {formData.indicationType !== 'INDICAÇÃO' && formData.indicationType !== 'INDICACAO' && formData.indicationType !== 'RÁDIO' && formData.indicationType !== 'RADIO' && (<input type="text" placeholder="Qual?" className="flex-1 bg-white border border-gray-300 rounded px-2 py-1 text-xs font-bold uppercase outline-none focus:ring-1 focus:ring-moss-500" value={formData.indicationType} onChange={e => setFormData({ ...formData, indicationType: e.target.value.toUpperCase() })} onKeyDown={handleKeyDown} autoFocus />)}
                            </div>
                        </div>
                    </div>
                </div>
                </ErrorBoundary>

                {isVehicleModality && (
                    <ErrorBoundary label="03. Informações do Veículo">
                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6 animate-fade-in-down">
                        <h3 className="text-sm font-bold text-moss-700 uppercase tracking-widest mb-4 flex items-center gap-2">03. Informações do Veículo</h3>
                        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                            <Input label="Marca" value={formData.vehicleBrand || ''} onChange={e => setFormData({ ...formData, vehicleBrand: e.target.value.toUpperCase() })} placeholder="Ex: FIAT" onKeyDown={handleKeyDown} />
                            <Input label="Modelo" value={formData.vehicleModel || ''} onChange={e => setFormData({ ...formData, vehicleModel: e.target.value.toUpperCase() })} placeholder="Ex: ARGO" onKeyDown={handleKeyDown} />
                            <Input label="Cor" value={formData.vehicleColor || ''} onChange={e => setFormData({ ...formData, vehicleColor: e.target.value.toUpperCase() })} placeholder="Ex: BRANCO" onKeyDown={handleKeyDown} />
                            <Input label="Ano" value={formData.vehicleYear || ''} onChange={e => setFormData({ ...formData, vehicleYear: e.target.value })} placeholder="Ex: 2022" onKeyDown={handleKeyDown} />
                            <Input label="Placa" value={formData.vehiclePlate || ''} onChange={e => setFormData({ ...formData, vehiclePlate: e.target.value.toUpperCase() })} placeholder="Ex: ABC-1234" onKeyDown={handleKeyDown} />
                            <div className="md:col-span-2"><Input label="Chassi" value={formData.vehicleChassis || ''} onChange={e => setFormData({ ...formData, vehicleChassis: e.target.value.toUpperCase() })} placeholder="Digite o número do chassi..." onKeyDown={handleKeyDown} /></div>
                            <Input label="Renavam" value={formData.vehicleRenavam || ''} onChange={e => setFormData({ ...formData, vehicleRenavam: e.target.value })} placeholder="Digite o renavam..." onKeyDown={handleKeyDown} />
                        </div>
                    </div>
                    </ErrorBoundary>
                )}

                <ErrorBoundary label="04. Dívida Atual">
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
                    <h3 className="text-sm font-bold text-moss-700 uppercase tracking-widest mb-4 flex items-center gap-2">04. Dívida Atual</h3>
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                        <Input label="Parcelas Totais" type="number" value={formData.totalInstallments} onChange={e => setFormData({ ...formData, totalInstallments: e.target.value })} onKeyDown={handleKeyDown} />
                        <Input label="Parcelas Pagas" type="number" value={formData.paidInstallments} onChange={e => setFormData({ ...formData, paidInstallments: e.target.value })} onKeyDown={handleKeyDown} />
                        <Input label="Em Atraso" type="number" value={formData.overdueInstallments} onChange={e => setFormData({ ...formData, overdueInstallments: e.target.value })} onKeyDown={handleKeyDown} />
                        <Input label="Valor Financiado (R$)" type="text" value={formData.financedAmount} onChange={e => setFormData({ ...formData, financedAmount: formatCurrencyBRL(e.target.value) })} placeholder="0,00" onKeyDown={handleKeyDown} />
                        <div className="md:col-span-2"><Input label="Valor da Parcela (R$)" type="text" value={formData.installmentValue} onChange={e => setFormData({ ...formData, installmentValue: formatCurrencyBRL(e.target.value) })} placeholder="0,00" onKeyDown={handleKeyDown} /></div>
                        <div><Input label="Dia Vencimento" type="number" value={formData.dueDay} onChange={e => setFormData({ ...formData, dueDay: e.target.value })} placeholder="Ex: 10" onKeyDown={handleKeyDown} /></div>
                        <div><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Tipo Pagamento</label><select className="w-full bg-white border border-gray-300 rounded-lg px-4 py-3 text-sm font-bold uppercase" value={formData.paymentType} onChange={(e) => setFormData({ ...formData, paymentType: e.target.value })} onKeyDown={handleKeyDown}><option value="">Selecione...</option>{(config.paymentTypes || []).map(t => <option key={t} value={t}>{t}</option>)}</select></div>
                    </div>
                </div>
                </ErrorBoundary>

                <ErrorBoundary label="Recálculo e Tabela de Serviços">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                        <div className="bg-emerald-800 px-5 py-3"><h3 className="text-[10px] font-black text-white uppercase tracking-widest">Informações do Recálculo</h3></div>
                        <div className="p-5 space-y-4">
                            <Input label="Parcelas a Pagar" type="number" value={formData.recalcScenarios?.[0]?.installmentsToPay || ''} onChange={e => { if (formData.recalcScenarios?.[0]) handleUpdateScenario(formData.recalcScenarios?.[0].id, 'installmentsToPay', e.target.value); }} onKeyDown={handleKeyDown} />
                            <Input label="Dívida Original (R$)" value={formData.recalcScenarios?.[0]?.originalDebt || ''} onChange={e => { if (formData.recalcScenarios?.[0]) handleUpdateScenario(formData.recalcScenarios?.[0].id, 'originalDebt', e.target.value); }} placeholder="0,00" onKeyDown={handleKeyDown} />
                            <Input label="Parcela Recálculo (R$)" value={formData.recalcScenarios?.[0]?.installmentValue || ''} onChange={e => { if (formData.recalcScenarios?.[0]) handleUpdateScenario(formData.recalcScenarios?.[0].id, 'installmentValue', e.target.value); }} placeholder="0,00" onKeyDown={handleKeyDown} />
                            <Input label="Dívida Recálculo (R$)" value={formData.recalcScenarios?.[0]?.newDebt || ''} onChange={e => { if (formData.recalcScenarios?.[0]) handleUpdateScenario(formData.recalcScenarios?.[0].id, 'newDebt', e.target.value); }} placeholder="0,00" onKeyDown={handleKeyDown} />
                            <Input label="Economia (R$)" value={formData.recalcScenarios?.[0]?.savings || ''} onChange={e => { if (formData.recalcScenarios?.[0]) handleUpdateScenario(formData.recalcScenarios?.[0].id, 'savings', e.target.value); }} placeholder="0,00" onKeyDown={handleKeyDown} />
                            <Input label="Dia Vencimento" type="number" value={formData.recalcScenarios?.[0]?.dueDay || ''} onChange={e => { if (formData.recalcScenarios?.[0]) handleUpdateScenario(formData.recalcScenarios?.[0].id, 'dueDay', e.target.value); }} placeholder="Ex: 10" onKeyDown={handleKeyDown} />
                            <div>
                                <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Modalidade</label>
                                <input type="text" className="w-full bg-gray-50 border border-gray-200 rounded-lg px-4 py-3 text-sm font-bold text-gray-700 uppercase" readOnly value={selectedModalityLabel} />
                            </div>
                        </div>
                    </div>
                    <div className="flex flex-col gap-6">
                        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                            <div className="bg-emerald-800 px-5 py-3"><h3 className="text-[10px] font-black text-white uppercase tracking-widest">Tabela de Serviços</h3></div>
                            <div className="overflow-x-auto">
                                <table className="w-full text-xs border-collapse operational-grid" data-grid-typography="preserve">
                                    <thead>
                                        <tr className="bg-gray-50 text-gray-500 uppercase font-bold text-[10px]">
                                            <th className="px-3 py-2 text-left border border-gray-200 w-10">Und</th>
                                            <th className="px-3 py-2 text-left border border-gray-200">Descrição</th>
                                            <th className="px-3 py-2 text-right border border-gray-200 w-24">Unitário</th>
                                            <th className="px-3 py-2 text-right border border-gray-200 w-24">Total</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr className="border-b border-gray-100">
                                            <td className="px-3 py-2 border border-gray-200 text-center">UN</td>
                                            <td className="px-3 py-2 border border-gray-200 font-bold uppercase">Gestão</td>
                                            <td className="px-3 py-2 border border-gray-200">
                                                <div className="flex items-center gap-1"><span className="text-gray-400 font-bold">R$</span><input type="text" className="flex-1 bg-white border border-gray-200 rounded px-2 py-1 text-right text-gray-800 font-bold outline-none focus:ring-1 focus:ring-emerald-500 min-w-0" value={formData.parcela1 || ''} onChange={e => setFormData({ ...formData, parcela1: formatCurrencyBRL(e.target.value) })} placeholder="0,00" onKeyDown={handleKeyDown} /></div>
                                            </td>
                                            <td className="px-3 py-2 border border-gray-200 text-right font-bold text-gray-700">R$ {formData.parcela1 || ''}</td>
                                        </tr>
                                        <tr className="border-b border-gray-100 bg-gray-50/50">
                                            <td className="px-3 py-2 border border-gray-200 text-center">UN</td>
                                            <td className="px-3 py-2 border border-gray-200 font-bold uppercase">Custos Finais da Economia</td>
                                            <td className="px-3 py-2 border border-gray-200 text-right text-gray-500">20%</td>
                                            <td className="px-3 py-2 border border-gray-200 text-right font-bold text-gray-700">{custosEcon > 0 ? `R$ ${fmtBRL(custosEcon)}` : 'Variável'}</td>
                                        </tr>
                                        <tr className="border-b border-gray-100">
                                            <td className="px-3 py-2 border border-gray-200 text-center">UN</td>
                                            <td className="px-3 py-2 border border-gray-200 font-bold uppercase">Custos Iniciais</td>
                                            <td className="px-3 py-2 border border-gray-200">
                                                <div className="flex items-center gap-1"><span className="text-gray-400 font-bold">R$</span><input type="text" className="flex-1 bg-white border border-gray-200 rounded px-2 py-1 text-right text-gray-800 font-bold outline-none focus:ring-1 focus:ring-emerald-500 min-w-0" value={formData.parcela2 || ''} onChange={e => setFormData({ ...formData, parcela2: formatCurrencyBRL(e.target.value) })} placeholder="0,00" onKeyDown={handleKeyDown} /></div>
                                            </td>
                                            <td className="px-3 py-2 border border-gray-200 text-right font-bold text-gray-700">R$ {formData.parcela2 || ''}</td>
                                        </tr>
                                        <tr className="bg-gray-50 text-gray-600">
                                            <td colSpan={2} className="border border-gray-200"></td>
                                            <td className="px-3 py-2 border border-gray-200 text-right font-bold uppercase text-[10px]">Subtotal:</td>
                                            <td className="px-3 py-2 border border-gray-200 text-right font-bold">R$ {fmtBRL(subtotal)}</td>
                                        </tr>
                                        <tr className="bg-gray-50 text-gray-600">
                                            <td colSpan={2} className="border border-gray-200"></td>
                                            <td className="px-3 py-2 border border-gray-200 text-right font-bold uppercase text-[10px]">
                                                <div className="flex items-center justify-end gap-1 flex-wrap">
                                                    <span>Desc. R$</span>
                                                    <input type="text" className="w-16 bg-white border border-gray-200 rounded px-1 py-0.5 text-right text-gray-800 font-bold outline-none focus:ring-1 focus:ring-emerald-500" value={formData.desconto || ''} onChange={e => setFormData({ ...formData, desconto: formatCurrencyBRL(e.target.value) })} placeholder="0,00" onKeyDown={handleKeyDown} />
                                                    <span>/ Acres. R$</span>
                                                    <input type="text" className="w-16 bg-white border border-gray-200 rounded px-1 py-0.5 text-right text-gray-800 font-bold outline-none focus:ring-1 focus:ring-emerald-500" value={formData.acrescimo || ''} onChange={e => setFormData({ ...formData, acrescimo: formatCurrencyBRL(e.target.value) })} placeholder="0,00" onKeyDown={handleKeyDown} />
                                                </div>
                                            </td>
                                            <td className="px-3 py-2 border border-gray-200 text-right font-bold text-[10px]">
                                                {desc > 0 && <span className="text-red-600">-R$ {fmtBRL(desc)} </span>}
                                                {acres > 0 && <span className="text-emerald-700">+R$ {fmtBRL(acres)}</span>}
                                                {!desc && !acres && <span className="text-gray-400">R$0,00</span>}
                                            </td>
                                        </tr>
                                        <tr className="bg-emerald-50 font-black text-emerald-900">
                                            <td colSpan={2} className="border border-gray-200"></td>
                                            <td className="px-3 py-2 border border-gray-200 text-right uppercase text-[10px]">Total:</td>
                                            <td className="px-3 py-2 border border-gray-200 text-right">R$ {fmtBRL(total)}</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
                            <div className="bg-emerald-800 px-5 py-3"><h3 className="text-[10px] font-black text-white uppercase tracking-widest">Outras Informações</h3></div>
                            <div className="p-5 space-y-4">
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Taxa Administrativa (R$)</label>
                                    <div className="flex items-center gap-2">
                                        <input
                                            type="text"
                                            readOnly
                                            value={config.units.find(u => u.id === formData.unitId)?.taxaMinima || ''}
                                            className="flex-1 bg-gray-100 border border-gray-200 rounded-lg px-4 py-3 text-sm font-bold text-gray-600 cursor-default"
                                            placeholder="—"
                                            title="Valor configurado na Unidade (Configurações → Unidades)"
                                        />
                                        <span className="text-[9px] text-gray-400 font-bold uppercase leading-tight whitespace-nowrap">Da Unidade</span>
                                    </div>
                                </div>
                                <Input label="Valor Parcela 01 (R$)" value={formData.parcela1 || ''} onChange={e => setFormData({ ...formData, parcela1: formatCurrencyBRL(e.target.value) })} placeholder="0,00" onKeyDown={handleKeyDown} />
                                <Input label="Valor Boletos (R$)" value={formData.taxaCobranca || ''} onChange={e => setFormData({ ...formData, taxaCobranca: formatCurrencyBRL(e.target.value) })} placeholder="0,00" onKeyDown={handleKeyDown} />
                                <div><label className="block text-xs font-bold text-gray-500 uppercase mb-1.5 ml-1">Anotações</label><textarea data-scenario-idx={99} data-field-idx={0} className="w-full h-[80px] bg-white border border-gray-300 rounded-lg p-3 text-xs font-semibold text-gray-700 outline-none focus:ring-2 focus:ring-emerald-500 transition-all resize-none" placeholder="Observações importantes..." value={formData.otherInfo1} onChange={e => setFormData({ ...formData, otherInfo1: e.target.value })} onKeyDown={handleKeyDown} /></div>
                            </div>
                        </div>
                    </div>
                </div>
                </ErrorBoundary>

                <ErrorBoundary label="Planejamento de Quitação">
                <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6 bg-emerald-50/20">
                    <div className="flex justify-between items-center mb-6">
                        <h3 className="text-sm font-bold text-emerald-800 uppercase tracking-widest mb-0 flex items-center gap-2">Planejamento de Quitação</h3>
                        <button
                            title={!formData.bankId ? 'Selecione um Banco para habilitar cenários' : formData.recalcScenarios.length >= maxScenarios ? `Máximo de ${maxScenarios} cenário(s) para este banco` : '+ Adicionar Cenário'}
                            disabled={!formData.bankId || formData.recalcScenarios.length >= maxScenarios}
                            onClick={() => setFormData(prev => ({ ...prev, recalcScenarios: [...prev.recalcScenarios, { id: 'sc-' + Date.now(), label: 'Recálculo %', installmentsToPay: '', originalDebt: '', installmentValue: '', newDebt: '', savings: '', dueDay: '' }] }))}
                            className={`!w-auto py-2 px-4 text-xs font-bold rounded-lg border transition-colors ${!formData.bankId || formData.recalcScenarios.length >= maxScenarios ? 'bg-gray-100 border-gray-200 text-gray-400 cursor-not-allowed' : 'bg-white border-gray-300 text-gray-700 hover:bg-emerald-50 hover:border-emerald-400 hover:text-emerald-700'}`}
                        >+ Adicionar Cenário</button>
                    </div>
                    <div className="overflow-x-auto">
                        <table className="w-full border-collapse operational-grid" data-grid-typography="preserve">
                            <thead>
                                <tr className="bg-emerald-800 text-white text-[10px] uppercase tracking-widest text-left">
                                    <th className="p-4 border border-emerald-900 font-black min-w-[200px]">Informações</th>
                                    {formData.recalcScenarios.map((s) => (
                                        <th key={s.id} className="p-4 border border-emerald-900 min-w-[180px]">
                                            <div className="flex items-center gap-2">
                                                <input className="bg-transparent border-none outline-none font-black text-center w-full focus:ring-0 text-white text-xs" value={s.label} onChange={e => handleUpdateScenario(s.id, 'label', e.target.value)} onKeyDown={handleKeyDown} />
                                                {formData.recalcScenarios.length > 1 && <button onClick={() => setFormData(prev => ({ ...prev, recalcScenarios: prev.recalcScenarios.filter(rs => rs.id !== s.id) }))} className="text-white/50 hover:text-red-300">✕</button>}
                                            </div>
                                        </th>
                                    ))}
                                </tr>
                            </thead>
                            <tbody className="bg-white text-sm font-bold text-gray-700">
                                <tr><td className="p-4 border border-gray-200 bg-gray-50 uppercase text-[11px] text-gray-500">Parcelas a pagar:</td>{formData.recalcScenarios.map((s, colIdx) => (<td key={s.id} className="p-3 border border-gray-200"><input data-scenario-idx={colIdx} data-field-idx={0} className="w-full bg-white border border-gray-200 rounded-md p-2 text-center text-gray-800 font-bold outline-none focus:ring-2 focus:ring-emerald-500 transition-all" value={s.installmentsToPay} onChange={e => handleUpdateScenario(s.id, 'installmentsToPay', e.target.value)} onKeyDown={handleKeyDown} /></td>))}</tr>
                                <tr><td className="p-4 border border-gray-200 bg-gray-50 uppercase text-[11px] text-gray-500">Dívida Original (R$):</td>{formData.recalcScenarios.map((s, colIdx) => (<td key={s.id} className="p-3 border border-gray-200"><input data-scenario-idx={colIdx} data-field-idx={1} className="w-full bg-white border border-gray-200 rounded-md p-2 text-center text-gray-800 font-bold outline-none focus:ring-2 focus:ring-emerald-500 transition-all" value={s.originalDebt} onChange={e => handleUpdateScenario(s.id, 'originalDebt', e.target.value)} onKeyDown={handleKeyDown} /></td>))}</tr>
                                <tr><td className="p-4 border border-gray-200 bg-gray-50 uppercase text-[11px] text-gray-500">Parc. Recalculada (R$):</td>{formData.recalcScenarios.map((s, colIdx) => (<td key={s.id} className="p-3 border border-gray-200"><input data-scenario-idx={colIdx} data-field-idx={2} className="w-full bg-white border border-gray-200 rounded-md p-2 text-center text-gray-800 font-bold outline-none focus:ring-2 focus:ring-emerald-500 transition-all bg-emerald-50/30 text-emerald-800" value={s.installmentValue} onChange={e => handleUpdateScenario(s.id, 'installmentValue', e.target.value)} onKeyDown={handleKeyDown} /></td>))}</tr>
                                <tr><td className="p-4 border border-gray-200 bg-gray-50 uppercase text-[11px] text-gray-500">Dívida Recalculada (R$):</td>{formData.recalcScenarios.map((s, colIdx) => (<td key={s.id} className="p-3 border border-gray-200"><input data-scenario-idx={colIdx} data-field-idx={3} className="w-full bg-white border border-gray-200 rounded-md p-2 text-center text-gray-800 font-bold outline-none focus:ring-2 focus:ring-emerald-500 transition-all bg-emerald-50/30 text-emerald-800" value={s.newDebt} onChange={e => handleUpdateScenario(s.id, 'newDebt', e.target.value)} onKeyDown={handleKeyDown} /></td>))}</tr>
                                <tr><td className="p-4 border border-gray-200 bg-gray-50 uppercase text-[11px] text-gray-500">Economia (R$):</td>{formData.recalcScenarios.map((s, colIdx) => (<td key={s.id} className="p-3 border border-gray-200"><input data-scenario-idx={colIdx} data-field-idx={4} className="w-full bg-emerald-800 border border-gray-200 rounded-md p-2 text-center text-white font-bold outline-none focus:ring-2 focus:ring-emerald-500 transition-all shadow-inner" value={s.savings} onChange={e => handleUpdateScenario(s.id, 'savings', e.target.value)} onKeyDown={handleKeyDown} /></td>))}</tr>
                                <tr><td className="p-4 border border-gray-200 bg-gray-50 uppercase text-[11px] text-gray-500">Dia Vencimento:</td>{formData.recalcScenarios.map((s, colIdx) => (<td key={s.id} className="p-3 border border-gray-200"><input data-scenario-idx={colIdx} data-field-idx={5} className="w-full bg-white border border-gray-200 rounded-md p-2 text-center text-gray-800 font-bold outline-none focus:ring-2 focus:ring-emerald-500 transition-all" value={s.dueDay} onChange={e => handleUpdateScenario(s.id, 'dueDay', e.target.value)} onKeyDown={handleKeyDown} /></td>))}</tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                </ErrorBoundary>

            </fieldset>

            <div className="flex justify-end gap-4 no-print pb-10 mt-4 border-t pt-8 max-w-7xl mx-auto w-full">
                <Button variant="ghost" className="!w-auto px-8 py-4" onClick={() => setViewMode('LIST')}>CANCELAR</Button>
                {!isFormLocked && <Button variant="primary" className="!w-auto px-12 py-4 bg-moss-700" onClick={handleFinalSubmit}>SALVAR PROCESSO</Button>}
            </div>

            </div>
            )}

            <input ref={docxInputRef} type="file" accept=".docx,.doc" className="hidden" onChange={handleDirectDocxUpload} />

            {showExportModal && (
                <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 no-print">
                    <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden">
                        <div className="bg-blue-600 px-6 py-4 flex items-center justify-between">
                            <h3 className="text-white font-bold text-lg flex items-center gap-2">
                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                Exportar para Word
                            </h3>
                            <button onClick={() => setShowExportModal(false)} className="text-white/80 hover:text-white"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button>
                        </div>
                        <div className="p-6 space-y-4">
                            {formsWithDocx.length > 0 && (
                                <div>
                                    <h4 className="text-sm font-bold text-gray-700 uppercase mb-3">Templates Salvos</h4>
                                    <div className="space-y-2 max-h-48 overflow-y-auto">
                                        {formsWithDocx.map((form: any) => (
                                            <button key={form.id} disabled={isExporting} onClick={() => handleExportDocx(form.docxTemplate, form.name)} className="w-full text-left px-4 py-3 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-all flex items-center gap-3">
                                                <svg className="w-8 h-8 text-blue-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                                <div><p className="font-bold text-sm text-gray-800">{form.name}</p><p className="text-xs text-gray-500">Template com variáveis</p></div>
                                            </button>
                                        ))}
                                    </div>
                                    <div className="border-t border-gray-200 my-4"></div>
                                </div>
                            )}
                            <div>
                                <h4 className="text-sm font-bold text-gray-700 uppercase mb-3">Enviar Template .docx</h4>
                                <p className="text-xs text-gray-500 mb-3">Envie um arquivo .docx com variáveis entre {'{{ }}'} para preencher automaticamente com os dados desta admissão.</p>
                                <button disabled={isExporting} onClick={() => docxInputRef.current?.click()} className="w-full px-4 py-4 border-2 border-dashed border-blue-300 rounded-xl text-blue-600 hover:bg-blue-50 hover:border-blue-400 transition-all flex flex-col items-center gap-2">
                                    {isExporting ? (<span className="text-sm font-bold">Gerando documento...</span>) : (<><svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg><span className="text-sm font-bold">Clique para selecionar arquivo .docx</span></>)}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default AdmissionFormView;

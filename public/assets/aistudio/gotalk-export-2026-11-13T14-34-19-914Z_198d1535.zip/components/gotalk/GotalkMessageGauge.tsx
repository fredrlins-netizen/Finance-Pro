import React, { useEffect, useRef, useState } from 'react';
import { useGotalk } from '../../contexts/GotalkContext';

const AUTO_DISMISS_MS = 10000;

const GotalkMessageGauge: React.FC = () => {
  const { newMessages, dismissNewMessages, openClient } = useGotalk();
  const [visible, setVisible] = useState(false);
  const [progress, setProgress] = useState(100);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startRef = useRef<number>(0);

  const clearTimer = () => {
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
  };

  const startTimer = () => {
    clearTimer();
    startRef.current = Date.now();
    setProgress(100);
    timerRef.current = setInterval(() => {
      const elapsed = Date.now() - startRef.current;
      const pct = Math.max(0, 100 - (elapsed / AUTO_DISMISS_MS) * 100);
      setProgress(pct);
      if (pct <= 0) {
        clearTimer();
        setVisible(false);
        setTimeout(() => dismissNewMessages(), 300);
      }
    }, 50);
  };

  useEffect(() => {
    if (newMessages.length > 0) {
      setVisible(true);
      startTimer();
    } else {
      clearTimer();
      setVisible(false);
    }
    return clearTimer;
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [newMessages]);

  const handleDismiss = () => {
    clearTimer();
    setVisible(false);
    setTimeout(() => dismissNewMessages(), 300);
  };

  const handlePause = () => clearTimer();
  const handleResume = () => {
    if (newMessages.length > 0 && visible) startTimer();
  };

  if (newMessages.length === 0 && !visible) return null;

  const uniqueSenders = Array.from(
    new Map(
      newMessages.map(m => [
        m.gotalk_contact_id,
        { name: m.client_name || m.contact_name || 'Desconhecido', client_id: m.client_id },
      ])
    ).values()
  );

  return (
    <div
      className={`w-full overflow-hidden flex-shrink-0 transition-all duration-300 ${visible ? 'max-h-20 opacity-100' : 'max-h-0 opacity-0'}`}
      onMouseEnter={handlePause}
      onMouseLeave={handleResume}
    >
      {/* Barra principal */}
      <div className="bg-emerald-700 text-white flex items-center gap-2 px-3 py-1.5 min-h-[36px]">
        {/* Ícone WhatsApp */}
        <svg className="w-4 h-4 flex-shrink-0 text-emerald-200" viewBox="0 0 24 24" fill="currentColor">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
        </svg>

        {/* Contador */}
        <span className="text-[11px] font-bold bg-emerald-900/60 text-emerald-100 rounded-full px-1.5 py-0.5 flex-shrink-0 tabular-nums">
          {newMessages.length}
        </span>

        {/* Texto descritivo */}
        <span className="text-[11px] font-medium flex-shrink-0 text-emerald-100">
          {newMessages.length === 1 ? 'nova mensagem de:' : 'novas mensagens de:'}
        </span>

        {/* Remetentes clicáveis */}
        <div className="flex items-center gap-1.5 flex-1 flex-wrap overflow-hidden min-w-0">
          {uniqueSenders.slice(0, 5).map((s, i) => (
            <button
              key={i}
              onClick={() => s.client_id ? openClient(s.client_id) : undefined}
              className={`text-[11px] px-2 py-0.5 rounded-full font-semibold truncate max-w-[160px] transition-colors ${
                s.client_id
                  ? 'bg-white/20 hover:bg-white/35 cursor-pointer'
                  : 'bg-white/10 cursor-default'
              }`}
              title={s.client_id ? `Abrir cadastro de ${s.name}` : s.name}
            >
              {s.name}
            </button>
          ))}
          {uniqueSenders.length > 5 && (
            <span className="text-[11px] text-emerald-200 flex-shrink-0">+{uniqueSenders.length - 5}</span>
          )}
        </div>

        {/* Botão fechar */}
        <button
          onClick={handleDismiss}
          className="flex-shrink-0 text-emerald-200 hover:text-white transition-colors p-0.5 rounded ml-1"
          title="Dispensar"
        >
          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      {/* Barra de progresso — esgota em AUTO_DISMISS_MS */}
      <div className="h-0.5 bg-emerald-900/40">
        <div
          className="h-full bg-emerald-300"
          style={{ width: `${progress}%`, transition: 'none' }}
        />
      </div>
    </div>
  );
};

export default GotalkMessageGauge;

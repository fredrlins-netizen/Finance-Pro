import React, { useState, useEffect, useRef, useCallback } from 'react';
import GoTalkMediaRenderer from './GoTalkMediaRenderer';
import GotalkSendTemplateModal from './GotalkSendTemplateModal';
import ToastContainer, { ToastMessage } from '../ui/Toast';
import {
  ConversationBubble,
  ConversationComposerSurface,
  ConversationDateSeparator,
  ConversationSurface,
  ConversationTimeline,
} from '../conversations/ConversationPrimitives';

interface GotalkMessage {
  id?: string;
  gotalk_message_id?: string;
  body: string | null;
  direction: 'IN' | 'OUT';
  message_type: string;
  sent_at?: string | null;
  attachment_url?: string | null;
  attachment_name?: string | null;
  attachment_mime_type?: string | null;
  attachment_size?: number | null;
  transcription?: string | null;
  contact_name?: string | null;
  operator_name?: string | null;
  department?: string | null;
  area?: string | null;
  source?: string;
  ack_status?: number | null;
  template_body?: string | null;
  template_header?: string | null;
  template_footer?: string | null;
  template_category?: string | null;
  template_status?: string | null;
}

interface LinkedContact {
  id: string;
  name: string | null;
  phone_number: string | null;
}

interface Props {
  clientId?: string;
  gotalkContactId?: string;
  operatorName?: string;
  area?: string;
  onLinked?: (clientId: string) => void;
}

const GotalkChatPanel: React.FC<Props> = ({ clientId, gotalkContactId, onLinked }) => {
  const [messages, setMessages] = useState<GotalkMessage[]>([]);
  const [contact, setContact] = useState<LinkedContact | null>(null);
  const [loading, setLoading] = useState(true);

  const [showLinkModal, setShowLinkModal] = useState(false);
  const [linkSearch, setLinkSearch] = useState('');
  const [linkResults, setLinkResults] = useState<Array<{id: string; name: string; phone: string | null; document: string | null}>>([]);
  const [linkLoading, setLinkLoading] = useState(false);
  const [linking, setLinking] = useState(false);
  const [linkError, setLinkError] = useState('');

  const [showSyncModal, setShowSyncModal] = useState(false);
  const [syncTab, setSyncTab] = useState<'attendance' | 'phone'>('attendance');
  const [syncAttendanceId, setSyncAttendanceId] = useState('');
  const [syncPhone, setSyncPhone] = useState('');
  const [syncLoading, setSyncLoading] = useState(false);
  const [syncResult, setSyncResult] = useState<{ saved: number; total?: number } | null>(null);
  const [syncError, setSyncError] = useState('');

  const [composeText, setComposeText] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [showTemplateModal, setShowTemplateModal] = useState(false);

  const [activeAttendance, setActiveAttendance] = useState<{
    id: string;
    gotalk_attendance_id: string;
    contact_phone: string;
  } | null>(null);
  const [hasActiveChannel, setHasActiveChannel] = useState<boolean | null>(null);

  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const addToast = useCallback((t: Omit<ToastMessage, 'id'>) => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts([{ ...t, id }]);
  }, []);
  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const composeRef = useRef<HTMLTextAreaElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const fetchMessages = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      let url: string;
      let markReadBody: Record<string, string>;
      if (clientId) {
        url = `/api/gotalk/messages/${clientId}?limit=100`;
        markReadBody = { clientId };
      } else if (gotalkContactId) {
        url = `/api/gotalk/messages/contact/${gotalkContactId}?limit=100`;
        markReadBody = { contactId: gotalkContactId };
      } else {
        return;
      }
      const res = await fetch(url);
      if (!res.ok) return;
      const data = await res.json();
      setMessages(data.data || []);
      fetch('/api/gotalk/messages/mark-read', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(markReadBody),
      }).catch(() => {});
    } finally {
      if (!silent) setLoading(false);
    }
  }, [clientId, gotalkContactId]);

  const fetchContact = useCallback(async () => {
    try {
      if (clientId) {
        const res = await fetch(`/api/gotalk/client/${clientId}`);
        if (!res.ok) return;
        const data = await res.json();
        if (data.linked) setContact(data.contact);
      } else if (gotalkContactId) {
        const res = await fetch(`/api/gotalk/contact-by-id/${gotalkContactId}`);
        if (!res.ok) return;
        const data = await res.json();
        setContact({ id: data.id, name: data.name, phone_number: data.phone_number });
      }
    } catch {}
  }, [clientId, gotalkContactId]);

  const searchClients = useCallback(async (q: string) => {
    if (!q.trim()) { setLinkResults([]); return; }
    setLinkLoading(true);
    try {
      const res = await fetch(`/api/clients?search=${encodeURIComponent(q)}&limit=20`);
      if (!res.ok) return;
      const data = await res.json();
      setLinkResults((data.data || []).map((c: Record<string, string>) => ({ id: c.id, name: c.name, phone: c.phone || null, document: c.document || null })));
    } catch {} finally { setLinkLoading(false); }
  }, []);

  useEffect(() => {
    const t = setTimeout(() => searchClients(linkSearch), 300);
    return () => clearTimeout(t);
  }, [linkSearch, searchClients]);

  const handleLinkClient = async (selectedClientId: string) => {
    if (!gotalkContactId) return;
    setLinking(true);
    setLinkError('');
    try {
      const res = await fetch('/api/gotalk/link-client', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gotalkContactId, clientId: selectedClientId }),
      });
      if (!res.ok) {
        const d = await res.json();
        setLinkError(d.error || 'Erro ao vincular');
        return;
      }
      setShowLinkModal(false);
      setLinkSearch('');
      setLinkResults([]);
      await fetchContact();
      await fetchMessages(true);
      onLinked?.(selectedClientId);
    } catch { setLinkError('Erro de conexão'); } finally { setLinking(false); }
  };

  const handleSyncAttendance = async () => {
    const id = syncAttendanceId.trim();
    if (!id) return;
    setSyncLoading(true);
    setSyncError('');
    setSyncResult(null);
    try {
      const res = await fetch('/api/gotalk/sync-attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          attendanceId: id,
          contactId: gotalkContactId || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro ao sincronizar');
      setSyncResult({ saved: data.saved, total: data.total });
      if (data.saved > 0) fetchMessages(true);
    } catch (e: unknown) {
      setSyncError(e instanceof Error ? e.message : 'Erro desconhecido');
    } finally {
      setSyncLoading(false);
    }
  };

  const handleSyncByPhone = async () => {
    const phone = syncPhone.replace(/\D/g, '');
    if (!phone) return;
    setSyncLoading(true);
    setSyncError('');
    setSyncResult(null);
    try {
      const res = await fetch('/api/gotalk/sync-by-phone', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ phone }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro ao sincronizar');
      setSyncResult({ saved: data.saved });
      if (data.saved > 0) fetchMessages(true);
    } catch (e: unknown) {
      setSyncError(e instanceof Error ? e.message : 'Erro desconhecido');
    } finally {
      setSyncLoading(false);
    }
  };

  const fetchActiveAttendance = useCallback(async () => {
    if (!clientId) return;
    try {
      const res = await fetch(`/api/gotalk/attendances?clientId=${clientId}&status=open&limit=1`);
      if (!res.ok) return;
      const data = await res.json();
      const att = (data.data || [])[0] || null;
      if (att?.gotalk_attendance_id && att?.contact_phone) {
        setActiveAttendance({
          id: att.id,
          gotalk_attendance_id: att.gotalk_attendance_id,
          contact_phone: att.contact_phone,
        });
      } else {
        setActiveAttendance(null);
      }
    } catch {}
  }, [clientId]);

  const fetchChannelStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/gotalk/channels');
      if (!res.ok) { setHasActiveChannel(false); return; }
      const data = await res.json();
      const channels: Array<{ is_active: boolean }> = data.channels || data || [];
      setHasActiveChannel(channels.some(c => c.is_active));
    } catch { setHasActiveChannel(false); }
  }, []);

  const handleSendText = useCallback(async () => {
    const text = composeText.trim();
    if (!text || sending) return;
    setSending(true);
    setSendError('');
    try {
      let res: Response;
      if (activeAttendance?.gotalk_attendance_id && activeAttendance?.contact_phone) {
        res = await fetch('/api/gotalk/send-message-attendance', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            attendanceId: activeAttendance.gotalk_attendance_id,
            phone: activeAttendance.contact_phone,
            body: text,
          }),
        });
      } else {
        if (!contact?.phone_number) {
          setSendError('Contato sem número de telefone.');
          setSending(false);
          return;
        }
        res = await fetch('/api/gotalk/send-text', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ contactNumber: contact.phone_number, message: text }),
        });
      }
      const data = await res.json();
      if (!res.ok) {
        const errMsg = data.error || data.message || 'Erro ao enviar mensagem.';
        setSendError(errMsg);
        addToast({ type: 'error', title: 'Erro ao enviar', message: errMsg });
        return;
      }
      setComposeText('');
      setSendError('');
      addToast({ type: 'success', title: 'Mensagem enviada', message: 'Mensagem enviada com sucesso.' });
      const optimistic: GotalkMessage = {
        body: text,
        direction: 'OUT',
        message_type: 'TEXT',
        sent_at: new Date().toISOString(),
      };
      setMessages(prev => [...prev, optimistic]);
    } catch (e: unknown) {
      const errMsg = e instanceof Error ? e.message : 'Erro de conexão.';
      setSendError(errMsg);
      addToast({ type: 'error', title: 'Erro ao enviar', message: errMsg });
    } finally {
      setSending(false);
    }
  }, [composeText, contact, sending, activeAttendance, addToast]);

  useEffect(() => {
    fetchContact();
    fetchMessages();
    fetchActiveAttendance();
    fetchChannelStatus();
    pollRef.current = setInterval(() => fetchMessages(true), 60000);
    return () => { if (pollRef.current) clearInterval(pollRef.current); };
  }, [fetchContact, fetchMessages, fetchActiveAttendance, fetchChannelStatus]);

  useEffect(() => { scrollToBottom(); }, [messages]);

  const formatTime = (iso?: string | null) => {
    if (!iso) return '';
    return new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDay = (iso?: string | null) => {
    if (!iso) return '';
    return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' });
  };


  const renderAckIcon = (ackStatus: number | null | undefined) => {
    if (ackStatus === null || ackStatus === undefined) {
      return (
        <svg className="inline w-3 h-3 ml-0.5 opacity-60" viewBox="0 0 16 16" fill="currentColor">
          <path d="M8 1a7 7 0 1 0 0 14A7 7 0 0 0 8 1zm0 1.5a5.5 5.5 0 1 1 0 11A5.5 5.5 0 0 1 8 2.5zM7.25 5v3.31l2.47 1.48.53-.88-2-1.2V5h-1z"/>
        </svg>
      );
    }
    if (ackStatus === 1) {
      return (
        <svg className="inline w-3.5 h-3 ml-0.5 opacity-60" viewBox="0 0 16 11" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="1,5.5 5.5,10 15,1"/>
        </svg>
      );
    }
    if (ackStatus === 2) {
      return (
        <svg className="inline w-4 h-3 ml-0.5 opacity-60" viewBox="0 0 20 11" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="1,5.5 5.5,10 15,1"/>
          <polyline points="6,5.5 10.5,10 20,1"/>
        </svg>
      );
    }
    if (ackStatus >= 3) {
      return (
        <svg className="inline w-4 h-3 ml-0.5" viewBox="0 0 20 11" fill="none" stroke="#53bdeb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="1,5.5 5.5,10 15,1"/>
          <polyline points="6,5.5 10.5,10 20,1"/>
        </svg>
      );
    }
    return null;
  };

  const renderMeta = (msg: GotalkMessage) => {
    if (msg.direction !== 'OUT') return null;
    const parts: string[] = [];
    if (msg.operator_name) parts.push(msg.operator_name);
    if (msg.area) parts.push(msg.area);
    if (!parts.length) return null;
    return (
      <p className="text-[10px] text-green-700 opacity-70 mt-0.5 text-right">
        {parts.join(' · ')}
      </p>
    );
  };

  let lastDay = '';

  if (loading) {
    return (
      <ConversationSurface className="flex items-center justify-center h-40 text-gray-400 text-sm">
        Carregando mensagens...
      </ConversationSurface>
    );
  }

  if (!contact) {
    return (
      <ConversationSurface className="flex items-center justify-center h-32 text-gray-400 text-sm">
        Nenhum contato WhatsApp vinculado. Use a seção acima para sincronizar.
      </ConversationSurface>
    );
  }

  const isUnlinked = !clientId && !!gotalkContactId;

  return (
    <ConversationSurface className="flex flex-col border border-gray-200 rounded-lg overflow-hidden bg-white" style={{ height: '500px' }}>
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 bg-green-600 text-white flex-shrink-0">
        <div className="w-9 h-9 rounded-full bg-green-500 flex items-center justify-center font-bold text-sm">
          {((contact.name || '?')[0]).toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <p className="font-semibold text-sm truncate">{contact.name || 'Contato'}</p>
          <p className="text-xs text-green-100 truncate">{contact.phone_number}</p>
        </div>
        {isUnlinked && (
          <button
            type="button"
            onClick={() => setShowLinkModal(true)}
            className="flex items-center gap-1 px-2 py-1 bg-yellow-400 hover:bg-yellow-300 text-yellow-900 text-xs font-semibold rounded-lg transition-colors flex-shrink-0"
            title="Vincular a um cliente CRM"
          >
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
            </svg>
            Vincular
          </button>
        )}
        <button
          type="button"
          onClick={() => { setShowSyncModal(true); setSyncResult(null); setSyncError(''); }}
          className="p-1 rounded hover:bg-green-500 transition-colors"
          title="Importar histórico via ID do atendimento GoTalk"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
          </svg>
        </button>
        <button
          type="button"
          onClick={() => fetchMessages(true)}
          className="p-1 rounded hover:bg-green-500 transition-colors"
          title="Atualizar mensagens"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
        </button>
        {contact?.phone_number && (
          <button
            type="button"
            onClick={() => setShowTemplateModal(true)}
            className="flex items-center gap-1 px-2 py-1 bg-green-500 hover:bg-green-400 text-white text-xs font-semibold rounded-lg transition-colors flex-shrink-0"
            title="Enviar template HSM"
          >
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h10M4 18h6" />
            </svg>
            Template
          </button>
        )}
      </div>

      {/* Import Attendance Modal */}
      {showSyncModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4">
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-md p-5 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-gray-800">Importar Mensagens do GoTalk</h3>
              <button onClick={() => { setShowSyncModal(false); setSyncResult(null); setSyncError(''); }} className="text-gray-400 hover:text-gray-600 text-xl leading-none">✕</button>
            </div>

            {/* Tabs */}
            <div className="flex rounded-lg border border-gray-200 overflow-hidden text-sm">
              <button
                onClick={() => { setSyncTab('attendance'); setSyncResult(null); setSyncError(''); }}
                className={`flex-1 py-2 font-medium transition-colors ${syncTab === 'attendance' ? 'bg-green-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
              >
                Por ID do Atendimento
              </button>
              <button
                onClick={() => { setSyncTab('phone'); setSyncResult(null); setSyncError(''); }}
                className={`flex-1 py-2 font-medium transition-colors ${syncTab === 'phone' ? 'bg-green-600 text-white' : 'bg-white text-gray-600 hover:bg-gray-50'}`}
              >
                Por Telefone
              </button>
            </div>

            {syncTab === 'attendance' ? (
              <>
                <p className="text-sm text-gray-600">
                  Abra a conversa no <strong>GoTalk web</strong>, copie o ID do atendimento da URL (ex.: <code className="bg-gray-100 px-1 rounded text-xs">68e94a0...</code>) e cole abaixo para importar o histórico completo.
                </p>
                <input
                  type="text"
                  value={syncAttendanceId}
                  onChange={e => setSyncAttendanceId(e.target.value)}
                  placeholder="ID do atendimento GoTalk"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </>
            ) : (
              <>
                <p className="text-sm text-gray-600">
                  Informe o <strong>número de telefone</strong> do cliente (com ou sem código de país) para buscar e importar mensagens de todos os atendimentos recentes.
                </p>
                <input
                  type="tel"
                  value={syncPhone}
                  onChange={e => setSyncPhone(e.target.value)}
                  placeholder="Ex.: 11999998888 ou 5511999998888"
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                />
              </>
            )}

            {syncError && <p className="text-sm text-red-600">{syncError}</p>}
            {syncResult && (
              <p className="text-sm text-green-700">
                ✓ {syncResult.saved} mensagem(ns) importada(s){syncResult.total != null ? ` de ${syncResult.total} encontrada(s)` : ''}.
              </p>
            )}
            <div className="flex gap-2 justify-end">
              <button
                onClick={() => { setShowSyncModal(false); setSyncResult(null); setSyncError(''); }}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800"
              >
                Fechar
              </button>
              <button
                onClick={syncTab === 'attendance' ? handleSyncAttendance : handleSyncByPhone}
                disabled={syncLoading || (syncTab === 'attendance' ? !syncAttendanceId.trim() : !syncPhone.replace(/\D/g, ''))}
                className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg disabled:opacity-50 transition-colors"
              >
                {syncLoading ? 'Importando...' : 'Importar'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Unlinked contact banner */}
      {isUnlinked && (
        <div className="flex items-center gap-2 px-4 py-2 bg-yellow-50 border-b border-yellow-200 text-yellow-800 text-xs flex-shrink-0">
          <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <span>Contato <strong>não vinculado</strong> a nenhum cliente CRM. Clique em <strong>Vincular</strong> para associar.</span>
        </div>
      )}

      {/* Link-to-client modal */}
      {showLinkModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setShowLinkModal(false)}>
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden" onClick={e => e.stopPropagation()}>
            <div className="bg-green-700 text-white px-5 py-4 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-sm">Vincular ao Cliente CRM</h3>
                <p className="text-[11px] text-green-100 mt-0.5">Contato: {contact.name} ({contact.phone_number})</p>
              </div>
              <button onClick={() => setShowLinkModal(false)} className="text-white/70 hover:text-white">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              </button>
            </div>
            <div className="p-4">
              <input
                type="text"
                value={linkSearch}
                onChange={e => setLinkSearch(e.target.value)}
                placeholder="Buscar cliente por nome, CPF ou telefone..."
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-green-500 focus:border-green-500"
                autoFocus
              />
              {linkError && <p className="text-xs text-red-600 mt-1">{linkError}</p>}
              <div className="mt-3 max-h-60 overflow-y-auto border border-gray-200 rounded-lg">
                {linkLoading ? (
                  <div className="text-center py-6 text-gray-400 text-sm">Buscando...</div>
                ) : linkResults.length === 0 ? (
                  <div className="text-center py-6 text-gray-400 text-sm">{linkSearch ? 'Nenhum cliente encontrado' : 'Digite para buscar clientes'}</div>
                ) : (
                  linkResults.map(c => (
                    <button
                      key={c.id}
                      onClick={() => handleLinkClient(c.id)}
                      disabled={linking}
                      className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-green-50 border-b border-gray-100 last:border-0 transition-colors disabled:opacity-50"
                    >
                      <div className="w-8 h-8 rounded-full bg-green-100 text-green-800 font-bold text-xs flex items-center justify-center shrink-0">
                        {(c.name || '?')[0].toUpperCase()}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-gray-800 truncate">{c.name}</p>
                        <p className="text-xs text-gray-500">{[c.document, c.phone].filter(Boolean).join(' · ')}</p>
                      </div>
                      {linking ? (
                        <span className="w-4 h-4 border-2 border-green-500 border-t-transparent rounded-full animate-spin" />
                      ) : (
                        <svg className="w-4 h-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                        </svg>
                      )}
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Messages */}
      <ConversationTimeline className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
        {messages.length === 0 && (
          <div className="flex items-center justify-center h-full text-gray-500 text-sm">
            Nenhuma mensagem ainda.
          </div>
        )}
        {messages.map((msg, idx) => {
          const day = formatDay(msg.sent_at);
          const showDayLabel = day !== lastDay;
          if (showDayLabel) lastDay = day;
          const isOut = msg.direction === 'OUT';

          return (
            <React.Fragment key={msg.gotalk_message_id || msg.id || idx}>
              {showDayLabel && day && (
                <ConversationDateSeparator className="text-xs bg-white/70 text-gray-600 px-3 py-1 rounded-full shadow-sm">
                  {day}
                </ConversationDateSeparator>
              )}
              <div className={`flex ${isOut ? 'justify-end' : 'justify-start'}`}>
                <ConversationBubble
                  outgoing={isOut}
                  className={`max-w-[70%] px-3 py-2 rounded-lg shadow-sm ${
                    isOut ? 'bg-[#dcf8c6] text-gray-800' : 'bg-white text-gray-800'
                  }`}
                >
                  <GoTalkMediaRenderer
                    messageId={msg.id}
                    messageType={msg.message_type}
                    attachmentUrl={msg.attachment_url}
                    attachmentName={msg.attachment_name}
                    attachmentMime={msg.attachment_mime_type}
                    attachmentSize={msg.attachment_size}
                    audioTranscript={msg.transcription}
                    caption={msg.body}
                    templateBody={msg.template_body}
                    templateHeader={msg.template_header}
                    templateFooter={msg.template_footer}
                    templateCategory={msg.template_category}
                    templateStatus={msg.template_status}
                  />
                  <div className={`flex items-center gap-0.5 mt-0.5 ${isOut ? 'justify-end' : 'justify-start'}`}>
                    <span className={`text-[10px] ${isOut ? 'text-green-700' : 'text-gray-400'}`}>
                      {formatTime(msg.sent_at)}
                    </span>
                    {isOut && renderAckIcon(msg.ack_status)}
                  </div>
                  {renderMeta(msg)}
                </ConversationBubble>
              </div>
            </React.Fragment>
          );
        })}
        <div ref={messagesEndRef} />
      </ConversationTimeline>

      {/* Compose bar */}
      <ConversationComposerSurface className="flex-shrink-0 border-t border-gray-200 bg-white">
        {sendError && (
          <div className="flex items-center gap-1.5 px-4 py-1.5 bg-red-50 border-b border-red-100 text-xs text-red-600">
            <svg className="w-3 h-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            {sendError}
          </div>
        )}
        {hasActiveChannel === false ? (
          <div className="flex items-center gap-2 px-4 py-2 text-amber-700 bg-amber-50 text-xs">
            <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Nenhum canal GoTalk ativo configurado — envio de mensagens indisponível
          </div>
        ) : contact?.phone_number || activeAttendance ? (
          <div className="flex items-end gap-2 px-3 py-2">
            {activeAttendance && (
              <span className="text-[10px] text-green-700 bg-green-50 border border-green-200 px-2 py-0.5 rounded-full whitespace-nowrap self-center">
                Atendimento ativo
              </span>
            )}
            <textarea
              ref={composeRef}
              value={composeText}
              onChange={e => { setComposeText(e.target.value); setSendError(''); }}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSendText();
                }
              }}
              placeholder="Digite uma mensagem... (Enter para enviar, Shift+Enter para nova linha)"
              rows={1}
              className="flex-1 resize-none border border-gray-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent max-h-28 overflow-y-auto"
              style={{ minHeight: '38px' }}
              disabled={sending}
            />
            <button
              type="button"
              onClick={handleSendText}
              disabled={!composeText.trim() || sending}
              className="flex-shrink-0 w-9 h-9 flex items-center justify-center bg-green-600 hover:bg-green-700 text-white rounded-full disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              title="Enviar mensagem"
            >
              {sending ? (
                <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              )}
            </button>
          </div>
        ) : (
          <div className="flex items-center gap-2 px-4 py-2 text-gray-400 text-xs">
            <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
            </svg>
            Contato sem número de telefone — não é possível enviar mensagens
          </div>
        )}
      </ConversationComposerSurface>

      {showTemplateModal && (contact?.phone_number || activeAttendance?.contact_phone) && (
        <GotalkSendTemplateModal
          isOpen={showTemplateModal}
          onClose={() => setShowTemplateModal(false)}
          contactPhone={(contact?.phone_number || activeAttendance?.contact_phone)!}
          contactName={contact?.name || 'Contato'}
          onSuccess={() => {
            addToast({ type: 'success', title: 'Template enviado', message: 'Notificação HSM disparada com sucesso.' });
            setTimeout(() => fetchMessages(true), 2000);
          }}
          onError={(msg) => addToast({ type: 'error', title: 'Erro ao enviar template', message: msg })}
        />
      )}

      <ToastContainer toasts={toasts} removeToast={removeToast} />
    </ConversationSurface>
  );
};

export default GotalkChatPanel;

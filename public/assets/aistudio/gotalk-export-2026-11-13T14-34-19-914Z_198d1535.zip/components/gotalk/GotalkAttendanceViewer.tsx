import React, { useState, useEffect, useCallback, useRef } from 'react';
import GoTalkMediaRenderer from './GoTalkMediaRenderer';
import GotalkSendTemplateModal from './GotalkSendTemplateModal';
import ToastContainer, { ToastMessage } from '../ui/Toast';
import { useSecurity } from '../../contexts/SecurityContext';
import {
  ConversationBubble,
  ConversationComposerSurface,
  ConversationDateSeparator,
  ConversationSurface,
  ConversationTimeline,
} from '../conversations/ConversationPrimitives';

interface Attendance {
  id: string;
  gotalk_attendance_id: string | null;
  status: string;
  type: string | null;
  department: string | null;
  subject: string | null;
  started_at: string | null;
  ended_at: string | null;
  client_id: string | null;
  gotalk_contact_id: string | null;
  operator_id: string | null;
  gotalk_operator_id: string | null;
  client_name: string | null;
  contact_name: string | null;
  contact_phone: string | null;
  operator_name: string | null;
  collaborator_id: string | null;
  collaborator_name: string | null;
  message_count: number;
  last_message_at: string | null;
}

interface AttendanceMessage {
  id: string;
  gotalk_message_id: string | null;
  direction: 'IN' | 'OUT';
  body: string | null;
  message_type: string;
  attachment_url: string | null;
  attachment_name: string | null;
  attachment_mime_type: string | null;
  audio_transcript: string | null;
  ack_status: number | null;
  sent_at: string | null;
  operator_name: string | null;
  department: string | null;
  template_body: string | null;
  template_header: string | null;
  template_footer: string | null;
  template_category: string | null;
  template_status: string | null;
}

interface UnitOption {
  id: string;
  name: string;
}

interface Props {
  clientId?: string;
  collaboratorId?: string;
  type?: string;
  title?: string;
  showUnitFilter?: boolean;
}

const WA_ICON = (
  <svg className="w-4 h-4" viewBox="0 0 24 24" fill="currentColor">
    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
  </svg>
);

function formatDateTime(iso: string | null): string {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function formatTime(iso: string | null): string {
  if (!iso) return '';
  return new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
}

function statusBadge(status: string) {
  if (status === 'open') return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-100 text-green-800">Aberto</span>;
  return <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-gray-100 text-gray-600">Fechado</span>;
}

function typeBadge(type: string | null) {
  if (!type) return null;
  const labels: Record<string, string> = { CLIENT: 'Cliente', BANK: 'Banco' };
  const colors: Record<string, string> = { CLIENT: 'bg-blue-50 text-blue-700', BANK: 'bg-orange-50 text-orange-700' };
  return <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold ${colors[type] || 'bg-gray-100 text-gray-600'}`}>{labels[type] || type}</span>;
}


const MSG_LIMIT = 100;

const GotalkAttendanceViewer: React.FC<Props> = ({ clientId, collaboratorId, type, title, showUnitFilter }) => {
  const { currentUser, isLoggedAdmin } = useSecurity();
  const [attendances, setAttendances] = useState<Attendance[]>([]);
  const [loading, setLoading] = useState(false);
  const [selectedAttendance, setSelectedAttendance] = useState<Attendance | null>(null);
  const [messages, setMessages] = useState<AttendanceMessage[]>([]);
  const [messagesLoading, setMessagesLoading] = useState(false);
  const [loadingMore, setLoadingMore] = useState(false);
  const [msgOffset, setMsgOffset] = useState(0);
  const [msgTotal, setMsgTotal] = useState(0);
  const [typeFilter, setTypeFilter] = useState<string>(type || '');
  const [unitFilter, setUnitFilter] = useState<string>('');
  const [availableUnits, setAvailableUnits] = useState<UnitOption[]>([]);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [totalPages, setTotalPages] = useState(1);
  const [composeText, setComposeText] = useState('');
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [showTemplateModal, setShowTemplateModal] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const [hasActiveChannel, setHasActiveChannel] = useState<boolean | null>(null);

  const [toasts, setToasts] = useState<ToastMessage[]>([]);
  const addToast = useCallback((t: Omit<ToastMessage, 'id'>) => {
    const id = `${Date.now()}-${Math.random()}`;
    setToasts([{ ...t, id }]);
  }, []);
  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  const LIMIT = 20;

  const fetchAttendances = useCallback(async (p: number, tFilter: string, uFilter: string) => {
    setLoading(true);
    try {
      const params = new URLSearchParams({ page: String(p), limit: String(LIMIT) });
      if (clientId) params.set('clientId', clientId);
      if (collaboratorId) params.set('collaboratorId', collaboratorId);
      if (tFilter) params.set('type', tFilter);
      if (uFilter) params.set('unitId', uFilter);
      const res = await fetch(`/api/gotalk/attendances?${params.toString()}`);
      if (!res.ok) return;
      const data = await res.json();
      setAttendances(data.data || []);
      setTotal(data.total || 0);
      setTotalPages(data.totalPages || 1);
    } catch {
    } finally {
      setLoading(false);
    }
  }, [clientId, collaboratorId]);

  const fetchMessages = useCallback(async (attendance: Attendance, offset = 0) => {
    if (offset === 0) {
      setMessagesLoading(true);
      setMessages([]);
    } else {
      setLoadingMore(true);
    }
    try {
      const res = await fetch(`/api/gotalk/attendances/${attendance.id}/messages?limit=${MSG_LIMIT}&offset=${offset}`);
      if (!res.ok) return;
      const data = await res.json();
      const newMsgs: AttendanceMessage[] = data.data || [];
      setMsgTotal(data.total || 0);
      setMsgOffset(offset + newMsgs.length);
      if (offset === 0) {
        setMessages(newMsgs);
      } else {
        setMessages(prev => [...prev, ...newMsgs]);
      }
    } catch {
    } finally {
      setMessagesLoading(false);
      setLoadingMore(false);
    }
  }, []);

  const fetchChannelStatus = useCallback(async () => {
    try {
      const res = await fetch('/api/gotalk/channels');
      if (!res.ok) { setHasActiveChannel(false); return; }
      const data = await res.json();
      const channels: Array<{ is_active: boolean; unit_id?: string; unit_name?: string }> = data.channels || data || [];
      setHasActiveChannel(channels.some(c => c.is_active));
      // Build unit list for the selector (only when standalone unit filter is enabled)
      if (showUnitFilter && !clientId && !collaboratorId) {
        // Build name map from channel data (most reliable source for display names)
        const channelUnitMap = new Map<string, string>();
        channels.forEach(c => { if (c.unit_id && c.unit_name) channelUnitMap.set(c.unit_id, c.unit_name); });

        if (!isLoggedAdmin && currentUser?.allowedUnits?.length) {
          // Non-admins: use security-context units as the authoritative list,
          // enriching display names from channel data when available.
          const units: UnitOption[] = (currentUser.allowedUnits).map(u => ({
            id: u.id,
            name: channelUnitMap.get(u.id) || u.nomeFantasia || u.razaoSocial || u.id,
          }));
          setAvailableUnits(units);
        } else {
          // Admins: derive from channel data (covers all active channels).
          const allUnits: UnitOption[] = Array.from(channelUnitMap.entries()).map(([id, name]) => ({ id, name }));
          setAvailableUnits(allUnits);
        }
      }
    } catch { setHasActiveChannel(false); }
  }, [showUnitFilter, clientId, isLoggedAdmin, currentUser]);

  useEffect(() => {
    fetchChannelStatus();
  }, [fetchChannelStatus]);

  useEffect(() => {
    fetchAttendances(page, typeFilter, unitFilter);
  }, [fetchAttendances, page, typeFilter, unitFilter]);

  useEffect(() => {
    if (selectedAttendance) {
      setMsgOffset(0);
      setMsgTotal(0);
      fetchMessages(selectedAttendance, 0);
    }
  }, [selectedAttendance, fetchMessages]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleTypeFilter = (t: string) => {
    setTypeFilter(t);
    setPage(1);
    setSelectedAttendance(null);
  };

  const handleUnitFilter = (uid: string) => {
    setUnitFilter(uid);
    setPage(1);
    setSelectedAttendance(null);
  };

  const handleSelectAttendance = (att: Attendance) => {
    setSelectedAttendance(att);
  };

  const handleBack = () => {
    setSelectedAttendance(null);
    setMessages([]);
    setComposeText('');
    setSendError('');
  };

  const handleSendMessageAttendance = useCallback(async () => {
    const text = composeText.trim();
    if (!text || !selectedAttendance || sending) return;
    if (!selectedAttendance.gotalk_attendance_id) {
      setSendError('Este atendimento não possui ID GoTalk vinculado.');
      return;
    }
    if (!selectedAttendance.contact_phone) {
      setSendError('Este atendimento não possui número de telefone do contato.');
      return;
    }
    setSending(true);
    setSendError('');
    try {
      const res = await fetch('/api/gotalk/send-message-attendance', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          attendanceId: selectedAttendance.gotalk_attendance_id,
          phone: selectedAttendance.contact_phone,
          body: text,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        const errMsg = data.error || data.message || 'Erro ao enviar mensagem.';
        setSendError(errMsg);
        addToast({ type: 'error', title: 'Erro ao enviar', message: errMsg });
        return;
      }
      setComposeText('');
      setSendError('');
      addToast({ type: 'success', title: 'Mensagem enviada', message: 'Mensagem enviada com sucesso.' });
      const optimistic: AttendanceMessage = {
        id: `optimistic-${Date.now()}`,
        gotalk_message_id: null,
        direction: 'OUT',
        body: text,
        message_type: 'TEXT',
        attachment_url: null,
        attachment_name: null,
        attachment_mime_type: null,
        audio_transcript: null,
        ack_status: null,
        sent_at: new Date().toISOString(),
        operator_name: null,
        department: null,
        template_body: null,
        template_header: null,
        template_footer: null,
        template_category: null,
        template_status: null,
      };
      setMessages(prev => [...prev, optimistic]);
    } catch (e: unknown) {
      const errMsg = e instanceof Error ? e.message : 'Erro de conexão.';
      setSendError(errMsg);
      addToast({ type: 'error', title: 'Erro ao enviar', message: errMsg });
    } finally {
      setSending(false);
    }
  }, [composeText, selectedAttendance, sending, addToast]);

  if (selectedAttendance) {
    return (
      <ConversationSurface className="flex flex-col h-full bg-white overflow-hidden">
        <div className="flex items-center gap-3 px-4 py-3 bg-green-700 text-white shrink-0">
          <button onClick={handleBack} className="hover:bg-white/20 rounded-lg p-1 transition-colors" title="Voltar">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div className="text-green-100">{WA_ICON}</div>
          <div className="flex-1 min-w-0">
            <p className="text-xs font-bold truncate">{selectedAttendance.contact_name || selectedAttendance.client_name || 'Contato'}</p>
            <p className="text-[10px] text-green-200 truncate">
              {selectedAttendance.contact_phone ? `${selectedAttendance.contact_phone} · ` : ''}
              {selectedAttendance.operator_name ? `Operador: ${selectedAttendance.operator_name}` : ''}
              {selectedAttendance.started_at ? ` · ${formatDateTime(selectedAttendance.started_at)}` : ''}
            </p>
          </div>
          <div className="flex items-center gap-2 shrink-0">
            {statusBadge(selectedAttendance.status)}
            {typeBadge(selectedAttendance.type)}
            {selectedAttendance.status === 'open' && selectedAttendance.contact_phone && (
              <button
                type="button"
                onClick={() => setShowTemplateModal(true)}
                className="flex items-center gap-1 px-2 py-1 bg-green-600 hover:bg-green-500 text-white text-[10px] font-semibold rounded-lg transition-colors"
                title="Enviar template HSM"
              >
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h10M4 18h6" />
                </svg>
                Template
              </button>
            )}
          </div>
        </div>

        <ConversationTimeline className="flex-1 overflow-y-auto px-4 py-3 space-y-2">
          {messagesLoading && (
            <div className="flex items-center justify-center py-12">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-green-700" />
            </div>
          )}
          {!messagesLoading && messages.length === 0 && (
            <div className="text-center py-10 text-sm text-gray-500">Nenhuma mensagem neste atendimento.</div>
          )}
          {!messagesLoading && messages.map((msg, idx) => {
            const isOut = msg.direction === 'OUT';
            const prevMsg = idx > 0 ? messages[idx - 1] : null;
            const showDay = !prevMsg || (msg.sent_at && prevMsg.sent_at && new Date(msg.sent_at).toDateString() !== new Date(prevMsg.sent_at).toDateString());
            return (
              <React.Fragment key={msg.id}>
                {showDay && msg.sent_at && (
                  <ConversationDateSeparator className="bg-white/80 text-gray-500 text-[10px] px-3 py-1 rounded-full shadow-sm">
                    {new Date(msg.sent_at).toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' })}
                  </ConversationDateSeparator>
                )}
                <div className={`flex ${isOut ? 'justify-end' : 'justify-start'}`}>
                  <ConversationBubble outgoing={isOut} className={`max-w-[75%] rounded-xl px-3 py-2 shadow-sm ${isOut ? 'bg-[#DCF8C6] text-gray-800 rounded-tr-none' : 'bg-white text-gray-800 rounded-tl-none'}`}>
                    {!isOut && msg.operator_name && (
                      <p className="text-[10px] font-bold text-green-700 mb-0.5">{msg.operator_name}</p>
                    )}
                    <GoTalkMediaRenderer
                      messageId={msg.id}
                      messageType={msg.message_type}
                      attachmentUrl={msg.attachment_url}
                      attachmentName={msg.attachment_name}
                      attachmentMime={msg.attachment_mime_type}
                      audioTranscript={msg.audio_transcript}
                      caption={msg.body}
                      templateBody={msg.template_body}
                      templateHeader={msg.template_header}
                      templateFooter={msg.template_footer}
                      templateCategory={msg.template_category}
                      templateStatus={msg.template_status}
                    />
                    <p className="text-[10px] text-gray-400 text-right mt-1">{formatTime(msg.sent_at)}</p>
                  </ConversationBubble>
                </div>
              </React.Fragment>
            );
          })}
          {!messagesLoading && msgOffset < msgTotal && (
            <div className="flex justify-center py-3">
              <button
                onClick={() => selectedAttendance && fetchMessages(selectedAttendance, msgOffset)}
                disabled={loadingMore}
                className="px-4 py-1.5 rounded-full text-xs font-semibold bg-white text-green-700 border border-green-200 hover:bg-green-50 disabled:opacity-50 shadow-sm transition-colors"
              >
                {loadingMore ? 'Carregando...' : `Carregar mais (${msgTotal - msgOffset} restantes)`}
              </button>
            </div>
          )}
          <div ref={messagesEndRef} />
        </ConversationTimeline>

        {selectedAttendance.status === 'open' && selectedAttendance.gotalk_attendance_id && selectedAttendance.contact_phone ? (
          <ConversationComposerSurface className="flex-shrink-0 border-t border-gray-200 bg-white">
            {sendError && (
              <div className="flex items-center gap-1.5 px-4 py-1.5 bg-red-50 border-b border-red-100 text-xs text-red-600">
                <svg className="w-3 h-3 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {sendError}
              </div>
            )}
            {hasActiveChannel === false ? (
              <div className="flex items-center gap-2 px-4 py-2 text-amber-700 bg-amber-50 text-xs">
                <svg className="w-3.5 h-3.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                Nenhum canal GoTalk ativo configurado — envio de mensagens indisponível
              </div>
            ) : (
              <div className="flex items-end gap-2 px-3 py-2">
                <textarea
                  value={composeText}
                  onChange={e => { setComposeText(e.target.value); setSendError(''); }}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendMessageAttendance();
                    }
                  }}
                  placeholder="Responder no atendimento... (Enter para enviar, Shift+Enter para nova linha)"
                  rows={1}
                  className="flex-1 resize-none border border-gray-300 rounded-xl px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent max-h-28 overflow-y-auto"
                  style={{ minHeight: '38px' }}
                  disabled={sending}
                />
                <button
                  type="button"
                  onClick={handleSendMessageAttendance}
                  disabled={!composeText.trim() || sending}
                  className="flex-shrink-0 w-9 h-9 flex items-center justify-center bg-green-700 hover:bg-green-600 text-white rounded-full disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
                  title="Enviar mensagem"
                >
                  {sending ? (
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                  )}
                </button>
              </div>
            )}
          </ConversationComposerSurface>
        ) : (
          <div className="bg-gray-50 border-t border-gray-200 px-4 py-2 text-xs text-gray-400 text-center shrink-0">
            {selectedAttendance.status !== 'open'
              ? `Atendimento encerrado — ${messages.length}${msgTotal > messages.length ? ` de ${msgTotal}` : ''} mensagem(s)`
              : `Sem telefone do contato — ${messages.length}${msgTotal > messages.length ? ` de ${msgTotal}` : ''} mensagem(s)`}
          </div>
        )}

        {showTemplateModal && selectedAttendance.contact_phone && (
          <GotalkSendTemplateModal
            isOpen={showTemplateModal}
            onClose={() => setShowTemplateModal(false)}
            contactPhone={selectedAttendance.contact_phone}
            contactName={selectedAttendance.contact_name || selectedAttendance.client_name || 'Contato'}
            onSuccess={() => {
              addToast({ type: 'success', title: 'Template enviado', message: 'Notificação HSM disparada com sucesso.' });
            }}
            onError={(msg) => addToast({ type: 'error', title: 'Erro ao enviar template', message: msg })}
          />
        )}

        <ToastContainer toasts={toasts} removeToast={removeToast} />
      </ConversationSurface>
    );
  }

  return (
    <ConversationSurface className="flex flex-col h-full bg-white overflow-hidden">
      <div className="px-4 py-3 bg-green-700 text-white shrink-0 flex items-center gap-2">
        <div className="text-green-200">{WA_ICON}</div>
        <div className="flex-1">
          <p className="text-xs font-bold">{title || 'Atendimentos GoTalk'}</p>
          <p className="text-[10px] text-green-200">{total} atendimento(s)</p>
        </div>
      </div>

      {!type && (
        <div className="flex gap-1 px-4 py-2 border-b border-gray-200 bg-gray-50 shrink-0">
          {(['', 'CLIENT', 'BANK'] as const).map(t => {
            const labels: Record<string, string> = { '': 'Todos', CLIENT: 'Cliente', BANK: 'Banco' };
            const active = typeFilter === t;
            return (
              <button
                key={t}
                onClick={() => handleTypeFilter(t)}
                className={`px-3 py-1 rounded-full text-xs font-semibold transition-colors ${active ? 'bg-green-700 text-white' : 'bg-white text-gray-600 border border-gray-200 hover:bg-gray-100'}`}
              >
                {labels[t]}
              </button>
            );
          })}
        </div>
      )}

      {showUnitFilter && !clientId && !collaboratorId && (
        <div className="flex items-center gap-2 px-4 py-2 border-b border-gray-100 bg-white shrink-0">
          <label className="text-[10px] font-bold text-gray-500 uppercase tracking-wide whitespace-nowrap">Unidade:</label>
          <select
            value={unitFilter}
            onChange={e => handleUnitFilter(e.target.value)}
            className="flex-1 text-xs border border-gray-200 rounded-lg px-2 py-1.5 bg-white outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="">Todas as unidades</option>
            {availableUnits.map(u => (
              <option key={u.id} value={u.id}>{u.name}</option>
            ))}
          </select>
        </div>
      )}

      <div className="flex-1 overflow-y-auto">
        {loading && (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-green-700" />
          </div>
        )}
        {!loading && attendances.length === 0 && (
          <div className="flex flex-col items-center justify-center py-12 text-gray-400 gap-2">
            <svg className="w-10 h-10 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <p className="text-sm">Nenhum atendimento encontrado.</p>
          </div>
        )}
        {!loading && attendances.map(att => (
          <button
            key={att.id}
            onClick={() => handleSelectAttendance(att)}
            className="w-full text-left px-4 py-3 border-b border-gray-100 hover:bg-green-50 transition-colors group"
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1 min-w-0">
                <p className="text-sm font-semibold text-gray-800 truncate group-hover:text-green-800">
                  {att.contact_name || att.client_name || att.contact_phone || 'Contato desconhecido'}
                </p>
                <p className="text-xs text-gray-500 truncate">
                  {att.operator_name ? `Operador: ${att.operator_name}` : 'Sem operador'}
                  {att.collaborator_name ? ` · ${att.collaborator_name}` : ''}
                </p>
                <p className="text-[10px] text-gray-400 mt-0.5">
                  {att.department || att.subject || ''}
                </p>
              </div>
              <div className="flex flex-col items-end gap-1 shrink-0">
                {statusBadge(att.status)}
                {typeBadge(att.type)}
                <p className="text-[10px] text-gray-400">{formatDateTime(att.started_at)}</p>
              </div>
            </div>
            <div className="flex items-center justify-between mt-1.5">
              <span className="text-[10px] text-gray-400">
                {att.message_count > 0 ? `${att.message_count} mensagem(s)` : 'Sem mensagens'}
                {att.last_message_at ? ` · última: ${formatTime(att.last_message_at)}` : ''}
              </span>
              <svg className="w-3.5 h-3.5 text-gray-300 group-hover:text-green-500 transition-colors" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </div>
          </button>
        ))}
      </div>

      {totalPages > 1 && (
        <div className="flex items-center justify-between px-4 py-2 border-t border-gray-200 bg-gray-50 shrink-0">
          <button
            onClick={() => setPage(p => Math.max(1, p - 1))}
            disabled={page <= 1}
            className="px-3 py-1 rounded text-xs font-semibold border border-gray-200 bg-white hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Anterior
          </button>
          <span className="text-xs text-gray-500">Pág. {page} / {totalPages}</span>
          <button
            onClick={() => setPage(p => Math.min(totalPages, p + 1))}
            disabled={page >= totalPages}
            className="px-3 py-1 rounded text-xs font-semibold border border-gray-200 bg-white hover:bg-gray-100 disabled:opacity-40 disabled:cursor-not-allowed"
          >
            Próxima
          </button>
        </div>
      )}
    </ConversationSurface>
  );
};

export default GotalkAttendanceViewer;

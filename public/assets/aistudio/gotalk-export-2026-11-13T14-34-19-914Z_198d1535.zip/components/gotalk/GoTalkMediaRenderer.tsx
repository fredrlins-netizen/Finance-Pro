import React, { useState } from 'react';

interface Props {
  messageId?: string | null;
  messageType: string;
  attachmentUrl?: string | null;
  attachmentName?: string | null;
  attachmentMime?: string | null;
  attachmentSize?: number | null;
  audioTranscript?: string | null;
  caption?: string | null;
  templateBody?: string | null;
  templateHeader?: string | null;
  templateFooter?: string | null;
  templateCategory?: string | null;
  templateStatus?: string | null;
}

function proxyUrl(messageId: string): string {
  return `/api/gotalk/media/${messageId}`;
}

function downloadUrl(messageId: string): string {
  return `/api/gotalk/media/${messageId}?download=1`;
}

function fmtBytes(bytes: number | null | undefined): string | null {
  if (!bytes || bytes <= 0) return null;
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

function extFromMime(mime: string | null | undefined, name: string | null | undefined): string {
  const m = (mime || '').toLowerCase();
  if (m.includes('jpeg') || m.includes('jpg')) return 'jpg';
  if (m.includes('png')) return 'png';
  if (m.includes('gif')) return 'gif';
  if (m.includes('webp')) return 'webp';
  if (m.includes('pdf')) return 'pdf';
  if (m.includes('mp4')) return 'mp4';
  if (m.includes('webm')) return 'webm';
  if (m.includes('ogg')) return 'ogg';
  if (m.includes('mp3') || m.includes('mpeg')) return 'mp3';
  if (m.includes('opus')) return 'opus';
  if (m.includes('aac')) return 'aac';
  if (m.includes('wav')) return 'wav';
  if (m.includes('docx') || m.includes('word')) return 'docx';
  if (m.includes('xlsx') || m.includes('excel') || m.includes('sheet')) return 'xlsx';
  if (m.includes('pptx') || m.includes('powerpoint')) return 'pptx';
  if (m.includes('zip')) return 'zip';
  const dotPos = (name || '').lastIndexOf('.');
  if (dotPos !== -1) return (name || '').slice(dotPos + 1).toLowerCase();
  return 'bin';
}

function fmtLabel(mime: string | null | undefined): string | null {
  const m = (mime || '').toLowerCase();
  if (m.includes('pdf')) return 'PDF';
  if (m.includes('jpeg') || m.includes('jpg')) return 'JPEG';
  if (m.includes('png')) return 'PNG';
  if (m.includes('gif')) return 'GIF';
  if (m.includes('webp')) return 'WEBP';
  if (m.includes('mp4')) return 'MP4';
  if (m.includes('webm')) return 'WEBM';
  if (m.includes('mp3') || m.includes('mpeg')) return 'MP3';
  if (m.includes('ogg')) return 'OGG';
  if (m.includes('opus')) return 'OPUS';
  if (m.includes('aac')) return 'AAC';
  if (m.includes('wav')) return 'WAV';
  if (m.includes('docx') || m.includes('word')) return 'DOCX';
  if (m.includes('xlsx') || m.includes('sheet')) return 'XLSX';
  if (m.includes('pptx') || m.includes('powerpoint')) return 'PPTX';
  if (m.includes('zip')) return 'ZIP';
  return null;
}

function FileMeta({ mime, size }: { mime?: string | null; size?: number | null }) {
  const label = fmtLabel(mime);
  const sizeStr = fmtBytes(size);
  if (!label && !sizeStr) return null;
  return (
    <span className="inline-flex items-center gap-1 text-[9px] font-semibold text-gray-600 mt-0.5">
      {label && (
        <span className="bg-gray-100 text-gray-600 px-1 py-0.5 rounded font-bold tracking-wide">
          {label}
        </span>
      )}
      {sizeStr && <span>{sizeStr}</span>}
    </span>
  );
}

function getDocIcon(mime: string | null | undefined) {
  const m = (mime || '').toLowerCase();
  if (m.includes('pdf')) return '📄';
  if (m.includes('word') || m.includes('docx') || m.includes('doc')) return '📝';
  if (m.includes('sheet') || m.includes('excel') || m.includes('xlsx') || m.includes('xls')) return '📊';
  if (m.includes('presentation') || m.includes('powerpoint') || m.includes('pptx') || m.includes('ppt')) return '📊';
  if (m.includes('zip') || m.includes('rar') || m.includes('7z') || m.includes('tar')) return '🗜️';
  return '📎';
}

function renderFormattedText(text: string): React.ReactNode {
  const parts = text.split(/(\*[^*]+\*)/g);
  return parts.map((part, i) =>
    part.startsWith('*') && part.endsWith('*')
      ? <strong key={i}>{part.slice(1, -1)}</strong>
      : <span key={i}>{part}</span>
  );
}

function DownloadButton({ href, fileName }: { href: string; fileName: string }) {
  return (
    <a
      href={href}
      download={fileName}
      className="inline-flex items-center gap-1 text-[10px] text-gray-700 hover:text-gray-900 mt-1 transition-colors"
      onClick={(e) => e.stopPropagation()}
      title="Baixar arquivo"
    >
      <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
      </svg>
      Baixar
    </a>
  );
}

function MediaError({ fallbackUrl, fileName }: { fallbackUrl?: string | null; fileName?: string | null }) {
  return (
    <div className="flex items-center gap-2 text-xs text-red-500 italic">
      <svg className="w-3.5 h-3.5 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
      </svg>
      Mídia indisponível
      {fallbackUrl && (
        <a href={fallbackUrl} target="_blank" rel="noopener noreferrer" className="underline text-blue-500 ml-1">
          link direto
        </a>
      )}
    </div>
  );
}

interface InteractiveRow {
  id: string;
  title: string;
  description?: string;
}

interface InteractiveSection {
  title?: string;
  rows?: InteractiveRow[];
}

interface InteractiveButton {
  reply?: { id: string; title: string };
  type?: string;
}

interface InteractivePayload {
  type?: string;
  header?: { text?: string; type?: string };
  body?: { text?: string };
  footer?: { text?: string };
  action?: {
    button?: string;
    sections?: InteractiveSection[];
    buttons?: InteractiveButton[];
  };
}

function tryParseInteractive(body: string | null | undefined): InteractivePayload | null {
  if (!body) return null;
  const trimmed = body.trim();
  if (!trimmed.startsWith('{')) return null;
  try {
    const parsed = JSON.parse(trimmed);
    if (parsed?.type === 'interactive' && parsed?.interactive) {
      return parsed.interactive as InteractivePayload;
    }
    if (parsed?.interactive) return parsed.interactive as InteractivePayload;
  } catch {
    return null;
  }
  return null;
}

function InteractiveMessageCard({ interactive }: { interactive: InteractivePayload }) {
  const isList = interactive.type === 'list';
  const isButtons = interactive.type === 'button';
  const sections = interactive.action?.sections || [];
  const buttons = interactive.action?.buttons || [];
  const allRows = sections.flatMap(s => s.rows || []);

  return (
    <div className="rounded-lg overflow-hidden border border-green-200 bg-white max-w-[270px] text-sm shadow-sm">
      {interactive.header?.text && (
        <div className="bg-green-600 text-white px-3 py-2 text-xs font-bold tracking-wide">
          {interactive.header.text}
        </div>
      )}
      {interactive.body?.text && (
        <div className="px-3 py-2 text-gray-800 leading-snug text-[13px] whitespace-pre-wrap">
          {renderFormattedText(interactive.body.text)}
        </div>
      )}
      {isList && allRows.length > 0 && (
        <div className="border-t border-gray-100">
          {sections.map((section, si) => (
            <div key={si}>
              {section.title && (
                <div className="px-3 pt-2 pb-0.5 text-[10px] font-bold uppercase text-gray-400 tracking-wider">
                  {section.title}
                </div>
              )}
              {(section.rows || []).map((row, ri) => (
                <div key={ri} className="flex items-start gap-2 px-3 py-1.5 border-b border-gray-50 last:border-0">
                  <div className="min-w-0">
                    <p className="text-[12px] font-medium text-gray-800 leading-tight">{row.title}</p>
                    {row.description && (
                      <p className="text-[10px] text-gray-500 mt-0.5 leading-snug">{row.description}</p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
      {isButtons && buttons.length > 0 && (
        <div className="border-t border-gray-100 flex flex-col gap-0.5 p-2">
          {buttons.map((btn, i) => (
            <div key={i} className="text-center text-[12px] font-medium text-green-700 border border-green-200 rounded py-1 px-2 bg-green-50">
              {btn.reply?.title || 'Opção'}
            </div>
          ))}
        </div>
      )}
      {interactive.action?.button && isList && (
        <div className="border-t border-green-100 px-3 py-1.5">
          <div className="flex items-center justify-center gap-1.5 text-[11px] font-semibold text-green-700">
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M4 6h16M4 12h16M4 18h7" />
            </svg>
            {interactive.action.button}
          </div>
        </div>
      )}
      {interactive.footer?.text && (
        <div className="px-3 pb-2 pt-0.5 text-[10px] text-gray-400 italic">
          {interactive.footer.text}
        </div>
      )}
    </div>
  );
}

const GoTalkMediaRenderer: React.FC<Props> = ({
  messageId,
  messageType,
  attachmentUrl,
  attachmentName,
  attachmentMime,
  attachmentSize,
  audioTranscript,
  caption,
  templateBody,
  templateHeader,
  templateFooter,
  templateCategory,
  templateStatus,
}) => {
  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [transcriptOpen, setTranscriptOpen] = useState(false);
  const [pdfExpanded, setPdfExpanded] = useState(false);
  const [imgError, setImgError] = useState(false);
  const [audioError, setAudioError] = useState(false);
  const [videoError, setVideoError] = useState(false);

  const type = (messageType || 'TEXT').toUpperCase();
  const hasProxy = !!messageId;
  const mediaSrc = hasProxy ? proxyUrl(messageId!) : (attachmentUrl || undefined);
  const dlHref = hasProxy ? downloadUrl(messageId!) : attachmentUrl || '#';
  const ext = extFromMime(attachmentMime, attachmentName);
  const baseName = attachmentName
    ? attachmentName.replace(/\.[^.]+$/, '')
    : `media-${messageId || 'arquivo'}`;
  const fileName = `${baseName}.${ext}`;

  if (type === 'IMAGE') {
    if (!mediaSrc) return <p className="text-sm text-gray-400 italic">Imagem sem URL</p>;
    return (
      <div className="space-y-1">
        {imgError ? (
          <MediaError fallbackUrl={attachmentUrl} fileName={fileName} />
        ) : (
          <>
            <img
              src={mediaSrc}
              alt={attachmentName || 'imagem'}
              className="max-w-[200px] rounded-lg cursor-zoom-in hover:opacity-90 transition-opacity border border-gray-200"
              onError={() => setImgError(true)}
              onClick={() => setLightboxOpen(true)}
            />
            <div className="flex items-center gap-2">
              {hasProxy && <DownloadButton href={dlHref} fileName={fileName} />}
              <FileMeta mime={attachmentMime} size={attachmentSize} />
            </div>
          </>
        )}
        {caption && <p className="text-sm mt-1">{caption}</p>}

        {lightboxOpen && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-black/80"
            onClick={() => setLightboxOpen(false)}
          >
            <div className="relative max-w-[90vw] max-h-[90vh]" onClick={(e) => e.stopPropagation()}>
              <img
                src={mediaSrc}
                alt={attachmentName || 'imagem'}
                className="max-w-full max-h-[85vh] rounded-lg object-contain"
              />
              <div className="absolute top-2 right-2 flex gap-2">
                {hasProxy && (
                  <a
                    href={dlHref}
                    download={fileName}
                    className="flex items-center gap-1 bg-white/90 hover:bg-white text-gray-800 text-xs px-2 py-1 rounded shadow transition-colors"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                    </svg>
                    Baixar
                  </a>
                )}
                <button
                  className="flex items-center bg-white/90 hover:bg-white text-gray-800 text-xs px-2 py-1 rounded shadow transition-colors"
                  onClick={() => setLightboxOpen(false)}
                >
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (type === 'STICKER') {
    if (!mediaSrc) return <p className="text-sm text-gray-400 italic">Sticker sem URL</p>;
    return (
      <div>
        {imgError ? (
          <MediaError fallbackUrl={attachmentUrl} />
        ) : (
          <img
            src={mediaSrc}
            alt="sticker"
            className="w-20 h-20 object-contain"
            onError={() => setImgError(true)}
          />
        )}
      </div>
    );
  }

  if (type === 'AUDIO' || type === 'VOICE' || type === 'PTT') {
    if (!mediaSrc) return <p className="text-sm text-gray-400 italic">Áudio sem URL</p>;
    return (
      <div className="space-y-1 min-w-[220px]">
        {audioError ? (
          <MediaError fallbackUrl={attachmentUrl} fileName={fileName} />
        ) : (
          <audio
            controls
            src={mediaSrc}
            className="w-full h-8"
            onError={() => setAudioError(true)}
          />
        )}
        <div className="flex items-center gap-2">
          {hasProxy && !audioError && <DownloadButton href={dlHref} fileName={fileName} />}
          <FileMeta mime={attachmentMime} size={attachmentSize} />
        </div>
        {audioTranscript && (
          <div>
            <button
              type="button"
              aria-expanded={transcriptOpen}
              className="text-[10px] text-gray-700 hover:text-gray-900 flex items-center gap-1"
              onClick={() => setTranscriptOpen(!transcriptOpen)}
            >
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d={transcriptOpen ? 'M5 15l7-7 7 7' : 'M19 9l-7 7-7-7'} />
              </svg>
              Transcrição
            </button>
            {transcriptOpen && (
              <p className="text-xs italic text-gray-700 mt-0.5 leading-relaxed">"{audioTranscript}"</p>
            )}
          </div>
        )}
      </div>
    );
  }

  if (type === 'VIDEO') {
    if (!mediaSrc) return <p className="text-sm text-gray-400 italic">Vídeo sem URL</p>;
    return (
      <div className="space-y-1">
        {videoError ? (
          <MediaError fallbackUrl={attachmentUrl} fileName={fileName} />
        ) : (
          <video
            controls
            src={mediaSrc}
            className="max-w-[240px] rounded-lg border border-gray-200"
            style={{ maxHeight: '180px' }}
            onError={() => setVideoError(true)}
          />
        )}
        <div className="flex items-center gap-2">
          {hasProxy && !videoError && <DownloadButton href={dlHref} fileName={fileName} />}
          <FileMeta mime={attachmentMime} size={attachmentSize} />
        </div>
        {caption && <p className="text-sm mt-1">{caption}</p>}
      </div>
    );
  }

  if (type === 'DOCUMENT') {
    if (!mediaSrc) return <p className="text-sm text-gray-400 italic">Documento sem URL</p>;
    const isPdf = (attachmentMime || '').toLowerCase().includes('pdf')
      || (attachmentName || '').toLowerCase().endsWith('.pdf');
    if (isPdf) {
      return (
        <div className="flex flex-col gap-1 max-w-[260px]">
          <div className="flex items-center gap-2">
            <span className="text-xl" aria-hidden="true">📄</span>
            <div className="flex flex-col min-w-0">
              <span className="text-sm text-gray-700 break-all leading-tight">
                {attachmentName || 'Documento PDF'}
              </span>
              <FileMeta mime={attachmentMime} size={attachmentSize} />
            </div>
          </div>
          <button
            type="button"
            onClick={() => setPdfExpanded(prev => !prev)}
            className="self-start text-[10px] text-green-700 hover:text-green-900 flex items-center gap-1 font-medium"
          >
            <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d={pdfExpanded ? 'M5 15l7-7 7 7' : 'M19 9l-7 7-7-7'} />
            </svg>
            {pdfExpanded ? 'Recolher' : 'Visualizar PDF'}
          </button>
          {pdfExpanded && (
            /* Using <object> (not <embed>) to support nested fallback content
               when the browser cannot render the PDF inline */
            <object
              data={mediaSrc}
              type="application/pdf"
              className="w-full rounded-lg border border-gray-200"
              style={{ height: '320px' }}
            >
              <div className="flex flex-col items-center justify-center gap-2 h-full bg-gray-50 rounded-lg border border-gray-200 py-6 text-center">
                <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <p className="text-xs text-gray-500">Seu navegador não conseguiu exibir este PDF inline.</p>
                <a
                  href={mediaSrc}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-blue-600 hover:underline font-medium"
                >
                  Abrir em nova aba
                </a>
                {hasProxy && (
                  <DownloadButton href={dlHref} fileName={fileName} />
                )}
              </div>
            </object>
          )}
          {!pdfExpanded && hasProxy && <DownloadButton href={dlHref} fileName={fileName} />}
        </div>
      );
    }
    return (
      <div className="flex items-center gap-2">
        <span className="text-xl" aria-hidden="true">{getDocIcon(attachmentMime)}</span>
        <div className="flex flex-col">
          <span className="text-sm text-gray-700 break-all">{attachmentName || 'Documento'}</span>
          <FileMeta mime={attachmentMime} size={attachmentSize} />
          {hasProxy ? (
            <DownloadButton href={dlHref} fileName={fileName} />
          ) : (
            <a
              href={attachmentUrl || '#'}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[10px] text-blue-600 hover:underline"
            >
              Abrir
            </a>
          )}
        </div>
      </div>
    );
  }

  if (type === 'TEMPLATE') {
    const bodyToShow = templateBody || (caption !== attachmentName ? caption : null);
    const headerToShow = templateHeader;
    const footerToShow = templateFooter;
    const isNameOnly = !bodyToShow;

    return (
      <div className="rounded-lg overflow-hidden border border-green-200 bg-white max-w-[270px] shadow-sm">
        <div className="bg-green-600 px-3 py-1.5 flex items-center justify-between gap-2">
          <span className="text-white text-[10px] font-bold uppercase tracking-wide">Template HSM</span>
          {templateCategory && (
            <span className="text-green-100 text-[9px] bg-green-700/60 px-1.5 py-0.5 rounded">
              {templateCategory}
            </span>
          )}
        </div>
        {headerToShow && (
          <div className="px-3 pt-2 text-[11px] font-semibold text-gray-700">{headerToShow}</div>
        )}
        <div className="px-3 py-2 text-[13px] text-gray-800 leading-snug whitespace-pre-wrap">
          {isNameOnly ? (
            <span className="text-gray-400 italic">
              {attachmentName || 'template'}
              {templateStatus && templateStatus !== 'APPROVED' && (
                <span className="ml-1 text-yellow-600">({templateStatus})</span>
              )}
            </span>
          ) : (
            renderFormattedText(bodyToShow!)
          )}
        </div>
        {footerToShow && (
          <div className="px-3 pb-2 text-[10px] text-gray-400 italic border-t border-gray-100 pt-1">
            {footerToShow}
          </div>
        )}
      </div>
    );
  }

  if (type === 'TEXT') {
    const interactive = tryParseInteractive(caption);
    if (interactive) {
      return <InteractiveMessageCard interactive={interactive} />;
    }
    return (
      <p className="text-sm whitespace-pre-wrap break-words">
        {caption ? renderFormattedText(caption) : <span className="text-gray-400 italic">(mensagem vazia)</span>}
      </p>
    );
  }

  return (
    <p className="text-sm whitespace-pre-wrap break-words">
      {caption ? renderFormattedText(caption) : <span className="text-gray-400 italic">(mensagem vazia)</span>}
    </p>
  );
};

export default GoTalkMediaRenderer;

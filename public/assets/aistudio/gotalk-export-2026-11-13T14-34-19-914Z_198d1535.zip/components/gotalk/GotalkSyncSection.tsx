import React, { useState, useEffect, useCallback } from 'react';

interface GotalkContact {
  id: string;
  name: string | null;
  phone_number: string | null;
  gotalk_id: string;
  linked_at?: string | null;
}

interface LastMessage {
  body: string;
  direction: string;
  sent_at: string;
}

interface LinkStatus {
  linked: boolean;
  contact: GotalkContact | null;
  lastMessage: LastMessage | null;
}

interface UnlinkedContact {
  id: string;
  name: string | null;
  phone_number: string | null;
  gotalk_id: string;
}

interface Props {
  clientId: string;
  clientPhone?: string;
  onChatOpen?: () => void;
}

const GotalkSyncSection: React.FC<Props> = ({ clientId, clientPhone, onChatOpen }) => {
  const [webhookUrl, setWebhookUrl] = useState<string>('');
  const [isOpen, setIsOpen] = useState(false);
  const [status, setStatus] = useState<LinkStatus | null>(null);
  const [loading, setLoading] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [unlinking, setUnlinking] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [unlinkedContacts, setUnlinkedContacts] = useState<UnlinkedContact[]>([]);
  const [loadingContacts, setLoadingContacts] = useState(false);
  const [showContactSearch, setShowContactSearch] = useState(false);
  const [linkingId, setLinkingId] = useState<string | null>(null);

  const fetchStatus = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch(`/api/gotalk/client/${clientId}`);
      if (res.ok) setStatus(await res.json());
    } finally {
      setLoading(false);
    }
  }, [clientId]);

  // Fetch canonical webhook URL from server (uses REPLIT_DEV_DOMAIN/prod domain)
  useEffect(() => {
    fetch('/api/gotalk/webhook-url', { credentials: 'include' })
      .then(r => r.ok ? r.json() : null)
      .then(d => { if (d?.webhookUrl) setWebhookUrl(d.webhookUrl); })
      .catch(() => {});
  }, []);

  // Preload on mount so badge shows immediately, refresh when section expands
  useEffect(() => {
    fetchStatus();
  }, [fetchStatus]);

  useEffect(() => {
    if (isOpen) fetchStatus();
  }, [isOpen, fetchStatus]);

  const handleSyncByPhone = async () => {
    setSyncing(true);
    setMsg(null);
    try {
      const res = await fetch(`/api/gotalk/client/${clientId}/sync-phone`, { method: 'POST' });
      const data = await res.json();
      setMsg(data.message || (data.success ? 'Vinculado!' : 'Não encontrado.'));
      if (data.success) await fetchStatus();
    } catch {
      setMsg('Erro ao sincronizar.');
    } finally {
      setSyncing(false);
    }
  };

  const handleUnlink = async () => {
    if (!status?.contact) return;
    if (!window.confirm('Desvincular contato WhatsApp deste cliente?')) return;
    setUnlinking(true);
    setMsg(null);
    try {
      const res = await fetch('/api/gotalk/unlink-client', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gotalkContactId: status.contact.id }),
      });
      const data = await res.json();
      if (data.success) {
        setMsg('Desvinculado com sucesso.');
        await fetchStatus();
      }
    } catch {
      setMsg('Erro ao desvincular.');
    } finally {
      setUnlinking(false);
    }
  };

  const searchContacts = useCallback(async (q: string) => {
    setLoadingContacts(true);
    try {
      const params = new URLSearchParams({ linked: 'false', limit: '20' });
      if (q.trim()) params.set('search', q.trim());
      const res = await fetch(`/api/gotalk/contacts?${params.toString()}`);
      if (!res.ok) return;
      const data = await res.json();
      setUnlinkedContacts(data.data || []);
    } finally {
      setLoadingContacts(false);
    }
  }, []);

  useEffect(() => {
    if (showContactSearch) {
      const timer = setTimeout(() => searchContacts(searchTerm), 400);
      return () => clearTimeout(timer);
    }
  }, [searchTerm, showContactSearch, searchContacts]);

  const handleShowContactSearch = () => {
    setShowContactSearch(true);
    searchContacts(searchTerm);
  };

  const handleLinkContact = async (contact: UnlinkedContact) => {
    setLinkingId(contact.id);
    setMsg(null);
    try {
      const res = await fetch('/api/gotalk/link-client', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ gotalkContactId: contact.id, clientId }),
      });
      const data = await res.json();
      if (data.success) {
        setMsg(`Vinculado ao contato "${contact.name || contact.phone_number}" com sucesso.`);
        setShowContactSearch(false);
        await fetchStatus();
      } else {
        setMsg(data.error || 'Erro ao vincular.');
      }
    } catch {
      setMsg('Erro ao vincular contato.');
    } finally {
      setLinkingId(null);
    }
  };

  const formatDate = (iso?: string | null) => {
    if (!iso) return '—';
    return new Date(iso).toLocaleString('pt-BR', {
      day: '2-digit', month: '2-digit', year: '2-digit',
      hour: '2-digit', minute: '2-digit',
    });
  };

  return (
    <div className="mt-4 border border-gray-200 rounded-lg overflow-hidden">
      <button
        type="button"
        onClick={() => setIsOpen(v => !v)}
        className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 hover:bg-gray-100 transition-colors"
      >
        <div className="flex items-center gap-2">
          <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 24 24">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
          <span className="text-sm font-semibold text-gray-700">WhatsApp / Gotalk</span>
          {status?.linked && (
            <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium">Vinculado</span>
          )}
          {status && !status.linked && (
            <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">Não vinculado</span>
          )}
        </div>
        <svg className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && (
        <div className="px-4 py-3 bg-white animate-fade-in space-y-3">
          {loading && <p className="text-sm text-gray-400 py-2">Carregando...</p>}

          {!loading && status?.linked && status.contact && (
            <div className="space-y-2">
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-800">{status.contact.name || '—'}</p>
                  <p className="text-xs text-gray-500">{status.contact.phone_number}</p>
                  {status.lastMessage && (
                    <p className="text-xs text-gray-400 mt-1">
                      Última mensagem: {formatDate(status.lastMessage.sent_at)}
                      {status.lastMessage.body && ` — "${status.lastMessage.body.substring(0, 60)}${status.lastMessage.body.length > 60 ? '…' : ''}"`}
                    </p>
                  )}
                </div>
                <div className="flex gap-2 flex-shrink-0 ml-3">
                  {onChatOpen && (
                    <button
                      type="button"
                      onClick={onChatOpen}
                      className="text-xs bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-lg font-medium transition-colors"
                    >
                      Abrir Chat
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={handleUnlink}
                    disabled={unlinking}
                    className="text-xs bg-white border border-red-300 text-red-600 hover:bg-red-50 px-3 py-1.5 rounded-lg font-medium transition-colors disabled:opacity-50"
                  >
                    {unlinking ? 'Desvinculando...' : 'Desvincular'}
                  </button>
                </div>
              </div>
            </div>
          )}

          {!loading && status && !status.linked && (
            <div className="space-y-3">
              <p className="text-sm text-gray-500">
                Nenhum contato WhatsApp vinculado.
                {clientPhone && <span className="ml-1 font-medium">Tel: {clientPhone}</span>}
              </p>

              <div className="flex gap-2 flex-wrap">
                <button
                  type="button"
                  onClick={handleSyncByPhone}
                  disabled={syncing}
                  className="flex items-center gap-1.5 text-sm bg-green-600 hover:bg-green-700 text-white px-3 py-1.5 rounded-lg font-medium transition-colors disabled:opacity-50"
                >
                  {syncing ? (
                    <>
                      <span className="inline-block w-3 h-3 border-2 border-white border-t-transparent rounded-full animate-spin" />
                      Sincronizando...
                    </>
                  ) : (
                    <>
                      <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                      </svg>
                      Sincronizar por Telefone
                    </>
                  )}
                </button>
                <button
                  type="button"
                  onClick={handleShowContactSearch}
                  className="flex items-center gap-1.5 text-sm bg-white border border-gray-300 text-gray-600 hover:bg-gray-50 px-3 py-1.5 rounded-lg font-medium transition-colors"
                >
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                  </svg>
                  Buscar e Vincular Manualmente
                </button>
              </div>

              {showContactSearch && (
                <div className="border border-gray-200 rounded-lg overflow-hidden animate-fade-in">
                  <div className="flex items-center gap-2 px-3 py-2 bg-gray-50 border-b">
                    <svg className="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                    <input
                      type="text"
                      placeholder="Buscar por nome ou telefone..."
                      className="flex-1 text-sm bg-transparent outline-none"
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                      autoFocus
                    />
                    <button
                      type="button"
                      onClick={() => setShowContactSearch(false)}
                      className="text-gray-400 hover:text-gray-600 text-xs"
                    >
                      Fechar
                    </button>
                  </div>
                  <div className="max-h-48 overflow-y-auto">
                    {loadingContacts && (
                      <p className="text-xs text-gray-400 text-center py-3">Buscando...</p>
                    )}
                    {!loadingContacts && unlinkedContacts.length === 0 && (
                      <p className="text-xs text-gray-400 text-center py-3">Nenhum contato não vinculado encontrado.</p>
                    )}
                    {!loadingContacts && unlinkedContacts.map(c => (
                      <div key={c.id} className="flex items-center justify-between px-3 py-2 border-b border-gray-100 last:border-0 hover:bg-gray-50">
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-gray-800 truncate">{c.name || '(sem nome)'}</p>
                          <p className="text-xs text-gray-500">{c.phone_number || '—'}</p>
                        </div>
                        <button
                          type="button"
                          onClick={() => handleLinkContact(c)}
                          disabled={linkingId === c.id}
                          className="flex-shrink-0 ml-3 text-xs bg-green-600 hover:bg-green-700 text-white px-2.5 py-1 rounded font-medium transition-colors disabled:opacity-50"
                        >
                          {linkingId === c.id ? '...' : 'Vincular'}
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {msg && (
            <p className={`text-xs px-3 py-2 rounded-lg ${msg.includes('sucesso') || msg.includes('Vinculado') ? 'bg-green-50 text-green-700' : 'bg-yellow-50 text-yellow-700'}`}>
              {msg}
            </p>
          )}

          <div className="pt-1 border-t border-gray-100">
            <p className="text-xs text-gray-400 mb-1 font-medium">URL do Webhook GoTalk</p>
            <div className="flex items-center gap-2">
              <code className="flex-1 text-xs bg-gray-50 border border-gray-200 rounded px-2 py-1.5 text-gray-600 truncate select-all">
                {webhookUrl}
              </code>
              <button
                type="button"
                title="Copiar URL"
                onClick={() => navigator.clipboard.writeText(webhookUrl)}
                className="flex-shrink-0 p-1.5 rounded hover:bg-gray-100 text-gray-400 hover:text-gray-600 transition-colors"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </button>
            </div>
            <p className="text-[10px] text-gray-400 mt-1">Configure esta URL como webhook no painel do GoTalk para receber mensagens em tempo real.</p>
          </div>
        </div>
      )}
    </div>
  );
};

export default GotalkSyncSection;

import React, { useState, useEffect, useRef } from 'react';
import { useMessaging } from '../../contexts/MessagingContext';
import { useWhatsappMutePrefs } from '../../hooks/useWhatsappMutePrefs';

interface NotificationBellProps {
    onOpenInbox: () => void;
    compact?: boolean;
}

function timeAgo(dateStr: string): string {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'agora';
    if (mins < 60) return `há ${mins}min`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `há ${hrs}h`;
    return `há ${Math.floor(hrs / 24)}d`;
}

const NotificationBell: React.FC<NotificationBellProps> = ({ onOpenInbox, compact = false }) => {
    const { messages, unreadCount, markAsRead, markAllAsRead } = useMessaging();
    const mutePrefs = useWhatsappMutePrefs();
    const [open, setOpen] = useState(false);
    const [wiggle, setWiggle] = useState(false);
    const ref = useRef<HTMLDivElement>(null);
    const prevUnread = useRef(unreadCount);

    useEffect(() => {
        if (unreadCount > prevUnread.current) {
            setWiggle(true);
            setTimeout(() => setWiggle(false), 1000);
        }
        prevUnread.current = unreadCount;
    }, [unreadCount]);

    useEffect(() => {
        const handler = (e: MouseEvent) => {
            if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
        };
        document.addEventListener('mousedown', handler);
        return () => document.removeEventListener('mousedown', handler);
    }, []);

    const recentUnread = messages.filter(m => !m.read).slice(0, 5);
    const hasMutedItems = mutePrefs.globalMuted || mutePrefs.mutedConversations.length > 0;

    return (
        <div ref={ref} className="relative">
            <button
                onClick={() => setOpen(o => !o)}
                className={`relative flex items-center justify-center rounded-full transition-all ${compact ? 'w-7 h-7' : 'w-9 h-9'} ${open ? 'bg-white/20' : 'hover:bg-white/10'}`}
                title="Notificações"
            >
                <svg
                    className={`${compact ? 'w-4 h-4' : 'w-5 h-5'} text-white transition-transform ${wiggle ? 'animate-[wiggle_0.5s_ease-in-out]' : ''}`}
                    fill="none" viewBox="0 0 24 24" stroke="currentColor"
                >
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                {unreadCount > 0 && (
                    <span className={`absolute -top-1 -right-1 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1 ${unreadCount > 0 ? 'animate-bounce' : ''}`}>
                        {unreadCount > 99 ? '99+' : unreadCount}
                    </span>
                )}
                {hasMutedItems && (
                    <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-yellow-400 rounded-full border border-white flex items-center justify-center" title="Notificações WhatsApp silenciadas">
                        <svg className="w-2 h-2 text-yellow-900" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M9.383 3.076A1 1 0 0110 4v12a1 1 0 01-1.707.707L4.586 13H2a1 1 0 01-1-1V8a1 1 0 011-1h2.586l3.707-3.707a1 1 0 011.09-.217zM14.657 2.929a1 1 0 011.414 0A9.972 9.972 0 0119 10a9.972 9.972 0 01-2.929 7.071 1 1 0 01-1.414-1.414A7.971 7.971 0 0017 10c0-2.21-.894-4.208-2.343-5.657a1 1 0 010-1.414zm-2.829 2.828a1 1 0 011.415 0A5.983 5.983 0 0115 10a5.984 5.984 0 01-1.757 4.243 1 1 0 01-1.415-1.415A3.984 3.984 0 0013 10a3.983 3.983 0 00-1.172-2.828 1 1 0 010-1.415z" clipRule="evenodd" />
                        </svg>
                    </span>
                )}
            </button>

            {open && (
                <div className="absolute right-0 top-full mt-2 w-80 bg-white rounded-2xl shadow-2xl border border-gray-100 z-[9999] overflow-hidden animate-fade-in">
                    <div className="bg-moss-800 text-white px-4 py-3 flex items-center justify-between">
                        <span className="font-semibold text-sm">Notificações</span>
                        {unreadCount > 0 && (
                            <button onClick={() => { markAllAsRead(); setOpen(false); }} className="text-[11px] text-white/70 hover:text-white underline">
                                Marcar todas lidas
                            </button>
                        )}
                    </div>

                    {recentUnread.length === 0 ? (
                        <div className="py-10 text-center text-gray-400 text-sm">
                            <svg className="w-10 h-10 mx-auto mb-2 text-gray-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                            </svg>
                            Nenhuma mensagem não lida
                        </div>
                    ) : (
                        <div className="max-h-72 overflow-y-auto divide-y divide-gray-50">
                            {recentUnread.map(msg => (
                                <button
                                    key={msg.id}
                                    onClick={() => { markAsRead(msg.id); setOpen(false); onOpenInbox(); }}
                                    className="w-full text-left px-4 py-3 hover:bg-moss-50 transition-colors flex items-start gap-3"
                                >
                                    <div className={`w-9 h-9 rounded-full flex-shrink-0 flex items-center justify-center text-sm font-bold ${msg.is_system ? 'bg-slate-700 text-white' : 'bg-moss-100 text-moss-800'}`}>
                                        {msg.is_system ? '⚙' : msg.sender_name.charAt(0).toUpperCase()}
                                    </div>
                                    <div className="flex-1 min-w-0">
                                        <div className="flex items-center justify-between gap-1">
                                            <span className="font-semibold text-xs text-gray-800 truncate">{msg.is_system ? 'Sistema Invicta' : msg.sender_name}</span>
                                            <div className="flex items-center gap-1 flex-shrink-0">
                                                {msg.is_system && <span className="px-1.5 py-0.5 rounded-full bg-blue-100 text-blue-700 text-[9px] font-bold">SISTEMA</span>}
                                                {msg.recipient_type === 'GROUP' && <span className="px-1.5 py-0.5 rounded-full bg-green-100 text-green-700 text-[9px] font-bold">GRUPO</span>}
                                                <span className="text-[10px] text-gray-400">{timeAgo(msg.created_at)}</span>
                                            </div>
                                        </div>
                                        {msg.subject && <div className="text-[11px] font-medium text-gray-700 truncate">{msg.subject}</div>}
                                        <div className="text-[11px] text-gray-500 truncate">{msg.body.substring(0, 60)}{msg.body.length > 60 ? '…' : ''}</div>
                                    </div>
                                </button>
                            ))}
                        </div>
                    )}

                    <div className="border-t border-gray-100 px-4 py-2.5">
                        <button
                            onClick={() => { setOpen(false); onOpenInbox(); }}
                            className="w-full text-center text-xs font-semibold text-moss-700 hover:text-moss-900 transition-colors py-1"
                        >
                            Ver caixa de entrada completa →
                        </button>
                    </div>

                    {/* WhatsApp notification mute controls */}
                    <div className="border-t border-gray-100 bg-gray-50 px-4 py-3">
                        <p className="text-[10px] font-semibold text-gray-500 uppercase tracking-wide mb-2 flex items-center gap-1">
                            <span>📱</span> Notificações WhatsApp
                        </p>
                        <div className="flex items-center justify-between">
                            <span className="text-xs text-gray-600">
                                {mutePrefs.globalMuted ? 'Todas silenciadas' : 'Ativas'}
                            </span>
                            <button
                                onClick={() => mutePrefs.globalMuted ? mutePrefs.unmuteGlobal() : mutePrefs.muteGlobal()}
                                className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${mutePrefs.globalMuted ? 'bg-gray-300' : 'bg-green-500'}`}
                                title={mutePrefs.globalMuted ? 'Reativar notificações' : 'Silenciar todas as notificações'}
                            >
                                <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow transition-transform ${mutePrefs.globalMuted ? 'translate-x-1' : 'translate-x-4'}`} />
                            </button>
                        </div>

                        {mutePrefs.mutedConversations.length > 0 && (
                            <div className="mt-2 pt-2 border-t border-gray-200">
                                <p className="text-[10px] text-gray-500 mb-1.5">
                                    {mutePrefs.mutedConversations.length} contato{mutePrefs.mutedConversations.length > 1 ? 's' : ''} silenciado{mutePrefs.mutedConversations.length > 1 ? 's' : ''}
                                </p>
                                <button
                                    onClick={() => mutePrefs.mutedConversations.forEach(id => mutePrefs.unmuteConversation(id))}
                                    className="text-[11px] text-green-700 hover:text-green-900 font-medium underline"
                                >
                                    Reativar todos os contatos
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
};

export default NotificationBell;

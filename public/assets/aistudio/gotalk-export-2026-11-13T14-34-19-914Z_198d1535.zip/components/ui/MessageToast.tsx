import React, { useEffect, useState } from 'react';

export interface MessageToastItem {
    id: string;
    senderName: string;
    senderInitials: string;
    body: string;
    createdAt: string;
    type: 'normal' | 'system' | 'urgent' | 'whatsapp';
    conversationId?: string;
}

interface MessageToastProps {
    toasts: MessageToastItem[];
    onDismiss: (id: string) => void;
    onView: (toast: MessageToastItem) => void;
    onMuteConversation?: (conversationId: string) => void;
    onMuteGlobal?: () => void;
}

const DURATION = 5000;

const SingleToast: React.FC<{
    toast: MessageToastItem;
    onDismiss: (id: string) => void;
    onView: (t: MessageToastItem) => void;
    onMuteConversation?: (conversationId: string) => void;
    onMuteGlobal?: () => void;
}> = React.memo(({ toast, onDismiss, onView, onMuteConversation, onMuteGlobal }) => {
    const [progress, setProgress] = useState(100);
    const [visible, setVisible] = useState(false);
    const [showMuteMenu, setShowMuteMenu] = useState(false);

    useEffect(() => {
        requestAnimationFrame(() => setVisible(true));
        const start = Date.now();
        const interval = setInterval(() => {
            const elapsed = Date.now() - start;
            const remaining = Math.max(0, 100 - (elapsed / DURATION) * 100);
            setProgress(remaining);
            if (remaining <= 0) {
                clearInterval(interval);
                setVisible(false);
                setTimeout(() => onDismiss(toast.id), 300);
            }
        }, 50);
        return () => clearInterval(interval);
    }, []);

    const isUrgent = toast.type === 'urgent';
    const isSystem = toast.type === 'system';
    const isWhatsapp = toast.type === 'whatsapp';

    const headerBg = isUrgent ? 'bg-red-700' : isSystem ? 'bg-slate-700' : isWhatsapp ? 'bg-green-700' : 'bg-moss-700';
    const progressColor = isUrgent ? 'bg-red-300' : isSystem ? 'bg-slate-400' : isWhatsapp ? 'bg-green-300' : 'bg-moss-300';
    const barBg = isUrgent ? 'bg-red-900/40' : isSystem ? 'bg-slate-900/40' : isWhatsapp ? 'bg-green-900/40' : 'bg-moss-900/40';

    const handleMuteConversation = () => {
        if (toast.conversationId && onMuteConversation) {
            onMuteConversation(toast.conversationId);
        }
        setShowMuteMenu(false);
        setVisible(false);
        setTimeout(() => onDismiss(toast.id), 300);
    };

    const handleMuteGlobal = () => {
        if (onMuteGlobal) onMuteGlobal();
        setShowMuteMenu(false);
        setVisible(false);
        setTimeout(() => onDismiss(toast.id), 300);
    };

    return (
        <div
            className={`w-[300px] bg-white rounded-xl shadow-2xl overflow-hidden border border-gray-100 transition-all duration-300 ${visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'}`}
        >
            <div className={`${headerBg} text-white px-3 py-2 flex items-center gap-2`}>
                <div className="w-7 h-7 rounded-full bg-white/20 flex items-center justify-center text-xs font-bold flex-shrink-0">
                    {isSystem ? '⚙' : isWhatsapp ? '📱' : toast.senderInitials}
                </div>
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-1.5">
                        {isUrgent && (
                            <span className="text-[9px] font-black bg-red-900 px-1.5 py-0.5 rounded uppercase tracking-wider">URGENTE</span>
                        )}
                        {isWhatsapp && (
                            <span className="text-[9px] font-black bg-green-900 px-1.5 py-0.5 rounded uppercase tracking-wider">WhatsApp</span>
                        )}
                        <span className="text-xs font-bold truncate">{toast.senderName}</span>
                    </div>
                </div>
                {isWhatsapp && (onMuteConversation || onMuteGlobal) && (
                    <div className="relative flex-shrink-0">
                        <button
                            onClick={() => setShowMuteMenu(v => !v)}
                            title="Silenciar notificações"
                            className="text-white/60 hover:text-white p-0.5"
                        >
                            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                                    d="M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
                                    d="M17 14l2-2m0 0l2-2m-2 2l-2-2m2 2l2 2" />
                            </svg>
                        </button>
                        {showMuteMenu && (
                            <div className="absolute right-0 top-6 bg-white border border-gray-200 rounded-lg shadow-xl z-10 w-48 py-1 text-left">
                                {toast.conversationId && onMuteConversation && (
                                    <button
                                        onClick={handleMuteConversation}
                                        className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                    >
                                        <span>🔕</span>
                                        <span>Silenciar este contato</span>
                                    </button>
                                )}
                                {onMuteGlobal && (
                                    <button
                                        onClick={handleMuteGlobal}
                                        className="w-full text-left px-3 py-2 text-xs text-gray-700 hover:bg-gray-50 flex items-center gap-2"
                                    >
                                        <span>🚫</span>
                                        <span>Silenciar tudo</span>
                                    </button>
                                )}
                            </div>
                        )}
                    </div>
                )}
                <button
                    onClick={() => { setVisible(false); setTimeout(() => onDismiss(toast.id), 300); }}
                    className="text-white/60 hover:text-white flex-shrink-0 ml-1"
                >
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                    </svg>
                </button>
            </div>
            <div className="px-3 py-2">
                <p className="text-xs text-gray-700 leading-relaxed line-clamp-2">{toast.body}</p>
                <div className="flex items-center justify-between mt-2">
                    <span className="text-[10px] text-gray-400">{timeAgoShort(toast.createdAt)}</span>
                    <button
                        onClick={() => { onView(toast); onDismiss(toast.id); }}
                        className={`text-[10px] font-semibold ${isUrgent ? 'text-red-600 hover:text-red-800' : isWhatsapp ? 'text-green-700 hover:text-green-900' : 'text-moss-700 hover:text-moss-900'} transition-colors`}
                    >
                        Ver mensagem →
                    </button>
                </div>
            </div>
            <div className={`h-1 ${barBg}`}>
                <div
                    className={`h-full ${progressColor} transition-none`}
                    style={{ width: `${progress}%` }}
                />
            </div>
        </div>
    );
});

function timeAgoShort(dateStr: string): string {
    const diff = Date.now() - new Date(dateStr).getTime();
    const secs = Math.floor(diff / 1000);
    if (secs < 5) return 'agora';
    if (secs < 60) return `${secs}s atrás`;
    const mins = Math.floor(secs / 60);
    if (mins < 60) return `${mins}min atrás`;
    return `${Math.floor(mins / 60)}h atrás`;
}

const MessageToast: React.FC<MessageToastProps> = ({ toasts, onDismiss, onView, onMuteConversation, onMuteGlobal }) => {
    if (toasts.length === 0) return null;
    return (
        <div className="fixed bottom-5 right-5 z-[99997] flex flex-col-reverse gap-2 pointer-events-none">
            {toasts.slice(0, 3).map(t => (
                <div key={t.id} className="pointer-events-auto">
                    <SingleToast
                        toast={t}
                        onDismiss={onDismiss}
                        onView={onView}
                        onMuteConversation={onMuteConversation}
                        onMuteGlobal={onMuteGlobal}
                    />
                </div>
            ))}
        </div>
    );
};

export default MessageToast;

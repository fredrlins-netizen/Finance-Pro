import { HelpTopic } from '../../types';
export type { HelpTopic };

export const DEFAULT_HELP_TOPICS: HelpTopic[] = [
    {
        id: 'login',
        menuPath: 'Login',
        title: 'Tela de Login',
        summary: 'Tela inicial do sistema onde você entra com seu e-mail e senha para acessar o FinancePro.',
        content: `<img src="/help-screenshots/login.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Como acessar o sistema</h3>
            <p>A tela de login é a porta de entrada do FinancePro. Para acessar, você precisa do seu <strong>e-mail</strong> e da sua <strong>senha</strong> cadastrados pelo administrador.</p>

            <h3>Campos da tela de login</h3>
            <ul>
                <li><strong>E-mail:</strong> Digite o e-mail que foi cadastrado para você no sistema. Exemplo: joao@empresa.com</li>
                <li><strong>Senha:</strong> Digite sua senha. Na primeira vez, use a senha provisória que o administrador forneceu.</li>
                <li><strong>Captcha Matemático:</strong> Para sua segurança, o sistema mostra uma conta simples de matemática (ex: "Quanto é 3 + 5?"). Digite o resultado correto para provar que você não é um robô.</li>
            </ul>

            <h3>Primeiro acesso</h3>
            <p>Se esta é a primeira vez que você entra no sistema, ou se o administrador pediu para você trocar a senha, o sistema vai abrir automaticamente uma tela para você criar uma <strong>nova senha</strong>.</p>
            <p>A nova senha precisa seguir estas regras de segurança:</p>
            <ul>
                <li>Ter pelo menos <strong>8 caracteres</strong></li>
                <li>Conter pelo menos uma <strong>letra maiúscula</strong> (ex: A, B, C)</li>
                <li>Conter pelo menos um <strong>número</strong> (ex: 1, 2, 3)</li>
                <li>Conter pelo menos um <strong>caractere especial</strong> (ex: @, #, $, !)</li>
            </ul>
            <p><strong>Exemplo de senha válida:</strong> MinhaSenh@123</p>

            <h3>Troca de senha forçada pelo administrador</h3>
            <p>O administrador pode marcar sua conta para que você seja obrigado a trocar a senha no próximo login. Nesse caso, ao entrar com sua senha atual, o sistema vai pedir que você crie uma nova senha seguindo as regras acima.</p>

            <h3>Bloqueio de conta</h3>
            <p>Para proteger sua conta, se você errar a senha <strong>3 vezes seguidas</strong>, sua conta será <strong>bloqueada automaticamente</strong>. Quando isso acontece:</p>
            <ul>
                <li>Você verá uma mensagem informando que a conta está bloqueada</li>
                <li>Somente o <strong>administrador</strong> pode desbloquear sua conta</li>
                <li>Entre em contato com o administrador do sistema para solicitar o desbloqueio</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Nunca compartilhe sua senha com outras pessoas</li>
                <li>Se esqueceu sua senha, peça ao administrador para redefinir</li>
                <li>Anote sua senha em um lugar seguro na primeira vez que criar</li>
            </ul>
        `,
        keywords: ['login', 'entrar', 'senha', 'acesso', 'email', 'captcha', 'bloqueio', 'primeiro acesso', 'trocar senha', 'segurança', 'desbloquear']
    },
    {
        id: 'home',
        menuPath: 'Home',
        title: 'Tela Inicial (Home)',
        summary: 'Página principal do sistema que exibe o logotipo da empresa e a área de boas-vindas.',
        content: `<img src="/help-screenshots/home.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>A tela inicial é a primeira página que você vê depois de fazer login no FinancePro. Ela serve como ponto de partida para navegar pelo sistema.</p>

            <h3>O que você encontra na Home</h3>
            <ul>
                <li><strong>Logotipo da empresa:</strong> No topo da página, aparece o logotipo e o nome da sua empresa conforme configurado pelo administrador.</li>
                <li><strong>Área de boas-vindas:</strong> Uma mensagem de boas-vindas personalizada com o nome do usuário logado.</li>
            </ul>

            <h3>Cabeçalho do sistema</h3>
            <p>No cabeçalho (barra superior), você encontra:</p>
            <ul>
                <li><strong>Nome da empresa:</strong> Exibido no canto esquerdo do cabeçalho.</li>
                <li><strong>Relógio:</strong> Mostra a hora atual e a data completa por extenso (ex: Terça-feira, 15 de janeiro de 2025).</li>
                <li><strong>Seu nome e e-mail:</strong> Identifica quem está usando o sistema.</li>
                <li><strong>Botão SAIR:</strong> Botão vermelho para sair do sistema com segurança. Sempre use este botão ao terminar de usar o sistema.</li>
            </ul>

            <h3>Menu lateral (Sidebar)</h3>
            <p>No lado esquerdo da tela, existe um menu com todas as opções do sistema. Clique em cada item para navegar. Alguns itens têm submenus que se expandem ao clicar.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Use o menu lateral para navegar entre as diferentes áreas do sistema</li>
                <li>Você pode recolher o menu lateral clicando no ícone de menu para ter mais espaço na tela</li>
                <li>Sempre clique em "SAIR" ao terminar, em vez de apenas fechar o navegador</li>
            </ul>
        `,
        keywords: ['home', 'início', 'tela inicial', 'dashboard', 'boas-vindas', 'menu', 'sidebar', 'sair', 'logout']
    },
    {
        id: 'agenda',
        menuPath: 'Agenda',
        title: 'Agenda de Atendimentos',
        summary: 'Ferramenta completa de agendamento com visualização diária e semanal, serviços, bloqueios e fila de espera.',
        content: `<img src="/help-screenshots/agenda.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>A Agenda é onde você gerencia todos os agendamentos de atendimentos da empresa. Ela funciona como uma agenda visual onde você pode ver, criar e organizar compromissos.</p>

            <h3>Abas da Agenda</h3>
            <p>A tela possui 5 abas no topo:</p>
            <ul>
                <li><strong>Agenda:</strong> A visão principal do calendário com os agendamentos</li>
                <li><strong>Serviços:</strong> Cadastro dos serviços oferecidos pela empresa</li>
                <li><strong>Bloqueio:</strong> Configuração de horários bloqueados (férias, feriados, etc.)</li>
                <li><strong>Fila de Espera:</strong> Lista de clientes aguardando uma vaga</li>
                <li><strong>Configuração:</strong> Ajustes de horário de funcionamento e intervalos</li>
            </ul>

            <h3>Aba Agenda - Visualização do Calendário</h3>
            <ul>
                <li><strong>Visão Diária:</strong> Mostra todos os horários de um único dia, com os agendamentos encaixados nos respectivos horários</li>
                <li><strong>Visão Semanal:</strong> Mostra a semana inteira de uma vez, permitindo uma visão mais ampla</li>
                <li><strong>Mini Calendário:</strong> No lado da tela, há um calendário pequeno onde você pode clicar em qualquer data para navegar rapidamente</li>
                <li><strong>Arrastar e soltar:</strong> Você pode mover um agendamento de um horário para outro simplesmente arrastando o card do compromisso</li>
            </ul>

            <h3>Cabeçalho de colaboradores no grid</h3>
            <p>No topo do quadro de agendamento, cada coluna exibe o nome de um colaborador ativo. Esse cabeçalho possui um comportamento especial:</p>
            <ul>
                <li><strong>Rolagem lateral livre:</strong> Quando há muitos colaboradores, o cabeçalho acompanha a rolagem horizontal, permitindo visualizar todas as colunas sem perder a referência de quem é quem.</li>
                <li><strong>Fixo na rolagem vertical:</strong> Ao descer para ver horários mais tarde no dia, os nomes dos colaboradores permanecem sempre visíveis no topo, garantindo que você saiba em qual coluna está trabalhando a qualquer momento.</li>
            </ul>

            <h3>Rodízio da fila de atendimento</h3>
            <p>Na lateral esquerda da tela, na seção <strong>Agendas Ativas</strong>, os colaboradores aparecem ordenados pela fila de rodízio de atendimento. Esse mecanismo funciona da seguinte forma:</p>
            <ul>
                <li>O colaborador marcado como <strong>Próximo</strong> (indicado pelo badge verde) é quem receberá o próximo cliente agendado.</li>
                <li>Após ser escalado para um atendimento, esse colaborador <strong>passa automaticamente para o final da fila</strong>, cedendo a vez ao próximo da lista.</li>
                <li>Os demais colaboradores avançam uma posição, e o ciclo se repete de forma sucessiva e equilibrada.</li>
                <li>Isso garante uma distribuição justa e automática dos atendimentos entre todos os colaboradores participantes da fila.</li>
            </ul>
            <p><em>Observação: apenas colaboradores cujo cargo esteja configurado com a opção "Participa da Fila de Agendamento" ativada aparecem no rodízio. Essa configuração é feita em Cadastros → Cargos.</em></p>

            <h3>Cores de agendamento: Presencial × Online</h3>
            <p>No quadro de agendamentos, cada card de atendimento é colorido de acordo com a modalidade escolhida no momento do cadastro:</p>
            <ul>
                <li><span style="display:inline-block;width:14px;height:14px;background:#F59E0B;border-radius:3px;vertical-align:middle;margin-right:6px;"></span><strong>Amarelo — Atendimento Presencial:</strong> O cliente comparecerá fisicamente ao escritório para ser atendido.</li>
                <li><span style="display:inline-block;width:14px;height:14px;background:#3B82F6;border-radius:3px;vertical-align:middle;margin-right:6px;"></span><strong>Azul — Atendimento Online:</strong> O atendimento ocorrerá de forma remota (videoconferência, telefone, etc.).</li>
            </ul>
            <p>Essa distinção visual facilita a identificação rápida do tipo de atendimento no calendário, sem necessidade de abrir cada card individualmente.</p>

            <h3>Como criar um agendamento</h3>
            <p>Clique em um horário vazio no calendário ou use o botão de novo agendamento. Preencha:</p>
            <ul>
                <li><strong>Cliente:</strong> Selecione o cliente que será atendido</li>
                <li><strong>Colaborador:</strong> Escolha quem vai realizar o atendimento</li>
                <li><strong>Serviço:</strong> Selecione o tipo de serviço (a duração é preenchida automaticamente)</li>
                <li><strong>Data e Horário:</strong> Defina quando será o atendimento</li>
                <li><strong>Modalidade:</strong> Indique se o atendimento será <strong>Presencial</strong> (amarelo) ou <strong>Online</strong> (azul)</li>
                <li><strong>Observações:</strong> Espaço para anotações sobre o agendamento</li>
            </ul>

            <h3>Aba Serviços</h3>
            <p>Aqui você cadastra os serviços que a empresa oferece. Cada serviço tem:</p>
            <ul>
                <li><strong>Nome:</strong> O nome do serviço (ex: "Consultoria Inicial")</li>
                <li><strong>Duração:</strong> Quanto tempo o serviço leva, em minutos (ex: 30 minutos)</li>
                <li><strong>Preço:</strong> O valor cobrado pelo serviço (ex: R$ 150,00)</li>
                <li><strong>Cor:</strong> Uma cor para identificar visualmente o serviço no calendário</li>
            </ul>

            <h3>Aba Bloqueio</h3>
            <p>Use os bloqueios para impedir agendamentos em determinados horários. Útil para:</p>
            <ul>
                <li>Férias de um colaborador</li>
                <li>Horário de almoço</li>
                <li>Feriados</li>
                <li>Reuniões internas</li>
            </ul>
            <p>Você pode bloquear o dia inteiro ou apenas um período específico, e pode configurar para repetir em determinados dias da semana.</p>

            <h3>Aba Fila de Espera</h3>
            <p>Quando não há horário disponível, você pode colocar o cliente na fila de espera. Quando surgir uma vaga, basta mover o cliente da fila para o calendário.</p>

            <h3>Aba Configuração</h3>
            <ul>
                <li><strong>Horário de início:</strong> A que horas a agenda começa (ex: 08:00)</li>
                <li><strong>Horário de término:</strong> A que horas a agenda termina (ex: 18:00)</li>
                <li><strong>Intervalo de horários:</strong> De quantos em quantos minutos os horários são divididos (ex: 30 minutos)</li>
            </ul>
        `,
        keywords: ['agenda', 'agendamento', 'calendário', 'horário', 'serviço', 'bloqueio', 'fila de espera', 'compromisso', 'atendimento', 'marcar', 'consulta', 'rodízio', 'fila', 'próximo', 'colaborador', 'presencial', 'online', 'amarelo', 'azul', 'modalidade', 'cabeçalho', 'colunas', 'grid', 'rolagem']
    },
    {
        id: 'cad_clientes',
        menuPath: 'Cadastros > Clientes',
        title: 'Cadastro de Clientes',
        summary: 'Tela para registrar e gerenciar todos os clientes da empresa, com dados pessoais, documentos e endereço.',
        content: `<img src="/help-screenshots/cad-clientes.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Cadastro de Clientes é onde você registra todas as informações dos clientes da empresa. Cada cliente cadastrado pode ser usado nas admissões, negociações e no financeiro.</p>

            <h3>Grade de dados (listagem)</h3>
            <p>A tela principal mostra uma tabela com todos os clientes cadastrados. Você pode:</p>
            <ul>
                <li><strong>Pesquisar:</strong> Use o campo de busca para encontrar clientes pelo nome, documento ou e-mail</li>
                <li><strong>Ordenar:</strong> Clique no cabeçalho de qualquer coluna para ordenar os dados (A-Z ou Z-A)</li>
                <li><strong>Paginação:</strong> Na parte inferior, navegue entre as páginas de resultados</li>
                <li><strong>Editar:</strong> Clique em um cliente para abrir seus dados e editá-los</li>
                <li><strong>Excluir:</strong> Remova clientes que não são mais necessários</li>
            </ul>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Nome:</strong> Nome completo do cliente (pessoa física) ou Razão Social (pessoa jurídica). Campo obrigatório.</li>
                <li><strong>Tipo de Pessoa:</strong> Escolha entre:
                    <ul>
                        <li><strong>Pessoa Física:</strong> Para pessoas comuns (CPF)</li>
                        <li><strong>Pessoa Jurídica:</strong> Para empresas (CNPJ)</li>
                    </ul>
                </li>
                <li><strong>CPF/CNPJ:</strong> Documento principal. O sistema valida automaticamente se o número é válido. Se o tipo for Pessoa Física, o campo aceita CPF (ex: 123.456.789-00). Se for Jurídica, aceita CNPJ (ex: 00.111.222/0001-33).</li>
                <li><strong>RG:</strong> Registro Geral (identidade). Opcional, apenas para pessoa física.</li>
                <li><strong>E-mail:</strong> Endereço de e-mail do cliente para contato e envio de documentos.</li>
                <li><strong>Telefone:</strong> Número principal de telefone do cliente.</li>
                <li><strong>WhatsApp:</strong> Marque esta opção se o telefone do cliente é também um número de WhatsApp. Isso facilita o contato rápido.</li>
                <li><strong>Telefone 2:</strong> Número alternativo de telefone.</li>
                <li><strong>Profissão:</strong> A profissão ou ocupação do cliente.</li>
                <li><strong>Estado Civil:</strong> Selecione entre as opções: Solteiro(a), Casado(a), Divorciado(a), Viúvo(a), União Estável.</li>
                <li><strong>Data de Nascimento:</strong> Data de nascimento do cliente.</li>
            </ul>

            <h3>Endereço</h3>
            <ul>
                <li><strong>CEP:</strong> Digite o CEP e os campos de endereço serão preenchidos automaticamente (logradouro, bairro, cidade e estado). Você pode corrigir manualmente caso necessário.</li>
                <li><strong>Endereço:</strong> Rua, avenida ou logradouro.</li>
                <li><strong>Número:</strong> Número do endereço.</li>
                <li><strong>Complemento:</strong> Informações adicionais (ex: Apto 12, Bloco B, Sala 3).</li>
                <li><strong>Bairro:</strong> Nome do bairro.</li>
                <li><strong>Cidade:</strong> Nome da cidade.</li>
                <li><strong>Estado:</strong> Sigla do estado (ex: SP, RJ, MG).</li>
            </ul>

            <h3>Observações</h3>
            <p>Campo livre para anotar qualquer informação importante sobre o cliente. Exemplos: "Cliente prioritário", "Prefere contato por WhatsApp", "Negociação de dívida de cartão".</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Sempre preencha o CPF/CNPJ corretamente, pois o sistema valida o número</li>
                <li>Marque o telefone como WhatsApp para facilitar o contato</li>
                <li>Use o CEP para preencher o endereço automaticamente e ganhar tempo</li>
                <li>Mantenha as observações atualizadas com informações relevantes sobre cada cliente</li>
            </ul>
        `,
        keywords: ['cliente', 'clientes', 'cadastro', 'CPF', 'CNPJ', 'pessoa física', 'pessoa jurídica', 'endereço', 'telefone', 'WhatsApp', 'email', 'nome', 'documento']
    },
    {
        id: 'cad_colaboradores',
        menuPath: 'Cadastros > Colaboradores',
        title: 'Cadastro de Colaboradores',
        summary: 'Tela para registrar os colaboradores (funcionários) da empresa, com dados pessoais, cargo, foto e vínculo com usuários.',
        content: `<img src="/help-screenshots/cad-colaboradores.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Cadastro de Colaboradores é onde você registra todas as informações dos funcionários e colaboradores da empresa. Esses cadastros são usados em diversas partes do sistema, como admissões, agenda e cobranças.</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Nome:</strong> Nome completo do colaborador. Campo obrigatório.</li>
                <li><strong>Cargo:</strong> O cargo ou função do colaborador na empresa (ex: Gerente Comercial, Consultor de Negócios, Analista Jurídico, Atendente). Selecione da lista ou digite um novo.</li>
                <li><strong>Departamento:</strong> Setor onde o colaborador trabalha.</li>
                <li><strong>E-mail:</strong> E-mail profissional do colaborador.</li>
                <li><strong>Telefone:</strong> Número de telefone principal.</li>
                <li><strong>WhatsApp:</strong> Marque se o telefone é também WhatsApp.</li>
                <li><strong>Estado Civil:</strong> Selecione o estado civil.</li>
                <li><strong>Data de Nascimento:</strong> Data de nascimento do colaborador.</li>
            </ul>

            <h3>Foto do colaborador</h3>
            <p>Você pode adicionar uma foto do colaborador de duas formas:</p>
            <ul>
                <li><strong>Câmera:</strong> Use a câmera do computador ou celular para tirar uma foto na hora</li>
                <li><strong>Upload:</strong> Envie uma foto que já está salva no seu computador</li>
            </ul>
            <p>A foto aparece no perfil do colaborador e ajuda na identificação visual.</p>

            <h3>Endereço</h3>
            <p>Funciona da mesma forma que no cadastro de clientes: digite o <strong>CEP</strong> e o sistema preenche automaticamente o endereço, bairro, cidade e estado.</p>

            <h3>Vínculo com Usuário do Sistema</h3>
            <p>Um colaborador pode ser vinculado a um usuário do sistema (na tela de Configurações > Usuários). Isso permite que o sistema identifique qual colaborador está logado e mostre informações específicas, como na Cobrança Operacional.</p>

            <h3>Status</h3>
            <p>O colaborador pode estar como <strong>Ativo</strong> ou <strong>Inativo</strong>. Colaboradores inativos não aparecem nas listas de seleção do sistema.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Mantenha os dados dos colaboradores sempre atualizados</li>
                <li>Vincule o colaborador ao usuário do sistema para que ele tenha acesso às suas funcionalidades específicas</li>
                <li>Use a foto para facilitar a identificação visual no sistema</li>
            </ul>
        `,
        keywords: ['colaborador', 'colaboradores', 'funcionário', 'funcionários', 'equipe', 'cargo', 'departamento', 'foto', 'câmera', 'upload']
    },
    {
        id: 'cad_bancos',
        menuPath: 'Cadastros > Bancos',
        title: 'Cadastro de Bancos',
        summary: 'Tela para registrar os bancos com os quais a empresa trabalha, incluindo serviços e percentuais de negociação.',
        content: `<img src="/help-screenshots/cad-bancos.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Cadastro de Bancos é onde você registra todos os bancos e instituições financeiras com as quais a empresa trabalha nas negociações de dívidas. Esses bancos são usados nas admissões de clientes.</p>

            <h3>Campos do formulário principal</h3>
            <ul>
                <li><strong>Nome:</strong> Nome completo do banco ou instituição financeira (ex: BANCO DO BRASIL S.A., CAIXA ECONÔMICA FEDERAL).</li>
                <li><strong>Código FEBRABAN:</strong> Código oficial do banco no sistema bancário brasileiro (ex: 001 para Banco do Brasil, 104 para Caixa). Esse código é padronizado nacionalmente.</li>
                <li><strong>Status:</strong> Se o banco está <strong>Ativo</strong> (disponível para uso) ou <strong>Inativo</strong> (não aparece nas listas de seleção).</li>
                <li><strong>Observações:</strong> Informações adicionais sobre o banco, como políticas de desconto, contatos ou particularidades (ex: "Aceita quitação com até 70% de desconto após 180 dias").</li>
            </ul>

            <h3>Serviços do Banco (Sub-grade)</h3>
            <p>Dentro de cada banco, existe uma tabela de <strong>Serviços</strong> que detalha os tipos de negociação que o banco aceita:</p>
            <ul>
                <li><strong>Descrição do Serviço:</strong> Nome do serviço (ex: "CDC Veículos", "Empréstimo Pessoal").</li>
                <li><strong>Tipo:</strong> Classificação do serviço.</li>
                <li><strong>Modalidade:</strong> Qual modalidade de negociação se aplica.</li>
                <li><strong>Percentual de Negociação:</strong> O percentual típico de desconto ou taxa para essa modalidade (ex: 25,5%). Esse valor é usado nos cálculos de recálculo da admissão.</li>
            </ul>

            <h3>Como adicionar serviços</h3>
            <p>Dentro do cadastro do banco, clique no botão para adicionar um novo serviço. Preencha os campos e salve. Você pode adicionar quantos serviços forem necessários para cada banco.</p>

            <h3>Contatos do Banco (Sub-grade)</h3>
            <p>Cada banco pode ter vários contatos cadastrados — pessoas ou setores com quem a equipe se comunica para negociações. Os campos disponíveis para cada contato são:</p>
            <ul>
                <li><strong>Nome:</strong> Nome completo da pessoa ou do setor (ex: "Central de Renegociação", "Maria Souza").</li>
                <li><strong>Setor:</strong> Área ou departamento do contato dentro do banco (ex: "Crédito", "Jurídico", "Cobrança").</li>
                <li><strong>Telefone:</strong> Número de telefone fixo com máscara automática no formato <strong>(00) 0000-0000</strong>. O número é gravado sem máscara no banco de dados para facilitar buscas e integrações.</li>
                <li><strong>Celular:</strong> Número de celular com máscara automática no formato <strong>(00) 00000-0000</strong>. Também gravado sem máscara no banco de dados.</li>
                <li><strong>Zap (WhatsApp):</strong> Marque esta caixinha para indicar que o celular do contato tem WhatsApp ativo.</li>
                <li><strong>E-mail:</strong> Endereço de e-mail completo do contato. O campo ocupa toda a largura do formulário para facilitar a leitura e digitação de endereços longos.</li>
            </ul>

            <h3>Visualização de conversas por WhatsApp</h3>
            <p>Na tabela de contatos, ao lado de cada número de <strong>Telefone</strong> e <strong>Celular</strong>, aparece um ícone verde do WhatsApp 
            <span style="display:inline-flex;align-items:center;vertical-align:middle;margin:0 4px;color:#16a34a;">
                <svg width="14" height="14" fill="currentColor" viewBox="0 0 24 24"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
            </span>. 
            Clique nesse ícone para abrir um painel com o histórico de conversas trocadas com aquele número via GoTalk (o sistema de mensagens integrado). Isso permite consultar negociações anteriores, mensagens enviadas e recebidas sem sair da tela de bancos.</p>
            <p><em>Observação: o botão de visualização de conversas aparece apenas quando o número está vinculado a um atendimento registrado no GoTalk. Se não houver histórico, o painel informará que não há conversas encontradas para aquele contato.</em></p>

            <h3>Uso nas Admissões</h3>
            <p>Quando você cria uma admissão, seleciona o banco de onde vem a dívida do cliente. Os serviços e percentuais cadastrados aqui são usados para calcular os cenários de recálculo.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Mantenha os percentuais de negociação atualizados conforme as políticas dos bancos mudam</li>
                <li>Cadastre os contatos do banco com o número de celular correto e marque o campo "Zap" para que o histórico de WhatsApp fique disponível na tela</li>
                <li>Desative bancos que não são mais utilizados em vez de excluí-los</li>
            </ul>
        `,
        keywords: ['banco', 'bancos', 'instituição financeira', 'FEBRABAN', 'código', 'serviço', 'percentual', 'negociação', 'desconto', 'contato', 'contatos', 'telefone', 'celular', 'whatsapp', 'zap', 'email', 'e-mail', 'conversa', 'mensagem', 'setor', 'gotalk']
    },
    {
        id: 'cad_modalidades',
        menuPath: 'Cadastros > Modalidades',
        title: 'Cadastro de Modalidades',
        summary: 'Tela para registrar os tipos de modalidade de negociação utilizados nas admissões.',
        content: `<img src="/help-screenshots/cad-modalidades.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>As Modalidades definem os tipos de dívida ou negociação com os quais a empresa trabalha. Elas são usadas para classificar as admissões de clientes.</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Tipo:</strong> A categoria principal da modalidade. Você pode escolher uma das opções existentes no menu suspenso ou digitar um novo tipo. Exemplos de tipos:
                    <ul>
                        <li><strong>VEÍCULOS:</strong> Para financiamentos e dívidas relacionadas a veículos</li>
                        <li><strong>CARTÕES:</strong> Para dívidas de cartão de crédito</li>
                        <li><strong>CONSIGNADO:</strong> Para empréstimos consignados</li>
                        <li><strong>EMPRÉSTIMOS:</strong> Para empréstimos pessoais</li>
                        <li><strong>OUTROS:</strong> Para outros tipos de negociação</li>
                    </ul>
                </li>
                <li><strong>Descrição:</strong> Um texto descritivo que explica melhor a modalidade (ex: "Revisão de financiamento de veículos", "Revisão de dívidas de cartão de crédito").</li>
            </ul>

            <h3>Uso no sistema</h3>
            <p>Quando você cria uma nova admissão, precisa selecionar a modalidade que se aplica ao caso do cliente. Se a modalidade for do tipo "VEÍCULOS", o formulário de admissão exibirá campos adicionais para dados do veículo (placa, chassi, renavam, etc.).</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Crie modalidades específicas para facilitar a organização e os relatórios</li>
                <li>Use descrições claras para que qualquer pessoa entenda o tipo de negociação</li>
                <li>Novos tipos podem ser criados diretamente no campo Tipo</li>
            </ul>
        `,
        keywords: ['modalidade', 'modalidades', 'tipo', 'categoria', 'veículos', 'cartões', 'consignado', 'empréstimo', 'classificação']
    },
    {
        id: 'cad_produtos',
        menuPath: 'Cadastros > Produtos',
        title: 'Cadastro de Produtos e Serviços',
        summary: 'Tela para registrar produtos e serviços oferecidos pela empresa, com unidades de medida e tipo.',
        content: `<img src="/help-screenshots/cad-produtos.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Cadastro de Produtos é onde você registra os produtos materiais e serviços que a empresa oferece. Esses itens podem ser usados no faturamento e na emissão de notas.</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Descrição:</strong> Nome ou descrição do produto/serviço (ex: "Consultoria Financeira", "Material de Escritório").</li>
                <li><strong>Tipo:</strong> Escolha entre:
                    <ul>
                        <li><strong>Material:</strong> Para produtos físicos que você vende ou usa</li>
                        <li><strong>Serviço:</strong> Para serviços prestados pela empresa</li>
                    </ul>
                </li>
                <li><strong>Unidade de Medida:</strong> Como o produto é medido (ex: UN para unidade, KG para quilograma, HR para hora). Você pode selecionar uma unidade existente ou criar uma nova diretamente no campo.</li>
                <li><strong>Fator de Conversão:</strong> Número usado para converter entre diferentes unidades de medida. Para a maioria dos casos, deixe como 1.</li>
            </ul>

            <h3>Criação de Unidades de Medida</h3>
            <p>Se a unidade que você precisa não existe na lista, você pode criar uma nova diretamente dentro do formulário de produto, sem precisar ir a outra tela. Basta digitar o nome da nova unidade e confirmar.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Separe bem os tipos entre Material e Serviço para facilitar os relatórios</li>
                <li>Use descrições claras e padronizadas</li>
                <li>As unidades de medida mais comuns já vêm cadastradas (UN, etc.)</li>
            </ul>
        `,
        keywords: ['produto', 'produtos', 'serviço', 'serviços', 'material', 'unidade de medida', 'catálogo', 'faturamento', 'nota']
    },
    {
        id: 'cad_series',
        menuPath: 'Cadastros > Série/Números',
        title: 'Cadastro de Séries e Numeração',
        summary: 'Tela para configurar as séries de documentos e controlar a numeração automática do sistema.',
        content: `<img src="/help-screenshots/cad-series.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Cadastro de Séries controla a numeração automática dos documentos emitidos pelo sistema, como contratos e procurações. Cada série tem seu próprio contador que avança automaticamente.</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Sigla:</strong> Uma abreviação curta para identificar a série (ex: CONTR para Contratos, PROCUR para Procurações). Normalmente usa-se letras maiúsculas.</li>
                <li><strong>Descrição:</strong> Um texto que descreve para que serve essa série (ex: "Contratos de Assessoria", "Procurações Judiciais").</li>
                <li><strong>Numeração Geral:</strong> O próximo número que será usado quando um documento dessa série for criado. O sistema incrementa esse número automaticamente a cada novo documento.</li>
            </ul>

            <h3>Numeração por Unidade</h3>
            <p>Se a empresa tem múltiplas unidades (filiais), cada unidade pode ter sua própria sequência de numeração. A tabela de numeração por unidade mostra:</p>
            <ul>
                <li><strong>Unidade:</strong> Nome da filial ou unidade</li>
                <li><strong>Número Atual:</strong> O próximo número a ser usado nessa unidade</li>
            </ul>

            <h3>Como funciona a numeração</h3>
            <p>Quando um documento é criado (como uma admissão), o sistema usa a série selecionada, pega o número atual e incrementa automaticamente. Por exemplo, se a série CONTR está no número 150, o próximo contrato será 151, depois 152, e assim por diante.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Nunca altere a numeração geral para um número menor, pois pode causar duplicidade</li>
                <li>Crie séries diferentes para cada tipo de documento que precisa de controle de numeração</li>
                <li>A numeração por unidade é útil quando cada filial precisa de sua própria sequência</li>
            </ul>
        `,
        keywords: ['série', 'séries', 'numeração', 'número', 'sequência', 'contrato', 'procuração', 'documento', 'sigla', 'controle']
    },
    {
        id: 'com_admissao',
        menuPath: 'Atendimento > Comercial > Admissão',
        title: 'Painel de Admissões',
        summary: 'Tela principal para registrar e gerenciar as admissões de clientes, com dados de dívida, cenários de recálculo e anexos.',
        content: `<img src="/help-screenshots/admissao.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>A Admissão é o registro principal de atendimento ao cliente. É aqui que você cadastra os dados da dívida do cliente junto ao banco, calcula cenários de negociação e acompanha o andamento do processo.</p>

            <h3>SmartSelect (Seleção Inteligente)</h3>
            <p>Para selecionar Cliente, Banco e Colaborador, o sistema oferece um campo de seleção inteligente que permite:</p>
            <ul>
                <li><strong>Pesquisar:</strong> Digite parte do nome para encontrar registros existentes</li>
                <li><strong>Adicionar Novo:</strong> Se o registro não existe, clique no botão "+" para criar um novo sem sair da tela</li>
                <li><strong>Editar:</strong> Se precisa corrigir dados, clique no ícone de edição para abrir o cadastro</li>
            </ul>

            <h3>Campos principais</h3>
            <ul>
                <li><strong>Cliente:</strong> Selecione o cliente que está sendo admitido.</li>
                <li><strong>Banco:</strong> O banco credor (de onde vem a dívida).</li>
                <li><strong>Colaborador:</strong> O colaborador responsável pelo atendimento.</li>
                <li><strong>Modalidade:</strong> O tipo de dívida (Veículos, Cartões, Consignado, etc.).</li>
                <li><strong>Número do Contrato:</strong> O número do contrato com o banco (gerado automaticamente pela série ou digitado manualmente).</li>
            </ul>

            <h3>Dados do Veículo</h3>
            <p>Se a modalidade for do tipo "Veículos", campos adicionais aparecem:</p>
            <ul>
                <li><strong>Placa:</strong> Placa do veículo.</li>
                <li><strong>Chassi:</strong> Número do chassi do veículo.</li>
                <li><strong>Renavam:</strong> Número do Renavam para consultas.</li>
                <li><strong>Marca, Modelo, Cor, Ano:</strong> Dados de identificação do veículo.</li>
            </ul>

            <h3>Informações da Dívida</h3>
            <ul>
                <li><strong>Total de Parcelas:</strong> Quantas parcelas o financiamento original tem.</li>
                <li><strong>Parcelas Pagas:</strong> Quantas parcelas o cliente já pagou.</li>
                <li><strong>Parcelas em Atraso:</strong> Quantas parcelas estão vencidas.</li>
                <li><strong>Valor Financiado:</strong> O valor total do financiamento original.</li>
                <li><strong>Valor da Parcela:</strong> O valor de cada parcela.</li>
                <li><strong>Taxa de Cobrança:</strong> A taxa cobrada pela empresa pelo serviço.</li>
            </ul>

            <h3>Cenários de Recálculo</h3>
            <p>A tabela de recálculo mostra diferentes propostas de negociação. Cada cenário exibe:</p>
            <ul>
                <li><strong>Parcelas a Pagar:</strong> Quantas parcelas na nova negociação.</li>
                <li><strong>Dívida Original:</strong> Quanto o cliente deve hoje.</li>
                <li><strong>Valor da Parcela:</strong> Valor de cada parcela na nova proposta.</li>
                <li><strong>Nova Dívida:</strong> Valor total da nova negociação.</li>
                <li><strong>Economia:</strong> Quanto o cliente vai economizar (diferença entre dívida original e nova).</li>
                <li><strong>Dia de Vencimento:</strong> Em qual dia do mês as parcelas vencerão.</li>
            </ul>
            <p>Você pode criar vários cenários diferentes para apresentar opções ao cliente.</p>

            <h3>Anexos</h3>
            <p>Faça upload de documentos relacionados à admissão (contratos, comprovantes, etc.). Os arquivos são armazenados no sistema e ficam disponíveis para consulta.</p>

            <h3>Impressão com QR Code</h3>
            <p>O botão de imprimir gera um formulário completo da admissão que inclui um QR Code para acesso rápido ao registro no sistema.</p>

            <h3>Status da Admissão</h3>
            <p>Cada admissão passa por diferentes etapas (status):</p>
            <ul>
                <li><strong>PENDENTE:</strong> A admissão acabou de ser criada e aguarda análise.</li>
                <li><strong>NEGOCIAÇÃO:</strong> A admissão está em processo de negociação (muda automaticamente quando o formulário é impresso).</li>
                <li><strong>APROVADA:</strong> A negociação foi aprovada e o acordo fechado.</li>
                <li><strong>ANÁLISE CLIENTE:</strong> O cliente está analisando a proposta.</li>
                <li><strong>REPROVADA:</strong> A negociação foi recusada.</li>
                <li><strong>RETORNO AUDITORIA:</strong> A auditoria devolveu o processo para correções.</li>
            </ul>

            <h3>Filtros avançados</h3>
            <p>Na listagem de admissões, use os filtros para encontrar registros específicos:</p>
            <ul>
                <li>Filtrar por <strong>status</strong> (Pendente, Aprovada, etc.)</li>
                <li>Filtrar por <strong>banco</strong></li>
                <li>Filtrar por <strong>colaborador</strong></li>
                <li>Filtrar por <strong>cliente</strong></li>
                <li>Filtrar por <strong>período</strong> (data inicial e final)</li>
            </ul>
        `,
        keywords: ['admissão', 'admissões', 'atendimento', 'comercial', 'dívida', 'negociação', 'recálculo', 'parcela', 'contrato', 'veículo', 'placa', 'chassi', 'QR code', 'impressão', 'anexo']
    },
    {
        id: 'com_negociacao',
        menuPath: 'Atendimento > Comercial > Negociação',
        title: 'Painel de Negociação Comercial (Kanban)',
        summary: 'Quadro Kanban visual para acompanhar o andamento das negociações comerciais em 4 etapas.',
        content: `<img src="/help-screenshots/negociacao-kanban.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>A Negociação Comercial usa um quadro visual no formato <strong>Kanban</strong> (parecido com um quadro de post-its) para acompanhar o andamento das negociações de forma rápida e visual.</p>

            <h3>As 4 colunas do Kanban</h3>
            <p>O quadro é dividido em 4 colunas, cada uma representando uma etapa do processo:</p>
            <ul>
                <li><strong>Triagem:</strong> Negociações que acabaram de chegar e precisam ser analisadas pela primeira vez. É o ponto de entrada de todas as negociações.</li>
                <li><strong>Proposta Enviada:</strong> A proposta de negociação já foi elaborada e enviada ao banco ou ao cliente. Aguardando retorno.</li>
                <li><strong>Aguardando Banco:</strong> A proposta está nas mãos do banco para análise e aprovação. O tempo de resposta depende de cada banco.</li>
                <li><strong>Acordo Fechado:</strong> A negociação foi concluída com sucesso. O acordo foi aceito por todas as partes.</li>
            </ul>

            <h3>Cartões de negociação</h3>
            <p>Cada negociação aparece como um cartão (card) que mostra:</p>
            <ul>
                <li><strong>Nome do cliente</strong></li>
                <li><strong>Nome do banco</strong></li>
                <li><strong>Valores envolvidos</strong></li>
                <li><strong>Status atual</strong></li>
            </ul>

            <h3>Como mover negociações</h3>
            <p>Para mover uma negociação de uma coluna para outra, basta <strong>arrastar o cartão</strong> de uma coluna e soltar na próxima. Isso atualiza automaticamente o status da negociação.</p>

            <h3>Resumo do pipeline</h3>
            <p>No topo ou na lateral do quadro, são exibidas <strong>estatísticas resumidas</strong> do pipeline:</p>
            <ul>
                <li>Quantidade de negociações em cada etapa</li>
                <li>Valores totais por etapa</li>
                <li>Total geral de negociações ativas</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Revise o quadro diariamente para acompanhar o andamento das negociações</li>
                <li>Negociações paradas por muito tempo na mesma coluna podem precisar de atenção especial</li>
                <li>Use o resumo do pipeline para ter uma visão rápida do desempenho comercial</li>
            </ul>
        `,
        keywords: ['negociação', 'kanban', 'quadro', 'pipeline', 'triagem', 'proposta', 'acordo', 'comercial', 'etapa', 'cartão']
    },
    {
        id: 'auditoria',
        menuPath: 'Atendimento > Auditoria',
        title: 'Painel de Auditoria',
        summary: 'Tela de auditoria para verificação de conformidade das admissões, com checklist, robô jurídico e controle de status.',
        content: `<img src="/help-screenshots/auditoria.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Painel de Auditoria é onde são verificadas e validadas as admissões antes de serem finalizadas. A auditoria garante que todos os dados e documentos estão corretos e que não há impedimentos jurídicos.</p>

            <h3>Checklist de conformidade</h3>
            <p>Cada admissão passa por uma lista de verificação (checklist) para garantir que todos os requisitos foram atendidos. Marque cada item conforme for verificando.</p>

            <h3>Robô Jurídico</h3>
            <p>O sistema possui um <strong>robô de verificação jurídica</strong> que faz buscas automáticas para verificar se existem processos judiciais ativos relacionados ao veículo ou ao cliente. Essa verificação é importante para:</p>
            <ul>
                <li>Detectar se há processos de <strong>busca e apreensão</strong> do veículo</li>
                <li>Verificar se existem <strong>ações judiciais</strong> em andamento</li>
                <li>Identificar possíveis <strong>impedimentos legais</strong> para a negociação</li>
            </ul>

            <h3>Fluxo de status</h3>
            <p>A auditoria segue este fluxo de status:</p>
            <ul>
                <li><strong>PENDENTE:</strong> A admissão chegou para auditoria e ainda não foi analisada.</li>
                <li><strong>EM ANÁLISE:</strong> A equipe de auditoria está verificando os dados e documentos.</li>
                <li><strong>CONCLUÍDO:</strong> A auditoria foi finalizada e a admissão está liberada.</li>
                <li><strong>RETORNAR AO COMERCIAL:</strong> Foram encontrados problemas e a admissão precisa voltar ao setor comercial para correções.</li>
            </ul>

            <h3>Notas de crítica</h3>
            <p>Quando a auditoria retorna uma admissão ao comercial, o auditor deve registrar uma <strong>nota de crítica</strong> explicando o que precisa ser corrigido. Essa nota aparece para o setor comercial quando ele abrir a admissão devolvida.</p>

            <h3>Visualização e impressão</h3>
            <p>O auditor pode visualizar e imprimir o formulário completo da admissão para conferência, sem alterar os dados originais.</p>

            <h3>Notificações jurídicas</h3>
            <p>Quando o robô jurídico encontra processos ativos, o sistema gera notificações automáticas para alertar a equipe sobre possíveis riscos.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Sempre execute o robô jurídico antes de aprovar uma admissão com veículo</li>
                <li>Ao retornar ao comercial, seja claro e específico na nota de crítica</li>
                <li>Verifique todos os itens do checklist antes de concluir a auditoria</li>
            </ul>
        `,
        keywords: ['auditoria', 'verificação', 'checklist', 'robô jurídico', 'conformidade', 'aprovação', 'análise', 'retorno', 'crítica', 'jurídico']
    },
    {
        id: 'juridico',
        menuPath: 'Atendimento > Jurídico',
        title: 'Painel Jurídico',
        summary: 'Tela para gerenciar processos judiciais, com OCR para leitura de documentos, linha do tempo e integração com auditoria.',
        content: `
            <img src="/help-screenshots/juridico.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>O Painel Jurídico é onde são gerenciados todos os processos judiciais relacionados aos clientes e suas admissões. Ele permite acompanhar movimentações processuais, ler documentos automaticamente e manter um histórico completo.</p>

            <h3>Cadastro de processos</h3>
            <p>Crie, edite e exclua processos judiciais com todas as informações relevantes. Os processos podem ser importados automaticamente quando o robô da auditoria encontra casos ativos.</p>

            <h3>OCR - Leitura de Documentos</h3>
            <p>O sistema possui tecnologia <strong>OCR (Reconhecimento Óptico de Caracteres)</strong> que permite:</p>
            <ul>
                <li><strong>Ler texto de imagens:</strong> Fotografe um documento e o sistema extrai o texto automaticamente</li>
                <li><strong>Ler texto de PDFs:</strong> Envie um PDF e o sistema identifica o conteúdo escrito</li>
            </ul>
            <p>Isso economiza muito tempo, pois você não precisa digitar manualmente as informações dos documentos.</p>

            <h3>Linha do tempo de movimentações</h3>
            <p>Cada processo tem uma linha do tempo (timeline) que mostra todas as movimentações em ordem cronológica. Você pode:</p>
            <ul>
                <li><strong>Adicionar movimentações:</strong> Registre novas atualizações do processo</li>
                <li><strong>Editar movimentações:</strong> Corrija informações de movimentações existentes</li>
                <li><strong>Excluir movimentações:</strong> Remova registros incorretos</li>
            </ul>

            <h3>Integração com Auditoria</h3>
            <p>Quando o robô jurídico da auditoria detecta processos ativos, esses dados são automaticamente importados para o Painel Jurídico, economizando tempo de cadastro.</p>

            <h3>Pesquisa e filtros</h3>
            <ul>
                <li><strong>Busca:</strong> Pesquise processos por número, cliente ou palavras-chave</li>
                <li><strong>Filtros:</strong> Filtre por status, período, tipo de processo</li>
                <li><strong>Arquivo:</strong> Processos encerrados podem ser arquivados para manter a lista principal limpa</li>
            </ul>

            <h3>Links rápidos</h3>
            <ul>
                <li><strong>Pesquisa Google:</strong> Um botão de atalho para pesquisar o número do processo no Google, facilitando a busca por informações em tribunais</li>
                <li><strong>Atualizar dados:</strong> Botão para verificar se há novas movimentações em fontes externas</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Use o OCR para economizar tempo na leitura de documentos</li>
                <li>Mantenha a linha do tempo sempre atualizada com as movimentações mais recentes</li>
                <li>Archive processos encerrados para manter o painel organizado</li>
                <li>Use o link do Google para verificar informações em sites de tribunais</li>
            </ul>
        `,
        keywords: ['jurídico', 'processo', 'processos', 'judicial', 'OCR', 'leitura', 'documento', 'movimentação', 'timeline', 'tribunal', 'busca e apreensão']
    },
    {
        id: 'fin_tipo_documento',
        menuPath: 'Financeiro > Tipo Documento',
        title: 'Cadastro de Tipo de Documento',
        summary: 'Tela para registrar os tipos de documentos financeiros utilizados nos títulos a receber e a pagar.',
        content: `
            <img src="/help-screenshots/fin-tipo-documento.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>O Tipo de Documento define como um título financeiro é classificado. Por exemplo, se é um boleto, uma nota fiscal, um recibo ou uma duplicata. Essa classificação é usada nos módulos de Contas a Receber e Contas a Pagar.</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Descrição:</strong> O nome do tipo de documento (ex: "NOTA FISCAL", "BOLETO BANCÁRIO", "RECIBO", "DUPLICATA").</li>
                <li><strong>Categoria:</strong> Define onde esse tipo pode ser usado:
                    <ul>
                        <li><strong>RECEBER:</strong> Apenas em Contas a Receber</li>
                        <li><strong>PAGAR:</strong> Apenas em Contas a Pagar</li>
                        <li><strong>AMBOS:</strong> Pode ser usado tanto em Contas a Receber quanto a Pagar</li>
                    </ul>
                </li>
                <li><strong>Fiscal:</strong> Marque se este tipo de documento é um documento fiscal (ex: Nota Fiscal, Duplicata). Documentos fiscais podem ter regras específicas.</li>
                <li><strong>Exige Número:</strong> Marque se este tipo de documento exige um número de documento (ex: número da nota fiscal, número do boleto). Se não marcado, o campo de número do documento ficará opcional ao criar um título.</li>
                <li><strong>Status:</strong> <strong>Ativo</strong> (disponível para uso) ou <strong>Inativo</strong> (não aparece nas seleções).</li>
            </ul>

            <h3>Tipos pré-cadastrados</h3>
            <p>O sistema já vem com alguns tipos comuns:</p>
            <ul>
                <li>NOTA FISCAL - Documento fiscal, exige número</li>
                <li>BOLETO BANCÁRIO - Não fiscal, exige número</li>
                <li>RECIBO - Não fiscal, não exige número</li>
                <li>DUPLICATA - Documento fiscal, exige número, apenas para Receber</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Crie tipos específicos para cada formato de documento que sua empresa usa</li>
                <li>Use a categoria corretamente para controlar onde cada tipo pode ser selecionado</li>
                <li>Desative tipos que não são mais utilizados em vez de excluí-los</li>
            </ul>
        `,
        keywords: ['tipo documento', 'documento', 'boleto', 'nota fiscal', 'recibo', 'duplicata', 'fiscal', 'financeiro', 'classificação']
    },
    {
        id: 'fin_portador',
        menuPath: 'Financeiro > Portador',
        title: 'Cadastro de Portadores',
        summary: 'Tela para registrar os portadores de documentos financeiros, identificando quem detém ou cobra o título.',
        content: `
            <img src="/help-screenshots/fin-portadores.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>O Portador identifica quem está com o documento financeiro ou quem é responsável pela cobrança. Por exemplo, o título pode estar na carteira local da empresa, no banco para cobrança, em cartório para protesto, etc.</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Código:</strong> Um código curto para identificação rápida (ex: "CRT" para Carteira, "BB-01" para Cobrança Banco do Brasil).</li>
                <li><strong>Nome:</strong> Nome descritivo do portador (ex: "CARTEIRA (LOCAL)", "COBRANÇA BB").</li>
                <li><strong>Tipo:</strong> A classificação do portador:
                    <ul>
                        <li><strong>CARTEIRA:</strong> O título está na empresa (carteira local)</li>
                        <li><strong>BANCO:</strong> O título foi enviado ao banco para cobrança</li>
                        <li><strong>CARTÓRIO:</strong> O título foi enviado a cartório para protesto</li>
                        <li><strong>JURÍDICO:</strong> O título está em cobrança judicial</li>
                        <li><strong>TERCEIROS:</strong> O título está com terceiros</li>
                    </ul>
                </li>
                <li><strong>Conta Bancária Associada:</strong> Se o portador é do tipo BANCO, vincule a conta bancária correspondente. Isso permite rastrear os recebimentos na conta correta.</li>
                <li><strong>Status:</strong> <strong>Ativo</strong> ou <strong>Inativo</strong>.</li>
            </ul>

            <h3>Portadores pré-cadastrados</h3>
            <ul>
                <li>CARTEIRA (LOCAL) - Tipo Carteira, para títulos sob responsabilidade direta da empresa</li>
                <li>COBRANÇA BB - Tipo Banco, vinculado à conta do Banco do Brasil</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Vincule portadores do tipo BANCO à conta bancária correta para facilitar a conciliação</li>
                <li>Crie portadores separados para cada banco que faz cobrança para a empresa</li>
                <li>O portador ajuda a rastrear onde cada título está e quem é responsável pela cobrança</li>
            </ul>
        `,
        keywords: ['portador', 'portadores', 'carteira', 'cobrança', 'banco', 'cartório', 'protesto', 'jurídico', 'custódia']
    },
    {
        id: 'fin_plano_contas',
        menuPath: 'Financeiro > Plano de Contas',
        title: 'Plano de Contas',
        summary: 'Tela para configurar a estrutura hierárquica de contas contábeis usada para classificar receitas e despesas.',
        content: `<img src="/help-screenshots/fin-plano-contas.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Plano de Contas é a estrutura que organiza todas as categorias financeiras da empresa. Ele funciona como uma árvore hierárquica onde cada conta pode ter subcontas. É usado para classificar receitas e despesas nos títulos financeiros.</p>

            <h3>Estrutura hierárquica</h3>
            <p>As contas são organizadas em níveis, como pastas e subpastas:</p>
            <ul>
                <li><strong>Nível 1:</strong> Categorias principais (ex: "1 - Receitas Operacionais", "2 - Despesas")</li>
                <li><strong>Nível 2:</strong> Subcategorias (ex: "1.01 - Honorários e Serviços", "2.01 - Despesas Administrativas")</li>
                <li><strong>Nível 3:</strong> Contas específicas (ex: "1.01.01 - Honorários de Consultoria", "2.01.01 - Aluguel e Condomínio")</li>
            </ul>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Código:</strong> O número que identifica a conta na estrutura hierárquica (ex: "1.01.01"). Os pontos separam os níveis.</li>
                <li><strong>Nome:</strong> A descrição da conta (ex: "Honorários de Consultoria").</li>
                <li><strong>Tipo:</strong> Define se a conta é de:
                    <ul>
                        <li><strong>RECEITA:</strong> Dinheiro que entra na empresa (vendas, serviços, etc.)</li>
                        <li><strong>DESPESA:</strong> Dinheiro que sai da empresa (aluguel, salários, etc.)</li>
                    </ul>
                </li>
                <li><strong>Conta Pai:</strong> A qual conta superior esta pertence na hierarquia.</li>
                <li><strong>Analítica:</strong> Se a conta é analítica, ela pode receber lançamentos (valores). Contas sintéticas (não analíticas) servem apenas para agrupar outras contas.</li>
            </ul>

            <h3>Contas do sistema</h3>
            <p>Algumas contas são marcadas como "do sistema" e não podem ser excluídas, pois são necessárias para o funcionamento correto do módulo financeiro.</p>

            <h3>Contas pré-cadastradas</h3>
            <ul>
                <li><strong>1 - Receitas Operacionais</strong> (sintética)
                    <ul>
                        <li>1.01 - Honorários e Serviços
                            <ul>
                                <li>1.01.01 - Honorários de Consultoria (analítica)</li>
                                <li>1.01.02 - Comissões sobre Êxito (analítica)</li>
                            </ul>
                        </li>
                    </ul>
                </li>
                <li><strong>2 - Despesas</strong> (sintética)
                    <ul>
                        <li>2.01 - Despesas Administrativas
                            <ul>
                                <li>2.01.01 - Aluguel e Condomínio (analítica)</li>
                                <li>2.01.02 - Energia Elétrica (analítica)</li>
                            </ul>
                        </li>
                    </ul>
                </li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Somente contas <strong>analíticas</strong> (último nível) podem receber valores nos títulos financeiros</li>
                <li>Mantenha a estrutura organizada e consistente para facilitar os relatórios</li>
                <li>Crie contas específicas para cada tipo de receita ou despesa que a empresa tem</li>
                <li>Os códigos devem seguir a lógica hierárquica (ex: 1 > 1.01 > 1.01.01)</li>
            </ul>
        `,
        keywords: ['plano de contas', 'conta', 'contas', 'receita', 'despesa', 'categoria', 'hierarquia', 'contábil', 'classificação', 'analítica', 'sintética']
    },
    {
        id: 'fin_cc_cadastro',
        menuPath: 'Financeiro > Conta Corrente > Cadastro',
        title: 'Cadastro de Contas Bancárias',
        summary: 'Tela para registrar as contas bancárias da empresa, com dados de banco, agência, número e saldo inicial.',
        content: `<img src="/help-screenshots/fin-cc-cadastro.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Cadastro de Contas Bancárias é onde você registra todas as contas que a empresa utiliza, sejam contas correntes em bancos ou caixas internos. Essas contas são usadas para registrar as movimentações financeiras (entradas e saídas de dinheiro).</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Descrição:</strong> Um nome para identificar a conta (ex: "BANCO DO BRASIL - PRINCIPAL", "CAIXA PEQUENO").</li>
                <li><strong>Tipo de Conta:</strong> O tipo da conta bancária:
                    <ul>
                        <li><strong>CORRENTE:</strong> Conta corrente comum em banco</li>
                        <li><strong>POUPANÇA:</strong> Conta poupança</li>
                        <li><strong>INVESTIMENTO:</strong> Conta de investimentos</li>
                        <li><strong>CAIXA:</strong> Caixa interno da empresa (dinheiro em espécie)</li>
                    </ul>
                </li>
                <li><strong>Banco:</strong> Selecione o banco onde a conta está aberta (vinculado ao Cadastro de Bancos). Para contas do tipo CAIXA, não é necessário.</li>
                <li><strong>Agência:</strong> Número da agência bancária (ex: "1234-5").</li>
                <li><strong>Número da Conta:</strong> Número da conta no banco (ex: "998877-X").</li>
                <li><strong>Saldo Inicial:</strong> O valor que a conta tinha na data de início do controle (ex: R$ 15.000,00).</li>
                <li><strong>Data do Saldo Inicial:</strong> A data a partir da qual o sistema começa a controlar os movimentos.</li>
                <li><strong>Conta Padrão:</strong> Marque se esta é a conta principal da empresa. A conta padrão é selecionada automaticamente em novas operações.</li>
                <li><strong>Status:</strong> <strong>ATIVA</strong> (em uso) ou <strong>INATIVA</strong> (desativada).</li>
            </ul>

            <h3>Saldo atual</h3>
            <p>O sistema calcula automaticamente o <strong>saldo atual</strong> da conta com base no saldo inicial mais todas as entradas (créditos) menos todas as saídas (débitos) registradas.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Cadastre todas as contas que a empresa usa para ter controle total do dinheiro</li>
                <li>O saldo inicial deve ser o valor exato da conta na data informada</li>
                <li>Defina uma conta como padrão para agilizar os lançamentos</li>
                <li>Use o tipo CAIXA para controlar o dinheiro em espécie do escritório</li>
            </ul>
        `,
        keywords: ['conta bancária', 'conta corrente', 'banco', 'agência', 'saldo', 'caixa', 'poupança', 'investimento', 'cadastro conta']
    },
    {
        id: 'fin_cc_movimento',
        menuPath: 'Financeiro > Conta Corrente > Movimento',
        title: 'Movimentos da Conta Corrente',
        summary: 'Tela para visualizar e registrar todos os movimentos financeiros (entradas e saídas) das contas bancárias.',
        content: `<img src="/help-screenshots/fin-cc-movimento.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>A tela de Movimentos mostra todas as transações (entradas e saídas de dinheiro) de cada conta bancária. Aqui você visualiza os movimentos automáticos (gerados por baixas de títulos) e pode criar movimentos manuais.</p>

            <h3>Seleção de conta e filtros</h3>
            <ul>
                <li><strong>Conta:</strong> Selecione qual conta bancária deseja visualizar.</li>
                <li><strong>Período:</strong> Defina a data inicial e final para filtrar os movimentos. Só serão exibidos movimentos dentro desse período.</li>
            </ul>

            <h3>Cards de resumo</h3>
            <p>No topo da tela, cards mostram um resumo rápido:</p>
            <ul>
                <li><strong>Saldo Inicial:</strong> O saldo da conta no início do período filtrado</li>
                <li><strong>Total Créditos:</strong> Soma de todas as entradas no período</li>
                <li><strong>Total Débitos:</strong> Soma de todas as saídas no período</li>
                <li><strong>Saldo Período:</strong> Calculado como: Saldo Inicial + Créditos - Débitos. Mostra quanto ficou na conta no período filtrado.</li>
            </ul>

            <h3>Tabela de movimentos</h3>
            <p>A tabela exibe cada movimento com as seguintes informações:</p>
            <ul>
                <li><strong>Data:</strong> Quando o movimento aconteceu.</li>
                <li><strong>Descrição:</strong> O que originou o movimento.</li>
                <li><strong>Documento:</strong> Número do documento associado (se houver).</li>
                <li><strong>Tipo:</strong> <strong>CRÉDITO</strong> (entrada de dinheiro, mostrado em <span style="color:blue">azul</span>) ou <strong>DÉBITO</strong> (saída de dinheiro, mostrado em <span style="color:red">vermelho com sinal negativo</span>).</li>
                <li><strong>Valor:</strong> O valor do movimento.</li>
                <li><strong>Saldo:</strong> O saldo acumulado após este movimento.</li>
            </ul>

            <h3>Origem dos movimentos</h3>
            <p>Cada movimento tem uma origem que indica de onde ele veio:</p>
            <ul>
                <li><strong>BAIXA_RECEBER:</strong> Gerado automaticamente quando um título a receber é liquidado (baixa). É um CRÉDITO na conta.</li>
                <li><strong>BAIXA_PAGAR:</strong> Gerado automaticamente quando um título a pagar é liquidado. É um DÉBITO na conta.</li>
                <li><strong>MANUAL:</strong> Movimento criado manualmente pelo usuário (ex: transferência, depósito avulso).</li>
                <li><strong>TARIFA:</strong> Tarifas bancárias ou ajustes.</li>
            </ul>

            <h3>Lançamento manual</h3>
            <p>Para criar um movimento manual, use o formulário com os campos:</p>
            <ul>
                <li><strong>Data:</strong> Data do movimento.</li>
                <li><strong>Descrição:</strong> Descrição do que é o movimento (ex: "Depósito em espécie", "Transferência para conta X").</li>
                <li><strong>Número do Documento:</strong> Número de referência (opcional).</li>
                <li><strong>Valor:</strong> Quanto foi o movimento.</li>
                <li><strong>Tipo:</strong> CRÉDITO (entrada) ou DÉBITO (saída).</li>
                <li><strong>Categoria:</strong> Conta do Plano de Contas para classificar o movimento.</li>
                <li><strong>Departamento:</strong> Departamento responsável.</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Os movimentos de baixa são criados automaticamente - não é preciso criar manualmente</li>
                <li>Use movimentos manuais para registrar transações que não passam pelo módulo de títulos</li>
                <li>Confira o saldo do período regularmente para manter o controle financeiro</li>
                <li>Movimentos em azul (CRÉDITO) são entradas, em vermelho (DÉBITO) são saídas</li>
            </ul>
        `,
        keywords: ['movimento', 'movimentação', 'extrato', 'conta corrente', 'crédito', 'débito', 'saldo', 'entrada', 'saída', 'transação', 'lançamento']
    },
    {
        id: 'fin_cc_conciliacao',
        menuPath: 'Financeiro > Conta Corrente > Conciliação Bancária',
        title: 'Conciliação Bancária',
        summary: 'Tela para comparar os movimentos do sistema com o extrato bancário e marcar os itens que conferem.',
        content: `<img src="/help-screenshots/fin-cc-conciliacao.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>A Conciliação Bancária é o processo de comparar os movimentos registrados no sistema com o extrato real do banco. O objetivo é garantir que todos os valores conferem e identificar diferenças.</p>

            <h3>Como funciona</h3>
            <p>O processo de conciliação consiste em:</p>
            <ul>
                <li><strong>Passo 1:</strong> Selecionar a conta bancária que deseja conciliar.</li>
                <li><strong>Passo 2:</strong> Comparar os movimentos do sistema com os lançamentos do extrato bancário.</li>
                <li><strong>Passo 3:</strong> Marcar cada movimento como <strong>conciliado</strong> quando ele conferir com o extrato do banco.</li>
            </ul>

            <h3>Status dos movimentos</h3>
            <ul>
                <li><strong>Conciliado:</strong> O movimento confere com o extrato bancário. Tudo está correto.</li>
                <li><strong>Não conciliado:</strong> O movimento ainda não foi verificado ou há diferença em relação ao extrato.</li>
            </ul>

            <h3>Por que fazer conciliação?</h3>
            <ul>
                <li>Detectar <strong>lançamentos faltantes</strong> no sistema (ex: uma tarifa bancária que não foi registrada)</li>
                <li>Identificar <strong>valores incorretos</strong> (diferença entre o que está no sistema e o que está no banco)</li>
                <li>Manter o <strong>saldo do sistema alinhado</strong> com o saldo real do banco</li>
                <li>Cumprir boas práticas de <strong>controle financeiro</strong></li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Faça a conciliação pelo menos uma vez por semana</li>
                <li>Se encontrar diferenças, verifique se há movimentos faltantes ou valores incorretos</li>
                <li>Crie movimentos manuais para tarifas bancárias que não foram registradas automaticamente</li>
                <li>O objetivo é que todos os movimentos estejam conciliados ao final do processo</li>
            </ul>
        `,
        keywords: ['conciliação', 'conciliação bancária', 'extrato', 'conferência', 'banco', 'saldo', 'verificação', 'conciliar']
    },
    {
        id: 'fin_departamentos',
        menuPath: 'Financeiro > Departamentos',
        title: 'Cadastro de Departamentos',
        summary: 'Tela para registrar os departamentos da empresa, usados como centros de custo na classificação financeira.',
        content: `<img src="/help-screenshots/fin-departamentos.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Cadastro de Departamentos permite registrar os setores da empresa. Os departamentos são usados como <strong>centros de custo</strong> nos lançamentos financeiros, ajudando a saber quanto cada setor gasta ou gera de receita.</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Código:</strong> Um código curto para identificar o departamento (ex: "01" para Administrativo, "02" para Comercial).</li>
                <li><strong>Nome:</strong> O nome completo do departamento (ex: "ADMINISTRATIVO", "COMERCIAL", "JURÍDICO").</li>
                <li><strong>Gerente:</strong> O nome do responsável pelo departamento (opcional).</li>
                <li><strong>Status:</strong> <strong>Ativo</strong> (disponível para uso) ou <strong>Inativo</strong> (não aparece nas seleções).</li>
            </ul>

            <h3>Departamentos pré-cadastrados</h3>
            <ul>
                <li><strong>01 - ADMINISTRATIVO:</strong> Gerente: Carlos Silva</li>
                <li><strong>02 - COMERCIAL:</strong> Gerente: Ricardo Souza</li>
                <li><strong>03 - JURÍDICO:</strong> Gerente: Dra. Ana</li>
            </ul>

            <h3>Uso no sistema</h3>
            <p>Nos títulos financeiros (Contas a Receber e a Pagar) e nos movimentos bancários, você pode associar cada lançamento a um departamento. Isso permite gerar relatórios por setor, como:</p>
            <ul>
                <li>Quanto o departamento Comercial gastou no mês</li>
                <li>Quanto o departamento Jurídico gerou de receita</li>
                <li>Comparar gastos entre departamentos</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Cadastre todos os departamentos da empresa para ter um controle financeiro detalhado</li>
                <li>Use códigos curtos e sequenciais para facilitar a identificação</li>
                <li>Mantenha o nome do gerente atualizado</li>
            </ul>
        `,
        keywords: ['departamento', 'departamentos', 'centro de custo', 'setor', 'área', 'gerente', 'classificação']
    },
    {
        id: 'fin_receber',
        menuPath: 'Financeiro > Contas a Receber',
        title: 'Contas a Receber',
        summary: 'Módulo completo para gerenciar todos os valores que a empresa tem a receber de clientes, com baixas, faturas, adiantamentos e muito mais.',
        content: `<img src="/help-screenshots/fin-receber.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O módulo de Contas a Receber gerencia todos os valores que os clientes devem à empresa. Aqui você cria títulos (cobranças), registra pagamentos (baixas), gera faturas e acompanha a situação financeira de cada cliente.</p>

            <h3>Campos do título</h3>
            <ul>
                <li><strong>Descrição:</strong> Uma descrição do que se refere o título (ex: "Honorários consultoria mês 01/2025").</li>
                <li><strong>Cliente:</strong> O cliente devedor.</li>
                <li><strong>Tipo de Documento:</strong> Boleto, Nota Fiscal, Recibo, etc. (conforme cadastrado em Tipo Documento).</li>
                <li><strong>Portador:</strong> Quem detém o documento (Carteira, Banco, etc.).</li>
                <li><strong>Departamento:</strong> Setor responsável (centro de custo).</li>
                <li><strong>Categoria:</strong> Conta do Plano de Contas para classificação (ex: "Honorários de Consultoria").</li>
                <li><strong>Número do Documento:</strong> Número do documento fiscal ou boleto.</li>
                <li><strong>Data de Emissão:</strong> Quando o título foi emitido.</li>
                <li><strong>Data de Vencimento:</strong> Quando o título vence (prazo para pagamento).</li>
                <li><strong>Valor:</strong> O valor do título em reais.</li>
            </ul>

            <h3>Status dos títulos</h3>
            <ul>
                <li><strong>Em Aberto:</strong> O título ainda não foi pago. Aguardando pagamento.</li>
                <li><strong>Liquidado:</strong> O título foi totalmente pago (baixa total).</li>
                <li><strong>Parcial:</strong> O título foi parcialmente pago. Resta um saldo a receber.</li>
                <li><strong>Cancelado:</strong> O título foi cancelado e não precisa mais ser cobrado.</li>
                <li><strong>Agrupado:</strong> O título foi agrupado com outros em uma fatura.</li>
                <li><strong>Adiantamento:</strong> Valor recebido antecipadamente (antes de gerar o serviço). Aparece em <span style="color:orange">laranja</span>.</li>
                <li><strong>Devolução:</strong> Valor que precisa ser devolvido ao cliente. Aparece em <span style="color:red">vermelho</span>.</li>
            </ul>

            <h3>Baixa (Liquidação)</h3>
            <p>A baixa é o registro do pagamento recebido. Existem dois tipos:</p>
            <ul>
                <li><strong>Baixa Total:</strong> O cliente pagou o valor integral do título. O título muda para status "Liquidado".</li>
                <li><strong>Baixa Parcial:</strong> O cliente pagou apenas parte do valor. O título muda para status "Parcial" e o saldo restante fica em aberto.</li>
            </ul>
            <p>Na tela de baixa, você pode informar:</p>
            <ul>
                <li><strong>Juros:</strong> Valor de juros cobrados por atraso.</li>
                <li><strong>Multa:</strong> Valor de multa por atraso.</li>
                <li><strong>Desconto:</strong> Desconto concedido ao cliente.</li>
                <li><strong>Conta Bancária:</strong> Em qual conta o dinheiro foi depositado.</li>
            </ul>

            <h3>Baixa em Lote</h3>
            <p>Selecione vários títulos de uma vez e faça a baixa de todos juntos. Útil quando recebe vários pagamentos ao mesmo tempo.</p>

            <h3>Gerar Faturas</h3>
            <p>O botão "Gerar Faturas" permite agrupar vários títulos de um mesmo cliente em uma única fatura. Os títulos originais ficam com status "Agrupado" e um novo título de fatura é criado com o valor total.</p>

            <h3>Títulos Recorrentes</h3>
            <p>Crie títulos que se repetem automaticamente (mensalmente, por exemplo). Útil para cobranças fixas como mensalidades de serviço.</p>

            <h3>Tipos especiais de títulos</h3>
            <ul>
                <li><strong>PADRÃO:</strong> Título normal de cobrança.</li>
                <li><strong>ADIANTAMENTO:</strong> Valor recebido antecipadamente. Aparece em <span style="color:orange">laranja</span>. Pode ser vinculado a um título padrão posteriormente.</li>
                <li><strong>DEVOLUÇÃO:</strong> Valor a devolver ao cliente. Aparece em <span style="color:red">vermelho</span>. Pode ser vinculado a um título padrão para abater o valor.</li>
            </ul>

            <h3>Vinculação de Adiantamento/Devolução</h3>
            <p>Use a janela de vinculação para conectar um adiantamento ou devolução a um título padrão. Isso permite abater valores automaticamente na hora da baixa.</p>

            <h3>Dedução na baixa</h3>
            <p>Na hora de fazer a baixa, se o título tiver adiantamentos ou devoluções vinculados, uma janela de dedução mostra os valores que podem ser abatidos.</p>

            <h3>Protesto e Provisão</h3>
            <ul>
                <li><strong>Protesto:</strong> Marque um título como protestado quando ele for enviado a cartório. Títulos protestados ficam bloqueados e somente o administrador pode liberar para baixa.</li>
                <li><strong>Provisão:</strong> Marque títulos que são considerados provisão (possível perda). Também requer liberação do administrador.</li>
            </ul>

            <h3>Rastreio (Rastreabilidade)</h3>
            <p>O botão "Rastreio" mostra toda a cadeia de documentos relacionados a um título: faturas, baixas, adiantamentos vinculados, etc. Permite acompanhar todo o histórico.</p>

            <h3>Rodapé com totais</h3>
            <p>Na parte inferior da tela, um rodapé colapsável mostra os totais de todos os títulos filtrados: valor total, total em aberto, total liquidado, etc.</p>

            <h3>Seletor de colunas</h3>
            <p>Clique no ícone de colunas para escolher quais colunas exibir na tabela. Isso permite personalizar a visualização conforme sua necessidade.</p>

            <h3>Filtros avançados</h3>
            <p>Use os filtros para encontrar títulos específicos por cliente, status, período de vencimento, tipo de documento, portador, departamento e muito mais.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Faça as baixas no mesmo dia em que receber o pagamento para manter o controle atualizado</li>
                <li>Use a Baixa em Lote quando tiver muitos pagamentos para registrar</li>
                <li>Títulos vencidos aparecem destacados - dê atenção a eles</li>
                <li>Use o Rastreio para entender a história completa de um título</li>
                <li>Configure os filtros para ver rapidamente o que precisa</li>
            </ul>
        `,
        keywords: ['contas a receber', 'receber', 'cobrança', 'título', 'títulos', 'baixa', 'liquidação', 'pagamento', 'fatura', 'adiantamento', 'devolução', 'protesto', 'provisão', 'vencido', 'recorrente']
    },
    {
        id: 'fin_pagar',
        menuPath: 'Financeiro > Contas a Pagar',
        title: 'Contas a Pagar',
        summary: 'Módulo completo para gerenciar todos os pagamentos que a empresa precisa fazer a fornecedores, com as mesmas funcionalidades do Contas a Receber.',
        content: `<img src="/help-screenshots/fin-pagar.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O módulo de Contas a Pagar gerencia todos os valores que a empresa deve pagar a fornecedores, prestadores de serviço e outras obrigações financeiras. Funciona de forma muito similar ao Contas a Receber, mas com foco nas saídas de dinheiro.</p>

            <h3>Diferenças em relação ao Contas a Receber</h3>
            <ul>
                <li>Ao invés de <strong>Cliente</strong>, usa-se <strong>Fornecedor</strong> para identificar a quem se deve</li>
                <li>As baixas geram movimentos de <strong>DÉBITO</strong> (saída) na conta bancária, em vez de CRÉDITO</li>
                <li>O foco é no controle das obrigações e não dos direitos a receber</li>
            </ul>

            <h3>Campos do título</h3>
            <p>Os campos são os mesmos do Contas a Receber:</p>
            <ul>
                <li><strong>Descrição:</strong> Do que se trata o pagamento (ex: "Aluguel do escritório mês 01/2025").</li>
                <li><strong>Fornecedor:</strong> A quem devemos pagar.</li>
                <li><strong>Tipo de Documento, Portador, Departamento, Categoria, Número do Documento:</strong> Mesmos campos do Contas a Receber.</li>
                <li><strong>Data de Emissão e Vencimento:</strong> Quando foi emitido e quando vence.</li>
                <li><strong>Valor:</strong> Quanto deve ser pago.</li>
            </ul>

            <h3>Funcionalidades disponíveis</h3>
            <p>Todas as funcionalidades do Contas a Receber também estão disponíveis no Contas a Pagar:</p>
            <ul>
                <li><strong>Baixa Total e Parcial:</strong> Registre pagamentos completos ou parciais com juros, multa e desconto.</li>
                <li><strong>Baixa em Lote:</strong> Pague vários títulos de uma vez.</li>
                <li><strong>Gerar Faturas:</strong> Agrupe títulos do mesmo fornecedor em uma fatura.</li>
                <li><strong>Títulos Recorrentes:</strong> Para despesas fixas mensais (aluguel, internet, etc.).</li>
                <li><strong>Adiantamento e Devolução:</strong> Gerencie pagamentos antecipados e devoluções de fornecedores.</li>
                <li><strong>Protesto e Provisão:</strong> Controle títulos protestados ou provisionados.</li>
                <li><strong>Rastreio:</strong> Acompanhe toda a cadeia de documentos.</li>
                <li><strong>Filtros avançados:</strong> Encontre títulos por fornecedor, status, vencimento, etc.</li>
            </ul>

            <h3>Status dos títulos</h3>
            <p>Os mesmos status do Contas a Receber se aplicam: Em Aberto, Liquidado, Parcial, Cancelado, Agrupado, Adiantamento, Devolução.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Cadastre todas as contas a pagar para não perder nenhum vencimento</li>
                <li>Use títulos recorrentes para despesas fixas e não se esqueça de pagá-las</li>
                <li>Verifique regularmente os títulos vencidos para evitar multas e juros</li>
                <li>A baixa de um título a pagar gera automaticamente um débito na conta bancária selecionada</li>
            </ul>
        `,
        keywords: ['contas a pagar', 'pagar', 'fornecedor', 'despesa', 'título', 'pagamento', 'baixa', 'vencimento', 'obrigação', 'conta', 'boleto']
    },
    {
        id: 'fin_cob_coordenador',
        menuPath: 'Financeiro > Cobrança > Coordenadores',
        title: 'Cobrança - Visão do Coordenador',
        summary: 'Painel completo de cobrança para coordenadores, com visão de toda a carteira, distribuição para colaboradores e dashboard de indicadores.',
        content: `
            <img src="/help-screenshots/fin-cob-coordenador.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>A tela do Coordenador de Cobrança oferece uma visão completa de toda a carteira de títulos a receber que precisam ser cobrados. O coordenador pode distribuir os títulos entre os colaboradores e acompanhar os resultados da equipe.</p>

            <h3>Carteira de títulos</h3>
            <p>A grade mostra todos os títulos a receber do tipo PADRÃO que ainda não foram pagos, cancelados ou agrupados. Cada linha mostra:</p>
            <ul>
                <li>Nome do cliente</li>
                <li>Valor do título</li>
                <li>Data de vencimento</li>
                <li>Dias em atraso</li>
                <li>Status de cobrança</li>
                <li>Colaborador responsável</li>
            </ul>

            <h3>Seleção em lote</h3>
            <p>Use as <strong>caixas de seleção</strong> (checkboxes) para selecionar vários títulos ao mesmo tempo. Isso permite fazer operações em lote, como atribuir vários títulos a um mesmo colaborador de uma só vez.</p>

            <h3>Filtros avançados</h3>
            <ul>
                <li><strong>Cliente:</strong> Filtre por um cliente específico</li>
                <li><strong>Status:</strong> Filtre pelo status do título (Em Aberto, Parcial, etc.)</li>
                <li><strong>Situação Cobrança:</strong> Filtre pela situação da cobrança (A cobrar, Em negociação, etc.)</li>
                <li><strong>Colaborador:</strong> Veja os títulos atribuídos a um colaborador específico</li>
                <li><strong>Faixa de Atraso:</strong> Filtre por quantidade de dias em atraso (1-30 dias, 31-60 dias, etc.)</li>
                <li><strong>Vencimento:</strong> Filtre por período de vencimento</li>
            </ul>

            <h3>Atribuição de colaborador em lote</h3>
            <p>Selecione vários títulos usando os checkboxes, depois clique no botão de atribuir colaborador. Escolha o colaborador responsável e todos os títulos selecionados serão atribuídos a ele.</p>

            <h3>Painel de informações do cliente</h3>
            <p>Ao clicar em um cliente, abre-se um painel lateral com informações detalhadas:</p>
            <ul>
                <li><strong>Dados cadastrais:</strong> Nome, documento, telefone, e-mail, endereço</li>
                <li><strong>Títulos:</strong> Todos os títulos do cliente com valores e vencimentos</li>
                <li><strong>Admissões:</strong> Histórico de admissões do cliente</li>
                <li><strong>Anexos:</strong> Documentos relacionados</li>
                <li><strong>Cenários de recálculo:</strong> Propostas de negociação das admissões</li>
            </ul>

            <h3>Aba Dashboard</h3>
            <p>A aba Dashboard mostra indicadores de desempenho (KPIs) da cobrança:</p>
            <ul>
                <li><strong>Taxa de Inadimplência:</strong> Percentual de títulos vencidos em relação ao total. Quanto menor, melhor.</li>
                <li><strong>Taxa de Recuperação:</strong> Percentual de valores recuperados (recebidos) em relação ao total de títulos vencidos. Quanto maior, melhor.</li>
                <li><strong>DSO (Days Sales Outstanding):</strong> Média de dias que os clientes levam para pagar. Quanto menor, melhor.</li>
                <li><strong>Saldo Total:</strong> Valor total em aberto na carteira de cobrança.</li>
            </ul>

            <h3>Gráficos</h3>
            <ul>
                <li><strong>Carteira por Faixa de Atraso:</strong> Gráfico de barras horizontais mostrando quanto da carteira está em cada faixa de atraso (1-30 dias, 31-60 dias, 61-90 dias, 91-120 dias, 120+ dias). Cada faixa tem uma cor diferente para fácil visualização.</li>
                <li><strong>Performance por Colaborador:</strong> Gráfico mostrando o desempenho de cada colaborador na cobrança.</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Distribua os títulos de forma equilibrada entre os colaboradores</li>
                <li>Priorize os títulos com mais dias de atraso</li>
                <li>Use o Dashboard para acompanhar a evolução dos indicadores de cobrança</li>
                <li>Verifique regularmente se há títulos sem colaborador atribuído</li>
            </ul>
        `,
        keywords: ['cobrança', 'coordenador', 'carteira', 'inadimplência', 'recuperação', 'DSO', 'atraso', 'faixa', 'atribuição', 'colaborador', 'KPI', 'dashboard']
    },
    {
        id: 'fin_cob_operacional',
        menuPath: 'Financeiro > Cobrança > Operacionais',
        title: 'Cobrança - Visão Operacional',
        summary: 'Painel de cobrança para o colaborador operacional, mostrando sua carteira pessoal e seus resultados individuais.',
        content: `
            <img src="/help-screenshots/fin-cob-operacional.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>A tela Operacional de Cobrança é voltada para o colaborador que executa a cobrança no dia a dia. Ela mostra apenas os títulos atribuídos a você e seus resultados pessoais.</p>

            <h3>Aba "Minha Carteira"</h3>
            <p>Mostra todos os títulos que foram atribuídos a você pelo coordenador e que estão com status de cobrança = COBRAR.</p>
            <ul>
                <li><strong>Cards de resumo no topo:</strong>
                    <ul>
                        <li><strong>Total:</strong> Quantidade total de títulos na sua carteira</li>
                        <li><strong>Vencidos:</strong> Quantidade de títulos já vencidos</li>
                        <li><strong>Saldo:</strong> Valor total em aberto na sua carteira</li>
                    </ul>
                </li>
                <li><strong>Grade de títulos:</strong> Lista todos os títulos com nome do cliente, valor, vencimento e dias de atraso.</li>
            </ul>

            <h3>Aba "Meus Resultados"</h3>
            <p>Mostra seus indicadores pessoais de desempenho:</p>
            <ul>
                <li><strong>Vencendo Hoje:</strong> Títulos que vencem hoje e precisam de atenção imediata</li>
                <li><strong>Vencidos Acumulados:</strong> Total de títulos vencidos na sua carteira</li>
                <li><strong>Baixas Hoje:</strong> Quantas baixas (recebimentos) você registrou hoje</li>
                <li><strong>Carteira Total:</strong> Valor total sob sua responsabilidade</li>
                <li><strong>Taxa de Recuperação:</strong> Percentual de valores que você conseguiu recuperar</li>
                <li><strong>Inadimplência:</strong> Percentual de títulos vencidos na sua carteira</li>
                <li><strong>DSO:</strong> Média de dias que seus clientes levam para pagar</li>
            </ul>

            <h3>Gráficos de desempenho</h3>
            <ul>
                <li><strong>Por faixa de atraso:</strong> Gráfico de barras horizontais mostrando como sua carteira está distribuída por faixas de atraso</li>
                <li><strong>Evolução diária:</strong> Gráfico que mostra a evolução dos seus resultados ao longo dos dias</li>
            </ul>

            <h3>Modal de detalhes do cliente</h3>
            <p>Ao clicar em um título, abre-se uma janela com 3 abas de informações do cliente:</p>
            <ul>
                <li><strong>Cadastro:</strong> Dados cadastrais do cliente (nome, telefone, endereço, etc.)</li>
                <li><strong>Títulos:</strong> Todos os títulos do cliente, não apenas os da sua carteira</li>
                <li><strong>Admissões:</strong> Histórico de admissões e negociações do cliente</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Comece o dia verificando os títulos que vencem hoje</li>
                <li>Priorize os títulos com mais dias de atraso</li>
                <li>Use o modal de detalhes para ter todas as informações do cliente antes de ligar</li>
                <li>Acompanhe seus indicadores na aba "Meus Resultados" para melhorar seu desempenho</li>
            </ul>
        `,
        keywords: ['cobrança', 'operacional', 'minha carteira', 'meus resultados', 'vencido', 'recuperação', 'inadimplência', 'cobrar', 'título', 'desempenho']
    },
    {
        id: 'fin_negociacao',
        menuPath: 'Financeiro > Negociação',
        title: 'Negociação Financeira',
        summary: 'Módulo completo para gerenciar negociações de dívidas com clientes, incluindo contatos, propostas, metas e dashboard de performance.',
        content: `<img src="/help-screenshots/fin-negociacao.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O módulo de Negociação Financeira é onde você gerencia todo o processo de negociação de dívidas com os clientes. Ele permite registrar contatos, criar propostas, acompanhar metas e visualizar o desempenho da equipe.</p>

            <h3>Aba "Negociações"</h3>
            <p>A grade principal mostra todas as negociações com:</p>
            <ul>
                <li><strong>Cards de resumo:</strong> Totais por status (abertas, em andamento, acordos fechados, etc.)</li>
                <li><strong>Filtros:</strong> Filtre por cliente, status, colaborador, período</li>
                <li><strong>Status com badges coloridos:</strong>
                    <ul>
                        <li><strong>ABERTA:</strong> Negociação recém-criada</li>
                        <li><strong>EM ANDAMENTO:</strong> Em processo de negociação ativa</li>
                        <li><strong>ACORDO FECHADO:</strong> Acordo foi aceito pelo cliente</li>
                        <li><strong>ACORDO QUEBRADO:</strong> O cliente não cumpriu o acordo</li>
                        <li><strong>CANCELADA:</strong> Negociação foi cancelada</li>
                        <li><strong>ENCERRADA:</strong> Processo totalmente finalizado</li>
                    </ul>
                </li>
                <li><strong>Alertas de próximo contato:</strong> O sistema destaca negociações que têm data de próximo contato para hoje ou que estão atrasadas</li>
            </ul>

            <h3>Criar nova negociação</h3>
            <p>Para criar uma negociação, use o formulário que funciona em cascata:</p>
            <ul>
                <li><strong>Passo 1:</strong> Selecione o <strong>cliente</strong></li>
                <li><strong>Passo 2:</strong> O sistema carrega automaticamente as <strong>admissões</strong> desse cliente</li>
                <li><strong>Passo 3:</strong> Selecione a admissão relacionada</li>
                <li><strong>Passo 4:</strong> Os dados da dívida são preenchidos automaticamente</li>
            </ul>

            <h3>Ficha de Negociação</h3>
            <p>Ao abrir uma negociação, a ficha completa tem 4 abas:</p>
            <ul>
                <li><strong>Dados:</strong> Informações gerais da negociação (cliente, banco, valor da dívida, status)</li>
                <li><strong>Contatos:</strong> Linha do tempo com todos os contatos realizados (ligações, WhatsApp, e-mails) + formulário para registrar novos contatos com canal, resposta, descrição e data do próximo contato</li>
                <li><strong>Propostas:</strong> Tabela com todas as propostas feitas ao cliente. Cada proposta mostra: valor original, percentual de desconto, valor com desconto, número de parcelas, valor da parcela, entrada, status. Os cálculos são feitos automaticamente.</li>
                <li><strong>Metas:</strong> Metas mensais do colaborador com preenchimento automático. Mostra meta de valor, valor atingido, meta de quantidade e quantidade atingida.</li>
            </ul>

            <h3>Aba "Dashboard Cliente"</h3>
            <ul>
                <li><strong>Seletor de cliente:</strong> Escolha um cliente para ver sua visão consolidada</li>
                <li><strong>Resumo financeiro:</strong> Total de dívidas, valores negociados, valores pagos</li>
                <li><strong>Linha do tempo:</strong> Todos os eventos em ordem cronológica</li>
                <li><strong>Comparação de propostas:</strong> Compare as diferentes propostas feitas ao cliente</li>
            </ul>

            <h3>Aba "Performance"</h3>
            <ul>
                <li><strong>Filtro de período:</strong> Selecione o período para análise</li>
                <li><strong>KPIs:</strong>
                    <ul>
                        <li><strong>Conversão:</strong> Percentual de negociações que viraram acordo</li>
                        <li><strong>Ticket Médio:</strong> Valor médio dos acordos fechados</li>
                        <li><strong>Recuperação:</strong> Total de valores recuperados</li>
                        <li><strong>Acordos:</strong> Quantidade de acordos fechados</li>
                    </ul>
                </li>
                <li><strong>Ranking de colaboradores:</strong> Classificação da equipe com sistema de pontuação</li>
                <li><strong>Barras de progresso das metas:</strong> Visualização do progresso em relação às metas definidas</li>
            </ul>

            <h3>Máscara de moeda</h3>
            <p>Todos os campos de valor usam a máscara brasileira: <strong>R$ 999.999.999,99</strong>. O sistema formata automaticamente os valores conforme você digita.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Registre todos os contatos com o cliente para manter o histórico completo</li>
                <li>Sempre defina a data do próximo contato para não perder o timing da negociação</li>
                <li>Compare as propostas antes de enviar uma nova ao cliente</li>
                <li>Acompanhe suas metas regularmente na aba Performance</li>
            </ul>
        `,
        keywords: ['negociação', 'financeiro', 'acordo', 'proposta', 'contato', 'meta', 'performance', 'conversão', 'ticket médio', 'ranking', 'dívida', 'desconto', 'parcela']
    },
    {
        id: 'fin_gerenciamento',
        menuPath: 'Financeiro > Gerenciamento',
        title: 'Dashboard de Gerenciamento Financeiro',
        summary: 'Painel gerencial com visão consolidada de todos os indicadores financeiros da empresa em um só lugar.',
        content: `<img src="/help-screenshots/fin-gerenciamento.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Gerenciamento Financeiro é o painel central onde gestores e diretores podem visualizar todos os indicadores financeiros da empresa de forma consolidada. É a visão "de cima" de todo o financeiro.</p>

            <h3>Aba "Resumo"</h3>
            <p>Cards com os principais indicadores:</p>
            <ul>
                <li><strong>Saldo em Contas:</strong> Saldo total de todas as contas bancárias ativas</li>
                <li><strong>A Receber Aberto:</strong> Total de valores que os clientes ainda devem (títulos em aberto)</li>
                <li><strong>Vencidos:</strong> Total de títulos que já passaram do vencimento</li>
                <li><strong>Taxa de Recuperação:</strong> Percentual de valores recuperados em relação ao total</li>
            </ul>
            <p>Abaixo dos cards, há <strong>atalhos rápidos</strong> para acessar diretamente outros módulos do financeiro (Contas a Receber, Contas a Pagar, Movimentos, etc.).</p>

            <h3>Aba "Extrato Geral"</h3>
            <p>Uma linha do tempo unificada que mostra todos os movimentos financeiros de todos os clientes em ordem cronológica. Inclui:</p>
            <ul>
                <li>Baixas de títulos a receber</li>
                <li>Baixas de títulos a pagar</li>
                <li>Movimentos bancários manuais</li>
                <li>Criação de títulos</li>
            </ul>
            <p>Filtros disponíveis:</p>
            <ul>
                <li><strong>Cliente:</strong> Veja apenas os movimentos de um cliente específico</li>
                <li><strong>Tipo:</strong> Filtre por tipo de movimento (receber, pagar, manual)</li>
                <li><strong>Período:</strong> Defina data inicial e final</li>
            </ul>

            <h3>Aba "Indicadores"</h3>
            <p>Indicadores detalhados com filtros de período:</p>
            
            <p><strong>Estatísticas de Admissões:</strong></p>
            <ul>
                <li>Total de admissões</li>
                <li>Admissões aprovadas</li>
                <li>Admissões reprovadas</li>
                <li>Admissões pendentes</li>
                <li>Admissões auditadas</li>
                <li>Admissões no jurídico</li>
            </ul>

            <p><strong>Estatísticas de Títulos:</strong></p>
            <ul>
                <li>Total de títulos</li>
                <li>Títulos pagos</li>
                <li>Títulos em aberto</li>
                <li>Títulos cancelados</li>
                <li>Títulos vencidos</li>
                <li>Valor recuperado (total de baixas)</li>
                <li>Saldo em aberto (total ainda a receber)</li>
                <li>Taxa de recuperação</li>
            </ul>

            <p><strong>Análise por Faixa de Atraso:</strong></p>
            <p>Mostra como a carteira de títulos vencidos está distribuída por faixas de atraso (1-30, 31-60, 61-90, 91-120, 120+ dias).</p>

            <p><strong>Fluxo de Caixa por Conta:</strong></p>
            <p>Para cada conta bancária, mostra o fluxo de entradas e saídas.</p>

            <p><strong>Ranking de Colaboradores:</strong></p>
            <p>Classificação dos colaboradores por desempenho em recuperação de valores.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Use a aba Resumo para ter uma visão rápida da saúde financeira da empresa</li>
                <li>O Extrato Geral é ótimo para auditar movimentações de um cliente específico</li>
                <li>Acompanhe os Indicadores mensalmente para identificar tendências</li>
                <li>Compare a Taxa de Recuperação com meses anteriores para avaliar o progresso</li>
            </ul>
        `,
        keywords: ['gerenciamento', 'dashboard', 'indicadores', 'KPI', 'resumo', 'extrato', 'saldo', 'recuperação', 'inadimplência', 'fluxo de caixa', 'relatório gerencial']
    },
    {
        id: 'rel_consultas',
        menuPath: 'Relatórios > Consultas',
        title: 'Consultas',
        summary: 'Consultas somente para leitura de clientes, títulos, admissões, movimentações bancárias e colaboradores.',
        content: `<img src="/help-screenshots/rel-consultas.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>A tela de Consultas permite pesquisar dados de cinco fontes autorizadas, sem alterar registros. A unidade ativa e as permissões do usuário determinam quais dados podem ser exibidos.</p>

            <h3>Como usar</h3>
            <ul>
                <li><strong>Selecione o tipo de dados:</strong> Escolha qual tipo de informação você quer consultar (clientes, títulos, admissões, etc.)</li>
                <li><strong>Defina os filtros:</strong> Use os campos de filtro para refinar sua busca</li>
                <li><strong>Visualize os resultados:</strong> Os dados encontrados são exibidos em uma tabela organizada</li>
            </ul>

            <h3>Tipos de consulta disponíveis</h3>
            <ul>
                <li>Consulta de clientes</li>
                <li>Consulta de títulos financeiros</li>
                <li>Consulta de admissões</li>
                <li>Consulta de movimentações bancárias</li>
                <li>Consulta de colaboradores</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Use filtros combinados para encontrar dados específicos mais rapidamente</li>
                <li>Os resultados podem ser ordenados clicando nos cabeçalhos das colunas</li>
                <li>As consultas não alteram dados e exibem no máximo 100 linhas; refine os filtros para obter resultados mais específicos</li>
                <li>Se uma fonte não estiver autorizada, solicite acesso ao administrador</li>
            </ul>
        `,
        keywords: ['consultas', 'pesquisa', 'busca', 'relatório', 'dados', 'filtro', 'visualização']
    },
    {
        id: 'rel_formularios',
        menuPath: 'Relatórios > Formulários',
        title: 'Editor de Formulários',
        summary: 'Editor visual para criar formulários personalizados no formato A4 com variáveis dinâmicas, cabeçalho e rodapé para impressão.',
        content: `<img src="/help-screenshots/rel-formularios.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>O Editor de Formulários permite criar ou importar modelos DOCX, editar documentos A4 e inserir variáveis dinâmicas. As ações disponíveis dependem das permissões do usuário.</p>

            <h3>Editor Visual (WYSIWYG)</h3>
            <p>O editor funciona como um processador de texto simples. O que você vê na tela é o que sairá na impressão. A página tem o tamanho A4 e a paginação é automática.</p>

            <h3>Barra de formatação</h3>
            <p>No topo do editor, há uma barra com ferramentas de formatação:</p>
            <ul>
                <li><strong>Negrito (B):</strong> Deixa o texto em negrito</li>
                <li><strong>Itálico (I):</strong> Deixa o texto em itálico</li>
                <li><strong>Sublinhado (U):</strong> Sublinha o texto</li>
                <li><strong>Alinhamento:</strong> Esquerda, centro, direita ou justificado</li>
                <li><strong>Listas:</strong> Listas numeradas ou com marcadores</li>
                <li><strong>Tamanho da fonte:</strong> Altere o tamanho das letras</li>
                <li><strong>Cores:</strong> Altere a cor do texto ou do fundo</li>
            </ul>

            <h3>Upload de imagens</h3>
            <p>Você pode inserir imagens no formulário. As imagens são convertidas para o formato Base64, ou seja, ficam embutidas no documento e não dependem de arquivos externos.</p>

            <h3>Cabeçalho e Rodapé personalizados</h3>
            <p>Configure um cabeçalho e um rodapé que se repetem automaticamente em todas as páginas do formulário quando impresso. Ideal para colocar o logotipo da empresa, dados da empresa, número de página, etc.</p>

            <h3>Variáveis dinâmicas (Mail Merge)</h3>
            <p>As variáveis são campos especiais que são substituídos automaticamente pelos dados reais quando o formulário é usado. Insira variáveis no texto entre chaves duplas. Categorias disponíveis:</p>
            <ul>
                <li><strong>Cliente:</strong> nome, documento (CPF/CNPJ), e-mail, telefone, endereço completo, etc.</li>
                <li><strong>Colaborador:</strong> nome, cargo, etc.</li>
                <li><strong>Banco:</strong> nome, código, etc.</li>
                <li><strong>Empresa:</strong> razão social, CNPJ, endereço completo, etc.</li>
                <li><strong>Geral:</strong> data atual, hora atual, etc.</li>
            </ul>
            <p><strong>Exemplo:</strong> "Eu, {{cliente_nome}}, portador do CPF {{cliente_documento}}, residente à {{cliente_endereco}}..." será substituído pelos dados reais do cliente selecionado.</p>

            <h3>Gerenciamento de modelos</h3>
            <ul>
                <li><strong>Salvar:</strong> Salve o formulário como um modelo para usar novamente</li>
                <li><strong>Vincular:</strong> Escolha os módulos nos quais o modelo pode ser utilizado</li>
                <li><strong>Editar:</strong> Altere um modelo existente</li>
                <li><strong>Excluir:</strong> Remova modelos que não são mais necessários</li>
                <li><strong>Imprimir:</strong> Imprima o formulário preenchido com os dados selecionados</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Crie modelos para os documentos que você usa com frequência</li>
                <li>Use as variáveis dinâmicas para não ter que digitar os dados do cliente toda vez</li>
                <li>Configure o cabeçalho com o logotipo da empresa para um visual profissional</li>
                <li>Antes de imprimir, verifique se as variáveis foram substituídas corretamente</li>
            </ul>
        `,
        keywords: ['formulário', 'formulários', 'editor', 'modelo', 'template', 'variável', 'impressão', 'contrato', 'declaração', 'procuração', 'A4', 'cabeçalho', 'rodapé', 'WYSIWYG']
    },
    {
        id: 'rel_gerais',
        menuPath: 'Relatórios > Relatórios Gerais',
        title: 'Relatórios Gerais',
        summary: 'Editor e executor de relatórios autorizados, com filtros, preview, gráficos e exportação.',
        content: `<img src="/help-screenshots/rel-gerais.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>Em Relatórios Gerais, administradores podem configurar a fonte de dados somente para leitura, filtros, layout, gráficos e subrelatórios. O preview executável permanece ao lado do editor em telas amplas; em telas menores, abra o preview pelo botão correspondente. Usuários autorizados podem executar e exportar modelos liberados para seu usuário ou grupo.</p>

            <h3>Tipos de relatórios disponíveis</h3>
            <ul>
                <li><strong>Relatórios de Clientes:</strong> Lista de clientes, clientes por região, clientes ativos/inativos</li>
                <li><strong>Relatórios Financeiros:</strong> Resumo de receitas e despesas, fluxo de caixa, títulos vencidos</li>
                <li><strong>Relatórios de Admissões:</strong> Admissões por período, por banco, por colaborador, por status</li>
                <li><strong>Relatórios de Cobrança:</strong> Carteira de cobrança, inadimplência, recuperação</li>
            </ul>

            <h3>Como usar</h3>
            <ul>
                <li><strong>Selecione o relatório:</strong> Escolha um modelo que esteja autorizado para você</li>
                <li><strong>Defina os parâmetros:</strong> Informe os filtros exibidos no preview</li>
                <li><strong>Gere o relatório:</strong> Execute para atualizar os dados e subrelatórios</li>
                <li><strong>Imprima ou exporte:</strong> Use os formatos disponíveis; os resultados têm limite de 500 linhas</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Use relatórios periódicos (mensal, semanal) para acompanhar a evolução do negócio</li>
                <li>Compare relatórios de períodos diferentes para identificar tendências</li>
                <li>Relatórios financeiros são essenciais para a tomada de decisão</li>
            </ul>
        `,
        keywords: ['relatório', 'relatórios', 'gerais', 'análise', 'dados', 'impressão', 'exportar', 'financeiro', 'cobrança', 'admissão']
    },
    {
        id: 'settings_portal',
        menuPath: 'Configurações > Portal',
        title: 'Configurações do Portal (Aparência)',
        summary: 'Personalize a aparência do sistema: cores, logotipo, textos de marketing e identidade visual da tela de login e do painel interno.',
        content: `<img src="/help-screenshots/settings-portal.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>As Configurações do Portal permitem personalizar toda a aparência visual do sistema. Você pode alterar cores, logotipo, textos e imagens para que o sistema tenha a identidade visual da sua empresa.</p>

            <h3>Sub-aba "Login & Identidade"</h3>
            <p>Configura a aparência da tela de login que os usuários veem antes de entrar no sistema:</p>
            <ul>
                <li><strong>Nome da empresa:</strong> O nome que aparece na tela de login e no cabeçalho do sistema.</li>
                <li><strong>Logotipo:</strong> Faça upload do logotipo da sua empresa. Ele aparecerá na tela de login e na Home do sistema. Recomendação: use uma imagem quadrada, de boa qualidade.</li>
                <li><strong>Título de marketing:</strong> A frase principal que aparece na tela de login (ex: "Sua Liberdade Financeira Começa Aqui").</li>
                <li><strong>Texto de marketing:</strong> Um texto complementar abaixo do título (ex: "Especialistas em negociação de dívidas e planejamento estratégico").</li>
                <li><strong>Cores de fundo do login:</strong> Personalize as cores do lado esquerdo (área de marketing) e do lado direito (área do formulário) da tela de login.</li>
            </ul>

            <h3>Sub-aba "Layout Interno"</h3>
            <p>Configura as cores do sistema interno (após o login):</p>
            <ul>
                <li><strong>Cor do menu lateral (Sidebar):</strong> A cor de fundo do menu no lado esquerdo da tela.</li>
                <li><strong>Cor do texto do menu:</strong> A cor dos textos e ícones do menu lateral.</li>
                <li><strong>Cor do cabeçalho:</strong> A cor da barra superior do sistema.</li>
                <li><strong>Cor do texto do cabeçalho:</strong> A cor dos textos na barra superior.</li>
                <li><strong>Cor de fundo do conteúdo:</strong> A cor do fundo da área principal de trabalho.</li>
                <li><strong>Imagem de fundo:</strong> Opcionalmente, defina uma imagem de fundo para a área principal.</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Use as cores da identidade visual da sua empresa para manter a consistência da marca</li>
                <li>O logotipo deve ter boa resolução para não ficar pixelado</li>
                <li>Teste as cores para garantir que o texto fique legível (contraste adequado)</li>
                <li>A imagem de fundo do conteúdo pode deixar o sistema mais bonito, mas certifique-se de que não atrapalhe a leitura</li>
            </ul>
        `,
        keywords: ['portal', 'aparência', 'cores', 'logotipo', 'logo', 'tema', 'personalização', 'identidade visual', 'login', 'layout', 'sidebar', 'cabeçalho']
    },
    {
        id: 'settings_units',
        menuPath: 'Configurações > Unidades',
        title: 'Gestão de Unidades',
        summary: 'Cadastro e gerenciamento das unidades (filiais) da empresa, com dados de CNPJ, endereço e contato.',
        content: `<img src="/help-screenshots/settings-unidades.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>A Gestão de Unidades permite cadastrar e gerenciar as filiais ou unidades da empresa. Cada unidade tem seus próprios dados de CNPJ, endereço e contato. O sistema é multi-unidade, ou seja, uma mesma empresa pode ter várias filiais.</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Razão Social:</strong> O nome jurídico da unidade (como está no contrato social). Ex: "FinancePro Assessoria Ltda - Filial SP".</li>
                <li><strong>CNPJ:</strong> O CNPJ da unidade. O sistema valida automaticamente se o número é válido. Cada unidade deve ter seu próprio CNPJ.</li>
                <li><strong>Telefone:</strong> Telefone principal da unidade.</li>
                <li><strong>E-mail:</strong> E-mail de contato da unidade.</li>
            </ul>

            <h3>Endereço</h3>
            <ul>
                <li><strong>CEP:</strong> Digite o CEP e o endereço será preenchido automaticamente.</li>
                <li><strong>Endereço, Número, Complemento, Bairro, Cidade, Estado:</strong> Dados completos do endereço da unidade.</li>
            </ul>

            <h3>Empresas com múltiplas unidades</h3>
            <p>Se sua empresa tem mais de uma filial, cadastre cada uma como uma unidade separada. Os usuários podem ser vinculados a uma ou mais unidades, e certas informações (como numeração de séries) podem ser controladas por unidade.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Mantenha os dados das unidades sempre atualizados, especialmente endereço e CNPJ</li>
                <li>O CNPJ é validado pelo sistema - verifique se está correto antes de salvar</li>
                <li>Cada unidade pode ter sua própria configuração de e-mail SMTP</li>
            </ul>
        `,
        keywords: ['unidade', 'unidades', 'filial', 'filiais', 'empresa', 'CNPJ', 'razão social', 'endereço', 'multi-unidade']
    },
    {
        id: 'settings_users',
        menuPath: 'Configurações > Usuários',
        title: 'Gestão de Usuários e Grupos de Acesso',
        summary: 'Cadastro de usuários do sistema com controle de acesso, permissões, foto, status e vínculo com colaboradores. Inclui gestão de grupos de acesso com matriz de permissões.',
        content: `<img src="/help-screenshots/settings-usuarios.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>A Gestão de Usuários controla quem pode acessar o sistema e o que cada pessoa pode fazer. Possui duas sub-abas: <strong>Cadastro de Usuários</strong> e <strong>Grupos de Acesso</strong>.</p>

            <h3>Sub-aba "Cadastro de Usuários"</h3>
            <p>Aqui você cria e gerencia as contas de acesso ao sistema:</p>
            <ul>
                <li><strong>Nome:</strong> Nome completo do usuário.</li>
                <li><strong>E-mail:</strong> O e-mail que será usado para fazer login. Deve ser único no sistema.</li>
                <li><strong>Senha:</strong> Defina a senha inicial do usuário ou altere a senha atual. A senha deve seguir as regras de segurança (8+ caracteres, maiúscula, número, caractere especial).</li>
                <li><strong>Foto:</strong> Adicione uma foto do usuário usando a câmera ou fazendo upload de um arquivo.</li>
                <li><strong>Status:</strong>
                    <ul>
                        <li><strong>ATIVO:</strong> O usuário pode acessar o sistema normalmente</li>
                        <li><strong>INATIVO:</strong> O usuário está desativado e não consegue entrar no sistema</li>
                    </ul>
                </li>
                <li><strong>Colaborador associado:</strong> Vincule o usuário a um colaborador cadastrado. Isso permite que o sistema identifique qual colaborador está logado.</li>
                <li><strong>Forçar troca de senha:</strong> Marque esta opção para que o usuário seja obrigado a trocar a senha no próximo login. Útil quando você cria a conta com uma senha provisória.</li>
                <li><strong>Unidades permitidas:</strong> Selecione quais unidades (filiais) este usuário pode acessar.</li>
                <li><strong>Grupos de acesso:</strong> Selecione a quais grupos o usuário pertence. Os grupos definem quais menus e funcionalidades ele pode usar.</li>
            </ul>

            <h3>Indicadores visuais</h3>
            <ul>
                <li><strong>Conta bloqueada:</strong> Um ícone indica visualmente que a conta está bloqueada por tentativas incorretas de senha.</li>
                <li><strong>Troca de senha pendente:</strong> Um ícone indica que o usuário precisa trocar a senha no próximo login.</li>
                <li><strong>Botão Desbloquear:</strong> Para contas bloqueadas, o administrador pode clicar neste botão para desbloquear a conta do usuário.</li>
            </ul>

            <h3>Sub-aba "Grupos de Acesso"</h3>
            <p>Os Grupos de Acesso definem quais permissões um conjunto de usuários tem:</p>
            <ul>
                <li><strong>Nome do grupo:</strong> Um nome descritivo (ex: "Administradores", "Atendentes", "Financeiro").</li>
                <li><strong>Matriz de permissões:</strong> Uma tabela com todos os itens de menu do sistema. Para cada item, existem checkboxes para:
                    <ul>
                        <li><strong>Acesso:</strong> O usuário pode ver/acessar esse menu</li>
                        <li><strong>INCLUIR:</strong> O usuário pode criar novos registros</li>
                        <li><strong>ALTERAR:</strong> O usuário pode editar registros existentes</li>
                        <li><strong>EXCLUIR:</strong> O usuário pode excluir registros</li>
                    </ul>
                </li>
            </ul>

            <h3>Grupos pré-cadastrados</h3>
            <ul>
                <li><strong>Administradores:</strong> Acesso total a todas as funcionalidades do sistema</li>
                <li><strong>Atendentes:</strong> Acesso à Home, Agenda, Atendimento e Cadastro de Clientes</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Crie grupos específicos para cada função na empresa (Comercial, Financeiro, Jurídico)</li>
                <li>Dê apenas as permissões necessárias para cada grupo (princípio do menor privilégio)</li>
                <li>Sempre vincule o usuário ao colaborador correspondente</li>
                <li>Use a opção "Forçar troca de senha" ao criar novos usuários com senha provisória</li>
                <li>Desative usuários que saíram da empresa em vez de excluí-los</li>
            </ul>
        `,
        keywords: ['usuário', 'usuários', 'grupo', 'grupos de acesso', 'permissão', 'permissões', 'senha', 'bloqueio', 'desbloquear', 'acesso', 'login', 'foto', 'status']
    },
    {
        id: 'settings_emails',
        menuPath: 'Configurações > E-mails',
        title: 'Configurações de E-mail',
        summary: 'Configuração do servidor de e-mail SMTP, integração com Google e modelos de mensagens para envio automático.',
        content: `<img src="/help-screenshots/settings-emails.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>As Configurações de E-mail controlam como o sistema envia e-mails. Possui três sub-abas para diferentes aspectos da configuração.</p>

            <h3>Sub-aba "Configuração SMTP"</h3>
            <p>O SMTP é o protocolo usado para enviar e-mails. Configure os dados do servidor de e-mail da sua empresa:</p>
            <ul>
                <li><strong>Servidor (Host):</strong> O endereço do servidor de e-mail (ex: smtp.gmail.com, smtp.office365.com). Pergunte ao seu provedor de e-mail.</li>
                <li><strong>Porta:</strong> O número da porta de conexão. As mais comuns são:
                    <ul>
                        <li><strong>587:</strong> Para conexão TLS (mais segura, recomendada)</li>
                        <li><strong>465:</strong> Para conexão SSL</li>
                        <li><strong>25:</strong> Sem criptografia (não recomendada)</li>
                    </ul>
                </li>
                <li><strong>Usuário:</strong> Geralmente é o endereço de e-mail completo (ex: contato@suaempresa.com).</li>
                <li><strong>Senha:</strong> A senha do e-mail ou uma senha de aplicativo (no caso do Gmail, é necessário gerar uma senha de aplicativo).</li>
            </ul>
            <p>Cada <strong>unidade</strong> pode ter sua própria configuração SMTP, permitindo que cada filial envie e-mails com seu próprio endereço.</p>

            <h3>Sub-aba "Integração Google"</h3>
            <p>Configurações para integração com serviços do Google via OAuth:</p>
            <ul>
                <li>Conecte a conta do Google da empresa</li>
                <li>Configure as permissões de acesso</li>
                <li>Visualize o status da conexão e a última sincronização</li>
            </ul>

            <h3>Sub-aba "Modelos de Mensagem"</h3>
            <p>Crie modelos (templates) de e-mail que podem ser reutilizados. Cada modelo tem:</p>
            <ul>
                <li><strong>Título:</strong> Nome interno do modelo para identificação (ex: "E-mail de cobrança", "Confirmação de agendamento").</li>
                <li><strong>Assunto:</strong> O assunto que aparecerá no e-mail enviado.</li>
                <li><strong>Corpo:</strong> O texto do e-mail. Pode incluir variáveis dinâmicas que serão substituídas pelos dados reais (nome do cliente, valor, data, etc.).</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Teste a configuração SMTP enviando um e-mail de teste antes de usá-la em produção</li>
                <li>Para Gmail, use senhas de aplicativo em vez da senha normal da conta</li>
                <li>Crie modelos para os e-mails que você envia com frequência para economizar tempo</li>
                <li>Use variáveis nos modelos para personalizar automaticamente cada e-mail</li>
            </ul>
        `,
        keywords: ['email', 'e-mail', 'SMTP', 'servidor', 'Google', 'OAuth', 'modelo', 'template', 'mensagem', 'configuração', 'envio']
    },
    {
        id: 'settings_api',
        menuPath: "Configurações > API's",
        title: 'Integrações de API',
        summary: 'Configuração de integrações com sistemas externos via API, com autenticação, headers, body e teste de conexão.',
        content: `<img src="/help-screenshots/settings-api.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>As Integrações de API permitem conectar o FinancePro a outros sistemas externos. Você pode configurar chamadas a APIs de terceiros para enviar ou receber dados automaticamente.</p>

            <h3>Sub-aba "Geral"</h3>
            <p>Informações básicas da integração:</p>
            <ul>
                <li><strong>Nome:</strong> Um nome para identificar a integração (ex: "API de Consulta CPF", "Webhook de Pagamento").</li>
                <li><strong>URL:</strong> O endereço da API externa (ex: https://api.exemplo.com/consulta).</li>
                <li><strong>Método:</strong> O tipo de requisição HTTP:
                    <ul>
                        <li><strong>GET:</strong> Para buscar/consultar dados</li>
                        <li><strong>POST:</strong> Para enviar dados novos</li>
                        <li><strong>PUT:</strong> Para atualizar dados existentes</li>
                        <li><strong>DELETE:</strong> Para excluir dados</li>
                        <li><strong>PATCH:</strong> Para atualizar dados parcialmente</li>
                    </ul>
                </li>
                <li><strong>Descrição:</strong> Uma explicação sobre o que essa integração faz.</li>
            </ul>

            <h3>Sub-aba "Autenticação"</h3>
            <p>Configure como o sistema se autentica na API externa:</p>
            <ul>
                <li><strong>NONE:</strong> Sem autenticação (APIs públicas)</li>
                <li><strong>BEARER:</strong> Usa um token de acesso (o mais comum em APIs modernas)</li>
                <li><strong>BASIC:</strong> Usa usuário e senha</li>
                <li><strong>HEADER KEY:</strong> Usa uma chave de API enviada no cabeçalho da requisição</li>
            </ul>

            <h3>Sub-aba "Headers"</h3>
            <p>Configure cabeçalhos adicionais da requisição em formato de pares chave-valor. Exemplo:</p>
            <ul>
                <li>Content-Type: application/json</li>
                <li>Accept: application/json</li>
            </ul>

            <h3>Sub-aba "Body JSON"</h3>
            <p>Para requisições POST/PUT/PATCH, configure o corpo (body) da requisição em formato JSON. Um editor de texto permite escrever e formatar o JSON.</p>

            <h3>Sub-aba "Teste"</h3>
            <p>Execute a integração em modo de teste para verificar se está funcionando:</p>
            <ul>
                <li>Clique no botão de testar</li>
                <li>O sistema faz a chamada à API com as configurações definidas</li>
                <li>O resultado da resposta é exibido na tela (código de status, dados retornados, etc.)</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Sempre teste a integração antes de usá-la em produção</li>
                <li>Guarde os tokens e chaves de API em local seguro</li>
                <li>Se a API retornar erro, verifique a URL, autenticação e headers</li>
                <li>Consulte a documentação da API externa para saber quais campos enviar</li>
            </ul>
        `,
        keywords: ['API', 'integração', 'integrações', 'webhook', 'REST', 'HTTP', 'GET', 'POST', 'autenticação', 'token', 'headers', 'JSON', 'teste']
    },
    {
        id: 'settings_help',
        menuPath: 'Configurações > Central de Ajuda',
        title: 'Central de Ajuda (Administração)',
        summary: 'Painel administrativo para gerenciar o conteúdo da Central de Ajuda do sistema, editar tópicos e organizar por menu.',
        content: `<img src="/help-screenshots/settings-help.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />
            
            <h3>Visão geral</h3>
            <p>A Central de Ajuda (Administração) é onde o administrador gerencia todo o conteúdo de ajuda que os usuários veem quando acessam a ajuda do sistema. Você pode editar os textos explicativos, adicionar novos tópicos e organizar o conteúdo.</p>

            <h3>O que você pode fazer</h3>
            <ul>
                <li><strong>Editar tópicos existentes:</strong> Altere o título, resumo e conteúdo detalhado de qualquer tópico de ajuda.</li>
                <li><strong>Adicionar novos tópicos:</strong> Crie novos conteúdos de ajuda para telas ou funcionalidades que ainda não têm documentação.</li>
                <li><strong>Organizar por menu:</strong> Os tópicos são organizados seguindo a mesma estrutura do menu do sistema, facilitando a navegação dos usuários.</li>
                <li><strong>Pesquisa:</strong> Configure palavras-chave para que os usuários encontrem facilmente os tópicos através da busca.</li>
            </ul>

            <h3>Estrutura de cada tópico</h3>
            <ul>
                <li><strong>Título:</strong> Nome do tópico (ex: "Cadastro de Clientes").</li>
                <li><strong>Caminho no menu:</strong> Onde o tópico se encaixa na estrutura do menu (ex: "Cadastros > Clientes").</li>
                <li><strong>Resumo:</strong> Uma descrição curta de 1-2 frases sobre o que a tela faz.</li>
                <li><strong>Conteúdo:</strong> O texto detalhado com explicações completas, formatado em HTML (negrito, listas, títulos, etc.).</li>
                <li><strong>Palavras-chave:</strong> Termos que os usuários podem buscar para encontrar este tópico.</li>
            </ul>

            <h3>Dicas para escrever bom conteúdo de ajuda</h3>
            <ul>
                <li>Use <strong>linguagem simples</strong> que qualquer pessoa possa entender</li>
                <li>Explique <strong>cada campo</strong> do formulário e o que deve ser preenchido</li>
                <li>Explique <strong>cada botão</strong> e o que acontece quando é clicado</li>
                <li>Inclua <strong>exemplos práticos</strong> quando possível</li>
                <li>Organize o conteúdo com <strong>títulos e listas</strong> para facilitar a leitura</li>
                <li>Mantenha o conteúdo <strong>atualizado</strong> quando houver mudanças no sistema</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Revise periodicamente os conteúdos de ajuda para garantir que estejam atualizados</li>
                <li>Peça feedback dos usuários sobre quais tópicos precisam de mais detalhes</li>
                <li>Adicione palavras-chave variadas para facilitar a busca (ex: para "Clientes", adicione "cliente", "CPF", "cadastro", "pessoa física")</li>
            </ul>
        `,
        keywords: ['ajuda', 'central de ajuda', 'help', 'documentação', 'tópico', 'conteúdo', 'administração', 'editor', 'suporte']
    }
    ,
    {
        id: 'cad_cargos',
        menuPath: 'Cadastros > Cargos',
        title: 'Cadastro de Cargos',
        summary: 'Tela para registrar os cargos ou funções dos colaboradores da empresa, com opção de participação na fila de agendamento.',
        content: `
            <img src="/help-screenshots/cad-cargos.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>O Cadastro de Cargos permite registrar todas as funções existentes na empresa. Os cargos são utilizados no Cadastro de Colaboradores para identificar a função de cada membro da equipe e, opcionalmente, para controlar a fila de agendamento.</p>

            <h3>Grade de dados (listagem)</h3>
            <p>A tela principal exibe uma tabela com todos os cargos cadastrados, contendo as colunas:</p>
            <ul>
                <li><strong>Nome:</strong> O nome do cargo.</li>
                <li><strong>Agendamento:</strong> Indica (com Sim ou Não) se o cargo participa da fila de agendamento.</li>
                <li><strong>Ações:</strong> Botões para Editar, Duplicar e Excluir o cargo.</li>
            </ul>
            <p>Você pode usar o campo de busca no topo para filtrar cargos pelo nome. A paginação na parte inferior permite navegar entre páginas de resultados.</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Nome do Cargo:</strong> O nome completo da função. Exemplos: "Consultor de Negócios", "Gerente Comercial", "Analista Jurídico", "Atendente", "Diretor Financeiro". Campo obrigatório — não é possível salvar sem preencher.</li>
                <li><strong>Participa da Fila de Agendamento:</strong> Checkbox (caixa de marcação). Quando marcado, indica que colaboradores com este cargo aparecem na lista de disponíveis para agendamentos na Agenda. Se desmarcado, o cargo não é exibido na fila de agendamento — útil para cargos administrativos que não realizam atendimentos.</li>
            </ul>

            <h3>Como criar um novo cargo</h3>
            <ol>
                <li>Clique no botão <strong>"Novo Cargo"</strong> no canto superior direito.</li>
                <li>O formulário de cadastro abre na tela.</li>
                <li>Digite o <strong>Nome do Cargo</strong>.</li>
                <li>Marque o checkbox <strong>"Participa da Fila de Agendamento"</strong> se necessário.</li>
                <li>Clique em <strong>"Salvar"</strong> (ou pressione Ctrl+S).</li>
            </ol>

            <h3>Duplicar cargo</h3>
            <p>Para criar um cargo similar a um já existente, clique no botão de duplicar na linha do cargo. O sistema abre o formulário com os dados copiados (com "Cópia de" no nome) para que você faça os ajustes necessários antes de salvar.</p>

            <h3>Excluir cargo</h3>
            <p>Clique em <strong>"Excluir"</strong> na linha do cargo. O sistema pedirá confirmação. Se o cargo estiver sendo usado por algum colaborador, a exclusão pode ser bloqueada — nesse caso, inative o colaborador antes de tentar excluir o cargo.</p>

            <h3>Uso no sistema</h3>
            <p>Os cargos cadastrados aqui aparecem como opção no campo <strong>"Cargo"</strong> do Cadastro de Colaboradores. Quando um cargo é marcado para participar da fila de agendamento, os colaboradores que ocupam esse cargo ficam disponíveis para seleção na Agenda.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Crie um cargo para cada função existente na empresa</li>
                <li>Marque "Participa da Fila de Agendamento" somente para cargos que realizam atendimentos com clientes</li>
                <li>Use nomes padronizados para facilitar a identificação (ex: sempre em maiúsculas ou sempre em minúsculas)</li>
                <li>Você pode duplicar um cargo para criar variações (ex: "Consultor Júnior" a partir de "Consultor")</li>
            </ul>
        `,
        keywords: ['cargo', 'cargos', 'função', 'funções', 'agendamento', 'fila', 'colaborador', 'consultor', 'gerente', 'analista', 'atendente']
    },
    {
        id: 'cad_departamentos',
        menuPath: 'Cadastros > Departamentos',
        title: 'Cadastro de Departamentos (Cadastros)',
        summary: 'Tela para registrar os departamentos ou setores da empresa, usados para vincular colaboradores e organizar a estrutura organizacional.',
        content: `
            <img src="/help-screenshots/cad-departamentos.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>O Cadastro de Departamentos (disponível no menu Cadastros) permite registrar os setores da empresa. Esses departamentos são usados no Cadastro de Colaboradores para indicar em qual setor cada colaborador trabalha, além de serem usados como centros de custo no módulo financeiro.</p>

            <h3>Grade de dados (listagem)</h3>
            <p>A tela principal exibe uma tabela com todos os departamentos, contendo as colunas:</p>
            <ul>
                <li><strong>Código:</strong> O código numérico ou alfanumérico do departamento (ex: "01", "02").</li>
                <li><strong>Descrição:</strong> O nome completo do departamento (sempre em maiúsculas).</li>
                <li><strong>Responsável:</strong> O nome do gerente ou responsável pelo departamento.</li>
                <li><strong>Status:</strong> Um badge colorido indicando <span style="color:green">ATIVO</span> (verde) ou <span style="color:red">INATIVO</span> (vermelho).</li>
                <li><strong>Ações:</strong> Botões para Auditar, Editar e Excluir.</li>
            </ul>
            <p>Use o campo de pesquisa no topo para buscar departamentos pelo nome ou código.</p>

            <h3>Campos do formulário</h3>
            <ul>
                <li><strong>Código:</strong> Um código curto e único para identificar o departamento. Exemplos: "01" para o primeiro departamento, "02" para o segundo. Serve para organização e referência rápida. Campo opcional.</li>
                <li><strong>Nome do Departamento:</strong> O nome completo do setor. O sistema converte automaticamente para <strong>letras maiúsculas</strong> enquanto você digita. Exemplos: "FINANCEIRO", "COMERCIAL", "JURÍDICO", "ADMINISTRATIVO", "RECURSOS HUMANOS". Campo obrigatório.</li>
                <li><strong>Responsável / Gerente:</strong> O nome completo da pessoa responsável pelo departamento. Exemplos: "João da Silva", "Dra. Ana Costa". Campo opcional.</li>
                <li><strong>Status:</strong> Define se o departamento está disponível para uso:
                    <ul>
                        <li><strong>Ativo:</strong> O departamento aparece nas listas de seleção do sistema e pode receber colaboradores e lançamentos financeiros.</li>
                        <li><strong>Inativo:</strong> O departamento não aparece nas listas de seleção, mas seus dados históricos são mantidos.</li>
                    </ul>
                </li>
            </ul>

            <h3>Como criar um novo departamento</h3>
            <ol>
                <li>Clique no botão <strong>"Novo Departamento"</strong> no canto superior direito.</li>
                <li>O formulário abre em um modal.</li>
                <li>Preencha o <strong>Código</strong> e o <strong>Nome</strong> (obrigatório).</li>
                <li>Adicione o <strong>Responsável</strong> se necessário.</li>
                <li>Defina o <strong>Status</strong> como Ativo.</li>
                <li>Clique em <strong>"Salvar"</strong>.</li>
            </ol>

            <h3>Botão de Auditoria</h3>
            <p>O ícone de auditoria (relógio) na linha de cada departamento abre o histórico completo de alterações feitas naquele registro: quem alterou, quando e o que mudou.</p>

            <h3>Excluir departamento</h3>
            <p>A exclusão é bloqueada se o departamento estiver sendo usado por colaboradores ou lançamentos financeiros. Nesse caso, desative o departamento (status Inativo) em vez de excluí-lo.</p>

            <h3>Uso no sistema</h3>
            <p>Os departamentos aparecem em:</p>
            <ul>
                <li><strong>Cadastro de Colaboradores:</strong> Para indicar o setor de cada funcionário</li>
                <li><strong>Contas a Receber e Contas a Pagar:</strong> Para classificar lançamentos por centro de custo</li>
                <li><strong>Movimentos bancários:</strong> Para associar movimentos a departamentos específicos</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Use códigos sequenciais para facilitar a organização (01, 02, 03...)</li>
                <li>Mantenha o nome do responsável atualizado quando houver mudanças de gerência</li>
                <li>Não exclua departamentos com histórico — prefira inativar</li>
                <li>Crie departamentos específicos para facilitar relatórios financeiros por área</li>
            </ul>
        `,
        keywords: ['departamento', 'departamentos', 'setor', 'área', 'centro de custo', 'gerente', 'responsável', 'código', 'cadastro']
    },
    {
        id: 'jur_dashboard',
        menuPath: 'Acompanhamento Jurídico > Dashboard',
        title: 'Dashboard Jurídico',
        summary: 'Painel com visão geral dos processos judiciais da empresa: indicadores, distribuição por tipo, status, unidade e próximos prazos e audiências.',
        content: `
            <img src="/help-screenshots/jur-dashboard.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>O Dashboard Jurídico é a tela inicial do módulo de Acompanhamento Jurídico. Ela reúne em um único painel todos os indicadores dos processos judiciais em que a empresa está envolvida (como ré, autora ou terceira interessada), permitindo uma gestão visual e proativa.</p>

            <h3>Cards de indicadores (topo da tela)</h3>
            <p>Cinco cards resumem a situação atual dos processos:</p>
            <ul>
                <li><strong>Processos Ativos:</strong> Quantidade total de processos com status <strong>ATIVO</strong>. Processos encerrados ou suspensos não são contados.</li>
                <li><strong>Prazos Vencendo (7d):</strong> Quantidade de prazos processuais com status <strong>PENDENTE</strong> cujo vencimento ocorre nos próximos 7 dias. Atenção redobrada é necessária nesses casos.</li>
                <li><strong>Audiências Próximas (7d):</strong> Quantidade de audiências com status <strong>AGENDADA</strong> marcadas para os próximos 7 dias.</li>
                <li><strong>Valor Provisionado:</strong> Soma total dos valores provisionados em todos os processos cadastrados. O provisionamento é o valor que a empresa reserva contabilmente para cobrir possíveis condenações.</li>
                <li><strong>Risco (Ativos):</strong> Distribuição dos processos ativos por nível de risco, com badges coloridos:
                    <ul>
                        <li><span style="color:#10b981">Baixo</span> — Probabilidade de perda pequena</li>
                        <li><span style="color:#f59e0b">Médio</span> — Risco moderado de perda</li>
                        <li><span style="color:#f97316">Alto</span> — Risco elevado de perda</li>
                        <li><span style="color:#ef4444">Crítico</span> — Processo em situação crítica</li>
                    </ul>
                </li>
            </ul>

            <h3>Gráficos de distribuição</h3>
            <p>Três gráficos em formato de barras e rosca mostram como os processos estão distribuídos:</p>
            <ul>
                <li><strong>Processos por Tipo (barras horizontais):</strong> Mostra quantos processos existem de cada tipo jurídico:
                    <ul>
                        <li>Trabalhista, Cível, Tributário, Consumidor, Criminal, Administrativo, Outro</li>
                    </ul>
                </li>
                <li><strong>Processos por Status (gráfico de rosca):</strong> Distribuição visual dos processos por seu status atual:
                    <ul>
                        <li>Ativo, Suspenso, Arquivado, Encerrado Procedente, Encerrado Improcedente, Acordo</li>
                    </ul>
                    No centro do gráfico aparece o número total de processos.
                </li>
                <li><strong>Processos por Unidade (barras horizontais):</strong> Mostra quantos processos estão associados a cada unidade (filial) da empresa. Útil para empresas com múltiplas filiais.</li>
            </ul>

            <h3>Tabelas de próximos eventos</h3>
            <p>Na parte inferior do dashboard, duas tabelas listam os eventos mais urgentes:</p>
            <ul>
                <li><strong>Próximos Prazos:</strong> Lista os até 10 prazos pendentes mais próximos do vencimento, com colunas:
                    <ul>
                        <li><strong>Processo:</strong> Número do processo</li>
                        <li><strong>Descrição:</strong> O que precisa ser feito</li>
                        <li><strong>Data:</strong> Data de vencimento do prazo</li>
                        <li><strong>Responsável:</strong> Colaborador designado</li>
                        <li><strong>Prazo:</strong> Badge colorido com dias restantes (verde = ok, amarelo = atenção, vermelho = urgente/vencido)</li>
                    </ul>
                </li>
                <li><strong>Próximas Audiências:</strong> Lista as até 10 audiências agendadas mais próximas, com colunas:
                    <ul>
                        <li><strong>Processo:</strong> Número do processo</li>
                        <li><strong>Data:</strong> Data da audiência</li>
                        <li><strong>Hora:</strong> Horário da audiência</li>
                        <li><strong>Tipo:</strong> Tipo de audiência (Inicial, Instrução, Julgamento, etc.)</li>
                        <li><strong>Local:</strong> Local onde ocorrerá</li>
                        <li><strong>Prazo:</strong> Dias restantes com badge colorido</li>
                    </ul>
                </li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Acesse o dashboard diariamente para monitorar prazos urgentes</li>
                <li>Se o card "Prazos Vencendo (7d)" mostrar um número alto, acesse imediatamente a tela de Prazos para tomar providências</li>
                <li>O valor provisionado deve ser atualizado periodicamente conforme o andamento dos processos</li>
                <li>Processos com risco Crítico devem ter atenção prioritária da equipe jurídica</li>
            </ul>
        `,
        keywords: ['dashboard jurídico', 'processos', 'prazos', 'audiências', 'risco', 'valor provisionado', 'indicadores', 'jurídico', 'acompanhamento']
    },
    {
        id: 'jur_processos',
        menuPath: 'Acompanhamento Jurídico > Processos',
        title: 'Processos Judiciais',
        summary: 'Lista e gerenciamento completo dos processos judiciais da empresa, com formulário detalhado, movimentações, prazos e audiências por processo.',
        content: `
            <img src="/help-screenshots/jur-processos.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>A tela de Processos Judiciais é onde você cadastra e acompanha todos os processos em que a empresa está envolvida (trabalhista, cível, tributário, etc.). Cada processo tem um cadastro detalhado com dados da ação, movimentações, prazos e audiências.</p>

            <h3>Grade de dados (listagem)</h3>
            <p>A tabela principal exibe os processos cadastrados com as seguintes colunas (todas clicáveis para ordenar):</p>
            <ul>
                <li><strong>Nº Processo:</strong> O número oficial do processo no tribunal (CNJ ou número antigo).</li>
                <li><strong>Vara/Comarca:</strong> Nome da vara judicial e comarca onde o processo tramita.</li>
                <li><strong>Parte Adversa:</strong> Nome do autor ou réu oposto à empresa no processo.</li>
                <li><strong>Parceiro:</strong> Cliente vinculado ao processo (quando o processo envolve um cliente da empresa).</li>
                <li><strong>Tipo:</strong> Natureza jurídica — Trabalhista, Cível, Tributário, Consumidor, Criminal, Administrativo ou Outro.</li>
                <li><strong>Papel:</strong> O papel que a empresa ocupa no processo (ex: Réu, Autor, Terceiro).</li>
                <li><strong>Risco:</strong> Nível de risco com badge colorido — Baixo, Médio, Alto ou Crítico.</li>
                <li><strong>Status:</strong> Situação atual — Ativo, Suspenso, Arquivado, Encerrado Procedente, Encerrado Improcedente, Acordo.</li>
                <li><strong>Advogado:</strong> Nome do advogado responsável pelo processo.</li>
                <li><strong>Últ. Mov.:</strong> Data da última movimentação registrada.</li>
                <li><strong>Valor:</strong> Valor da causa em Reais.</li>
                <li><strong>Ações:</strong> Botões para Visualizar, Editar, Duplicar e Excluir.</li>
            </ul>

            <h3>Busca e filtros</h3>
            <p>No topo da lista, há um campo de busca livre que pesquisa em:</p>
            <ul>
                <li>Número do processo, vara, comarca, parte adversa, assunto, advogado e parceiro</li>
            </ul>
            <p>Clique no botão <strong>"Filtros"</strong> para expandir os filtros avançados:</p>
            <ul>
                <li><strong>Tipo:</strong> Filtre por natureza jurídica (Trabalhista, Cível, etc.)</li>
                <li><strong>Status:</strong> Filtre por situação (Ativo, Suspenso, etc.)</li>
                <li><strong>Risco:</strong> Filtre por nível de risco (Baixo, Médio, Alto, Crítico)</li>
                <li><strong>Unidade:</strong> Filtre por filial/unidade da empresa</li>
                <li><strong>Parceiro:</strong> Busca por nome, CPF ou telefone do parceiro/cliente</li>
                <li><strong>De / Até:</strong> Filtre por data de distribuição do processo</li>
            </ul>
            <p>Clique em <strong>"Limpar"</strong> para remover todos os filtros aplicados.</p>

            <h3>Formulário de cadastro do processo</h3>
            <p>Ao clicar em <strong>"Novo Processo"</strong> ou editar um existente, um formulário completo é exibido com as seguintes seções:</p>

            <h4>Dados Principais</h4>
            <ul>
                <li><strong>Número do Processo:</strong> O número CNJ do processo (formato: NNNNNNN-DD.AAAA.J.TT.OOOO) ou outro formato. Campo obrigatório.</li>
                <li><strong>Vara:</strong> Nome da vara judicial onde o processo tramita (ex: "3ª Vara do Trabalho").</li>
                <li><strong>Comarca:</strong> A comarca onde o processo tramita (ex: "São Paulo", "Campinas").</li>
                <li><strong>Tipo:</strong> Natureza jurídica do processo. Selecione: Trabalhista, Cível, Tributário, Consumidor, Criminal, Administrativo, Outro.</li>
                <li><strong>Papel da Empresa:</strong> Como a empresa participa do processo — Réu, Autor, Terceiro Interessado, etc.</li>
                <li><strong>Status:</strong> Situação atual do processo. Selecione: Ativo, Suspenso, Arquivado, Encerrado Procedente, Encerrado Improcedente, Acordo.</li>
                <li><strong>Nível de Risco:</strong> Avaliação jurídica do risco de perda. Selecione: Baixo, Médio, Alto, Crítico.</li>
                <li><strong>Unidade:</strong> Filial/unidade da empresa envolvida no processo.</li>
                <li><strong>Parceiro:</strong> Cliente vinculado ao processo (opcional).</li>
            </ul>

            <h4>Parte Adversa</h4>
            <ul>
                <li><strong>Nome da Parte Adversa:</strong> Nome completo do autor (ou réu oposto). Campo obrigatório.</li>
                <li><strong>Documento da Parte Adversa:</strong> CPF ou CNPJ da parte adversa.</li>
            </ul>

            <h4>Valores e Datas</h4>
            <ul>
                <li><strong>Valor da Causa:</strong> O valor declarado na ação judicial (ex: R$ 50.000,00).</li>
                <li><strong>Valor Provisionado:</strong> Quanto a empresa provisionou (reservou) para cobrir uma possível condenação.</li>
                <li><strong>Data de Distribuição:</strong> Data em que o processo foi distribuído ao juízo.</li>
                <li><strong>Data da Última Movimentação:</strong> Data do último andamento registrado no tribunal.</li>
            </ul>

            <h4>Responsável</h4>
            <ul>
                <li><strong>Advogado Responsável:</strong> Nome do advogado que cuida do processo na empresa.</li>
                <li><strong>Assunto:</strong> Uma descrição resumida do objeto da ação (ex: "Revisão de horas extras", "Danos morais por cobrança indevida").</li>
                <li><strong>Observações:</strong> Campo livre para anotações internas sobre o processo.</li>
            </ul>

            <h3>Visualização detalhada do processo</h3>
            <p>Ao clicar no ícone de visualizar, uma tela de detalhe do processo é aberta com abas para:</p>
            <ul>
                <li><strong>Movimentações:</strong> Linha do tempo com todos os andamentos do processo registrados, com data, descrição e tipo.</li>
                <li><strong>Prazos:</strong> Lista dos prazos deste processo específico (também visíveis na tela de Prazos do módulo).</li>
                <li><strong>Audiências:</strong> Lista das audiências deste processo específico.</li>
            </ul>

            <h3>Imprimir / Formulários</h3>
            <p>O botão de formulários permite gerar documentos a partir dos dados do processo usando os modelos de formulário cadastrados no sistema.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Mantenha o número do processo exatamente como aparece no tribunal para facilitar buscas</li>
                <li>Atualize o status e o nível de risco conforme o processo avança</li>
                <li>Registre todas as movimentações para ter um histórico completo</li>
                <li>O valor provisionado deve ser revisado após cada audiência importante</li>
                <li>Use o campo parceiro para vincular processos a clientes da empresa</li>
            </ul>
        `,
        keywords: ['processo', 'processos', 'judicial', 'ação', 'vara', 'comarca', 'parte adversa', 'advogado', 'risco', 'trabalhista', 'cível', 'tributário', 'movimentação', 'cadastrar processo']
    },
    {
        id: 'jur_prazos',
        menuPath: 'Acompanhamento Jurídico > Prazos',
        title: 'Prazos e Audiências',
        summary: 'Gerenciamento centralizado de todos os prazos processuais e audiências dos processos judiciais, com alertas automáticos e controle de status.',
        content: `
            <img src="/help-screenshots/jur-prazos.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>A tela de Prazos e Audiências centraliza o acompanhamento de todos os prazos e datas de audiências dos processos judiciais, independentemente do processo ao qual pertencem. O sistema envia alertas automáticos quando prazos se aproximam.</p>

            <h3>Alertas automáticos</h3>
            <p>O sistema verifica automaticamente os prazos e audiências <strong>pendentes</strong>. Quando um prazo ou audiência está faltando <strong>7, 5 ou 3 dias</strong> para o vencimento, uma mensagem de alerta é enviada automaticamente pelo sistema para todos os usuários. Isso garante que a equipe não perca nenhum prazo crítico.</p>

            <h3>Aba "Prazos"</h3>
            <p>Exibe todos os prazos processuais de todos os processos cadastrados, com as colunas:</p>
            <ul>
                <li><strong>Processo:</strong> Número do processo ao qual o prazo pertence.</li>
                <li><strong>Descrição:</strong> O que precisa ser feito (ex: "Apresentar contestação", "Recurso de apelação", "Manifestar sobre laudo pericial").</li>
                <li><strong>Tipo:</strong> Classificação do prazo:
                    <ul>
                        <li><strong>Contestação:</strong> Prazo para apresentar defesa</li>
                        <li><strong>Recurso:</strong> Prazo para interpor recurso</li>
                        <li><strong>Manifestação:</strong> Prazo para se manifestar sobre documentos</li>
                        <li><strong>Cumprimento:</strong> Prazo para cumprir determinação judicial</li>
                        <li><strong>Audiência:</strong> Prazo relacionado a audiência</li>
                        <li><strong>Outro:</strong> Outros tipos de prazo</li>
                    </ul>
                </li>
                <li><strong>Vencimento:</strong> Data limite para cumprir o prazo.</li>
                <li><strong>Responsável:</strong> Colaborador designado para cumprir o prazo.</li>
                <li><strong>Status:</strong> Situação do prazo:
                    <ul>
                        <li><strong>Pendente:</strong> O prazo ainda precisa ser cumprido</li>
                        <li><strong>Cumprido:</strong> O prazo foi cumprido (ação realizada)</li>
                        <li><strong>Vencido:</strong> O prazo passou sem ser cumprido</li>
                    </ul>
                </li>
                <li><strong>Dias:</strong> Badge colorido mostrando quantos dias faltam (verde = ok, amarelo = atenção, vermelho = urgente/vencido).</li>
                <li><strong>Ações:</strong> Botões para Editar e Excluir o prazo.</li>
            </ul>

            <h4>Filtros da aba Prazos</h4>
            <ul>
                <li><strong>Status:</strong> Filtre por Pendente, Cumprido ou Vencido</li>
                <li><strong>Tipo:</strong> Filtre por tipo de prazo</li>
                <li><strong>Responsável:</strong> Filtre pelos prazos de um colaborador específico</li>
                <li><strong>De / Até:</strong> Filtre por faixa de data de vencimento</li>
            </ul>

            <h4>Formulário de novo prazo</h4>
            <ul>
                <li><strong>Processo:</strong> Selecione o processo ao qual o prazo pertence. Campo obrigatório.</li>
                <li><strong>Descrição:</strong> O que precisa ser feito (ex: "Apresentar contestação"). Campo obrigatório.</li>
                <li><strong>Tipo:</strong> Classificação do prazo. Selecione uma das opções disponíveis.</li>
                <li><strong>Data de Vencimento:</strong> Data limite. Campo obrigatório.</li>
                <li><strong>Responsável:</strong> Selecione o colaborador responsável. Campo obrigatório para que o sistema saiba quem alertar.</li>
                <li><strong>Status:</strong> Normalmente inicia como "Pendente".</li>
                <li><strong>Observações:</strong> Anotações adicionais sobre o prazo.</li>
            </ul>

            <h3>Aba "Audiências"</h3>
            <p>Exibe todas as audiências de todos os processos, com as colunas:</p>
            <ul>
                <li><strong>Processo:</strong> Número do processo.</li>
                <li><strong>Data:</strong> Data da audiência.</li>
                <li><strong>Hora:</strong> Horário de início.</li>
                <li><strong>Tipo:</strong> Natureza da audiência:
                    <ul>
                        <li><strong>Inicial:</strong> Primeira audiência do processo</li>
                        <li><strong>Instrução:</strong> Audiência para coleta de provas/depoimentos</li>
                        <li><strong>Julgamento:</strong> Audiência de julgamento</li>
                        <li><strong>Conciliação:</strong> Tentativa de acordo entre as partes</li>
                        <li><strong>Outro:</strong> Outros tipos</li>
                    </ul>
                </li>
                <li><strong>Local:</strong> Onde a audiência será realizada (ex: "3ª Vara do Trabalho - Sala 2", "Virtual via Microsoft Teams").</li>
                <li><strong>Status:</strong> Situação da audiência:
                    <ul>
                        <li><strong>Agendada:</strong> A audiência está marcada</li>
                        <li><strong>Realizada:</strong> A audiência aconteceu</li>
                        <li><strong>Adiada:</strong> A audiência foi remarcada</li>
                        <li><strong>Cancelada:</strong> A audiência foi cancelada</li>
                    </ul>
                </li>
                <li><strong>Dias:</strong> Badge com dias até a audiência.</li>
            </ul>

            <h4>Filtros da aba Audiências</h4>
            <ul>
                <li><strong>Status:</strong> Filtre por Agendada, Realizada, Adiada ou Cancelada</li>
                <li><strong>Tipo:</strong> Filtre por tipo de audiência</li>
                <li><strong>De / Até:</strong> Filtre por faixa de data</li>
            </ul>

            <h4>Formulário de nova audiência</h4>
            <ul>
                <li><strong>Processo:</strong> Selecione o processo. Campo obrigatório.</li>
                <li><strong>Data:</strong> Data da audiência. Campo obrigatório.</li>
                <li><strong>Hora:</strong> Horário de início. Campo obrigatório.</li>
                <li><strong>Tipo:</strong> Tipo de audiência. Campo obrigatório.</li>
                <li><strong>Local:</strong> Local físico ou virtual da audiência.</li>
                <li><strong>Status:</strong> Normalmente inicia como "Agendada".</li>
                <li><strong>Observações:</strong> Anotações sobre a audiência (ex: "Testemunhas convocadas: João e Maria").</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Cadastre os prazos assim que receber uma intimação — não deixe para depois</li>
                <li>Sempre defina um responsável para cada prazo, pois o sistema usará essa informação nos alertas</li>
                <li>Marque o prazo como "Cumprido" assim que a ação for realizada</li>
                <li>Os alertas automáticos (3, 5 e 7 dias) são enviados pelo sistema — verifique as mensagens regularmente</li>
                <li>Após uma audiência, atualize seu status para "Realizada" e registre o resultado nas movimentações do processo</li>
            </ul>
        `,
        keywords: ['prazo', 'prazos', 'audiência', 'audiências', 'contestação', 'recurso', 'manifestação', 'cumprimento', 'alerta', 'vencimento', 'responsável', 'conciliação', 'julgamento']
    },
    {
        id: 'mensagens',
        menuPath: 'Mensagens',
        title: 'Central de Mensagens',
        summary: 'Sistema interno de comunicação entre usuários, com conversas individuais, grupos, mensagens do sistema e integração WhatsApp via GoTalk.',
        content: `
            <img src="/help-screenshots/mensagens.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>A Central de Mensagens é o sistema de comunicação interna do FinancePro. Permite trocar mensagens com outros usuários do sistema, participar de grupos, receber alertas automáticos do sistema e acessar conversas de WhatsApp dos clientes via integração GoTalk.</p>

            <h3>Layout da tela</h3>
            <p>A tela está dividida em dois painéis:</p>
            <ul>
                <li><strong>Painel esquerdo (lista de conversas):</strong> Exibe as abas de navegação e a lista de conversas ou contatos.</li>
                <li><strong>Painel direito (chat):</strong> Exibe a conversa selecionada com todos os balões de mensagem.</li>
            </ul>

            <h3>Abas do painel esquerdo</h3>
            <ul>
                <li><strong>Conversas:</strong> Lista todas as conversas ativas. Cada item mostra o nome do contato/grupo, o trecho da última mensagem, o horário e um badge com a quantidade de mensagens não lidas.</li>
                <li><strong>Contatos:</strong> Lista todos os usuários do sistema disponíveis para iniciar uma nova conversa. Contatos com status online aparecem com um indicador verde.</li>
                <li><strong>WhatsApp:</strong> Lista as conversas de WhatsApp dos clientes integradas via GoTalk. Veja o número do telefone, nome do contato/cliente e última mensagem recebida.</li>
            </ul>

            <h3>Filtros de conversas</h3>
            <p>Na aba Conversas, use os filtros para organizar sua caixa de entrada:</p>
            <ul>
                <li><strong>Todos:</strong> Mostra todas as conversas</li>
                <li><strong>Não lidos:</strong> Filtra apenas conversas com mensagens não lidas</li>
                <li><strong>Sistema:</strong> Mostra apenas mensagens automáticas do sistema (alertas de prazos, auditoria, etc.)</li>
                <li><strong>Direto:</strong> Mostra apenas conversas individuais (você com outro usuário)</li>
                <li><strong>Grupo:</strong> Mostra apenas conversas em grupo</li>
            </ul>

            <h3>Campo de busca</h3>
            <p>O campo de busca na parte superior filtra as conversas pelo nome do contato ou pelo conteúdo das mensagens.</p>

            <h3>Como ler mensagens</h3>
            <p>Clique em qualquer conversa na lista para abrir o chat no painel direito. As mensagens são exibidas em balões:</p>
            <ul>
                <li>Mensagens <strong>enviadas por você</strong>: balão verde-escuro, alinhadas à direita</li>
                <li>Mensagens <strong>recebidas</strong>: balão branco, alinhadas à esquerda</li>
                <li>Mensagens do <strong>sistema</strong>: centralizadas com ícone de engrenagem</li>
            </ul>
            <p>Cada mensagem mostra a data e hora do envio. Para mensagens enviadas, há indicadores de status:</p>
            <ul>
                <li><strong>✓</strong> (um check) — Mensagem enviada</li>
                <li><strong>✓✓</strong> (dois checks brancos) — Mensagem entregue</li>
                <li><strong>✓✓</strong> (dois checks azuis) — Mensagem lida</li>
            </ul>

            <h3>Enviar mensagem</h3>
            <p>No painel direito (chat aberto), na parte inferior há um campo de texto para digitar sua mensagem e um botão de enviar. Pressione <strong>Enter</strong> para enviar ou clique no botão de envio.</p>

            <h3>Enviar arquivos</h3>
            <p>Clique no ícone de clipe (ou arraste um arquivo) para anexar documentos à mensagem. Tipos aceitos:</p>
            <ul>
                <li>Imagens: PNG, JPEG, GIF, WebP</li>
                <li>Documentos: PDF, Word (.doc/.docx), Excel (.xls/.xlsx), TXT</li>
            </ul>
            <p>Tamanho máximo: <strong>5 MB por arquivo</strong>.</p>

            <h3>Compor nova mensagem</h3>
            <p>Clique no botão <strong>"Compor"</strong> (ícone de lápis ou botão no topo) para iniciar uma nova conversa. No formulário de composição:</p>
            <ul>
                <li><strong>Destinatário:</strong> Escolha:
                    <ul>
                        <li><strong>Usuário:</strong> Mensagem individual para um usuário específico</li>
                        <li><strong>Grupo:</strong> Mensagem para um grupo de usuários (definido nos Grupos de Acesso)</li>
                        <li><strong>Todos:</strong> Mensagem transmitida para todos os usuários do sistema</li>
                    </ul>
                </li>
                <li><strong>Assunto:</strong> O assunto da mensagem (opcional, aparece destacado no balão).</li>
                <li><strong>Mensagem:</strong> O texto da mensagem. Campo obrigatório.</li>
                <li><strong>Anexos:</strong> Adicione arquivos se necessário.</li>
            </ul>
            <p>Clique em <strong>"Enviar"</strong> para enviar a mensagem.</p>

            <h3>Aba WhatsApp (GoTalk)</h3>
            <p>Se a integração GoTalk estiver configurada, a aba WhatsApp mostra as conversas dos clientes via WhatsApp. Você pode:</p>
            <ul>
                <li>Ver as conversas organizadas por contato/cliente</li>
                <li>Ler o histórico de mensagens trocadas</li>
                <li>Ver o nome do atendente que estava na conversa</li>
                <li>Filtrar por canal (número de WhatsApp) se a empresa tiver múltiplos números</li>
            </ul>

            <h3>Mensagens do sistema</h3>
            <p>O sistema envia alertas automáticos de diversas situações, como:</p>
            <ul>
                <li>Alertas de prazos jurídicos próximos do vencimento</li>
                <li>Notificações de auditoria (aprovações, retornos)</li>
                <li>Alertas de admissões aguardando ação</li>
            </ul>
            <p>Essas mensagens aparecem com o ícone de engrenagem e são identificadas como "Sistema".</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Verifique as mensagens não lidas diariamente para não perder alertas importantes</li>
                <li>Use o filtro "Não lidos" para encontrar rapidamente mensagens pendentes de leitura</li>
                <li>Mensagens do sistema contêm informações importantes — não as ignore</li>
                <li>Para comunicados para toda a equipe, use "Todos" como destinatário</li>
            </ul>
        `,
        keywords: ['mensagem', 'mensagens', 'chat', 'comunicação', 'inbox', 'conversa', 'grupo', 'sistema', 'WhatsApp', 'GoTalk', 'notificação', 'alerta', 'enviar', 'arquivo', 'anexo']
    },
    {
        id: 'settings_escala',
        menuPath: 'Configurações > Escala de Trabalho',
        title: 'Escala de Trabalho',
        summary: 'Gerenciamento das escalas de horário dos colaboradores por dia da semana, com visualização semanal, mensal e impressão.',
        content: `
            <img src="/help-screenshots/settings-escala.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>A Escala de Trabalho permite definir e visualizar os horários de trabalho de cada usuário do sistema por dia da semana. É útil para gestão de equipes, controle de folgas e planejamento de jornadas.</p>

            <h3>Seletor de escala</h3>
            <p>No topo da tela há um seletor com as escalas cadastradas. Selecione a escala que deseja visualizar ou editar. Para criar uma nova escala, clique em <strong>"Nova Escala"</strong>.</p>

            <h3>Modos de visualização</h3>
            <ul>
                <li><strong>Semana:</strong> Exibe a grade com os horários por dia da semana (Domingo a Sábado) para todos os usuários.</li>
                <li><strong>Mês:</strong> Exibe uma visualização mensal para acompanhar os dias trabalhados e folgas no mês selecionado.</li>
                <li><strong>Todos:</strong> Exibe todas as escalas de todos os períodos.</li>
            </ul>

            <h3>Filtros disponíveis</h3>
            <ul>
                <li><strong>Ano:</strong> Selecione o ano da escala.</li>
                <li><strong>Mês:</strong> Selecione o mês (relevante na visualização Mês).</li>
                <li><strong>Unidade:</strong> Filtre por filial para ver apenas os colaboradores de uma unidade específica.</li>
            </ul>

            <h3>Grade de horários (visualização Semana)</h3>
            <p>A grade mostra linhas (um colaborador/usuário por linha) e colunas (um dia da semana por coluna: Seg, Ter, Qua, Qui, Sex, Sáb, Dom).</p>
            <p>Para cada célula (usuário × dia), você pode configurar:</p>
            <ul>
                <li><strong>Folga:</strong> Marque o checkbox "Folga" para indicar que o colaborador não trabalha nesse dia. A célula fica destacada em laranja com o texto "FOLGA".</li>
                <li><strong>Horário de Início:</strong> A que horas o colaborador começa a trabalhar (ex: 08:00).</li>
                <li><strong>Horário de Término:</strong> A que horas o colaborador termina o trabalho (ex: 18:00).</li>
            </ul>
            <p>Se o dia estiver marcado como Folga, os campos de horário ficam ocultos.</p>

            <h3>Propriedades da escala</h3>
            <ul>
                <li><strong>Nome:</strong> Nome identificador da escala (ex: "Escala 2025", "Equipe Comercial").</li>
                <li><strong>Visibilidade:</strong>
                    <ul>
                        <li><strong>Pública:</strong> Todos os usuários podem ver a escala</li>
                        <li><strong>Privada:</strong> Apenas administradores podem ver a escala</li>
                    </ul>
                </li>
                <li><strong>Ativa:</strong> Se a escala está ativa e em vigor.</li>
                <li><strong>Ano:</strong> O ano de referência da escala.</li>
            </ul>

            <h3>Compartilhar escala</h3>
            <p>O botão <strong>"Compartilhar"</strong> abre um modal para selecionar quais grupos de acesso têm permissão de visualizar a escala.</p>

            <h3>Salvar alterações</h3>
            <p>Ao modificar os horários, o botão <strong>"Salvar"</strong> fica disponível. Clique nele (ou pressione Ctrl+S) para salvar todas as alterações da escala atual.</p>

            <h3>Imprimir</h3>
            <p>O botão <strong>"Imprimir"</strong> abre a janela de impressão do navegador para imprimir a escala atual. A grade é formatada para impressão.</p>

            <h3>Excluir escala</h3>
            <p>O botão <strong>"Excluir Escala"</strong> remove permanentemente a escala selecionada. Uma confirmação é solicitada antes de excluir.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Crie uma escala por ano ou por equipe, conforme a necessidade da empresa</li>
                <li>Use a visibilidade "Privada" para escalas que contêm informações sensíveis</li>
                <li>Defina os horários padrão da empresa e marque as folgas de cada colaborador</li>
                <li>Imprima a escala mensal e afixe no mural da empresa para comunicação interna</li>
                <li>Apenas administradores podem criar novas escalas — usuários comuns podem visualizar as públicas</li>
            </ul>
        `,
        keywords: ['escala', 'escala de trabalho', 'horário', 'jornada', 'folga', 'colaborador', 'dia da semana', 'turno', 'expediente', 'segunda, terça, quarta, quinta, sexta, sábado, domingo']
    },
    {
        id: 'settings_audit',
        menuPath: 'Configurações > Auditoria',
        title: 'Log de Auditoria (Configurações)',
        summary: 'Painel de visualização do log de auditoria do sistema, com registros de todas as ações realizadas pelos usuários, filtros avançados e detalhes das alterações.',
        content: `
            <img src="/help-screenshots/settings-audit.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>O Log de Auditoria (disponível em Configurações > Auditoria) registra automaticamente <strong>todas as ações importantes</strong> realizadas no sistema. É uma ferramenta de controle e segurança que permite rastrear quem fez o quê, quando e em qual registro.</p>

            <h3>O que é registrado</h3>
            <p>Toda vez que um usuário cria, edita ou exclui um registro no sistema, um log de auditoria é gerado automaticamente. Os registros incluem:</p>
            <ul>
                <li>Criação de clientes, colaboradores, admissões</li>
                <li>Alterações em configurações do sistema</li>
                <li>Aprovações e reprovações na auditoria</li>
                <li>Baixas financeiras e movimentações bancárias</li>
                <li>Inclusão, alteração e exclusão de usuários e grupos</li>
                <li>Cadastro e atualização de processos jurídicos</li>
                <li>Alterações de escalas de trabalho</li>
                <li>Qualquer outra ação relevante para conformidade</li>
            </ul>

            <h3>Tabela de logs</h3>
            <p>A tabela exibe os registros de auditoria com as colunas:</p>
            <ul>
                <li><strong>Data/Hora:</strong> Quando a ação foi realizada (data e hora exatas).</li>
                <li><strong>Usuário:</strong> Quem realizou a ação (nome e e-mail do usuário logado).</li>
                <li><strong>Entidade:</strong> Qual área ou tipo de registro foi afetado (ex: CLIENTE, ADMISSAO, CARGO, DEPARTAMENTO, PROCESSO_JURIDICO, USUARIO).</li>
                <li><strong>Tipo:</strong> Que tipo de ação foi realizada:
                    <ul>
                        <li><strong>INSERT / INCLUIR:</strong> Um novo registro foi criado</li>
                        <li><strong>UPDATE / ALTERAR:</strong> Um registro existente foi modificado</li>
                        <li><strong>DELETE / EXCLUIR:</strong> Um registro foi removido</li>
                    </ul>
                </li>
                <li><strong>Identificador:</strong> O ID do registro afetado.</li>
                <li><strong>Detalhes:</strong> Botão para ver o "diff" (diferença) completo, mostrando os valores antes e depois da alteração.</li>
            </ul>

            <h3>Filtros disponíveis</h3>
            <ul>
                <li><strong>Período (De / Até):</strong> Filtre os logs por intervalo de datas.</li>
                <li><strong>Usuário:</strong> Veja apenas as ações de um usuário específico.</li>
                <li><strong>Entidade:</strong> Filtre por tipo de registro (ex: mostrar apenas alterações em CLIENTES).</li>
                <li><strong>Tipo de Ação:</strong> Filtre por INSERT, UPDATE ou DELETE.</li>
            </ul>

            <h3>Detalhes da alteração (Diff)</h3>
            <p>Ao clicar em "Detalhes" em um log de tipo UPDATE, o sistema mostra lado a lado os valores <strong>antes</strong> e <strong>depois</strong> da alteração. Isso permite saber exatamente o que mudou em um registro — por exemplo, qual campo foi modificado, o valor antigo e o novo valor.</p>

            <h3>Botão de auditoria nos registros</h3>
            <p>Além desta tela centralizada, muitos cadastros do sistema possuem um botão de auditoria (ícone de relógio) na grade de listagem. Clicando nele, você vê o histórico de alterações específico daquele registro, sem precisar vir à tela de Configurações.</p>

            <h3>Importância da auditoria</h3>
            <p>O log de auditoria é fundamental para:</p>
            <ul>
                <li>Detectar e investigar alterações indevidas</li>
                <li>Cumprir requisitos de conformidade regulatória</li>
                <li>Resolver disputas sobre dados ("quem alterou isso?")</li>
                <li>Rastrear o histórico completo de um registro importante</li>
            </ul>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Consulte o log regularmente para monitorar as ações da equipe</li>
                <li>Em caso de dados incorretos em um registro, verifique o log para saber quando e quem fez a alteração</li>
                <li>O log não pode ser editado ou excluído — é um registro imutável para garantir a integridade</li>
                <li>Apenas administradores têm acesso ao log de auditoria completo em Configurações</li>
            </ul>
        `,
        keywords: ['auditoria', 'log', 'histórico', 'ações', 'rastreamento', 'conformidade', 'compliance', 'alteração', 'exclusão', 'registro', 'usuário', 'INSERT', 'UPDATE', 'DELETE', 'diff']
    },
    {
        id: 'settings_gotalk',
        menuPath: 'Configurações > Mensagens GoTalk',
        title: 'Mensagens GoTalk (Configurações)',
        summary: 'Painel de gerenciamento e visualização de todas as mensagens WhatsApp trocadas via integração GoTalk, com filtros avançados, detalhes de mensagem, canais e chatbot.',
        content: `
            <img src="/help-screenshots/settings-gotalk.jpg" alt="" style="width:100%;max-width:860px;border-radius:8px;border:1px solid #e5e7eb;margin:12px 0 20px 0;box-shadow:0 2px 8px rgba(0,0,0,0.08);display:block;" />

            <h3>Visão geral</h3>
            <p>A tela de Mensagens GoTalk (em Configurações) oferece um painel administrativo completo para gerenciar a integração do FinancePro com o serviço GoTalk de WhatsApp Business. Aqui você visualiza, filtra e analisa todas as mensagens trocadas com clientes via WhatsApp.</p>

            <h3>Abas da tela</h3>
            <ul>
                <li><strong>Mensagens:</strong> Tabela completa com todas as mensagens registradas (enviadas e recebidas).</li>
                <li><strong>Canais:</strong> Gerenciamento dos canais de WhatsApp conectados (números de telefone).</li>
                <li><strong>Chatbot:</strong> Visualização e configuração dos menus do chatbot automático do GoTalk.</li>
            </ul>

            <h3>Aba "Mensagens" — Tabela de mensagens</h3>
            <p>A tabela lista todas as mensagens com as colunas:</p>
            <ul>
                <li><strong>Telefone:</strong> O número de WhatsApp do contato (cliente ou atendente externo).</li>
                <li><strong>Contato / Cliente:</strong> Nome do contato (se identificado) e nome do cliente no FinancePro (se vinculado).</li>
                <li><strong>Direção:</strong> Indica o fluxo da mensagem:
                    <ul>
                        <li><span style="background:#d1fae5;padding:2px 6px;border-radius:4px;color:#065f46">⬇ Entrada</span> — Mensagem recebida do cliente</li>
                        <li><span style="background:#fed7aa;padding:2px 6px;border-radius:4px;color:#9a3412">⬆ Saída</span> — Mensagem enviada para o cliente</li>
                    </ul>
                </li>
                <li><strong>Tipo:</strong> Formato da mensagem com badges coloridos:
                    <ul>
                        <li>💬 <strong>Texto:</strong> Mensagem de texto simples</li>
                        <li>🖼️ <strong>Imagem:</strong> Foto ou imagem</li>
                        <li>🎵 <strong>Áudio:</strong> Áudio ou nota de voz</li>
                        <li>🎬 <strong>Vídeo:</strong> Arquivo de vídeo</li>
                        <li>📄 <strong>Documento:</strong> Arquivo PDF, Word, Excel, etc.</li>
                        <li>📋 <strong>Template:</strong> Mensagem HSM (template de WhatsApp Business)</li>
                        <li>😊 <strong>Sticker:</strong> Figurinha/emoji animado</li>
                    </ul>
                </li>
                <li><strong>Conteúdo:</strong> Trecho do texto da mensagem. Clique para ver o conteúdo completo.</li>
                <li><strong>Operador:</strong> Nome do atendente que enviou ou recebeu a mensagem.</li>
                <li><strong>Departamento:</strong> Departamento do GoTalk associado.</li>
                <li><strong>Data/Hora:</strong> Quando a mensagem foi enviada/recebida.</li>
                <li><strong>Lida em:</strong> Quando a mensagem foi marcada como lida (se disponível).</li>
                <li><strong>Ações:</strong> Botão para ver os detalhes completos da mensagem.</li>
            </ul>

            <h3>Filtros de mensagens</h3>
            <ul>
                <li><strong>Canal:</strong> Filtre por número de WhatsApp (se a empresa tiver múltiplos canais).</li>
                <li><strong>Direção:</strong> Filtre por Entrada (IN) ou Saída (OUT).</li>
                <li><strong>Tipo:</strong> Filtre por tipo de mensagem (Texto, Imagem, Áudio, etc.).</li>
                <li><strong>Operador:</strong> Filtre pelas mensagens de um operador específico.</li>
                <li><strong>Período (De / Até):</strong> Filtre por intervalo de datas.</li>
                <li><strong>Busca por telefone:</strong> Digite um número para ver apenas as mensagens daquele contato.</li>
            </ul>

            <h3>Detalhes da mensagem</h3>
            <p>Ao clicar em uma mensagem, um painel de detalhes exibe:</p>
            <ul>
                <li>Informações completas do contato (telefone, nome, cliente vinculado)</li>
                <li>Conteúdo completo da mensagem</li>
                <li>Para mensagens com mídia: preview da imagem/vídeo ou link para download do arquivo</li>
                <li>Para áudios: transcrição automática (quando disponível)</li>
                <li>Para templates: corpo, cabeçalho, rodapé e categoria do template</li>
                <li>Status de leitura (se disponível via API)</li>
            </ul>

            <h3>Aba "Canais"</h3>
            <p>Exibe os canais de WhatsApp configurados na conta GoTalk, com:</p>
            <ul>
                <li><strong>Nome do Canal:</strong> Identificador do canal (ex: "WhatsApp Principal", "Suporte").</li>
                <li><strong>Número:</strong> O número de telefone do WhatsApp Business.</li>
                <li><strong>Unidade:</strong> A unidade/filial da empresa associada ao canal.</li>
                <li><strong>Canal Principal:</strong> Indica se é o canal padrão.</li>
                <li><strong>Status:</strong> Se o canal está ativo.</li>
            </ul>

            <h3>Aba "Chatbot"</h3>
            <p>Exibe a estrutura de menus do chatbot automático configurado no GoTalk. Permite visualizar os fluxos de atendimento automático, incluindo as opções de menu que os clientes recebem ao entrar em contato pelo WhatsApp.</p>

            <h3>Dicas úteis</h3>
            <ul>
                <li>Use o filtro de "Entrada" + período para monitorar os contatos recebidos no dia</li>
                <li>Vincule os contatos a clientes no sistema para ter rastreabilidade completa</li>
                <li>Verifique regularmente as mensagens sem leitura para garantir tempo de resposta adequado</li>
                <li>A transcrição de áudios facilita o trabalho quando não é possível ouvir as mensagens</li>
            </ul>
        `,
        keywords: ['GoTalk', 'WhatsApp', 'mensagem', 'mensagens', 'canal', 'chatbot', 'template', 'HSM', 'operador', 'atendimento', 'entrada', 'saída', 'áudio', 'imagem', 'documento']
    }

];
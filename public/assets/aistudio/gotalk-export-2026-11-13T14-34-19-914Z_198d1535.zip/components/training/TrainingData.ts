export interface TrainingStep {
    id: string;
    title: string;
    content: string;
    leoMessage: string;
    tipText?: string;
    screenshot?: string;
}

export interface TrainingModule {
    id: string;
    title: string;
    description: string;
    icon: string;
    category: string;
    defaultScreenshot: string;
    steps: TrainingStep[];
}

export const TRAINING_MODULES: TrainingModule[] = [
    {
        id: 'primeiros-passos',
        title: 'Primeiros Passos',
        description: 'Aprenda o básico para começar a usar o FinancePro com confiança.',
        icon: '🚀',
        category: 'Início',
        defaultScreenshot: 'login.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'Acessando o Sistema',
                content: '<p>Para acessar o FinancePro, digite seu <strong>e-mail corporativo</strong> e sua <strong>senha</strong> nos campos da tela de login.</p><p>Na primeira vez, use a senha provisória fornecida pelo administrador.</p><p>Você também precisará resolver um <strong>captcha matemático</strong> simples para confirmar que não é um robô.</p>',
                leoMessage: 'Olá! Eu sou o Léo, seu guia no FinancePro! Vamos começar pelo básico: como entrar no sistema. É bem simples, você vai ver!',
                tipText: 'Nunca compartilhe sua senha com outras pessoas!',
                screenshot: 'login.jpg'
            },
            {
                id: 'step-2',
                title: 'Primeiro Acesso e Troca de Senha',
                content: '<p>Se esta é a primeira vez que você entra, o sistema vai pedir para você criar uma <strong>nova senha</strong>.</p><p>A senha precisa ter:</p><ul><li>Pelo menos <strong>8 caracteres</strong></li><li>Uma <strong>letra maiúscula</strong></li><li>Um <strong>número</strong></li><li>Um <strong>caractere especial</strong> (ex: @, #, $, !)</li></ul><p>Exemplo de senha válida: <strong>MinhaSenh@123</strong></p>',
                leoMessage: 'Esse é um passo importante! Criar uma senha forte protege você e toda a empresa. Capricha na escolha, hein!',
                tipText: 'Anote sua senha em um lugar seguro na primeira vez que criar.',
                screenshot: 'login.jpg'
            },
            {
                id: 'step-3',
                title: 'Conhecendo o Cabeçalho',
                content: '<p>O cabeçalho fica na parte superior da tela e mostra informações úteis:</p><ul><li><strong>Nome da empresa</strong> no canto esquerdo</li><li><strong>Relógio</strong> com data e hora por extenso</li><li><strong>Seu nome e e-mail</strong> para identificação</li><li><strong>Botão SAIR</strong> (vermelho) para encerrar a sessão com segurança</li></ul>',
                leoMessage: 'Olha que bacana o cabeçalho! Ele sempre mostra quem você é e a data atual. Bem prático, né?',
                tipText: undefined,
                screenshot: 'home.jpg'
            },
            {
                id: 'step-4',
                title: 'Navegando pelo Menu Lateral',
                content: '<p>No lado esquerdo da tela existe o <strong>menu lateral (sidebar)</strong> com todas as opções do sistema.</p><p>Clique em cada item para acessar a funcionalidade. Alguns itens possuem <strong>submenus</strong> que se expandem ao clicar.</p><p>Você pode <strong>recolher o menu</strong> clicando no ícone de menu para ter mais espaço na tela principal.</p>',
                leoMessage: 'O menu lateral é seu mapa do tesouro! Tudo que o sistema oferece está organizado ali. Explore sem medo!',
                tipText: 'Recolha o menu lateral para ganhar mais espaço na tela quando precisar.',
                screenshot: 'home.jpg'
            },
            {
                id: 'step-5',
                title: 'Bloqueio de Conta',
                content: '<p>Para proteger sua conta, se você errar a senha <strong>3 vezes seguidas</strong>, a conta será <strong>bloqueada automaticamente</strong>.</p><p>Quando isso acontece:</p><ul><li>Você verá uma mensagem informando o bloqueio</li><li>Somente o <strong>administrador</strong> pode desbloquear</li><li>Entre em contato com o administrador para solicitar o desbloqueio</li></ul>',
                leoMessage: 'Calma, não se preocupe! Errar a senha acontece com todo mundo. Se sua conta bloquear, é só falar com o administrador que ele resolve rapidinho!',
                tipText: 'Se esqueceu sua senha, peça ao administrador para redefinir antes de tentar muitas vezes.',
                screenshot: 'login.jpg'
            },
            {
                id: 'step-6',
                title: 'Saindo do Sistema com Segurança',
                content: '<p>Quando terminar de usar o FinancePro, <strong>sempre clique no botão SAIR</strong> (vermelho) no cabeçalho.</p><p>Isso encerra sua sessão de forma segura, impedindo que outras pessoas acessem sua conta.</p><p><strong>Nunca</strong> apenas feche o navegador sem clicar em Sair.</p>',
                leoMessage: 'Vamos lá! Sair direitinho do sistema é tão importante quanto entrar. Um clique no botão vermelho e pronto, tudo seguro!',
                tipText: 'Sempre clique em SAIR ao terminar, especialmente em computadores compartilhados.',
                screenshot: 'home.jpg'
            }
        ]
    },
    {
        id: 'agenda',
        title: 'Agenda e Compromissos',
        description: 'Domine a agenda do sistema para organizar seus atendimentos e compromissos.',
        icon: '📅',
        category: 'Início',
        defaultScreenshot: 'agenda.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'Visão Geral da Agenda',
                content: '<p>A <strong>Agenda</strong> é onde você gerencia todos os atendimentos e compromissos da empresa.</p><p>Ela possui 5 abas:</p><ul><li><strong>Agenda:</strong> Visão principal do calendário</li><li><strong>Serviços:</strong> Cadastro dos serviços oferecidos</li><li><strong>Bloqueio:</strong> Horários bloqueados (férias, feriados)</li><li><strong>Fila de Espera:</strong> Clientes aguardando vaga</li><li><strong>Configuração:</strong> Ajustes de horários e intervalos</li></ul>',
                leoMessage: 'A Agenda é uma das ferramentas mais usadas do sistema! Vou te mostrar como aproveitar tudo que ela oferece. Vamos lá!',
                tipText: undefined
            },
            {
                id: 'step-2',
                title: 'Visualizando o Calendário',
                content: '<p>A aba Agenda oferece duas formas de visualização:</p><ul><li><strong>Visão Diária:</strong> Mostra todos os horários de um único dia</li><li><strong>Visão Semanal:</strong> Mostra a semana inteira de uma vez</li></ul><p>Use o <strong>mini calendário</strong> lateral para navegar rapidamente entre as datas clicando no dia desejado.</p>',
                leoMessage: 'Escolha a visão que funciona melhor pra você! Eu gosto da visão semanal pra ter uma ideia geral, e a diária quando preciso dos detalhes.',
                tipText: 'Clique em qualquer data no mini calendário para pular direto para aquele dia.'
            },
            {
                id: 'step-3',
                title: 'Criando um Agendamento',
                content: '<p>Para criar um novo agendamento, clique em um <strong>horário vazio</strong> no calendário ou use o botão de novo agendamento.</p><p>Preencha os campos:</p><ul><li><strong>Cliente:</strong> Selecione quem será atendido</li><li><strong>Colaborador:</strong> Quem vai realizar o atendimento</li><li><strong>Serviço:</strong> Tipo de serviço (a duração é preenchida automaticamente)</li><li><strong>Data e Horário:</strong> Quando será o atendimento</li><li><strong>Observações:</strong> Anotações adicionais</li></ul>',
                leoMessage: 'Criar agendamento é muito fácil! Basta clicar no horário e preencher os dados. O sistema já calcula a duração pra você. Prático, né?',
                tipText: 'A duração do atendimento é preenchida automaticamente com base no serviço selecionado.'
            },
            {
                id: 'step-4',
                title: 'Editando e Movendo Agendamentos',
                content: '<p>Para <strong>editar</strong> um agendamento existente, basta clicar sobre ele no calendário.</p><p>Você pode alterar qualquer campo: cliente, colaborador, serviço, horário ou observações.</p><p>Também é possível <strong>arrastar e soltar</strong> um agendamento para movê-lo de um horário para outro diretamente no calendário.</p>',
                leoMessage: 'Mudou o horário? Sem problema! Arrasta e solta que o sistema cuida do resto. Muito bem!',
                tipText: undefined
            },
            {
                id: 'step-5',
                title: 'Cores e Identificação Visual',
                content: '<p>Cada <strong>serviço</strong> cadastrado pode ter uma <strong>cor específica</strong>, facilitando a identificação visual no calendário.</p><p>Ao cadastrar ou editar um serviço na aba Serviços, você pode escolher a cor que será usada para destacar os agendamentos daquele tipo.</p><p>Isso permite que você identifique rapidamente o tipo de atendimento apenas olhando para o calendário.</p>',
                leoMessage: 'As cores são suas melhores amigas na agenda! Com elas, você bate o olho e já sabe que tipo de atendimento é cada um. Agora ficou fácil, né?',
                tipText: 'Use cores distintas para cada serviço para facilitar a leitura visual da agenda.'
            },
            {
                id: 'step-6',
                title: 'Bloqueios e Fila de Espera',
                content: '<p>Na aba <strong>Bloqueio</strong>, você pode impedir agendamentos em determinados horários. Útil para férias, feriados, horário de almoço e reuniões internas.</p><p>Na aba <strong>Fila de Espera</strong>, quando não há horário disponível, coloque o cliente na fila. Quando surgir uma vaga, mova o cliente para o calendário.</p>',
                leoMessage: 'Bloqueios evitam confusão e a fila de espera garante que ninguém fique sem atendimento. O sistema pensa em tudo!',
                tipText: 'Configure bloqueios recorrentes para horários fixos, como almoço, para não precisar bloquear todo dia.'
            }
        ]
    },
    {
        id: 'cadastro-clientes',
        title: 'Cadastro de Clientes',
        description: 'Aprenda a cadastrar e gerenciar todos os clientes da empresa.',
        icon: '👥',
        category: 'Cadastros',
        defaultScreenshot: 'cad-clientes.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'Visão Geral do Cadastro',
                content: '<p>O <strong>Cadastro de Clientes</strong> é onde você registra todas as informações dos clientes da empresa.</p><p>Cada cliente cadastrado pode ser usado nas <strong>admissões</strong>, <strong>negociações</strong> e no <strong>financeiro</strong>.</p><p>A tela principal mostra uma tabela com todos os clientes, onde você pode pesquisar, ordenar e paginar os resultados.</p>',
                leoMessage: 'Vamos conhecer o cadastro de clientes! É aqui que tudo começa. Um bom cadastro facilita todo o trabalho depois. Vamos lá!',
                tipText: undefined
            },
            {
                id: 'step-2',
                title: 'Criando um Novo Cliente',
                content: '<p>Clique no botão <strong>Novo Cliente</strong> para abrir o formulário de cadastro.</p><p>Os campos obrigatórios são:</p><ul><li><strong>Nome:</strong> Nome completo (pessoa física) ou Razão Social (pessoa jurídica)</li><li><strong>Tipo de Pessoa:</strong> Pessoa Física (CPF) ou Pessoa Jurídica (CNPJ)</li><li><strong>CPF/CNPJ:</strong> O sistema valida automaticamente se o número é válido</li></ul><p>Preencha também telefone, e-mail e endereço para ter um cadastro completo.</p>',
                leoMessage: 'Hora de cadastrar! Presta atenção nos campos obrigatórios: nome, tipo de pessoa e CPF ou CNPJ. O resto complementa, mas esses três são essenciais!',
                tipText: 'O sistema valida automaticamente o CPF/CNPJ. Se aparecer erro, verifique se digitou corretamente.'
            },
            {
                id: 'step-3',
                title: 'Campos de Endereço e CEP Automático',
                content: '<p>Na seção de endereço, digite o <strong>CEP</strong> e os campos serão preenchidos automaticamente:</p><ul><li>Logradouro (rua, avenida)</li><li>Bairro</li><li>Cidade</li><li>Estado</li></ul><p>Você só precisa completar o <strong>número</strong> e o <strong>complemento</strong> (apto, bloco, sala).</p><p>Caso o CEP não seja encontrado, preencha manualmente.</p>',
                leoMessage: 'Essa é uma dica de ouro: digita o CEP e deixa o sistema fazer o trabalho pesado! Só falta colocar o número e pronto!',
                tipText: 'Use o preenchimento automático pelo CEP para ganhar tempo e evitar erros de digitação.'
            },
            {
                id: 'step-4',
                title: 'Pesquisando Clientes',
                content: '<p>Na tela principal do cadastro, use o <strong>campo de busca</strong> para encontrar clientes rapidamente.</p><p>Você pode pesquisar por:</p><ul><li><strong>Nome</strong> do cliente</li><li><strong>CPF/CNPJ</strong></li><li><strong>E-mail</strong></li></ul><p>Clique no <strong>cabeçalho de qualquer coluna</strong> para ordenar os dados em ordem crescente (A-Z) ou decrescente (Z-A).</p>',
                leoMessage: 'Com milhares de clientes, a busca é sua melhor amiga! Digita parte do nome ou documento e o sistema encontra rapidinho.',
                tipText: 'Você pode ordenar por qualquer coluna clicando no cabeçalho dela.'
            },
            {
                id: 'step-5',
                title: 'Editando um Cliente',
                content: '<p>Para editar os dados de um cliente, <strong>clique sobre o nome dele</strong> na listagem.</p><p>O formulário será aberto com todos os dados preenchidos. Altere o que for necessário e clique em <strong>Salvar</strong>.</p><p>Todas as alterações ficam registradas no <strong>log de auditoria</strong> do sistema.</p>',
                leoMessage: 'Mudou o telefone? Trocou de endereço? Sem problema! Editar é super simples. E o melhor: tudo fica registrado no histórico!',
                tipText: 'Mantenha os dados dos clientes sempre atualizados para facilitar o contato.'
            },
            {
                id: 'step-6',
                title: 'Excluindo um Cliente',
                content: '<p>Para excluir um cliente, selecione-o na listagem e clique no botão de <strong>exclusão</strong>.</p><p>O sistema pedirá uma <strong>confirmação</strong> antes de excluir definitivamente.</p><p><strong>Atenção:</strong> A exclusão é permanente. Se o cliente possui admissões ou negociações vinculadas, considere manter o cadastro e apenas atualizar os dados.</p>',
                leoMessage: 'Cuidado com a exclusão! Ela é definitiva. Na dúvida, é melhor manter o cadastro do que apagar. Prevenir é sempre melhor, né?',
                tipText: 'Antes de excluir, verifique se o cliente não possui admissões ou negociações vinculadas.'
            }
        ]
    },
    {
        id: 'cadastro-bancos',
        title: 'Cadastro de Bancos',
        description: 'Saiba como cadastrar bancos e configurar percentuais de negociação.',
        icon: '🏦',
        category: 'Cadastros',
        defaultScreenshot: 'cad-bancos.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'Para que Serve o Cadastro de Bancos',
                content: '<p>O <strong>Cadastro de Bancos</strong> registra todos os bancos e instituições financeiras com as quais a empresa trabalha nas negociações de dívidas.</p><p>Esses bancos são usados diretamente nas <strong>admissões de clientes</strong>, onde você seleciona de qual banco vem a dívida.</p>',
                leoMessage: 'Os bancos são peça-chave no FinancePro! Sem eles cadastrados, não dá pra criar admissões. Vamos configurar direitinho!',
                tipText: undefined
            },
            {
                id: 'step-2',
                title: 'Adicionando um Novo Banco',
                content: '<p>Clique em <strong>Novo Banco</strong> e preencha:</p><ul><li><strong>Nome:</strong> Nome completo da instituição (ex: BANCO DO BRASIL S.A.)</li><li><strong>Código FEBRABAN:</strong> Código oficial no sistema bancário (ex: 001 para BB, 104 para Caixa)</li><li><strong>Status:</strong> Ativo ou Inativo</li><li><strong>Observações:</strong> Informações como políticas de desconto e contatos</li></ul>',
                leoMessage: 'Muito bem! Ao cadastrar um banco, não esqueça do código FEBRABAN. É o código oficial que identifica o banco no sistema bancário brasileiro.',
                tipText: 'Use o campo de observações para anotar contatos e regras específicas de cada banco.'
            },
            {
                id: 'step-3',
                title: 'Configurando Serviços e Percentuais',
                content: '<p>Dentro de cada banco, existe uma tabela de <strong>Serviços</strong> que detalha os tipos de negociação aceitos:</p><ul><li><strong>Descrição do Serviço:</strong> Nome do serviço (ex: CDC Veículos)</li><li><strong>Tipo e Modalidade:</strong> Classificação da negociação</li><li><strong>Percentual de Negociação:</strong> Percentual típico de desconto ou taxa (ex: 25,5%)</li></ul><p>Esse percentual é usado nos <strong>cálculos de recálculo</strong> da admissão.</p>',
                leoMessage: 'Esse é um passo importante! O percentual de negociação que você coloca aqui vai ser usado nos recálculos da admissão. Então capriche na precisão!',
                tipText: 'Mantenha os percentuais de negociação atualizados conforme as políticas dos bancos mudam.'
            },
            {
                id: 'step-4',
                title: 'Editando e Gerenciando Bancos',
                content: '<p>Para editar um banco, clique sobre ele na listagem. Você pode alterar todos os campos e também adicionar ou remover serviços.</p><p>Bancos que não são mais utilizados devem ser <strong>desativados</strong> (Status: Inativo) em vez de excluídos, pois podem estar vinculados a admissões existentes.</p>',
                leoMessage: 'Se um banco não é mais usado, desative em vez de excluir! Assim você mantém o histórico das admissões antigas. Esperto, né?',
                tipText: 'Desative bancos que não são mais utilizados em vez de excluí-los para preservar o histórico.'
            },
            {
                id: 'step-5',
                title: 'Importância nas Admissões',
                content: '<p>Quando você cria uma <strong>admissão</strong>, seleciona o banco de onde vem a dívida do cliente.</p><p>Os serviços e percentuais cadastrados aqui são utilizados automaticamente para calcular os <strong>cenários de recálculo</strong>, mostrando quanto o cliente pode economizar.</p><p>Um cadastro de banco bem feito resulta em cálculos mais precisos e propostas melhores para o cliente.</p>',
                leoMessage: 'Agora você entende por que o cadastro de bancos é tão importante! Ele alimenta todo o processo de admissão. Um cadastro bem feito = propostas melhores!',
                tipText: 'Revise periodicamente os serviços e percentuais para garantir que estão atualizados.'
            }
        ]
    },
    {
        id: 'admissao',
        title: 'Admissão de Contratos',
        description: 'Domine o processo completo de admissão de contratos no sistema.',
        icon: '📋',
        category: 'Comercial',
        defaultScreenshot: 'admissao.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'O que é uma Admissão',
                content: '<p>A <strong>Ficha de Admissão</strong> é o registro central de um contrato de dívida que o cliente deseja renegociar. Ela reúne em um único lugar todas as informações necessárias para a análise, negociação, aprovação e auditoria do caso.</p><p>A ficha passa por um ciclo completo:</p><ol><li>Preenchimento pelo setor <strong>Comercial</strong></li><li>Aprovação pelo próprio setor Comercial</li><li>Revisão pelo setor de <strong>Auditoria</strong></li><li>Conclusão após aprovação final</li></ol><p>Cada etapa tem regras específicas de quem pode editar e o que pode ser alterado. Vamos conhecer cada campo e cada regra!</p>',
                leoMessage: 'A ficha de admissão é o documento mais importante do FinancePro! Ela acompanha o cliente do início ao fim do processo. Vamos entender cada detalhe com calma!',
                tipText: undefined
            },
            {
                id: 'step-2',
                title: 'Seção 01 — Dados do Cliente',
                content: '<p>A primeira seção da ficha registra quem é o cliente e como ele chegou até a empresa:</p><ul><li><strong>Responsável (cliente principal):</strong> Nome do titular da dívida — precisa estar cadastrado no sistema</li><li><strong>Tipo de Cliente:</strong> Define se o cliente é o próprio titular da dívida (<em>Titular</em>) ou um responsável legal (<em>Responsável</em>)</li><li><strong>Titular:</strong> Campo adicional que aparece quando o tipo for "Responsável" — identifica o dono real da dívida</li><li><strong>Tipo de Indicação:</strong> Como o cliente chegou à empresa (ex: indicação, publicidade, parceiro)</li><li><strong>Unidade de Origem:</strong> Qual unidade/filial da empresa está gerando esta ficha — é desta unidade que virá a <strong>Taxa Administrativa</strong></li><li><strong>Colaborador responsável:</strong> Quem está realizando o atendimento</li></ul>',
                leoMessage: 'Presta atenção na Unidade de Origem! É dela que o sistema vai buscar a Taxa Administrativa automaticamente. Certifique-se de selecionar a unidade correta desde o início!',
                tipText: 'O cliente e o titular precisam estar cadastrados antes de criar a admissão. Verifique no Cadastro de Clientes se ainda não existirem.'
            },
            {
                id: 'step-3',
                title: 'Seção 02 — Identificação do Contrato',
                content: '<p>Esta seção identifica o contrato junto ao banco:</p><ul><li><strong>Banco:</strong> Instituição financeira credora — vincula os serviços e percentuais de negociação cadastrados</li><li><strong>Modalidade:</strong> Tipo do contrato (ex: CDC Veículos, Cartão de Crédito, Consignado). A modalidade define quais campos adicionais aparecerão na ficha</li><li><strong>Série:</strong> Série para numeração automática do documento interno</li><li><strong>Número do Contrato:</strong> Número original do contrato junto ao banco — pode ser gerado automaticamente pela série ou informado manualmente</li><li><strong>Tipo de Pagamento:</strong> Forma como o cliente pagará as novas parcelas (ex: boleto, débito automático)</li><li><strong>Data da 1ª Parcela:</strong> Data de vencimento da primeira nova parcela após a renegociação</li></ul>',
                leoMessage: 'O banco e a modalidade são a base de tudo! Eles determinam os percentuais de desconto e os campos que aparecerão na ficha. Escolha com atenção!',
                tipText: 'Confira se o banco selecionado tem os serviços e percentuais cadastrados corretamente antes de prosseguir.'
            },
            {
                id: 'step-4',
                title: 'Seção 03 — Parcelas e Valores do Contrato Original',
                content: '<p>Aqui você registra a situação atual do contrato que será renegociado:</p><ul><li><strong>Total de Parcelas:</strong> Quantas parcelas o contrato original tem no total</li><li><strong>Parcelas Pagas:</strong> Quantas já foram quitadas pelo cliente</li><li><strong>Parcelas em Atraso:</strong> Quantas estão vencidas e não pagas</li><li><strong>Valor Financiado:</strong> Valor total do financiamento original</li><li><strong>Valor da Parcela:</strong> Valor mensal do contrato original</li><li><strong>Dia de Vencimento:</strong> Dia do mês em que as parcelas vencem</li></ul><p>Esses valores alimentam diretamente os <strong>Cenários de Recálculo</strong>. Quanto mais precisos, mais realistas serão as simulações apresentadas ao cliente.</p>',
                leoMessage: 'Esses números são a base dos cálculos! Confira no extrato ou contrato do cliente antes de digitar. Um dado errado aqui compromete todo o recálculo.',
                tipText: 'Solicite ao cliente o extrato atualizado do contrato para preencher esses campos com precisão.'
            },
            {
                id: 'step-5',
                title: 'Seção 04 — Dados do Veículo (quando aplicável)',
                content: '<p>Quando a modalidade selecionada for do tipo <strong>Veículos</strong>, campos adicionais surgirão automaticamente na ficha:</p><ul><li><strong>Marca:</strong> Fabricante do veículo (ex: Toyota, Ford)</li><li><strong>Modelo:</strong> Modelo específico (ex: Corolla, Fiesta)</li><li><strong>Cor:</strong> Cor do veículo conforme CRLV</li><li><strong>Ano:</strong> Ano de fabricação/modelo</li><li><strong>Placa:</strong> Placa de emplacamento</li><li><strong>Chassi:</strong> Número do chassi (17 dígitos)</li><li><strong>RENAVAM:</strong> Registro Nacional de Veículos Automotores</li><li><strong>Veículo Elétrico:</strong> Marque esta opção se o veículo for elétrico</li></ul><p><strong>Atenção:</strong> Veículos elétricos acionam um alerta especial no setor de Auditoria referente ao <em>Risco de GPS</em>, que será verificado durante a revisão.</p>',
                leoMessage: 'Chassis e RENAVAM são essenciais para veículos! Encontre esses dados no CRLV do cliente. E cuidado: veículo elétrico gera alerta automático na auditoria!',
                tipText: 'O RENAVAM fica no CRLV (documento do veículo). O chassi também pode ser encontrado no painel do carro ou na porta do motorista.'
            },
            {
                id: 'step-6',
                title: 'Seção 05 — Taxa Administrativa e Valores Financeiros',
                content: '<p>Esta seção registra os valores que a empresa vai cobrar pelo serviço de renegociação:</p><ul><li><strong>Taxa Administrativa (Entrada):</strong> Valor cobrado pela empresa como honorário inicial. Este valor é gerado automaticamente com base nas configurações da <strong>unidade que originou a ficha</strong> — não é informado manualmente</li><li><strong>Valor da 1ª Parcela:</strong> Valor da primeira parcela do novo contrato renegociado</li><li><strong>Valor dos Boletos (Taxa de Cobrança):</strong> Valor mensal de boletos administrativos cobrados ao cliente durante o processo</li><li><strong>Desconto:</strong> Eventual desconto aplicado sobre os honorários</li><li><strong>Acréscimo:</strong> Eventuais cobranças adicionais</li><li><strong>Observações 1 e 2:</strong> Campos livres para anotações internas relevantes ao caso</li></ul><p>Os campos de entrada e 1ª parcela geram lançamentos automáticos no módulo <strong>Contas a Receber</strong> quando a auditoria finaliza o processo.</p>',
                leoMessage: 'A Taxa Administrativa vem automaticamente da unidade que gerou a ficha! Não precisa calcular manualmente. Verifique nas configurações da unidade se o valor está correto.',
                tipText: 'Confirme com a gestão da sua unidade qual é a Taxa Administrativa vigente antes de aprovar a ficha.'
            },
            {
                id: 'step-7',
                title: 'Seção 06 — Cenários de Recálculo',
                content: '<p>Os cenários de recálculo são simulações de como ficará a dívida após a renegociação. O sistema permite criar <strong>até 3 cenários</strong> para oferecer opções ao cliente.</p><p>Cada cenário contém:</p><ul><li><strong>Rótulo:</strong> Nome do cenário (ex: "Opção 1 — Quitação")</li><li><strong>Parcelas a Pagar:</strong> Nova quantidade de parcelas propostas</li><li><strong>Dívida Original:</strong> Valor da dívida antes da negociação</li><li><strong>Nova Dívida:</strong> Valor após aplicação dos descontos</li><li><strong>Novo Valor da Parcela:</strong> Quanto o cliente pagará por mês</li><li><strong>Economia Gerada:</strong> Diferença entre a dívida original e a nova — o argumento de venda!</li><li><strong>Dia de Vencimento:</strong> Dia de vencimento das novas parcelas</li></ul><p>Os percentuais cadastrados no banco são usados como base para os cálculos automáticos.</p>',
                leoMessage: 'Ofereça sempre mais de uma opção ao cliente! Cenários variados mostram flexibilidade e aumentam a chance de fechar o acordo. Use os percentuais do banco como referência!',
                tipText: 'Crie pelo menos 2 cenários: um mais agressivo (maior desconto, menos parcelas) e um mais conservador (parcelado). O cliente escolhe o que cabe no bolso.'
            },
            {
                id: 'step-8',
                title: 'Status APROVADA — Bloqueio e Recálculo para Auditoria',
                content: '<p>Quando o setor Comercial conclui o preenchimento e muda o status para <strong>APROVADA</strong>, ocorrem automaticamente duas ações importantes:</p><ol><li><strong>Recálculo da dívida:</strong> O sistema refaz todos os cálculos dos cenários de recálculo com os dados atuais, garantindo que os números enviados à auditoria são os mais recentes</li><li><strong>Bloqueio de edição:</strong> A ficha passa a ser <strong>somente leitura</strong>. Nenhum campo pode ser alterado enquanto a ficha estiver com status APROVADA, AUDITADA ou CONCLUÍDO</li></ol><p>Esse bloqueio é fundamental para a integridade do processo: <strong>o setor de Auditoria revisa exatamente o que foi aprovado pelo Comercial</strong>, sem risco de alterações posteriores que comprometeriam a análise.</p><p>Para que a ficha possa ser marcada como Aprovada, é obrigatório que exista pelo menos <strong>um anexo</strong> vinculado a ela.</p>',
                leoMessage: 'Status APROVADA = ficha travada! Isso é proposital. A auditoria precisa revisar exatamente o que o Comercial aprovou. Por isso nunca tente editar após aprovar — o sistema não deixará!',
                tipText: 'Confira todos os campos com atenção antes de mudar para APROVADA. Após isso, só será possível editar novamente com o status Retorno Auditoria.'
            },
            {
                id: 'step-9',
                title: 'Retorno Auditoria — Quadro de Críticas e Respostas',
                content: '<p>Quando o setor de Auditoria identifica alguma irregularidade ou pendência, ele devolve a ficha ao Comercial com o status <strong>RETORNO AUDITORIA</strong>. Este é o único momento em que a ficha volta a ser editável pelo setor Comercial.</p><p>O fluxo funciona assim:</p><ol><li><strong>Auditoria registra a crítica:</strong> O auditor preenche o <em>Quadro de Críticas</em> descrevendo o problema encontrado (ex: "Chassi inválido", "Ausência de documento RG")</li><li><strong>Ficha retorna desbloqueada:</strong> O status muda para RETORNO AUDITORIA e o Comercial pode editar os campos novamente para corrigir as pendências</li><li><strong>Comercial deve responder à crítica:</strong> Antes de reenviar a ficha como APROVADA, o Comercial é <strong>obrigado</strong> a preencher o <em>Quadro de Resposta</em>, justificando cada alteração realizada (ex: "Chassi corrigido conforme CRLV apresentado pelo cliente")</li><li><strong>Nova aprovação dispara novo recálculo:</strong> Ao mudar o status de volta para APROVADA, o sistema refaz o recálculo e trava a ficha novamente</li></ol><p>O histórico de todos os ciclos de crítica e resposta fica registrado permanentemente na ficha, formando uma linha do tempo de auditoria.</p>',
                leoMessage: 'O quadro de críticas e respostas é o canal oficial entre Auditoria e Comercial. Toda e qualquer alteração precisa ser justificada no campo de resposta. Transparência total!',
                tipText: 'Nunca deixe o campo de resposta vazio ao reenviar uma ficha após Retorno Auditoria. Descreva exatamente o que foi corrigido e por quê.'
            },
            {
                id: 'step-10',
                title: 'Fluxo Completo de Status da Ficha',
                content: '<p>Veja o caminho completo que uma ficha de admissão percorre:</p><ul><li><strong>PENDENTE:</strong> Ficha recém-criada, aguardando preenchimento. Editável livremente</li><li><strong>NEGOCIAÇÃO:</strong> Ficha em processo de negociação com o banco. Editável</li><li><strong>ANÁLISE CLIENTE:</strong> Proposta enviada ao cliente, aguardando resposta. Editável</li><li><strong>APROVADA:</strong> Comercial aprovou — recálculo executado, ficha <strong>bloqueada para edição</strong>, encaminhada à Auditoria</li><li><strong>RETORNO AUDITORIA:</strong> Auditoria devolveu com críticas — ficha <strong>desbloqueada</strong> para correções. O Comercial DEVE responder às críticas antes de reenviar</li><li><strong>AUDITADA:</strong> Auditoria está realizando a revisão final. Bloqueada para edição</li><li><strong>CONCLUÍDO:</strong> Processo encerrado com sucesso. Imutável</li><li><strong>REPROVADA:</strong> Proposta definitivamente recusada. Imutável</li></ul>',
                leoMessage: 'Guarde esse fluxo de status! Ele é o mapa da jornada de cada ficha. APROVADA e RETORNO AUDITORIA são os status mais críticos — eles controlam quem pode editar e o que precisa ser feito.',
                tipText: 'Mantenha o status sempre atualizado. A equipe toda depende dessa informação para saber o andamento de cada caso.'
            },
            {
                id: 'step-11',
                title: 'Anexos e Documentos Obrigatórios',
                content: '<p>A aba de <strong>Anexos</strong> permite vincular documentos digitalizados à ficha de admissão. A presença de pelo menos <strong>um anexo é obrigatória</strong> para que a ficha possa ser marcada como APROVADA.</p><p>Documentos essenciais a anexar:</p><ul><li>Contrato original (digitalizado)</li><li>Extrato de pagamentos atualizado</li><li>RG e CPF do cliente</li><li>Comprovante de renda</li><li>CRLV do veículo (para contratos de veículos)</li><li>Propostas formalizadas e aceitas pelo cliente</li></ul><p>Cada anexo deve ter um <strong>título descritivo</strong> que facilite a localização durante a revisão da Auditoria.</p><p>Todos os documentos ficam armazenados de forma permanente e segura, acessíveis a qualquer momento pelo histórico da ficha.</p>',
                leoMessage: 'Sem anexo, sem aprovação! O sistema bloqueia a mudança para APROVADA se não houver pelo menos um documento. Digitalize tudo antes de tentar aprovar!',
                tipText: 'Use títulos claros nos anexos: "Contrato Original BB", "RG Cliente", "CRLV Veículo". A Auditoria agradece a organização!'
            }
        ]
    },
    {
        id: 'contas-receber',
        title: 'Contas a Receber',
        description: 'Gerencie todas as entradas financeiras da empresa com eficiência.',
        icon: '💰',
        category: 'Financeiro',
        defaultScreenshot: 'fin-receber.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'Visão Geral de Contas a Receber',
                content: '<p>O módulo de <strong>Contas a Receber</strong> controla todos os valores que a empresa tem direito de receber de clientes e terceiros.</p><p>Aqui você registra títulos, acompanha vencimentos e controla pagamentos recebidos.</p>',
                leoMessage: 'O Contas a Receber é onde você controla o dinheiro que entra na empresa. Cada real conta! Vamos aprender a gerenciar direitinho.',
                tipText: undefined
            },
            {
                id: 'step-2',
                title: 'Criando um Título a Receber',
                content: '<p>Clique em <strong>Novo Título</strong> e preencha os campos obrigatórios:</p><ul><li><strong>Cliente:</strong> De quem a empresa vai receber</li><li><strong>Tipo de Documento:</strong> Nota fiscal, boleto, recibo, etc.</li><li><strong>Número do Documento:</strong> Identificação do documento</li><li><strong>Valor:</strong> Quanto será recebido</li><li><strong>Data de Emissão:</strong> Quando o título foi emitido</li><li><strong>Data de Vencimento:</strong> Quando vence o pagamento</li><li><strong>Conta Contábil:</strong> Classificação no plano de contas</li></ul>',
                leoMessage: 'Muito bem! Para criar um título, os campos mais importantes são o cliente, o valor e a data de vencimento. O resto ajuda na organização!',
                tipText: 'Sempre preencha o tipo de documento e o número para facilitar a conciliação depois.'
            },
            {
                id: 'step-3',
                title: 'Fluxo de Status dos Títulos',
                content: '<p>Cada título passa por um fluxo de status:</p><ul><li><strong>Em Aberto:</strong> Título registrado, aguardando pagamento</li><li><strong>Parcialmente Liquidado:</strong> Recebeu parte do valor</li><li><strong>Liquidado:</strong> Valor total recebido</li><li><strong>Cancelado:</strong> Título cancelado</li></ul><p>O status é atualizado automaticamente conforme você registra os recebimentos.</p>',
                leoMessage: 'O fluxo é simples: começa Em Aberto e termina Liquidado quando o valor é recebido por completo. O sistema cuida das mudanças de status pra você!',
                tipText: undefined
            },
            {
                id: 'step-4',
                title: 'Liquidação Total',
                content: '<p>Quando o cliente paga o <strong>valor total</strong> do título, clique no botão de <strong>Liquidar</strong>.</p><p>Informe:</p><ul><li><strong>Data do recebimento</strong></li><li><strong>Conta bancária</strong> onde o valor foi depositado</li><li><strong>Forma de pagamento</strong></li></ul><p>O título passará para o status <strong>Liquidado</strong> e um movimento será gerado automaticamente na conta bancária selecionada.</p>',
                leoMessage: 'Recebeu o pagamento? Ótimo! Registra a liquidação e o sistema já atualiza tudo: status do título e saldo da conta bancária. Maravilha!',
                tipText: 'Sempre informe a conta bancária correta para manter a conciliação em dia.'
            },
            {
                id: 'step-5',
                title: 'Liquidação Parcial',
                content: '<p>Quando o cliente paga <strong>apenas parte</strong> do valor, use a opção de <strong>Liquidação Parcial</strong>.</p><p>Informe o valor recebido e o sistema automaticamente:</p><ul><li>Registra o valor parcial recebido</li><li>Atualiza o saldo restante do título</li><li>Muda o status para <strong>Parcialmente Liquidado</strong></li></ul><p>Você pode fazer múltiplas liquidações parciais até completar o valor total.</p>',
                leoMessage: 'Às vezes o cliente paga em partes, e tudo bem! O sistema controla o saldo restante pra você não se perder.',
                tipText: 'Confira o saldo restante após cada liquidação parcial para garantir que os valores estão corretos.'
            },
            {
                id: 'step-6',
                title: 'Liquidação em Lote',
                content: '<p>Quando precisa liquidar <strong>vários títulos de uma vez</strong>, use a <strong>Liquidação em Lote</strong>.</p><p>Selecione os títulos desejados na listagem e clique em <strong>Liquidar Selecionados</strong>.</p><p>Todos os títulos selecionados serão liquidados com a mesma data e conta bancária, economizando muito tempo.</p>',
                leoMessage: 'Liquidação em lote é uma mão na roda quando tem muitos títulos pra dar baixa! Seleciona tudo e resolve de uma vez só. Eficiência pura!',
                tipText: 'Ideal para quando você recebe um depósito com vários títulos de um mesmo cliente.'
            },
            {
                id: 'step-7',
                title: 'Lançamentos Recorrentes',
                content: '<p>Para receitas que se repetem todos os meses (como mensalidades e aluguéis), use os <strong>Lançamentos Recorrentes</strong>.</p><p>Configure:</p><ul><li>Valor e descrição do lançamento</li><li>Frequência (mensal, semanal, etc.)</li><li>Data de início e quantidade de repetições</li></ul><p>O sistema criará automaticamente os títulos futuros, economizando tempo de digitação.</p>',
                leoMessage: 'Lançamento recorrente é perfeito pra quem tem receitas fixas! Configura uma vez e o sistema cria os títulos todo mês. Agora ficou fácil, né?',
                tipText: 'Use lançamentos recorrentes para mensalidades, aluguéis e outras receitas fixas.'
            }
        ]
    },
    {
        id: 'contas-pagar',
        title: 'Contas a Pagar',
        description: 'Controle todas as saídas financeiras e obrigações da empresa.',
        icon: '💸',
        category: 'Financeiro',
        defaultScreenshot: 'fin-pagar.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'Visão Geral de Contas a Pagar',
                content: '<p>O módulo de <strong>Contas a Pagar</strong> controla todas as obrigações financeiras da empresa: contas, fornecedores, despesas e pagamentos programados.</p><p>A interface é muito semelhante ao Contas a Receber, porém focada nas <strong>saídas</strong> de dinheiro.</p>',
                leoMessage: 'Contas a Pagar funciona parecido com o Contas a Receber, mas aqui o foco é no que a empresa precisa pagar. Vamos aprender as diferenças!',
                tipText: undefined
            },
            {
                id: 'step-2',
                title: 'Criando um Título a Pagar',
                content: '<p>Clique em <strong>Novo Título</strong> e preencha:</p><ul><li><strong>Fornecedor/Beneficiário:</strong> A quem a empresa vai pagar</li><li><strong>Tipo de Documento:</strong> Nota fiscal, boleto, fatura, etc.</li><li><strong>Número do Documento:</strong> Identificação</li><li><strong>Valor:</strong> Quanto será pago</li><li><strong>Data de Emissão:</strong> Quando o título foi emitido</li><li><strong>Data de Vencimento:</strong> Quando vence o pagamento</li><li><strong>Conta Contábil:</strong> Classificação da despesa no plano de contas</li></ul>',
                leoMessage: 'Cadastrar uma conta a pagar é bem parecido com o a receber. A diferença principal é que aqui você informa quem vai receber o dinheiro!',
                tipText: 'Cadastre os títulos assim que receber as faturas para não perder prazos de pagamento.'
            },
            {
                id: 'step-3',
                title: 'Diferenças do Contas a Receber',
                content: '<p>As principais diferenças entre Contas a Pagar e Contas a Receber:</p><ul><li><strong>Direção do dinheiro:</strong> Pagar = saída, Receber = entrada</li><li><strong>Conta contábil:</strong> Pagar usa contas de <strong>Despesa</strong>, Receber usa contas de <strong>Receita</strong></li><li><strong>Impacto no saldo:</strong> Pagamentos <strong>diminuem</strong> o saldo bancário, recebimentos <strong>aumentam</strong></li></ul><p>O fluxo de status (Em Aberto → Liquidado) funciona da mesma forma.</p>',
                leoMessage: 'A lógica é a mesma, só muda a direção! Aqui o dinheiro sai da conta. Fique de olho nos vencimentos pra não pagar juros desnecessários!',
                tipText: 'Organize os pagamentos por data de vencimento para priorizar o que vence primeiro.'
            },
            {
                id: 'step-4',
                title: 'Liquidação de Pagamentos',
                content: '<p>Quando efetuar o pagamento, clique em <strong>Liquidar</strong> e informe:</p><ul><li><strong>Data do pagamento</strong></li><li><strong>Conta bancária</strong> de onde saiu o dinheiro</li><li><strong>Forma de pagamento</strong></li></ul><p>Assim como no Receber, você pode fazer <strong>liquidação total</strong>, <strong>parcial</strong> ou <strong>em lote</strong>.</p><p>O movimento de saída será gerado automaticamente na conta bancária.</p>',
                leoMessage: 'Pagou a conta? Registra aqui! O saldo da conta bancária já é atualizado automaticamente. Tudo integrado!',
                tipText: 'Use a liquidação em lote quando precisar pagar vários fornecedores no mesmo dia.'
            },
            {
                id: 'step-5',
                title: 'Lançamentos Recorrentes de Despesas',
                content: '<p>Para despesas fixas como aluguel, energia e internet, configure <strong>Lançamentos Recorrentes</strong>.</p><p>O sistema criará automaticamente os títulos a pagar nos meses futuros, garantindo que nenhuma conta seja esquecida.</p><p>Você pode ajustar valores individualmente caso haja variação (como na conta de energia).</p>',
                leoMessage: 'Despesas fixas não precisam ser digitadas todo mês! Configura a recorrência uma vez e fica tranquilo. O sistema lembra por você!',
                tipText: 'Mesmo com lançamento recorrente, revise os valores mensalmente para contas variáveis.'
            },
            {
                id: 'step-6',
                title: 'Acompanhamento e Filtros',
                content: '<p>Use os <strong>filtros</strong> disponíveis para acompanhar suas contas:</p><ul><li><strong>Por status:</strong> Em Aberto, Liquidado, Vencido</li><li><strong>Por período:</strong> Filtre por data de vencimento</li><li><strong>Por fornecedor:</strong> Veja todas as contas de um fornecedor específico</li></ul><p>Isso facilita a <strong>gestão do fluxo de caixa</strong> e o planejamento financeiro da empresa.</p>',
                leoMessage: 'Os filtros são essenciais pra você ter controle total! Filtre por vencimento e nunca mais perca um prazo. Organização é poder!',
                tipText: 'Consulte regularmente os títulos vencidos para evitar juros e multas.'
            }
        ]
    },
    {
        id: 'movimentos-bancarios',
        title: 'Movimentos Bancários',
        description: 'Acompanhe e gerencie todas as movimentações das contas bancárias.',
        icon: '🏧',
        category: 'Financeiro',
        defaultScreenshot: 'fin-cc-movimento.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'O que são Movimentos Bancários',
                content: '<p>O módulo de <strong>Movimentos Bancários</strong> mostra todas as entradas e saídas de dinheiro em cada conta da empresa.</p><p>Cada movimento é gerado automaticamente quando você liquida um título a receber ou a pagar, ou pode ser inserido manualmente.</p>',
                leoMessage: 'Movimentos bancários é o extrato do sistema! Aqui você vê tudo que entrou e saiu de cada conta. Vamos entender como funciona!',
                tipText: undefined
            },
            {
                id: 'step-2',
                title: 'Selecionando a Conta Bancária',
                content: '<p>No topo da tela, use o <strong>seletor de conta</strong> para escolher qual conta bancária deseja visualizar.</p><p>Cada conta mostra seus próprios movimentos e saldo independente.</p><p>Se a empresa possui múltiplas contas (corrente, poupança, caixa), alterne entre elas para ver os movimentos de cada uma.</p>',
                leoMessage: 'Primeiro, escolha a conta que quer analisar. Se a empresa tem várias contas, cada uma tem seu próprio extrato!',
                tipText: 'Verifique todas as contas periodicamente para ter uma visão completa da saúde financeira.'
            },
            {
                id: 'step-3',
                title: 'Entendendo Créditos e Débitos',
                content: '<p>Os movimentos são classificados por cores para facilitar a leitura:</p><ul><li><strong style="color: green;">Verde (Crédito):</strong> Dinheiro que <strong>entrou</strong> na conta (recebimentos)</li><li><strong style="color: red;">Vermelho (Débito):</strong> Dinheiro que <strong>saiu</strong> da conta (pagamentos)</li></ul><p>A coluna de <strong>Saldo</strong> mostra o saldo acumulado após cada movimentação, permitindo acompanhar a evolução do saldo ao longo do tempo.</p>',
                leoMessage: 'Verde é bom: dinheiro entrando! Vermelho é saindo. E o saldo vai atualizando a cada linha. Simples e visual!',
                tipText: 'Fique atento ao saldo acumulado para garantir que a conta não fique negativa.'
            },
            {
                id: 'step-4',
                title: 'Saldo Corrente (Running Balance)',
                content: '<p>A coluna de <strong>Saldo</strong> funciona como um saldo corrente:</p><ul><li>Começa com o <strong>saldo inicial</strong> configurado na conta</li><li>Cada <strong>crédito</strong> soma ao saldo</li><li>Cada <strong>débito</strong> subtrai do saldo</li></ul><p>O último valor da coluna é o <strong>saldo atual</strong> da conta.</p>',
                leoMessage: 'O saldo corrente é como o saldo do seu extrato bancário: vai somando e subtraindo a cada movimento. O último número é o que tem na conta!',
                tipText: 'Compare o saldo do sistema com o saldo real do banco para detectar divergências.'
            },
            {
                id: 'step-5',
                title: 'Lançamentos Manuais',
                content: '<p>Além dos movimentos gerados automaticamente, você pode criar <strong>lançamentos manuais</strong>.</p><p>Isso é útil para:</p><ul><li>Taxas e tarifas bancárias</li><li>Transferências entre contas</li><li>Juros recebidos ou pagos</li><li>Ajustes e correções</li></ul><p>Clique em <strong>Novo Movimento</strong>, informe se é crédito ou débito, o valor, a data e uma descrição.</p>',
                leoMessage: 'Aquela tarifa do banco que apareceu no extrato? Registra aqui manualmente! Assim o saldo do sistema fica igualzinho ao do banco.',
                tipText: 'Registre tarifas bancárias e IOF manualmente para manter o saldo do sistema atualizado.'
            },
            {
                id: 'step-6',
                title: 'Filtros e Pesquisa',
                content: '<p>Use os filtros para encontrar movimentos específicos:</p><ul><li><strong>Por período:</strong> Data inicial e final</li><li><strong>Por tipo:</strong> Crédito ou Débito</li><li><strong>Por descrição:</strong> Busque por palavras na descrição do movimento</li></ul><p>Os filtros ajudam a localizar movimentos rapidamente, especialmente quando há muitas transações.</p>',
                leoMessage: 'Com os filtros, você encontra qualquer movimento em segundos! Perfeito pra quando precisa conferir alguma coisa específica. Agora ficou fácil, né?',
                tipText: 'Use o filtro de período para analisar movimentos de um mês específico.'
            }
        ]
    },
    {
        id: 'cobranca',
        title: 'Módulo de Cobrança',
        description: 'Gerencie a cobrança de clientes inadimplentes de forma organizada.',
        icon: '📞',
        category: 'Financeiro',
        defaultScreenshot: 'fin-cob-operacional.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'Visão Geral do Módulo de Cobrança',
                content: '<p>O <strong>Módulo de Cobrança</strong> é dividido em duas visões:</p><ul><li><strong>Coordenador:</strong> Visão gerencial com todos os clientes e métricas</li><li><strong>Operacional:</strong> Visão do colaborador com seus clientes designados</li></ul><p>O objetivo é organizar e acompanhar as cobranças de clientes inadimplentes de forma sistemática.</p>',
                leoMessage: 'O módulo de cobrança é essencial pra manter as finanças em dia! Tem duas visões: uma pro gestor e outra pro operador. Vamos conhecer as duas!',
                tipText: undefined
            },
            {
                id: 'step-2',
                title: 'Visão do Coordenador',
                content: '<p>A visão do <strong>Coordenador</strong> oferece uma perspectiva gerencial:</p><ul><li><strong>Dashboard com KPIs:</strong> Indicadores como total de inadimplentes, valor total em atraso, taxa de recuperação</li><li><strong>Lista completa de clientes:</strong> Todos os inadimplentes da empresa</li><li><strong>Filtros avançados:</strong> Por período, valor, colaborador responsável</li><li><strong>Distribuição de carteira:</strong> Quantos clientes cada colaborador atende</li></ul>',
                leoMessage: 'O coordenador tem a visão do todo! Ele vê os indicadores, distribui os clientes entre a equipe e acompanha os resultados. Visão estratégica!',
                tipText: 'Acompanhe os KPIs diariamente para identificar tendências e agir rapidamente.',
                screenshot: 'fin-cob-coordenador.jpg'
            },
            {
                id: 'step-3',
                title: 'Visão Operacional',
                content: '<p>A visão <strong>Operacional</strong> é voltada para o colaborador que executa as cobranças:</p><ul><li><strong>Meus clientes:</strong> Lista dos clientes designados para você</li><li><strong>Ações de cobrança:</strong> Registrar ligações, e-mails e contatos</li><li><strong>Histórico:</strong> Todo o histórico de contatos com cada cliente</li><li><strong>Próximas ações:</strong> Agenda de follow-up programado</li></ul>',
                leoMessage: 'Na visão operacional, você vê só os seus clientes. Foco total! Registre cada contato pra manter o histórico completo.',
                tipText: 'Registre todos os contatos, mesmo os que não tiveram resposta. O histórico completo é valioso.'
            },
            {
                id: 'step-4',
                title: 'Designando Colaboradores',
                content: '<p>O coordenador pode <strong>designar colaboradores</strong> para cada cliente inadimplente.</p><p>Isso distribui a carteira de cobrança entre a equipe, garantindo que cada cliente tenha um responsável.</p><p>Para designar, selecione o cliente e escolha o colaborador responsável.</p>',
                leoMessage: 'Distribuir bem a carteira é a chave do sucesso! Cada colaborador cuida dos seus clientes e ninguém fica esquecido.',
                tipText: 'Distribua os clientes de forma equilibrada, considerando a carga de trabalho de cada colaborador.',
                screenshot: 'fin-cob-coordenador.jpg'
            },
            {
                id: 'step-5',
                title: 'Detalhes do Cliente e Aging',
                content: '<p>Ao clicar em um cliente, você vê todos os detalhes da inadimplência:</p><ul><li><strong>Dados do cliente:</strong> Contatos e informações cadastrais</li><li><strong>Aging (envelhecimento):</strong> Classificação por tempo de atraso:<ul><li>1-30 dias</li><li>31-60 dias</li><li>61-90 dias</li><li>Acima de 90 dias</li></ul></li><li><strong>Valor total em atraso</strong></li><li><strong>Histórico de contatos</strong></li></ul>',
                leoMessage: 'O aging mostra há quanto tempo cada dívida está em atraso. Quanto mais antiga, mais atenção precisa! As cores ajudam a identificar rapidinho.',
                tipText: 'Priorize os clientes com dívidas mais antigas (acima de 90 dias) para evitar que se tornem irrecuperáveis.'
            },
            {
                id: 'step-6',
                title: 'Dashboard e KPIs de Cobrança',
                content: '<p>O <strong>Dashboard</strong> do módulo exibe indicadores-chave:</p><ul><li><strong>Total de inadimplentes:</strong> Quantidade de clientes em atraso</li><li><strong>Valor total em atraso:</strong> Soma de todas as dívidas</li><li><strong>Taxa de recuperação:</strong> Percentual de valores recuperados</li><li><strong>Contatos realizados:</strong> Quantidade de ações de cobrança</li><li><strong>Tendência mensal:</strong> Evolução dos indicadores ao longo do tempo</li></ul>',
                leoMessage: 'Os KPIs mostram como a equipe está se saindo! Acompanhe esses números pra celebrar os avanços e ajustar o que for preciso. Muito bem!',
                tipText: 'Compare os KPIs mês a mês para avaliar a efetividade das estratégias de cobrança.'
            }
        ]
    },
    {
        id: 'negociacao-financeira',
        title: 'Negociação Financeira',
        description: 'Conduza negociações de dívidas com clientes de forma profissional.',
        icon: '🤝',
        category: 'Financeiro',
        defaultScreenshot: 'fin-negociacao.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'O que é a Negociação Financeira',
                content: '<p>O módulo de <strong>Negociação Financeira</strong> permite conduzir e acompanhar todo o processo de renegociação de dívidas com os clientes.</p><p>Cada negociação vincula um <strong>cliente</strong> a uma <strong>admissão</strong> e registra todo o histórico de contatos e propostas.</p>',
                leoMessage: 'A negociação é onde a mágica acontece! Aqui você registra cada conversa, cada proposta e acompanha até fechar o acordo. Vamos lá!',
                tipText: undefined
            },
            {
                id: 'step-2',
                title: 'Criando uma Negociação',
                content: '<p>Para iniciar uma negociação, clique em <strong>Nova Negociação</strong> e preencha:</p><ul><li><strong>Cliente:</strong> Selecione o cliente</li><li><strong>Admissão:</strong> Vincule à admissão existente</li><li><strong>Banco:</strong> Instituição financeira envolvida</li><li><strong>Colaborador:</strong> Responsável pela negociação</li><li><strong>Valor da dívida:</strong> Valor total em negociação</li></ul><p>O status inicial será <strong>ABERTA</strong>.</p>',
                leoMessage: 'Comece selecionando o cliente e a admissão. A negociação vai registrar tudo que acontecer a partir de agora. Organização total!',
                tipText: 'Vincule sempre a negociação à admissão correta para manter o rastreamento completo.'
            },
            {
                id: 'step-3',
                title: 'Timeline de Contatos',
                content: '<p>Registre cada <strong>contato</strong> realizado com o cliente:</p><ul><li><strong>Data e hora</strong> do contato</li><li><strong>Canal:</strong> Telefone, WhatsApp, E-mail, SMS, Presencial ou Carta</li><li><strong>Resposta:</strong> Atendeu, Não Atendeu, Recado, Interessado, etc.</li><li><strong>Descrição:</strong> Detalhes da conversa</li><li><strong>Próxima ação:</strong> Agende o próximo contato</li></ul><p>Todos os contatos formam uma <strong>linha do tempo</strong> da negociação.</p>',
                leoMessage: 'Registrar cada contato é fundamental! A timeline mostra todo o histórico e ajuda a equipe a saber exatamente o que já foi conversado.',
                tipText: 'Sempre agende a próxima ação ao registrar um contato. Isso evita que o cliente seja esquecido.'
            },
            {
                id: 'step-4',
                title: 'Propostas de Acordo',
                content: '<p>Dentro da negociação, você pode criar <strong>propostas</strong> para o cliente:</p><ul><li><strong>Valor original</strong> da dívida</li><li><strong>Percentual de desconto</strong></li><li><strong>Valor com desconto</strong></li><li><strong>Número de parcelas</strong></li><li><strong>Valor de entrada</strong> (opcional)</li><li><strong>Status:</strong> Enviada, Em Análise, Aceita, Recusada, etc.</li></ul><p>Você pode criar múltiplas propostas até encontrar a que melhor atende ao cliente.</p>',
                leoMessage: 'Cada proposta é uma oportunidade de fechar o acordo! Crie diferentes opções e encontre a melhor solução para o cliente e para a empresa.',
                tipText: 'Ofereça pelo menos duas opções de proposta: uma com desconto maior à vista e outra parcelada.'
            },
            {
                id: 'step-5',
                title: 'Metas e Objetivos',
                content: '<p>O módulo permite definir <strong>metas</strong> para os colaboradores:</p><ul><li><strong>Meta de valor:</strong> Quanto em dívidas deve ser negociado no mês</li><li><strong>Meta de quantidade:</strong> Quantos acordos devem ser fechados</li><li><strong>Acompanhamento:</strong> Valores alcançados vs. metas definidas</li></ul><p>As metas são definidas por colaborador e por mês, permitindo acompanhar o desempenho individual.</p>',
                leoMessage: 'Metas claras motivam a equipe! Defina objetivos realistas e acompanhe o progresso. Quando bater a meta, celebre com o time!',
                tipText: 'Defina metas desafiadoras mas alcançáveis. Metas impossíveis desmotivam a equipe.'
            },
            {
                id: 'step-6',
                title: 'Dashboard de Performance',
                content: '<p>O <strong>Dashboard</strong> de negociações mostra:</p><ul><li><strong>Negociações abertas:</strong> Quantidade e valor total</li><li><strong>Acordos fechados:</strong> No período selecionado</li><li><strong>Taxa de conversão:</strong> Propostas aceitas vs. total de propostas</li><li><strong>Performance por colaborador:</strong> Ranking de desempenho</li><li><strong>Meta vs. Realizado:</strong> Comparativo mensal</li></ul><p>Esses dados ajudam na tomada de decisão e no ajuste de estratégias.</p>',
                leoMessage: 'O dashboard é o seu painel de controle! Aqui você vê como a equipe está performando e onde precisa melhorar. Dados são poder!',
                tipText: 'Analise o dashboard semanalmente para fazer ajustes rápidos na estratégia de negociação.'
            }
        ]
    },
    {
        id: 'relatorios',
        title: 'Relatórios e Formulários',
        description: 'Crie relatórios personalizados e formulários para sua operação.',
        icon: '📊',
        category: 'Relatórios',
        defaultScreenshot: 'rel-formularios.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'Visão Geral de Relatórios',
                content: '<p>O módulo de <strong>Relatórios e Formulários</strong> permite criar documentos personalizados para diversas finalidades.</p><p>Você pode montar formulários com campos variados, usar modelos prontos e exportar os resultados.</p>',
                leoMessage: 'Relatórios são a cereja do bolo! Eles transformam dados em informação útil. Vou te mostrar como criar os seus!',
                tipText: undefined
            },
            {
                id: 'step-2',
                title: 'Construindo um Formulário',
                content: '<p>No <strong>Construtor de Formulários</strong>, você monta seus documentos arrastando e posicionando campos:</p><ul><li><strong>Campos de texto:</strong> Para informações escritas</li><li><strong>Campos numéricos:</strong> Para valores e quantidades</li><li><strong>Campos de data:</strong> Para datas específicas</li><li><strong>Listas de seleção:</strong> Para escolher entre opções predefinidas</li><li><strong>Áreas de texto:</strong> Para descrições longas</li></ul><p>Organize os campos conforme a necessidade do seu formulário.</p>',
                leoMessage: 'Montar formulário é como montar um quebra-cabeça! Arraste os campos, organize do seu jeito e pronto. Você é o arquiteto do seu relatório!',
                tipText: 'Comece com os campos mais importantes no topo do formulário.'
            },
            {
                id: 'step-3',
                title: 'Usando Templates Prontos',
                content: '<p>O sistema oferece <strong>templates</strong> (modelos prontos) para os relatórios mais comuns:</p><ul><li>Relatório de admissões</li><li>Relatório financeiro</li><li>Relatório de cobranças</li><li>Formulário de atendimento</li></ul><p>Selecione um template e personalize conforme sua necessidade. Isso economiza muito tempo!</p>',
                leoMessage: 'Templates são atalhos inteligentes! Em vez de começar do zero, pegue um modelo pronto e adapte. Trabalho inteligente é assim!',
                tipText: 'Salve seus formulários personalizados como novos templates para reutilizar no futuro.'
            },
            {
                id: 'step-4',
                title: 'Exportando Relatórios',
                content: '<p>Após construir seu relatório, você pode <strong>exportá-lo</strong> em diferentes formatos:</p><ul><li><strong>PDF:</strong> Para impressão e envio por e-mail</li><li><strong>Impressão direta:</strong> Envie direto para a impressora</li></ul><p>Os relatórios podem incluir logotipo da empresa, data de geração e informações do usuário que gerou.</p>',
                leoMessage: 'Pronto! Seu relatório ficou lindo? Agora é só exportar em PDF ou imprimir. Compartilhe com a equipe e impressione todo mundo!',
                tipText: 'Exporte em PDF para manter uma cópia digital organizada dos seus relatórios.',
                screenshot: 'rel-gerais.jpg'
            },
            {
                id: 'step-5',
                title: 'Filtros e Personalização',
                content: '<p>Ao gerar relatórios, use <strong>filtros</strong> para extrair exatamente os dados que precisa:</p><ul><li><strong>Por período:</strong> Data inicial e final</li><li><strong>Por status:</strong> Filtre por situação dos registros</li><li><strong>Por colaborador:</strong> Dados de um profissional específico</li><li><strong>Por cliente:</strong> Informações de um cliente em particular</li></ul><p>Combine filtros para obter relatórios precisos e relevantes.</p>',
                leoMessage: 'Filtros são seus melhores amigos nos relatórios! Com eles, você extrai exatamente a informação que precisa. Nem mais, nem menos!',
                tipText: 'Combine múltiplos filtros para relatórios mais específicos e relevantes.',
                screenshot: 'rel-gerais.jpg'
            }
        ]
    },
    {
        id: 'configuracoes',
        title: 'Configurações do Sistema',
        description: 'Configure o FinancePro de acordo com as necessidades da sua empresa.',
        icon: '⚙️',
        category: 'Configurações',
        defaultScreenshot: 'settings-portal.jpg',
        steps: [
            {
                id: 'step-1',
                title: 'Visão Geral das Configurações',
                content: '<p>As <strong>Configurações</strong> permitem personalizar o FinancePro de acordo com as necessidades da sua empresa.</p><p>As principais áreas de configuração são:</p><ul><li><strong>Portal:</strong> Dados da empresa e personalização visual</li><li><strong>Unidades:</strong> Filiais e unidades de negócio</li><li><strong>Usuários:</strong> Gerenciamento de acessos</li><li><strong>Grupos e Permissões:</strong> Controle de acesso por perfil</li><li><strong>E-mail:</strong> Configuração de envio de e-mails</li></ul>',
                leoMessage: 'As configurações são a fundação do sistema! Configure tudo direitinho no começo e o dia a dia vai fluir muito melhor. Vamos lá!',
                tipText: 'Somente administradores têm acesso às configurações do sistema.',
                screenshot: 'settings-portal.jpg'
            },
            {
                id: 'step-2',
                title: 'Configurações do Portal',
                content: '<p>Na aba <strong>Portal</strong>, defina os dados da empresa:</p><ul><li><strong>Razão Social e CNPJ</strong></li><li><strong>Endereço completo</strong></li><li><strong>Telefone e e-mail</strong></li><li><strong>Logotipo da empresa:</strong> Aparecerá no login e no cabeçalho</li><li><strong>Cores do sistema:</strong> Personalize as cores da sidebar, cabeçalho, tela de login e área principal</li></ul><p>Essas configurações definem a identidade visual do sistema para sua empresa.</p>',
                leoMessage: 'Deixe o sistema com a cara da sua empresa! Configure o logotipo, as cores e os dados. Personalização faz toda a diferença!',
                tipText: 'Use as cores da identidade visual da empresa para manter a consistência.',
                screenshot: 'settings-portal.jpg'
            },
            {
                id: 'step-3',
                title: 'Gerenciando Unidades',
                content: '<p>Se a empresa possui <strong>filiais ou unidades de negócio</strong>, cadastre cada uma separadamente.</p><p>Cada unidade pode ter:</p><ul><li>Nome e dados próprios (CNPJ, endereço, telefone)</li><li>Numeração independente de documentos</li><li>Colaboradores vinculados</li></ul><p>Os usuários podem ser autorizados a acessar uma ou mais unidades, e devem selecionar a unidade ao entrar no sistema.</p>',
                leoMessage: 'Múltiplas unidades? Sem problema! Cada filial tem seus próprios dados e numeração. Tudo organizado e separado!',
                tipText: 'Configure as unidades antes de cadastrar usuários para poder vincular corretamente.',
                screenshot: 'settings-unidades.jpg'
            },
            {
                id: 'step-4',
                title: 'Usuários e Acessos',
                content: '<p>Na seção de <strong>Usuários</strong>, gerencie quem acessa o sistema:</p><ul><li><strong>Criar usuário:</strong> Nome, e-mail e senha provisória</li><li><strong>Tipo:</strong> Administrador (acesso total) ou Usuário (acesso limitado)</li><li><strong>Status:</strong> Ativo ou Inativo</li><li><strong>Unidades permitidas:</strong> Quais unidades o usuário pode acessar</li><li><strong>Forçar troca de senha:</strong> Obriga o usuário a criar nova senha no próximo login</li></ul>',
                leoMessage: 'Cada pessoa que usa o sistema precisa de um usuário próprio. Nunca compartilhe logins! Segurança em primeiro lugar!',
                tipText: 'Sempre marque "Forçar troca de senha" ao criar um novo usuário para garantir que ele crie uma senha pessoal.',
                screenshot: 'settings-usuarios.jpg'
            },
            {
                id: 'step-5',
                title: 'Grupos e Permissões',
                content: '<p>Os <strong>Grupos</strong> definem perfis de acesso com permissões específicas:</p><ul><li>Crie grupos como "Financeiro", "Comercial", "Gerência"</li><li>Defina quais <strong>menus e funcionalidades</strong> cada grupo pode acessar</li><li>Vincule usuários a um ou mais grupos</li></ul><p>As permissões controlam o que cada usuário pode ver e fazer no sistema, garantindo segurança e organização.</p>',
                leoMessage: 'Grupos são como crachás de acesso! Cada grupo libera funcionalidades diferentes. Assim cada pessoa vê só o que precisa. Esse é um passo importante!',
                tipText: 'Crie grupos específicos por departamento para facilitar o controle de permissões.',
                screenshot: 'settings-usuarios.jpg'
            },
            {
                id: 'step-6',
                title: 'Configuração de E-mail',
                content: '<p>Configure o <strong>servidor de e-mail</strong> para que o sistema possa enviar notificações e documentos:</p><ul><li><strong>Nome do remetente:</strong> Como aparecerá para quem receber</li><li><strong>Servidor (Host):</strong> Endereço do servidor SMTP</li><li><strong>Porta:</strong> Normalmente 587 (TLS) ou 465 (SSL)</li><li><strong>Usuário e Senha:</strong> Credenciais de autenticação</li><li><strong>Segurança:</strong> TLS recomendado para proteção</li></ul><p>Após configurar, use o botão de <strong>teste</strong> para verificar se está funcionando.</p>',
                leoMessage: 'E-mail configurado = sistema completo! Assim o FinancePro pode enviar notificações, documentos e alertas automaticamente. Muito prático!',
                tipText: 'Sempre teste o envio de e-mail após configurar para garantir que está funcionando corretamente.',
                screenshot: 'settings-emails.jpg'
            }
        ]
    }
];

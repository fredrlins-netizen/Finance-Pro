import React from 'react';
import { PortalConfig, FinancialRecord } from '../../types';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';
import { useSecurity } from '../../contexts/SecurityContext';
import PaginationBar from '../ui/PaginationBar';
import CollectionCoordinatorPanel from './CollectionCoordinatorPanel';
import CollectionOperationalPanel from './CollectionOperationalPanel';
import NegotiationPanel from './NegotiationPanel';
import { useDashboardInvalidation } from '../../contexts/useDashboardInvalidation';

interface CollectionPanelProps {
    config: PortalConfig;
    activeView: string;
    currentUserId?: string;
    onNavigate?: (view: string) => void;
    onRefresh?: () => void;
    gotalkEnabled?: boolean;
    GotalkChatPanel?: React.ComponentType<{ clientId: string; area: string; operatorName?: string }>;
    GotalkConversationsTab?: React.ComponentType<{ clientId: string }>;
    GotalkAttendanceViewer?: React.ComponentType<{ clientId: string; collaboratorId?: string; title: string }>;
}


const CollectionPanel: React.FC<CollectionPanelProps> = ({ config, activeView, currentUserId, onRefresh, onNavigate, gotalkEnabled, GotalkChatPanel, GotalkConversationsTab, GotalkAttendanceViewer }) => {
    const { isLoggedAdmin } = useSecurity();
    const { data: apiReceivableTitles, loading: titlesLoading, search: searchTitles, refresh: refreshTitles, currentPage: serverPage, totalPages: serverTotalPages, total: serverTotal, goToPage: serverGoToPage } = useEntityCRUD<FinancialRecord>('financial-titles', { pageSize: 50, extraParams: { filter_title_scope: 'RECEBER' } });
    const isCollectionDashboard = activeView === 'fin_cob_coordenador' || activeView === 'fin_cob_operacional';
    useDashboardInvalidation('collection', refreshTitles, isCollectionDashboard);

    const receivableTitles = React.useMemo(() => {
        return apiReceivableTitles.filter(t => t.status !== 'CANCELADO');
    }, [apiReceivableTitles]);

    const handleUpdateGlobal = async (key: keyof PortalConfig, value: any) => {
        try {
            await fetch('/api/settings/section', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key, value }) });
            if (onRefresh) onRefresh();
        } catch (e) { console.error('CollectionPanel handleUpdateGlobal error:', e); }
    };

    const gotalkChatPanel = gotalkEnabled ? GotalkChatPanel : undefined;
    const gotalkConversationsTab = gotalkEnabled ? GotalkConversationsTab : undefined;
    const gotalkAttendanceViewer = gotalkEnabled ? GotalkAttendanceViewer : undefined;

    switch (activeView) {
        case 'fin_cob_coordenador': {
            return (
                <div className="flex flex-col flex-1 min-h-0">
                    <CollectionCoordinatorPanel
                        titles={receivableTitles}
                        collaborators={config.collaborators || []}
                        currentUserId={currentUserId || ''}
                        isAdmin={isLoggedAdmin}
                        clients={config.clients || []}
                        admissions={config.admissions || []}
                        auditLogs={config.auditLogs || []}
                        banks={config.banks || []}
                        series={config.series || []}
                        modalities={config.modalities || []}
                        units={config.units || []}
                        onSearch={searchTitles}
                        GotalkChatPanel={gotalkChatPanel}
                        GotalkAttendanceViewer={gotalkAttendanceViewer}
                    />
                    <PaginationBar currentPage={serverPage} totalPages={serverTotalPages} total={serverTotal} pageSize={50} onPageChange={serverGoToPage} loading={titlesLoading} />
                </div>
            );
        }

        case 'fin_cob_operacional': {
            const loggedUser = (config.users || []).find(u => u.id === currentUserId);
            return (
                <div className="flex flex-col flex-1 min-h-0">
                    <CollectionOperationalPanel
                        titles={receivableTitles}
                        collaborators={config.collaborators || []}
                        currentUserId={currentUserId || ''}
                        currentCollaboratorId={loggedUser?.collaboratorId || ''}
                        isAdmin={isLoggedAdmin}
                        clients={config.clients || []}
                        admissions={config.admissions || []}
                        auditLogs={config.auditLogs || []}
                        userGroups={config.userGroups || []}
                        onRefresh={onRefresh}
                        onBack={onNavigate ? () => onNavigate('fin_cob_coordenador') : undefined}
                        onSearch={searchTitles}
                        GotalkChatPanel={gotalkChatPanel}
                        GotalkConversationsTab={gotalkConversationsTab}
                    />
                    <PaginationBar currentPage={serverPage} totalPages={serverTotalPages} total={serverTotal} pageSize={50} onPageChange={serverGoToPage} loading={titlesLoading} />
                </div>
            );
        }

        case 'fin_negociacao': {
            const negUser = (config.users || []).find(u => u.id === currentUserId);
            return (
                <div className="flex flex-col flex-1 min-h-0">
                    <NegotiationPanel
                        clients={config.clients || []}
                        collaborators={config.collaborators || []}
                        admissions={config.admissions || []}
                        banks={config.banks || []}
                        currentCollaboratorId={negUser?.collaboratorId || ''}
                        receivableTitles={receivableTitles}
                        auditLogs={config.auditLogs || []}
                        isAdmin={isLoggedAdmin}
                        onBack={onNavigate ? () => onNavigate('fin_cob_coordenador') : undefined}
                        GotalkConversationsTab={gotalkConversationsTab}
                    />
                    <PaginationBar currentPage={serverPage} totalPages={serverTotalPages} total={serverTotal} pageSize={50} onPageChange={serverGoToPage} loading={titlesLoading} />
                </div>
            );
        }

        default:
            return null;
    }
};

export default CollectionPanel;

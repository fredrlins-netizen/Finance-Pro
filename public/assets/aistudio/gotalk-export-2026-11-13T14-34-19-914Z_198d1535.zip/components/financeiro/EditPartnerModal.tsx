import React, { useState, useEffect } from 'react';
import { Client } from '../../types';
import { useAudit } from '../../contexts/AuditContext';
import { useKeyboardShortcut } from '../../contexts/KeyboardShortcutContext';
import { api } from '../../services/apiService';

interface EditPartnerModalProps {
    client: Client;
    label: string;
    onClose: () => void;
    onNameChange?: (newName: string) => void;
}

const EditPartnerModal: React.FC<EditPartnerModalProps> = ({ client, label, onClose, onNameChange }) => {
    const { logTransaction } = useAudit();
    const { registerFormActions, unregisterFormActions } = useKeyboardShortcut();
    const [form, setForm] = useState<Client>({ ...client });
    const [saving, setSaving] = useState(false);

    useEffect(() => {
        setForm({ ...client });
    }, [client]);

    const handleSave = async () => {
        setSaving(true);
        try {
            await api.put(`/api/clients/${form.id}`, {
                name: form.name,
                type: form.type,
                document: form.document,
                phone: form.phone,
                email: form.email,
                address: form.address,
                number: form.number,
                complement: form.complement,
                district: form.district,
                city: form.city,
                state: form.state,
                cep: form.cep,
                notes: form.notes,
            });
            logTransaction('CLIENTE', form.id, client, form);
            if (onNameChange) onNameChange(form.name);
            onClose();
        } catch {
            logTransaction('CLIENTE', form.id, client, form);
            if (onNameChange) onNameChange(form.name);
            onClose();
        } finally {
            setSaving(false);
        }
    };

    useEffect(() => {
        registerFormActions(handleSave, onClose);
        return () => unregisterFormActions();
    }, [handleSave, onClose, registerFormActions, unregisterFormActions]);

    const field = (
        id: keyof Client,
        lbl: string,
        placeholder?: string,
        type: string = 'text',
        half?: boolean
    ) => (
        <div className={half ? '' : 'col-span-2'}>
            <label className="block text-xs font-semibold text-gray-600 mb-1">{lbl}</label>
            <input
                type={type}
                value={(form[id] as string) || ''}
                onChange={e => setForm(prev => ({ ...prev, [id]: e.target.value }))}
                placeholder={placeholder}
                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-moss-400 focus:border-moss-400 transition-colors"
            />
        </div>
    );

    return (
        <div className="fixed inset-0 z-[99999] flex items-center justify-center p-4 bg-black/60" onClick={onClose}>
            <div
                className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden"
                onClick={e => e.stopPropagation()}
            >
                <div className="bg-moss-800 text-white px-5 py-4 flex items-center justify-between">
                    <div>
                        <h3 className="font-bold text-base">Editar {label}</h3>
                        <p className="text-[11px] text-white/60 mt-0.5">ID: {client.id}</p>
                    </div>
                    <button
                        onClick={onClose}
                        className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors"
                    >
                        <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                    </button>
                </div>

                <div className="p-5 overflow-y-auto max-h-[70vh]">
                    <div className="grid grid-cols-2 gap-4">
                        <div className="col-span-2">
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Nome / Razão Social *</label>
                            <input
                                type="text"
                                value={form.name}
                                onChange={e => setForm(prev => ({ ...prev, name: e.target.value }))}
                                placeholder="Nome completo ou razão social"
                                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-moss-400 focus:border-moss-400 transition-colors"
                            />
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Tipo</label>
                            <select
                                value={form.type}
                                onChange={e => setForm(prev => ({ ...prev, type: e.target.value as 'FISICA' | 'JURIDICA' }))}
                                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-moss-400"
                            >
                                <option value="FISICA">Pessoa Física</option>
                                <option value="JURIDICA">Pessoa Jurídica</option>
                            </select>
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-gray-600 mb-1">{form.type === 'JURIDICA' ? 'CNPJ' : 'CPF'}</label>
                            <input
                                type="text"
                                value={form.document}
                                onChange={e => setForm(prev => ({ ...prev, document: e.target.value }))}
                                placeholder={form.type === 'JURIDICA' ? '00.000.000/0000-00' : '000.000.000-00'}
                                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-moss-400"
                            />
                        </div>

                        {field('phone', 'Telefone / WhatsApp', '(00) 00000-0000', 'text', true)}
                        {field('email', 'E-mail', 'email@exemplo.com', 'email', true)}

                        <div className="col-span-2">
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Endereço</label>
                            <input
                                type="text"
                                value={form.address || ''}
                                onChange={e => setForm(prev => ({ ...prev, address: e.target.value }))}
                                placeholder="Rua, Av..."
                                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-moss-400"
                            />
                        </div>

                        {field('number', 'Número', '000', 'text', true)}
                        {field('complement', 'Complemento', 'Apto, Sala...', 'text', true)}
                        {field('district', 'Bairro', '', 'text', true)}
                        {field('city', 'Cidade', '', 'text', true)}

                        <div>
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Estado</label>
                            <input
                                type="text"
                                maxLength={2}
                                value={form.state || ''}
                                onChange={e => setForm(prev => ({ ...prev, state: e.target.value.toUpperCase() }))}
                                placeholder="SP"
                                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-moss-400"
                            />
                        </div>

                        <div>
                            <label className="block text-xs font-semibold text-gray-600 mb-1">CEP</label>
                            <input
                                type="text"
                                value={form.cep || ''}
                                onChange={e => setForm(prev => ({ ...prev, cep: e.target.value }))}
                                placeholder="00000-000"
                                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-moss-400"
                            />
                        </div>

                        <div className="col-span-2">
                            <label className="block text-xs font-semibold text-gray-600 mb-1">Observações</label>
                            <textarea
                                value={form.notes || ''}
                                onChange={e => setForm(prev => ({ ...prev, notes: e.target.value }))}
                                rows={3}
                                placeholder="Informações adicionais..."
                                className="w-full rounded-lg border border-gray-200 px-3 py-2 text-sm outline-none focus:ring-2 focus:ring-moss-400 resize-none"
                            />
                        </div>
                    </div>
                </div>

                <div className="px-5 pb-5 flex gap-3">
                    <button
                        onClick={onClose}
                        className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-600 hover:bg-gray-50 transition-colors"
                    >
                        Cancelar
                    </button>
                    <button
                        onClick={handleSave}
                        disabled={!form.name.trim() || saving}
                        className="flex-1 py-2.5 bg-moss-700 text-white rounded-xl text-sm font-bold hover:bg-moss-800 transition-colors shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                        {saving ? 'Salvando...' : 'Salvar Alterações'}
                    </button>
                </div>
            </div>
        </div>
    );
};

export default EditPartnerModal;

import React, { useState, useMemo, useEffect, useCallback } from 'react';
import { createPortal } from 'react-dom';
import { Client, Collaborator, Admission, Bank, NegotiationRecord, NegotiationContact, NegotiationProposal, NegotiationGoal, NegotiationStatus, NegotiationContactChannel, NegotiationContactResponse, NegotiationProposalStatus, AuditLog, TitleStatus, FinancialRecord } from '../../types';
import AuditLogButton from '../ui/AuditLogButton';
import AdmissionViewerModal from '../ui/AdmissionViewerModal';
import ConfirmDeleteModal from '../ui/ConfirmDeleteModal';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { formatCurrencyBRL, parseCurrencyBRL } from '../../utils/currencyUtils';
import { api, ApiError } from '../../services/apiService';
import BlockedClientBanner from '../ui/BlockedClientBanner';
import { useKeyboardShortcut } from '../../contexts/KeyboardShortcutContext';

type ReceivableTitle = Pick<FinancialRecord, 'id' | 'description' | 'value' | 'status' | 'clientId' | 'clientName' | 'issueDate' | 'dueDate' | 'originalValue' | 'currentBalance' | 'documentNumber' | 'type' | 'collectionStatus' | 'assignedCollaboratorId'>;

interface NegotiationPanelProps {
    clients: Client[];
    collaborators: Collaborator[];
    admissions: Admission[];
    banks: Bank[];
    currentCollaboratorId?: string;
    receivableTitles?: ReceivableTitle[];
    auditLogs?: AuditLog[];
    isAdmin?: boolean;
    onBack?: () => void;
    GotalkConversationsTab?: React.ComponentType<{ clientId: string }>;
}

const genId = () => Date.now().toString(36) + Math.random().toString(36).substr(2, 5);

const fmtDate = (d: string) => {
    if (!d) return '—';
    const parts = d.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return d;
};

const todayStr = () => new Date().toISOString().split('T')[0];

const statusColors: Record<NegotiationStatus, string> = {
    ABERTA: 'bg-blue-100 text-blue-800',
    EM_ANDAMENTO: 'bg-amber-100 text-amber-800',
    ACORDO_FECHADO: 'bg-green-100 text-green-800',
    ACORDO_QUEBRADO: 'bg-red-100 text-red-800',
    CANCELADA: 'bg-gray-100 text-gray-800',
    ENCERRADA: 'bg-slate-100 text-slate-800',
};

const statusLabels: Record<NegotiationStatus, string> = {
    ABERTA: 'Aberta',
    EM_ANDAMENTO: 'Em Andamento',
    ACORDO_FECHADO: 'Acordo Fechado',
    ACORDO_QUEBRADO: 'Acordo Quebrado',
    CANCELADA: 'Cancelada',
    ENCERRADA: 'Encerrada',
};

const proposalStatusColors: Record<NegotiationProposalStatus, string> = {
    ENVIADA: 'bg-blue-100 text-blue-800',
    EM_ANALISE: 'bg-amber-100 text-amber-800',
    ACEITA: 'bg-green-100 text-green-800',
    RECUSADA: 'bg-red-100 text-red-800',
    CONTRA_PROPOSTA: 'bg-purple-100 text-purple-800',
    EXPIRADA: 'bg-gray-100 text-gray-600',
    CANCELADA: 'bg-gray-100 text-gray-800',
};

const proposalStatusLabels: Record<NegotiationProposalStatus, string> = {
    ENVIADA: 'Enviada',
    EM_ANALISE: 'Em Análise',
    ACEITA: 'Aceita',
    RECUSADA: 'Recusada',
    CONTRA_PROPOSTA: 'Contra-Proposta',
    EXPIRADA: 'Expirada',
    CANCELADA: 'Cancelada',
};

const channelLabels: Record<NegotiationContactChannel, string> = {
    TELEFONE: 'Telefone',
    WHATSAPP: 'WhatsApp',
    EMAIL: 'E-mail',
    SMS: 'SMS',
    PRESENCIAL: 'Presencial',
    CARTA: 'Carta',
};

const responseLabels: Record<NegotiationContactResponse, string> = {
    ATENDEU: 'Atendeu',
    NAO_ATENDEU: 'Não Atendeu',
    RECADO: 'Recado',
    CAIXA_POSTAL: 'Caixa Postal',
    RECUSOU: 'Recusou',
    INTERESSADO: 'Interessado',
    SEM_RESPOSTA: 'Sem Resposta',
};

const responseColors: Record<NegotiationContactResponse, string> = {
    ATENDEU: 'bg-green-400',
    NAO_ATENDEU: 'bg-red-400',
    RECADO: 'bg-yellow-400',
    CAIXA_POSTAL: 'bg-gray-400',
    RECUSOU: 'bg-red-600',
    INTERESSADO: 'bg-emerald-500',
    SEM_RESPOSTA: 'bg-gray-300',
};

const titleStatusLabel = (status: string) => {
    const labels: Record<string, string> = { 'ABERTO': 'Em Aberto', 'PAGO': 'Liquidado', 'PARCIAL': 'Parcial', 'CANCELADO': 'Cancelado', 'AGRUPADO': 'Fatura Gerada', 'ADIANTAMENTO': 'Adiantamento', 'ADIANTAMENTO_PARCIAL': 'Adiant. Parcial', 'DEVOLUCAO': 'Devolução', 'DEVOLUCAO_VINCULADA': 'Dev. Vinculada', 'DEVOLUCAO_PARCIAL': 'Dev. Parcial', 'PROTESTADO': 'Protestado', 'PROVISAO': 'Provisão' };
    return labels[status] || status;
};

const titleStatusColor = (status: string) => {
    const colors: Record<string, string> = { 'ABERTO': 'bg-blue-100 text-blue-800', 'PAGO': 'bg-green-100 text-green-800', 'PARCIAL': 'bg-amber-100 text-amber-800', 'CANCELADO': 'bg-gray-100 text-gray-600', 'AGRUPADO': 'bg-purple-100 text-purple-800', 'ADIANTAMENTO': 'bg-orange-100 text-orange-800', 'DEVOLUCAO': 'bg-red-100 text-red-800', 'PROTESTADO': 'bg-red-200 text-red-900', 'PROVISAO': 'bg-yellow-100 text-yellow-800' };
    return colors[status] || 'bg-gray-100 text-gray-600';
};


const NegotiationPanel: React.FC<NegotiationPanelProps> = ({ clients, collaborators, admissions, banks, currentCollaboratorId, receivableTitles = [], auditLogs = [], isAdmin, onBack, GotalkConversationsTab }) => {
    const { addToast, currentUser, temPermissao, validarPermissao } = useSecurity();
    const { logTransaction } = useAudit();
    const { registerFormActions, unregisterFormActions } = useKeyboardShortcut();
    const canExcluir = isAdmin || temPermissao('fin_negociacao:EXCLUIR');

    const [deleteModal, setDeleteModal] = useState<{ title: string; message: string; onConfirm: () => Promise<void> } | null>(null);
    const [deleteLoading, setDeleteLoading] = useState(false);

    const handleDeleteConfirmed = useCallback(async () => {
        if (!deleteModal) return;
        setDeleteLoading(true);
        try {
            await deleteModal.onConfirm();
        } catch {
            // error toast already shown inside onConfirm
        } finally {
            setDeleteLoading(false);
            setDeleteModal(null);
        }
    }, [deleteModal]);

    const [activeTab, setActiveTab] = useState<'NEGOCIACOES' | 'DASHBOARD' | 'PERFORMANCE'>('NEGOCIACOES');
    const [records, setRecords] = useState<NegotiationRecord[]>([]);
    const [goals, setGoals] = useState<NegotiationGoal[]>([]);
    const [isLoadingRecords, setIsLoadingRecords] = useState(true);

    const loadRecords = useCallback(async () => {
        try {
            const data = await api.get('/api/negotiations');
            setRecords(data);
        } catch { }
        setIsLoadingRecords(false);
    }, []);

    const loadGoals = useCallback(async () => {
        try {
            const data = await api.get('/api/negotiation-goals');
            setGoals(data);
        } catch { }
    }, []);

    useEffect(() => { loadRecords(); loadGoals(); }, [loadRecords, loadGoals]);

    const [showCardsFilters, setShowCardsFilters] = useState(false);
    const [filterClient, setFilterClient] = useState('');
    const [filterStatus, setFilterStatus] = useState('');
    const [receivableSearch, setReceivableSearch] = useState('');
    const [filterCollaborator, setFilterCollaborator] = useState('');
    const [filterDateStart, setFilterDateStart] = useState('');
    const [filterDateEnd, setFilterDateEnd] = useState('');
    const [sortColumn, setSortColumn] = useState('date');
    const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');

    const [showCreateModal, setShowCreateModal] = useState(false);
    const [showFichaModal, setShowFichaModal] = useState(false);
    const [selectedRecord, setSelectedRecord] = useState<NegotiationRecord | null>(null);
    const [fichaTab, setFichaTab] = useState<'DADOS' | 'CONTATOS' | 'PROPOSTAS' | 'METAS' | 'WHATSAPP'>('DADOS');
    const [showClientPanel, setShowClientPanel] = useState(false);
    const [clientPanelTab, setClientPanelTab] = useState<'DADOS' | 'TITULOS' | 'ADMISSOES'>('DADOS');
    const [viewingAdmission, setViewingAdmission] = useState<Admission | null>(null);
    const [loadingAdmissionId, setLoadingAdmissionId] = useState<string | null>(null);
    const [isFullscreen, setIsFullscreen] = useState(false);

    const handleViewFullAdmission = useCallback(async (adm: Admission) => {
        setLoadingAdmissionId(adm.id);
        try {
            const json = await api.get<{ data: Admission }>(`/api/admissions/${adm.id}`);
            setViewingAdmission(json.data ?? adm);
        } catch (err: unknown) {
            if (err instanceof ApiError && err.status === 403) {
                addToast('error', 'Acesso negado', 'Sem permissão para visualizar esta Ficha de Admissão.');
                return;
            }
            setViewingAdmission(adm);
        } finally {
            setLoadingAdmissionId(null);
        }
    }, [addToast]);

    const [newClientId, setNewClientId] = useState('');
    const [newAdmissionId, setNewAdmissionId] = useState('');
    const [newCollaboratorId, setNewCollaboratorId] = useState('');
    const [newNotes, setNewNotes] = useState('');

    const [contactDate, setContactDate] = useState(todayStr());
    const [contactTime, setContactTime] = useState('');
    const [contactChannel, setContactChannel] = useState<NegotiationContactChannel>('TELEFONE');
    const [contactResponse, setContactResponse] = useState<NegotiationContactResponse>('ATENDEU');
    const [contactDescription, setContactDescription] = useState('');
    const [contactNextDate, setContactNextDate] = useState('');
    const [contactNextDesc, setContactNextDesc] = useState('');

    const [proposalDiscount, setProposalDiscount] = useState(0);
    const [proposalInstallments, setProposalInstallments] = useState(1);
    const [proposalEntry, setProposalEntry] = useState('');
    const [proposalNotes, setProposalNotes] = useState('');

    const [dashboardClientId, setDashboardClientId] = useState('');
    const [perfMonth, setPerfMonth] = useState(String(new Date().getMonth() + 1).padStart(2, '0'));
    const [perfYear, setPerfYear] = useState(String(new Date().getFullYear()));

    const [goalTargetValue, setGoalTargetValue] = useState('');
    const [goalTargetCount, setGoalTargetCount] = useState('');

    const [editContact, setEditContact] = useState<NegotiationContact | null>(null);
    const [editContactDate, setEditContactDate] = useState('');
    const [editContactTime, setEditContactTime] = useState('');
    const [editContactChannel, setEditContactChannel] = useState<NegotiationContactChannel>('TELEFONE');
    const [editContactResponse, setEditContactResponse] = useState<NegotiationContactResponse>('ATENDEU');
    const [editContactDescription, setEditContactDescription] = useState('');
    const [editContactNextDate, setEditContactNextDate] = useState('');
    const [editContactNextDesc, setEditContactNextDesc] = useState('');

    const [editProposal, setEditProposal] = useState<NegotiationProposal | null>(null);
    const [editProposalDiscount, setEditProposalDiscount] = useState(0);
    const [editProposalInstallments, setEditProposalInstallments] = useState(1);
    const [editProposalEntry, setEditProposalEntry] = useState('');
    const [editProposalNotes, setEditProposalNotes] = useState('');
    const [editProposalStatus, setEditProposalStatus] = useState<NegotiationProposalStatus>('ENVIADA');

    const handleCurrencyInputLTR = (rawInput: string, setter: (v: string) => void) => {
        let val = rawInput.replace(/^R\$\s*/, '');
        val = val.replace(/\./g, '');
        const parts = val.split(',');
        let intPart = parts[0].replace(/\D/g, '');
        let decPart = parts.length > 1 ? parts[1].replace(/\D/g, '').slice(0, 2) : undefined;
        if (intPart) {
            intPart = intPart.replace(/^0+(?=\d)/, '');
            intPart = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, '.');
        }
        let formatted = intPart;
        if (decPart !== undefined) formatted += ',' + decPart;
        setter(formatted);
    };

    const fmtMoney = (val: string | number) => {
        const f = formatCurrencyBRL(val);
        return f ? 'R$ ' + f : '';
    };

    const getBankName = (bankId?: string) => banks.find(b => b.id === bankId)?.name || '—';
    const getAdmission = (admId?: string) => admissions.find(a => a.id === admId);
    const getCollaboratorName = (id: string) => collaborators.find(c => c.id === id)?.name || '—';

    const visibleReceivables = useMemo(() => {
        const normalize = (s: string) => s.toLowerCase().replace(/[\.\-\/\(\)\s]/g, '');
        const term = normalize(receivableSearch);
        return receivableTitles.filter(t => {
            if (t.collectionStatus === 'NAO_COBRAR') return false;
            if (t.status === 'CANCELADO' || t.status === 'AGRUPADO' || t.status === 'PAGO') return false;
            if (t.type !== 'PADRAO') return false;
            if (!term) return true;
            if (normalize(t.clientName).includes(term)) return true;
            const client = clients.find(c => c.id === t.clientId);
            if (client) {
                if (normalize(client.document || '').includes(term)) return true;
                if (normalize(client.phone || '').includes(term)) return true;
                if (normalize(client.phone2 || '').includes(term)) return true;
            }
            return false;
        });
    }, [receivableTitles, receivableSearch, clients]);

    const filteredRecords = useMemo(() => {
        let data = [...records];
        if (filterClient) data = data.filter(r => r.clientName.toLowerCase().includes(filterClient.toLowerCase()));
        if (filterStatus) data = data.filter(r => r.status === filterStatus);
        if (filterCollaborator) data = data.filter(r => r.collaboratorId === filterCollaborator);
        if (filterDateStart) data = data.filter(r => r.date >= filterDateStart);
        if (filterDateEnd) data = data.filter(r => r.date <= filterDateEnd);
        data.sort((a, b) => {
            let vA: any = (a as any)[sortColumn];
            let vB: any = (b as any)[sortColumn];
            if (sortColumn === 'debtValue') { vA = parseCurrencyBRL(vA); vB = parseCurrencyBRL(vB); }
            if (vA < vB) return sortDirection === 'asc' ? -1 : 1;
            if (vA > vB) return sortDirection === 'asc' ? 1 : -1;
            return 0;
        });
        return data;
    }, [records, filterClient, filterStatus, filterCollaborator, filterDateStart, filterDateEnd, sortColumn, sortDirection]);

    const handleSort = (col: string) => {
        if (sortColumn === col) setSortDirection(p => p === 'asc' ? 'desc' : 'asc');
        else { setSortColumn(col); setSortDirection('asc'); }
    };
    const sortIcon = (col: string) => sortColumn !== col ? '↕' : sortDirection === 'asc' ? '↑' : '↓';

    const summaryCards = useMemo(() => {
        const total = records.length;
        const emAndamento = records.filter(r => r.status === 'EM_ANDAMENTO').length;
        const acordos = records.filter(r => r.status === 'ACORDO_FECHADO').length;
        const valorRecuperado = records.filter(r => r.status === 'ACORDO_FECHADO' && r.closedValue).reduce((s, r) => s + parseCurrencyBRL(r.closedValue!), 0);
        return { total, emAndamento, acordos, valorRecuperado };
    }, [records]);

    const nextContactClass = (dt?: string) => {
        if (!dt) return '';
        const today = new Date(); today.setHours(0, 0, 0, 0);
        const d = new Date(dt + 'T00:00:00'); d.setHours(0, 0, 0, 0);
        const diff = (d.getTime() - today.getTime()) / (1000 * 60 * 60 * 24);
        if (diff < 0) return 'bg-red-100 text-red-800 animate-pulse';
        if (diff === 0) return 'bg-amber-100 text-amber-800';
        if (diff <= 3) return 'bg-yellow-100 text-yellow-800';
        return '';
    };

    const clientAdmissions = useMemo(() => {
        if (!newClientId) return [];
        return admissions.filter(a => a.clientId === newClientId && ['APROVADA', 'FINALIZADA', 'CONCLUIDO', 'AUDITADA', 'NEGOCIAÇÃO'].includes(a.status));
    }, [newClientId, admissions]);

    const selectedAdmission = useMemo(() => admissions.find(a => a.id === newAdmissionId), [newAdmissionId, admissions]);

    const selectedBank = useMemo(() => {
        const bankId = selectedAdmission?.bankId || selectedRecord?.bankId;
        return banks.find(b => b.id === bankId);
    }, [selectedAdmission, selectedRecord, banks]);

    const isClientBlocked = (clientId: string) => {
        const client = clients.find(c => c.id === clientId);
        return client?.blocked === true;
    };

    const handleCreateNegotiation = async () => {
        if (!newClientId || !newCollaboratorId) {
            addToast('warning', 'Validação', 'Preencha todos os campos obrigatórios.');
            return;
        }
        if (isClientBlocked(newClientId)) {
            addToast('warning', 'Cliente Bloqueado', 'Cliente bloqueado — somente consulta. Não é possível criar negociação.');
            return;
        }
        const adm = newAdmissionId ? admissions.find(a => a.id === newAdmissionId) : undefined;
        const collab = collaborators.find(c => c.id === newCollaboratorId);
        const client = clients.find(c => c.id === newClientId);
        if (!collab || !client) return;
        try {
            const payload = {
                date: todayStr(),
                clientId: client.id,
                clientName: client.name,
                admissionId: adm?.id,
                bankId: adm?.bankId,
                collaboratorId: collab.id,
                collaboratorName: collab.name,
                status: 'ABERTA',
                debtValue: adm ? formatCurrencyBRL(parseCurrencyBRL(adm.financedAmount) || 0) : '',
                notes: newNotes,
            };
            const data = await api.post('/api/negotiations', payload);
            logTransaction('NEGOCIACAO', data.id, null, data);
            setRecords(prev => [...prev, data]);
            addToast('success', 'Sucesso', 'Negociação criada com sucesso.');
        } catch {
            addToast('error', 'Erro', 'Não foi possível criar a negociação.');
        }
        setShowCreateModal(false);
        setNewClientId('');
        setNewAdmissionId('');
        setNewCollaboratorId('');
        setNewNotes('');
    };

    useEffect(() => {
        if (showCreateModal) {
            registerFormActions(handleCreateNegotiation, () => setShowCreateModal(false));
        } else if (showFichaModal) {
            registerFormActions(undefined, () => setShowFichaModal(false));
        } else {
            unregisterFormActions();
        }
        return () => unregisterFormActions();
    }, [showCreateModal, showFichaModal]);

    const openFicha = (rec: NegotiationRecord) => {
        setSelectedRecord(rec);
        setFichaTab('DADOS');
        setShowFichaModal(true);
    };

    const handleReceivableDoubleClick = (title: ReceivableTitle) => {
        setNewClientId(title.clientId);
        setNewAdmissionId('');
        setNewCollaboratorId('');
        setNewNotes('');
        setShowCreateModal(true);
    };

    const applyRecord = (updated: NegotiationRecord) => {
        setRecords(prev => prev.map(r => r.id === updated.id ? updated : r));
        setSelectedRecord(updated);
    };

    const handleDeleteRecord = (recId: string) => {
        if (!validarPermissao('fin_negociacao:EXCLUIR')) return;
        const recordToDelete = records.find(r => r.id === recId);
        setDeleteModal({
            title: 'Excluir Negociação',
            message: 'Excluir esta negociação? Esta ação não pode ser desfeita.',
            onConfirm: async () => {
                try {
                    await api.delete(`/api/negotiations/${recId}`);
                    logTransaction('NEGOCIACAO', recId, recordToDelete || { id: recId }, null);
                    setRecords(prev => prev.filter(r => r.id !== recId));
                    addToast('success', 'Excluído', 'Negociação excluída com sucesso.');
                } catch {
                    addToast('error', 'Erro', 'Não foi possível excluir a negociação.');
                }
            },
        });
    };

    const handleDeleteContact = (contactId: string) => {
        if (!selectedRecord) return;
        if (!validarPermissao('fin_negociacao:EXCLUIR')) return;
        const recordId = selectedRecord.id;
        const before = { ...selectedRecord };
        setDeleteModal({
            title: 'Excluir Contato',
            message: 'Excluir este registro de contato?',
            onConfirm: async () => {
                try {
                    const data = await api.delete(`/api/negotiations/${recordId}/contacts/${contactId}`);
                    logTransaction('NEGOCIACAO', recordId, before, data);
                    applyRecord(data);
                    addToast('success', 'Excluído', 'Contato excluído.');
                } catch {
                    addToast('error', 'Erro', 'Não foi possível excluir o contato.');
                }
            },
        });
    };

    const handleDeleteProposal = (proposalId: string) => {
        if (!selectedRecord) return;
        if (!validarPermissao('fin_negociacao:EXCLUIR')) return;
        const recordId = selectedRecord.id;
        const before = { ...selectedRecord };
        setDeleteModal({
            title: 'Excluir Proposta',
            message: 'Excluir esta proposta?',
            onConfirm: async () => {
                try {
                    const data = await api.delete(`/api/negotiations/${recordId}/proposals/${proposalId}`);
                    logTransaction('NEGOCIACAO', recordId, before, data);
                    applyRecord(data);
                    addToast('success', 'Excluído', 'Proposta excluída.');
                } catch {
                    addToast('error', 'Erro', 'Não foi possível excluir a proposta.');
                }
            },
        });
    };

    const handleAddContact = async () => {
        if (!selectedRecord || !contactDescription) {
            addToast('warning', 'Validação', 'Preencha a descrição do contato.');
            return;
        }
        if (isClientBlocked(selectedRecord.clientId)) {
            addToast('warning', 'Cliente Bloqueado', 'Cliente bloqueado — somente consulta. Não é possível adicionar contato.');
            return;
        }
        const collabId = currentCollaboratorId || selectedRecord.collaboratorId;
        const beforeContact = { ...selectedRecord };
        try {
            const data = await api.post(`/api/negotiations/${selectedRecord.id}/contacts`, {
                date: contactDate,
                time: contactTime,
                channel: contactChannel,
                response: contactResponse,
                description: contactDescription,
                nextActionDate: contactNextDate || undefined,
                nextActionDescription: contactNextDesc || undefined,
                collaboratorId: collabId,
                collaboratorName: getCollaboratorName(collabId),
            });
            logTransaction('NEGOCIACAO', selectedRecord.id, beforeContact, data);
            applyRecord(data);
            addToast('success', 'Sucesso', 'Contato registrado.');
        } catch {
            addToast('error', 'Erro', 'Não foi possível registrar o contato.');
        }
        setContactDescription('');
        setContactNextDate('');
        setContactNextDesc('');
        setContactTime('');
    };

    const openEditContact = (c: NegotiationContact) => {
        setEditContact(c);
        setEditContactDate(c.date);
        setEditContactTime(c.time);
        setEditContactChannel(c.channel);
        setEditContactResponse(c.response);
        setEditContactDescription(c.description);
        setEditContactNextDate(c.nextActionDate || '');
        setEditContactNextDesc(c.nextActionDescription || '');
    };

    const handleSaveEditContact = async () => {
        if (!selectedRecord || !editContact || !editContactDescription) {
            addToast('warning', 'Validação', 'Preencha a descrição do contato.');
            return;
        }
        try {
            const data = await api.put(`/api/negotiations/${selectedRecord.id}/contacts/${editContact.id}`, {
                date: editContactDate,
                time: editContactTime,
                channel: editContactChannel,
                response: editContactResponse,
                description: editContactDescription,
                nextActionDate: editContactNextDate || null,
                nextActionDescription: editContactNextDesc || null,
            });
            logTransaction('NEGOCIACAO', selectedRecord.id, selectedRecord, data);
            applyRecord(data);
            addToast('success', 'Sucesso', 'Contato atualizado.');
            setEditContact(null);
        } catch {
            addToast('error', 'Erro', 'Não foi possível atualizar o contato.');
        }
    };

    const handleAddProposal = async () => {
        if (!selectedRecord) return;
        if (isClientBlocked(selectedRecord.clientId)) {
            addToast('warning', 'Cliente Bloqueado', 'Cliente bloqueado — somente consulta. Não é possível adicionar proposta.');
            return;
        }
        const originalVal = parseCurrencyBRL(selectedRecord.debtValue);
        const discountedVal = originalVal * (1 - proposalDiscount / 100);
        const entryVal = proposalEntry ? parseCurrencyBRL(proposalEntry) : 0;
        const remaining = discountedVal - entryVal;
        const installmentVal = proposalInstallments > 0 ? remaining / proposalInstallments : remaining;
        const collabId = currentCollaboratorId || selectedRecord.collaboratorId;
        const beforeProposal = { ...selectedRecord };
        try {
            const data = await api.post(`/api/negotiations/${selectedRecord.id}/proposals`, {
                date: todayStr(),
                originalValue: selectedRecord.debtValue,
                discountPercentage: proposalDiscount,
                discountedValue: formatCurrencyBRL(discountedVal),
                installments: proposalInstallments,
                installmentValue: formatCurrencyBRL(installmentVal),
                entryValue: proposalEntry || undefined,
                status: 'ENVIADA',
                notes: proposalNotes || undefined,
                collaboratorId: collabId,
                collaboratorName: getCollaboratorName(collabId),
            });
            logTransaction('NEGOCIACAO', selectedRecord.id, beforeProposal, data);
            applyRecord(data);
            addToast('success', 'Sucesso', 'Proposta registrada.');
        } catch {
            addToast('error', 'Erro', 'Não foi possível registrar a proposta.');
        }
        setProposalDiscount(0);
        setProposalInstallments(1);
        setProposalEntry('');
        setProposalNotes('');
    };

    const handleUpdateProposalStatus = async (proposalId: string, newStatus: NegotiationProposalStatus) => {
        if (!selectedRecord) return;
        const proposal = selectedRecord.proposals.find(p => p.id === proposalId);
        if (!proposal) return;
        try {
            const payload: Partial<NegotiationProposal> & { responseDate?: string } = { status: newStatus, responseDate: todayStr() };
            if (newStatus === 'ACEITA') {
                payload.discountedValue = proposal.discountedValue;
                payload.installments = proposal.installments;
            }
            const data = await api.put(`/api/negotiations/${selectedRecord.id}/proposals/${proposalId}`, payload);
            applyRecord(data);
            if (newStatus === 'ACEITA') {
                addToast('success', 'Acordo Fechado', 'Proposta aceita e acordo registrado.');
            } else {
                addToast('info', 'Atualizado', `Status da proposta alterado para ${proposalStatusLabels[newStatus]}.`);
            }
        } catch {
            addToast('error', 'Erro', 'Não foi possível atualizar a proposta.');
        }
    };

    const handleUpdateNegotiationStatus = async (newStatus: NegotiationStatus) => {
        if (!selectedRecord) return;
        if (isClientBlocked(selectedRecord.clientId)) {
            addToast('warning', 'Cliente Bloqueado', 'Cliente bloqueado — somente consulta. Não é possível alterar status.');
            return;
        }
        try {
            const extra: Partial<NegotiationRecord> = { status: newStatus };
            if (newStatus === 'CANCELADA' || newStatus === 'ENCERRADA') extra.closedDate = todayStr();
            const data = await api.put(`/api/negotiations/${selectedRecord.id}`, { ...selectedRecord, ...extra });
            applyRecord(data);
            addToast('success', 'Atualizado', `Status alterado para ${statusLabels[newStatus]}.`);
        } catch {
            addToast('error', 'Erro', 'Não foi possível atualizar o status.');
        }
    };

    const handleSaveEditProposal = async () => {
        if (!selectedRecord || !editProposal) return;
        const originalRecord = { ...selectedRecord };
        const originalVal = parseCurrencyBRL(selectedRecord.debtValue);
        const discountedVal = originalVal * (1 - editProposalDiscount / 100);
        const entryVal = editProposalEntry ? parseCurrencyBRL(editProposalEntry) : 0;
        const remaining = discountedVal - entryVal;
        const installmentVal = editProposalInstallments > 0 ? remaining / editProposalInstallments : remaining;
        const responseDate = editProposalStatus !== editProposal.status ? todayStr() : (editProposal.responseDate || undefined);
        try {
            const data = await api.put(`/api/negotiations/${selectedRecord.id}/proposals/${editProposal.id}`, {
                discountPercentage: editProposalDiscount,
                discountedValue: formatCurrencyBRL(discountedVal),
                installments: editProposalInstallments,
                installmentValue: formatCurrencyBRL(installmentVal),
                entryValue: editProposalEntry || null,
                notes: editProposalNotes || null,
                status: editProposalStatus,
                responseDate: responseDate || null,
            });
            logTransaction('NEGOCIACAO', selectedRecord.id, originalRecord, data);
            applyRecord(data);
            if (editProposalStatus === 'ACEITA') {
                addToast('success', 'Acordo Fechado', 'Proposta aceita e acordo registrado.');
            } else {
                addToast('success', 'Sucesso', 'Proposta atualizada.');
            }
            setEditProposal(null);
        } catch {
            addToast('error', 'Erro', 'Não foi possível atualizar a proposta.');
        }
    };

    const handleSaveGoal = async () => {
        const collabId = currentCollaboratorId || (selectedRecord?.collaboratorId);
        if (!collabId) return;
        try {
            const saved = await api.post('/api/negotiation-goals', {
                month: perfMonth,
                year: perfYear,
                collaboratorId: collabId,
                targetValue: goalTargetValue,
                targetCount: goalTargetCount,
            });
            setGoals(prev => {
                const existing = prev.find(g => g.id === saved.id);
                if (existing) return prev.map(g => g.id === saved.id ? saved : g);
                const byMonthYear = prev.find(g => g.collaboratorId === collabId && g.month === perfMonth && g.year === perfYear);
                if (byMonthYear) return prev.map(g => (g.collaboratorId === collabId && g.month === perfMonth && g.year === perfYear) ? saved : g);
                return [...prev, saved];
            });
            addToast('success', 'Sucesso', 'Meta salva.');
        } catch {
            addToast('error', 'Erro', 'Não foi possível salvar a meta.');
        }
    };

    const dashboardClient = useMemo(() => {
        if (!dashboardClientId) return null;
        return clients.find(c => c.id === dashboardClientId);
    }, [dashboardClientId, clients]);

    const dashboardData = useMemo(() => {
        if (!dashboardClientId) return null;
        const clientRecords = records.filter(r => r.clientId === dashboardClientId);
        const totalDebt = clientRecords.reduce((s, r) => s + parseCurrencyBRL(r.debtValue), 0);
        const negotiatedValue = clientRecords.filter(r => r.closedValue).reduce((s, r) => s + parseCurrencyBRL(r.closedValue!), 0);
        const recoveredValue = clientRecords.filter(r => r.status === 'ACORDO_FECHADO' && r.closedValue).reduce((s, r) => s + parseCurrencyBRL(r.closedValue!), 0);
        const recoveryPct = totalDebt > 0 ? (recoveredValue / totalDebt) * 100 : 0;

        const allContacts = clientRecords.flatMap(r => r.contacts.map(c => ({ ...c, recordId: r.id })));
        const allProposals = clientRecords.flatMap(r => r.proposals.map(p => ({ ...p, recordId: r.id })));

        const timeline: { date: string; type: 'contact' | 'proposal'; data: any }[] = [
            ...allContacts.map(c => ({ date: c.date, type: 'contact' as const, data: c })),
            ...allProposals.map(p => ({ date: p.date, type: 'proposal' as const, data: p })),
        ].sort((a, b) => a.date.localeCompare(b.date));

        const clientAdms = admissions.filter(a => a.clientId === dashboardClientId);

        return { clientRecords, totalDebt, negotiatedValue, recoveredValue, recoveryPct, timeline, allProposals, clientAdms };
    }, [dashboardClientId, records, admissions]);

    const performanceData = useMemo(() => {
        const periodRecords = records.filter(r => {
            const d = new Date(r.date);
            return String(d.getMonth() + 1).padStart(2, '0') === perfMonth && String(d.getFullYear()) === perfYear;
        });

        const acordos = periodRecords.filter(r => r.status === 'ACORDO_FECHADO');
        const totalAcordos = acordos.length;
        const totalRecords = periodRecords.length;
        const taxaConversao = totalRecords > 0 ? (totalAcordos / totalRecords) * 100 : 0;
        const totalRecuperado = acordos.reduce((s, r) => s + parseCurrencyBRL(r.closedValue || '0'), 0);
        const ticketMedio = totalAcordos > 0 ? totalRecuperado / totalAcordos : 0;
        const totalCarteira = periodRecords.reduce((s, r) => s + parseCurrencyBRL(r.debtValue), 0);
        const taxaRecuperacao = totalCarteira > 0 ? (totalRecuperado / totalCarteira) * 100 : 0;

        const collabMap = new Map<string, { name: string; carteira: number; recuperado: number; acordos: number; pontos: number }>();

        periodRecords.forEach(r => {
            if (!collabMap.has(r.collaboratorId)) {
                collabMap.set(r.collaboratorId, { name: r.collaboratorName, carteira: 0, recuperado: 0, acordos: 0, pontos: 0 });
            }
            const entry = collabMap.get(r.collaboratorId)!;
            entry.carteira += parseCurrencyBRL(r.debtValue);
            if (r.status === 'ACORDO_FECHADO' && r.closedValue) {
                entry.recuperado += parseCurrencyBRL(r.closedValue);
                entry.acordos += 1;
                const inst = r.closedInstallments || 1;
                if (inst === 1) entry.pontos += 3;
                else if (inst <= 6) entry.pontos += 2;
                else if (inst <= 12) entry.pontos += 1;
                else entry.pontos += 0.5;
            }
        });

        const ranking = Array.from(collabMap.entries())
            .map(([id, data]) => ({ id, ...data, pctAtingido: data.carteira > 0 ? (data.recuperado / data.carteira) * 100 : 0 }))
            .sort((a, b) => b.pontos - a.pontos);

        const collabGoals = goals.filter(g => g.month === perfMonth && g.year === perfYear);

        return { taxaConversao, ticketMedio, taxaRecuperacao, totalAcordos, ranking, collabGoals, totalRecuperado };
    }, [records, goals, perfMonth, perfYear]);

    const maxPontos = useMemo(() => Math.max(...performanceData.ranking.map(r => r.pontos), 1), [performanceData]);

    const fichaAdmission = useMemo(() => {
        if (!selectedRecord) return null;
        return admissions.find(a => a.id === selectedRecord.admissionId);
    }, [selectedRecord, admissions]);

    const fichaBank = useMemo(() => {
        if (!selectedRecord) return null;
        return banks.find(b => b.id === selectedRecord.bankId);
    }, [selectedRecord, banks]);

    const currentGoal = useMemo(() => {
        if (!selectedRecord) return null;
        const collabId = currentCollaboratorId || selectedRecord.collaboratorId;
        const now = new Date();
        const m = String(now.getMonth() + 1).padStart(2, '0');
        const y = String(now.getFullYear());
        return goals.find(g => g.collaboratorId === collabId && g.month === m && g.year === y);
    }, [selectedRecord, goals, currentCollaboratorId]);

    return (
        <>
        <div className={isFullscreen ? "fixed inset-0 z-[9999] flex flex-col bg-white" : "h-full flex flex-col animate-fade-in"}>
            <div className="bg-moss-800 text-white px-8 py-5 flex items-center gap-4">
                {onBack && (
                    <button
                        onClick={onBack}
                        className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20 shrink-0"
                        title="Voltar"
                    >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                        Voltar
                    </button>
                )}
                <svg className="w-8 h-8 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 9V7a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2m2 4h10a2 2 0 002-2v-6a2 2 0 00-2-2H9a2 2 0 00-2 2v6a2 2 0 002 2zm7-5a2 2 0 11-4 0 2 2 0 014 0z" />
                </svg>
                <div>
                    <h2 className="text-xl font-bold tracking-wide">Negociação Financeira</h2>
                    <p className="text-moss-200 text-sm">Gestão de negociações, propostas e metas</p>
                </div>
                <button
                    onClick={() => setIsFullscreen(f => !f)}
                    className="ml-auto flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20 shrink-0"
                    title={isFullscreen ? 'Minimizar' : 'Expandir tela cheia'}
                >
                    {isFullscreen ? (
                        <>
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 9V4.5M9 9H4.5M9 9L3.75 3.75M9 15v4.5M9 15H4.5M9 15l-5.25 5.25M15 9h4.5M15 9V4.5M15 9l5.25-5.25M15 15h4.5M15 15v4.5m0-4.5l5.25 5.25" /></svg>
                            Minimizar
                        </>
                    ) : (
                        <>
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3.75 3.75v4.5m0-4.5h4.5m-4.5 0L9 9M3.75 20.25v-4.5m0 4.5h4.5m-4.5 0L9 15M20.25 3.75h-4.5m4.5 0v4.5m0-4.5L15 9m5.25 11.25h-4.5m4.5 0v-4.5m0 4.5L15 15" /></svg>
                            Expandir
                        </>
                    )}
                </button>
            </div>

            <div className="bg-white border-b border-gray-200 px-6 py-3 flex items-center gap-4">
                {(['NEGOCIACOES', 'DASHBOARD', 'PERFORMANCE'] as const).map(tab => (
                    <button key={tab} onClick={() => setActiveTab(tab)} className={`px-5 py-2 rounded-lg text-sm font-semibold transition-colors ${activeTab === tab ? 'bg-moss-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                        {tab === 'NEGOCIACOES' ? 'Negociações' : tab === 'DASHBOARD' ? 'Dashboard Cliente' : 'Performance'}
                    </button>
                ))}
            </div>

            {activeTab === 'NEGOCIACOES' && (
                <div className="flex-1 bg-gray-50 overflow-auto">
                    <div className="p-6 space-y-4">
                        <div className="flex items-center justify-between">
                            <button onClick={() => setShowCardsFilters(!showCardsFilters)} className="flex items-center gap-2 text-sm font-semibold text-moss-700 hover:text-moss-900 transition-colors">
                                <svg className={`w-4 h-4 transition-transform ${showCardsFilters ? 'rotate-90' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                                {showCardsFilters ? 'Ocultar Resumo e Filtros' : 'Exibir Resumo e Filtros'}
                            </button>
                            <button onClick={() => setShowCreateModal(true)} className="px-5 py-2.5 rounded-lg bg-moss-700 text-white text-sm font-bold hover:bg-moss-800 transition-colors shadow-sm flex items-center gap-2">
                                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                                Nova Negociação
                            </button>
                        </div>

                        {showCardsFilters && (
                            <div className="space-y-4 animate-fade-in">
                                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                                    <div className="bg-blue-50 rounded-xl p-4 border border-blue-100">
                                        <div className="flex items-center gap-2 mb-1">
                                            <svg className="w-5 h-5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" /></svg>
                                            <p className="text-xs text-blue-500 uppercase tracking-wider font-semibold">Total Negociações</p>
                                        </div>
                                        <p className="text-2xl font-bold text-blue-800">{summaryCards.total}</p>
                                    </div>
                                    <div className="bg-amber-50 rounded-xl p-4 border border-amber-100">
                                        <div className="flex items-center gap-2 mb-1">
                                            <svg className="w-5 h-5 text-amber-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                            <p className="text-xs text-amber-500 uppercase tracking-wider font-semibold">Em Andamento</p>
                                        </div>
                                        <p className="text-2xl font-bold text-amber-800">{summaryCards.emAndamento}</p>
                                    </div>
                                    <div className="bg-green-50 rounded-xl p-4 border border-green-100">
                                        <div className="flex items-center gap-2 mb-1">
                                            <svg className="w-5 h-5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                            <p className="text-xs text-green-500 uppercase tracking-wider font-semibold">Acordos Fechados</p>
                                        </div>
                                        <p className="text-2xl font-bold text-green-800">{summaryCards.acordos}</p>
                                    </div>
                                    <div className="bg-purple-50 rounded-xl p-4 border border-purple-100">
                                        <div className="flex items-center gap-2 mb-1">
                                            <svg className="w-5 h-5 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
                                            <p className="text-xs text-purple-500 uppercase tracking-wider font-semibold">Valor Recuperado</p>
                                        </div>
                                        <p className="text-2xl font-bold text-purple-800">{fmtMoney(summaryCards.valorRecuperado)}</p>
                                    </div>
                                </div>

                                <div className="flex items-center gap-3 flex-wrap">
                                    <input type="text" placeholder="Buscar cliente..." className="rounded-lg border border-gray-300 px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none w-56" value={filterClient} onChange={e => setFilterClient(e.target.value)} />
                                    <select className="rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                                        <option value="">Todos Status</option>
                                        {(Object.keys(statusLabels) as NegotiationStatus[]).map(s => <option key={s} value={s}>{statusLabels[s]}</option>)}
                                    </select>
                                    <select className="rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterCollaborator} onChange={e => setFilterCollaborator(e.target.value)}>
                                        <option value="">Todos Negociadores</option>
                                        {collaborators.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                    </select>
                                    <input type="date" className="rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterDateStart} onChange={e => setFilterDateStart(e.target.value)} />
                                    <input type="date" className="rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterDateEnd} onChange={e => setFilterDateEnd(e.target.value)} />
                                </div>
                            </div>
                        )}

                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                            <div className="overflow-x-auto">
                                <table className="min-w-full text-sm">
                                    <thead className="bg-gray-50 border-b border-gray-200">
                                        <tr>
                                            <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase cursor-pointer select-none" onClick={() => handleSort('date')}>Data {sortIcon('date')}</th>
                                            <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase cursor-pointer select-none" onClick={() => handleSort('clientName')}>Cliente {sortIcon('clientName')}</th>
                                            <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase">Contrato</th>
                                            <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase">Banco</th>
                                            <th className="px-4 py-3 text-right text-xs font-bold text-gray-500 uppercase cursor-pointer select-none" onClick={() => handleSort('debtValue')}>Valor Dívida {sortIcon('debtValue')}</th>
                                            <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase cursor-pointer select-none" onClick={() => handleSort('collaboratorName')}>Negociador {sortIcon('collaboratorName')}</th>
                                            <th className="px-4 py-3 text-center text-xs font-bold text-gray-500 uppercase cursor-pointer select-none" onClick={() => handleSort('status')}>Status {sortIcon('status')}</th>
                                            <th className="px-4 py-3 text-center text-xs font-bold text-gray-500 uppercase">Próximo Contato</th>
                                            <th className="px-4 py-3 text-center text-xs font-bold text-gray-500 uppercase">Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100">
                                        {isLoadingRecords && (
                                            <tr><td colSpan={9} className="px-4 py-12 text-center text-gray-400">Carregando negociações...</td></tr>
                                        )}
                                        {!isLoadingRecords && filteredRecords.length === 0 && (
                                            <tr><td colSpan={9} className="px-4 py-12 text-center text-gray-400">Nenhuma negociação encontrada.</td></tr>
                                        )}
                                        {filteredRecords.map(rec => {
                                            const adm = getAdmission(rec.admissionId);
                                            return (
                                                <tr key={rec.id} className="hover:bg-gray-50 cursor-pointer transition-colors" onClick={() => openFicha(rec)}>
                                                    <td className="px-4 py-3 whitespace-nowrap text-gray-700">{fmtDate(rec.date)}</td>
                                                    <td className="px-4 py-3 whitespace-nowrap font-semibold text-gray-900"><span className="flex items-center gap-1.5">{rec.clientName}{(() => { const cl = clients.find(c => c.id === rec.clientId); return cl?.blocked ? <BlockedClientBanner client={cl} compact /> : null; })()}</span></td>
                                                    <td className="px-4 py-3 whitespace-nowrap text-gray-600 font-mono">{adm?.contractNumber || '—'}</td>
                                                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{getBankName(rec.bankId)}</td>
                                                    <td className="px-4 py-3 whitespace-nowrap text-right font-semibold text-gray-900">{fmtMoney(rec.debtValue)}</td>
                                                    <td className="px-4 py-3 whitespace-nowrap text-gray-600">{rec.collaboratorName}</td>
                                                    <td className="px-4 py-3 whitespace-nowrap text-center">
                                                        <span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase ${statusColors[rec.status]}`}>{statusLabels[rec.status]}</span>
                                                    </td>
                                                    <td className="px-4 py-3 whitespace-nowrap text-center">
                                                        {rec.nextContactDate ? (
                                                            <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${nextContactClass(rec.nextContactDate)}`}>{fmtDate(rec.nextContactDate)}</span>
                                                        ) : '—'}
                                                    </td>
                                                    <td className="px-4 py-3 whitespace-nowrap text-center" onClick={e => e.stopPropagation()}>
                                                        <div className="flex justify-center items-center gap-2">
                                                            <AuditLogButton entityId={rec.id} entityName={rec.clientName || rec.id} logs={auditLogs} />
                                                            <button onClick={() => openFicha(rec)} className="text-moss-600 hover:text-moss-800 font-semibold text-xs">Abrir</button>
                                                            {canExcluir && (
                                                                <button onClick={() => handleDeleteRecord(rec.id)} className="text-red-500 hover:text-red-700 font-semibold text-xs">Excluir</button>
                                                            )}
                                                        </div>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                            <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100 flex-wrap gap-2">
                                <div className="flex items-center gap-3">
                                    <div className="w-2 h-6 rounded-full bg-blue-500"></div>
                                    <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Títulos a Receber Disponíveis para Negociação</span>
                                    <span className="text-xs text-gray-400 font-semibold">({visibleReceivables.length})</span>
                                </div>
                                <div className="relative">
                                    <svg className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-gray-400 pointer-events-none" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0z" /></svg>
                                    <input
                                        type="text"
                                        placeholder="Nome, CPF/CNPJ, telefone..."
                                        className="pl-8 pr-3 py-1.5 border border-gray-200 rounded-lg text-xs focus:ring-2 focus:ring-blue-400 focus:border-blue-400 outline-none w-56 bg-white"
                                        value={receivableSearch}
                                        onChange={e => setReceivableSearch(e.target.value)}
                                    />
                                </div>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="min-w-full text-sm">
                                    <thead className="bg-gray-50 border-b border-gray-200">
                                        <tr>
                                            <th className="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase">Cliente</th>
                                            <th className="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase">Descrição</th>
                                            <th className="px-4 py-2.5 text-left text-xs font-bold text-gray-500 uppercase">Documento</th>
                                            <th className="px-4 py-2.5 text-center text-xs font-bold text-gray-500 uppercase">Emissão</th>
                                            <th className="px-4 py-2.5 text-center text-xs font-bold text-gray-500 uppercase">Vencimento</th>
                                            <th className="px-4 py-2.5 text-right text-xs font-bold text-gray-500 uppercase">Valor Original</th>
                                            <th className="px-4 py-2.5 text-right text-xs font-bold text-gray-500 uppercase">Saldo</th>
                                            <th className="px-4 py-2.5 text-center text-xs font-bold text-gray-500 uppercase">Status</th>
                                            <th className="px-4 py-2.5 text-center text-xs font-bold text-gray-500 uppercase">Cobrança</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-100">
                                        {visibleReceivables.length === 0 && (
                                            <tr><td colSpan={9} className="px-4 py-8 text-center text-gray-400">Nenhum título disponível.</td></tr>
                                        )}
                                        {visibleReceivables.map(t => {
                                            const dueDate = new Date(t.dueDate);
                                            const today = new Date();
                                            today.setHours(0, 0, 0, 0);
                                            dueDate.setHours(0, 0, 0, 0);
                                            const isOverdue = dueDate < today && t.status !== 'PAGO';
                                            return (
                                                <tr
                                                    key={t.id}
                                                    className={`cursor-pointer select-none hover:bg-blue-50/60 transition-colors ${isOverdue ? 'bg-red-50/30' : ''}`}
                                                    onDoubleClick={() => handleReceivableDoubleClick(t)}
                                                    title="Duplo clique para iniciar negociação"
                                                >
                                                    <td className="px-4 py-2.5 whitespace-nowrap font-semibold text-gray-900 text-xs">{t.clientName}</td>
                                                    <td className="px-4 py-2.5 text-gray-600 text-xs max-w-[200px] truncate">{t.description}</td>
                                                    <td className="px-4 py-2.5 whitespace-nowrap text-gray-600 text-xs font-mono">{t.documentNumber}</td>
                                                    <td className="px-4 py-2.5 whitespace-nowrap text-center text-gray-600 text-xs">{fmtDate(t.issueDate)}</td>
                                                    <td className={`px-4 py-2.5 whitespace-nowrap text-center text-xs ${isOverdue ? 'text-red-600 font-bold' : 'text-gray-600'}`}>{fmtDate(t.dueDate)}</td>
                                                    <td className="px-4 py-2.5 whitespace-nowrap text-right text-gray-700 text-xs">{fmtMoney(t.originalValue)}</td>
                                                    <td className="px-4 py-2.5 whitespace-nowrap text-right font-semibold text-xs text-blue-700">{fmtMoney(t.currentBalance)}</td>
                                                    <td className="px-4 py-2.5 whitespace-nowrap text-center">
                                                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${titleStatusColor(t.status)}`}>{titleStatusLabel(t.status)}</span>
                                                    </td>
                                                    <td className="px-4 py-2.5 whitespace-nowrap text-center">
                                                        <span className={`px-2 py-0.5 rounded-full text-[10px] font-semibold ${t.collectionStatus === 'COBRAR' ? 'bg-amber-100 text-amber-800' : 'bg-green-100 text-green-700'}`}>
                                                            {t.collectionStatus === 'COBRAR' ? 'Cobrar' : 'Em Dia'}
                                                        </span>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                            {visibleReceivables.length > 0 && (
                                <div className="px-5 py-3 bg-gray-50 border-t border-gray-200 flex items-center justify-between text-xs text-gray-500">
                                    <span>{visibleReceivables.length} título(s)</span>
                                    <span className="font-semibold">Saldo Total: <span className="text-blue-700">{fmtMoney(visibleReceivables.reduce((s, t) => s + t.currentBalance, 0))}</span></span>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

            {activeTab === 'DASHBOARD' && (
                <div className="flex-1 bg-gray-50 overflow-auto p-6">
                    <div className="mb-6">
                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Selecionar Cliente</label>
                        <select className="w-full max-w-md rounded-lg border border-gray-300 px-4 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={dashboardClientId} onChange={e => setDashboardClientId(e.target.value)}>
                            <option value="">Selecione um cliente...</option>
                            {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                        </select>
                    </div>

                    {dashboardClient && dashboardData && (
                        <>
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                                <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
                                    <div className="flex items-center gap-2 mb-1">
                                        <div className="w-2 h-6 rounded-full bg-red-500"></div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Dívida Total</p>
                                    </div>
                                    <p className="text-2xl font-bold text-red-700">{fmtMoney(dashboardData.totalDebt)}</p>
                                </div>
                                <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
                                    <div className="flex items-center gap-2 mb-1">
                                        <div className="w-2 h-6 rounded-full bg-blue-500"></div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Valor Negociado</p>
                                    </div>
                                    <p className="text-2xl font-bold text-blue-700">{fmtMoney(dashboardData.negotiatedValue)}</p>
                                </div>
                                <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
                                    <div className="flex items-center gap-2 mb-1">
                                        <div className="w-2 h-6 rounded-full bg-green-500"></div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Valor Recuperado</p>
                                    </div>
                                    <p className="text-2xl font-bold text-green-700">{fmtMoney(dashboardData.recoveredValue)}</p>
                                </div>
                                <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
                                    <div className="flex items-center gap-2 mb-1">
                                        <div className="w-2 h-6 rounded-full bg-purple-500"></div>
                                        <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">% Recuperação</p>
                                    </div>
                                    <p className="text-2xl font-bold text-purple-700">{dashboardData.recoveryPct.toFixed(1)}%</p>
                                </div>
                            </div>

                            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
                                <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                    <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                        <div className="w-2 h-6 rounded-full bg-moss-500"></div>
                                        <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Timeline de Ações</span>
                                    </div>
                                    <div className="p-5 max-h-96 overflow-y-auto">
                                        {dashboardData.timeline.length === 0 && <p className="text-gray-400 text-sm text-center py-8">Nenhuma ação registrada.</p>}
                                        <div className="relative">
                                            {dashboardData.timeline.length > 0 && <div className="absolute left-3 top-2 bottom-2 w-0.5 bg-gray-200"></div>}
                                            {dashboardData.timeline.map((item, idx) => (
                                                <div key={idx} className="flex gap-4 mb-4 relative">
                                                    <div className={`w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center z-10 ${item.type === 'contact' ? responseColors[item.data.response as NegotiationContactResponse] || 'bg-gray-300' : 'bg-blue-500'}`}>
                                                        {item.type === 'contact' ? (
                                                            <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                                                        ) : (
                                                            <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                                        )}
                                                    </div>
                                                    <div className="flex-1 bg-gray-50 rounded-lg p-3">
                                                        <div className="flex items-center justify-between mb-1">
                                                            <span className="text-xs font-bold text-gray-700">
                                                                {item.type === 'contact' ? `Contato — ${channelLabels[item.data.channel as NegotiationContactChannel]}` : 'Proposta'}
                                                            </span>
                                                            <span className="text-xs text-gray-400">{fmtDate(item.date)}</span>
                                                        </div>
                                                        {item.type === 'contact' ? (
                                                            <>
                                                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${item.data.response === 'ATENDEU' || item.data.response === 'INTERESSADO' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'}`}>
                                                                    {responseLabels[item.data.response as NegotiationContactResponse]}
                                                                </span>
                                                                <p className="text-xs text-gray-600 mt-1">{item.data.description}</p>
                                                            </>
                                                        ) : (
                                                            <>
                                                                <p className="text-xs text-gray-600">Valor: {item.data.discountedValue} ({item.data.discountPercentage}% desc.) — {item.data.installments}x</p>
                                                                <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${proposalStatusColors[item.data.status as NegotiationProposalStatus]}`}>
                                                                    {proposalStatusLabels[item.data.status as NegotiationProposalStatus]}
                                                                </span>
                                                            </>
                                                        )}
                                                    </div>
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>

                                <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                    <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                        <div className="w-2 h-6 rounded-full bg-blue-500"></div>
                                        <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Propostas</span>
                                    </div>
                                    <div className="overflow-x-auto">
                                        <table className="min-w-full text-sm">
                                            <thead className="bg-gray-50 border-b border-gray-200">
                                                <tr>
                                                    <th className="px-4 py-2 text-left text-xs font-bold text-gray-500 uppercase">Data</th>
                                                    <th className="px-4 py-2 text-right text-xs font-bold text-gray-500 uppercase">Valor Original</th>
                                                    <th className="px-4 py-2 text-right text-xs font-bold text-gray-500 uppercase">Desc. %</th>
                                                    <th className="px-4 py-2 text-right text-xs font-bold text-gray-500 uppercase">Valor Proposta</th>
                                                    <th className="px-4 py-2 text-center text-xs font-bold text-gray-500 uppercase">Parcelas</th>
                                                    <th className="px-4 py-2 text-center text-xs font-bold text-gray-500 uppercase">Status</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-gray-100">
                                                {dashboardData.allProposals.length === 0 && (
                                                    <tr><td colSpan={6} className="px-4 py-8 text-center text-gray-400">Nenhuma proposta.</td></tr>
                                                )}
                                                {dashboardData.allProposals.map(p => (
                                                    <tr key={p.id} className="hover:bg-gray-50">
                                                        <td className="px-4 py-2 text-gray-700">{fmtDate(p.date)}</td>
                                                        <td className="px-4 py-2 text-right text-gray-700">{fmtMoney(p.originalValue)}</td>
                                                        <td className="px-4 py-2 text-right text-gray-700">{p.discountPercentage.toFixed(1)}%</td>
                                                        <td className="px-4 py-2 text-right font-semibold text-gray-900">{p.discountedValue}</td>
                                                        <td className="px-4 py-2 text-center text-gray-700">{p.installments}x</td>
                                                        <td className="px-4 py-2 text-center">
                                                            <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${proposalStatusColors[p.status]}`}>{proposalStatusLabels[p.status]}</span>
                                                        </td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>

                            {dashboardData.clientAdms.length > 0 && (
                                <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                    <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                        <div className="w-2 h-6 rounded-full bg-purple-500"></div>
                                        <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Admissões do Cliente</span>
                                    </div>
                                    <div className="p-5 space-y-4">
                                        {dashboardData.clientAdms.map(adm => {
                                            const bank = banks.find(b => b.id === adm.bankId);
                                            return (
                                                <div key={adm.id} className="bg-gray-50 rounded-lg p-4 border border-gray-100">
                                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                                                        <div><span className="text-gray-500 text-xs">Contrato:</span><p className="font-semibold">{adm.contractNumber}</p></div>
                                                        <div><span className="text-gray-500 text-xs">Banco:</span><p className="font-semibold">{bank?.name || '—'}</p></div>
                                                        <div><span className="text-gray-500 text-xs">Valor Financiado:</span><p className="font-semibold">{fmtMoney(parseCurrencyBRL(adm.financedAmount) || 0)}</p></div>
                                                        <div><span className="text-gray-500 text-xs">Parcela:</span><p className="font-semibold">{fmtMoney(parseCurrencyBRL(adm.installmentValue) || 0)}</p></div>
                                                        <div><span className="text-gray-500 text-xs">Total Parcelas:</span><p className="font-semibold">{adm.totalInstallments}</p></div>
                                                        <div><span className="text-gray-500 text-xs">Pagas:</span><p className="font-semibold">{adm.paidInstallments}</p></div>
                                                        <div><span className="text-gray-500 text-xs">Vencidas:</span><p className="font-semibold text-red-600">{adm.overdueInstallments}</p></div>
                                                        <div><span className="text-gray-500 text-xs">Status:</span><p className="font-semibold">{adm.status}</p></div>
                                                    </div>
                                                    {bank && bank.services.length > 0 && (
                                                        <div className="mt-3 pt-3 border-t border-gray-200">
                                                            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Taxas de Negociação</p>
                                                            <div className="flex flex-wrap gap-2">
                                                                {bank.services.map(svc => (
                                                                    <span key={svc.id} className="bg-moss-50 text-moss-800 px-3 py-1 rounded-full text-xs font-semibold border border-moss-200">
                                                                        {svc.name}: {svc.negotiationPercentage}%
                                                                    </span>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    )}
                                                </div>
                                            );
                                        })}
                                    </div>
                                </div>
                            )}
                        </>
                    )}

                    {!dashboardClientId && (
                        <div className="flex items-center justify-center h-64 text-gray-400">
                            <div className="text-center">
                                <svg className="w-16 h-16 mx-auto mb-3 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                                <p className="text-sm">Selecione um cliente para visualizar o dashboard.</p>
                            </div>
                        </div>
                    )}
                </div>
            )}

            {activeTab === 'PERFORMANCE' && (
                <div className="flex-1 bg-gray-50 overflow-auto p-6">
                    <div className="flex items-center gap-4 mb-6">
                        <div>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Mês</label>
                            <select className="rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={perfMonth} onChange={e => setPerfMonth(e.target.value)}>
                                {Array.from({ length: 12 }, (_, i) => String(i + 1).padStart(2, '0')).map(m => (
                                    <option key={m} value={m}>{m}</option>
                                ))}
                            </select>
                        </div>
                        <div>
                            <label className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-1 block">Ano</label>
                            <select className="rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={perfYear} onChange={e => setPerfYear(e.target.value)}>
                                {['2024', '2025', '2026'].map(y => <option key={y} value={y}>{y}</option>)}
                            </select>
                        </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
                        <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
                            <div className="flex items-center gap-2 mb-1">
                                <div className="w-2 h-6 rounded-full bg-blue-500"></div>
                                <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Taxa de Conversão</p>
                            </div>
                            <p className="text-2xl font-bold text-blue-700">{performanceData.taxaConversao.toFixed(1)}%</p>
                        </div>
                        <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
                            <div className="flex items-center gap-2 mb-1">
                                <div className="w-2 h-6 rounded-full bg-green-500"></div>
                                <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Ticket Médio Recuperado</p>
                            </div>
                            <p className="text-2xl font-bold text-green-700">{fmtMoney(performanceData.ticketMedio)}</p>
                        </div>
                        <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
                            <div className="flex items-center gap-2 mb-1">
                                <div className="w-2 h-6 rounded-full bg-purple-500"></div>
                                <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Taxa de Recuperação</p>
                            </div>
                            <p className="text-2xl font-bold text-purple-700">{performanceData.taxaRecuperacao.toFixed(1)}%</p>
                        </div>
                        <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
                            <div className="flex items-center gap-2 mb-1">
                                <div className="w-2 h-6 rounded-full bg-amber-500"></div>
                                <p className="text-xs text-gray-500 uppercase tracking-wider font-semibold">Total Acordos</p>
                            </div>
                            <p className="text-2xl font-bold text-amber-700">{performanceData.totalAcordos}</p>
                        </div>
                    </div>

                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden mb-6">
                        <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                            <div className="w-2 h-6 rounded-full bg-moss-500"></div>
                            <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Ranking de Negociadores</span>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="min-w-full text-sm">
                                <thead className="bg-gray-50 border-b border-gray-200">
                                    <tr>
                                        <th className="px-4 py-3 text-center text-xs font-bold text-gray-500 uppercase w-12">#</th>
                                        <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase">Nome</th>
                                        <th className="px-4 py-3 text-right text-xs font-bold text-gray-500 uppercase">Carteira (R$)</th>
                                        <th className="px-4 py-3 text-right text-xs font-bold text-gray-500 uppercase">Recuperado (R$)</th>
                                        <th className="px-4 py-3 text-right text-xs font-bold text-gray-500 uppercase">% Atingido</th>
                                        <th className="px-4 py-3 text-center text-xs font-bold text-gray-500 uppercase">Acordos</th>
                                        <th className="px-4 py-3 text-center text-xs font-bold text-gray-500 uppercase">Pontos</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-100">
                                    {performanceData.ranking.length === 0 && (
                                        <tr><td colSpan={7} className="px-4 py-8 text-center text-gray-400">Nenhum dado para o período.</td></tr>
                                    )}
                                    {performanceData.ranking.map((r, idx) => (
                                        <tr key={r.id} className="hover:bg-gray-50">
                                            <td className="px-4 py-3 text-center font-bold text-gray-500">{idx + 1}º</td>
                                            <td className="px-4 py-3 font-semibold text-gray-900">{r.name}</td>
                                            <td className="px-4 py-3 text-right text-gray-700">{fmtMoney(r.carteira)}</td>
                                            <td className="px-4 py-3 text-right font-semibold text-green-700">{fmtMoney(r.recuperado)}</td>
                                            <td className="px-4 py-3 text-right text-gray-700">{r.pctAtingido.toFixed(1)}%</td>
                                            <td className="px-4 py-3 text-center text-gray-700">{r.acordos}</td>
                                            <td className="px-4 py-3 text-center font-bold text-moss-700">{r.pontos.toFixed(1)}</td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>

                    {performanceData.collabGoals.length > 0 && (
                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden mb-6">
                            <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                <div className="w-2 h-6 rounded-full bg-blue-500"></div>
                                <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Metas por Colaborador</span>
                            </div>
                            <div className="p-5 space-y-4">
                                {performanceData.collabGoals.map(g => {
                                    const target = parseCurrencyBRL(g.targetValue);
                                    const achieved = parseCurrencyBRL(g.achievedValue);
                                    const pct = target > 0 ? (achieved / target) * 100 : 0;
                                    const barColor = pct >= 80 ? 'bg-green-500' : pct >= 50 ? 'bg-amber-500' : 'bg-red-500';
                                    return (
                                        <div key={g.id} className="bg-gray-50 rounded-lg p-4">
                                            <div className="flex items-center justify-between mb-2">
                                                <span className="font-semibold text-sm text-gray-800">{getCollaboratorName(g.collaboratorId)}</span>
                                                <span className="text-xs text-gray-500">{fmtMoney(achieved)} / {fmtMoney(target)}</span>
                                            </div>
                                            <div className="w-full bg-gray-200 rounded-full h-3">
                                                <div className={`h-3 rounded-full transition-all ${barColor}`} style={{ width: `${Math.min(pct, 100)}%` }}></div>
                                            </div>
                                            <div className="flex items-center justify-between mt-1">
                                                <span className="text-xs text-gray-500">Acordos: {fmtMoney(g.achievedCount)} / {fmtMoney(g.targetCount)}</span>
                                                <span className={`text-xs font-bold ${pct >= 80 ? 'text-green-600' : pct >= 50 ? 'text-amber-600' : 'text-red-600'}`}>{pct.toFixed(1)}%</span>
                                            </div>
                                        </div>
                                    );
                                })}
                            </div>
                        </div>
                    )}

                    {performanceData.ranking.length > 0 && (
                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                            <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                <div className="w-2 h-6 rounded-full bg-purple-500"></div>
                                <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Performance por Negociador</span>
                            </div>
                            <div className="p-5 space-y-3">
                                {performanceData.ranking.map(r => (
                                    <div key={r.id} className="flex items-center gap-4">
                                        <span className="text-sm font-semibold text-gray-700 w-40 truncate">{r.name}</span>
                                        <div className="flex-1 bg-gray-100 rounded-full h-6 relative overflow-hidden">
                                            <div className="h-6 rounded-full bg-moss-500 transition-all flex items-center justify-end pr-2" style={{ width: `${maxPontos > 0 ? (r.pontos / maxPontos) * 100 : 0}%`, minWidth: r.pontos > 0 ? '2rem' : '0' }}>
                                                <span className="text-[10px] font-bold text-white">{r.pontos.toFixed(1)}</span>
                                            </div>
                                        </div>
                                        <span className="text-xs text-gray-500 w-24 text-right">{fmtMoney(r.recuperado)}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    )}
                </div>
            )}

            {showCreateModal && (
                <div className="fixed inset-0 bg-black/50 z-50">
                    <div className="bg-white w-full h-full flex flex-col overflow-hidden animate-fade-in">
                        <div className="bg-moss-800 px-6 py-4 flex items-center justify-between flex-shrink-0">
                            <div className="flex items-center gap-3">
                                <svg className="w-7 h-7 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                                <div>
                                    <h3 className="text-lg font-bold text-white tracking-wide">Nova Negociação</h3>
                                    <p className="text-xs text-white/60">Criar uma nova negociação de dívida</p>
                                </div>
                            </div>
                            <button onClick={() => setShowCreateModal(false)} className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20">
                                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                                Voltar
                            </button>
                        </div>
                        <div className="overflow-y-auto bg-gray-50 p-6 space-y-6 flex-1">
                            <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                    <div className="w-2 h-6 rounded-full bg-moss-500"></div>
                                    <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Dados da Negociação</span>
                                </div>
                                <div className="p-5 space-y-4">
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Cliente</label>
                                        <select className="w-full rounded-lg border border-gray-300 px-4 py-3 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={newClientId} onChange={e => { setNewClientId(e.target.value); setNewAdmissionId(''); }}>
                                            <option value="">Selecione o cliente...</option>
                                            {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Admissão / Contrato <span className="text-gray-400 font-normal text-xs">(opcional)</span></label>
                                        <select className="w-full rounded-lg border border-gray-300 px-4 py-3 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={newAdmissionId} onChange={e => setNewAdmissionId(e.target.value)} disabled={!newClientId}>
                                            <option value="">Selecione a admissão...</option>
                                            {clientAdmissions.map(a => (
                                                <option key={a.id} value={a.id}>Contrato {a.contractNumber} — {fmtMoney(a.financedAmount)} — {getBankName(a.bankId)}</option>
                                            ))}
                                        </select>
                                    </div>

                                    {selectedAdmission && selectedBank && (
                                        <div className="bg-gray-50 rounded-lg p-4 border border-gray-100">
                                            <p className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Dados do Contrato</p>
                                            <div className="grid grid-cols-2 gap-2 text-sm">
                                                <div><span className="text-gray-500">Banco:</span> <span className="font-semibold">{selectedBank.name}</span></div>
                                                <div><span className="text-gray-500">Valor:</span> <span className="font-semibold">{fmtMoney(parseCurrencyBRL(selectedAdmission.financedAmount) || 0)}</span></div>
                                                <div><span className="text-gray-500">Parcelas:</span> <span className="font-semibold">{selectedAdmission.totalInstallments}x de {fmtMoney(parseCurrencyBRL(selectedAdmission.installmentValue) || 0)}</span></div>
                                                <div><span className="text-gray-500">Vencidas:</span> <span className="font-semibold text-red-600">{selectedAdmission.overdueInstallments}</span></div>
                                            </div>
                                            {selectedBank.services.length > 0 && (
                                                <div className="mt-3 pt-3 border-t border-gray-200">
                                                    <p className="text-xs text-gray-500 mb-1">Taxas de Negociação:</p>
                                                    <div className="flex flex-wrap gap-2">
                                                        {selectedBank.services.map(svc => (
                                                            <span key={svc.id} className="bg-moss-50 text-moss-800 px-2 py-0.5 rounded-full text-xs font-semibold border border-moss-200">{svc.name}: {svc.negotiationPercentage}%</span>
                                                        ))}
                                                    </div>
                                                </div>
                                            )}
                                        </div>
                                    )}

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Negociador</label>
                                        <select className="w-full rounded-lg border border-gray-300 px-4 py-3 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={newCollaboratorId} onChange={e => setNewCollaboratorId(e.target.value)}>
                                            <option value="">Selecione o negociador...</option>
                                            {collaborators.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                        </select>
                                    </div>
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
                                        <textarea className="w-full rounded-lg border border-gray-300 px-4 py-3 text-sm focus:ring-2 focus:ring-moss-500 outline-none resize-none" rows={3} value={newNotes} onChange={e => setNewNotes(e.target.value)} placeholder="Observações iniciais..."></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className="bg-gray-100 px-6 py-4 flex justify-end gap-3 border-t border-gray-200 flex-shrink-0">
                            <button onClick={() => setShowCreateModal(false)} className="px-5 py-2.5 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors">Cancelar</button>
                            <button onClick={handleCreateNegotiation} className="px-6 py-2.5 rounded-lg bg-moss-700 text-white text-sm font-bold hover:bg-moss-800 transition-colors shadow-sm">Criar Negociação</button>
                        </div>
                    </div>
                </div>
            )}

            {showFichaModal && selectedRecord && (
                <div className="fixed inset-0 bg-black/50 z-50">
                    <div className="bg-white w-full h-full flex flex-col overflow-hidden animate-fade-in">
                        <div className="bg-moss-800 px-6 py-4 flex items-center justify-between flex-shrink-0">
                            <div className="flex items-center gap-3">
                                <svg className="w-7 h-7 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                <div>
                                    <h3 className="text-lg font-bold text-white tracking-wide">Ficha de Negociação</h3>
                                    <p className="text-xs text-white/60">{selectedRecord.clientName} — {statusLabels[selectedRecord.status]}{(() => { const cl = clients.find(c => c.id === selectedRecord.clientId); return cl?.blocked ? <span className={`ml-2 px-1.5 py-0.5 rounded text-[9px] font-black uppercase ${cl.blockStatus === 'BLOQUEADO' ? 'bg-red-500 text-white' : 'bg-amber-400 text-amber-900'}`}>{cl.blockStatus}</span> : null; })()}</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-2">
                                {selectedRecord.status !== 'ACORDO_FECHADO' && selectedRecord.status !== 'CANCELADA' && selectedRecord.status !== 'ENCERRADA' && (
                                    <select className="rounded-lg border border-white/30 bg-white/10 text-white text-xs px-3 py-2 outline-none" value="" onChange={e => { if (e.target.value) handleUpdateNegotiationStatus(e.target.value as NegotiationStatus); }}>
                                        <option value="" className="text-gray-800">Alterar Status...</option>
                                        {(Object.keys(statusLabels) as NegotiationStatus[]).filter(s => s !== selectedRecord.status).map(s => (
                                            <option key={s} value={s} className="text-gray-800">{statusLabels[s]}</option>
                                        ))}
                                    </select>
                                )}
                                {fichaAdmission && (
                                    <button onClick={() => handleViewFullAdmission(fichaAdmission)} disabled={loadingAdmissionId === fichaAdmission.id} className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20 disabled:opacity-60">
                                        {loadingAdmissionId === fichaAdmission.id ? <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg> : <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>}
                                        Ficha de Admissão
                                    </button>
                                )}
                                <button onClick={() => setShowFichaModal(false)} className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20">
                                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                                    Voltar
                                </button>
                            </div>
                        </div>

                        <div className="bg-white border-b border-gray-200 px-6 py-2 flex items-center gap-3 flex-shrink-0">
                            {(['DADOS', 'CONTATOS', 'PROPOSTAS', 'METAS'] as const).map(tab => (
                                <button key={tab} onClick={() => { setFichaTab(tab); if (tab === 'METAS' && selectedRecord) { setGoalTargetValue(formatCurrencyBRL(selectedRecord.debtValue)); if (selectedRecord.proposals.length > 0) { const lp = selectedRecord.proposals[selectedRecord.proposals.length - 1]; setGoalTargetCount(formatCurrencyBRL(parseCurrencyBRL(lp.originalValue) - parseCurrencyBRL(lp.discountedValue))); } } }} className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors ${fichaTab === tab ? 'bg-moss-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                                    {tab === 'DADOS' ? 'Dados' : tab === 'CONTATOS' ? `Contatos (${selectedRecord.contacts.length})` : tab === 'PROPOSTAS' ? `Propostas (${selectedRecord.proposals.length})` : 'Metas'}
                                </button>
                            ))}
                            <button onClick={() => { setShowClientPanel(true); setClientPanelTab('DADOS'); }} className="px-4 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 bg-indigo-600 text-white hover:bg-indigo-700">
                                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                                Ficha do Cliente
                            </button>
                            {GotalkConversationsTab && (
                            <button onClick={() => setFichaTab('WHATSAPP')} className={`px-4 py-2 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${fichaTab === 'WHATSAPP' ? 'bg-green-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                                WhatsApp
                            </button>
                            )}
                        </div>

                        <div className="flex-1 overflow-y-auto bg-gray-50 p-6">
                            {(() => { const cl = clients.find(c => c.id === selectedRecord.clientId); return cl?.blocked ? <div className="mb-4"><BlockedClientBanner client={cl} /></div> : null; })()}
                            {fichaTab === 'DADOS' && (
                                <div className="space-y-6">
                                    {fichaAdmission && (
                                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                            <div className="flex items-center justify-between gap-3 px-5 py-3 border-b border-gray-100">
                                                <div className="flex items-center gap-3">
                                                    <div className="w-2 h-6 rounded-full bg-moss-500"></div>
                                                    <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Dados da Admissão</span>
                                                </div>
                                                <button onClick={() => handleViewFullAdmission(fichaAdmission)} disabled={loadingAdmissionId === fichaAdmission.id} className="text-xs text-moss-600 hover:text-moss-800 bg-moss-50 hover:bg-moss-100 border border-moss-200 px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-60">
                                                    {loadingAdmissionId === fichaAdmission.id ? <svg className="w-3.5 h-3.5 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg> : <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>}
                                                    Ver Ficha de Admissão
                                                </button>
                                            </div>
                                            <div className="p-5">
                                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                                                    <div><span className="text-gray-500 text-xs block">Contrato</span><p className="font-semibold">{fichaAdmission.contractNumber}</p></div>
                                                    <div><span className="text-gray-500 text-xs block">Banco</span><p className="font-semibold">{fichaBank?.name || '—'}</p></div>
                                                    <div><span className="text-gray-500 text-xs block">Valor Financiado</span><p className="font-semibold">{fmtMoney(parseCurrencyBRL(fichaAdmission.financedAmount) || 0)}</p></div>
                                                    <div><span className="text-gray-500 text-xs block">Parcela</span><p className="font-semibold">{fmtMoney(parseCurrencyBRL(fichaAdmission.installmentValue) || 0)}</p></div>
                                                    <div><span className="text-gray-500 text-xs block">Total Parcelas</span><p className="font-semibold">{fichaAdmission.totalInstallments}</p></div>
                                                    <div><span className="text-gray-500 text-xs block">Pagas</span><p className="font-semibold">{fichaAdmission.paidInstallments}</p></div>
                                                    <div><span className="text-gray-500 text-xs block">Vencidas</span><p className="font-semibold text-red-600">{fichaAdmission.overdueInstallments}</p></div>
                                                    <div><span className="text-gray-500 text-xs block">Status Admissão</span><p className="font-semibold">{fichaAdmission.status}</p></div>
                                                    {fichaAdmission.vehicleBrand && <div><span className="text-gray-500 text-xs block">Veículo</span><p className="font-semibold">{fichaAdmission.vehicleBrand} {fichaAdmission.vehicleModel}</p></div>}
                                                    {fichaAdmission.vehiclePlate && <div><span className="text-gray-500 text-xs block">Placa</span><p className="font-semibold">{fichaAdmission.vehiclePlate}</p></div>}
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    {fichaBank && fichaBank.services.length > 0 && (
                                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                            <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                                <div className="w-2 h-6 rounded-full bg-blue-500"></div>
                                                <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Taxas de Negociação do Banco</span>
                                            </div>
                                            <div className="p-5">
                                                <div className="flex flex-wrap gap-3">
                                                    {fichaBank.services.map(svc => (
                                                        <div key={svc.id} className="bg-blue-50 rounded-lg p-3 border border-blue-100">
                                                            <p className="text-xs text-blue-500 font-semibold">{svc.name}</p>
                                                            <p className="text-lg font-bold text-blue-800">{svc.negotiationPercentage}%</p>
                                                        </div>
                                                    ))}
                                                </div>
                                            </div>
                                        </div>
                                    )}

                                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                        <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                            <div className="w-2 h-6 rounded-full bg-purple-500"></div>
                                            <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Dados da Negociação</span>
                                        </div>
                                        <div className="p-5">
                                            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                                                <div><span className="text-gray-500 text-xs block">Data Abertura</span><p className="font-semibold">{fmtDate(selectedRecord.date)}</p></div>
                                                <div><span className="text-gray-500 text-xs block">Negociador</span><p className="font-semibold">{selectedRecord.collaboratorName}</p></div>
                                                <div><span className="text-gray-500 text-xs block">Valor Dívida</span><p className="font-semibold text-red-600">{fmtMoney(selectedRecord.debtValue)}</p></div>
                                                <div><span className="text-gray-500 text-xs block">Status</span><span className={`px-2.5 py-1 rounded-full text-[10px] font-black uppercase ${statusColors[selectedRecord.status]}`}>{statusLabels[selectedRecord.status]}</span></div>
                                                {selectedRecord.closedDate && <div><span className="text-gray-500 text-xs block">Data Fechamento</span><p className="font-semibold">{fmtDate(selectedRecord.closedDate)}</p></div>}
                                                {selectedRecord.closedValue && <div><span className="text-gray-500 text-xs block">Valor Acordo</span><p className="font-semibold text-green-600">{selectedRecord.closedValue}</p></div>}
                                                {selectedRecord.closedInstallments && <div><span className="text-gray-500 text-xs block">Parcelas Acordo</span><p className="font-semibold">{selectedRecord.closedInstallments}x</p></div>}
                                            </div>
                                            {selectedRecord.notes && (
                                                <div className="mt-4 pt-4 border-t border-gray-100">
                                                    <p className="text-xs text-gray-500 mb-1">Observações:</p>
                                                    <p className="text-sm text-gray-700">{selectedRecord.notes}</p>
                                                </div>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            )}

                            {fichaTab === 'CONTATOS' && (
                                <div className="space-y-6">
                                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                        <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                            <div className="w-2 h-6 rounded-full bg-moss-500"></div>
                                            <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Histórico de Contatos</span>
                                        </div>
                                        <div className="p-5 max-h-64 overflow-y-auto">
                                            {selectedRecord.contacts.length === 0 && <p className="text-gray-400 text-sm text-center py-4">Nenhum contato registrado.</p>}
                                            <div className="relative">
                                                {selectedRecord.contacts.length > 0 && <div className="absolute left-3 top-2 bottom-2 w-0.5 bg-gray-200"></div>}
                                                {[...selectedRecord.contacts].reverse().map(c => (
                                                    <div key={c.id} className="flex gap-4 mb-4 relative">
                                                        <div className={`w-6 h-6 rounded-full flex-shrink-0 z-10 ${responseColors[c.response]}`}></div>
                                                        <div className="flex-1 bg-gray-50 rounded-lg p-3">
                                                            <div className="flex items-center justify-between mb-1">
                                                                <span className="text-xs font-bold text-gray-700">{channelLabels[c.channel]} — {responseLabels[c.response]}</span>
                                                                <div className="flex items-center gap-2">
                                                                    <span className="text-xs text-gray-400">{fmtDate(c.date)} {c.time}</span>
                                                                    {canExcluir && (
                                                                        <button onClick={() => handleDeleteContact(c.id)} className="text-red-400 hover:text-red-600 text-[10px] font-semibold px-1.5 py-0.5 rounded hover:bg-red-50 transition-colors">Excluir</button>
                                                                    )}
                                                                </div>
                                                            </div>
                                                            <p className="text-xs text-gray-600">{c.description}</p>
                                                            {c.nextActionDate && <p className="text-xs text-moss-600 mt-1">Próxima ação: {fmtDate(c.nextActionDate)} — {c.nextActionDescription}</p>}
                                                            <p className="text-[10px] text-gray-400 mt-1">{c.collaboratorName}</p>
                                                        </div>
                                                    </div>
                                                ))}
                                            </div>
                                        </div>
                                    </div>

                                    {selectedRecord.status !== 'ACORDO_FECHADO' && selectedRecord.status !== 'CANCELADA' && selectedRecord.status !== 'ENCERRADA' && (
                                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                            <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                                <div className="w-2 h-6 rounded-full bg-blue-500"></div>
                                                <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Novo Contato</span>
                                            </div>
                                            <div className="p-5 space-y-4">
                                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Data</label>
                                                        <input type="date" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={contactDate} onChange={e => setContactDate(e.target.value)} />
                                                    </div>
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Hora</label>
                                                        <input type="time" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={contactTime} onChange={e => setContactTime(e.target.value)} />
                                                    </div>
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Canal</label>
                                                        <select className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={contactChannel} onChange={e => setContactChannel(e.target.value as NegotiationContactChannel)}>
                                                            {(Object.keys(channelLabels) as NegotiationContactChannel[]).map(ch => <option key={ch} value={ch}>{channelLabels[ch]}</option>)}
                                                        </select>
                                                    </div>
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Resposta</label>
                                                        <select className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={contactResponse} onChange={e => setContactResponse(e.target.value as NegotiationContactResponse)}>
                                                            {(Object.keys(responseLabels) as NegotiationContactResponse[]).map(r => <option key={r} value={r}>{responseLabels[r]}</option>)}
                                                        </select>
                                                    </div>
                                                </div>
                                                <div>
                                                    <label className="block text-xs font-medium text-gray-700 mb-1">Descrição</label>
                                                    <textarea className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none resize-none" rows={3} value={contactDescription} onChange={e => setContactDescription(e.target.value)} placeholder="Descreva o contato realizado..."></textarea>
                                                </div>
                                                <div className="grid grid-cols-2 gap-4">
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Data Próxima Ação</label>
                                                        <input type="date" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={contactNextDate} onChange={e => setContactNextDate(e.target.value)} />
                                                    </div>
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Descrição Próxima Ação</label>
                                                        <input type="text" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={contactNextDesc} onChange={e => setContactNextDesc(e.target.value)} placeholder="O que fazer na próxima ação..." />
                                                    </div>
                                                </div>
                                                <div className="flex justify-end">
                                                    <button onClick={handleAddContact} disabled={!!clients.find(c => c.id === selectedRecord.clientId)?.blocked} className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-colors shadow-sm ${clients.find(c => c.id === selectedRecord.clientId)?.blocked ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-moss-700 text-white hover:bg-moss-800'}`}>Salvar Contato</button>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}

                            {fichaTab === 'PROPOSTAS' && (
                                <div className="space-y-6">
                                    {fichaBank && (
                                        <div className="bg-white rounded-xl border border-amber-200 shadow-sm overflow-hidden">
                                            <div className="flex items-center gap-3 px-5 py-3 border-b border-amber-100 bg-amber-50">
                                                <div className="w-2 h-6 rounded-full bg-amber-500"></div>
                                                <span className="text-[11px] font-black uppercase tracking-widest text-amber-700">Banco e Taxas Máximas de Negociação</span>
                                            </div>
                                            <div className="p-5">
                                                <div className="flex items-center gap-4 mb-3">
                                                    <span className="text-sm font-bold text-gray-800">{fichaBank.name}</span>
                                                    <span className="text-xs text-gray-500">Código: {fichaBank.febrabanCode}</span>
                                                </div>
                                                {fichaBank.services.length > 0 ? (
                                                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                                                        {fichaBank.services.map(svc => (
                                                            <div key={svc.id} className="flex items-center gap-2 bg-amber-50 border border-amber-200 rounded-lg px-3 py-2">
                                                                <span className="text-xs text-gray-700">{svc.name}:</span>
                                                                <span className="text-sm font-bold text-amber-700">{svc.negotiationPercentage}%</span>
                                                            </div>
                                                        ))}
                                                    </div>
                                                ) : (
                                                    <p className="text-xs text-gray-400">Nenhum serviço cadastrado para este banco.</p>
                                                )}
                                                {fichaAdmission && (
                                                    <div className="mt-3 flex items-center gap-4 text-xs text-gray-500 border-t border-amber-100 pt-3">
                                                        <span>Contrato: <strong className="text-gray-700">{fichaAdmission.contractNumber}</strong></span>
                                                        <span>Valor Financiado: <strong className="text-gray-700">{fmtMoney(parseCurrencyBRL(fichaAdmission.financedAmount) || 0)}</strong></span>
                                                        <span>Parcelas: <strong className="text-gray-700">{fichaAdmission.totalInstallments}x de {fmtMoney(parseCurrencyBRL(fichaAdmission.installmentValue) || 0)}</strong></span>
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    )}

                                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                        <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                            <div className="w-2 h-6 rounded-full bg-moss-500"></div>
                                            <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Propostas Enviadas</span>
                                        </div>
                                        <div className="overflow-x-auto">
                                            <table className="min-w-full text-sm">
                                                <thead className="bg-gray-50 border-b border-gray-200">
                                                    <tr>
                                                        <th className="px-4 py-2 text-left text-xs font-bold text-gray-500 uppercase">Data</th>
                                                        <th className="px-4 py-2 text-right text-xs font-bold text-gray-500 uppercase">Valor Original</th>
                                                        <th className="px-4 py-2 text-right text-xs font-bold text-gray-500 uppercase">Desconto</th>
                                                        <th className="px-4 py-2 text-right text-xs font-bold text-gray-500 uppercase">Valor Proposta</th>
                                                        <th className="px-4 py-2 text-center text-xs font-bold text-gray-500 uppercase">Parcelas</th>
                                                        <th className="px-4 py-2 text-right text-xs font-bold text-gray-500 uppercase">Valor Parcela</th>
                                                        <th className="px-4 py-2 text-center text-xs font-bold text-gray-500 uppercase">Status</th>
                                                        <th className="px-4 py-2 text-center text-xs font-bold text-gray-500 uppercase">Ações</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="divide-y divide-gray-100">
                                                    {selectedRecord.proposals.length === 0 && (
                                                        <tr><td colSpan={8} className="px-4 py-8 text-center text-gray-400">Nenhuma proposta registrada.</td></tr>
                                                    )}
                                                    {selectedRecord.proposals.map(p => (
                                                        <tr key={p.id} className="hover:bg-gray-50">
                                                            <td className="px-4 py-2 text-gray-700">{fmtDate(p.date)}</td>
                                                            <td className="px-4 py-2 text-right text-gray-700">{fmtMoney(p.originalValue)}</td>
                                                            <td className="px-4 py-2 text-right text-gray-700">{p.discountPercentage.toFixed(1)}%</td>
                                                            <td className="px-4 py-2 text-right font-semibold text-gray-900">{'R$ ' + p.discountedValue}</td>
                                                            <td className="px-4 py-2 text-center text-gray-700">{p.installments}x</td>
                                                            <td className="px-4 py-2 text-right text-gray-700">{'R$ ' + p.installmentValue}</td>
                                                            <td className="px-4 py-2 text-center">
                                                                <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${proposalStatusColors[p.status]}`}>{proposalStatusLabels[p.status]}</span>
                                                            </td>
                                                            <td className="px-4 py-2 text-center">
                                                                <div className="flex items-center justify-center gap-2">
                                                                    <span className="text-xs text-gray-400">{p.responseDate ? fmtDate(p.responseDate) : '—'}</span>
                                                                    {canExcluir && (
                                                                        <button onClick={() => handleDeleteProposal(p.id)} className="text-red-400 hover:text-red-600 text-[10px] font-semibold px-1.5 py-0.5 rounded hover:bg-red-50 transition-colors">Excluir</button>
                                                                    )}
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                    {selectedRecord.status !== 'ACORDO_FECHADO' && selectedRecord.status !== 'CANCELADA' && selectedRecord.status !== 'ENCERRADA' && (
                                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                            <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                                <div className="w-2 h-6 rounded-full bg-blue-500"></div>
                                                <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Nova Proposta</span>
                                            </div>
                                            <div className="p-5 space-y-4">
                                                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Valor Original</label>
                                                        <input type="text" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm bg-gray-50 outline-none" value={fmtMoney(selectedRecord.debtValue)} readOnly />
                                                    </div>
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Desconto (%)</label>
                                                        <input type="number" min={0} max={100} step={0.5} className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={proposalDiscount} onChange={e => setProposalDiscount(parseFloat(e.target.value) || 0)} />
                                                    </div>
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Valor da Proposta</label>
                                                        <input type="text" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm bg-gray-50 outline-none font-semibold text-green-700" value={fmtMoney(parseCurrencyBRL(selectedRecord.debtValue) * (1 - proposalDiscount / 100))} readOnly />
                                                    </div>
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Parcelas</label>
                                                        <input type="number" min={1} className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={proposalInstallments} onChange={e => setProposalInstallments(parseInt(e.target.value) || 1)} />
                                                    </div>
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Valor da Parcela</label>
                                                        <input type="text" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm bg-gray-50 outline-none" value={(() => {
                                                            const disc = parseCurrencyBRL(selectedRecord.debtValue) * (1 - proposalDiscount / 100);
                                                            const entry = proposalEntry ? parseCurrencyBRL(proposalEntry) : 0;
                                                            return fmtMoney(proposalInstallments > 0 ? (disc - entry) / proposalInstallments : disc - entry);
                                                        })()} readOnly />
                                                    </div>
                                                    <div>
                                                        <label className="block text-xs font-medium text-gray-700 mb-1">Entrada (opcional)</label>
                                                        <input type="text" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={proposalEntry ? 'R$ ' + proposalEntry : ''} onChange={e => handleCurrencyInputLTR(e.target.value, setProposalEntry)} placeholder="R$ 0,00" />
                                                    </div>
                                                </div>
                                                <div>
                                                    <label className="block text-xs font-medium text-gray-700 mb-1">Observações</label>
                                                    <textarea className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none resize-none" rows={2} value={proposalNotes} onChange={e => setProposalNotes(e.target.value)} placeholder="Notas sobre a proposta..."></textarea>
                                                </div>
                                                <div className="flex justify-end">
                                                    <button onClick={handleAddProposal} disabled={!!clients.find(c => c.id === selectedRecord.clientId)?.blocked} className={`px-6 py-2.5 rounded-lg text-sm font-bold transition-colors shadow-sm ${clients.find(c => c.id === selectedRecord.clientId)?.blocked ? 'bg-gray-300 text-gray-500 cursor-not-allowed' : 'bg-moss-700 text-white hover:bg-moss-800'}`}>Registrar Proposta</button>
                                                </div>
                                            </div>
                                        </div>
                                    )}
                                </div>
                            )}

                            {fichaTab === 'METAS' && (
                                <div className="space-y-6">
                                    {currentGoal ? (
                                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                            <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                                <div className="w-2 h-6 rounded-full bg-green-500"></div>
                                                <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Meta do Mês Atual</span>
                                            </div>
                                            <div className="p-5">
                                                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-4">
                                                    <div><span className="text-gray-500 text-xs block">Meta Valor</span><p className="font-semibold">{fmtMoney(currentGoal.targetValue)}</p></div>
                                                    <div><span className="text-gray-500 text-xs block">Atingido Valor</span><p className="font-semibold text-green-600">{fmtMoney(currentGoal.achievedValue)}</p></div>
                                                    <div><span className="text-gray-500 text-xs block">Meta Acordos</span><p className="font-semibold">{fmtMoney(currentGoal.targetCount)}</p></div>
                                                    <div><span className="text-gray-500 text-xs block">Atingido Acordos</span><p className="font-semibold text-green-600">{fmtMoney(currentGoal.achievedCount)}</p></div>
                                                </div>
                                                {(() => {
                                                    const target = parseCurrencyBRL(currentGoal.targetValue);
                                                    const achieved = parseCurrencyBRL(currentGoal.achievedValue);
                                                    const pct = target > 0 ? (achieved / target) * 100 : 0;
                                                    const barColor = pct >= 80 ? 'bg-green-500' : pct >= 50 ? 'bg-amber-500' : 'bg-red-500';
                                                    return (
                                                        <div>
                                                            <div className="flex items-center justify-between mb-1">
                                                                <span className="text-xs text-gray-500">Progresso</span>
                                                                <span className={`text-xs font-bold ${pct >= 80 ? 'text-green-600' : pct >= 50 ? 'text-amber-600' : 'text-red-600'}`}>{pct.toFixed(1)}%</span>
                                                            </div>
                                                            <div className="w-full bg-gray-200 rounded-full h-4">
                                                                <div className={`h-4 rounded-full transition-all ${barColor}`} style={{ width: `${Math.min(pct, 100)}%` }}></div>
                                                            </div>
                                                        </div>
                                                    );
                                                })()}
                                            </div>
                                        </div>
                                    ) : (
                                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm p-8 text-center">
                                            <p className="text-gray-400 text-sm">Nenhuma meta definida para este mês.</p>
                                        </div>
                                    )}

                                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                        <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                                            <div className="w-2 h-6 rounded-full bg-blue-500"></div>
                                            <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Definir / Atualizar Meta</span>
                                        </div>
                                        <div className="p-5 space-y-4">
                                            <div className="grid grid-cols-2 gap-4">
                                                <div>
                                                    <label className="block text-xs font-medium text-gray-700 mb-1">Meta de Valor (R$)</label>
                                                    <input type="text" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={goalTargetValue ? 'R$ ' + goalTargetValue : ''} onChange={e => handleCurrencyInputLTR(e.target.value, setGoalTargetValue)} placeholder="R$ 100.000,00" />
                                                </div>
                                                <div>
                                                    <label className="block text-xs font-medium text-gray-700 mb-1">Meta de Acordos (R$)</label>
                                                    <input type="text" className="w-full rounded-lg border border-gray-300 px-3 py-2.5 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={goalTargetCount ? 'R$ ' + goalTargetCount : ''} onChange={e => handleCurrencyInputLTR(e.target.value, setGoalTargetCount)} placeholder="R$ 0,00" />
                                                </div>
                                            </div>
                                            <div className="flex justify-end">
                                                <button onClick={handleSaveGoal} className="px-6 py-2.5 rounded-lg bg-moss-700 text-white text-sm font-bold hover:bg-moss-800 transition-colors shadow-sm">Salvar Meta</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            )}

                            {fichaTab === 'WHATSAPP' && GotalkConversationsTab && (
                                <div className="-m-6 h-[calc(100%+48px)] min-h-[500px]">
                                    <GotalkConversationsTab clientId={selectedRecord.clientId} />
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            )}

        </div>

        {showFichaModal && selectedRecord && showClientPanel && createPortal(
            (() => {
                const fichaClient = clients.find(c => c.id === selectedRecord.clientId);
                const fichaClientAllTitles = receivableTitles.filter(t => t.clientId === selectedRecord.clientId);
                const fichaClientApprovedAdmissions = admissions.filter(a => a.clientId === selectedRecord.clientId);
                const agingDays = (dueDate: string) => { const d = new Date(dueDate + 'T00:00:00'); const now = new Date(); return Math.floor((now.getTime() - d.getTime()) / 86400000); };
                return (
                    <div className="fixed inset-0 z-[10001]">
                        <div className="bg-white w-full h-full overflow-hidden flex flex-col animate-fade-in">
                            <div className="bg-moss-800 text-white px-6 py-4 flex items-center justify-between flex-shrink-0">
                                <div className="flex items-center gap-3">
                                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
                                    <div>
                                        <h3 className="font-bold text-lg">{fichaClient?.name || selectedRecord.clientName}</h3>
                                        <p className="text-moss-200 text-sm">Dados Completos — Somente Leitura</p>
                                    </div>
                                </div>
                                <div className="flex items-center gap-2">
                                    <AuditLogButton entityType="CLIENT" entityId={selectedRecord.clientId} className="bg-white/15 hover:bg-white/25 text-white border border-white/20" />
                                    <button onClick={() => setShowClientPanel(false)} className="flex items-center gap-1.5 bg-white/15 hover:bg-white/25 text-white text-xs font-semibold px-3 py-1.5 rounded-lg transition-colors border border-white/20">
                                        <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg>
                                        Voltar
                                    </button>
                                </div>
                            </div>

                            {fichaClient?.blocked && <div className="px-6 pt-4 flex-shrink-0"><BlockedClientBanner client={fichaClient} /></div>}
                            <div className="flex border-b border-gray-200 bg-gray-50 flex-shrink-0 flex-wrap">
                                {(['DADOS', 'TITULOS', 'ADMISSOES'] as const).map(tab => (
                                    <button key={tab} onClick={() => setClientPanelTab(tab)} className={`flex-1 px-4 py-3 text-sm font-semibold transition-colors ${clientPanelTab === tab ? 'bg-white text-moss-700 border-b-2 border-moss-600' : 'text-gray-500 hover:text-gray-700'}`}>
                                        {tab === 'DADOS' ? 'Cadastro' : tab === 'TITULOS' ? `Títulos (${fichaClientAllTitles.length})` : `Admissões (${fichaClientApprovedAdmissions.length})`}
                                    </button>
                                ))}
                            </div>

                            <div className="flex-1 overflow-auto p-6">
                                {clientPanelTab === 'DADOS' && fichaClient && (
                                    <div className="space-y-4">
                                        <div className="bg-gray-50 rounded-xl p-5 border border-gray-200">
                                            <h4 className="text-sm font-bold text-gray-700 uppercase tracking-wider mb-3 flex items-center gap-2">
                                                <div className="w-2 h-5 rounded-full bg-moss-500"></div>
                                                Dados Cadastrais
                                            </h4>
                                            <div className="grid grid-cols-2 gap-4 text-sm">
                                                <div><span className="text-gray-500">Nome/Razão:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.name || '—'}</span></div>
                                                <div><span className="text-gray-500">Tipo:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.type === 'FISICA' ? 'Pessoa Física' : 'Pessoa Jurídica'}</span></div>
                                                <div><span className="text-gray-500">CPF/CNPJ:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.document || '—'}</span></div>
                                                <div><span className="text-gray-500">RG:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.rg || '—'}</span></div>
                                                <div><span className="text-gray-500">Telefone:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.phone || '—'}</span></div>
                                                <div><span className="text-gray-500">Telefone 2:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.phone2 || '—'}</span></div>
                                                <div><span className="text-gray-500">E-mail:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.email || '—'}</span></div>
                                                <div><span className="text-gray-500">Profissão:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.profession || '—'}</span></div>
                                                <div><span className="text-gray-500">Estado Civil:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.maritalStatus || '—'}</span></div>
                                                <div><span className="text-gray-500">Nascimento:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.birthDate ? new Date(fichaClient.birthDate + 'T00:00:00').toLocaleDateString('pt-BR') : '—'}</span></div>
                                                <div className="col-span-2"><span className="text-gray-500">Endereço:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.address || '—'}, {fichaClient.number || ''} {fichaClient.complement || ''} — {fichaClient.district || ''}, {fichaClient.city || ''}/{fichaClient.state || ''} — CEP: {fichaClient.cep || '—'}</span></div>
                                                {fichaClient.notes && (
                                                    <div className="col-span-2"><span className="text-gray-500">Observações:</span> <span className="font-medium text-gray-800 ml-1">{fichaClient.notes}</span></div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {clientPanelTab === 'TITULOS' && (
                                    <div className="space-y-2">
                                        <div className="flex items-center gap-3 mb-3 flex-wrap">
                                            <div className="bg-gray-50 rounded-lg px-4 py-2 border border-gray-200 flex flex-col items-center min-w-[80px]">
                                                <span className="text-[10px] text-gray-500 uppercase font-semibold tracking-wide">Total</span>
                                                <span className="text-lg font-bold text-gray-800 leading-tight">{fichaClientAllTitles.length}</span>
                                            </div>
                                            <div className="bg-blue-50 rounded-lg px-4 py-2 border border-blue-100 flex flex-col items-center min-w-[80px]">
                                                <span className="text-[10px] text-blue-500 uppercase font-semibold tracking-wide">Em Aberto</span>
                                                <span className="text-lg font-bold text-blue-800 leading-tight">{fichaClientAllTitles.filter(t => !['PAGO', 'CANCELADO', 'AGRUPADO'].includes(t.status)).length}</span>
                                            </div>
                                            <div className="bg-green-50 rounded-lg px-4 py-2 border border-green-100 flex flex-col items-center min-w-[80px]">
                                                <span className="text-[10px] text-green-500 uppercase font-semibold tracking-wide">Liquidados</span>
                                                <span className="text-lg font-bold text-green-800 leading-tight">{fichaClientAllTitles.filter(t => t.status === 'PAGO').length}</span>
                                            </div>
                                            <div className="bg-purple-50 rounded-lg px-4 py-2 border border-purple-100 flex flex-col">
                                                <span className="text-[10px] text-purple-500 uppercase font-semibold tracking-wide">Saldo Devedor</span>
                                                <span className="text-sm font-bold text-purple-800 leading-tight">{formatCurrencyBRL(fichaClientAllTitles.filter(t => !['PAGO', 'CANCELADO', 'AGRUPADO'].includes(t.status)).reduce((s, t) => s + (Number(t.currentBalance) || 0), 0))}</span>
                                            </div>
                                        </div>
                                        <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                                            <table className="min-w-full text-sm">
                                                <thead className="bg-gray-50 border-b border-gray-200">
                                                    <tr>
                                                        <th className="px-4 py-2.5 text-left font-semibold text-gray-600">Documento</th>
                                                        <th className="px-4 py-2.5 text-left font-semibold text-gray-600">Descrição</th>
                                                        <th className="px-4 py-2.5 text-left font-semibold text-gray-600">Vencimento</th>
                                                        <th className="px-4 py-2.5 text-right font-semibold text-gray-600">Valor</th>
                                                        <th className="px-4 py-2.5 text-right font-semibold text-gray-600">Saldo</th>
                                                        <th className="px-4 py-2.5 text-center font-semibold text-gray-600">Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="divide-y divide-gray-100">
                                                    {fichaClientAllTitles.length === 0 && (
                                                        <tr><td colSpan={6} className="px-6 py-8 text-center text-gray-400">Nenhum título encontrado.</td></tr>
                                                    )}
                                                    {fichaClientAllTitles.map(t => (
                                                        <tr key={t.id} className={`hover:bg-gray-50 ${t.status === 'PAGO' ? 'bg-green-50/30' : agingDays(t.dueDate) > 0 && !['PAGO', 'CANCELADO'].includes(t.status) ? 'bg-red-50/30' : ''}`}>
                                                            <td className="px-4 py-2.5 text-gray-700 font-medium">{t.documentNumber}</td>
                                                            <td className="px-4 py-2.5 text-gray-500 max-w-[160px] truncate">{t.description}</td>
                                                            <td className="px-4 py-2.5 text-gray-600">{new Date(t.dueDate + 'T00:00:00').toLocaleDateString('pt-BR')}</td>
                                                            <td className="px-4 py-2.5 text-right text-blue-700 font-medium">{formatCurrencyBRL(t.originalValue)}</td>
                                                            <td className="px-4 py-2.5 text-right font-semibold text-blue-800">{formatCurrencyBRL(t.currentBalance)}</td>
                                                            <td className="px-4 py-2.5 text-center">
                                                                <span className={`inline-block px-2 py-0.5 rounded-full text-xs font-semibold ${titleStatusColor(t.status)}`}>
                                                                    {titleStatusLabel(t.status)}
                                                                </span>
                                                            </td>
                                                        </tr>
                                                    ))}
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                )}

                                {clientPanelTab === 'ADMISSOES' && (
                                    <div className="space-y-4">
                                        {fichaClientApprovedAdmissions.length === 0 && (
                                            <div className="text-center py-8 text-gray-400">
                                                <svg className="w-12 h-12 mx-auto mb-3 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                                <p>Nenhuma admissão encontrada para este cliente.</p>
                                            </div>
                                        )}
                                        {fichaClientApprovedAdmissions.map(adm => {
                                            const adBank = banks.find(b => b.id === adm.bankId);
                                            return (
                                                <div key={adm.id} className="bg-gray-50 rounded-xl border border-gray-200 overflow-hidden">
                                                    <div className="bg-purple-50 px-5 py-3 border-b border-purple-100 flex items-center justify-between">
                                                        <div className="flex items-center gap-2">
                                                            <div className="w-2 h-5 rounded-full bg-purple-500"></div>
                                                            <span className="font-bold text-sm text-purple-900">Contrato: {adm.contractNumber || '—'}</span>
                                                            {adBank && <span className="text-xs text-purple-600 bg-purple-100 px-2 py-0.5 rounded-full">{adBank.name}</span>}
                                                        </div>
                                                        <div className="flex items-center gap-2">
                                                            <button
                                                                onClick={() => handleViewFullAdmission(adm)}
                                                                disabled={loadingAdmissionId === adm.id}
                                                                className="text-xs text-moss-600 hover:text-moss-800 bg-white hover:bg-moss-50 border border-moss-200 px-2.5 py-1 rounded-full font-semibold flex items-center gap-1 transition-colors disabled:opacity-60"
                                                            >
                                                                {loadingAdmissionId === adm.id ? (
                                                                    <svg className="w-3 h-3 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg>
                                                                ) : (
                                                                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                                                                )}
                                                                Ver Ficha
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div className="p-4 grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                                                        <div><span className="text-gray-500 text-xs block">Valor Financiado</span><p className="font-semibold">{formatCurrencyBRL(parseCurrencyBRL(adm.financedAmount) || 0)}</p></div>
                                                        <div><span className="text-gray-500 text-xs block">Parcela</span><p className="font-semibold">{formatCurrencyBRL(parseCurrencyBRL(adm.installmentValue) || 0)}</p></div>
                                                        <div><span className="text-gray-500 text-xs block">Parcelas</span><p className="font-semibold">{adm.paidInstallments}/{adm.totalInstallments}</p></div>
                                                        <div><span className="text-gray-500 text-xs block">Vencidas</span><p className={`font-semibold ${adm.overdueInstallments > 0 ? 'text-red-600' : ''}`}>{adm.overdueInstallments}</p></div>
                                                        {adm.vehicleBrand && <div><span className="text-gray-500 text-xs block">Veículo</span><p className="font-semibold">{adm.vehicleBrand} {adm.vehicleModel}</p></div>}
                                                        {adm.vehiclePlate && <div><span className="text-gray-500 text-xs block">Placa</span><p className="font-semibold">{adm.vehiclePlate}</p></div>}
                                                    </div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                );
            })(),
            document.body
        )}

        {viewingAdmission && (
            <AdmissionViewerModal
                admission={viewingAdmission}
                clientName={clients.find(c => c.id === viewingAdmission.clientId)?.name || viewingAdmission.clientName || viewingAdmission.clientId}
                onClose={() => setViewingAdmission(null)}
            />
        )}

        <ConfirmDeleteModal
            isOpen={!!deleteModal}
            title={deleteModal?.title ?? ''}
            message={deleteModal?.message ?? ''}
            isLoading={deleteLoading}
            onConfirm={handleDeleteConfirmed}
            onCancel={() => { if (!deleteLoading) setDeleteModal(null); }}
        />
        </>
    );
};

export default NegotiationPanel;

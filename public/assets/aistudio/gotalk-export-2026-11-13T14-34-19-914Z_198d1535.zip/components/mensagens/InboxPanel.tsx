import React, { useState, useRef, useEffect, useCallback, useMemo } from 'react';
import { PortalConfig, User, Message, Conversation } from '../../types';
import { useMessaging } from '../../contexts/MessagingContext';
import GotalkChatPanel from '../gotalk/GotalkChatPanel';

const ALLOWED_TYPES = 'image/png,image/jpeg,image/gif,image/webp,application/pdf,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,application/vnd.ms-excel,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,text/plain';
const MAX_FILE_SIZE = 5 * 1024 * 1024;

interface InboxPanelProps {
    config: PortalConfig;
    currentUser: User | null;
}

function useIsMobile(breakpoint = 768) {
    const [isMobile, setIsMobile] = React.useState(
        typeof window !== 'undefined' ? window.innerWidth < breakpoint : false
    );
    React.useEffect(() => {
        const handler = () => setIsMobile(window.innerWidth < breakpoint);
        window.addEventListener('resize', handler);
        return () => window.removeEventListener('resize', handler);
    }, [breakpoint]);
    return isMobile;
}

function timeAgo(dateStr: string): string {
    const diff = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'agora';
    if (mins < 60) return `${mins}min`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h`;
    const days = Math.floor(hrs / 24);
    if (days < 7) return `${days}d`;
    return new Date(dateStr).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short' });
}

const CHANNEL_COLORS = [
    { bg: 'bg-emerald-50', text: 'text-emerald-700', dot: 'bg-emerald-500', border: 'border-emerald-200' },
    { bg: 'bg-blue-50', text: 'text-blue-700', dot: 'bg-blue-500', border: 'border-blue-200' },
    { bg: 'bg-purple-50', text: 'text-purple-700', dot: 'bg-purple-500', border: 'border-purple-200' },
    { bg: 'bg-orange-50', text: 'text-orange-700', dot: 'bg-orange-500', border: 'border-orange-200' },
    { bg: 'bg-pink-50', text: 'text-pink-700', dot: 'bg-pink-500', border: 'border-pink-200' },
    { bg: 'bg-cyan-50', text: 'text-cyan-700', dot: 'bg-cyan-500', border: 'border-cyan-200' },
    { bg: 'bg-amber-50', text: 'text-amber-700', dot: 'bg-amber-500', border: 'border-amber-200' },
    { bg: 'bg-indigo-50', text: 'text-indigo-700', dot: 'bg-indigo-500', border: 'border-indigo-200' },
    { bg: 'bg-teal-50', text: 'text-teal-700', dot: 'bg-teal-500', border: 'border-teal-200' },
    { bg: 'bg-rose-50', text: 'text-rose-700', dot: 'bg-rose-500', border: 'border-rose-200' },
];

function formatPhoneBR(raw: string | null | undefined): string {
    if (!raw) return '';
    const d = raw.replace(/\D/g, '');
    const local = d.startsWith('55') && d.length > 11 ? d.slice(2) : d;
    if (local.length === 11) return `(${local.slice(0, 2)}) ${local.slice(2, 7)}-${local.slice(7)}`;
    if (local.length === 10) return `(${local.slice(0, 2)}) ${local.slice(2, 6)}-${local.slice(6)}`;
    return raw;
}

function fullDateTime(dateStr: string): string {
    return new Date(dateStr).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit', hour: '2-digit', minute: '2-digit' });
}

function isSameDay(a: string, b: string): boolean {
    return new Date(a).toDateString() === new Date(b).toDateString();
}

function getFileIcon(type: string, name: string): string {
    if (type.startsWith('image/')) return '🖼️';
    if (type.includes('pdf')) return '📄';
    if (type.includes('sheet') || type.includes('excel') || name.endsWith('.xlsx') || name.endsWith('.xls')) return '📊';
    if (type.includes('word') || name.endsWith('.docx') || name.endsWith('.doc')) return '📝';
    return '📁';
}

function formatBytes(bytes: number): string {
    if (bytes < 1024) return `${bytes}B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
}

function getInitials(name: string): string {
    return name.split(' ').map(p => p[0]).join('').toUpperCase().substring(0, 2);
}

const SingleCheckIcon = () => (
    <svg className="w-3.5 h-3.5 inline" viewBox="0 0 16 16" fill="currentColor">
        <path d="M13.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L2.22 9.28a.75.75 0 0 1 1.06-1.06L6 10.94l6.72-6.72a.75.75 0 0 1 1.06 0z"/>
    </svg>
);

const DoubleCheckIcon = ({ blue }: { blue?: boolean }) => (
    <svg className={`w-4 h-3.5 inline ${blue ? 'text-blue-300' : 'text-white/50'}`} viewBox="0 0 20 16" fill="currentColor">
        <path d="M15.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0L4.22 9.28a.75.75 0 0 1 1.06-1.06L8 10.94l6.72-6.72a.75.75 0 0 1 1.06 0z"/>
        <path d="M19.78 4.22a.75.75 0 0 1 0 1.06l-7.25 7.25a.75.75 0 0 1-1.06 0l-.75-.75a.75.75 0 0 1 1.06-1.06l.22.22 6.72-6.72a.75.75 0 0 1 1.06 0z" opacity="0.7"/>
    </svg>
);

const MessageStatus: React.FC<{ delivered?: boolean; read?: boolean }> = ({ delivered, read }) => {
    if (read) return <DoubleCheckIcon blue />;
    if (delivered) return <DoubleCheckIcon />;
    return <span className="text-white/50"><SingleCheckIcon /></span>;
};

const AttachmentCard: React.FC<{ att: { name: string; type: string; size: number; data: string }; sent: boolean }> = ({ att, sent }) => (
    <a
        href={`data:${att.type};base64,${att.data}`}
        download={att.name}
        className={`flex items-center gap-2 px-3 py-2 rounded-xl mt-1 cursor-pointer transition-colors ${sent ? 'bg-white/20 hover:bg-white/30' : 'bg-gray-100 hover:bg-gray-200'}`}
        title="Clique para baixar"
    >
        <span className="text-xl leading-none">{getFileIcon(att.type, att.name)}</span>
        <div className="flex-1 min-w-0">
            <div className={`text-xs font-medium truncate ${sent ? 'text-white' : 'text-gray-800'}`}>{att.name}</div>
            <div className={`text-[10px] ${sent ? 'text-white/60' : 'text-gray-400'}`}>{formatBytes(att.size)}</div>
        </div>
        <svg className={`w-4 h-4 flex-shrink-0 ${sent ? 'text-white/70' : 'text-gray-500'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
        </svg>
    </a>
);

const ChatBubble: React.FC<{ msg: Message; isSent: boolean; showName: boolean }> = React.memo(({ msg, isSent, showName }) => {
    if (msg.is_system) {
        return (
            <div className="flex justify-center my-2">
                <div className="flex items-center gap-2 bg-gray-100 rounded-full px-4 py-1.5 max-w-[80%]">
                    <span className="text-sm">⚙️</span>
                    <span className="text-xs text-gray-500 leading-snug">{msg.body}</span>
                    <span className="text-[9px] text-gray-400 flex-shrink-0">{timeAgo(msg.created_at)}</span>
                </div>
            </div>
        );
    }

    return (
        <div className={`flex items-end gap-2 ${isSent ? 'flex-row-reverse' : 'flex-row'}`}>
            {!isSent && (
                <div className="w-7 h-7 rounded-full bg-moss-100 text-moss-800 font-bold text-xs flex items-center justify-center flex-shrink-0 mb-1">
                    {msg.sender_name.charAt(0).toUpperCase()}
                </div>
            )}
            <div className={`max-w-[70%] ${isSent ? 'items-end' : 'items-start'} flex flex-col`}>
                {showName && !isSent && (
                    <span className="text-[10px] font-bold text-moss-700 mb-0.5 ml-1">{msg.sender_name}</span>
                )}
                <div className={`rounded-2xl px-4 py-2.5 shadow-sm ${isSent ? 'bg-moss-700 text-white rounded-br-sm' : 'bg-white text-gray-800 rounded-bl-sm border border-gray-100'}`}>
                    {msg.subject && (
                        <div className={`text-[10px] font-bold uppercase tracking-wider mb-1 ${isSent ? 'text-white/70' : 'text-moss-600'}`}>
                            {msg.subject}
                        </div>
                    )}
                    <p className="text-sm leading-relaxed whitespace-pre-wrap break-words">{msg.body}</p>
                    {(msg.attachments || []).map((att, i) => (
                        <AttachmentCard key={i} att={att} sent={isSent} />
                    ))}
                    <div className={`text-[10px] mt-1 flex items-center gap-1 ${isSent ? 'justify-end' : 'justify-end text-gray-400'}`}>
                        <span className={isSent ? 'text-white/50' : 'text-gray-400'}>{fullDateTime(msg.created_at)}</span>
                        {isSent && <MessageStatus delivered={msg.delivered} read={msg.read} />}
                    </div>
                </div>
            </div>
        </div>
    );
});

const InboxPanel: React.FC<InboxPanelProps> = ({ config, currentUser }) => {
    const isMobile = useIsMobile();
    const { messages, conversations, unreadCount, sendMessage, markAsRead, markAllAsRead, loadMore, hasMore, isLoading, onlineUserIds, pendingNavConvId, clearPendingNav } = useMessaging();
    const [activeConvId, setActiveConvId] = useState<string | null>(null);
    const [filter, setFilter] = useState<'all' | 'unread' | 'system' | 'direct' | 'group'>('all');
    const [search, setSearch] = useState('');
    const [showCompose, setShowCompose] = useState(false);
    const [leftTab, setLeftTab] = useState<'conversations' | 'contacts' | 'whatsapp'>('conversations');

    interface GotalkConv {
        contactId: string;
        gotalkId: string | null;
        clientId: string | null;
        channelUuid: string | null;
        clientName: string | null;
        contactName: string | null;
        phone: string | null;
        channelName: string | null;
        channelPhone: string | null;
        unitName: string | null;
        lastBody: string | null;
        lastFromMe: boolean | null;
        lastSentAt: string | null;
        unread: number;
    }

    const [gotalkConvs, setGotalkConvs] = useState<GotalkConv[]>([]);
    const [gotalkSelectedConv, setGotalkSelectedConv] = useState<GotalkConv | null>(null);
    const [gotalkLoading, setGotalkLoading] = useState(false);
    const [gotalkSearch, setGotalkSearch] = useState('');
    const [gotalkChannelFilter, setGotalkChannelFilter] = useState('');
    const [gotalkChannels, setGotalkChannels] = useState<Array<{ id: string; name: string; phone_number: string | null }>>([]);
    const chatBottomRef = useRef<HTMLDivElement>(null);

    const [composeRecipientType, setComposeRecipientType] = useState<'USER' | 'GROUP' | 'ALL'>('USER');
    const [composeRecipientId, setComposeRecipientId] = useState('');
    const [composeSubject, setComposeSubject] = useState('');
    const [composeBody, setComposeBody] = useState('');
    const [composeAttachments, setComposeAttachments] = useState<{ name: string; type: string; size: number; data: string }[]>([]);
    const [composeSending, setComposeSending] = useState(false);
    const [composeError, setComposeError] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);

    const activeConv = conversations.find(c => c.id === activeConvId);

    useEffect(() => {
        if (pendingNavConvId) {
            setActiveConvId(pendingNavConvId);
            setLeftTab('conversations');
            clearPendingNav();
        }
    }, [pendingNavConvId, clearPendingNav]);

    const fetchGotalkChannelsList = useCallback(async () => {
        try {
            const res = await fetch('/api/gotalk/channels');
            if (!res.ok) return;
            const data = await res.json();
            setGotalkChannels(data.channels || []);
        } catch {}
    }, []);

    const fetchGotalkConvs = useCallback(async (channelUuid?: string) => {
        setGotalkLoading(true);
        try {
            const qs = channelUuid ? `?limit=200&channel_uuid=${encodeURIComponent(channelUuid)}` : '?limit=200';
            const res = await fetch(`/api/gotalk/conversations${qs}`);
            if (!res.ok) return;
            const data = await res.json();
            setGotalkConvs(data.data || []);
        } catch {} finally {
            setGotalkLoading(false);
        }
    }, []);

    useEffect(() => {
        if (leftTab === 'whatsapp') {
            fetchGotalkChannelsList();
            fetchGotalkConvs(gotalkChannelFilter || undefined);
        }
    }, [leftTab, fetchGotalkConvs, fetchGotalkChannelsList]);

    const handleGotalkChannelFilterChange = (uuid: string) => {
        setGotalkChannelFilter(uuid);
        fetchGotalkConvs(uuid || undefined);
    };

    const messagesByConv = useMemo(() => {
        if (!currentUser) return new Map<string, Message[]>();
        const cache = new Map<string, Message[]>();

        const sistema: Message[] = [];
        const broadcast: Message[] = [];
        const groups = new Map<string, Message[]>();
        const users = new Map<string, Message[]>();

        for (const m of messages) {
            if (m.is_system) {
                sistema.push(m);
                continue;
            }
            if (m.recipient_type === 'ALL') {
                broadcast.push(m);
                continue;
            }
            if (m.recipient_type === 'GROUP') {
                const gid = `group_${m.recipient_id}`;
                if (!groups.has(gid)) groups.set(gid, []);
                groups.get(gid)!.push(m);
                continue;
            }
            const peerId = m.sender_id === currentUser.id ? m.recipient_id : m.sender_id;
            const uid = `user_${peerId}`;
            if (!users.has(uid)) users.set(uid, []);
            users.get(uid)!.push(m);
        }

        const sortFn = (a: Message, b: Message) => a.created_at.localeCompare(b.created_at);
        if (sistema.length) cache.set('__sistema__', sistema.sort(sortFn));
        if (broadcast.length) cache.set('__broadcast__', broadcast.sort(sortFn));
        groups.forEach((msgs, gid) => cache.set(gid, msgs.sort(sortFn)));
        users.forEach((msgs, uid) => cache.set(uid, msgs.sort(sortFn)));

        return cache;
    }, [messages, currentUser]);

    const getConvMessages = useCallback((convId: string): Message[] => {
        return messagesByConv.get(convId) || [];
    }, [messagesByConv]);

    useEffect(() => {
        if (activeConvId) {
            const unreadInConv = getConvMessages(activeConvId).filter(m => !m.read && m.sender_id !== currentUser?.id);
            unreadInConv.forEach(m => markAsRead(m.id));
        }
    }, [activeConvId, messages]);

    useEffect(() => {
        chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [activeConvId, messages.length]);

    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = Array.from(e.target.files || []);
        const results: { name: string; type: string; size: number; data: string }[] = [];
        for (const file of files) {
            if (file.type === 'image/svg+xml' || file.name.toLowerCase().endsWith('.svg')) {
                setComposeError('Arquivos SVG não são permitidos por questões de segurança.');
                continue;
            }
            if (file.size > MAX_FILE_SIZE) {
                setComposeError(`"${file.name}" excede o limite de 5MB.`);
                continue;
            }
            const data = await new Promise<string>((resolve) => {
                const reader = new FileReader();
                reader.onload = (ev) => resolve((ev.target?.result as string).split(',')[1]);
                reader.readAsDataURL(file);
            });
            results.push({ name: file.name, type: file.type, size: file.size, data });
        }
        setComposeAttachments(prev => [...prev, ...results]);
        if (fileInputRef.current) fileInputRef.current.value = '';
    };

    const handleSend = async () => {
        if (!composeBody.trim() || !composeRecipientId) return;
        setComposeSending(true);
        setComposeError('');
        try {
            await sendMessage({
                recipientType: composeRecipientType,
                recipientId: composeRecipientId,
                subject: composeSubject.trim() || undefined,
                body: composeBody.trim(),
                attachments: composeAttachments,
            });
            setComposeBody('');
            setComposeSubject('');
            setComposeAttachments([]);
            setShowCompose(false);
        } catch (err: any) {
            setComposeError(err.message || 'Falha ao enviar');
        }
        setComposeSending(false);
    };

    const [chatInput, setChatInput] = useState('');
    const [chatAttachments, setChatAttachments] = useState<{ name: string; type: string; size: number; data: string }[]>([]);
    const [chatSending, setChatSending] = useState(false);
    const chatFileRef = useRef<HTMLInputElement>(null);

    const handleChatFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const files = Array.from(e.target.files || []);
        const results: { name: string; type: string; size: number; data: string }[] = [];
        for (const file of files) {
            if (file.type === 'image/svg+xml' || file.name.toLowerCase().endsWith('.svg')) continue;
            if (file.size > MAX_FILE_SIZE) continue;
            const data = await new Promise<string>((resolve) => {
                const reader = new FileReader();
                reader.onload = (ev) => resolve((ev.target?.result as string).split(',')[1]);
                reader.readAsDataURL(file);
            });
            results.push({ name: file.name, type: file.type, size: file.size, data });
        }
        setChatAttachments(prev => [...prev, ...results]);
        if (chatFileRef.current) chatFileRef.current.value = '';
    };

    const handleChatSend = async () => {
        if (!chatInput.trim() && chatAttachments.length === 0) return;
        if (!activeConvId || !currentUser) return;

        let recipientType: 'USER' | 'GROUP' | 'ALL' = 'USER';
        let recipientId = '';
        let subject: string | undefined;

        if (activeConvId === '__sistema__' || activeConvId === '__broadcast__') {
            recipientType = 'ALL';
            recipientId = 'ALL';
        } else if (activeConvId.startsWith('group_')) {
            recipientType = 'GROUP';
            recipientId = activeConvId.replace('group_', '');
        } else if (activeConvId.startsWith('user_')) {
            recipientType = 'USER';
            recipientId = activeConvId.replace('user_', '');
        }

        setChatSending(true);
        try {
            await sendMessage({ recipientType, recipientId, subject, body: chatInput.trim(), attachments: chatAttachments });
            setChatInput('');
            setChatAttachments([]);
        } catch {}
        setChatSending(false);
    };

    const filteredConvs = useMemo(() => conversations.filter(c => {
        if (filter === 'unread' && c.unreadCount === 0) return false;
        if (filter === 'system' && c.type !== 'SYSTEM') return false;
        if (filter === 'direct' && c.type !== 'USER') return false;
        if (filter === 'group' && c.type !== 'GROUP') return false;
        if (search && !c.name.toLowerCase().includes(search.toLowerCase()) && !c.lastMessage?.body.toLowerCase().includes(search.toLowerCase())) return false;
        return true;
    }), [conversations, filter, search]);

    const convMessages = activeConvId ? getConvMessages(activeConvId) : [];

    const activeUsers = (config.users || []).filter(u => u.id !== currentUser?.id && u.status === 'ATIVO');

    // Enrich each user with last message data from their conversation
    const enrichContact = (u: User): { user: User; lastMsg: Message | null; lastTime: string | null } => {
        const convId = `user_${u.id}`;
        const msgs = messagesByConv.get(convId) || [];
        const lastMsg = msgs.length > 0 ? msgs[msgs.length - 1] : null;
        return { user: u, lastMsg, lastTime: lastMsg ? lastMsg.created_at : null };
    };

    const enrichedByUnit = (config.units || []).map(unit => ({
        unit,
        users: activeUsers
            .filter(u => (u.allowedUnitIds || []).includes(unit.id) || u.currentUnitId === unit.id)
            .map(enrichContact)
            .sort((a, b) => {
                if (!a.lastTime) return 1;
                if (!b.lastTime) return -1;
                return b.lastTime.localeCompare(a.lastTime);
            }),
    })).filter(g => g.users.length > 0);

    const enrichedWithoutUnit = activeUsers
        .filter(u => !(config.units || []).some(unit => (u.allowedUnitIds || []).includes(unit.id) || u.currentUnitId === unit.id))
        .map(enrichContact)
        .sort((a, b) => {
            if (!a.lastTime) return 1;
            if (!b.lastTime) return -1;
            return b.lastTime.localeCompare(a.lastTime);
        });

    const handleContactClick = (userId: string) => {
        const convId = `user_${userId}`;
        setActiveConvId(convId);
        setLeftTab('conversations');
    };

    return (
        <div className="h-full flex flex-col overflow-hidden bg-gray-50">
            <div className="flex flex-1 min-h-0 min-w-0 overflow-hidden">
                {/* LEFT PANEL */}
                <div className={`${isMobile ? (activeConvId ? 'hidden' : 'w-full') : 'w-80'} min-w-0 flex-shrink-0 flex flex-col border-r border-gray-200 bg-white overflow-hidden`}>
                    {/* Header */}
                    <div className="bg-moss-800 text-white px-4 py-3 flex items-center gap-2">
                        <div className="flex-1">
                            <h2 className="font-bold text-base tracking-tight">Mensagens</h2>
                            {unreadCount > 0 && <p className="text-[10px] text-white/60">{unreadCount} não lida{unreadCount > 1 ? 's' : ''}</p>}
                        </div>
                        <button
                            onClick={() => setShowCompose(true)}
                            className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors"
                            title="Nova Mensagem"
                        >
                            <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                            </svg>
                        </button>
                        {unreadCount > 0 && (
                            <button onClick={markAllAsRead} className="w-8 h-8 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center transition-colors" title="Marcar todas como lidas">
                                <svg className="w-4 h-4 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                                </svg>
                            </button>
                        )}
                    </div>

                    {/* Tab switcher */}
                    <div className="flex border-b border-gray-100">
                        <button
                            onClick={() => setLeftTab('conversations')}
                            className={`flex-1 py-2 text-xs font-semibold transition-colors ${leftTab === 'conversations' ? 'text-moss-700 border-b-2 border-moss-700 bg-moss-50' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            Conversas
                        </button>
                        <button
                            onClick={() => setLeftTab('contacts')}
                            className={`flex-1 py-2 text-xs font-semibold transition-colors ${leftTab === 'contacts' ? 'text-moss-700 border-b-2 border-moss-700 bg-moss-50' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            Contatos
                            <span className={`ml-1.5 text-[9px] font-bold px-1.5 py-0.5 rounded-full ${onlineUserIds.length > 0 ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-400'}`}>
                                {onlineUserIds.filter(id => id !== currentUser?.id).length} online
                            </span>
                        </button>
                        <button
                            onClick={() => { setLeftTab('whatsapp'); setGotalkSelectedConv(null); }}
                            className={`flex-1 py-2 text-xs font-semibold transition-colors flex items-center justify-center gap-1 ${leftTab === 'whatsapp' ? 'text-green-700 border-b-2 border-green-600 bg-green-50' : 'text-gray-500 hover:text-gray-700'}`}
                        >
                            <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                            WA
                        </button>
                    </div>

                    {leftTab === 'conversations' ? (
                        <>
                            {/* Search */}
                            <div className="px-3 py-2 bg-moss-900/5 border-b border-gray-100">
                                <div className="relative">
                                    <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                                    </svg>
                                    <input
                                        type="text"
                                        value={search}
                                        onChange={e => setSearch(e.target.value)}
                                        placeholder="Buscar mensagens..."
                                        className="w-full bg-white rounded-full pl-9 pr-4 py-1.5 text-xs outline-none border border-gray-200 focus:border-moss-400 focus:ring-2 focus:ring-moss-100"
                                    />
                                </div>
                            </div>

                            {/* Filters */}
                            <div className="flex gap-1 px-3 py-2 border-b border-gray-100 overflow-x-auto">
                                {(['all', 'unread', 'system', 'direct', 'group'] as const).map(f => (
                                    <button
                                        key={f}
                                        onClick={() => setFilter(f)}
                                        className={`px-2.5 py-1 rounded-full text-[10px] font-semibold whitespace-nowrap transition-colors ${filter === f ? 'bg-moss-700 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
                                    >
                                        {f === 'all' ? 'Todas' : f === 'unread' ? 'Não lidas' : f === 'system' ? 'Sistema' : f === 'direct' ? 'Diretas' : 'Grupos'}
                                    </button>
                                ))}
                            </div>

                            {/* Conversation List */}
                            <div className="flex-1 overflow-y-auto">
                                {filteredConvs.length === 0 ? (
                                    <div className="text-center py-12 text-gray-400 text-sm">Nenhuma conversa</div>
                                ) : (
                                    filteredConvs.map(conv => (
                                        <button
                                            key={conv.id}
                                            onClick={() => setActiveConvId(conv.id)}
                                            className={`w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-gray-50 transition-colors border-b border-gray-50 ${activeConvId === conv.id ? 'bg-moss-50 border-l-4 border-l-moss-600' : ''}`}
                                        >
                                            <div className={`w-11 h-11 rounded-full flex-shrink-0 flex items-center justify-center font-bold text-sm ${conv.type === 'SYSTEM' ? 'bg-slate-700 text-white' : conv.type === 'GROUP' ? 'bg-indigo-100 text-indigo-800' : 'bg-moss-100 text-moss-800'}`}>
                                                {conv.type === 'SYSTEM' ? '⚙' : conv.avatarInitials}
                                            </div>
                                            <div className="flex-1 min-w-0">
                                                <div className="flex items-center justify-between">
                                                    <span className="font-semibold text-gray-800 text-sm truncate">{conv.name}</span>
                                                    <span className="text-[10px] text-gray-400 flex-shrink-0 ml-1">
                                                        {conv.lastMessage ? timeAgo(conv.lastMessage.created_at) : ''}
                                                    </span>
                                                </div>
                                                <div className="flex items-center justify-between mt-0.5">
                                                    <span className="text-xs text-gray-500 truncate">
                                                        {conv.lastMessage?.body.substring(0, 40)}{(conv.lastMessage?.body.length || 0) > 40 ? '…' : ''}
                                                    </span>
                                                    {conv.unreadCount > 0 && (
                                                        <span className="ml-1 flex-shrink-0 min-w-[18px] h-[18px] bg-red-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                                                            {conv.unreadCount}
                                                        </span>
                                                    )}
                                                </div>
                                                {conv.channelLabel && (
                                                    <div className="flex items-center mt-0.5 gap-1">
                                                        <span className="text-[9px] text-gray-400 bg-gray-100 px-1.5 py-0.5 rounded-full truncate">
                                                            {conv.channelLabel}
                                                        </span>
                                                    </div>
                                                )}
                                            </div>
                                        </button>
                                    ))
                                )}
                            </div>
                        </>
                    ) : leftTab === 'whatsapp' ? (
                        /* WHATSAPP TAB */
                        <div className="flex-1 flex flex-col overflow-hidden">
                            <div className="px-3 py-2 bg-green-50 border-b border-green-100 flex items-center justify-between">
                                <span className="text-xs font-bold text-green-800 uppercase tracking-wider flex items-center gap-1.5">
                                    <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                                    Conversas WhatsApp
                                </span>
                                <button onClick={() => fetchGotalkConvs(gotalkChannelFilter || undefined)} className="text-green-600 hover:text-green-800 p-1 rounded hover:bg-green-100 transition-colors" title="Atualizar">
                                    <svg className={`w-3.5 h-3.5 ${gotalkLoading ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                                </button>
                            </div>
                            {gotalkChannels.length > 1 && (
                                <div className="px-3 pt-2 border-b border-green-100 bg-white pb-2">
                                    <select
                                        value={gotalkChannelFilter}
                                        onChange={e => handleGotalkChannelFilterChange(e.target.value)}
                                        className="w-full text-xs border border-gray-200 rounded-lg px-3 py-1.5 outline-none focus:border-green-400 bg-white"
                                    >
                                        <option value="">Todos os canais</option>
                                        {gotalkChannels.map(ch => (
                                            <option key={ch.id} value={ch.id}>{ch.name}{ch.phone_number ? ` (${ch.phone_number})` : ''}</option>
                                        ))}
                                    </select>
                                </div>
                            )}
                            <div className="px-3 py-1.5 border-b border-green-100 bg-white">
                                <input
                                    type="text"
                                    value={gotalkSearch}
                                    onChange={e => setGotalkSearch(e.target.value)}
                                    placeholder="Buscar por nome ou número..."
                                    className="w-full text-xs border border-gray-200 rounded-lg px-3 py-1.5 outline-none focus:border-green-400"
                                />
                            </div>
                            <div className="flex-1 overflow-y-auto">
                            {gotalkLoading ? (
                                <div className="text-center py-8 text-gray-400 text-sm">Carregando...</div>
                            ) : gotalkConvs.filter(c => !gotalkSearch || (c.clientName || c.contactName || '').toLowerCase().includes(gotalkSearch.toLowerCase()) || (c.phone || '').replace(/\D/g, '').includes(gotalkSearch.replace(/\D/g, ''))).length === 0 ? (
                                <div className="text-center py-12 text-gray-400 text-sm">{gotalkSearch ? 'Nenhum resultado encontrado' : 'Nenhuma conversa WhatsApp'}</div>
                            ) : (
                                gotalkConvs.filter(c => !gotalkSearch || (c.clientName || c.contactName || '').toLowerCase().includes(gotalkSearch.toLowerCase()) || (c.phone || '').replace(/\D/g, '').includes(gotalkSearch.replace(/\D/g, ''))).map(conv => {
                                    const hasName = !!(conv.clientName || conv.contactName);
                                    const title = conv.clientName || conv.contactName || formatPhoneBR(conv.phone) || 'Desconhecido';
                                    const chIdx = conv.channelUuid ? gotalkChannels.findIndex(ch => ch.id === conv.channelUuid) : -1;
                                    const chColor = CHANNEL_COLORS[(chIdx >= 0 ? chIdx : 0) % CHANNEL_COLORS.length];
                                    const showChannelPill = !gotalkChannelFilter && (conv.channelName || conv.channelPhone || conv.unitName);
                                    return (
                                    <button
                                        key={conv.contactId}
                                        onClick={() => setGotalkSelectedConv(conv)}
                                        className={`w-full flex items-start gap-3 px-4 py-3 text-left hover:bg-green-50 transition-colors border-b border-gray-50 ${gotalkSelectedConv?.contactId === conv.contactId ? 'bg-green-50 border-l-4 border-l-green-600' : ''}`}
                                    >
                                        <div className={`w-10 h-10 rounded-full font-bold text-sm flex items-center justify-center shrink-0 mt-0.5 ${conv.clientId ? 'bg-green-100 text-green-800' : 'bg-amber-100 text-amber-800'}`}>
                                            {title.charAt(0).toUpperCase()}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            {/* Linha 1: nome + timestamp */}
                                            <div className="flex items-center justify-between gap-1">
                                                <span className="font-semibold text-gray-800 text-sm truncate">
                                                    {title}
                                                </span>
                                                <div className="flex items-center gap-1 flex-shrink-0">
                                                    {!conv.clientId && (
                                                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-700">
                                                            não vinculado
                                                        </span>
                                                    )}
                                                    {conv.lastSentAt && (
                                                        <span className="text-[10px] text-gray-400">{timeAgo(conv.lastSentAt)}</span>
                                                    )}
                                                </div>
                                            </div>
                                            {/* telefone do contato (só quando há nome, para não duplicar) */}
                                            {hasName && conv.phone && (
                                                <div className="text-[11px] text-gray-400 font-mono truncate leading-tight">
                                                    {formatPhoneBR(conv.phone)}
                                                </div>
                                            )}
                                            {/* Linha 2: preview com ícone de direção + badge não lidas */}
                                            <div className="flex items-center justify-between mt-0.5 gap-1">
                                                <span className="text-xs text-gray-500 truncate flex items-center gap-1 min-w-0">
                                                    {conv.lastFromMe != null && (
                                                        <span className={conv.lastFromMe ? 'text-green-600' : 'text-blue-500'} title={conv.lastFromMe ? 'Enviada' : 'Recebida'}>
                                                            {conv.lastFromMe ? '↑' : '↓'}
                                                        </span>
                                                    )}
                                                    <span className="truncate">{conv.lastBody ? conv.lastBody.substring(0, 38) : '(mídia)'}</span>
                                                </span>
                                                {conv.unread > 0 && (
                                                    <span className="ml-1 flex-shrink-0 min-w-[18px] h-[18px] bg-green-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center px-1">
                                                        {conv.unread}
                                                    </span>
                                                )}
                                            </div>
                                            {/* Linha 3: pill de canal + unidade */}
                                            {showChannelPill && (
                                                <div className="flex items-center gap-1 mt-1 flex-wrap">
                                                    <span className={`inline-flex items-center gap-1 text-[9px] font-semibold px-1.5 py-0.5 rounded-full border ${chColor.bg} ${chColor.text} ${chColor.border}`}>
                                                        <span className={`w-1.5 h-1.5 rounded-full ${chColor.dot}`}></span>
                                                        {conv.channelName || 'Canal'}
                                                        {conv.channelPhone && <span className="font-mono opacity-80">· {formatPhoneBR(conv.channelPhone)}</span>}
                                                    </span>
                                                    {conv.unitName && (
                                                        <span className="text-[9px] text-gray-400 truncate">{conv.unitName}</span>
                                                    )}
                                                </div>
                                            )}
                                        </div>
                                    </button>
                                    );
                                })
                            )}
                        </div>
                        </div>
                    ) : (
                        /* CONTACTS TAB */
                        <div className="flex-1 overflow-y-auto">
                            {enrichedByUnit.map(({ unit, users }) => (
                                <div key={unit.id}>
                                    <div className="px-4 py-2 bg-gray-50 border-b border-gray-100 sticky top-0 z-10">
                                        <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">{unit.nomeFantasia || unit.razaoSocial}</span>
                                    </div>
                                    {users.map(({ user: u, lastMsg, lastTime }) => {
                                        const isOnline = onlineUserIds.includes(u.id);
                                        const userGroup = (config.userGroups || []).find(g => (u.groupIds || []).includes(g.id));
                                        return (
                                            <button
                                                key={u.id}
                                                onClick={() => handleContactClick(u.id)}
                                                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors border-b border-gray-50 text-left"
                                            >
                                                <div className="relative flex-shrink-0">
                                                    <div className="w-10 h-10 rounded-full bg-moss-100 text-moss-800 font-bold text-xs flex items-center justify-center">
                                                        {getInitials(u.name)}
                                                    </div>
                                                    <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-white ${isOnline ? 'bg-green-500' : 'bg-gray-300'}`} />
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex items-center justify-between">
                                                        <span className="text-sm font-semibold text-gray-800 truncate">{u.name}</span>
                                                        <span className="text-[10px] text-gray-400 flex-shrink-0 ml-1">
                                                            {lastTime ? timeAgo(lastTime) : ''}
                                                        </span>
                                                    </div>
                                                    <div className="flex items-center justify-between mt-0.5">
                                                        <span className="text-xs text-gray-500 truncate">
                                                            {lastMsg ? lastMsg.body.substring(0, 40) : (userGroup?.name || u.email)}
                                                            {(lastMsg?.body.length || 0) > 40 ? '…' : ''}
                                                        </span>
                                                        {isOnline && (
                                                            <span className="ml-1 flex-shrink-0 w-2 h-2 bg-green-500 rounded-full" />
                                                        )}
                                                    </div>
                                                </div>
                                            </button>
                                        );
                                    })}
                                </div>
                            ))}
                            {enrichedWithoutUnit.length > 0 && (
                                <div>
                                    <div className="px-4 py-2 bg-gray-50 border-b border-gray-100 sticky top-0 z-10">
                                        <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">Sem unidade definida</span>
                                    </div>
                                    {enrichedWithoutUnit.map(({ user: u, lastMsg, lastTime }) => {
                                        const isOnline = onlineUserIds.includes(u.id);
                                        const userGroup = (config.userGroups || []).find(g => (u.groupIds || []).includes(g.id));
                                        return (
                                            <button
                                                key={u.id}
                                                onClick={() => handleContactClick(u.id)}
                                                className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors border-b border-gray-50 text-left"
                                            >
                                                <div className="relative flex-shrink-0">
                                                    <div className="w-10 h-10 rounded-full bg-moss-100 text-moss-800 font-bold text-xs flex items-center justify-center">
                                                        {getInitials(u.name)}
                                                    </div>
                                                    <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-white ${isOnline ? 'bg-green-500' : 'bg-gray-300'}`} />
                                                </div>
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex items-center justify-between">
                                                        <span className="text-sm font-semibold text-gray-800 truncate">{u.name}</span>
                                                        <span className="text-[10px] text-gray-400 flex-shrink-0 ml-1">
                                                            {lastTime ? timeAgo(lastTime) : ''}
                                                        </span>
                                                    </div>
                                                    <div className="flex items-center justify-between mt-0.5">
                                                        <span className="text-xs text-gray-500 truncate">
                                                            {lastMsg ? lastMsg.body.substring(0, 40) : (userGroup?.name || u.email)}
                                                            {(lastMsg?.body.length || 0) > 40 ? '…' : ''}
                                                        </span>
                                                        {isOnline && (
                                                            <span className="ml-1 flex-shrink-0 w-2 h-2 bg-green-500 rounded-full" />
                                                        )}
                                                    </div>
                                                </div>
                                            </button>
                                        );
                                    })}
                                </div>
                            )}
                            {activeUsers.length === 0 && (
                                <div className="text-center py-12 text-gray-400 text-sm">Nenhum usuário ativo</div>
                            )}
                        </div>
                    )}
                </div>

                {/* RIGHT PANEL — Chat area */}
                {leftTab === 'whatsapp' ? (
                    <div className="flex-1 min-w-0 flex flex-col overflow-hidden">
                        {gotalkSelectedConv ? (
                            <GotalkChatPanel
                                clientId={gotalkSelectedConv.clientId || undefined}
                                gotalkContactId={gotalkSelectedConv.contactId}
                                area="MENSAGENS"
                                operatorName={currentUser?.name}
                                onLinked={(newClientId) => {
                                    setGotalkSelectedConv(prev => prev ? { ...prev, clientId: newClientId } : prev);
                                    setGotalkConvs(prev => prev.map(c => c.contactId === gotalkSelectedConv.contactId ? { ...c, clientId: newClientId } : c));
                                }}
                            />
                        ) : (
                            <div className="flex-1 flex flex-col items-center justify-center text-gray-400 bg-green-50">
                                <svg className="w-20 h-20 mb-4 text-green-200" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                                <p className="font-semibold text-green-700">Selecione uma conversa WhatsApp</p>
                                <p className="text-sm mt-1 text-green-500">para visualizar o histórico de mensagens</p>
                            </div>
                        )}
                    </div>
                ) : (
                <div className={`flex-1 min-w-0 flex flex-col overflow-hidden ${isMobile && !activeConvId ? 'hidden' : ''}`}>
                    {!activeConvId ? (
                        <div className="flex-1 flex flex-col items-center justify-center text-gray-400 bg-gray-50">
                            <svg className="w-20 h-20 mb-4 text-gray-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                            </svg>
                            <p className="font-semibold text-gray-500">Selecione uma conversa</p>
                            <p className="text-sm mt-1">ou escolha um contato para iniciar</p>
                            <button onClick={() => setShowCompose(true)} className="mt-4 px-5 py-2.5 bg-moss-700 text-white rounded-xl text-sm font-semibold hover:bg-moss-800 transition-colors shadow-sm">
                                + Nova Mensagem
                            </button>
                        </div>
                    ) : (
                        <>
                            {/* Chat Header */}
                            <div className="bg-white border-b border-gray-200 px-5 py-3 flex items-center gap-3 shadow-sm flex-shrink-0">
                                {isMobile && (
                                    <button
                                        onClick={() => setActiveConvId(null)}
                                        className="w-8 h-8 rounded-full flex items-center justify-center text-gray-500 hover:bg-gray-100 transition-colors flex-shrink-0 -ml-1"
                                        title="Voltar"
                                    >
                                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                                        </svg>
                                    </button>
                                )}
                                <div className="relative">
                                    <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm ${activeConv?.type === 'SYSTEM' ? 'bg-slate-700 text-white' : activeConv?.type === 'GROUP' ? 'bg-indigo-100 text-indigo-800' : 'bg-moss-100 text-moss-800'}`}>
                                        {activeConv?.type === 'SYSTEM' ? '⚙' : activeConv?.avatarInitials}
                                    </div>
                                    {activeConv?.type === 'USER' && (() => {
                                        const peerId = activeConvId?.replace('user_', '');
                                        const isOnline = peerId ? onlineUserIds.includes(peerId) : false;
                                        return <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full ring-2 ring-white ${isOnline ? 'bg-green-500' : 'bg-gray-300'}`} />;
                                    })()}
                                </div>
                                <div className="flex-1">
                                    <h3 className="font-bold text-gray-800 text-sm">{activeConv?.name}</h3>
                                    <p className="text-[11px] text-gray-400">
                                        {activeConv?.type === 'SYSTEM' ? 'Notificações automáticas do sistema' : activeConv?.type === 'GROUP' ? 'Grupo' : (() => {
                                            const peerId = activeConvId?.replace('user_', '');
                                            const isOnline = peerId ? onlineUserIds.includes(peerId) : false;
                                            return <span className={isOnline ? 'text-green-600 font-semibold' : ''}>
                                                {isOnline ? '● online' : 'offline'}
                                            </span>;
                                        })()}
                                    </p>
                                </div>
                                {hasMore && (
                                    <button onClick={() => convMessages.length > 0 && loadMore(convMessages[0].created_at)} className="text-xs text-moss-600 hover:text-moss-800">
                                        Carregar mais
                                    </button>
                                )}
                            </div>

                            {/* Messages */}
                            <div className="flex-1 overflow-y-auto px-6 py-4 space-y-2" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, rgba(74,133,96,0.04) 1px, transparent 0)', backgroundSize: '24px 24px' }}>
                                {convMessages.length === 0 ? (
                                    <div className="text-center text-gray-400 text-sm py-10">Nenhuma mensagem ainda. Diga olá! 👋</div>
                                ) : (
                                    convMessages.map((msg, i) => {
                                        const prev = convMessages[i - 1];
                                        const showDateSep = !prev || !isSameDay(prev.created_at, msg.created_at);
                                        const isSent = msg.sender_id === currentUser?.id;
                                        const showName = !isSent && (!prev || prev.sender_id !== msg.sender_id || !isSameDay(prev.created_at, msg.created_at));
                                        return (
                                            <React.Fragment key={msg.id}>
                                                {showDateSep && (
                                                    <div className="flex items-center gap-3 my-3">
                                                        <div className="flex-1 h-px bg-gray-200" />
                                                        <span className="text-[10px] text-gray-400 bg-white px-2 py-0.5 rounded-full border border-gray-200">
                                                            {new Date(msg.created_at).toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}
                                                        </span>
                                                        <div className="flex-1 h-px bg-gray-200" />
                                                    </div>
                                                )}
                                                <ChatBubble msg={msg} isSent={isSent} showName={showName} />
                                            </React.Fragment>
                                        );
                                    })
                                )}
                                <div ref={chatBottomRef} />
                            </div>

                            {/* Input Area */}
                            {activeConv?.type !== 'SYSTEM' && (
                                <div className="bg-white border-t border-gray-200 px-4 py-3 flex-shrink-0">
                                    {chatAttachments.length > 0 && (
                                        <div className="flex gap-2 mb-2 flex-wrap">
                                            {chatAttachments.map((a, i) => (
                                                <div key={i} className="flex items-center gap-1.5 bg-gray-100 rounded-lg px-2 py-1 text-xs">
                                                    <span>{getFileIcon(a.type, a.name)}</span>
                                                    <span className="text-gray-700 max-w-[100px] truncate">{a.name}</span>
                                                    <button onClick={() => setChatAttachments(p => p.filter((_, j) => j !== i))} className="text-gray-400 hover:text-red-500">×</button>
                                                </div>
                                            ))}
                                        </div>
                                    )}
                                    <div className="flex items-end gap-2">
                                        <input type="file" ref={chatFileRef} onChange={handleChatFileChange} multiple accept={ALLOWED_TYPES} className="hidden" />
                                        <button onClick={() => chatFileRef.current?.click()} className="w-9 h-9 rounded-full flex items-center justify-center text-gray-400 hover:text-moss-600 hover:bg-gray-100 transition-colors flex-shrink-0" title="Anexar arquivo">
                                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
                                            </svg>
                                        </button>
                                        <textarea
                                            value={chatInput}
                                            onChange={e => setChatInput(e.target.value)}
                                            onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleChatSend(); } }}
                                            placeholder="Digite uma mensagem... (Enter para enviar)"
                                            rows={1}
                                            className="flex-1 bg-gray-100 rounded-2xl px-4 py-2.5 text-sm outline-none focus:bg-white focus:ring-2 focus:ring-moss-300 resize-none max-h-32 transition-all"
                                            style={{ minHeight: '40px' }}
                                        />
                                        <button
                                            onClick={handleChatSend}
                                            disabled={(!chatInput.trim() && chatAttachments.length === 0) || chatSending}
                                            className="w-10 h-10 rounded-full bg-moss-700 hover:bg-moss-800 text-white flex items-center justify-center shadow-md transition-colors disabled:opacity-40 disabled:cursor-not-allowed flex-shrink-0"
                                            title="Enviar"
                                        >
                                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                                            </svg>
                                        </button>
                                    </div>
                                </div>
                            )}
                        </>
                    )}
                </div>
                )}
            </div>

            {/* Compose Modal */}
            {showCompose && (
                <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setShowCompose(false)}>
                    <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden" onClick={e => e.stopPropagation()}>
                        <div className="bg-moss-800 text-white px-5 py-4 flex items-center justify-between">
                            <h3 className="font-bold">Nova Mensagem</h3>
                            <button onClick={() => setShowCompose(false)} className="text-white/70 hover:text-white">
                                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                            </button>
                        </div>
                        <div className="p-5 space-y-4">
                            <div className="grid grid-cols-3 gap-2">
                                {(['USER', 'GROUP', 'ALL'] as const).map(t => (
                                    <button key={t} onClick={() => { setComposeRecipientType(t); setComposeRecipientId(t === 'ALL' ? 'ALL' : ''); }} className={`py-2 rounded-lg text-sm font-semibold border transition-colors ${composeRecipientType === t ? 'bg-moss-700 text-white border-moss-700' : 'bg-white text-gray-600 border-gray-200 hover:border-moss-400'}`}>
                                        {t === 'USER' ? '👤 Usuário' : t === 'GROUP' ? '👥 Grupo' : '📢 Todos'}
                                    </button>
                                ))}
                            </div>

                            {composeRecipientType !== 'ALL' && (
                                <div>
                                    <label className="block text-xs font-semibold text-gray-600 mb-1">
                                        {composeRecipientType === 'USER' ? 'Destinatário' : 'Grupo'}
                                    </label>
                                    <select
                                        value={composeRecipientId}
                                        onChange={e => setComposeRecipientId(e.target.value)}
                                        className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-moss-400"
                                    >
                                        <option value="">Selecione...</option>
                                        {composeRecipientType === 'USER'
                                            ? (config.users || []).filter(u => u.id !== currentUser?.id && u.status === 'ATIVO').map(u => (
                                                <option key={u.id} value={u.id}>{u.name} ({u.email})</option>
                                            ))
                                            : (config.userGroups || []).map(g => (
                                                <option key={g.id} value={g.id}>{g.name}</option>
                                            ))
                                        }
                                    </select>
                                </div>
                            )}

                            <div>
                                <label className="block text-xs font-semibold text-gray-600 mb-1">Assunto (opcional)</label>
                                <input value={composeSubject} onChange={e => setComposeSubject(e.target.value)} placeholder="Assunto da mensagem..." className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-moss-400" />
                            </div>

                            <div>
                                <label className="block text-xs font-semibold text-gray-600 mb-1">Mensagem *</label>
                                <textarea value={composeBody} onChange={e => setComposeBody(e.target.value)} rows={4} placeholder="Digite sua mensagem..." className="w-full rounded-xl border border-gray-200 px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-moss-400 resize-none" />
                            </div>

                            <div>
                                <label className="block text-xs font-semibold text-gray-600 mb-1">Anexos</label>
                                <input type="file" ref={fileInputRef} onChange={handleFileChange} multiple accept={ALLOWED_TYPES} className="hidden" />
                                <button onClick={() => fileInputRef.current?.click()} className="flex items-center gap-2 px-3 py-2 border border-dashed border-gray-300 rounded-xl text-sm text-gray-500 hover:border-moss-400 hover:text-moss-700 transition-colors w-full justify-center">
                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                                    Clique para anexar arquivos
                                </button>
                                {composeAttachments.length > 0 && (
                                    <div className="mt-2 space-y-1">
                                        {composeAttachments.map((a, i) => (
                                            <div key={i} className="flex items-center gap-2 bg-gray-50 rounded-lg px-3 py-1.5 text-xs">
                                                <span>{getFileIcon(a.type, a.name)}</span>
                                                <span className="flex-1 truncate text-gray-700">{a.name}</span>
                                                <span className="text-gray-400">{formatBytes(a.size)}</span>
                                                <button onClick={() => setComposeAttachments(p => p.filter((_, j) => j !== i))} className="text-gray-400 hover:text-red-500 ml-1">×</button>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>

                            {composeError && <p className="text-red-500 text-xs">{composeError}</p>}

                            <div className="flex gap-3 pt-1">
                                <button onClick={() => setShowCompose(false)} className="flex-1 py-2.5 border border-gray-200 rounded-xl text-sm font-semibold text-gray-600 hover:bg-gray-50 transition-colors">Cancelar</button>
                                <button
                                    onClick={handleSend}
                                    disabled={!composeBody.trim() || (!composeRecipientId && composeRecipientType !== 'ALL') || composeSending}
                                    className="flex-1 py-2.5 bg-moss-700 text-white rounded-xl text-sm font-bold hover:bg-moss-800 transition-colors shadow-sm disabled:opacity-40 disabled:cursor-not-allowed"
                                >
                                    {composeSending ? 'Enviando...' : 'Enviar Mensagem'}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

export default InboxPanel;

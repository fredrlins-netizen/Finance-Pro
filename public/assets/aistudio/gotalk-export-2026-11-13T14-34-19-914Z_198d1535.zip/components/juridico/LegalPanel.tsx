/**
 * TÍTULO: PAINEL JURÍDICO (MONITORAMENTO DE PROCESSOS)
 * 
 * Funcionalidades:
 * - Sincronização automática com Admissão/Auditoria.
 * - CRUD Completo de Processos.
 * - OCR Real via Tesseract.js para leitura de documentos/prints.
 * - Linha do tempo interativa (Adicionar, Editar e Excluir Movimentações).
 */

import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { PortalConfig, Client, Admission, LegalProcess, ProcessMovement, MovementStatus } from '../../types';
import Button from '../ui/Button';
import AdmissionViewerModal from '../ui/AdmissionViewerModal';
import Input from '../ui/Input';
import GotalkChatPanel from '../gotalk/GotalkChatPanel';
import GotalkAttendanceViewer from '../gotalk/GotalkAttendanceViewer';
import FormActions from '../ui/FormActions';
import { FixedSizeList } from 'react-window';
import AuditLogButton from '../ui/AuditLogButton';
import ConfirmDeleteModal from '../ui/ConfirmDeleteModal';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { createWorker } from 'tesseract.js';
import BlockedClientBanner from '../ui/BlockedClientBanner';
import { api } from '../../services/apiService';

interface LegalPanelProps {
  config: PortalConfig;
}

interface LegalRowItemData {
    filteredProcesses: LegalProcess[];
    selectedProcessDetailsId?: string;
    clients: Client[];
    auditLogs: PortalConfig['auditLogs'];
    getStatusStyle: (s: string) => string;
    getStatusLabel: (s: string) => string;
    setSelectedProcessDetails: (p: LegalProcess) => void;
    setLegalDrawerTab: (t: string) => void;
    handleEditProcess: (p: LegalProcess) => void;
    handleDeleteProcess: (id: string) => void;
}


function legalProcessToPayload(p: LegalProcess) {
    return {
        process_number: p.processNumber,
        court: p.court,
        type: p.type,
        status: p.status,
        client_id: p.clientId || null,
        client_name: p.clientName || '',
        admission_id: p.admissionId || null,
        contract_number: p.contractNumber || null,
        notes: p.notes || null,
        tags: p.tags || [],
        movements: p.movements || [],
        role: p.role || null,
        subject: p.subject || null,
        opposing_party: p.opposingParty || null,
        opposing_party_document: p.opposingPartyDocument || null,
        opposing_party_lawyer: p.opposingPartyLawyer || null,
        responsible_lawyer: p.responsibleLawyer || null,
        cause_value: p.causeValue || null,
        provision_value: p.provisionValue || null,
        risk_level: p.riskLevel || null,
        distribution_date: p.distributionDate || null,
        last_movement_date: p.lastMovementDate || null,
    };
}

const LegalPanel: React.FC<LegalPanelProps> = ({ config }) => {
    const { addToast, validarPermissao, currentUser, temPermissao, isLoggedAdmin } = useSecurity();
    const { logTransaction } = useAudit();

    // Delete modal state (replaces window.confirm)
    const [deleteModal, setDeleteModal] = useState<{ title: string; message: string; onConfirm: () => Promise<void> } | null>(null);
    const [deleteLoading, setDeleteLoading] = useState(false);

    const handleDeleteConfirmed = useCallback(async () => {
        if (!deleteModal) return;
        setDeleteLoading(true);
        try {
            await deleteModal.onConfirm();
        } catch {
            // error toast shown inside onConfirm
        } finally {
            setDeleteLoading(false);
            setDeleteModal(null);
        }
    }, [deleteModal]);

    // Estado Principal — loaded from API
    const [processes, setProcesses] = useState<LegalProcess[]>([]);
    const [processesLoading, setProcessesLoading] = useState(true);
    const [isEditing, setIsEditing] = useState(false);
    const [currentProcess, setCurrentProcess] = useState<LegalProcess | null>(null);
    const [selectedProcessDetails, setSelectedProcessDetails] = useState<LegalProcess | null>(null); // Para o Drawer Lateral
    const [viewingAdmission, setViewingAdmission] = useState<Admission | null>(null);
    const [legalDrawerTab, setLegalDrawerTab] = useState<'timeline' | 'whatsapp' | 'atendimentos'>('timeline');

    const handleOpenAdmissionModal = useCallback((adm: Admission) => {
        if (!isLoggedAdmin && !temPermissao('com_admissao:VISUALIZAR')) {
            addToast('error', 'Acesso negado', 'Sem permissão para visualizar a Ficha de Admissão.');
            return;
        }
        setViewingAdmission(adm);
    }, [addToast, isLoggedAdmin, temPermissao]);

    // Estado para Nova Movimentação (Smart Input)
    const [isAddingMovement, setIsAddingMovement] = useState(false);
    const [movementDate, setMovementDate] = useState(new Date().toISOString().split('T')[0]); // Data padrão Hoje
    const [newMovement, setNewMovement] = useState<Partial<ProcessMovement>>({ type: 'DESPACHO', description: '', source: '' });
    
    // Estado para EDICAO de Movimentação (Modal)
    const [editingMovementIdx, setEditingMovementIdx] = useState<number | null>(null);
    const [editMovementData, setEditMovementData] = useState<ProcessMovement | null>(null);

    // OCR States
    const [isReadingOCR, setIsReadingOCR] = useState(false);
    const [ocrStatusMessage, setOcrStatusMessage] = useState('');
    const fileInputRef = useRef<HTMLInputElement>(null);

    // Filtros e Pesquisa
    const [searchTerm, setSearchTerm] = useState('');
    const [showFilters, setShowFilters] = useState(false);
    const [filterStatus, setFilterStatus] = useState('');
    const [filterCourt, setFilterCourt] = useState('');
    const [filterDateStart, setFilterDateStart] = useState('');
    const [filterDateEnd, setFilterDateEnd] = useState('');
    
    // Paginação
    const [isRefreshing, setIsRefreshing] = useState(false);

    // --- LOAD FROM API ---
    const loadProcesses = useCallback(async () => {
        setProcessesLoading(true);
        try {
            const res = await api.get<{ data: LegalProcess[] }>('/api/legal-processes?limit=500&page=1');
            setProcesses(res.data || []);
        } catch {
            setProcesses([]);
        } finally {
            setProcessesLoading(false);
        }
    }, []);

    useEffect(() => { loadProcesses(); }, [loadProcesses]);

    // --- EFFECT: SYNC FROM AUDIT/ADMISSIONS (persists to DB) ---
    useEffect(() => {
        const relevantAdmissions = (config.admissions || []).filter(a => {
            if (a.status !== 'CONCLUIDO' || !a.legalScan || !a.legalScan.found || !a.legalScan.processNumber) return false;
            const modality = config.modalities.find(m => m.id === a.modalityId);
            return modality?.type?.toUpperCase() === 'VEÍCULOS';
        });

        const toCreate = relevantAdmissions.filter(adm =>
            !processes.some(p => p.processNumber === adm.legalScan!.processNumber)
        );

        if (toCreate.length === 0) return;

        (async () => {
            for (const adm of toCreate) {
                const scanData = adm.legalScan!;
                const initialMovement: ProcessMovement = {
                    date: new Date().toISOString(),
                    description: `[VARREDURA INICIAL] ${scanData.lastMovement}. \nAutor: ${scanData.plaintiff}`,
                    type: 'CERTIDAO',
                    source: 'ROBÔ JURÍDICO'
                };
                try {
                    await api.post('/api/legal-processes', {
                        client_id: adm.clientId,
                        client_name: adm.clientName,
                        admission_id: adm.id,
                        contract_number: adm.contractNumber,
                        process_number: scanData.processNumber,
                        court: scanData.court,
                        type: 'BUSCA E APREENSÃO',
                        status: 'ALERTA',
                        tags: ['Importado', 'Auditoria'],
                        notes: `Processo importado automaticamente da auditoria em ${new Date().toLocaleDateString()}.`,
                        movements: [initialMovement],
                    });
                } catch {
                    // Skip if already exists (unique constraint on process_number) or other error
                }
            }
            loadProcesses();
        })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [config.admissions, config.modalities]);

    // --- FILTROS AVANÇADOS ---
    const filteredProcesses = useMemo(() => {
        const lowerSearch = searchTerm.toLowerCase();
        
        return processes.filter(p => {
            // 1. Pesquisa Geral (Barra de Busca)
            const matchesSearch = 
                p.clientName.toLowerCase().includes(lowerSearch) || 
                p.processNumber.includes(lowerSearch) ||
                (p.contractNumber || '').includes(lowerSearch) ||
                p.court.toLowerCase().includes(lowerSearch);

            // 2. Filtro por Status
            const matchesStatus = filterStatus ? p.status === filterStatus : true;

            // 3. Filtro por Tribunal (Input específico)
            const matchesCourt = filterCourt ? p.court.toLowerCase().includes(filterCourt.toLowerCase()) : true;

            // 4. Filtro por Data de Movimentação
            let matchesDate = true;
            if (filterDateStart || filterDateEnd) {
                const pDate = p.lastUpdate.split('T')[0];
                if (filterDateStart && pDate < filterDateStart) matchesDate = false;
                if (filterDateEnd && pDate > filterDateEnd) matchesDate = false;
            }

            return matchesSearch && matchesStatus && matchesCourt && matchesDate;
        });
    }, [processes, searchTerm, filterStatus, filterCourt, filterDateStart, filterDateEnd]);


    // --- Stats ---
    const stats = useMemo(() => ({
        total: processes.length,
        moved: processes.filter(p => p.status === 'MOVIMENTADO' || p.status === 'ALERTA').length,
        stale: processes.filter(p => p.status === 'SEM_MOVIMENTO').length
    }), [processes]);

    // --- HANDLERS OCR ---
    const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        setIsReadingOCR(true);
        setOcrStatusMessage('Inicializando OCR...');

        try {
            const worker = await createWorker('por');
            
            setOcrStatusMessage('Lendo documento...');
            const ret = await worker.recognize(file);
            
            // Limpeza básica do texto
            const cleanText = ret.data.text.replace(/\n+/g, ' ').trim();
            
            setNewMovement(prev => ({
                ...prev,
                description: cleanText,
                source: 'OCR / Documento'
            }));
            
            await worker.terminate();
            addToast('success', 'OCR Concluído', 'Texto extraído com sucesso.');
        } catch (err) {
            console.error(err);
            addToast('error', 'Erro OCR', 'Falha ao ler o arquivo. Tente uma imagem mais nítida.');
        } finally {
            setIsReadingOCR(false);
            setOcrStatusMessage('');
            if (fileInputRef.current) fileInputRef.current.value = '';
        }
    };

    // --- HANDLERS CRUD ---

    const handleNewProcess = () => {
        if (!validarPermissao('INCLUIR')) return;
        const newProc: LegalProcess = {
            id: '',
            clientId: '',
            clientName: '',
            contractNumber: '',
            processNumber: '',
            court: '',
            type: 'BUSCA E APREENSÃO',
            status: 'SEM_MOVIMENTO',
            lastUpdate: new Date().toISOString(),
            movements: [],
            notes: ''
        };
        setCurrentProcess(newProc);
        setSelectedProcessDetails(null); 
        setIsEditing(true);
    };

    const isClientBlocked = (clientId: string) => {
        const client = config.clients.find(c => c.id === clientId);
        return client?.blocked === true;
    };

    const handleEditProcess = (proc: LegalProcess) => {
        if (!validarPermissao('ALTERAR')) return;
        if (isClientBlocked(proc.clientId)) {
            addToast('warning', 'Cliente Bloqueado', 'Cliente bloqueado — somente consulta. Não é possível editar este processo.');
            return;
        }
        setCurrentProcess({ ...proc });
        setSelectedProcessDetails(null); 
        setIsEditing(true);
    };

    const handleDeleteProcess = (id: string) => {
        if (!validarPermissao('EXCLUIR')) return;
        const proc = processes.find(p => p.id === id);
        if (proc && isClientBlocked(proc.clientId)) {
            addToast('warning', 'Cliente Bloqueado', 'Cliente bloqueado — somente consulta. Não é possível excluir este processo.');
            return;
        }
        setDeleteModal({
            title: 'Excluir Processo',
            message: 'Excluir este processo monitorado? Esta ação não pode ser desfeita.',
            onConfirm: async () => {
                try {
                    const isRealId = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(id);
                    if (isRealId) {
                        await api.delete(`/api/legal-processes/${id}`);
                    }
                    setProcesses(prev => prev.filter(p => p.id !== id));
                    logTransaction('JURIDICO' as any, id, proc || null, null);
                    addToast('success', 'Sucesso', 'Processo removido.');
                    if (selectedProcessDetails?.id === id) setSelectedProcessDetails(null);
                } catch {
                    addToast('error', 'Erro', 'Não foi possível excluir o processo.');
                    throw new Error('delete failed');
                }
            },
        });
    };

    const handleSave = async () => {
        if (!currentProcess?.clientId || !currentProcess.processNumber) {
            addToast('warning', 'Validação', 'Cliente e Nº do Processo são obrigatórios.');
            return;
        }

        const procToSave = { ...currentProcess };
        const originalProcess = processes.find(p => p.id === procToSave.id) || null;
        const isRealId = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(procToSave.id);

        try {
            let saved: LegalProcess;
            if (procToSave.id && isRealId) {
                const res = await api.put<{ data: LegalProcess }>(`/api/legal-processes/${procToSave.id}`, legalProcessToPayload(procToSave));
                saved = res.data;
                setProcesses(prev => prev.map(p => p.id === saved.id ? saved : p));
            } else {
                const res = await api.post<{ data: LegalProcess }>('/api/legal-processes', legalProcessToPayload(procToSave));
                saved = res.data;
                setProcesses(prev => [...prev, saved]);
            }
            logTransaction('JURIDICO' as any, saved.id, originalProcess, saved);
            setIsEditing(false);
            setCurrentProcess(null);
            addToast('success', 'Salvo', 'Processo salvo com sucesso.');
        } catch (err) {
            addToast('error', 'Erro', err instanceof Error ? err.message : 'Não foi possível salvar o processo.');
        }
    };

    const handleArchiveProcess = () => {
        if (!selectedProcessDetails) return;
        if (isClientBlocked(selectedProcessDetails.clientId)) {
            addToast('warning', 'Cliente Bloqueado', 'Cliente bloqueado — somente consulta. Não é possível arquivar este processo.');
            return;
        }
        setDeleteModal({
            title: 'Arquivar Processo',
            message: 'Arquivar este processo? Ele não aparecerá na lista principal.',
            onConfirm: async () => {
                try {
                    const isRealId = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(selectedProcessDetails.id);
                    const updated = { ...selectedProcessDetails, status: 'ARQUIVADO' as MovementStatus };
                    if (isRealId) {
                        await api.put(`/api/legal-processes/${selectedProcessDetails.id}`, legalProcessToPayload(updated));
                    }
                    const beforeArchive = { ...selectedProcessDetails };
                    setProcesses(prev => prev.map(p => p.id === selectedProcessDetails.id ? updated : p));
                    logTransaction('JURIDICO' as any, selectedProcessDetails.id, beforeArchive, updated);
                    addToast('info', 'Arquivado', 'Processo arquivado.');
                    setSelectedProcessDetails(null);
                } catch {
                    addToast('error', 'Erro', 'Não foi possível arquivar o processo.');
                    throw new Error('archive failed');
                }
            },
        });
    };

    // --- TIMELINE CRUD (ADD MOVEMENT) ---
    const handleSaveMovement = () => {
        if (!selectedProcessDetails || !newMovement.description) {
            addToast('warning', 'Atenção', 'A descrição é obrigatória.');
            return;
        }
        
        // Combina a data selecionada com a hora atual para ordenação
        const now = new Date();
        const finalDate = `${movementDate}T${now.toTimeString().split(' ')[0]}`;

        const movementToAdd: ProcessMovement = {
            date: finalDate,
            description: newMovement.description,
            type: newMovement.type as any,
            source: newMovement.source || 'Manual'
        };

        const updatedMovements = [movementToAdd, ...selectedProcessDetails.movements].sort((a, b) => 
            new Date(b.date).getTime() - new Date(a.date).getTime()
        );

        const updatedProcess = {
            ...selectedProcessDetails,
            lastUpdate: finalDate > selectedProcessDetails.lastUpdate ? finalDate : selectedProcessDetails.lastUpdate,
            status: 'MOVIMENTADO' as MovementStatus,
            movements: updatedMovements
        };

        // Atualiza a lista principal e o drawer
        setProcesses(prev => prev.map(p => p.id === updatedProcess.id ? updatedProcess : p));
        setSelectedProcessDetails(updatedProcess);
        setIsAddingMovement(false);
        setNewMovement({ type: 'DESPACHO', description: '', source: '' });
        setMovementDate(new Date().toISOString().split('T')[0]);

        // Persiste via API
        const isRealId = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(updatedProcess.id);
        if (isRealId) {
            api.put(`/api/legal-processes/${updatedProcess.id}`, legalProcessToPayload(updatedProcess))
                .then(() => {
                    logTransaction('JURIDICO' as any, selectedProcessDetails.id, selectedProcessDetails, updatedProcess);
                    addToast('success', 'Registrado', 'Nova movimentação adicionada e salva.');
                })
                .catch(() => addToast('error', 'Erro', 'Movimentação adicionada localmente, mas falhou ao salvar no servidor.'));
        } else {
            logTransaction('JURIDICO' as any, selectedProcessDetails.id, selectedProcessDetails, updatedProcess);
            addToast('success', 'Registrado', 'Nova movimentação adicionada.');
        }
    };

    // --- EDIT EXISTING MOVEMENT (CLICK ON CARD) ---
    const handleCardClick = (movement: ProcessMovement, index: number) => {
        if (!validarPermissao('ALTERAR')) return;
        if (selectedProcessDetails && isClientBlocked(selectedProcessDetails.clientId)) {
            addToast('warning', 'Cliente Bloqueado', 'Cliente bloqueado — somente consulta. Não é possível editar movimentações.');
            return;
        }
        setEditingMovementIdx(index);
        setEditMovementData({ ...movement });
    };

    const handleUpdateMovement = () => {
        if (!selectedProcessDetails || editingMovementIdx === null || !editMovementData) return;
        if (!editMovementData.description) {
            addToast('warning', 'Validação', 'Descrição é obrigatória.');
            return;
        }

        const newMovements = [...selectedProcessDetails.movements];
        newMovements[editingMovementIdx] = editMovementData;
        
        // Re-ordena por data caso a data tenha sido alterada
        newMovements.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

        const updatedProcess = {
            ...selectedProcessDetails,
            movements: newMovements
        };

        setProcesses(prev => prev.map(p => p.id === updatedProcess.id ? updatedProcess : p));
        setSelectedProcessDetails(updatedProcess);
        setEditingMovementIdx(null);
        setEditMovementData(null);

        const isRealId2 = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(updatedProcess.id);
        if (isRealId2) {
            api.put(`/api/legal-processes/${updatedProcess.id}`, legalProcessToPayload(updatedProcess))
                .then(() => addToast('success', 'Atualizado', 'Movimentação atualizada e salva.'))
                .catch(() => addToast('error', 'Erro', 'Movimentação atualizada localmente, mas falhou ao salvar no servidor.'));
        } else {
            addToast('success', 'Atualizado', 'Movimentação atualizada.');
        }
    };

    const handleDeleteMovement = () => {
        if (!selectedProcessDetails || editingMovementIdx === null) return;
        setDeleteModal({
            title: 'Excluir Movimentação',
            message: 'Excluir esta movimentação do histórico? Esta ação não pode ser desfeita.',
            onConfirm: async () => {
                const processBefore = { ...selectedProcessDetails };
                const newMovements = selectedProcessDetails.movements.filter((_, idx) => idx !== editingMovementIdx);
                const updatedProcess = { ...selectedProcessDetails, movements: newMovements };
                setProcesses(prev => prev.map(p => p.id === updatedProcess.id ? updatedProcess : p));
                setSelectedProcessDetails(updatedProcess);
                setEditingMovementIdx(null);
                setEditMovementData(null);

                const isRealId3 = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(updatedProcess.id);
                if (isRealId3) {
                    try {
                        await api.put(`/api/legal-processes/${updatedProcess.id}`, legalProcessToPayload(updatedProcess));
                        logTransaction('JURIDICO' as any, selectedProcessDetails.id, processBefore, updatedProcess);
                        addToast('success', 'Excluído', 'Movimentação removida e salva.');
                    } catch {
                        addToast('error', 'Erro', 'Movimentação removida localmente, mas falhou ao salvar no servidor.');
                    }
                } else {
                    logTransaction('JURIDICO' as any, selectedProcessDetails.id, processBefore, updatedProcess);
                    addToast('success', 'Excluído', 'Movimentação removida.');
                }
            },
        });
    };

    const handleRefresh = () => {
        setIsRefreshing(true);
        setTimeout(() => {
            setIsRefreshing(false);
            addToast('success', 'Atualizado', 'Tribunais consultados com sucesso.');
        }, 1500);
    };

    // --- FORM HELPERS ---
    const availableContracts = useMemo(() => {
        if (!currentProcess?.clientId) return [];
        return config.admissions.filter(a => a.clientId === currentProcess.clientId);
    }, [config.admissions, currentProcess?.clientId]);

    const handleClientChange = (clientId: string) => {
        const client = config.clients.find(c => c.id === clientId);
        if (client && currentProcess) {
            setCurrentProcess({ 
                ...currentProcess, 
                clientId: client.id, 
                clientName: client.name,
                admissionId: undefined,
                contractNumber: '' 
            });
        }
    };

    // --- HELPERS UI ---
    const getStatusStyle = (status: MovementStatus) => {
        switch (status) {
            case 'MOVIMENTADO': return 'bg-green-100 text-green-700 border-green-200';
            case 'ALERTA': return 'bg-red-100 text-red-700 border-red-200 animate-pulse';
            case 'SEM_MOVIMENTO': return 'bg-gray-100 text-gray-600 border-gray-200';
            case 'ARQUIVADO': return 'bg-blue-50 text-blue-600 border-blue-100';
            default: return 'bg-gray-100 text-gray-600';
        }
    };

    const getStatusLabel = (status: MovementStatus) => {
        switch (status) {
            case 'MOVIMENTADO': return 'Movimentado';
            case 'ALERTA': return 'Urgente / Decisão';
            case 'SEM_MOVIMENTO': return 'Sem Movimento';
            case 'ARQUIVADO': return 'Arquivado';
            default: return status;
        }
    };

    // --- RENDER FORM ---
    if (isEditing && currentProcess) {
        return (
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 animate-fade-in" data-form-container="true">
                <div className="flex justify-between items-center mb-6 pb-4 border-b">
                    <h3 className="text-xl font-bold text-gray-800">
                        {currentProcess.id ? 'Editar Processo' : 'Monitorar Novo Processo'}
                    </h3>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Cliente</label>
                        <select 
                            className="w-full border rounded-lg p-3 bg-white outline-none focus:ring-2 focus:ring-moss-500"
                            value={currentProcess.clientId}
                            onChange={(e) => handleClientChange(e.target.value)}
                        >
                            <option value="">Selecione o Cliente...</option>
                            {config.clients.map(c => (
                                <option key={c.id} value={c.id}>{c.name}</option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Contrato (Admissão)</label>
                        <select 
                            className="w-full border rounded-lg p-3 bg-white outline-none focus:ring-2 focus:ring-moss-500"
                            value={currentProcess.admissionId || ''}
                            onChange={(e) => {
                                const admission = availableContracts.find(adm => adm.id === e.target.value);
                                setCurrentProcess({...currentProcess, admissionId: admission?.id, contractNumber: admission?.contractNumber || ''});
                            }}
                            disabled={!currentProcess.clientId}
                        >
                            <option value="">Vincular Contrato (Opcional)</option>
                            {availableContracts.map(adm => (
                                <option key={adm.id} value={adm.id}>Contrato #{adm.contractNumber} - {config.banks.find(b => b.id === adm.bankId)?.name}</option>
                            ))}
                        </select>
                    </div>

                    <Input 
                        label="Número do Processo (CNJ)" 
                        value={currentProcess.processNumber} 
                        onChange={(e) => setCurrentProcess({...currentProcess, processNumber: e.target.value})} 
                        placeholder="0000000-00.0000.0.00.0000"
                    />

                    <Input 
                        label="Tribunal / Vara" 
                        value={currentProcess.court} 
                        onChange={(e) => setCurrentProcess({...currentProcess, court: e.target.value})} 
                        placeholder="Ex: TJSP - 1ª Vara Cível"
                    />

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Ação</label>
                        <select 
                            className="w-full border rounded-lg p-3 bg-white outline-none focus:ring-2 focus:ring-moss-500"
                            value={currentProcess.type}
                            onChange={(e) => setCurrentProcess({...currentProcess, type: e.target.value})}
                        >
                            <option value="BUSCA E APREENSÃO">BUSCA E APREENSÃO</option>
                            <option value="EXECUÇÃO DE TÍTULO">EXECUÇÃO DE TÍTULO</option>
                            <option value="MONITÓRIA">MONITÓRIA</option>
                            <option value="REVISIONAL">REVISIONAL</option>
                            <option value="OUTROS">OUTROS</option>
                        </select>
                    </div>

                    <div>
                        <label className="block text-sm font-medium text-gray-700 mb-1">Status Inicial</label>
                        <select 
                            className="w-full border rounded-lg p-3 bg-white outline-none focus:ring-2 focus:ring-moss-500"
                            value={currentProcess.status}
                            onChange={(e) => setCurrentProcess({...currentProcess, status: e.target.value as MovementStatus})}
                        >
                            <option value="SEM_MOVIMENTO">Sem Movimento</option>
                            <option value="MOVIMENTADO">Movimentado</option>
                            <option value="ALERTA">Alerta / Urgente</option>
                            <option value="ARQUIVADO">Arquivado</option>
                        </select>
                    </div>

                    <div className="md:col-span-2">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Observações Internas</label>
                        <textarea 
                            className="w-full border border-gray-300 rounded-lg p-3 h-24 outline-none focus:ring-2 focus:ring-moss-500"
                            value={currentProcess.notes || ''}
                            onChange={(e) => setCurrentProcess({...currentProcess, notes: e.target.value})}
                        />
                    </div>
                </div>

                <FormActions onSave={handleSave} onCancel={() => { setIsEditing(false); setCurrentProcess(null); }} />
            </div>
        );
    }

    // --- RENDER LIST ---
    return (
        <>
        <div className="flex h-full animate-fade-in relative overflow-hidden bg-gray-50/50">
            {/* LEFT SIDE - LIST */}
            <div className={`flex flex-col h-full transition-all duration-300 compact-virtual-grid ${selectedProcessDetails ? 'w-2/3 pr-2' : 'w-full'}`} data-grid-density="compact">
                {/* Header & Stats */}
                <div className="mb-6">
                    <div className="flex justify-between items-center mb-6">
                        <div>
                            <h2 className="text-2xl font-bold text-gray-800">Monitoramento Jurídico</h2>
                            <p className="text-sm text-gray-500">Acompanhamento automático de processos.</p>
                        </div>
                        <div className="flex gap-2">
                            <Button 
                                variant="secondary" 
                                className="!w-auto" 
                                onClick={handleRefresh}
                                isLoading={isRefreshing}
                            >
                                {isRefreshing ? 'Consultando...' : '🔄 Atualizar'}
                            </Button>
                            <Button variant="new" className="!w-auto" onClick={handleNewProcess}>
                                + Novo Processo
                            </Button>
                        </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mb-6">
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-l-4 border-l-blue-500 border-gray-200">
                            <span className="text-xs font-bold text-gray-400 uppercase">Monitorados</span>
                            <div className="text-2xl font-black text-gray-800">{stats.total}</div>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-l-4 border-l-green-500 border-gray-200">
                            <span className="text-xs font-bold text-gray-400 uppercase">Movimentados</span>
                            <div className="text-2xl font-black text-green-600">{stats.moved}</div>
                        </div>
                        <div className="bg-white p-4 rounded-lg shadow-sm border border-l-4 border-l-gray-400 border-gray-200">
                            <span className="text-xs font-bold text-gray-400 uppercase">Parados</span>
                            <div className="text-2xl font-black text-gray-600">{stats.stale}</div>
                        </div>
                    </div>

                    <div className="bg-white p-3 rounded-lg shadow-sm border border-gray-200 flex flex-col gap-3 grid-search">
                        <div className="flex gap-3">
                            <div className="flex-1">
                                <Input 
                                    label="" 
                                    placeholder="Buscar por Cliente, Processo, Contrato ou Tribunal..." 
                                    value={searchTerm} 
                                    onChange={e => setSearchTerm(e.target.value)} 
                                    containerClassName="!mb-0"
                                    icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>}
                                />
                            </div>
                            <Button variant="ghost" className={`!w-auto border ${showFilters ? 'bg-gray-100' : ''}`} onClick={() => setShowFilters(!showFilters)}>
                                Filtros
                            </Button>
                        </div>

                        {showFilters && (
                            <div className="grid grid-cols-1 md:grid-cols-4 gap-3 pt-2 border-t animate-fade-in-down">
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Status</label>
                                    <select className="w-full p-2 border rounded text-sm outline-none" value={filterStatus} onChange={e => setFilterStatus(e.target.value)}>
                                        <option value="">Todos</option>
                                        <option value="MOVIMENTADO">Movimentado</option>
                                        <option value="SEM_MOVIMENTO">Sem Movimento</option>
                                        <option value="ALERTA">Alerta</option>
                                        <option value="ARQUIVADO">Arquivado</option>
                                    </select>
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Tribunal</label>
                                    <input type="text" className="w-full p-2 border rounded text-sm outline-none" placeholder="Ex: TJSP" value={filterCourt} onChange={e => setFilterCourt(e.target.value)} />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Data Início (Mov.)</label>
                                    <input type="date" className="w-full p-2 border rounded text-sm outline-none" value={filterDateStart} onChange={e => setFilterDateStart(e.target.value)} />
                                </div>
                                <div>
                                    <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Data Fim (Mov.)</label>
                                    <input type="date" className="w-full p-2 border rounded text-sm outline-none" value={filterDateEnd} onChange={e => setFilterDateEnd(e.target.value)} />
                                </div>
                            </div>
                        )}
                    </div>
                </div>

                {/* Data Grid */}
                <div className="flex-1 bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex flex-col">
                    <div className="overflow-y-auto custom-scrollbar flex-1 grid-body-scroll">
                        <div className="compact-virtual-row flex items-center bg-gray-50 border-b border-gray-200 flex-shrink-0" style={{ minWidth: '700px' }}>
                            <div className="px-6 py-3 w-32 flex-shrink-0 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Status</div>
                            <div className="px-6 py-3 flex-1 min-w-0 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Processo / Tribunal</div>
                            <div className="px-6 py-3 w-28 flex-shrink-0 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Contrato</div>
                            <div className="px-6 py-3 w-48 flex-shrink-0 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">Cliente</div>
                            <div className="px-6 py-3 w-32 flex-shrink-0 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Última Mov.</div>
                            <div className="px-6 py-3 w-32 flex-shrink-0 text-right text-xs font-bold text-gray-500 uppercase tracking-wider">Ações</div>
                        </div>
                        {filteredProcesses.length === 0 ? (
                            <div className="px-6 py-10 text-center text-gray-400">Nenhum processo encontrado.</div>
                        ) : (
                            <FixedSizeList
                                height={Math.min(filteredProcesses.length * 40, 520)}
                                itemCount={filteredProcesses.length}
                                itemSize={40}
                                width="100%"
                                overscanCount={5}
                                itemData={{ filteredProcesses, selectedProcessDetailsId: selectedProcessDetails?.id, clients: config.clients, auditLogs: config.auditLogs, getStatusStyle, getStatusLabel, setSelectedProcessDetails, setLegalDrawerTab, handleEditProcess, handleDeleteProcess } as LegalRowItemData}
                            >
                                {({ index, style, data }: { index: number; style: React.CSSProperties; data: LegalRowItemData }) => {
                                    const proc = data.filteredProcesses[index];
                                    const cl = data.clients.find((c: Client) => c.id === proc.clientId);
                                    return (
                                        <div
                                            style={style}
                                            className={`compact-virtual-row flex items-center border-b border-gray-100 cursor-pointer transition-colors hover:bg-blue-50 ${data.selectedProcessDetailsId === proc.id ? 'bg-blue-50 border-l-4 border-l-blue-500' : ''}`}
                                            onClick={() => { data.setSelectedProcessDetails(proc); data.setLegalDrawerTab('timeline'); }}
                                        >
                                            <div className="px-6 w-32 flex-shrink-0">
                                                <span className={`px-2 py-1 inline-flex text-[10px] font-black rounded-full uppercase border ${data.getStatusStyle(proc.status)}`}>{data.getStatusLabel(proc.status)}</span>
                                            </div>
                                            <div className="px-6 flex-1 min-w-0">
                                                <div className="text-xs font-mono font-bold text-gray-800 truncate">{proc.processNumber}</div>
                                                <div className="text-[10px] text-gray-500 font-medium uppercase truncate">{proc.court}</div>
                                            </div>
                                            <div className="px-6 w-28 flex-shrink-0">
                                                <span className="text-xs font-bold text-moss-700 bg-moss-50 px-2 py-1 rounded border border-moss-100">{proc.contractNumber ? `#${proc.contractNumber}` : 'N/A'}</span>
                                            </div>
                                            <div className="px-6 w-48 flex-shrink-0">
                                                <div className="text-sm font-bold text-gray-900 flex items-center gap-1.5 truncate">{proc.clientName}{cl?.blocked ? <BlockedClientBanner client={cl} compact /> : null}</div>
                                                <div className="flex gap-1 mt-1">
                                                    {proc.tags?.map(tag => <span key={tag} className="text-[9px] bg-gray-100 text-gray-600 px-1.5 rounded border border-gray-200">{tag}</span>)}
                                                </div>
                                            </div>
                                            <div className="px-6 w-32 flex-shrink-0 text-right">
                                                <div className="text-xs font-bold text-gray-700">{new Date(proc.lastUpdate).toLocaleDateString('pt-BR')}</div>
                                                <div className="text-[10px] text-gray-400">há {Math.floor((Date.now() - new Date(proc.lastUpdate).getTime()) / (1000 * 60 * 60 * 24))} dias</div>
                                            </div>
                                            <div className="px-6 w-32 flex-shrink-0 text-right" onClick={e => e.stopPropagation()}>
                                                <div className="flex justify-end gap-2">
                                                    <AuditLogButton entityId={proc.id} entityName={proc.clientName || proc.processNumber} logs={data.auditLogs || []} />
                                                    <button onClick={() => data.setSelectedProcessDetails(proc)} className="text-moss-600 hover:text-moss-800 p-1 hover:bg-moss-50 rounded">
                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                                                    </button>
                                                    <button onClick={() => data.handleEditProcess(proc)} className="text-blue-600 hover:text-blue-800 p-1 hover:bg-blue-100 rounded">
                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                                                    </button>
                                                    <button onClick={() => data.handleDeleteProcess(proc.id)} className="text-red-600 hover:text-red-800 p-1 hover:bg-red-100 rounded">
                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    );
                                }}
                            </FixedSizeList>
                        )}
                    </div>
                </div>
            </div>

            {/* RIGHT SIDE - DETAILS DRAWER */}
            <div className={`fixed inset-y-0 right-0 w-[450px] bg-white shadow-2xl transform transition-transform duration-300 ease-in-out z-40 border-l border-gray-200 ${selectedProcessDetails ? 'translate-x-0' : 'translate-x-full'}`}>
                {selectedProcessDetails && (
                    <div className="flex flex-col h-full relative">
                        {/* HEADER */}
                        <div className="p-6 bg-moss-900 text-white flex justify-between items-start shadow-md">
                            <div>
                                <h3 className="font-bold text-lg leading-tight uppercase tracking-tighter">Detalhes do Processo</h3>
                                <p className="text-xs text-moss-300 font-mono mt-1 select-all">{selectedProcessDetails.processNumber}</p>
                            </div>
                            <button onClick={() => setSelectedProcessDetails(null)} className="text-moss-300 hover:text-white transition-colors">
                                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                            </button>
                        </div>

                        <div className="p-6 border-b bg-gray-50">
                            {(() => { const cl = config.clients.find(c => c.id === selectedProcessDetails.clientId); return cl?.blocked ? <div className="mb-4"><BlockedClientBanner client={cl} /></div> : null; })()}
                            <div className="flex items-center justify-between mb-4">
                                <span className={`px-3 py-1 rounded-full text-xs font-black uppercase border ${getStatusStyle(selectedProcessDetails.status)}`}>
                                    {getStatusLabel(selectedProcessDetails.status)}
                                </span>
                                <span className="text-[10px] font-bold text-gray-400 uppercase">{selectedProcessDetails.type}</span>
                            </div>
                            <div className="space-y-3">
                                <div>
                                    <label className="text-[10px] font-black text-gray-400 uppercase">Cliente</label>
                                    <p className="text-sm font-bold text-gray-800">{selectedProcessDetails.clientName}</p>
                                </div>
                                <div className="flex justify-between">
                                    <div>
                                        <label className="text-[10px] font-black text-gray-400 uppercase">Tribunal</label>
                                        <p className="text-sm text-gray-700">{selectedProcessDetails.court}</p>
                                    </div>
                                    <div className="text-right">
                                        <label className="text-[10px] font-black text-gray-400 uppercase">Contrato</label>
                                        <p className="text-sm font-mono font-bold text-moss-700">{selectedProcessDetails.contractNumber || 'N/A'}</p>
                                    </div>
                                </div>
                                {selectedProcessDetails.admissionId && (() => {
                                    const adm = config.admissions.find(a => a.id === selectedProcessDetails.admissionId);
                                    return adm ? (
                                        <button onClick={() => handleOpenAdmissionModal(adm)} className="w-full mt-2 text-xs text-moss-600 hover:text-moss-800 bg-moss-50 hover:bg-moss-100 border border-moss-200 px-3 py-2 rounded-lg font-semibold flex items-center justify-center gap-2 transition-colors">
                                            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                                            Ver Ficha de Admissão
                                        </button>
                                    ) : null;
                                })()}
                            </div>
                        </div>

                        {/* SMART INPUT FORM (QUICK MOVEMENT) */}
                        {isAddingMovement && (
                            <div className="p-4 bg-blue-50 border-b border-blue-200 animate-fade-in-down">
                                <div className="space-y-3">
                                    <div className="flex justify-between items-center">
                                        <h4 className="text-xs font-bold text-blue-800 uppercase flex items-center gap-2">
                                            Nova Movimentação
                                            {isReadingOCR && <span className="text-[9px] bg-blue-200 text-blue-800 px-1.5 rounded animate-pulse">{ocrStatusMessage}</span>}
                                        </h4>
                                        <button onClick={() => setIsAddingMovement(false)} className="text-blue-400 hover:text-blue-600">✕</button>
                                    </div>
                                    
                                    {/* DATA E TIPO */}
                                    <div className="flex gap-2">
                                        <input 
                                            type="date"
                                            className="w-1/3 p-2 border border-blue-200 rounded text-xs outline-none bg-white focus:ring-2 focus:ring-blue-300"
                                            value={movementDate}
                                            onChange={e => setMovementDate(e.target.value)}
                                        />
                                        <select 
                                            className="flex-1 p-2 border border-blue-200 rounded text-xs outline-none bg-white focus:ring-2 focus:ring-blue-300"
                                            value={newMovement.type}
                                            onChange={e => setNewMovement({...newMovement, type: e.target.value as any})}
                                        >
                                            <option value="DESPACHO">Despacho</option>
                                            <option value="DECISAO">Decisão</option>
                                            <option value="SENTENCA">Sentença</option>
                                            <option value="AUDIENCIA">Audiência</option>
                                            <option value="PETICAO">Petição</option>
                                            <option value="CERTIDAO">Certidão</option>
                                        </select>
                                    </div>

                                    {/* FONTE DA PUBLICAÇÃO */}
                                    <input 
                                        type="text"
                                        className="w-full p-2 border border-blue-200 rounded text-xs outline-none focus:ring-2 focus:ring-blue-300 uppercase"
                                        placeholder="Fonte (Ex: DJE, DOU, PJe, E-mail)..."
                                        value={newMovement.source || ''}
                                        onChange={e => setNewMovement({...newMovement, source: e.target.value})}
                                    />

                                    {/* ÁREA DE DESCRIÇÃO + DROPZONE */}
                                    <div className="relative">
                                        <textarea 
                                            className={`w-full p-2 border rounded text-xs outline-none focus:ring-2 focus:ring-blue-300 resize-none h-24 ${isReadingOCR ? 'bg-gray-100 text-gray-400' : 'bg-white border-blue-200'}`}
                                            placeholder="Cole o texto ou arraste um print do diário oficial aqui..."
                                            value={newMovement.description}
                                            onChange={e => setNewMovement({...newMovement, description: e.target.value})}
                                            disabled={isReadingOCR}
                                        />
                                        
                                        {/* File Upload Trigger */}
                                        <div className="absolute bottom-2 right-2 flex gap-1">
                                            <input 
                                                type="file" 
                                                ref={fileInputRef} 
                                                className="hidden" 
                                                accept="image/*, application/pdf" 
                                                onChange={handleFileChange}
                                            />
                                            <button 
                                                onClick={() => fileInputRef.current?.click()}
                                                className="bg-blue-100 text-blue-600 hover:bg-blue-200 p-1.5 rounded text-[10px] font-bold flex items-center gap-1 transition-colors"
                                                title="Ler texto da imagem (OCR)"
                                                disabled={isReadingOCR}
                                            >
                                                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                                OCR
                                            </button>
                                        </div>
                                    </div>

                                    <div className="flex justify-end gap-2">
                                        <button onClick={() => setIsAddingMovement(false)} className="px-3 py-1 text-xs text-blue-600 hover:bg-blue-100 rounded">Cancelar</button>
                                        <button onClick={handleSaveMovement} className="px-3 py-1 text-xs bg-blue-600 text-white rounded hover:bg-blue-700 font-bold disabled:opacity-50" disabled={isReadingOCR}>Salvar</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* OVERLAY MODAL FOR EDITING MOVEMENT */}
                        {editingMovementIdx !== null && editMovementData && (
                            <div className="absolute inset-0 bg-white/95 z-50 flex flex-col p-6 animate-fade-in">
                                <div className="flex justify-between items-center mb-6">
                                    <h4 className="text-sm font-bold text-gray-800 uppercase border-b-2 border-yellow-400 pb-1">Editar Movimentação</h4>
                                    <button onClick={() => setEditingMovementIdx(null)} className="text-gray-400 hover:text-gray-600 font-bold text-xl">✕</button>
                                </div>
                                <div className="space-y-4 flex-1">
                                    <div className="flex gap-2">
                                        <div className="w-1/3">
                                            <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Data</label>
                                            <input 
                                                type="date"
                                                className="w-full p-2 border border-gray-300 rounded text-xs outline-none bg-white focus:ring-2 focus:ring-yellow-400"
                                                value={editMovementData.date.split('T')[0]}
                                                onChange={e => setEditMovementData({...editMovementData, date: e.target.value + 'T12:00:00'})}
                                            />
                                        </div>
                                        <div className="flex-1">
                                            <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Tipo</label>
                                            <select 
                                                className="w-full p-2 border border-gray-300 rounded text-xs outline-none bg-white focus:ring-2 focus:ring-yellow-400"
                                                value={editMovementData.type}
                                                onChange={e => setEditMovementData({...editMovementData, type: e.target.value as any})}
                                            >
                                                <option value="DESPACHO">Despacho</option>
                                                <option value="DECISAO">Decisão</option>
                                                <option value="SENTENCA">Sentença</option>
                                                <option value="AUDIENCIA">Audiência</option>
                                                <option value="PETICAO">Petição</option>
                                                <option value="CERTIDAO">Certidão</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div>
                                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Fonte</label>
                                        <input 
                                            type="text"
                                            className="w-full p-2 border border-gray-300 rounded text-xs outline-none focus:ring-2 focus:ring-yellow-400 uppercase"
                                            value={editMovementData.source || ''}
                                            onChange={e => setEditMovementData({...editMovementData, source: e.target.value})}
                                        />
                                    </div>
                                    <div className="flex-1 flex flex-col">
                                        <label className="block text-[10px] font-bold text-gray-500 uppercase mb-1">Descrição</label>
                                        <textarea 
                                            className="w-full flex-1 p-3 border border-gray-300 rounded text-xs outline-none focus:ring-2 focus:ring-yellow-400 resize-none min-h-[150px]"
                                            value={editMovementData.description}
                                            onChange={e => setEditMovementData({...editMovementData, description: e.target.value})}
                                        />
                                    </div>
                                </div>
                                <div className="flex justify-between items-center mt-6 pt-4 border-t border-gray-100">
                                    <button onClick={handleDeleteMovement} className="text-red-500 hover:text-red-700 text-xs font-bold uppercase flex items-center gap-1">
                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                        Excluir
                                    </button>
                                    <div className="flex gap-2">
                                        <button onClick={() => setEditingMovementIdx(null)} className="px-4 py-2 text-xs font-bold text-gray-600 hover:bg-gray-100 rounded">Cancelar</button>
                                        <button onClick={handleUpdateMovement} className="px-6 py-2 text-xs font-bold text-white bg-yellow-500 hover:bg-yellow-600 rounded shadow-sm">Salvar Alterações</button>
                                    </div>
                                </div>
                            </div>
                        )}

                        {/* Drawer Tabs */}
                        <div className="flex border-b border-gray-200 bg-white shrink-0 px-4">
                            <button onClick={() => setLegalDrawerTab('timeline')} className={`px-4 py-3 text-xs font-bold border-b-2 transition-colors uppercase tracking-wide ${legalDrawerTab === 'timeline' ? 'border-moss-600 text-moss-700' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                                Linha do Tempo
                            </button>
                            <button onClick={() => setLegalDrawerTab('whatsapp')} className={`px-4 py-3 text-xs font-bold border-b-2 transition-colors flex items-center gap-1.5 ${legalDrawerTab === 'whatsapp' ? 'border-green-600 text-green-700' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                                <svg className="w-3.5 h-3.5" viewBox="0 0 24 24" fill="currentColor"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
                                WhatsApp
                            </button>
                            <button onClick={() => setLegalDrawerTab('atendimentos')} className={`px-4 py-3 text-xs font-bold border-b-2 transition-colors flex items-center gap-1.5 ${legalDrawerTab === 'atendimentos' ? 'border-green-600 text-green-700' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
                                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                                Atendimentos
                            </button>
                        </div>

                        {legalDrawerTab === 'whatsapp' ? (
                            <div className="flex-1 overflow-hidden">
                                <GotalkChatPanel clientId={selectedProcessDetails.clientId} area="JURIDICO" operatorName={currentUser?.name} />
                            </div>
                        ) : legalDrawerTab === 'atendimentos' ? (
                            <div className="flex-1 overflow-hidden">
                                <GotalkAttendanceViewer clientId={selectedProcessDetails.clientId} title="Atendimentos GoTalk — Jurídico" />
                            </div>
                        ) : (

                        <div className="flex-1 overflow-y-auto p-6 bg-white relative">
                            <div className="flex justify-between items-center mb-6 border-b pb-2">
                                <h4 className="font-bold text-gray-800 text-sm uppercase tracking-widest">Linha do Tempo</h4>
                                {!isAddingMovement && (
                                    <button 
                                        onClick={() => { const cl = config.clients.find(c => c.id === selectedProcessDetails.clientId); if (!cl?.blocked) setIsAddingMovement(true); }}
                                        disabled={!!config.clients.find(c => c.id === selectedProcessDetails.clientId)?.blocked}
                                        className={`text-[10px] px-2 py-1 rounded font-bold uppercase border transition-colors ${config.clients.find(c => c.id === selectedProcessDetails.clientId)?.blocked ? 'bg-gray-100 text-gray-400 border-gray-200 cursor-not-allowed' : 'bg-gray-100 hover:bg-gray-200 text-gray-600 border-gray-200'}`}
                                        title={config.clients.find(c => c.id === selectedProcessDetails.clientId)?.blocked ? 'Cliente bloqueado — movimentações desabilitadas' : undefined}
                                    >
                                        + Movimentação
                                    </button>
                                )}
                            </div>
                            
                            <div className="space-y-0 relative border-l-2 border-gray-200 ml-3">
                                {selectedProcessDetails.movements.length === 0 && (
                                    <p className="text-xs text-gray-400 italic ml-6">Nenhuma movimentação registrada.</p>
                                )}
                                {selectedProcessDetails.movements.map((mov, idx) => (
                                    <div key={idx} className="mb-8 ml-6 relative group">
                                        <div className={`absolute -left-[31px] top-0 w-4 h-4 rounded-full border-2 border-white shadow-sm ${
                                            idx === 0 ? 'bg-green-500 ring-4 ring-green-100' : 'bg-gray-300'
                                        }`}></div>
                                        
                                        <div 
                                            className="bg-white p-3 rounded-lg border border-gray-100 shadow-sm hover:shadow-md transition-all cursor-pointer hover:border-blue-300 relative"
                                            onClick={() => handleCardClick(mov, idx)}
                                            title="Clique para editar"
                                        >
                                            <div className="flex justify-between items-start mb-1">
                                                <div className="flex gap-2">
                                                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded uppercase ${
                                                        mov.type === 'DECISAO' ? 'bg-red-100 text-red-700' :
                                                        mov.type === 'DESPACHO' ? 'bg-blue-100 text-blue-700' :
                                                        'bg-gray-100 text-gray-600'
                                                    }`}>{mov.type}</span>
                                                    {mov.source && (
                                                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded uppercase bg-amber-50 text-amber-700 border border-amber-100">
                                                            {mov.source}
                                                        </span>
                                                    )}
                                                </div>
                                                <span className="text-[10px] text-gray-400 font-mono">{new Date(mov.date).toLocaleDateString()}</span>
                                            </div>
                                            <p className="text-xs text-gray-700 font-medium leading-relaxed whitespace-pre-wrap">
                                                {mov.description}
                                            </p>
                                            {idx === 0 && (
                                                <span className="inline-block mt-2 text-[9px] font-bold text-green-600 uppercase tracking-wide">
                                                    Última Movimentação
                                                </span>
                                            )}
                                            {/* Hover Edit Icon */}
                                            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <svg className="w-4 h-4 text-blue-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        </div>
                        )}

                        <div className="p-4 border-t bg-gray-50 flex justify-between items-center">
                            <Button 
                                variant="outline" 
                                className="!w-auto !text-xs !py-2 !px-3 text-red-600 border-red-200 hover:bg-red-50 hover:border-red-300" 
                                onClick={handleArchiveProcess}
                                title="Remover da lista de monitoramento"
                            >
                                🗄️ Arquivar Processo
                            </Button>
                            
                            <div className="flex gap-2">
                                <Button variant="outline" className="!w-auto !text-xs" onClick={() => addToast('info', 'PDF', 'Gerando relatório PDF...')}>
                                    📄 PDF
                                </Button>
                                <Button variant="primary" className="!w-auto !text-xs" onClick={() => window.open(`https://www.google.com/search?q=${selectedProcessDetails.processNumber}`, '_blank')}>
                                    🔗 Tribunal
                                </Button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </div>

        {viewingAdmission && (
            <AdmissionViewerModal
                admission={viewingAdmission}
                clientName={config.clients.find(c => c.id === viewingAdmission.clientId)?.name || viewingAdmission.clientName || viewingAdmission.clientId}
                onClose={() => setViewingAdmission(null)}
            />
        )}
        <ConfirmDeleteModal
            isOpen={!!deleteModal}
            title={deleteModal?.title ?? ''}
            message={deleteModal?.message ?? ''}
            onConfirm={handleDeleteConfirmed}
            onCancel={() => setDeleteModal(null)}
            isLoading={deleteLoading}
        />
        </>
    );
};

export default LegalPanel;
import React, { useState, useEffect, useRef, useCallback } from 'react';
import 'tinymce/tinymce';
import 'tinymce/themes/silver';
import 'tinymce/models/dom';
import 'tinymce/icons/default';
import 'tinymce/plugins/lists';
import 'tinymce/plugins/link';
import 'tinymce/plugins/code';
import 'tinymce/plugins/table';
import { Editor } from '@tinymce/tinymce-react';
import type { Editor as TinyMCEEditor } from 'tinymce';

interface KnowledgeImage {
  mimeType: string;
  data: string;
}

interface Article {
  id: string;
  title: string;
  category: string;
  content: string;
  images: KnowledgeImage[];
  active: boolean;
  content_preview?: string;
  image_count?: number;
  created_at: string;
  updated_at: string;
}

const MAX_IMAGES = 3;
const MAX_IMAGE_MB = 2;
const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

const DEFAULT_CATEGORIES = [
  'Geral', 'Admissão', 'Agenda', 'Financeiro', 'Jurídico',
  'Cobrança', 'Negociação', 'Relatórios', 'Configurações',
  'Comercial', 'Auditoria', 'Mensagens', 'WhatsApp'
];

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
}

function stripHtml(html: string) {
  return html.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
}

function getErrorMessage(err: unknown): string {
  return err instanceof Error ? err.message : 'Erro desconhecido.';
}

const LeoKnowledgePanel: React.FC = () => {
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterCategory, setFilterCategory] = useState('');

  const [isEditing, setIsEditing] = useState(false);
  const [editingArticle, setEditingArticle] = useState<Article | null>(null);
  const [saveLoading, setSaveLoading] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const editorRef = useRef<TinyMCEEditor | null>(null);

  const loadArticles = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/leo-knowledge');
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      setArticles(data);
    } catch (err) {
      setError(getErrorMessage(err));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { loadArticles(); }, [loadArticles]);

  const loadFullArticle = async (id: string): Promise<Article | null> => {
    try {
      const res = await fetch(`/api/leo-knowledge/${id}`);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      return await res.json();
    } catch {
      return null;
    }
  };

  const handleNew = () => {
    setEditingArticle({
      id: '',
      title: '',
      category: 'Geral',
      content: '',
      images: [],
      active: true,
      created_at: '',
      updated_at: '',
    });
    setSaveError(null);
    setIsEditing(true);
  };

  const handleEdit = async (article: Article) => {
    const full = await loadFullArticle(article.id);
    if (!full) return;
    setEditingArticle({ ...full });
    setSaveError(null);
    setIsEditing(true);
  };

  const handleDelete = async (id: string) => {
    try {
      const res = await fetch(`/api/leo-knowledge/${id}`, { method: 'DELETE' });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      setDeleteConfirm(null);
      await loadArticles();
    } catch (err) {
      alert('Erro ao excluir: ' + getErrorMessage(err));
    }
  };

  const handleSave = async () => {
    if (!editingArticle) return;
    if (!editingArticle.title.trim()) {
      setSaveError('O título é obrigatório.');
      return;
    }
    setSaveLoading(true);
    setSaveError(null);
    try {
      const content = editorRef.current ? editorRef.current.getContent() : editingArticle.content;
      const method = editingArticle.id ? 'PUT' : 'POST';
      const url = editingArticle.id ? `/api/leo-knowledge/${editingArticle.id}` : '/api/leo-knowledge';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: editingArticle.title.trim(),
          category: editingArticle.category,
          content,
          images: editingArticle.images,
          active: editingArticle.active,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
      setIsEditing(false);
      setEditingArticle(null);
      await loadArticles();
    } catch (err) {
      setSaveError(getErrorMessage(err));
    } finally {
      setSaveLoading(false);
    }
  };

  const processImageFiles = useCallback((files: File[]) => {
    if (!editingArticle) return;
    const current = editingArticle.images.length;
    const available = MAX_IMAGES - current;
    if (available <= 0) {
      alert(`Máximo de ${MAX_IMAGES} imagens por artigo já atingido.`);
      return;
    }
    const toProcess = files.slice(0, available);
    toProcess.forEach(file => {
      if (!ALLOWED_TYPES.includes(file.type)) {
        alert(`Tipo não permitido: ${file.type}. Use JPEG, PNG ou WEBP.`);
        return;
      }
      if (file.size > MAX_IMAGE_MB * 1024 * 1024) {
        alert(`"${file.name}" excede ${MAX_IMAGE_MB} MB.`);
        return;
      }
      const reader = new FileReader();
      reader.onload = ev => {
        const dataUrl = ev.target?.result as string;
        const base64 = dataUrl.split(',')[1];
        setEditingArticle(prev => {
          if (!prev || prev.images.length >= MAX_IMAGES) return prev;
          return { ...prev, images: [...prev.images, { mimeType: file.type, data: base64 }] };
        });
      };
      reader.readAsDataURL(file);
    });
  }, [editingArticle]);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    processImageFiles(files);
    e.target.value = '';
  };

  const handleRemoveImage = (idx: number) => {
    if (!editingArticle) return;
    setEditingArticle(prev => {
      if (!prev) return prev;
      return { ...prev, images: prev.images.filter((_, i) => i !== idx) };
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (!editingArticle) return;
    const files = Array.from(e.dataTransfer.files).filter(f => ALLOWED_TYPES.includes(f.type));
    if (files.length > 0) processImageFiles(files);
  };

  const filteredArticles = articles.filter(a => {
    const q = searchTerm.toLowerCase();
    const matchText = !q || a.title.toLowerCase().includes(q) || (a.content_preview || '').toLowerCase().includes(q) || a.category.toLowerCase().includes(q);
    const matchCat = !filterCategory || a.category === filterCategory;
    return matchText && matchCat;
  });

  const allCategories = Array.from(new Set([...DEFAULT_CATEGORIES, ...articles.map(a => a.category)])).sort();

  if (isEditing && editingArticle) {
    return (
      <div className="flex flex-col gap-5 animate-fade-in">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-gray-800">
              {editingArticle.id ? 'Editar Artigo' : 'Novo Artigo'}
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              Os artigos são usados pelo Léo para responder perguntas com mais precisão.
            </p>
          </div>
          <button
            onClick={() => { setIsEditing(false); setEditingArticle(null); }}
            className="text-gray-400 hover:text-gray-600 p-2 rounded-lg hover:bg-gray-100 transition"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        {saveError && (
          <div className="flex items-center gap-2 p-3 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
            <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
            {saveError}
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="md:col-span-2">
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1">Título *</label>
            <input
              type="text"
              value={editingArticle.title}
              onChange={e => setEditingArticle(prev => prev ? { ...prev, title: e.target.value } : prev)}
              placeholder="Ex: Como cadastrar um novo cliente"
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none"
              maxLength={255}
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1">Categoria</label>
            <select
              value={editingArticle.category}
              onChange={e => setEditingArticle(prev => prev ? { ...prev, category: e.target.value } : prev)}
              className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 outline-none bg-white"
            >
              {allCategories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide mb-1">Conteúdo</label>
          <p className="text-xs text-gray-400 mb-2">Descreva detalhadamente como o módulo funciona: campos, passos, fluxos, regras e dicas.</p>
          <Editor
            onInit={(_, editor) => { editorRef.current = editor; }}
            initialValue={editingArticle.content}
            licenseKey="gpl"
            init={{
              height: 380,
              menubar: false,
              skin_url: '/tinymce-skins/ui/oxide',
              content_css: '/tinymce-skins/content/default/content.min.css',
              plugins: 'lists link code table',
              toolbar: 'undo redo | bold italic | bullist numlist | link table | code',
              branding: false,
              promotion: false,
              statusbar: false,
              resize: false,
              placeholder: 'Descreva detalhes do módulo, campos disponíveis, fluxo de uso, dicas importantes...',
            }}
          />
        </div>

        <div>
          <div className="flex items-center justify-between mb-2">
            <div>
              <label className="block text-xs font-semibold text-gray-600 uppercase tracking-wide">Imagens / Prints</label>
              <p className="text-xs text-gray-400 mt-0.5">Máx. {MAX_IMAGES} imagens · {MAX_IMAGE_MB} MB cada · JPEG, PNG ou WEBP</p>
            </div>
            {editingArticle.images.length < MAX_IMAGES && (
              <button
                type="button"
                onClick={() => fileInputRef.current?.click()}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-moss-600 hover:bg-moss-700 text-white rounded-lg text-xs font-semibold transition"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                Adicionar imagem
              </button>
            )}
          </div>
          <input ref={fileInputRef} type="file" accept="image/jpeg,image/png,image/webp" multiple className="hidden" onChange={handleImageUpload} />

          {editingArticle.images.length === 0 ? (
            <div
              onDrop={handleDrop}
              onDragOver={e => e.preventDefault()}
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-gray-200 rounded-lg p-8 text-center cursor-pointer hover:border-moss-400 hover:bg-moss-50 transition"
            >
              <svg className="w-8 h-8 text-gray-300 mx-auto mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
              <p className="text-sm text-gray-400">Arraste prints aqui ou clique para selecionar</p>
            </div>
          ) : (
            <div className="flex flex-wrap gap-3">
              {editingArticle.images.map((img, idx) => (
                <div key={idx} className="relative group">
                  <img
                    src={`data:${img.mimeType};base64,${img.data}`}
                    alt={`Imagem ${idx + 1}`}
                    className="w-32 h-24 object-cover rounded-lg border border-gray-200 shadow-sm"
                  />
                  <button
                    onClick={() => handleRemoveImage(idx)}
                    className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 hover:bg-red-600 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition shadow"
                    title="Remover imagem"
                  >
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                  </button>
                  <span className="absolute bottom-1 left-1 text-[10px] bg-black/50 text-white rounded px-1">{idx + 1}</span>
                </div>
              ))}
              {editingArticle.images.length < MAX_IMAGES && (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  onDrop={handleDrop}
                  onDragOver={e => e.preventDefault()}
                  className="w-32 h-24 border-2 border-dashed border-gray-200 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-moss-400 hover:bg-moss-50 transition"
                >
                  <svg className="w-5 h-5 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                  <span className="text-[11px] text-gray-400 mt-1">Adicionar</span>
                </div>
              )}
            </div>
          )}
        </div>

        <div className="flex items-center gap-2">
          <input
            id="article-active"
            type="checkbox"
            checked={editingArticle.active}
            onChange={e => setEditingArticle(prev => prev ? { ...prev, active: e.target.checked } : prev)}
            className="w-4 h-4 rounded border-gray-300 text-moss-600 focus:ring-moss-500"
          />
          <label htmlFor="article-active" className="text-sm text-gray-600">Artigo ativo (disponível para o Léo)</label>
        </div>

        <div className="flex gap-3 pt-2 border-t border-gray-100">
          <button
            onClick={() => { setIsEditing(false); setEditingArticle(null); }}
            className="px-4 py-2 border border-gray-300 text-gray-700 rounded-lg text-sm hover:bg-gray-50 transition"
          >
            Cancelar
          </button>
          <button
            onClick={handleSave}
            disabled={saveLoading}
            className="px-5 py-2 bg-moss-600 hover:bg-moss-700 disabled:opacity-50 text-white rounded-lg text-sm font-semibold transition flex items-center gap-2"
          >
            {saveLoading && <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" /></svg>}
            {saveLoading ? 'Salvando...' : editingArticle.id ? 'Salvar alterações' : 'Criar artigo'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-5 animate-fade-in">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h3 className="text-base font-bold text-gray-800 flex items-center gap-2">
            <span className="text-xl">🧠</span>
            Base de Conhecimento do Léo
          </h3>
          <p className="text-xs text-gray-500 mt-1">
            Artigos com texto e prints que o Léo usa para responder perguntas dos usuários com precisão.
            O Léo menciona automaticamente quando uma resposta é baseada em um artigo cadastrado aqui.
          </p>
        </div>
        <button
          onClick={handleNew}
          className="flex-shrink-0 flex items-center gap-1.5 px-4 py-2 bg-moss-600 hover:bg-moss-700 text-white rounded-lg text-sm font-semibold transition shadow-sm"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
          Novo artigo
        </button>
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[180px]">
          <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
          <input
            type="text"
            placeholder="Buscar artigos..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-2 border border-gray-200 rounded-lg text-sm focus:ring-2 focus:ring-moss-500 outline-none"
          />
        </div>
        <select
          value={filterCategory}
          onChange={e => setFilterCategory(e.target.value)}
          className="border border-gray-200 rounded-lg px-3 py-2 text-sm bg-white focus:ring-2 focus:ring-moss-500 outline-none"
        >
          <option value="">Todas as categorias</option>
          {allCategories.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <svg className="w-6 h-6 animate-spin text-moss-500" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" /><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" /></svg>
        </div>
      ) : error ? (
        <div className="flex items-center gap-2 p-4 bg-red-50 border border-red-200 rounded-lg text-sm text-red-700">
          <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
          {error}
          <button onClick={loadArticles} className="ml-auto text-xs underline">Tentar novamente</button>
        </div>
      ) : filteredArticles.length === 0 ? (
        <div className="text-center py-12 text-gray-400">
          <svg className="w-10 h-10 mx-auto mb-3 text-gray-200" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
          <p className="text-sm font-medium text-gray-500">
            {searchTerm || filterCategory ? 'Nenhum artigo encontrado para os filtros aplicados.' : 'Nenhum artigo cadastrado ainda.'}
          </p>
          {!searchTerm && !filterCategory && (
            <p className="text-xs text-gray-400 mt-1">Crie o primeiro artigo para que o Léo passe a utilizá-lo.</p>
          )}
        </div>
      ) : (
        <div className="flex flex-col gap-2">
          <p className="text-xs text-gray-400">{filteredArticles.length} artigo(s)</p>
          {filteredArticles.map(article => (
            <div key={article.id} className={`border rounded-xl p-4 flex items-start gap-4 transition hover:shadow-sm ${article.active ? 'border-gray-200 bg-white' : 'border-gray-100 bg-gray-50 opacity-60'}`}>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-semibold text-sm text-gray-800 truncate">{article.title}</span>
                  <span className="text-[11px] bg-moss-100 text-moss-700 px-2 py-0.5 rounded-full font-medium flex-shrink-0">{article.category}</span>
                  {!article.active && <span className="text-[11px] bg-gray-200 text-gray-500 px-2 py-0.5 rounded-full font-medium flex-shrink-0">Inativo</span>}
                  {(article.image_count ?? 0) > 0 && (
                    <span className="text-[11px] bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full font-medium flex-shrink-0 flex items-center gap-1">
                      <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                      {article.image_count} imagem(ns)
                    </span>
                  )}
                </div>
                {article.content_preview && (
                  <p className="text-xs text-gray-500 mt-1 line-clamp-2">{stripHtml(article.content_preview)}</p>
                )}
                <p className="text-[11px] text-gray-400 mt-1.5">Atualizado em {formatDate(article.updated_at)}</p>
              </div>
              <div className="flex gap-1.5 flex-shrink-0">
                <button
                  onClick={() => handleEdit(article)}
                  className="p-2 text-gray-400 hover:text-moss-600 hover:bg-moss-50 rounded-lg transition"
                  title="Editar"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                </button>
                {deleteConfirm === article.id ? (
                  <div className="flex items-center gap-1">
                    <button onClick={() => handleDelete(article.id)} className="px-2 py-1 bg-red-500 hover:bg-red-600 text-white text-xs rounded-lg transition">Confirmar</button>
                    <button onClick={() => setDeleteConfirm(null)} className="px-2 py-1 border border-gray-300 text-gray-600 text-xs rounded-lg hover:bg-gray-50 transition">Cancelar</button>
                  </div>
                ) : (
                  <button
                    onClick={() => setDeleteConfirm(article.id)}
                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition"
                    title="Excluir"
                  >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                  </button>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default LeoKnowledgePanel;


/**
 * TÍTULO: PAINEL DE AGENDA E SERVIÇOS (LAYOUT GENDO/MODERNO)
 * 
 * ATUALIZAÇÕES RECENTES:
 * - Drag-and-Drop: Arrastar agendamentos para mudar horário/consultor/dia.
 * - Notificações: Envio automático de WhatsApp ao confirmar agendamento.
 */

import React, { useState, useEffect, useMemo, useRef } from 'react';
import { PortalConfig, ServiceItem, AgendaConfig, Appointment, AppointmentModalidade, Collaborator, Client, AppointmentStatus, ScheduleBlock, WaitlistItem, SchedulingQueueEntry, User } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';
import FormActions from '../ui/FormActions';
import AuditLogButton from '../ui/AuditLogButton';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { useKeyboardShortcut } from '../../contexts/KeyboardShortcutContext';
import { sendWhatsappNotification } from '../../services/whatsappService';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';
import { api } from '../../services/apiService';
import AgendaFilterDrawer from './AgendaFilterDrawer';

interface SchedulerPanelProps {
  config: PortalConfig;
  currentUnitId?: string;
  currentUser?: User;
  onRefresh?: () => void;
  lastRefreshedAt?: Date | null;
}

type TabType = 'AGENDA' | 'SERVICOS' | 'BLOQUEIO' | 'FILA' | 'CONFIG';
type ViewMode = 'DAILY' | 'WEEKLY';

// --- HELPER FUNCTIONS FOR TIME ---
const timeToMinutes = (time: string): number => {
    if (!time || typeof time !== 'string' || !time.includes(':')) return 0;
    const [h, m] = time.split(':').map(Number);
    return (isNaN(h) ? 0 : h) * 60 + (isNaN(m) ? 0 : m);
};

const minutesToTime = (minutes: number): string => {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
};

const addMinutes = (time: string, mins: number): string => {
    return minutesToTime(timeToMinutes(time) + mins);
};

const getDurationMinutes = (start: string, end: string): number => {
    return timeToMinutes(end) - timeToMinutes(start);
};

// --- DEFAULT STATUS COLORS ---
const DEFAULT_STATUS_COLORS = {
    'AGUARDANDO': '#fbbf24', // Amber
    'AGENDADO': '#3b82f6', // Blue
    'CONFIRMADO': '#10b981', // Emerald
    'CANCELADO_CLIENTE': '#ef4444', // Red
    'CANCELADO_CONSULTOR': '#9ca3af', // Gray
    'NAO_COMPARECEU': '#7f1d1d' // Dark Red
};

const ModalidadeBadge: React.FC<{ modalidade?: AppointmentModalidade; size?: 'xs' | 'sm' }> = ({ modalidade, size = 'xs' }) => {
    if (!modalidade) return null;
    const isPresencial = modalidade === 'PRESENCIAL';
    const cls = size === 'xs'
        ? 'text-[8px] px-1 py-0.5 rounded font-black uppercase tracking-wide'
        : 'text-[10px] px-1.5 py-0.5 rounded font-black uppercase tracking-wide';
    return isPresencial
        ? <span className={`${cls} bg-orange-500 text-white`}>Presencial</span>
        : <span className={`${cls} bg-blue-500 text-white`}>OnLine</span>;
};

const SchedulerPanel: React.FC<SchedulerPanelProps> = ({ config, currentUnitId, currentUser, onRefresh, lastRefreshedAt }) => {
  const updateSection = async (key: string, value: any) => {
    try {
      const res = await fetch('/api/settings/section', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key, value }) });
      if (res.ok && onRefresh) onRefresh();
    } catch (e) { console.error('updateSection error:', e); }
  };

  const saveSectionOrThrow = async (key: string, value: any) => {
    const res = await fetch('/api/settings/section', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key, value }) });
    if (!res.ok) throw new Error(`Falha ao salvar (HTTP ${res.status}).`);
    if (onRefresh) onRefresh();
  };

  const { validarPermissao, addToast } = useSecurity();
  const { logTransaction } = useAudit();
  const { registerFormActions, unregisterFormActions } = useKeyboardShortcut();
  const { refresh: refreshAppointments } = useEntityCRUD<any>('appointments', { pageSize: 500 });
  const { refresh: refreshScheduleBlocks } = useEntityCRUD<any>('schedule-blocks', { pageSize: 500 });
  
  const [activeTab, setActiveTab] = useState<TabType>('AGENDA');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(() => typeof window !== 'undefined' && window.innerWidth < 768);
  
  // --- AGENDA STATE ---
  const [viewMode, setViewMode] = useState<ViewMode>('DAILY');
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [showAppointmentModal, setShowAppointmentModal] = useState(false);
  const [currentAppointment, setCurrentAppointment] = useState<Appointment | null>(null);
  const [isNewAppointment, setIsNewAppointment] = useState(false);
  
  // --- DRAG AND DROP STATE ---
  const [draggedAppointmentId, setDraggedAppointmentId] = useState<string | null>(null);

  // --- HOVER TOOLTIP STATE ---
  const [hoveredApptTooltip, setHoveredApptTooltip] = useState<{ appt: Appointment; x: number; y: number; side: 'left' | 'right'; vside: 'top' | 'bottom' } | null>(null);
  const handleApptMouseEnter = (e: React.MouseEvent<HTMLDivElement>, appt: Appointment) => {
      const rect = e.currentTarget.getBoundingClientRect();
      const side = rect.left > window.innerWidth / 2 ? 'right' : 'left';
      const vside = rect.top > window.innerHeight / 2 ? 'bottom' : 'top';
      setHoveredApptTooltip({ appt, x: side === 'left' ? rect.right + 8 : rect.left - 8, y: rect.top, side, vside });
  };
  const handleApptMouseLeave = () => setHoveredApptTooltip(null);
  
  // States para filtros e visualização
  const [visibleCollaboratorIds, setVisibleCollaboratorIds] = useState<string[]>([]);
  const [showCollabSelectionModal, setShowCollabSelectionModal] = useState(false);

  // --- FILTRO RÁPIDO (FAB) ---
  const [showFilterDrawer, setShowFilterDrawer] = useState(false);
  const [activeCollaboratorFilter, setActiveCollaboratorFilter] = useState<string | null>(null);
  const [activeClientFilter, setActiveClientFilter] = useState<string | null>(null);

  // --- FILTRO DE UNIDADE DA AGENDA ---
  // 'ALL' apenas disponível para ADMIN
  const [selectedAgendaUnitId, setSelectedAgendaUnitId] = useState<string>(currentUnitId || '');

  // Unidades que este usuário pode ver na agenda
  const visibleUnitIds = useMemo(() => {
    const allUnits = (config.units || []).map(u => u.id);
    if (!currentUser) return currentUnitId ? [currentUnitId] : allUnits;
    if (currentUser.role === 'ADMIN') return allUnits;
    const userGroups = (config.userGroups || []).filter(g => (currentUser.groupIds || []).includes(g.id));
    const groupAgendaUnits = userGroups.flatMap(g => g.agendaUnitIds || []);
    if (groupAgendaUnits.length === 0) return currentUnitId ? [currentUnitId] : (currentUser.allowedUnitIds || []);
    const allowedSet = new Set(currentUser.allowedUnitIds || []);
    return groupAgendaUnits.filter(id => allowedSet.has(id));
  }, [currentUser, config.userGroups, config.units, currentUnitId]);

  const isAdmin = currentUser?.role === 'ADMIN';
  const hasMultipleUnits = isAdmin || visibleUnitIds.length > 1;

  const adminGroupId = useMemo(() => {
    return (config.userGroups || []).find(g => g.name === 'Administradores')?.id;
  }, [config.userGroups]);

  const collabToUserGroups = useMemo(() => {
    const map = new Map<string, Set<string>>();
    for (const user of (config.users || [])) {
      if (user.collaboratorId) {
        const existing = map.get(user.collaboratorId) || new Set<string>();
        for (const gId of (user.groupIds || [])) existing.add(gId);
        map.set(user.collaboratorId, existing);
      }
    }
    const result = new Map<string, string[]>();
    map.forEach((v, k) => result.set(k, Array.from(v)));
    return result;
  }, [config.users]);

  const sidebarCollaborators = useMemo(() => {
    const allCollabs = (config.collaborators || []).filter(c => c.active !== false);
    if (isAdmin) return allCollabs;
    return allCollabs.filter(c => !c.unitId || visibleUnitIds.includes(c.unitId));
  }, [config.collaborators, isAdmin, visibleUnitIds]);

  // When activeCollaboratorFilter is set, the grid shows only that collaborator
  // regardless of sidebar visibility checkboxes.
  const gridCollaboratorIds = useMemo(() => {
    if (activeCollaboratorFilter) return [activeCollaboratorFilter];
    return visibleCollaboratorIds;
  }, [visibleCollaboratorIds, activeCollaboratorFilter]);

  // --- FILTRO DE GRUPO DA AGENDA ---
  // Para ADMIN: seletor "Todos / Grupo X". Para usuário comum: aplicado automaticamente.
  const [selectedAgendaGroupId, setSelectedAgendaGroupId] = useState<string>('ALL');

  // --- BLOQUEIO STATE ---
  const [scheduleBlocks, setScheduleBlocks] = useState<ScheduleBlock[]>(config.scheduleBlocks || []);
  const [newBlock, setNewBlock] = useState<ScheduleBlock>({
      id: '',
      collaboratorId: '',
      isWholeDay: true,
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date().toISOString().split('T')[0],
      startTime: '08:00',
      endTime: '18:00',
      repeatDays: [1, 2, 3, 4, 5],
      reason: ''
  });

  // --- FILA DE ESPERA STATE ---
  const [waitlist, setWaitlist] = useState<WaitlistItem[]>(config.waitlist || []);
  const [newWaitEntry, setNewWaitEntry] = useState<WaitlistItem>({
      id: '',
      clientId: '',
      clientName: '',
      serviceId: '',
      serviceName: '',
      collaboratorId: '',
      collaboratorName: '',
      date: new Date().toISOString().split('T')[0],
      time: '08:00',
      notes: ''
  });
  const [promotedWaitlistId, setPromotedWaitlistId] = useState<string | null>(null);

  // --- RODÍZIO STATE ---
  const getNextTimeSlot = (): string => {
      const now = new Date();
      let h = now.getHours();
      let m = Math.ceil(now.getMinutes() / 30) * 30;
      if (m >= 60) { h++; m = 0; }
      if (h >= 24) { h = 0; }
      return `${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}`;
  };

  const eligibleCollaborators = useMemo(() => {
      const roleNames = (config.roles || []).filter(r => r.participatesInScheduling).map(r => r.name);
      return (config.collaborators || []).filter(c => c.active !== false && roleNames.includes(c.jobTitle || ''));
  }, [config.collaborators, config.roles]);

  const getQueueForUnit = (unitId: string): string[] => {
      const entry = (config.schedulingQueue || []).find(q => q.unitId === unitId);
      return entry?.collaboratorIds || [];
  };

  const saveQueue = (unitId: string, collaboratorIds: string[]) => {
      const queues = [...(config.schedulingQueue || [])];
      const idx = queues.findIndex(q => q.unitId === unitId);
      if (idx !== -1) {
          queues[idx] = { unitId, collaboratorIds };
      } else {
          queues.push({ unitId, collaboratorIds });
      }
      updateSection('schedulingQueue', queues);
  };

  const rotateQueue = (unitId: string) => {
      const queue = getQueueForUnit(unitId);
      const eligibleIds = eligibleCollaborators.map(c => c.id);
      const validQueue = queue.filter(id => eligibleIds.includes(id));
      const missingIds = eligibleIds.filter(id => !validQueue.includes(id));
      const fullQueue = [...validQueue, ...missingIds];
      if (fullQueue.length <= 1) return;
      const [first, ...rest] = fullQueue;
      const rotated = [...rest, first];
      saveQueue(unitId, rotated);
  };

  const getNextCollaboratorForUnit = (unitId: string): string | null => {
      const queue = getQueueForUnit(unitId);
      const eligibleIds = eligibleCollaborators.map(c => c.id);
      const validQueue = queue.filter(id => eligibleIds.includes(id));
      const missingIds = eligibleIds.filter(id => !validQueue.includes(id));
      const fullQueue = [...validQueue, ...missingIds];
      return fullQueue[0] || null;
  };

  // --- CLIENT AUTOCOMPLETE STATE ---
  const [clientSearchTerm, setClientSearchTerm] = useState('');
  const [showClientDropdown, setShowClientDropdown] = useState(false);

  // --- COLLABORATOR AUTOCOMPLETE STATE ---
  const [collabSearchTerm, setCollabSearchTerm] = useState('');
  
  // --- SERVICE & CONFIG STATE ---
  const [isEditingService, setIsEditingService] = useState(false);
  const [currentService, setCurrentService] = useState<ServiceItem | null>(null);
  
  const [localAgendaConfig, setLocalAgendaConfig] = useState<AgendaConfig>(config.agendaConfig || { startHour: '08:00', endHour: '19:00', slotInterval: 30 });
  const [statusColors, setStatusColors] = useState<Record<string, string>>((config as any).statusColors || DEFAULT_STATUS_COLORS);

  const sidebarInitRef = useRef(false);
  const headerScrollRef = useRef<HTMLDivElement>(null);
  const bodyScrollRef = useRef<HTMLDivElement>(null);

  const handleBodyScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (headerScrollRef.current) {
      headerScrollRef.current.scrollLeft = (e.currentTarget).scrollLeft;
    }
  };

  const handleHeaderScroll = (e: React.UIEvent<HTMLDivElement>) => {
    if (bodyScrollRef.current) {
      bodyScrollRef.current.scrollLeft = (e.currentTarget).scrollLeft;
    }
  };
  useEffect(() => {
      if (!sidebarInitRef.current && sidebarCollaborators.length > 0) {
          sidebarInitRef.current = true;
          setVisibleCollaboratorIds(sidebarCollaborators.map(c => c.id));
      }
  }, [sidebarCollaborators]);

  // --- AGENDA HELPERS ---
  
  const weekDays = useMemo(() => {
      const d = new Date(selectedDate + 'T12:00:00');
      const day = d.getDay();
      const diff = d.getDate() - day;
      const start = new Date(d);
      start.setDate(diff);
      
      const days = [];
      for(let i=0; i<7; i++) {
          const current = new Date(start);
          current.setDate(start.getDate() + i);
          days.push(current.toISOString().split('T')[0]);
      }
      return days;
  }, [selectedDate]);

  const displayedAppointments = useMemo(() => {
      const appointments = config.appointments || [];
      let filtered = appointments.filter(app => gridCollaboratorIds.includes(app.collaboratorId));

      // Filtro por unidade: agendamentos sem unitId (legados) são exibidos apenas na unidade atual
      if (selectedAgendaUnitId && selectedAgendaUnitId !== 'ALL') {
          filtered = filtered.filter(app => !app.unitId || app.unitId === selectedAgendaUnitId);
      }

      // Filtro por grupo: usuário comum vê apenas agendamentos do seu grupo (ou legados sem grupo)
      if (!isAdmin) {
          filtered = filtered.filter(app => !app.groupId || (currentUser?.groupIds || []).includes(app.groupId));
      } else if (selectedAgendaGroupId && selectedAgendaGroupId !== 'ALL') {
          filtered = filtered.filter(app => !app.groupId || app.groupId === selectedAgendaGroupId);
      }

      if (viewMode === 'DAILY') {
          return filtered.filter(app => app.date === selectedDate);
      } else {
          return filtered.filter(app => weekDays.includes(app.date));
      }
  }, [config.appointments, selectedDate, viewMode, weekDays, gridCollaboratorIds, selectedAgendaUnitId, selectedAgendaGroupId, isAdmin, currentUser]);

  const timeSlots = useMemo(() => {
      const slots = [];
      let current = timeToMinutes(localAgendaConfig.startHour);
      const end = timeToMinutes(localAgendaConfig.endHour);
      while (current < end) {
          slots.push(minutesToTime(current));
          current += localAgendaConfig.slotInterval;
      }
      return slots;
  }, [localAgendaConfig]);

  // Mini Calendar Logic
  const generateMiniCalendar = () => {
      const date = new Date(selectedDate + 'T12:00:00'); 
      const year = date.getFullYear();
      const month = date.getMonth();
      const firstDay = new Date(year, month, 1);
      const lastDay = new Date(year, month + 1, 0);
      const days = [];
      for (let i = 0; i < firstDay.getDay(); i++) days.push(null);
      for (let i = 1; i <= lastDay.getDate(); i++) days.push(i);
      return { days, monthName: date.toLocaleString('pt-BR', { month: 'long', year: 'numeric' }) };
  };

  const miniCal = generateMiniCalendar();

  const formattedHeaderDate = useMemo(() => {
      if (viewMode === 'DAILY') {
          return new Date(selectedDate + 'T12:00:00').toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long' });
      } else {
          const start = new Date(weekDays[0] + 'T12:00:00');
          const end = new Date(weekDays[6] + 'T12:00:00');
          return `${start.getDate()} ${start.toLocaleDateString('pt-BR', {month:'short'})} - ${end.getDate()} ${end.toLocaleDateString('pt-BR', {month:'short'})}`;
      }
  }, [selectedDate, viewMode, weekDays]);

  // --- BLOQUEIO HELPERS ---
  const getActiveBlocksFor = (collaboratorId: string, date: string) => {
    const blocks = scheduleBlocks || [];
    const dateObj = new Date(date + 'T12:00:00');
    const dayOfWeek = dateObj.getDay();

    return blocks.filter(b => {
        if (b.collaboratorId !== collaboratorId) return false;
        
        // Verifica se a data está no período
        const start = new Date(b.startDate + 'T00:00:00');
        const end = new Date(b.endDate + 'T23:59:59');
        if (dateObj < start || dateObj > end) return false;

        // Verifica se o dia da semana está incluso na repetição
        return b.repeatDays.includes(dayOfWeek);
    });
  };

  // --- DRAG AND DROP HANDLERS (HTML5 API) ---
  const handleDragStart = (e: React.DragEvent, apptId: string) => {
      e.dataTransfer.setData("text/plain", apptId);
      e.dataTransfer.effectAllowed = "move";
      setDraggedAppointmentId(apptId);
  };

  const handleDragOver = (e: React.DragEvent) => {
      e.preventDefault(); // Necessário para permitir o drop
      e.dataTransfer.dropEffect = "move";
  };

  const handleDrop = async (e: React.DragEvent, targetCollabId: string, targetTime: string, targetDate: string) => {
      e.preventDefault();
      const apptId = e.dataTransfer.getData("text/plain");
      setDraggedAppointmentId(null);

      if (!apptId) return;

      // Encontra o agendamento original
      const appointments = [...(config.appointments || [])];
      const apptIndex = appointments.findIndex(a => a.id === apptId);
      
      if (apptIndex === -1) return;

      const originalAppt = appointments[apptIndex];
      
      // Calcula a duração original
      const duration = getDurationMinutes(originalAppt.startTime, originalAppt.endTime);
      
      // Cria o objeto atualizado
      const updatedAppt: Appointment = {
          ...originalAppt,
          collaboratorId: targetCollabId || originalAppt.collaboratorId, // Se targetCollabId for nulo (na view semanal), mantém ou ajusta
          date: targetDate,
          startTime: targetTime,
          endTime: addMinutes(targetTime, duration)
      };

      appointments[apptIndex] = updatedAppt;

      try {
          await api.put(`/api/appointments/${apptId}`, {
              collaborator_id: updatedAppt.collaboratorId,
              date: updatedAppt.date,
              start_time: updatedAppt.startTime,
              end_time: updatedAppt.endTime,
          });
          if (onRefresh) await onRefresh();
          logTransaction('AGENDA', apptId, originalAppt, updatedAppt);
          addToast('success', 'Movido', 'Agendamento reagendado com sucesso.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível atualizar o agendamento.');
      }
  };

  // --- ACTIONS: APPOINTMENT ---

  const handleOpenSlot = (collabId: string | null, time: string, dateOverride?: string) => {
      if (!validarPermissao('agenda:INCLUIR')) return;
      
      const targetDate = dateOverride || selectedDate;
      let targetCollabId = collabId || '';
      const slotUnitId = (selectedAgendaUnitId && selectedAgendaUnitId !== 'ALL') ? selectedAgendaUnitId : currentUnitId;
      if (!targetCollabId && slotUnitId) {
          const nextFromQueue = getNextCollaboratorForUnit(slotUnitId);
          if (nextFromQueue) targetCollabId = nextFromQueue;
      }
      if (!targetCollabId && visibleCollaboratorIds.length > 0) {
          targetCollabId = visibleCollaboratorIds[0];
      }
      
      // Validação de Bloqueio
      const blocks = getActiveBlocksFor(targetCollabId, targetDate);
      const isSlotBlocked = blocks.some(b => {
          if (b.isWholeDay) return true;
          const slotMin = timeToMinutes(time);
          const startMin = timeToMinutes(b.startTime || '00:00');
          const endMin = timeToMinutes(b.endTime || '23:59');
          return slotMin >= startMin && slotMin < endMin;
      });

      if (isSlotBlocked) {
          addToast('error', 'Bloqueado', 'Este horário está bloqueado para agendamentos.');
          return;
      }

      const collabName = (config.collaborators || []).find(c => c.id === targetCollabId)?.name || '';

      const newAppt: Appointment = {
          id: '', clientId: '', clientName: '', collaboratorId: targetCollabId, serviceId: '',
          date: targetDate, startTime: time, endTime: addMinutes(time, 30),
          status: 'AGENDADO', notes: ''
      };
      setCurrentAppointment(newAppt);
      setClientSearchTerm('');
      setCollabSearchTerm(collabName);
      setIsNewAppointment(true);
      setShowAppointmentModal(true);
  };

  const handleSaveAppointment = async () => {
    if (!currentAppointment) return;
    if (!currentAppointment.clientId || !currentAppointment.serviceId) {
        addToast('warning', 'Validação', 'Selecione o cliente e o serviço.');
        return;
    }

    const appointments = [...(config.appointments || [])];
    let apptToSave = { ...currentAppointment };
    const originalAppt = isNewAppointment ? null : appointments.find(a => a.id === apptToSave.id);

    if (isNewAppointment) {
        apptToSave.id = 'appt-' + Date.now();
        apptToSave.unitId = selectedAgendaUnitId && selectedAgendaUnitId !== 'ALL'
            ? selectedAgendaUnitId
            : (currentUnitId || undefined);
        if (!apptToSave.groupId && currentUser?.groupIds?.[0]) {
            apptToSave.groupId = currentUser.groupIds[0];
        }
        if (currentUser) {
            apptToSave.createdBy = { id: currentUser.id, name: currentUser.name, at: new Date().toISOString() };
        }
        appointments.push(apptToSave);
    } else {
        if (currentUser) {
            apptToSave.updatedBy = { id: currentUser.id, name: currentUser.name, at: new Date().toISOString() };
        }
        const idx = appointments.findIndex(a => a.id === apptToSave.id);
        if (idx !== -1) appointments[idx] = apptToSave;
    }

    // Lógica para retirar da fila de espera se vier de uma promoção (aplicada após confirmação da API)
    let updatedWaitlist = waitlist;
    if (promotedWaitlistId) {
        updatedWaitlist = waitlist.filter(w => w.id !== promotedWaitlistId);
    }

    // --- LÓGICA DE NOTIFICAÇÃO WHATSAPP ---
    // Verifica se mudou para CONFIRMADO e não era CONFIRMADO antes
    if (apptToSave.status === 'CONFIRMADO' && (!originalAppt || originalAppt.status !== 'CONFIRMADO')) {
        const client = (config.clients || []).find(c => c.id === apptToSave.clientId);
        if (client && client.phone) {
            const collab = (config.collaborators || []).find(c => c.id === apptToSave.collaboratorId);
            const msg = `Olá ${client.name.split(' ')[0]}, seu agendamento na ${config.companyName} foi confirmado para ${new Date(apptToSave.date + 'T12:00:00').toLocaleDateString('pt-BR')} às ${apptToSave.startTime} com ${collab?.name || 'nosso consultor'}.`;
            
            // Dispara notificação sem bloquear a UI (async fire-and-forget com toast)
            sendWhatsappNotification(client.phone, msg).then(success => {
                if (success) addToast('success', 'WhatsApp', 'Notificação enviada ao cliente.');
                else addToast('warning', 'WhatsApp', 'Falha ao enviar notificação (verifique o número).');
            });
        }
    }

    let updatedConfig = { ...config, appointments, waitlist: updatedWaitlist };

    const savedCollabUnitId = apptToSave.collaboratorId
        ? (config.collaborators || []).find(c => c.id === apptToSave.collaboratorId)?.unitId || null
        : null;
    const rotationUnitId = savedCollabUnitId
        || ((selectedAgendaUnitId && selectedAgendaUnitId !== 'ALL') ? selectedAgendaUnitId : null)
        || currentUnitId
        || '';

    if (isNewAppointment && apptToSave.collaboratorId) {
        const nextCollab = getNextCollaboratorForUnit(rotationUnitId);
        if (nextCollab === apptToSave.collaboratorId) {
            const queues = [...(updatedConfig.schedulingQueue || [])];
            const queueEntry = queues.find(q => q.unitId === rotationUnitId);
            const eligibleIds = eligibleCollaborators
                .filter(c => !c.unitId || c.unitId === rotationUnitId)
                .map(c => c.id);
            const currentQ = queueEntry ? queueEntry.collaboratorIds.filter(id => eligibleIds.includes(id)) : [];
            const missingIds = eligibleIds.filter(id => !currentQ.includes(id));
            const fullQueue = [...currentQ, ...missingIds];
            if (fullQueue.length > 1) {
                const [first, ...rest] = fullQueue;
                const rotated = [...rest, first];
                const qIdx = queues.findIndex(q => q.unitId === rotationUnitId);
                if (qIdx !== -1) {
                    queues[qIdx] = { unitId: rotationUnitId, collaboratorIds: rotated };
                } else {
                    queues.push({ unitId: rotationUnitId, collaboratorIds: rotated });
                }
                updatedConfig = { ...updatedConfig, schedulingQueue: queues };
            }
        }
    }

    const wasPromoted = !!promotedWaitlistId;

    try {
        const payload = {
            client_id: apptToSave.clientId,
            client_name: apptToSave.clientName,
            collaborator_id: apptToSave.collaboratorId,
            service_id: apptToSave.serviceId,
            date: apptToSave.date,
            start_time: apptToSave.startTime,
            end_time: apptToSave.endTime,
            status: apptToSave.status,
            notes: apptToSave.notes,
            unit_id: apptToSave.unitId,
            group_id: apptToSave.groupId,
            modalidade: apptToSave.modalidade || null,
        };
        if (isNewAppointment) {
            await api.post('/api/appointments', payload);
        } else {
            await api.put(`/api/appointments/${apptToSave.id}`, payload);
        }
        if (promotedWaitlistId) {
            setWaitlist(updatedWaitlist);
            setPromotedWaitlistId(null);
        }
        if (updatedConfig.schedulingQueue) await updateSection('schedulingQueue', updatedConfig.schedulingQueue);
        if (updatedConfig.waitlist) await updateSection('waitlist', updatedConfig.waitlist);
        if (onRefresh) await onRefresh();
        logTransaction('AGENDA', apptToSave.id, originalAppt, apptToSave);
        addToast('success', 'Sucesso', wasPromoted ? 'Fila convertida em agendamento.' : 'Agendamento salvo.');
        setShowAppointmentModal(false);
    } catch (err: any) {
        addToast('error', 'Erro', err?.message || 'Não foi possível salvar o agendamento.');
    }
  };

  useEffect(() => {
    if (showAppointmentModal) {
      registerFormActions(handleSaveAppointment, () => { setShowAppointmentModal(false); setPromotedWaitlistId(null); });
    } else {
      unregisterFormActions();
    }
    return () => unregisterFormActions();
  }, [showAppointmentModal]);

  // --- ACTIONS: BLOQUEIO ---
  const handleAddBlock = async () => {
      if (!newBlock.collaboratorId) {
          addToast('warning', 'Atenção', 'Selecione um consultor.');
          return;
      }
      if (!newBlock.reason) {
          addToast('warning', 'Atenção', 'Informe o motivo do bloqueio.');
          return;
      }

      const blockToSave = { ...newBlock, id: 'blk-' + Date.now() };
      try {
          await api.post('/api/schedule-blocks', {
              collaborator_id: blockToSave.collaboratorId,
              is_whole_day: blockToSave.isWholeDay,
              start_date: blockToSave.startDate,
              end_date: blockToSave.endDate,
              start_time: blockToSave.startTime,
              end_time: blockToSave.endTime,
              repeat_days: blockToSave.repeatDays,
              reason: blockToSave.reason,
          });
          setScheduleBlocks(prev => [...(prev || []), blockToSave]);
          setNewBlock({ ...newBlock, reason: '', id: '' });
          refreshScheduleBlocks();
          addToast('success', 'Sucesso', 'Horário bloqueado na agenda.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível salvar o bloqueio de agenda.');
      }
  };

  const handleRemoveBlock = async (id: string) => {
      if (!window.confirm('Remover este bloqueio?')) return;
      const blockToDelete = scheduleBlocks.find(b => b.id === id);
      try {
          await api.delete(`/api/schedule-blocks/${id}`);
          setScheduleBlocks(prev => (prev || []).filter(b => b.id !== id));
          if (blockToDelete) logTransaction('AGENDA', id, blockToDelete, null);
          refreshScheduleBlocks();
          addToast('info', 'Removido', 'Bloqueio de agenda removido.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível remover o bloqueio de agenda.');
      }
  };

  // --- ACTIONS: FILA DE ESPERA ---
  const handleSaveService = async () => {
      if (!currentService?.name) {
          addToast('warning', 'Validação', 'O nome do serviço é obrigatório.');
          return;
      }
      const list = [...(config.services || [])];
      let svcToSave = { ...currentService };
      if (svcToSave.id) {
          const idx = list.findIndex(s => s.id === svcToSave.id);
          if (idx !== -1) list[idx] = svcToSave;
      } else {
          svcToSave = { ...svcToSave, id: 'svc-' + Date.now() };
          list.push(svcToSave);
      }
      try {
          await saveSectionOrThrow('services', list);
          setIsEditingService(false);
          addToast('success', 'Sucesso', 'Serviço salvo.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Não foi possível salvar o serviço.');
      }
  };

  const handleAddWaitlist = () => {
      if (!newWaitEntry.clientId || !newWaitEntry.serviceId) {
          addToast('warning', 'Atenção', 'Preencha os campos obrigatórios (Cliente e Serviço).');
          return;
      }

      const entryToSave = { 
          ...newWaitEntry, 
          id: newWaitEntry.id || 'wait-' + Date.now(),
          clientName: (config.clients || []).find(c => c.id === newWaitEntry.clientId)?.name || '',
          serviceName: (config.services || []).find(s => s.id === newWaitEntry.serviceId)?.name || '',
          collaboratorName: (config.collaborators || []).find(c => c.id === newWaitEntry.collaboratorId)?.name || 'Qualquer Consultor'
      };
      
      let updatedWaitlist = [...(waitlist || [])];
      const idx = updatedWaitlist.findIndex(w => w.id === entryToSave.id);
      
      if (idx !== -1) {
          updatedWaitlist[idx] = entryToSave;
      } else {
          updatedWaitlist.push(entryToSave);
      }

      setWaitlist(updatedWaitlist);
      updateSection('waitlist', updatedWaitlist);
      
      addToast('success', 'Fila de Espera', 'Registro salvo na fila.');
      setNewWaitEntry({ ...newWaitEntry, id: '', notes: '', clientId: '', clientName: '' });
      setClientSearchTerm('');
  };

  const handleRemoveWaitlist = (id: string) => {
      if (!window.confirm('Remover este cliente da fila?')) return;
      const waitToDelete = waitlist.find(w => w.id === id);
      const updated = waitlist.filter(w => w.id !== id);
      setWaitlist(updated);
      updateSection('waitlist', updated);
      if (waitToDelete) logTransaction('AGENDA', id, waitToDelete, null);
      addToast('info', 'Removido', 'Registro da fila removido.');
  };

  const handleEditWaitlist = (item: WaitlistItem) => {
      setNewWaitEntry({ ...item });
      setClientSearchTerm(item.clientName);
      setActiveTab('FILA');
  };

  const handlePromoteToAppointment = (item: WaitlistItem) => {
      const svc = (config.services || []).find(s => s.id === item.serviceId);
      const newAppt: Appointment = {
          id: '',
          clientId: item.clientId,
          clientName: item.clientName,
          serviceId: item.serviceId,
          collaboratorId: item.collaboratorId || (visibleCollaboratorIds.length > 0 ? visibleCollaboratorIds[0] : ''),
          date: item.date || selectedDate,
          startTime: item.time || '08:00',
          endTime: svc ? addMinutes(item.time || '08:00', svc.durationMinutes) : addMinutes(item.time || '08:00', 30),
          status: 'AGENDADO',
          notes: item.notes
      };

      setPromotedWaitlistId(item.id); // Registra que viemos da fila
      setCurrentAppointment(newAppt);
      setClientSearchTerm(item.clientName);
      const colabName = (config.collaborators || []).find(c => c.id === newAppt.collaboratorId)?.name || '';
      setCollabSearchTerm(colabName);
      setIsNewAppointment(true);
      setShowAppointmentModal(true);
      setActiveTab('AGENDA');
  };

  const filteredClients = useMemo(() => {
    const clients = config.clients || [];
    if (!clientSearchTerm) return [];
    const lower = clientSearchTerm.toLowerCase();
    const digits = clientSearchTerm.replace(/\D/g, '');
    return clients.filter(c =>
        c.name.toLowerCase().includes(lower) ||
        (c.document || '').replace(/\D/g, '').includes(digits || lower) ||
        (digits && (c.phone || '').replace(/\D/g, '').includes(digits)) ||
        (digits && (c.phone2 || '').replace(/\D/g, '').includes(digits)) ||
        (c.email || '').toLowerCase().includes(lower)
    ).slice(0, 10);
  }, [config.clients, clientSearchTerm]);

  const handleSelectClient = (client: Client) => {
    if (activeTab === 'FILA') {
        setNewWaitEntry({ ...newWaitEntry, clientId: client.id, clientName: client.name });
    } else if (currentAppointment) {
        setCurrentAppointment({
            ...currentAppointment,
            clientId: client.id,
            clientName: client.name
        });
    }
    setClientSearchTerm(client.name);
    setShowClientDropdown(false);
  };

  const handleEditAppointment = (appt: Appointment) => {
    setCurrentAppointment({ ...appt });
    setClientSearchTerm(appt.clientName);
    const collab = (config.collaborators || []).find(c => c.id === appt.collaboratorId);
    setCollabSearchTerm(collab?.name || '');
    setIsNewAppointment(false);
    setShowAppointmentModal(true);
  };

  const toggleCollaboratorVisibility = (id: string) => {
      setVisibleCollaboratorIds(prev => 
          prev.includes(id) ? prev.filter(v => v !== id) : [...prev, id]
      );
  };

  // --- STYLE HELPERS ---
  
  const getBlockStyle = (startTime: string, endTime: string, color: string, textColor: string = '#1f2937', isHatched: boolean = false) => {
      const startMin = timeToMinutes(startTime);
      const endMin = timeToMinutes(endTime);
      const dayStartMin = timeToMinutes(localAgendaConfig.startHour);
      const top = (startMin - dayStartMin) * 2; 
      const height = (endMin - startMin) * 2;

      return {
          top: `${top}px`,
          height: `${height}px`,
          backgroundColor: color,
          color: textColor,
          backgroundImage: isHatched ? 'repeating-linear-gradient(45deg, transparent, transparent 5px, rgba(0,0,0,0.03) 5px, rgba(0,0,0,0.03) 10px)' : 'none'
      };
  };

  const changeDay = (delta: number) => {
      const d = new Date(selectedDate);
      const jump = viewMode === 'WEEKLY' ? delta * 7 : delta;
      d.setDate(d.getDate() + jump);
      setSelectedDate(d.toISOString().split('T')[0]);
  };

  const handleNavigateToAppointment = (appt: Appointment) => {
      setSelectedDate(appt.date);
      setViewMode('DAILY');
      const dayStartMin = timeToMinutes(localAgendaConfig.startHour);
      const apptMin = timeToMinutes(appt.startTime);
      const scrollTarget = Math.max(0, (apptMin - dayStartMin) * 2 - 60);
      setTimeout(() => {
          if (bodyScrollRef.current) {
              bodyScrollRef.current.scrollTop = scrollTarget;
          }
      }, 120);
  };

  return (
    <div className="flex flex-col h-full bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
      <style>{`
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #d1d5db; border-radius: 10px; }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #9ca3af; }
        .hide-scrollbar { scrollbar-width: none; -ms-overflow-style: none; }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
      `}</style>

      {/* GLOBAL TABS */}
      <div className="flex border-b border-gray-200 bg-gray-50 flex-shrink-0">
          <button onClick={() => setActiveTab('AGENDA')} className={`px-6 py-4 font-bold text-sm transition-colors ${activeTab === 'AGENDA' ? 'border-b-2 border-moss-600 text-moss-800 bg-white' : 'text-gray-500 hover:text-gray-700'}`}>Agenda</button>
          <button onClick={() => setActiveTab('BLOQUEIO')} className={`px-6 py-4 font-bold text-sm transition-colors ${activeTab === 'BLOQUEIO' ? 'border-b-2 border-moss-600 text-moss-800 bg-white' : 'text-gray-500 hover:text-gray-700'}`}>Bloquear Agenda</button>
          <button onClick={() => setActiveTab('FILA')} className={`px-6 py-4 font-bold text-sm transition-colors ${activeTab === 'FILA' ? 'border-b-2 border-moss-600 text-moss-800 bg-white' : 'text-gray-500 hover:text-gray-700'}`}>Fila de Espera</button>
          <button onClick={() => setActiveTab('SERVICOS')} className={`px-6 py-4 font-bold text-sm transition-colors ${activeTab === 'SERVICOS' ? 'border-b-2 border-moss-600 text-moss-800 bg-white' : 'text-gray-500 hover:text-gray-700'}`}>Serviços</button>
          <button onClick={() => setActiveTab('CONFIG')} className={`px-6 py-4 font-bold text-sm transition-colors ${activeTab === 'CONFIG' ? 'border-b-2 border-moss-600 text-moss-800 bg-white' : 'text-gray-500 hover:text-gray-700'}`}>Configurações</button>
      </div>

      <div className="flex-1 overflow-hidden relative">
        {/* === AGENDA TAB === */}
        {activeTab === 'AGENDA' && (
            <div className="flex h-full relative">
                {sidebarCollapsed && (
                    <button
                        onClick={() => setSidebarCollapsed(false)}
                        className="absolute top-2 left-2 z-30 p-2 bg-[#1f2937] text-white rounded-lg shadow-lg hover:bg-[#374151] transition-colors"
                        title="Expandir painel lateral"
                    >
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                    </button>
                )}
                {/* 1. SIDEBAR */}
                {!sidebarCollapsed && (
                <div className="w-72 bg-white border-r border-gray-200 flex flex-col flex-shrink-0 z-20 shadow-md max-md:absolute max-md:inset-y-0 max-md:left-0 max-md:z-40">
                    <div className="bg-[#1f2937] text-white p-3 flex justify-between items-center">
                        <span className="font-bold text-sm capitalize tracking-wide">{miniCal.monthName}</span>
                        <button onClick={() => setSidebarCollapsed(true)} className="p-1 hover:bg-white/20 rounded transition-colors" title="Recolher painel">
                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 19l-7-7 7-7m8 14l-7-7 7-7" /></svg>
                        </button>
                    </div>
                    <div className="p-4 bg-white border-b">
                         <div className="grid grid-cols-7 gap-1 text-center text-[10px] text-gray-400 font-bold mb-2 uppercase">
                            <div>D</div><div>S</div><div>T</div><div>Q</div><div>Q</div><div>S</div><div>S</div>
                        </div>
                        <div className="grid grid-cols-7 gap-1 text-center text-sm">
                            {miniCal.days.map((day, i) => {
                                const isSelected = day && parseInt(selectedDate.split('-')[2]) === day;
                                return (
                                    <div key={i} className="aspect-square flex items-center justify-center">
                                        {day ? (
                                            <button 
                                                onClick={() => {
                                                    const d = new Date(selectedDate);
                                                    d.setDate(day);
                                                    setSelectedDate(d.toISOString().split('T')[0]);
                                                    if (window.innerWidth < 768) setSidebarCollapsed(true);
                                                }}
                                                className={`w-7 h-7 rounded-full flex items-center justify-center text-xs transition-colors ${isSelected ? 'bg-blue-900 text-white font-bold' : 'hover:bg-gray-100'}`}
                                            >
                                                {day}
                                            </button>
                                        ) : null}
                                    </div>
                                );
                            })}
                        </div>
                    </div>

                    {/* FILA DE ESPERA NA SIDEBAR COM AÇÕES INTERATIVAS */}
                    <div className="p-4 border-b bg-amber-50/30">
                        <div className="flex justify-between items-center mb-3">
                            <span className="font-bold text-xs text-amber-800 uppercase tracking-tighter italic">Fila de Espera</span>
                            <span className="bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-full text-[10px] font-black">{waitlist.length}</span>
                        </div>
                        <div className="space-y-2 max-h-56 overflow-y-auto custom-scrollbar pr-1">
                            {waitlist.map(w => (
                                <div key={w.id} className="bg-white p-2 rounded border border-amber-100 shadow-sm hover:shadow-md transition-all cursor-default group relative overflow-hidden">
                                    <div className="text-[10px] font-black text-gray-800 uppercase leading-tight truncate pr-4">{w.clientName}</div>
                                    <div className="flex justify-between items-center mt-1">
                                        <span className="text-[9px] font-bold text-amber-600 uppercase truncate max-w-[120px]">{w.serviceName}</span>
                                        {w.collaboratorId && (
                                            <div className="w-4 h-4 rounded-full bg-gray-100 flex items-center justify-center text-[8px] font-bold text-gray-400" title={`Preferência: ${w.collaboratorName}`}>
                                                👤
                                            </div>
                                        )}
                                    </div>

                                    {/* BOTÕES DE AÇÃO RÁPIDA (APARECEM NO HOVER) */}
                                    <div className="absolute inset-0 bg-white/95 flex items-center justify-center gap-3 opacity-0 group-hover:opacity-100 transition-opacity">
                                        <button 
                                            onClick={() => handlePromoteToAppointment(w)}
                                            className="p-1.5 bg-green-600 text-white rounded hover:bg-green-700 shadow-sm"
                                            title="Passar para Agendamento"
                                        >
                                            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                        </button>
                                        <button 
                                            onClick={() => handleEditWaitlist(w)}
                                            className="p-1.5 bg-blue-600 text-white rounded hover:bg-blue-700 shadow-sm"
                                            title="Alterar Dados"
                                        >
                                            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" /></svg>
                                        </button>
                                        <button 
                                            onClick={() => handleRemoveWaitlist(w.id)}
                                            className="p-1.5 bg-red-600 text-white rounded hover:bg-red-700 shadow-sm"
                                            title="Excluir"
                                        >
                                            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                        </button>
                                    </div>
                                </div>
                            ))}
                            {waitlist.length === 0 && (
                                <div className="text-center py-2 italic text-[10px] text-gray-400">Ninguém aguardando.</div>
                            )}
                        </div>
                    </div>

                    <div className="flex-1 flex flex-col min-h-0 border-b bg-gray-50/50">
                        <div className="flex justify-between items-center p-4 pb-2">
                            <span className="font-bold text-sm text-gray-800 uppercase tracking-tighter italic">Agendas Ativas</span>
                        </div>
                        <div className="flex-1 overflow-y-auto custom-scrollbar px-4 pb-4" style={{ maxHeight: '40vh' }}>
                            {(() => {
                                const collabs = sidebarCollaborators;
                                const eligibleIds = eligibleCollaborators.map(ec => ec.id);

                                const allowedUnits = isAdmin
                                    ? (config.units || [])
                                    : (config.units || []).filter(u => visibleUnitIds.includes(u.id));

                                const allGroups = config.userGroups || [];
                                const nonAdminGroups = allGroups.filter(g => g.id !== adminGroupId);

                                type CollabType = (typeof collabs)[0];

                                const getCollabGroupIds = (c: CollabType): string[] => collabToUserGroups.get(c.id) || [];

                                const sortCollabsForUnit = (list: CollabType[], unitId: string) => {
                                    const unitQueue = getQueueForUnit(unitId);
                                    return [...list].sort((a, b) => {
                                        const aEligible = eligibleIds.includes(a.id);
                                        const bEligible = eligibleIds.includes(b.id);
                                        if (aEligible && !bEligible) return -1;
                                        if (!aEligible && bEligible) return 1;
                                        const aIdx = unitQueue.indexOf(a.id);
                                        const bIdx = unitQueue.indexOf(b.id);
                                        if (aIdx !== -1 && bIdx !== -1) return aIdx - bIdx;
                                        if (aIdx !== -1) return -1;
                                        if (bIdx !== -1) return 1;
                                        return a.name.localeCompare(b.name);
                                    });
                                };

                                const renderCollab = (c: CollabType, unitId: string) => {
                                    const nextCollabId = getNextCollaboratorForUnit(unitId);
                                    const isNext = c.id === nextCollabId;
                                    const isEligible = eligibleIds.includes(c.id);
                                    const isVisible = visibleCollaboratorIds.includes(c.id);
                                    return (
                                        <li key={c.id} className={`flex items-center gap-2 p-1.5 rounded text-xs font-medium group transition-all ${!isVisible ? 'opacity-40' : ''} ${isNext ? 'bg-moss-50 border border-moss-200 shadow-sm' : 'hover:bg-white text-gray-700'}`}>
                                            <div className={`w-6 h-6 rounded-full overflow-hidden flex items-center justify-center font-bold text-[10px] flex-shrink-0 ${isNext ? 'bg-moss-600 text-white' : 'bg-moss-100 text-moss-800'}`}>
                                                {c.photoUrl ? <img src={c.photoUrl} className="w-full h-full object-cover" /> : c.name.charAt(0)}
                                            </div>
                                            <div className="flex-1 min-w-0 cursor-pointer" onClick={() => toggleCollaboratorVisibility(c.id)}>
                                                <div className={`truncate ${isNext ? 'text-moss-800 font-bold' : ''}`}>{c.name}</div>
                                                {c.jobTitle && (
                                                    <div className={`text-[9px] truncate ${isEligible ? 'text-moss-600 font-bold' : 'text-gray-400'}`}>
                                                        {c.jobTitle}{isEligible ? ' ✓ Fila' : ''}
                                                    </div>
                                                )}
                                            </div>
                                            {isNext && (
                                                <span className="px-1.5 py-0.5 bg-moss-600 text-white text-[8px] font-black rounded-full uppercase tracking-wide flex-shrink-0">Próximo</span>
                                            )}
                                            {isEligible && (
                                                <button 
                                                    onClick={() => handleOpenSlot(c.id, getNextTimeSlot())}
                                                    className="p-1 rounded-full hover:bg-moss-100 text-moss-600 hover:text-moss-800 transition-colors flex-shrink-0"
                                                    title="Agendar para este colaborador"
                                                >
                                                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                                </button>
                                            )}
                                        </li>
                                    );
                                };

                                const rendered = new Set<string>();
                                const sections: JSX.Element[] = [];

                                for (const unit of allowedUnits) {
                                    const unitCollabs = collabs.filter(c => c.unitId === unit.id);
                                    if (unitCollabs.length === 0) continue;

                                    const groupSections: JSX.Element[] = [];
                                    for (const group of nonAdminGroups) {
                                        const groupCollabs = unitCollabs.filter(c => {
                                            const gIds = getCollabGroupIds(c);
                                            return gIds.includes(group.id);
                                        });
                                        if (groupCollabs.length === 0) continue;
                                        groupCollabs.forEach(c => rendered.add(c.id));
                                        groupSections.push(
                                            <div key={`${unit.id}-${group.id}`} className="ml-2 mb-2">
                                                <div className="text-[8px] font-bold uppercase tracking-wide text-moss-600 mb-0.5 px-1">{group.name}</div>
                                                <ul className="space-y-0.5">{sortCollabsForUnit(groupCollabs, unit.id).map(c => renderCollab(c, unit.id))}</ul>
                                            </div>
                                        );
                                    }

                                    const ungroupedCollabs = unitCollabs.filter(c => !rendered.has(c.id));
                                    ungroupedCollabs.forEach(c => rendered.add(c.id));

                                    sections.push(
                                        <div key={unit.id} className="mb-3">
                                            <div className="text-[9px] font-black uppercase tracking-widest text-gray-400 mb-1 px-1 border-b border-gray-200 pb-1">
                                                {unit.nomeFantasia || unit.razaoSocial || unit.id}
                                            </div>
                                            {groupSections}
                                            {ungroupedCollabs.length > 0 && (
                                                <ul className="space-y-0.5 ml-2">{sortCollabsForUnit(ungroupedCollabs, unit.id).map(c => renderCollab(c, unit.id))}</ul>
                                            )}
                                        </div>
                                    );
                                }

                                const noUnitCollabs = collabs.filter(c => !rendered.has(c.id));
                                if (noUnitCollabs.length > 0) {
                                    sections.push(
                                        <div key="no-unit" className="mb-3">
                                            <div className="text-[9px] font-black uppercase tracking-widest text-gray-400 mb-1 px-1 border-b border-gray-200 pb-1">Sem Unidade</div>
                                            <ul className="space-y-0.5 ml-2">{sortCollabsForUnit(noUnitCollabs, '').map(c => renderCollab(c, ''))}</ul>
                                        </div>
                                    );
                                }

                                return (
                                    <>
                                        {sections}
                                        {collabs.length === 0 && (
                                            <p className="text-[10px] text-gray-400 italic text-center py-2">Nenhum consultor disponível.</p>
                                        )}
                                    </>
                                );
                            })()}
                        </div>
                    </div>
                </div>
                )}

                {/* Overlay backdrop for mobile */}
                {!sidebarCollapsed && (
                    <div className="md:hidden fixed inset-0 bg-black/30 z-30" onClick={() => setSidebarCollapsed(true)} />
                )}

                {/* 2. GRID */}
                <div className="flex-1 flex flex-col h-full bg-gray-100 overflow-hidden">
                    <div className="bg-[#374151] text-white h-14 flex items-center justify-between px-4 shadow-md flex-shrink-0 z-10">
                        <div className="flex bg-gray-700 rounded p-1">
                            <button onClick={() => setViewMode('DAILY')} className={`px-3 py-1 text-xs font-bold rounded ${viewMode === 'DAILY' ? 'bg-gray-500 text-white shadow' : 'text-gray-400'}`}>Diário</button>
                            <button onClick={() => setViewMode('WEEKLY')} className={`px-3 py-1 text-xs font-bold rounded ${viewMode === 'WEEKLY' ? 'bg-gray-500 text-white shadow' : 'text-gray-400'}`}>Semanal</button>
                        </div>
                        <div className="flex items-center gap-4">
                            <button onClick={() => changeDay(-1)} className="p-1 hover:bg-white/10 rounded-full transition-colors"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" /></svg></button>
                            <span className="font-bold text-sm capitalize">{formattedHeaderDate}</span>
                            <button onClick={() => changeDay(1)} className="p-1 hover:bg-white/10 rounded-full transition-colors"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg></button>
                        </div>
                        <div className="flex items-center gap-2">
                            {hasMultipleUnits ? (
                                <select
                                    value={selectedAgendaUnitId}
                                    onChange={e => setSelectedAgendaUnitId(e.target.value)}
                                    className="text-xs font-bold bg-white/10 border border-white/20 rounded px-2 py-1.5 text-white focus:outline-none focus:ring-1 focus:ring-white/40"
                                    title="Filtrar por unidade"
                                >
                                    {isAdmin && <option value="ALL" className="bg-gray-800">Todas as Unidades</option>}
                                    {(config.units || [])
                                        .filter(u => isAdmin || visibleUnitIds.includes(u.id))
                                        .map(u => (
                                            <option key={u.id} value={u.id} className="bg-gray-800">
                                                {u.nomeFantasia || u.razaoSocial}
                                            </option>
                                        ))
                                    }
                                </select>
                            ) : (
                                <span className="text-xs font-bold bg-white/10 border border-white/20 rounded px-2.5 py-1.5 text-white/90 flex items-center gap-1.5" title="Unidade ativa">
                                    <svg className="w-3 h-3 opacity-70" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-2 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                                    {(config.units || []).find(u => u.id === currentUnitId)?.nomeFantasia || (config.units || [])[0]?.nomeFantasia || 'Unidade'}
                                </span>
                            )}
                            {isAdmin && (config.userGroups || []).length > 0 && (
                                <select
                                    value={selectedAgendaGroupId}
                                    onChange={e => setSelectedAgendaGroupId(e.target.value)}
                                    className="text-xs font-bold bg-white/10 border border-white/20 rounded px-2 py-1.5 text-white focus:outline-none focus:ring-1 focus:ring-white/40"
                                    title="Filtrar por grupo"
                                >
                                    <option value="ALL" className="bg-gray-800">Todos os Grupos</option>
                                    {(config.userGroups || []).map(g => (
                                        <option key={g.id} value={g.id} className="bg-gray-800">{g.name}</option>
                                    ))}
                                </select>
                            )}
                            <button onClick={() => setSelectedDate(new Date().toISOString().split('T')[0])} className="px-3 py-1.5 text-xs font-bold bg-white/10 rounded border border-white/20">Hoje</button>
                            {onRefresh && (
                                <button
                                    onClick={onRefresh}
                                    title="Atualizar agenda agora"
                                    className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-bold bg-white/10 rounded border border-white/20 hover:bg-white/20 transition-colors"
                                >
                                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" /></svg>
                                    {lastRefreshedAt
                                        ? lastRefreshedAt.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })
                                        : 'Atualizar'}
                                </button>
                            )}
                        </div>
                    </div>

                    <div className="flex border-b border-gray-200 bg-white flex-shrink-0 shadow-sm z-10">
                        <div className="w-14 flex-shrink-0 border-r border-gray-200 bg-gray-50"></div>
                        <div
                            ref={headerScrollRef}
                            onScroll={handleHeaderScroll}
                            className="flex flex-1 overflow-x-auto hide-scrollbar"
                        >
                            {viewMode === 'DAILY' ? (
                                (config.collaborators || []).filter(c => gridCollaboratorIds.includes(c.id)).map(collab => (
                                    <div key={collab.id} className="flex-1 min-w-[150px] py-3 text-center border-r border-gray-200 last:border-0 font-bold text-gray-800 text-sm">{collab.name.split(' ')[0]}</div>
                                ))
                            ) : (
                                weekDays.map(dateStr => (
                                    <div key={dateStr} className={`flex-1 min-w-[120px] py-3 text-center border-r border-gray-200 last:border-0 ${dateStr === new Date().toISOString().split('T')[0] ? 'bg-blue-50' : ''}`}>
                                        <span className="text-[10px] text-gray-500 font-bold uppercase block">{new Date(dateStr + 'T12:00:00').toLocaleDateString('pt-BR', {weekday: 'short'})}</span>
                                        <span className="text-lg font-bold">{new Date(dateStr + 'T12:00:00').getDate()}</span>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>

                    <div ref={bodyScrollRef} onScroll={handleBodyScroll} className="flex-1 overflow-y-auto overflow-x-auto relative bg-white">
                        <div className="flex min-h-full">
                            <div className="w-14 flex-shrink-0 border-r border-gray-200 bg-white text-right text-[11px] font-medium text-gray-400 sticky left-0 z-10">
                                {timeSlots.map(time => <div key={time} className="h-[60px] pr-2 -mt-2">{time}</div>)}
                            </div>

                            {viewMode === 'DAILY' ? (
                                (config.collaborators || []).filter(c => gridCollaboratorIds.includes(c.id)).map(collab => (
                                    <div key={collab.id} className="flex-1 min-w-[150px] border-r border-gray-200 last:border-0 relative">
                                        {/* DROP ZONES */}
                                        {timeSlots.map(time => (
                                            <div 
                                                key={time} 
                                                className={`h-[60px] border-b border-gray-100 hover:bg-blue-50/50 cursor-pointer ${draggedAppointmentId ? 'hover:bg-green-50 transition-colors' : ''}`}
                                                onClick={() => handleOpenSlot(collab.id, time)}
                                                onDragOver={handleDragOver}
                                                onDrop={(e) => handleDrop(e, collab.id, time, selectedDate)}
                                            ></div>
                                        ))}

                                        {/* RENDERIZA BLOQUEIOS (VISÃO DIÁRIA) */}
                                        {getActiveBlocksFor(collab.id, selectedDate).map(block => {
                                            const dayStart = timeToMinutes(localAgendaConfig.startHour);
                                            const dayEnd = timeToMinutes(localAgendaConfig.endHour);
                                            const midDay = (dayStart + dayEnd) / 2;
                                            const blockTime = timeToMinutes(block.startTime || '08:00');
                                            
                                            const tooltipVerticalClass = blockTime > midDay 
                                                ? 'bottom-full mb-1' 
                                                : 'top-full mt-1';

                                            return (
                                                <div 
                                                    key={block.id}
                                                    className="absolute left-1 right-1 z-20 rounded border border-slate-300 border-l-4 group cursor-help overflow-hidden transition-all hover:brightness-95"
                                                    style={{
                                                        ...getBlockStyle(
                                                            block.isWholeDay ? localAgendaConfig.startHour : (block.startTime || '08:00'),
                                                            block.isWholeDay ? localAgendaConfig.endHour : (block.endTime || '18:00'),
                                                            '#f8fafc', '#64748b', true
                                                        ),
                                                        borderLeftColor: '#94a3b8'
                                                    }}
                                                >
                                                    <div className="p-1.5">
                                                        <div className="text-[10px] font-black uppercase text-slate-500 mb-0.5 tracking-tighter">BLOQUEADO</div>
                                                        <div className="text-[9px] font-bold text-slate-700 truncate whitespace-pre-wrap leading-tight">{block.reason}</div>
                                                    </div>

                                                    <div className={`hidden group-hover:block absolute left-1/2 -translate-x-1/2 w-64 bg-white rounded-xl shadow-2xl border border-gray-200 z-[100] animate-fade-in pointer-events-auto p-0 overflow-hidden ${tooltipVerticalClass}`}>
                                                        <div className="p-3 border-b bg-slate-50 border-slate-200">
                                                            <div className="flex items-center gap-2 mb-1">
                                                                <div className="w-2 h-2 rounded-full bg-slate-400"></div>
                                                                <span className="text-[10px] font-black uppercase text-slate-500 tracking-widest">INDISPONÍVEL</span>
                                                            </div>
                                                            <h4 className="font-black text-slate-900 leading-tight uppercase tracking-tighter">Agenda Bloqueada</h4>
                                                        </div>
                                                        <div className="p-3 space-y-2 max-h-64 overflow-y-auto custom-scrollbar">
                                                            <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                                                                <span>🕗 Horário</span>
                                                                <span className="text-gray-900">{block.isWholeDay ? 'Dia Inteiro' : `${block.startTime} - ${block.endTime}`}</span>
                                                            </div>
                                                            <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                                                                <span>👤 Consultor</span>
                                                                <span className="text-gray-900">{collab.name}</span>
                                                            </div>
                                                            <div className="mt-2 pt-2 border-t border-gray-100">
                                                                <span className="text-[9px] font-black uppercase text-gray-400 block mb-1">Motivo do Bloqueio:</span>
                                                                <p className="text-[11px] text-gray-700 leading-relaxed font-medium italic whitespace-pre-wrap break-words">
                                                                    {block.reason}
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        })}

                                        {displayedAppointments.filter(a => a.collaboratorId === collab.id).map(appt => {
                                            const statusColor = statusColors[appt.status] || '#3b82f6';
                                            const svc = (config.services || []).find(s => s.id === appt.serviceId);
                                            const apptClient = config.clients?.find(c => c.id === appt.clientId);
                                            const apptClientAddress = apptClient ? [apptClient.address, apptClient.number, apptClient.district, apptClient.city, apptClient.state].filter(Boolean).join(', ') : '';
                                            
                                            const leftBorderColor = appt.modalidade === 'PRESENCIAL' ? '#f97316' : appt.modalidade === 'ONLINE' ? '#3b82f6' : statusColor;

                                            return (
                                                <div
                                                    key={appt.id}
                                                    onClick={() => handleEditAppointment(appt)}
                                                    draggable={true}
                                                    onDragStart={(e) => handleDragStart(e, appt.id)}
                                                    onMouseEnter={(e) => handleApptMouseEnter(e, appt)}
                                                    onMouseLeave={handleApptMouseLeave}
                                                    className="absolute left-1 right-1 rounded border border-l-4 shadow-sm p-1.5 cursor-move z-10 hover:brightness-95 transition-all"
                                                    style={{
                                                        ...getBlockStyle(appt.startTime, appt.endTime, statusColor + '22', '#1f2937'),
                                                        borderLeftColor: leftBorderColor
                                                    }}
                                                >
                                                    <div className="flex items-center gap-1 mb-0.5">
                                                        <div className="text-[10px] font-bold truncate flex-1">{appt.clientName}</div>
                                                        <ModalidadeBadge modalidade={appt.modalidade} size="xs" />
                                                    </div>
                                                    <div className="text-[9px] font-semibold text-gray-600 mb-0.5">
                                                        {appt.startTime}{appt.endTime ? ` - ${appt.endTime}` : ''}
                                                    </div>
                                                    {apptClient?.phone && (
                                                        <div className="text-[10px] text-gray-500 truncate flex items-center gap-0.5">
                                                            <svg className="w-2.5 h-2.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                                                            {apptClient.phone}
                                                        </div>
                                                    )}
                                                    {apptClientAddress && (
                                                        <div className="text-[10px] text-gray-500 truncate flex items-center gap-0.5">
                                                            <svg className="w-2.5 h-2.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                                            {apptClientAddress}
                                                        </div>
                                                    )}
                                                    <div className="text-[9px] opacity-70 truncate">{svc?.name}</div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                ))
                            ) : (
                                weekDays.map((dateStr, dateIdx) => (
                                    <div key={dateStr} className="flex-1 min-w-[120px] border-r border-gray-200 last:border-0 relative">
                                        {timeSlots.map(time => (
                                            <div 
                                                key={time} 
                                                className={`h-[60px] border-b border-gray-100 hover:bg-blue-50/50 cursor-pointer ${draggedAppointmentId ? 'hover:bg-green-50 transition-colors' : ''}`}
                                                onClick={() => handleOpenSlot(null, time, dateStr)}
                                                onDragOver={handleDragOver}
                                                // Na visão semanal, como não temos a coluna "Collab", mantemos o collab original ou pegamos o primeiro visível
                                                onDrop={(e) => handleDrop(e, '', time, dateStr)} 
                                            ></div>
                                        ))}

                                        {gridCollaboratorIds.map(cid => getActiveBlocksFor(cid, dateStr).map(block => {
                                            const collab = (config.collaborators || []).find(c => c.id === cid);
                                            const tooltipSideClass = dateIdx >= 4 ? 'right-full mr-2 ml-0' : 'left-full ml-2 mr-0';

                                            return (
                                                <div 
                                                    key={`${block.id}-${cid}`}
                                                    className="absolute left-1 right-1 z-0 rounded border border-slate-300 border-l-4 group cursor-help overflow-hidden"
                                                    style={{
                                                        ...getBlockStyle(
                                                            block.isWholeDay ? localAgendaConfig.startHour : (block.startTime || '08:00'),
                                                            block.isWholeDay ? localAgendaConfig.endHour : (block.endTime || '18:00'),
                                                            '#f8fafc', '#64748b', true
                                                        ),
                                                        borderLeftColor: '#94a3b8'
                                                    }}
                                                >
                                                    <div className="p-1">
                                                        <div className="text-[8px] font-black text-slate-400 leading-none mb-0.5">BLOQUEIO</div>
                                                        <div className="text-[9px] font-bold text-slate-600 truncate">{block.reason}</div>
                                                    </div>

                                                    <div className={`hidden group-hover:block absolute top-0 w-72 bg-white rounded-xl shadow-2xl border border-gray-200 z-[100] animate-fade-in pointer-events-auto p-0 overflow-hidden ${tooltipSideClass}`}>
                                                        <div className="p-3 border-b bg-slate-50 border-slate-200">
                                                            <div className="flex items-center gap-2 mb-1">
                                                                <div className="w-2 h-2 rounded-full bg-slate-400"></div>
                                                                <span className="text-[10px] font-black uppercase text-slate-500 tracking-widest">INDISPONÍVEL</span>
                                                            </div>
                                                            <h4 className="font-black text-slate-900 leading-tight uppercase tracking-tighter">Bloqueio de Agenda</h4>
                                                        </div>
                                                        <div className="p-3 space-y-2 max-h-64 overflow-y-auto custom-scrollbar">
                                                            <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                                                                <span>📅 Data</span>
                                                                <span className="text-gray-900">{new Date(dateStr + 'T12:00:00').toLocaleDateString('pt-BR')}</span>
                                                            </div>
                                                            <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                                                                <span>🕗 Horário</span>
                                                                <span className="text-gray-900">{block.isWholeDay ? 'Dia Inteiro' : `${block.startTime} - ${block.endTime}`}</span>
                                                            </div>
                                                            <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                                                                <span>👤 Consultor</span>
                                                                <span className="text-gray-900">{collab?.name}</span>
                                                            </div>
                                                            <div className="mt-2 pt-2 border-t border-gray-100">
                                                                <span className="text-[9px] font-black uppercase text-gray-400 block mb-1">Motivo:</span>
                                                                <p className="text-[11px] text-gray-700 leading-relaxed font-medium italic whitespace-pre-wrap break-words">
                                                                    {block.reason}
                                                                </p>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            );
                                        }))}

                                        {displayedAppointments.filter(a => a.date === dateStr).map(appt => {
                                            const statusColor = statusColors[appt.status] || '#3b82f6';
                                            const svc = (config.services || []).find(s => s.id === appt.serviceId);
                                            const collab = (config.collaborators || []).find(c => c.id === appt.collaboratorId);
                                            const apptClient = config.clients?.find(c => c.id === appt.clientId);
                                            const apptClientAddress = apptClient ? [apptClient.address, apptClient.number, apptClient.district, apptClient.city, apptClient.state].filter(Boolean).join(', ') : '';
                                            const leftBorderColor = appt.modalidade === 'PRESENCIAL' ? '#f97316' : appt.modalidade === 'ONLINE' ? '#3b82f6' : statusColor;

                                            return (
                                                <div
                                                    key={appt.id}
                                                    onClick={() => handleEditAppointment(appt)}
                                                    draggable={true}
                                                    onDragStart={(e) => handleDragStart(e, appt.id)}
                                                    onMouseEnter={(e) => handleApptMouseEnter(e, appt)}
                                                    onMouseLeave={handleApptMouseLeave}
                                                    className="absolute left-1 right-1 rounded border border-l-4 shadow-sm p-1.5 cursor-move z-10 hover:brightness-95 transition-all"
                                                    style={{
                                                        ...getBlockStyle(appt.startTime, appt.endTime, statusColor + '22', '#1f2937'),
                                                        borderLeftColor: leftBorderColor
                                                    }}
                                                >
                                                    <div className="flex items-center gap-1 mb-0.5">
                                                        <div className="text-[10px] font-bold truncate flex-1">{appt.clientName}</div>
                                                        <ModalidadeBadge modalidade={appt.modalidade} size="xs" />
                                                    </div>
                                                    <div className="text-[9px] font-semibold text-gray-600 mb-0.5">
                                                        {appt.startTime}{appt.endTime ? ` - ${appt.endTime}` : ''}
                                                    </div>
                                                    {apptClient?.phone && (
                                                        <div className="text-[10px] text-gray-500 truncate flex items-center gap-0.5">
                                                            <svg className="w-2.5 h-2.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                                                            {apptClient.phone}
                                                        </div>
                                                    )}
                                                    {apptClientAddress && (
                                                        <div className="text-[10px] text-gray-500 truncate flex items-center gap-0.5">
                                                            <svg className="w-2.5 h-2.5 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                                            {apptClientAddress}
                                                        </div>
                                                    )}
                                                    <div className="text-[9px] opacity-70 truncate">{collab?.name.split(' ')[0]}</div>
                                                </div>
                                            );
                                        })}
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>

                {/* ── FAB: FILTRO RÁPIDO ─────────────────────────────────── */}
                {(() => {
                    const activeFilterCount = (activeCollaboratorFilter ? 1 : 0) + (activeClientFilter ? 1 : 0);
                    return (
                        <button
                            onClick={() => setShowFilterDrawer(true)}
                            className="fixed bottom-6 right-6 z-40 flex items-center justify-center rounded-full bg-[#1f2937] text-white shadow-lg hover:bg-[#374151] active:scale-95 transition-all"
                            style={{ width: 52, height: 52 }}
                            title="Filtros da Agenda"
                            aria-label="Abrir filtros da agenda"
                        >
                            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" />
                            </svg>
                            {activeFilterCount > 0 && (
                                <span className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center rounded-full bg-emerald-500 text-white text-[10px] font-black shadow">
                                    {activeFilterCount}
                                </span>
                            )}
                        </button>
                    );
                })()}

                {/* ── FILTER DRAWER ──────────────────────────────────────── */}
                <AgendaFilterDrawer
                    open={showFilterDrawer}
                    onClose={() => setShowFilterDrawer(false)}
                    collaborators={sidebarCollaborators}
                    activeCollaboratorFilter={activeCollaboratorFilter}
                    onSetCollaboratorFilter={setActiveCollaboratorFilter}
                    activeClientFilter={activeClientFilter}
                    onSetClientFilter={setActiveClientFilter}
                    appointments={config.appointments || []}
                    clients={config.clients || []}
                    config={config}
                    onNavigateToAppointment={handleNavigateToAppointment}
                />
            </div>
        )}

        {/* ... (RESTO DO CÓDIGO - FILA DE ESPERA, BLOQUEIO, SERVIÇOS, CONFIG E MODAIS - MANTIDOS IGUAIS) ... */}
        {/* OBS: O bloco de código para FILA, BLOQUEIO, SERVIÇOS e CONFIGURAÇÕES não precisa de alteração lógica, apenas é mantido para consistência do arquivo. Vou omitir a repetição excessiva do XML para focar nas mudanças principais se você preferir, mas como pediu o arquivo completo no formato XML, seguirei abaixo com o restante do arquivo intacto para garantir a substituição correta. */}

        {/* === FILA DE ESPERA TAB === */}
        {activeTab === 'FILA' && (
            <div className="p-6 h-full overflow-y-auto bg-gray-50">
                {/* ... CONTEÚDO DA FILA DE ESPERA MANTIDO ... */}
                <div className="max-w-4xl mx-auto space-y-6">
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm" data-form-container="true">
                        <h3 className="text-lg font-bold text-gray-800 border-b pb-3 mb-6 uppercase tracking-tighter italic">
                            {newWaitEntry.id ? 'Alterar Registro na Fila' : 'Adicionar à Fila de Espera'}
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            {/* 01. CLIENTE */}
                            <div className="relative">
                                <label className="block text-xs font-black text-gray-400 uppercase mb-1.5 ml-1">01. Cliente</label>
                                <input 
                                    type="text"
                                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moss-500 outline-none font-bold text-sm"
                                    placeholder="Pesquisar cliente..."
                                    value={clientSearchTerm}
                                    onChange={(e) => setClientSearchTerm(e.target.value)}
                                    onFocus={() => setShowClientDropdown(true)}
                                    onBlur={() => setTimeout(() => setShowClientDropdown(false), 200)}
                                />
                                {showClientDropdown && (
                                    <div className="absolute z-20 w-full bg-white border border-gray-200 rounded-lg shadow-xl max-h-48 overflow-y-auto mt-1">
                                        {filteredClients.map(client => (
                                            <div key={client.id} className="p-3 hover:bg-moss-50 cursor-pointer border-b" onMouseDown={() => handleSelectClient(client)}>
                                                <span className="font-bold text-gray-800 text-sm">{client.name}</span>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </div>

                            {/* 02. SERVIÇO */}
                            <div>
                                <label className="block text-xs font-black text-gray-400 uppercase mb-1.5 ml-1">02. Serviço Pretendido</label>
                                <select 
                                    className="w-full border border-gray-300 rounded-lg p-3 bg-white outline-none focus:ring-2 focus:ring-moss-500 font-bold text-sm"
                                    value={newWaitEntry.serviceId}
                                    onChange={(e) => setNewWaitEntry({ ...newWaitEntry, serviceId: e.target.value })}
                                >
                                    <option value="">Selecione o serviço...</option>
                                    {(config.services || []).map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                                </select>
                            </div>

                            {/* 03. COLABORADOR */}
                            <div>
                                <label className="block text-xs font-black text-gray-400 uppercase mb-1.5 ml-1">03. Consultor Preferencial</label>
                                <select 
                                    className="w-full border border-gray-300 rounded-lg p-3 bg-white outline-none focus:ring-2 focus:ring-moss-500 font-bold text-sm"
                                    value={newWaitEntry.collaboratorId}
                                    onChange={(e) => setNewWaitEntry({ ...newWaitEntry, collaboratorId: e.target.value })}
                                >
                                    <option value="">Sem preferência (Qualquer um)</option>
                                    {(config.collaborators || []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                </select>
                            </div>

                            {/* 04. DATA E HORÁRIO */}
                            <div className="grid grid-cols-2 gap-4">
                                <Input label="04. Data Pretendida" type="date" value={newWaitEntry.date} onChange={e => setNewWaitEntry({ ...newWaitEntry, date: e.target.value })} containerClassName="!mb-0" />
                                <Input label="Horário Inicial" type="time" value={newWaitEntry.time} onChange={e => setNewWaitEntry({ ...newWaitEntry, time: e.target.value })} containerClassName="!mb-0" />
                            </div>

                            {/* 05. OBSERVAÇÃO */}
                            <div className="md:col-span-2">
                                <label className="block text-xs font-black text-gray-400 uppercase mb-1.5 ml-1">05. Observações</label>
                                <textarea 
                                    className="w-full border border-gray-300 rounded-lg p-4 h-24 outline-none focus:ring-2 focus:ring-moss-500 font-medium text-sm text-gray-700"
                                    placeholder="Detalhes adicionais, urgência, ou restrições do cliente..."
                                    value={newWaitEntry.notes}
                                    onChange={e => setNewWaitEntry({ ...newWaitEntry, notes: e.target.value })}
                                />
                            </div>
                        </div>

                        <div className="mt-6 pt-6 border-t flex justify-end gap-3">
                            {newWaitEntry.id && (
                                <Button variant="outline" className="!w-auto px-8 py-3" onClick={() => { setNewWaitEntry({ ...newWaitEntry, id: '', notes: '', clientId: '', clientName: '' }); setClientSearchTerm(''); }}>Cancelar Edição</Button>
                            )}
                            <Button variant="primary" className="!w-auto px-12 py-3 font-black uppercase italic tracking-tighter" onClick={handleAddWaitlist}>
                                {newWaitEntry.id ? 'SALVAR ALTERAÇÕES' : 'ADICIONAR À FILA'}
                            </Button>
                        </div>
                    </div>

                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                        <div className="p-4 bg-gray-50 border-b flex justify-between items-center">
                            <h4 className="font-black text-gray-500 text-xs uppercase tracking-widest">Clientes Aguardando Horário</h4>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200 data-grid-typography">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="px-6 py-3 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Cliente</th>
                                        <th className="px-6 py-3 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Serviço</th>
                                        <th className="px-6 py-3 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Preferência</th>
                                        <th className="px-6 py-3 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Data/Hora</th>
                                        <th className="px-6 py-3 text-right text-[10px] font-black text-gray-400 uppercase tracking-widest">Ações</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200 bg-white">
                                    {waitlist.length === 0 && (
                                        <tr><td colSpan={5} className="px-6 py-10 text-center text-gray-400 italic text-sm">Ninguém na fila de espera no momento.</td></tr>
                                    )}
                                    {waitlist.map(w => (
                                        <tr key={w.id} className="hover:bg-gray-50 transition-colors group">
                                            <td className="px-6 py-4 text-sm font-bold text-gray-900">{w.clientName}</td>
                                            <td className="px-6 py-4 text-xs font-bold text-moss-600 uppercase">{w.serviceName}</td>
                                            <td className="px-6 py-4 text-xs text-gray-600">{w.collaboratorName}</td>
                                            <td className="px-6 py-4 text-xs font-mono text-gray-500">
                                                {new Date(w.date + 'T12:00:00').toLocaleDateString()} - {w.time}
                                            </td>
                                            <td className="px-6 py-4 text-right">
                                                <div className="flex justify-end gap-2">
                                                    <AuditLogButton entityId={w.id} entityName={w.clientName} logs={config.auditLogs || []} />
                                                    <button onClick={() => handlePromoteToAppointment(w)} className="text-green-600 hover:text-green-800 p-1.5 rounded hover:bg-green-50 transition-colors" title="Programar Agendamento">
                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" /></svg>
                                                    </button>
                                                    <button onClick={() => handleEditWaitlist(w)} className="text-blue-600 hover:text-blue-800 p-1.5 rounded hover:bg-blue-50 transition-colors" title="Editar Registro">
                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" /></svg>
                                                    </button>
                                                    <button onClick={() => handleRemoveWaitlist(w.id)} className="text-red-400 hover:text-red-600 p-1.5 rounded hover:bg-red-50 transition-colors" title="Remover da Fila">
                                                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                                    </button>
                                                </div>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* === BLOQUEIO TAB === */}
        {activeTab === 'BLOQUEIO' && (
            <div className="p-6 h-full overflow-y-auto bg-gray-50">
                {/* ... CONTEÚDO DE BLOQUEIO MANTIDO ... */}
                <div className="max-w-4xl mx-auto space-y-6">
                    <div className="bg-white p-6 rounded-xl border border-gray-200 shadow-sm" data-form-container="true">
                        <h3 className="text-lg font-bold text-gray-800 border-b pb-3 mb-6 uppercase tracking-tighter italic">Bloquear Agenda de Profissional</h3>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label className="block text-xs font-black text-gray-400 uppercase mb-1.5 ml-1">Consultor Responsável</label>
                                <select 
                                    className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moss-500 bg-white font-bold text-sm"
                                    value={newBlock.collaboratorId}
                                    onChange={e => setNewBlock({...newBlock, collaboratorId: e.target.value})}
                                >
                                    <option value="">Selecione...</option>
                                    {(config.collaborators || []).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                                </select>
                            </div>

                            <div className="flex items-center gap-4 pt-7">
                                <label className="flex items-center gap-3 cursor-pointer group">
                                    <input 
                                        type="checkbox" 
                                        className="w-5 h-5 text-moss-600 rounded focus:ring-moss-500 border-gray-300"
                                        checked={newBlock.isWholeDay}
                                        onChange={e => setNewBlock({...newBlock, isWholeDay: e.target.checked})}
                                    />
                                    <span className="text-xs font-black text-gray-600 uppercase tracking-widest group-hover:text-gray-900 transition-colors">Bloquear dia inteiro</span>
                                </label>
                            </div>

                            <div className="md:col-span-2 grid grid-cols-2 md:grid-cols-4 gap-4">
                                <Input label="Data Início" type="date" value={newBlock.startDate} onChange={e => setNewBlock({...newBlock, startDate: e.target.value})} containerClassName="!mb-0" />
                                <Input label="Data Fim" type="date" value={newBlock.endDate} onChange={e => setNewBlock({...newBlock, endDate: e.target.value})} containerClassName="!mb-0" />
                                {!newBlock.isWholeDay && (
                                    <>
                                        <Input label="Hora Início" type="time" value={newBlock.startTime} onChange={e => setNewBlock({...newBlock, startTime: e.target.value})} containerClassName="!mb-0" />
                                        <Input label="Hora Fim" type="time" value={newBlock.endTime} onChange={e => setNewBlock({...newBlock, endTime: e.target.value})} containerClassName="!mb-0" />
                                    </>
                                )}
                            </div>

                            <div className="md:col-span-2">
                                <label className="block text-xs font-black text-gray-400 uppercase mb-2 ml-1">Repetir nos dias da semana:</label>
                                <div className="flex gap-2">
                                    {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab'].map((day, idx) => (
                                        <button 
                                            key={idx}
                                            onClick={() => {
                                                const current = newBlock.repeatDays;
                                                setNewBlock({...newBlock, repeatDays: current.includes(idx) ? current.filter(d => d !== idx) : [...current, idx]});
                                            }}
                                            className={`flex-1 py-2 rounded text-[10px] font-black uppercase border transition-all ${newBlock.repeatDays.includes(idx) ? 'bg-moss-800 text-white border-moss-900 shadow-inner' : 'bg-white text-gray-400 border-gray-200 hover:border-gray-300'}`}
                                        >
                                            {day}
                                        </button>
                                    ))}
                                </div>
                            </div>

                            <div className="md:col-span-2">
                                <label className="block text-xs font-black text-gray-400 uppercase mb-1.5 ml-1">Motivo do Bloqueio (Será exibido na agenda)</label>
                                <textarea 
                                    className="w-full border border-gray-300 rounded-lg p-4 h-24 outline-none focus:ring-2 focus:ring-moss-500 font-medium text-sm text-gray-700"
                                    placeholder="Ex: Consultor em treinamento externo, Manutenção de sistema, Férias coletivas..."
                                    value={newBlock.reason}
                                    onChange={e => setNewBlock({...newBlock, reason: e.target.value})}
                                />
                            </div>
                        </div>

                        <div className="mt-6 pt-6 border-t flex justify-end">
                            <Button variant="primary" className="!w-auto px-12 py-3 font-black uppercase italic tracking-tighter" onClick={handleAddBlock}>ADICIONAR BLOQUEIO</Button>
                        </div>
                    </div>

                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                        <div className="p-4 bg-gray-50 border-b flex justify-between items-center">
                            <h4 className="font-black text-gray-500 text-xs uppercase tracking-widest">Lista de Bloqueios Ativos</h4>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="min-w-full divide-y divide-gray-200 data-grid-typography">
                                <thead className="bg-gray-50">
                                    <tr>
                                        <th className="px-6 py-3 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Colaborador</th>
                                        <th className="px-6 py-3 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Período</th>
                                        <th className="px-6 py-3 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Tipo</th>
                                        <th className="px-6 py-3 text-left text-[10px] font-black text-gray-400 uppercase tracking-widest">Motivo</th>
                                        <th className="px-6 py-3 text-right text-[10px] font-black text-gray-400 uppercase tracking-widest">Ações</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-gray-200 bg-white">
                                    {(scheduleBlocks || []).length === 0 && (
                                        <tr><td colSpan={5} className="px-6 py-10 text-center text-gray-400 italic text-sm">Nenhum bloqueio configurado.</td></tr>
                                    )}
                                    {(scheduleBlocks || []).map(b => (
                                        <tr key={b.id} className="hover:bg-gray-50 transition-colors">
                                            <td className="px-6 py-4 text-sm font-bold text-gray-900">{(config.collaborators || []).find(c => c.id === b.collaboratorId)?.name}</td>
                                            <td className="px-6 py-4 text-xs text-gray-600 font-medium">{new Date(b.startDate + 'T12:00:00').toLocaleDateString()} - {new Date(b.endDate + 'T12:00:00').toLocaleDateString()}</td>
                                            <td className="px-6 py-4">
                                                {b.isWholeDay ? (
                                                    <span className="px-2 py-0.5 rounded bg-red-100 text-red-700 text-[10px] font-black uppercase">DIA INTEIRO</span>
                                                ) : (
                                                    <span className="text-[10px] text-slate-600 font-black uppercase bg-slate-100 px-2 py-0.5 rounded">{b.startTime} às {b.endTime}</span>
                                                )}
                                            </td>
                                            <td className="px-6 py-4 text-sm text-gray-600 truncate max-w-xs font-medium italic">"{b.reason}"</td>
                                            <td className="px-6 py-4 text-right">
                                                <button onClick={() => handleRemoveBlock(b.id)} className="text-red-400 hover:text-red-600 transition-colors p-2">
                                                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        )}

        {/* === SERVICOS TAB === */}
        {activeTab === 'SERVICOS' && (
            <div className="p-6 h-full overflow-y-auto">
                {/* ... CONTEÚDO DE SERVIÇOS MANTIDO ... */}
                {!isEditingService ? (
                    <div className="space-y-4">
                        <div className="flex justify-between items-center">
                            <h3 className="font-bold text-gray-700">Catálogo de Serviços</h3>
                            <Button variant="new" className="!w-auto" onClick={() => { setCurrentService({ id: '', name: '', durationMinutes: 30, price: 0, color: '#e0e7ff' }); setIsEditingService(true); }}>Novo Serviço</Button>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            {(config.services || []).map(svc => (
                                <div key={svc.id} className="border p-4 rounded-lg flex justify-between items-center hover:shadow-md transition-shadow bg-white relative overflow-hidden">
                                    <div className="absolute left-0 top-0 bottom-0 w-2" style={{ backgroundColor: svc.color }}></div>
                                    <div className="pl-4">
                                        <p className="font-bold text-gray-800">{svc.name}</p>
                                        <p className="text-sm text-gray-500 mt-1">
                                            <span className="bg-gray-100 px-2 py-0.5 rounded text-xs font-mono mr-2">{svc.durationMinutes} min</span>
                                            <span className="text-green-700 font-bold">R$ {svc.price.toFixed(2)}</span>
                                        </p>
                                    </div>
                                    <div className="flex gap-2">
                                        <AuditLogButton entityId={svc.id} entityName={svc.name} logs={config.auditLogs || []} />
                                        <button onClick={() => { setCurrentService({...svc}); setIsEditingService(true); }} className="text-blue-600 hover:bg-blue-50 p-2 rounded">✎</button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                ) : (
                    <div className="max-w-lg mx-auto bg-gray-50 p-6 rounded-lg border shadow-sm animate-fade-in" data-form-container="true">
                        <h3 className="font-bold text-gray-800 mb-6 text-lg border-b pb-2">{currentService?.id ? 'Editar Serviço' : 'Novo Serviço'}</h3>
                        <div className="space-y-4">
                            <Input label="Nome do Serviço" value={currentService?.name || ''} onChange={e => setCurrentService(prev => prev ? {...prev, name: e.target.value} : null)} />
                            <div className="grid grid-cols-2 gap-4">
                                <Input label="Duração (min)" type="number" value={currentService?.durationMinutes || ''} onChange={e => setCurrentService(prev => prev ? {...prev, durationMinutes: parseInt(e.target.value)||0} : null)} />
                                <Input label="Preço (R$)" type="number" value={currentService?.price || ''} onChange={e => setCurrentService(prev => prev ? {...prev, price: parseFloat(e.target.value)||0} : null)} />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Cor Padrão</label>
                                <div className="flex gap-2 items-center">
                                    <input type="color" className="h-10 w-10 border rounded cursor-pointer p-0" value={currentService?.color || '#ffffff'} onChange={e => setCurrentService(prev => prev ? {...prev, color: e.target.value} : null)} />
                                    <span className="text-xs text-gray-500">Cor usada se não houver status definido.</span>
                                </div>
                            </div>
                            <div className="pt-4 flex gap-3 justify-end border-t mt-4">
                                <Button variant="outline" className="!w-auto" onClick={() => setIsEditingService(false)}>Cancelar</Button>
                                <Button variant="primary" className="!w-auto" onClick={handleSaveService}>Salvar Serviço</Button>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        )}

        {/* === CONFIG TAB === */}
        {activeTab === 'CONFIG' && (
            <div className="p-6 h-full overflow-y-auto">
                {/* ... CONTEÚDO DE CONFIGURAÇÕES MANTIDO ... */}
                <div className="max-w-2xl mx-auto space-y-8" data-form-container="true">
                    <div className="bg-white p-6 rounded-lg border shadow-sm">
                        <h3 className="font-bold text-gray-800 mb-4 border-b pb-2">Grade de Horários</h3>
                        <div className="grid grid-cols-2 gap-6">
                            <Input label="Horário Início" type="time" value={localAgendaConfig.startHour} onChange={e => setLocalAgendaConfig({...localAgendaConfig, startHour: e.target.value})} />
                            <Input label="Horário Fim" type="time" value={localAgendaConfig.endHour} onChange={e => setLocalAgendaConfig({...localAgendaConfig, endHour: e.target.value})} />
                        </div>
                        <div className="mt-4">
                            <label className="block text-sm font-medium text-gray-700 mb-1">Intervalo de Slot (Grade)</label>
                            <select className="w-full border rounded-lg p-3 bg-white focus:ring-2 focus:ring-moss-500 outline-none" value={localAgendaConfig.slotInterval} onChange={e => setLocalAgendaConfig({...localAgendaConfig, slotInterval: parseInt(e.target.value)})}>
                                <option value="15">15 minutos (Detalhado)</option>
                                <option value="30">30 minutos (Padrão)</option>
                                <option value="45">45 minutos</option>
                                <option value="60">60 minutos (Hora cheia)</option>
                            </select>
                        </div>
                    </div>
                    <div className="bg-white p-6 rounded-lg border shadow-sm">
                        <h3 className="font-bold text-gray-800 mb-4 border-b pb-2">Cadastro de Status & Cores</h3>
                        <div className="space-y-2">
                            {[
                                { k: 'AGUARDANDO', l: 'Aguardando' },
                                { k: 'AGENDADO', l: 'Agendado' },
                                { k: 'CONFIRMADO', l: 'Confirmado' },
                                { k: 'CANCELADO_CLIENTE', l: 'Cancelado Pelo Cliente' },
                                { k: 'CANCELADO_CONSULTOR', l: 'Cancelado Pelo Consultor' },
                                { k: 'NAO_COMPARECEU', l: 'Cliente Não Veio' }
                            ].map(({k, l}) => (
                                <div key={k} className="flex items-center justify-between border p-3 rounded-lg hover:bg-gray-50 transition-colors">
                                    <div className="flex items-center gap-3">
                                        <div className="w-4 h-4 rounded-full border border-gray-300 shadow-sm" style={{ backgroundColor: statusColors[k] || '#cccccc' }}></div>
                                        <span className="text-sm font-bold text-gray-700">{l}</span>
                                    </div>
                                    <div className="flex items-center gap-2">
                                        <input 
                                            type="color" 
                                            className="h-8 w-10 border border-gray-300 p-0.5 cursor-pointer rounded bg-white" 
                                            value={statusColors[k] || '#cccccc'} 
                                            onChange={(e) => setStatusColors(prev => ({...prev, [k]: e.target.value}))} 
                                        />
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className="pt-4 flex justify-end">
                        <Button variant="primary" className="!w-auto px-8" onClick={() => {
                            const newConfig = { ...config, agendaConfig: localAgendaConfig, statusColors: statusColors };
                            updateSection('agendaConfig', localAgendaConfig);
                            updateSection('statusColors', statusColors);
                            addToast('success', 'Sucesso', 'Configurações salvas.');
                        }}>Salvar Configurações</Button>
                    </div>
                </div>
            </div>
        )}
      </div>

      {/* ... (MODAIS MANTIDOS ABAIXO) ... */}
      
      {/* === COLLABORATOR SELECTION MODAL === */}
      {showCollabSelectionModal && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black bg-opacity-60 animate-fade-in p-4">
              <div data-grid-modal-size="2xl" className="bg-white rounded-xl shadow-2xl w-full max-w-2xl overflow-hidden flex flex-col max-h-[85vh]">
                  <div className="bg-moss-800 p-4 flex justify-between items-center text-white">
                      <div>
                          <h3 className="font-bold text-lg leading-none uppercase italic tracking-tighter">Gerenciar Consultores da Agenda</h3>
                          <p className="text-[10px] text-moss-300 font-bold mt-1 uppercase">Selecione quais agendas deseja visualizar na grade principal</p>
                      </div>
                      <button onClick={() => setShowCollabSelectionModal(false)} className="text-white/70 hover:text-white">✕</button>
                  </div>
                  <div className="flex-1 overflow-y-auto p-0">
                      <table className="min-w-full divide-y divide-gray-200 data-grid-typography">
                          <thead className="bg-gray-50 sticky top-0 z-10">
                              <tr>
                                  <th className="px-6 py-3 text-left text-[10px] font-black text-gray-500 uppercase tracking-widest">Profissional</th>
                                  <th className="px-6 py-3 text-center text-[10px] font-black text-gray-500 uppercase tracking-widest">Exibir</th>
                              </tr>
                          </thead>
                          <tbody className="bg-white divide-y divide-gray-200">
                              {(config.collaborators || []).map(collab => {
                                  const isVisible = visibleCollaboratorIds.includes(collab.id);
                                  return (
                                      <tr key={collab.id} className="hover:bg-gray-50 transition-colors">
                                          <td className="px-6 py-4 whitespace-nowrap">
                                              <div className="flex items-center gap-3">
                                                  <div className="h-10 w-10 rounded-full bg-gray-100 overflow-hidden flex items-center justify-center text-gray-400 font-bold">
                                                      {collab.photoUrl ? <img src={collab.photoUrl} className="w-full h-full object-cover" /> : collab.name.charAt(0)}
                                                  </div>
                                                  <div>
                                                      <div className="text-xs font-bold text-gray-900">{collab.name}</div>
                                                      <div className="text-xs text-gray-500 uppercase font-medium">{collab.jobTitle || 'Consultor'}</div>
                                                  </div>
                                              </div>
                                          </td>
                                          <td className="px-6 py-4 whitespace-nowrap text-center">
                                              <button 
                                                onClick={() => toggleCollaboratorVisibility(collab.id)}
                                                className={`w-12 h-6 rounded-full relative transition-colors duration-200 ease-in-out ${isVisible ? 'bg-moss-600' : 'bg-gray-300'}`}
                                              >
                                                  <div className={`w-4 h-4 rounded-full bg-white absolute top-1 transition-transform duration-200 ${isVisible ? 'translate-x-7' : 'translate-x-1'}`}></div>
                                              </button>
                                          </td>
                                      </tr>
                                  );
                              })}
                              {(config.collaborators || []).length === 0 && (
                                  <tr>
                                      <td colSpan={2} className="px-6 py-10 text-center text-gray-400 italic">Nenhum colaborador cadastrado no sistema.</td>
                                  </tr>
                              )}
                          </tbody>
                      </table>
                  </div>
                  <div className="p-4 border-t bg-gray-50 flex justify-between items-center">
                      <span className="text-[10px] font-black text-gray-400 uppercase">{visibleCollaboratorIds.length} Agenda(s) Visível(is)</span>
                      <Button variant="primary" className="!w-auto px-10 py-3 font-black uppercase italic tracking-tighter" onClick={() => setShowCollabSelectionModal(false)}>CONCLUIR</Button>
                  </div>
              </div>
          </div>
      )}

      {/* === APPOINTMENT MODAL === */}
      {showAppointmentModal && currentAppointment && (
          <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-60 animate-fade-in p-4">
              <div className="bg-white rounded-xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
                  <div className="bg-moss-800 p-4 flex justify-between items-center text-white">
                      <h3 className="font-bold text-lg uppercase italic tracking-tighter">{isNewAppointment ? 'Novo Agendamento' : 'Editar Agendamento'}</h3>
                      <button onClick={() => { setShowAppointmentModal(false); setPromotedWaitlistId(null); }} className="text-white/70 hover:text-white">✕</button>
                  </div>
                  <div className="p-6 overflow-y-auto space-y-4" data-form-container="true">
                      {/* ... CONTEÚDO DO MODAL DE AGENDAMENTO MANTIDO ... */}
                      <div className="relative">
                          <label className="block text-xs font-black text-gray-500 uppercase mb-1.5 ml-1">Cliente</label>
                          <input 
                              type="text"
                              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moss-500 outline-none font-bold text-sm"
                              placeholder="Pesquisar cliente..."
                              value={clientSearchTerm}
                              onChange={(e) => setClientSearchTerm(e.target.value)}
                              onFocus={() => setShowClientDropdown(true)}
                              onBlur={() => setTimeout(() => setShowClientDropdown(false), 200)}
                          />
                          {showClientDropdown && (
                              <div className="absolute z-20 w-full bg-white border border-gray-200 rounded-lg shadow-xl max-h-48 overflow-y-auto mt-1">
                                  {filteredClients.map(client => (
                                      <div key={client.id} className="p-3 hover:bg-moss-50 cursor-pointer border-b" onMouseDown={() => handleSelectClient(client)}>
                                          <span className="font-bold text-gray-800 text-sm">{client.name}</span>
                                      </div>
                                  ))}
                              </div>
                          )}
                      </div>
                      <div>
                          <label className="block text-xs font-black text-gray-500 uppercase mb-1.5 ml-1">Serviço</label>
                          <select 
                              className="w-full border border-gray-300 rounded-lg p-3 bg-gray-50 outline-none focus:ring-2 focus:ring-moss-500 font-bold text-sm"
                              value={currentAppointment.serviceId}
                              onChange={(e) => {
                                  const svc = (config.services || []).find(s => s.id === e.target.value);
                                  setCurrentAppointment({...currentAppointment, serviceId: e.target.value, endTime: svc ? addMinutes(currentAppointment.startTime, svc.durationMinutes) : currentAppointment.endTime});
                              }}
                          >
                              <option value="">Selecione...</option>
                              {(config.services || []).map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
                          </select>
                      </div>
                      <div className="grid grid-cols-3 gap-4">
                          <Input label="Data" type="date" value={currentAppointment.date} onChange={e => setCurrentAppointment({...currentAppointment, date: e.target.value})} containerClassName="!mb-0" />
                          <Input label="Horário Inicial" type="time" value={currentAppointment.startTime} onChange={e => setCurrentAppointment({...currentAppointment, startTime: e.target.value})} containerClassName="!mb-0" />
                          <Input label="Horário Final" type="time" value={currentAppointment.endTime || ''} onChange={e => setCurrentAppointment({...currentAppointment, endTime: e.target.value})} containerClassName="!mb-0" />
                      </div>

                      {/* UNIDADE SELECTOR */}
                      {(config.units || []).length > 1 && (
                          <div>
                              <label className="block text-xs font-black text-gray-500 uppercase mb-1.5 ml-1">Unidade</label>
                              <select
                                  className="w-full border border-gray-300 rounded-lg p-3 bg-gray-50 outline-none focus:ring-2 focus:ring-moss-500 font-bold text-sm"
                                  value={currentAppointment.unitId || ''}
                                  onChange={e => setCurrentAppointment({...currentAppointment, unitId: e.target.value})}
                              >
                                  <option value="">Selecione a unidade...</option>
                                  {(config.units || []).map(u => (
                                      <option key={u.id} value={u.id}>{u.nomeFantasia || u.razaoSocial}</option>
                                  ))}
                              </select>
                          </div>
                      )}

                      {/* MODALIDADE SELECTOR */}
                      <div>
                          <label className="block text-xs font-black text-gray-500 uppercase mb-2 ml-1">Modalidade</label>
                          <div className="flex gap-3">
                              <button
                                  type="button"
                                  onClick={() => setCurrentAppointment({...currentAppointment, modalidade: 'PRESENCIAL'})}
                                  className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl border-2 font-black text-sm uppercase tracking-wide transition-all ${
                                      currentAppointment.modalidade === 'PRESENCIAL'
                                          ? 'bg-orange-500 border-orange-500 text-white shadow-lg shadow-orange-200 scale-105'
                                          : 'bg-orange-50 border-orange-200 text-orange-400 hover:border-orange-400 hover:bg-orange-100'
                                  }`}
                              >
                                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                  Presencial
                              </button>
                              <button
                                  type="button"
                                  onClick={() => setCurrentAppointment({...currentAppointment, modalidade: 'ONLINE'})}
                                  className={`flex-1 flex items-center justify-center gap-2 py-3 px-4 rounded-xl border-2 font-black text-sm uppercase tracking-wide transition-all ${
                                      currentAppointment.modalidade === 'ONLINE'
                                          ? 'bg-blue-500 border-blue-500 text-white shadow-lg shadow-blue-200 scale-105'
                                          : 'bg-blue-50 border-blue-200 text-blue-400 hover:border-blue-400 hover:bg-blue-100'
                                  }`}
                              >
                                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                                  OnLine
                              </button>
                          </div>
                          {!currentAppointment.modalidade && (
                              <p className="text-[10px] text-gray-400 mt-1.5 ml-1">Selecione a modalidade do atendimento</p>
                          )}
                      </div>

                      {/* STATUS SELECTOR IN MODAL */}
                      <div>
                          <label className="block text-xs font-black text-gray-500 uppercase mb-1.5 ml-1">Status</label>
                          <select
                              className="w-full border border-gray-300 rounded-lg p-3 bg-white outline-none focus:ring-2 focus:ring-moss-500 font-bold text-sm"
                              value={currentAppointment.status}
                              onChange={(e) => setCurrentAppointment({...currentAppointment, status: e.target.value as AppointmentStatus})}
                          >
                              <option value="AGUARDANDO">Aguardando</option>
                              <option value="AGENDADO">Agendado</option>
                              <option value="CONFIRMADO">Confirmado (Envia WhatsApp)</option>
                              <option value="CANCELADO_CLIENTE">Cancelado (Cliente)</option>
                              <option value="CANCELADO_CONSULTOR">Cancelado (Consultor)</option>
                              <option value="NAO_COMPARECEU">Não Compareceu</option>
                          </select>
                      </div>

                      <div>
                          <label className="block text-xs font-black text-gray-500 uppercase mb-1.5 ml-1">Observações</label>
                          <textarea className="w-full border border-gray-300 rounded-lg p-3 h-20 outline-none text-sm font-medium" value={currentAppointment.notes || ''} onChange={e => setCurrentAppointment({...currentAppointment, notes: e.target.value})}></textarea>
                      </div>
                  </div>
                  <div className="p-4 border-t bg-gray-50 flex justify-end gap-2">
                      <Button variant="ghost" className="!w-auto px-6 py-3 font-bold text-xs" onClick={() => { setShowAppointmentModal(false); setPromotedWaitlistId(null); }}>FECHAR</Button>
                      <Button variant="primary" className="!w-auto px-10 py-3 font-black uppercase italic tracking-tighter" onClick={handleSaveAppointment}>SALVAR AGENDAMENTO</Button>
                  </div>
              </div>
          </div>
      )}

      {/* FLOATING APPOINTMENT TOOLTIP — fixed position, escapes overflow clip */}
      {hoveredApptTooltip && (() => {
          const { appt, x, y, side, vside } = hoveredApptTooltip;
          const statusColor = statusColors[appt.status] || '#3b82f6';
          const svc = (config.services || []).find(s => s.id === appt.serviceId);
          const collabTooltip = (config.collaborators || []).find(c => c.id === appt.collaboratorId);
          const clientTooltip = (config.clients || []).find(c => c.id === appt.clientId);
          const addressTooltip = clientTooltip ? [clientTooltip.address, clientTooltip.number, clientTooltip.district, clientTooltip.city, clientTooltip.state].filter(Boolean).join(', ') : '';
          const leftStyle = side === 'left' ? x : undefined;
          const rightStyle = side === 'right' ? window.innerWidth - x : undefined;
          const topStyle = vside === 'top' ? y : undefined;
          const bottomStyle = vside === 'bottom' ? window.innerHeight - y : undefined;
          return (
              <div
                  className="fixed z-[9999] w-72 bg-white rounded-xl shadow-2xl border border-gray-200 overflow-hidden pointer-events-none"
                  style={{ left: leftStyle, right: rightStyle, top: topStyle, bottom: bottomStyle, maxHeight: '80vh' }}
              >
                  <div className="p-3 border-b" style={{ backgroundColor: statusColor + '11', borderBottomColor: statusColor + '44' }}>
                      <div className="flex items-center gap-2 mb-1">
                          <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: statusColor }}></div>
                          <span className="text-[10px] font-black uppercase text-gray-500 tracking-widest">{appt.status}</span>
                          <ModalidadeBadge modalidade={appt.modalidade} size="xs" />
                      </div>
                      <h4 className="font-black text-gray-900 leading-tight uppercase tracking-tighter">{appt.clientName}</h4>
                  </div>
                  <div className="p-3 space-y-2 max-h-64 overflow-y-auto custom-scrollbar">
                      {clientTooltip?.phone && (
                          <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                              <span>📞 Telefone</span>
                              <span className="text-gray-900">{clientTooltip.phone}</span>
                          </div>
                      )}
                      {addressTooltip && (
                          <div className="text-[10px] font-bold uppercase text-gray-400">
                              <span>📍 Endereço</span>
                              <span className="text-gray-900 block normal-case font-medium mt-0.5">{addressTooltip}</span>
                          </div>
                      )}
                      <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                          <span>📅 Data</span>
                          <span className="text-gray-900">{new Date(appt.date + 'T12:00:00').toLocaleDateString('pt-BR')}</span>
                      </div>
                      <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                          <span>🕗 Horário</span>
                          <span className="text-gray-900">{appt.startTime} - {appt.endTime}</span>
                      </div>
                      {collabTooltip && (
                          <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                              <span>👤 Consultor</span>
                              <span className="text-gray-900">{collabTooltip.name}</span>
                          </div>
                      )}
                      <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                          <span>📋 Serviço</span>
                          <span className="text-gray-900">{svc?.name || 'Não informado'}</span>
                      </div>
                      {appt.unitId && (
                          <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                              <span>🏢 Unidade</span>
                              <span className="text-gray-900">{(config.units || []).find(u => u.id === appt.unitId)?.nomeFantasia || appt.unitId}</span>
                          </div>
                      )}
                      {appt.modalidade && (
                          <div className="flex items-center justify-between text-[10px] font-bold uppercase text-gray-400">
                              <span>📍 Modalidade</span>
                              <ModalidadeBadge modalidade={appt.modalidade} size="sm" />
                          </div>
                      )}
                      {(appt.createdBy || appt.updatedBy) && (
                          <div className="mt-2 pt-2 border-t border-gray-100 space-y-1">
                              {appt.createdBy && (
                                  <div>
                                      <span className="text-[9px] font-black uppercase text-gray-400 block">👤 Incluído por</span>
                                      <span className="text-[11px] text-gray-700 font-medium">{appt.createdBy.name} <span className="text-gray-400 font-normal">· {new Date(appt.createdBy.at).toLocaleString('pt-BR', {day:'2-digit',month:'2-digit',year:'2-digit',hour:'2-digit',minute:'2-digit'})}</span></span>
                                  </div>
                              )}
                              {appt.updatedBy && (
                                  <div>
                                      <span className="text-[9px] font-black uppercase text-gray-400 block">✏️ Alterado por</span>
                                      <span className="text-[11px] text-gray-700 font-medium">{appt.updatedBy.name} <span className="text-gray-400 font-normal">· {new Date(appt.updatedBy.at).toLocaleString('pt-BR', {day:'2-digit',month:'2-digit',year:'2-digit',hour:'2-digit',minute:'2-digit'})}</span></span>
                                  </div>
                              )}
                          </div>
                      )}
                      {appt.notes && (
                          <div className="mt-2 pt-2 border-t border-gray-100">
                              <span className="text-[9px] font-black uppercase text-gray-400 block mb-1">Observações:</span>
                              <p className="text-[11px] text-gray-700 leading-relaxed font-medium italic whitespace-pre-wrap break-words">{appt.notes}</p>
                          </div>
                      )}
                  </div>
              </div>
          );
      })()}
    </div>
  );
};

export default SchedulerPanel;

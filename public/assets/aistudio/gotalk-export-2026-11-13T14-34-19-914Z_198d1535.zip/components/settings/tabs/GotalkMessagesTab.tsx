import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { api } from '../../../services/apiService';
import GotalkAttendanceViewer from '../../gotalk/GotalkAttendanceViewer';

// ─── Types ───────────────────────────────────────────────────────────────────

interface GotalkMessage {
  id: string;
  gotalk_message_id: string | null;
  phone_number: string;
  direction: 'IN' | 'OUT';
  body: string;
  message_type: string;
  operator_name: string | null;
  department: string | null;
  sent_at: string;
  read_at: string | null;
  attachment_url: string | null;
  attachment_name: string | null;
  attachment_mime_type: string | null;
  attachment_size: number | null;
  audio_transcript: string | null;
  ack_status: number | null;
  contact_name: string | null;
  client_name: string | null;
  template_body?: string | null;
  template_header?: string | null;
  template_footer?: string | null;
  template_category?: string | null;
  template_status?: string | null;
}

interface ChatbotMenuOption {
  _id?: string;
  name?: string;
  title?: string;
  description?: string;
  action?: string;
  options?: ChatbotMenuOption[];
  items?: ChatbotMenuOption[];
}

interface ChatbotMenu {
  _id?: string;
  name?: string;
  title?: string;
  description?: string;
  options?: ChatbotMenuOption[];
  items?: ChatbotMenuOption[];
}

interface ChatbotMenusResponse {
  menus?: ChatbotMenu[];
  data?: ChatbotMenu[];
}

interface MessagesResponse {
  data: GotalkMessage[];
  total: number;
}

interface OperatorsResponse {
  data: string[];
}

interface GotalkChannel {
  id: string;
  name: string;
  phone_number: string | null;
  is_primary: boolean;
  is_active: boolean;
  unit_id: string | null;
  unit_name: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

interface ChannelsResponse {
  channels: GotalkChannel[];
  total: number;
}

type SortCol = 'sent_at' | 'direction' | 'phone_number' | 'contact_name' | 'operator_name' | 'message_type';
type SortDir = 'asc' | 'desc';

// ─── Constants ───────────────────────────────────────────────────────────────

const PAGE_SIZE       = 50;
const PHONE_PAGE_SIZE = 50;

// ─── Helpers ─────────────────────────────────────────────────────────────────

const errMsg = (e: unknown): string =>
  e instanceof Error ? e.message : String(e);

const fmtDate = (iso: string | null) => {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' });
};

const fmtDateLong = (iso: string | null) => {
  if (!iso) return '—';
  return new Date(iso).toLocaleString('pt-BR', { dateStyle: 'full', timeStyle: 'medium' });
};

const formatDayLabel = (dateStr: string): string => {
  const d   = new Date(dateStr);
  const now  = new Date();
  const today     = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const yesterday = new Date(today.getTime() - 86400000);
  const dDay      = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  if (dDay.getTime() === today.getTime())     return 'Hoje';
  if (dDay.getTime() === yesterday.getTime()) return 'Ontem';
  return d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
};

const fmtBytes = (bytes: number | null | undefined): string => {
  if (!bytes || bytes <= 0) return '';
  if (bytes < 1024)        return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
};

function extFromMime(mime: string | null | undefined, fallbackName: string | null | undefined): string {
  const m = (mime || '').toLowerCase();
  if (m.includes('pdf')) return '.pdf';
  if (m.includes('jpeg') || m.includes('jpg')) return '.jpg';
  if (m.includes('png')) return '.png';
  if (m.includes('gif')) return '.gif';
  if (m.includes('webp')) return '.webp';
  if (m.includes('mp4')) return '.mp4';
  if (m.includes('webm')) return '.webm';
  if (m.includes('ogg') && m.includes('video')) return '.ogv';
  if (m.includes('mp3') || (m.includes('mpeg') && m.includes('audio'))) return '.mp3';
  if (m.includes('wav')) return '.wav';
  if (m.includes('ogg')) return '.ogg';
  if (m.includes('m4a') || m.includes('aac')) return '.m4a';
  if (m.includes('word') || m.includes('docx')) return '.docx';
  if (m.includes('doc')) return '.doc';
  if (m.includes('sheet') || m.includes('xlsx')) return '.xlsx';
  if (m.includes('xls')) return '.xls';
  if (m.includes('presentation') || m.includes('pptx')) return '.pptx';
  if (m.includes('ppt')) return '.ppt';
  if (m.includes('zip')) return '.zip';
  if (m.includes('rar')) return '.rar';
  if (fallbackName) {
    const dot = fallbackName.lastIndexOf('.');
    if (dot > 0) return fallbackName.slice(dot);
  }
  return '';
}

function safeDownloadName(
  name: string | null | undefined,
  mime: string | null | undefined,
  fallback: string,
): string {
  if (name) {
    const hasDot = name.lastIndexOf('.') > 0;
    if (hasDot) return name;
    const ext = extFromMime(mime, null);
    return name + ext;
  }
  const ext = extFromMime(mime, null);
  return fallback + ext;
}

// ─── Badges ─────────────────────────────────────────────────────────────────

const TYPE_MAP: Record<string, { label: string; cls: string; icon: string }> = {
  TEXT:     { label: 'Texto',    cls: 'bg-gray-100 text-gray-700',    icon: '💬' },
  IMAGE:    { label: 'Imagem',   cls: 'bg-blue-100 text-blue-700',    icon: '🖼️' },
  AUDIO:    { label: 'Áudio',    cls: 'bg-purple-100 text-purple-700',icon: '🎵' },
  VIDEO:    { label: 'Vídeo',    cls: 'bg-pink-100 text-pink-700',    icon: '🎬' },
  DOCUMENT: { label: 'Doc',      cls: 'bg-amber-100 text-amber-700',  icon: '📄' },
  HSM:      { label: 'Template', cls: 'bg-green-100 text-green-700',  icon: '📋' },
  TEMPLATE: { label: 'Template', cls: 'bg-green-100 text-green-700',  icon: '📋' },
  STICKER:  { label: 'Sticker',  cls: 'bg-rose-100 text-rose-700',    icon: '😊' },
};

const TypeBadge: React.FC<{ type: string }> = ({ type }) => {
  const cfg = TYPE_MAP[type?.toUpperCase()] ?? { label: type, cls: 'bg-gray-100 text-gray-500', icon: '?' };
  return (
    <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${cfg.cls}`}>
      <span>{cfg.icon}</span>{cfg.label}
    </span>
  );
};

const DirBadge: React.FC<{ dir: string }> = ({ dir }) => (
  <span className={`px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${dir === 'IN' ? 'bg-moss-100 text-moss-700' : 'bg-orange-100 text-orange-700'}`}>
    {dir === 'IN' ? '⬇ Entrada' : '⬆ Saída'}
  </span>
);

// ─── File meta chip ──────────────────────────────────────────────────────────

const FileMeta: React.FC<{ mime: string | null; size: number | null; name?: string | null }> = ({ mime, size, name }) => {
  const ext = extFromMime(mime, name).toUpperCase().replace('.', '');
  const sz  = fmtBytes(size);
  if (!ext && !sz) return null;
  return (
    <div className="flex flex-wrap gap-1 mt-1">
      {ext && (
        <span className="px-1.5 py-0.5 bg-gray-100 text-gray-600 text-[10px] rounded font-mono font-bold">{ext}</span>
      )}
      {sz && (
        <span className="px-1.5 py-0.5 bg-gray-100 text-gray-500 text-[10px] rounded">{sz}</span>
      )}
    </div>
  );
};

// ─── Download button ─────────────────────────────────────────────────────────

const DlButton: React.FC<{ url: string; name: string; label?: string }> = ({ url, name, label }) => (
  <a
    href={url}
    download={name}
    target="_blank"
    rel="noreferrer"
    className="inline-flex items-center gap-1 text-xs text-moss-700 hover:text-moss-900 underline mt-1"
  >
    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
      <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
    </svg>
    {label ?? 'Baixar'}
  </a>
);

// ─── Media viewer ─────────────────────────────────────────────────────────────

const MediaViewer: React.FC<{ msg: GotalkMessage; compact?: boolean }> = ({ msg, compact = false }) => {
  const mediaUrl = `/api/gotalk/media/${msg.id}`;
  const dlUrl    = `/api/gotalk/media/${msg.id}?download=1`;
  const mime     = (msg.attachment_mime_type || '').toLowerCase();
  const type     = (msg.message_type || '').toUpperCase();
  const dlName   = safeDownloadName(msg.attachment_name, msg.attachment_mime_type, `media-${msg.id}`);
  const hasMedia = !!(msg.attachment_url || msg.attachment_name);
  const isPdf    = mime.includes('pdf') || (msg.attachment_name || '').toLowerCase().endsWith('.pdf');
  const ext      = extFromMime(msg.attachment_mime_type, msg.attachment_name).toUpperCase().replace('.', '');

  const [lightboxOpen, setLightboxOpen] = useState(false);
  const [audioError,   setAudioError]   = useState(false);
  const [videoError,   setVideoError]   = useState(false);
  const [imgError,     setImgError]     = useState(false);
  const [pdfExpanded,  setPdfExpanded]  = useState(false);

  if (!hasMedia) return null;

  if (type === 'IMAGE' || mime.startsWith('image/')) {
    return (
      <div className="flex flex-col items-start gap-1">
        {imgError ? (
          <p className="text-xs text-red-400 italic">Imagem indisponível</p>
        ) : (
          <img
            src={mediaUrl}
            alt={msg.attachment_name || 'imagem'}
            className={`rounded-lg object-contain border border-gray-200 shadow cursor-zoom-in hover:opacity-90 transition-opacity ${compact ? 'max-h-40' : 'max-h-80'}`}
            onError={() => setImgError(true)}
            onClick={() => setLightboxOpen(true)}
          />
        )}
        <FileMeta mime={msg.attachment_mime_type} size={msg.attachment_size} name={msg.attachment_name} />
        {!imgError && <DlButton url={dlUrl} name={dlName} label={`Baixar${ext ? ' ' + ext : ''}`} />}
        {lightboxOpen && (
          <div
            className="fixed inset-0 z-[9999] flex items-center justify-center bg-black/85"
            onClick={() => setLightboxOpen(false)}
          >
            <div className="relative max-w-[92vw] max-h-[92vh]" onClick={e => e.stopPropagation()}>
              <img
                src={mediaUrl}
                alt={msg.attachment_name || 'imagem'}
                className="max-w-full max-h-[87vh] rounded-lg object-contain"
              />
              <div className="absolute top-2 right-2 flex gap-2">
                <a
                  href={dlUrl}
                  download={dlName}
                  className="flex items-center gap-1 bg-white/90 hover:bg-white text-gray-800 text-xs px-2 py-1 rounded shadow"
                  onClick={e => e.stopPropagation()}
                >
                  <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                  </svg>
                  Baixar
                </a>
                <button
                  className="bg-white/90 hover:bg-white text-gray-800 text-xs px-2 py-1 rounded shadow"
                  onClick={() => setLightboxOpen(false)}
                >
                  ✕
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (type === 'AUDIO' || mime.startsWith('audio/')) {
    return (
      <div className="flex flex-col gap-1 w-full">
        {audioError ? (
          <p className="text-xs text-red-400 italic">Áudio indisponível</p>
        ) : (
          <audio controls src={mediaUrl} className="w-full" preload="metadata" onError={() => setAudioError(true)}>
            Seu navegador não suporta reprodução de áudio.
          </audio>
        )}
        <FileMeta mime={msg.attachment_mime_type} size={msg.attachment_size} name={msg.attachment_name} />
        {msg.audio_transcript && (
          <div className="bg-purple-50 border border-purple-200 rounded-lg p-3 mt-1">
            <p className="text-[10px] font-bold text-purple-600 uppercase mb-1">Transcrição automática</p>
            <p className="text-sm text-gray-700 italic">{msg.audio_transcript}</p>
          </div>
        )}
        {!audioError && <DlButton url={dlUrl} name={dlName} label={`Baixar${ext ? ' ' + ext : ' áudio'}`} />}
      </div>
    );
  }

  if (type === 'VIDEO' || mime.startsWith('video/')) {
    return (
      <div className="flex flex-col items-start gap-1">
        {videoError ? (
          <p className="text-xs text-red-400 italic">Vídeo indisponível</p>
        ) : (
          <video
            controls
            src={mediaUrl}
            preload="metadata"
            className={`rounded-lg border border-gray-200 shadow w-full ${compact ? 'max-h-40' : 'max-h-64'}`}
            onError={() => setVideoError(true)}
          >
            Seu navegador não suporta reprodução de vídeo.
          </video>
        )}
        <FileMeta mime={msg.attachment_mime_type} size={msg.attachment_size} name={msg.attachment_name} />
        {!videoError && <DlButton url={dlUrl} name={dlName} label={`Baixar${ext ? ' ' + ext : ' vídeo'}`} />}
      </div>
    );
  }

  if (isPdf) {
    const showEmbed = !compact || pdfExpanded;
    return (
      <div className="flex flex-col gap-1">
        {showEmbed && (
          /* Using <object> (not <embed>) to support nested fallback content
             when the browser cannot render the PDF inline */
          <object
            data={mediaUrl}
            type="application/pdf"
            className="w-full rounded-lg border border-gray-200"
            style={{ height: '420px' }}
          >
            <div className="flex flex-col items-center justify-center gap-2 h-full bg-gray-50 rounded-lg border border-gray-200 py-6 text-center">
              <svg className="w-8 h-8 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
              </svg>
              <p className="text-sm text-gray-500">Não foi possível exibir o PDF no navegador.</p>
              <p className="text-xs text-gray-400">Use os botões abaixo para abrir ou baixar o arquivo.</p>
            </div>
          </object>
        )}
        <div className="flex items-center gap-3 mt-1">
          <span className="text-2xl">📄</span>
          <div className="flex flex-col gap-1 min-w-0">
            <span className="text-sm font-medium text-gray-700">{msg.attachment_name || 'Documento PDF'}</span>
            <FileMeta mime={msg.attachment_mime_type} size={msg.attachment_size} name={msg.attachment_name} />
            <div className="flex gap-3 flex-wrap items-center">
              {compact && (
                <button
                  onClick={() => setPdfExpanded(v => !v)}
                  className="text-xs text-blue-600 hover:underline"
                >
                  {pdfExpanded ? 'Recolher' : 'Visualizar PDF'}
                </button>
              )}
              {!compact && (
                <a href={mediaUrl} target="_blank" rel="noreferrer" className="text-xs text-blue-600 hover:underline">
                  Abrir em nova aba
                </a>
              )}
              <DlButton url={dlUrl} name={dlName} label="Baixar PDF" />
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-3 py-1">
      <span className="text-2xl">📎</span>
      <div className="flex flex-col gap-1 min-w-0">
        <span className="text-sm font-medium text-gray-700 break-all">{msg.attachment_name || 'Documento'}</span>
        <FileMeta mime={msg.attachment_mime_type} size={msg.attachment_size} name={msg.attachment_name} />
        <div className="flex gap-3 flex-wrap">
          <a href={mediaUrl} target="_blank" rel="noreferrer" className="text-xs text-blue-600 hover:underline">
            Abrir
          </a>
          <DlButton url={dlUrl} name={dlName} label={`Baixar${ext ? ' ' + ext : ''}`} />
        </div>
      </div>
    </div>
  );
};

// ─── Message detail modal ────────────────────────────────────────────────────

const MessageModal: React.FC<{ msg: GotalkMessage; onClose: () => void }> = ({ msg, onClose }) => {
  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  const hasMedia = !!(msg.attachment_url || msg.attachment_name);
  const type = msg.message_type?.toUpperCase();

  return (
    <div
      className="fixed inset-0 z-[9000] flex items-center justify-center p-4"
      onClick={e => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
      <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] flex flex-col overflow-hidden animate-fade-in">
        <div className="bg-moss-800 px-5 py-4 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
            </div>
            <div>
              <p className="text-white font-bold text-sm leading-tight">
                {msg.client_name || msg.contact_name || msg.phone_number || '—'}
              </p>
              <p className="text-white/60 text-xs">{fmtDateLong(msg.sent_at)}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-colors"
          >
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="overflow-y-auto flex-1 p-5 space-y-4">
          <div className="flex flex-wrap gap-2">
            <DirBadge dir={msg.direction} />
            <TypeBadge type={msg.message_type} />
            {msg.read_at && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-green-100 text-green-700">✓ Lida</span>
            )}
          </div>

          <div className="bg-gray-50 rounded-xl border border-gray-200 divide-y divide-gray-100 text-sm">
            {([
              { label: 'Telefone',         value: msg.phone_number },
              { label: 'Contato / Cliente', value: msg.client_name || msg.contact_name },
              { label: 'Operador',          value: msg.operator_name },
              { label: 'Departamento',      value: msg.department },
              { label: 'Leitura',           value: msg.read_at ? fmtDate(msg.read_at) : 'Não lida' },
            ] as { label: string; value: string | null | undefined }[]).filter(r => r.value).map(({ label, value }) => (
              <div key={label} className="flex px-4 py-2.5 gap-3">
                <span className="text-xs text-gray-400 font-semibold w-32 flex-shrink-0">{label}</span>
                <span className="text-xs text-gray-700 break-words">{value}</span>
              </div>
            ))}
          </div>

          {hasMedia && (
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-3">Mídia / Anexo</p>
              <MediaViewer msg={msg} />
            </div>
          )}

          {(type === 'TEXT' || type === 'HSM' || type === 'TEMPLATE') && msg.body && (
            <div className="bg-gray-50 border border-gray-200 rounded-xl p-4">
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider mb-2">Conteúdo</p>
              <p className="text-sm text-gray-800 whitespace-pre-wrap leading-relaxed">{msg.body}</p>
            </div>
          )}

          {type === 'AUDIO' && !hasMedia && msg.audio_transcript && (
            <div className="bg-purple-50 border border-purple-200 rounded-xl p-4">
              <p className="text-[10px] font-bold text-purple-500 uppercase tracking-wider mb-2">Transcrição</p>
              <p className="text-sm text-gray-800 italic leading-relaxed">{msg.audio_transcript}</p>
            </div>
          )}

          {!hasMedia && !msg.body && !msg.audio_transcript && (
            <div className="text-center py-6 text-gray-400 text-sm">Sem conteúdo disponível para esta mensagem.</div>
          )}
        </div>

        <div className="border-t border-gray-100 px-5 py-3 flex justify-end bg-gray-50 flex-shrink-0">
          <button
            onClick={onClose}
            className="px-5 py-2 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};

// ─── Phone history modal ─────────────────────────────────────────────────────

const PhoneHistoryModal: React.FC<{ phone: string; onClose: () => void }> = ({ phone, onClose }) => {
  const [messages, setMessages] = useState<GotalkMessage[]>([]);
  const [total, setTotal]       = useState(0);
  const [page, setPage]         = useState(0);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState<string | null>(null);
  const [detailMsg, setDetailMsg] = useState<GotalkMessage | null>(null);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onClose]);

  const fetchPage = useCallback(async (pg: number) => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        limit:  String(PHONE_PAGE_SIZE),
        offset: String(pg * PHONE_PAGE_SIZE),
      });
      const res = await api.get<MessagesResponse>(
        `/api/gotalk/messages/by-phone/${encodeURIComponent(phone)}?${params}`,
      );
      setMessages(res.data);
      setTotal(res.total);
    } catch (e: unknown) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, [phone]);

  useEffect(() => { fetchPage(0); }, [fetchPage]);

  const totalPages = Math.ceil(total / PHONE_PAGE_SIZE);

  return (
    <>
      {detailMsg && <MessageModal msg={detailMsg} onClose={() => setDetailMsg(null)} />}
      <div
        className="fixed inset-0 z-[8900] flex items-center justify-center p-4"
        onClick={e => { if (e.target === e.currentTarget) onClose(); }}
      >
        <div className="absolute inset-0 bg-black/50 backdrop-blur-sm" />
        <div className="relative bg-white rounded-2xl shadow-2xl w-full max-w-3xl max-h-[92vh] flex flex-col overflow-hidden animate-fade-in">
          {/* Header */}
          <div className="bg-moss-800 px-5 py-4 flex items-center justify-between flex-shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-full bg-white/10 flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </div>
              <div>
                <p className="text-white font-bold text-sm leading-tight">Histórico do número</p>
                <p className="text-white/80 text-xs font-mono">{phone}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-white/60 text-xs">{total.toLocaleString('pt-BR')} mensagem{total !== 1 ? 's' : ''}</span>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-full flex items-center justify-center text-white/60 hover:text-white hover:bg-white/10 transition-colors"
              >
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>

          {/* Body */}
          <div className="overflow-y-auto flex-1 p-4 space-y-3">
            {loading && (
              <div className="flex items-center justify-center py-10">
                <svg className="animate-spin w-6 h-6 text-moss-600" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
              </div>
            )}

            {error && (
              <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-3 text-sm text-red-700">{error}</div>
            )}

            {!loading && !error && messages.length === 0 && (
              <div className="text-center py-12 text-gray-400 text-sm">
                Nenhuma mensagem encontrada para este número.
              </div>
            )}

            {!loading && messages.map(msg => {
              const hasMedia = !!(msg.attachment_url || msg.attachment_name);
              const isOut    = msg.direction === 'OUT';
              return (
                <div key={msg.id} className={`flex ${isOut ? 'justify-end' : 'justify-start'}`}>
                  <div className={`rounded-2xl border shadow-sm max-w-[85%] overflow-hidden ${isOut ? 'bg-moss-50 border-moss-200' : 'bg-white border-gray-200'}`}>
                    {/* Card header */}
                    <div className={`px-3 py-2 flex items-center justify-between gap-4 border-b ${isOut ? 'border-moss-200 bg-moss-100/40' : 'border-gray-100 bg-gray-50'}`}>
                      <div className="flex items-center gap-2 min-w-0">
                        <DirBadge dir={msg.direction} />
                        <TypeBadge type={msg.message_type} />
                        {msg.operator_name && (
                          <span className="text-[10px] text-gray-500 truncate max-w-[120px]" title={msg.operator_name}>
                            👤 {msg.operator_name}
                          </span>
                        )}
                      </div>
                      <div className="flex items-center gap-2 flex-shrink-0">
                        <span className="text-[10px] text-gray-400 font-mono whitespace-nowrap">{fmtDate(msg.sent_at)}</span>
                        <button
                          onClick={() => setDetailMsg(msg)}
                          title="Ver detalhes"
                          className="w-6 h-6 flex items-center justify-center rounded bg-moss-50 hover:bg-moss-100 text-moss-700 transition-colors flex-shrink-0"
                        >
                          <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                          </svg>
                        </button>
                      </div>
                    </div>
                    {/* Card body */}
                    <div className="px-3 py-2.5 space-y-1.5">
                      {hasMedia && <MediaViewer msg={msg} compact />}
                      {msg.body && (
                        <p className="text-sm text-gray-800 whitespace-pre-wrap break-words leading-relaxed">
                          {msg.body}
                        </p>
                      )}
                      {!hasMedia && !msg.body && (
                        <p className="text-xs text-gray-400 italic">Sem conteúdo</p>
                      )}
                      {msg.department && (
                        <p className="text-[10px] text-gray-400">Depto: {msg.department}</p>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Footer / Pagination */}
          <div className="border-t border-gray-100 px-5 py-3 flex items-center justify-between bg-gray-50 flex-shrink-0">
            <span className="text-xs text-gray-500">
              {total > 0
                ? `${page * PHONE_PAGE_SIZE + 1}–${Math.min((page + 1) * PHONE_PAGE_SIZE, total)} de ${total.toLocaleString('pt-BR')}`
                : '0 resultados'}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => { const p = Math.max(0, page - 1); setPage(p); fetchPage(p); }}
                disabled={page === 0 || loading}
                className="px-3 py-1.5 rounded-lg border border-gray-300 text-xs font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                ← Anterior
              </button>
              <span className="text-xs text-gray-600 min-w-[60px] text-center">
                {totalPages > 0 ? `${page + 1} / ${totalPages}` : '—'}
              </span>
              <button
                onClick={() => { const p = Math.min(totalPages - 1, page + 1); setPage(p); fetchPage(p); }}
                disabled={page >= totalPages - 1 || loading}
                className="px-3 py-1.5 rounded-lg border border-gray-300 text-xs font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed"
              >
                Próxima →
              </button>
              <button
                onClick={onClose}
                className="px-4 py-1.5 rounded-lg border border-gray-300 text-xs font-medium text-gray-700 bg-white hover:bg-gray-50 ml-2"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

// ─── Chatbot menus section ───────────────────────────────────────────────────

function renderMenuOptions(options: ChatbotMenuOption[], depth = 0): React.ReactNode {
  if (!options || options.length === 0) return null;
  return (
    <ul className={`space-y-1 ${depth > 0 ? 'ml-4 mt-1' : ''}`}>
      {options.map((opt, i) => {
        const subOpts: ChatbotMenuOption[] = opt.options ?? opt.items ?? [];
        return (
          <li key={opt._id ?? i} className="rounded-lg overflow-hidden">
            <div className={`flex items-start gap-2 px-3 py-2 rounded-lg border ${depth === 0 ? 'bg-green-50 border-green-200' : 'bg-gray-50 border-gray-200'}`}>
              <span className={`flex-shrink-0 w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-bold ${depth === 0 ? 'bg-green-600 text-white' : 'bg-gray-400 text-white'}`}>
                {i + 1}
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-gray-800">{opt.name ?? opt.title ?? `Opção ${i + 1}`}</p>
                {opt.description && (
                  <p className="text-xs text-gray-500 mt-0.5">{opt.description}</p>
                )}
                {opt.action && (
                  <span className="inline-block mt-0.5 text-[10px] bg-blue-50 border border-blue-200 text-blue-700 rounded px-1.5 py-0.5">
                    {opt.action}
                  </span>
                )}
              </div>
            </div>
            {subOpts.length > 0 && renderMenuOptions(subOpts, depth + 1)}
          </li>
        );
      })}
    </ul>
  );
}

// ─── Attendances section (standalone — unit filter) ──────────────────────────

const AttendancesSection: React.FC = () => {
  const [open, setOpen] = useState(false);
  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
      <button
        onClick={() => setOpen(o => !o)}
        className="w-full flex items-center justify-between px-4 py-3 text-sm font-semibold text-gray-700 hover:bg-gray-50 transition-colors"
      >
        <span className="flex items-center gap-2">
          <svg className="w-4 h-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
          Histórico de Atendimentos
        </span>
        <svg
          className={`w-4 h-4 text-gray-400 transition-transform ${open ? 'rotate-180' : ''}`}
          fill="none" viewBox="0 0 24 24" stroke="currentColor"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      {open && (
        <div className="h-[600px] border-t border-gray-200">
          <GotalkAttendanceViewer showUnitFilter title="Histórico de Atendimentos GoTalk" />
        </div>
      )}
    </div>
  );
};

// ─── Channels section ────────────────────────────────────────────────────────

const BLANK_FORM = { name: '', phone: '', unitId: '', isPrimary: false, isActive: true, notes: '' };

const ChannelsSection: React.FC = () => {
  const [open, setOpen]         = useState(false);
  const [channels, setChannels] = useState<GotalkChannel[]>([]);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState<string | null>(null);
  const [fetched, setFetched]   = useState(false);

  const [showForm, setShowForm]       = useState(false);
  const [form, setForm]               = useState(BLANK_FORM);
  const [saving, setSaving]           = useState(false);
  const [saveError, setSaveError]     = useState<string | null>(null);

  const [discovering, setDiscovering]     = useState(false);
  const [scanning, setScanning]           = useState(false);
  const [discoverMsg, setDiscoverMsg]     = useState<{ text: string; ok: boolean } | null>(null);
  const [discoverSuggestion, setDiscoverSuggestion] = useState<{
    suggestedName: string; suggestedPhone: string | null
  } | null>(null);
  const [scanSuggestions, setScanSuggestions] = useState<Array<{ name: string; phone: string | null }>>([]);

  const [editingId, setEditingId]         = useState<string | null>(null);
  const [editForm, setEditForm]           = useState<{ name: string; phone: string; unit_id: string; notes: string; is_primary: boolean; is_active: boolean }>({ name: '', phone: '', unit_id: '', notes: '', is_primary: false, is_active: true });
  const [editSaving, setEditSaving]       = useState(false);
  const [editError, setEditError]         = useState<string | null>(null);

  const [units, setUnits]                 = useState<Array<{ id: string; nome_fantasia: string }>>([]);
  const [unitsLoaded, setUnitsLoaded]     = useState(false);

  const [deletingId, setDeletingId]   = useState<string | null>(null);
  const [togglingId, setTogglingId]   = useState<string | null>(null);

  const loadUnits = async () => {
    if (unitsLoaded) return;
    try {
      const res = await api.get<{ units?: Array<{ id: string; nome_fantasia: string }>, data?: Array<{ id: string; nome_fantasia: string }> }>('/api/units');
      const list = res.units ?? res.data ?? (Array.isArray(res) ? (res as unknown as Array<{ id: string; nome_fantasia: string }>) : []);
      setUnits(list);
      setUnitsLoaded(true);
    } catch (_) {}
  };

  const fetchChannels = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.get<ChannelsResponse>('/api/gotalk/channels');
      setChannels(res.channels ?? []);
      setFetched(true);
    } catch (e: unknown) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = () => {
    const next = !open;
    setOpen(next);
    if (next && !fetched) fetchChannels();
  };

  const handleDiscover = async () => {
    setDiscovering(true);
    setDiscoverMsg(null);
    setDiscoverSuggestion(null);
    try {
      const res = await api.post<{
        found: boolean; alreadyRegistered: boolean; existingChannel: GotalkChannel | null;
        suggestedName?: string; suggestedPhone?: string | null; message: string;
      }>('/api/gotalk/channels/discover', {});
      setDiscoverMsg({ text: res.message, ok: true });
      if (res.alreadyRegistered) {
        await fetchChannels();
      } else if (res.found && !res.alreadyRegistered) {
        // Show suggestion card — admin must confirm by filling the form
        setDiscoverSuggestion({ suggestedName: res.suggestedName ?? 'Canal Principal', suggestedPhone: res.suggestedPhone ?? null });
        setShowForm(true);
        setForm(f => ({
          ...f,
          name: res.suggestedName ?? 'Canal Principal',
          phone: res.suggestedPhone ?? '',
          isPrimary: true,
        }));
      }
    } catch (e: unknown) {
      setDiscoverMsg({ text: errMsg(e), ok: false });
    } finally {
      setDiscovering(false);
    }
  };

  const handleScanAll = async () => {
    setScanning(true);
    setDiscoverMsg(null);
    setScanSuggestions([]);
    try {
      const res = await api.post<{
        message: string; backfilled: number; created: number; suggestions: Array<{ name: string; phone: string | null }>;
        channels: GotalkChannel[]; total: number;
      }>('/api/gotalk/channels/scan-all', {});
      setDiscoverMsg({ text: res.message, ok: true });
      if (res.suggestions?.length) setScanSuggestions(res.suggestions);
      if (res.channels?.length) {
        setChannels(res.channels);
        setFetched(true);
      } else {
        await fetchChannels();
      }
    } catch (e: unknown) {
      setDiscoverMsg({ text: errMsg(e), ok: false });
    } finally {
      setScanning(false);
    }
  };

  const handleAdd = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaveError(null);
    if (!form.name.trim()) {
      setSaveError('O nome do canal é obrigatório.');
      return;
    }
    setSaving(true);
    try {
      await api.post('/api/gotalk/channels', {
        name:         form.name.trim(),
        phone_number: form.phone.trim() || null,
        unit_id:      form.unitId || null,
        is_primary:   form.isPrimary,
        is_active:    form.isActive,
        notes:        form.notes.trim() || null,
      });
      setForm(BLANK_FORM);
      setShowForm(false);
      setDiscoverMsg(null);
      await fetchChannels();
    } catch (e: unknown) {
      setSaveError(errMsg(e));
    } finally {
      setSaving(false);
    }
  };

  const handleStartEdit = (ch: GotalkChannel) => {
    loadUnits();
    setEditingId(ch.id);
    setEditForm({
      name:       ch.name,
      phone:      ch.phone_number ?? '',
      unit_id:    ch.unit_id ?? '',
      notes:      ch.notes ?? '',
      is_primary: ch.is_primary,
      is_active:  ch.is_active,
    });
    setEditError(null);
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingId) return;
    setEditSaving(true);
    setEditError(null);
    try {
      const updated = await api.patch<{ channel: GotalkChannel }>(`/api/gotalk/channels/${editingId}`, {
        name:         editForm.name.trim(),
        phone_number: editForm.phone.trim() || null,
        unit_id:      editForm.unit_id || null,
        notes:        editForm.notes.trim() || null,
        is_primary:   editForm.is_primary,
        is_active:    editForm.is_active,
      });
      setChannels(prev => prev.map(c => c.id === editingId ? { ...c, ...updated.channel } : c));
      setEditingId(null);
    } catch (e: unknown) {
      setEditError(errMsg(e));
    } finally {
      setEditSaving(false);
    }
  };

  const handleToggleActive = async (ch: GotalkChannel) => {
    setTogglingId(ch.id);
    try {
      await api.patch(`/api/gotalk/channels/${ch.id}`, { is_active: !ch.is_active });
      setChannels(prev => prev.map(c => c.id === ch.id ? { ...c, is_active: !c.is_active } : c));
    } catch (e: unknown) {
      setError(errMsg(e));
    } finally {
      setTogglingId(null);
    }
  };

  const handleDelete = async (ch: GotalkChannel) => {
    if (!confirm(`Remover o canal "${ch.name}"? Esta ação não pode ser desfeita.`)) return;
    setDeletingId(ch.id);
    try {
      await api.delete(`/api/gotalk/channels/${ch.id}`);
      setChannels(prev => prev.filter(c => c.id !== ch.id));
    } catch (e: unknown) {
      setError(errMsg(e));
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
      {/* Header */}
      <button
        onClick={handleToggle}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-50 border border-blue-200 flex items-center justify-center flex-shrink-0">
            <svg className="w-4 h-4 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
          </div>
          <div className="text-left">
            <p className="text-sm font-semibold text-gray-800">Canais Configurados</p>
            <p className="text-xs text-gray-500">Canais WhatsApp vinculados à conta GoTalk</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {fetched && !loading && (
            <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
              {channels.length} canal{channels.length !== 1 ? 'is' : ''}
            </span>
          )}
          <svg
            className={`w-4 h-4 text-gray-400 transition-transform ${open ? 'rotate-180' : ''}`}
            fill="none" viewBox="0 0 24 24" stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </button>

      {open && (
        <div className="border-t border-gray-100 px-4 py-4 space-y-4">
          {/* Loading */}
          {loading && (
            <div className="flex items-center gap-2 text-sm text-gray-500 py-4 justify-center">
              <svg className="animate-spin w-4 h-4 text-blue-600" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Carregando canais...
            </div>
          )}

          {/* Error banner */}
          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-3 text-sm text-red-700">
              {error}
            </div>
          )}

          {/* Channels table */}
          {!loading && channels.length === 0 && fetched && (
            <div className="text-center py-4 text-gray-400 text-sm">
              Nenhum canal cadastrado. Use o botão abaixo para adicionar.
            </div>
          )}

          {!loading && channels.length > 0 && (
            <div className="overflow-x-auto rounded-lg border border-gray-200">
              <table className="min-w-full divide-y divide-gray-200 text-sm data-grid-typography">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Nome</th>
                    <th className="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Telefone</th>
                    <th className="px-4 py-2 text-left text-xs font-semibold text-gray-500 uppercase">Unidade</th>
                    <th className="px-4 py-2 text-center text-xs font-semibold text-gray-500 uppercase">Tipo</th>
                    <th className="px-4 py-2 text-center text-xs font-semibold text-gray-500 uppercase">Ativo</th>
                    <th className="px-4 py-2 text-center text-xs font-semibold text-gray-500 uppercase w-20">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100 bg-white">
                  {channels.map(ch => (
                    <React.Fragment key={ch.id}>
                      <tr className={`hover:bg-gray-50 transition-colors ${!ch.is_active ? 'opacity-50' : ''}`}>
                        <td className="px-4 py-2">
                          <span className="font-medium text-gray-800 text-sm">{ch.name}</span>
                          {ch.notes && <span className="block text-xs text-gray-400 truncate max-w-[180px]">{ch.notes}</span>}
                        </td>
                        <td className="px-4 py-2 text-xs font-mono text-gray-600">{ch.phone_number || '—'}</td>
                        <td className="px-4 py-2 text-xs text-gray-600">{ch.unit_name || '—'}</td>
                        <td className="px-4 py-2 text-center">
                          {ch.is_primary ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-blue-100 text-blue-700">Principal</span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-semibold bg-gray-100 text-gray-500">Secundário</span>
                          )}
                        </td>
                        <td className="px-4 py-2 text-center">
                          <button
                            onClick={() => handleToggleActive(ch)}
                            disabled={togglingId === ch.id}
                            title={ch.is_active ? 'Desativar canal' : 'Ativar canal'}
                            className={`relative inline-flex h-5 w-9 items-center rounded-full transition-colors focus:outline-none ${ch.is_active ? 'bg-green-500' : 'bg-gray-300'} ${togglingId === ch.id ? 'opacity-50' : ''}`}
                          >
                            <span className={`inline-block h-3.5 w-3.5 transform rounded-full bg-white shadow transition-transform ${ch.is_active ? 'translate-x-4' : 'translate-x-1'}`} />
                          </button>
                        </td>
                        <td className="px-4 py-2 text-center">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => editingId === ch.id ? setEditingId(null) : handleStartEdit(ch)}
                              title="Editar canal"
                              className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-blue-50 text-blue-600 hover:bg-blue-100 transition-colors"
                            >
                              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                              </svg>
                            </button>
                            <button
                              onClick={() => handleDelete(ch)}
                              disabled={deletingId === ch.id}
                              title="Remover canal"
                              className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-red-50 text-red-600 hover:bg-red-100 transition-colors disabled:opacity-40"
                            >
                              {deletingId === ch.id ? (
                                <svg className="animate-spin w-3.5 h-3.5" fill="none" viewBox="0 0 24 24">
                                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                                </svg>
                              ) : (
                                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                                </svg>
                              )}
                            </button>
                          </div>
                        </td>
                      </tr>
                      {/* Inline edit row */}
                      {editingId === ch.id && (
                        <tr>
                          <td colSpan={6} className="px-4 py-3 bg-blue-50 border-t border-blue-100">
                            <form onSubmit={handleSaveEdit} className="space-y-2">
                              <p className="text-xs font-semibold text-blue-700 mb-2">Editar canal</p>
                              {editError && <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded px-2 py-1">{editError}</div>}
                              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                                <div>
                                  <label className="block text-xs font-medium text-gray-600 mb-1">Nome *</label>
                                  <input type="text" value={editForm.name} onChange={e => setEditForm(f => ({ ...f, name: e.target.value }))}
                                    className="w-full rounded border border-gray-300 px-2 py-1 text-sm focus:ring-1 focus:ring-blue-400 outline-none" required />
                                </div>
                                <div>
                                  <label className="block text-xs font-medium text-gray-600 mb-1">Telefone</label>
                                  <input type="text" value={editForm.phone} onChange={e => setEditForm(f => ({ ...f, phone: e.target.value }))}
                                    placeholder="Ex: 11 99999-0000"
                                    className="w-full rounded border border-gray-300 px-2 py-1 text-sm focus:ring-1 focus:ring-blue-400 outline-none" />
                                </div>
                                <div>
                                  <label className="block text-xs font-medium text-gray-600 mb-1">Unidade</label>
                                  <select value={editForm.unit_id} onChange={e => setEditForm(f => ({ ...f, unit_id: e.target.value }))}
                                    className="w-full rounded border border-gray-300 px-2 py-1 text-sm focus:ring-1 focus:ring-blue-400 outline-none bg-white">
                                    <option value="">— Sem unidade —</option>
                                    {units.map(u => <option key={u.id} value={u.id}>{u.nome_fantasia}</option>)}
                                  </select>
                                </div>
                                <div>
                                  <label className="block text-xs font-medium text-gray-600 mb-1">Notas</label>
                                  <input type="text" value={editForm.notes} onChange={e => setEditForm(f => ({ ...f, notes: e.target.value }))}
                                    className="w-full rounded border border-gray-300 px-2 py-1 text-sm focus:ring-1 focus:ring-blue-400 outline-none" />
                                </div>
                              </div>
                              <div className="flex items-center gap-4 pt-1">
                                <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                                  <input type="checkbox" checked={editForm.is_primary} onChange={e => setEditForm(f => ({ ...f, is_primary: e.target.checked }))} className="rounded" />
                                  Canal principal
                                </label>
                                <label className="flex items-center gap-1.5 text-xs cursor-pointer">
                                  <input type="checkbox" checked={editForm.is_active} onChange={e => setEditForm(f => ({ ...f, is_active: e.target.checked }))} className="rounded" />
                                  Ativo
                                </label>
                                <div className="flex-1" />
                                <button type="submit" disabled={editSaving}
                                  className="px-3 py-1 rounded bg-blue-600 text-white text-xs font-medium hover:bg-blue-700 disabled:opacity-50 transition-colors">
                                  {editSaving ? 'Salvando…' : 'Salvar'}
                                </button>
                                <button type="button" onClick={() => setEditingId(null)}
                                  className="px-3 py-1 rounded border border-gray-300 text-xs text-gray-600 hover:bg-gray-100 transition-colors">
                                  Cancelar
                                </button>
                              </div>
                            </form>
                          </td>
                        </tr>
                      )}
                    </React.Fragment>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Discover message */}
          {discoverMsg && (
            <div className={`text-sm px-4 py-2 rounded-lg ${discoverMsg.ok ? 'bg-green-50 text-green-700 border border-green-200' : 'bg-red-50 text-red-700 border border-red-200'}`}>
              {discoverMsg.text}
            </div>
          )}

          {/* Scan-all suggestions (discovered channels not yet in DB) */}
          {scanSuggestions.length > 0 && (
            <div className="border border-amber-200 rounded-lg bg-amber-50 p-3 space-y-2">
              <p className="text-xs font-semibold text-amber-800">
                Canais descobertos não cadastrados — confirme para adicionar:
              </p>
              {scanSuggestions.map((sg, i) => (
                <div key={i} className="flex items-center justify-between gap-3 bg-white border border-amber-100 rounded px-3 py-2">
                  <div>
                    <span className="text-sm font-medium text-gray-800">{sg.name}</span>
                    {sg.phone && <span className="text-xs text-gray-500 ml-2 font-mono">{sg.phone}</span>}
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      setScanSuggestions(prev => prev.filter((_, j) => j !== i));
                      setShowForm(true);
                      setSaveError(null);
                      loadUnits();
                      setForm(f => ({ ...f, name: sg.name, phone: sg.phone ?? '', isPrimary: false }));
                    }}
                    className="text-xs px-3 py-1 rounded bg-blue-600 text-white hover:bg-blue-700 font-medium transition-colors flex-shrink-0"
                  >
                    Adicionar
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => setScanSuggestions([])}
                className="text-xs text-gray-400 hover:text-gray-600"
              >
                Dispensar sugestões
              </button>
            </div>
          )}

          {/* Add channel form */}
          {showForm && (
            <form onSubmit={handleAdd} className="border border-gray-200 rounded-lg p-4 bg-gray-50 space-y-3">
              <p className="text-sm font-semibold text-gray-700">Adicionar canal</p>
              {saveError && (
                <div className="text-xs text-red-600 bg-red-50 border border-red-200 rounded px-3 py-2">{saveError}</div>
              )}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Nome do canal *</label>
                  <input
                    type="text"
                    value={form.name}
                    onChange={e => setForm(f => ({ ...f, name: e.target.value }))}
                    placeholder="Ex: Invicta Principal"
                    className="w-full rounded border border-gray-300 px-3 py-1.5 text-sm focus:ring-1 focus:ring-blue-500 outline-none"
                    required
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Telefone (WhatsApp)</label>
                  <input
                    type="text"
                    value={form.phone}
                    onChange={e => setForm(f => ({ ...f, phone: e.target.value }))}
                    placeholder="Ex: 11 99999-0000"
                    className="w-full rounded border border-gray-300 px-3 py-1.5 text-sm focus:ring-1 focus:ring-blue-500 outline-none"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-gray-600 mb-1">Unidade</label>
                  <select
                    value={form.unitId}
                    onChange={e => setForm(f => ({ ...f, unitId: e.target.value }))}
                    className="w-full rounded border border-gray-300 px-3 py-1.5 text-sm focus:ring-1 focus:ring-blue-500 outline-none bg-white"
                  >
                    <option value="">— Sem unidade —</option>
                    {units.map(u => <option key={u.id} value={u.id}>{u.nome_fantasia}</option>)}
                  </select>
                </div>
              </div>
              <div className="rounded border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-700">
                Canal primário: o identificador GoTalk é obtido automaticamente via "Detectar canal primário".<br />
                Canais secundários ficam pendentes de sincronização até usar o botão "Sincronizar todos" ou "Detectar canal primário".
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Notas (opcional)</label>
                <input
                  type="text"
                  value={form.notes}
                  onChange={e => setForm(f => ({ ...f, notes: e.target.value }))}
                  placeholder="Ex: Canal de atendimento SP"
                  className="w-full rounded border border-gray-300 px-3 py-1.5 text-sm focus:ring-1 focus:ring-blue-500 outline-none"
                />
              </div>
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.isPrimary}
                    onChange={e => setForm(f => ({ ...f, isPrimary: e.target.checked }))}
                    className="rounded"
                  />
                  <span className="text-xs text-gray-600">Canal principal</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={form.isActive}
                    onChange={e => setForm(f => ({ ...f, isActive: e.target.checked }))}
                    className="rounded"
                  />
                  <span className="text-xs text-gray-600">Ativo</span>
                </label>
              </div>
              <div className="flex items-center gap-2 pt-1">
                <button
                  type="submit"
                  disabled={saving}
                  className="px-4 py-1.5 rounded bg-blue-600 hover:bg-blue-700 text-white text-sm font-medium disabled:opacity-50 transition-colors"
                >
                  {saving ? 'Salvando…' : 'Salvar canal'}
                </button>
                <button
                  type="button"
                  onClick={() => { setShowForm(false); setSaveError(null); setForm(BLANK_FORM); }}
                  className="px-4 py-1.5 rounded border border-gray-300 text-sm text-gray-600 hover:bg-gray-100 transition-colors"
                >
                  Cancelar
                </button>
              </div>
            </form>
          )}

          {/* Actions row */}
          <div className="flex items-center gap-2 flex-wrap">
            {!showForm && (
              <button
                onClick={() => { setShowForm(true); setSaveError(null); loadUnits(); }}
                className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg bg-blue-600 text-white hover:bg-blue-700 font-medium transition-colors"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                </svg>
                Adicionar canal
              </button>
            )}
            <button
              onClick={handleDiscover}
              disabled={discovering}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50 font-medium transition-colors disabled:opacity-50"
            >
              {discovering ? (
                <svg className="animate-spin w-3.5 h-3.5" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
              ) : (
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              )}
              Detectar canal primário
            </button>
            <button
              onClick={handleScanAll}
              disabled={scanning}
              className="flex items-center gap-1.5 text-xs px-3 py-1.5 rounded-lg border border-gray-300 text-gray-600 hover:bg-gray-50 font-medium transition-colors disabled:opacity-50"
            >
              {scanning ? (
                <svg className="animate-spin w-3.5 h-3.5" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                </svg>
              ) : (
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              )}
              Sincronizar todos
            </button>
            <button
              onClick={fetchChannels}
              disabled={loading}
              className="flex items-center gap-1.5 text-xs text-gray-400 hover:text-gray-600 transition-colors"
            >
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Recarregar
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const ChatbotMenusSection: React.FC = () => {
  const [open, setOpen]               = useState(false);
  const [menus, setMenus]             = useState<ChatbotMenu[]>([]);
  const [loading, setLoading]         = useState(false);
  const [error, setError]             = useState<string | null>(null);
  const [fetched, setFetched]         = useState(false);
  const [expandedMenu, setExpandedMenu] = useState<string | null>(null);

  const fetchMenus = async () => {
    if (fetched && menus.length > 0) return;
    setLoading(true);
    setError(null);
    try {
      const raw = await api.get<ChatbotMenu[] | ChatbotMenusResponse>('/api/gotalk/chatbot-menus');
      let list: ChatbotMenu[];
      if (Array.isArray(raw)) {
        list = raw;
      } else {
        const typed = raw as ChatbotMenusResponse;
        list = Array.isArray(typed.menus) ? typed.menus
             : Array.isArray(typed.data)  ? typed.data
             : [];
      }
      setMenus(list);
      setFetched(true);
    } catch (e: unknown) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = () => {
    const next = !open;
    setOpen(next);
    if (next) fetchMenus();
  };

  return (
    <div className="bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
      <button
        onClick={handleToggle}
        className="w-full flex items-center justify-between px-4 py-3 hover:bg-gray-50 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-green-50 border border-green-200 flex items-center justify-center flex-shrink-0">
            <svg className="w-4 h-4 text-green-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
            </svg>
          </div>
          <div className="text-left">
            <p className="text-sm font-semibold text-gray-800">Menus do Chatbot</p>
            <p className="text-xs text-gray-500">Menus configurados no canal GoTalk</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          {fetched && !loading && (
            <span className="text-xs text-gray-400 bg-gray-100 px-2 py-0.5 rounded-full">
              {menus.length} menu{menus.length !== 1 ? 's' : ''}
            </span>
          )}
          <svg
            className={`w-4 h-4 text-gray-400 transition-transform ${open ? 'rotate-180' : ''}`}
            fill="none"
            viewBox="0 0 24 24"
            stroke="currentColor"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </div>
      </button>

      {open && (
        <div className="border-t border-gray-100 px-4 py-4">
          {loading && (
            <div className="flex items-center gap-2 text-sm text-gray-500 py-4 justify-center">
              <svg className="animate-spin w-4 h-4 text-moss-600" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
              Carregando menus...
            </div>
          )}

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg px-4 py-3 text-sm text-red-700 flex items-start gap-2">
              <svg className="w-4 h-4 flex-shrink-0 mt-0.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              <div>
                <p className="font-medium">Erro ao carregar menus</p>
                <p className="text-xs mt-0.5 opacity-80">{error}</p>
                <button
                  onClick={() => { setFetched(false); fetchMenus(); }}
                  className="mt-2 text-xs text-red-700 underline hover:text-red-900"
                >
                  Tentar novamente
                </button>
              </div>
            </div>
          )}

          {!loading && !error && menus.length === 0 && fetched && (
            <div className="text-center py-8 text-gray-400 text-sm">
              <svg className="w-8 h-8 mx-auto mb-2 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
              </svg>
              Nenhum menu configurado neste canal.
            </div>
          )}

          {!loading && !error && menus.length > 0 && (
            <div className="space-y-3">
              {menus.map((menu, idx) => {
                const menuId     = menu._id ?? String(idx);
                const isExpanded = expandedMenu === menuId;
                const options: ChatbotMenuOption[] = menu.options ?? menu.items ?? [];
                return (
                  <div key={menuId} className="rounded-xl border border-green-200 overflow-hidden">
                    <button
                      onClick={() => setExpandedMenu(isExpanded ? null : menuId)}
                      className="w-full flex items-center justify-between px-4 py-3 bg-green-600 hover:bg-green-700 transition-colors text-left"
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <span className="text-white font-bold text-sm truncate">
                          {menu.name ?? menu.title ?? `Menu ${idx + 1}`}
                        </span>
                        {options.length > 0 && (
                          <span className="text-green-100 text-[10px] bg-green-700/60 px-1.5 py-0.5 rounded-full flex-shrink-0">
                            {options.length} opç{options.length !== 1 ? 'ões' : 'ão'}
                          </span>
                        )}
                      </div>
                      <svg
                        className={`w-4 h-4 text-white/70 flex-shrink-0 transition-transform ${isExpanded ? 'rotate-180' : ''}`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
                      </svg>
                    </button>
                    {menu.description && (
                      <div className="px-4 py-2 bg-green-50 border-b border-green-200 text-xs text-green-800">
                        {menu.description}
                      </div>
                    )}
                    {isExpanded && options.length > 0 && (
                      <div className="px-4 py-3 bg-white">{renderMenuOptions(options)}</div>
                    )}
                    {isExpanded && options.length === 0 && (
                      <div className="px-4 py-3 text-sm text-gray-400 italic">Sem opções configuradas.</div>
                    )}
                  </div>
                );
              })}
              <button
                onClick={() => { setFetched(false); fetchMenus(); }}
                className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-gray-700 mt-1"
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                Recarregar menus
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// ─── Sort icon ───────────────────────────────────────────────────────────────

const SortIcon: React.FC<{ col: SortCol; active: SortCol; dir: SortDir }> = ({ col, active, dir }) => {
  if (col !== active) return <span className="text-gray-300 ml-1 text-xs">⇅</span>;
  return <span className="text-moss-600 ml-1 text-xs">{dir === 'asc' ? '↑' : '↓'}</span>;
};

// ─── Chip ────────────────────────────────────────────────────────────────────

const CHIP_COLORS: Record<string, string> = {
  moss:   'bg-moss-100 text-moss-800',
  blue:   'bg-blue-100 text-blue-800',
  indigo: 'bg-indigo-100 text-indigo-800',
  orange: 'bg-orange-100 text-orange-800',
};

const Chip: React.FC<{ label: string; color: string; onRemove: () => void }> = ({ label, color, onRemove }) => (
  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${CHIP_COLORS[color] ?? CHIP_COLORS.blue}`}>
    {label}
    <button onClick={onRemove} className="ml-0.5 hover:opacity-70 font-bold">×</button>
  </span>
);

// ─── Main component ──────────────────────────────────────────────────────────

const GotalkMessagesTab: React.FC = () => {
  const [messages, setMessages] = useState<GotalkMessage[]>([]);
  const [total, setTotal]       = useState(0);
  const [loading, setLoading]   = useState(false);
  const [error, setError]       = useState<string | null>(null);

  const [filterOperator,  setFilterOperator]  = useState('');
  const [filterPhone,     setFilterPhone]     = useState('');
  const [filterDirection, setFilterDirection] = useState('');
  const [filterContact,   setFilterContact]   = useState('');
  const [filterChannel,   setFilterChannel]   = useState('');
  const [filtersOpen,     setFiltersOpen]     = useState(false);

  const [sortCol, setSortCol] = useState<SortCol>('sent_at');
  const [sortDir, setSortDir] = useState<SortDir>('desc');

  const [operators, setOperators] = useState<string[]>([]);
  const [msgChannels, setMsgChannels] = useState<Array<{ id: string; name: string; phone_number: string | null }>>([]);
  const [page, setPage]           = useState(0);

  const [selectedMsg,   setSelectedMsg]   = useState<GotalkMessage | null>(null);
  const [selectedPhone, setSelectedPhone] = useState<string | null>(null);

  const debounceRef  = useRef<ReturnType<typeof setTimeout> | null>(null);
  const tableRef     = useRef<HTMLDivElement>(null);

  // Group by date (preserving DESC order from backend), sort within each group by contact then time ASC
  // Only activate when user has selected sent_at DESC — any other sort shows plain backend order
  const sortedMessages = useMemo(() => {
    if (sortCol !== 'sent_at' || sortDir !== 'desc') return messages;
    const groups = new Map<string, GotalkMessage[]>();
    for (const m of messages) {
      const key = m.sent_at ? new Date(m.sent_at).toDateString() : '_none';
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(m);
    }
    const result: GotalkMessage[] = [];
    for (const [, group] of groups) {
      group.sort((a, b) => {
        const nameA = (a.client_name || a.contact_name || a.phone_number || '').toLowerCase();
        const nameB = (b.client_name || b.contact_name || b.phone_number || '').toLowerCase();
        const cmp = nameA.localeCompare(nameB, 'pt-BR');
        if (cmp !== 0) return cmp;
        return new Date(a.sent_at).getTime() - new Date(b.sent_at).getTime();
      });
      result.push(...group);
    }
    return result;
  }, [messages, sortCol]);

  // Scroll table to top whenever new data loads
  useEffect(() => {
    if (!loading && sortedMessages.length > 0) {
      tableRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [sortedMessages, loading]);

  const fetchMessages = useCallback(async (
    op: string, ph: string, dir: string, ct: string, ch: string,
    sc: SortCol, sd: SortDir, pg: number,
  ) => {
    setLoading(true);
    setError(null);
    try {
      const params = new URLSearchParams({
        limit:    String(PAGE_SIZE),
        offset:   String(pg * PAGE_SIZE),
        sort_by:  sc,
        sort_dir: sd,
      });
      if (op)  params.set('operator',     op);
      if (ph)  params.set('phone',        ph);
      if (dir) params.set('direction',    dir);
      if (ct)  params.set('contact',      ct);
      if (ch)  params.set('channel_uuid', ch);

      const res = await api.get<MessagesResponse>(`/api/gotalk/messages/all?${params.toString()}`);
      setMessages(res.data);
      setTotal(res.total);
    } catch (e: unknown) {
      setError(errMsg(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    api.get<OperatorsResponse>('/api/gotalk/messages/operators')
      .then(r => setOperators(r.data ?? []))
      .catch(() => {});
    api.get<ChannelsResponse>('/api/gotalk/channels')
      .then(r => setMsgChannels(r.channels ?? []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      setPage(0);
      fetchMessages(filterOperator, filterPhone, filterDirection, filterContact, filterChannel, sortCol, sortDir, 0);
    }, 350);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [filterOperator, filterPhone, filterDirection, filterContact, filterChannel, sortCol, sortDir, fetchMessages]);

  useEffect(() => {
    fetchMessages(filterOperator, filterPhone, filterDirection, filterContact, filterChannel, sortCol, sortDir, page);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page]);

  useEffect(() => {
    if (page !== 0) return;
    const interval = setInterval(() => {
      fetchMessages(filterOperator, filterPhone, filterDirection, filterContact, filterChannel, sortCol, sortDir, 0);
    }, 60_000);
    return () => clearInterval(interval);
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterOperator, filterPhone, filterDirection, filterContact, filterChannel, sortCol, sortDir, fetchMessages, page]);

  const toggleSort = (col: SortCol) => {
    if (col === sortCol) {
      setSortDir(d => d === 'desc' ? 'asc' : 'desc');
    } else {
      setSortCol(col);
      setSortDir('desc');
    }
    setPage(0);
  };

  const totalPages = Math.ceil(total / PAGE_SIZE);
  const anyFilter  = filterOperator || filterPhone || filterDirection || filterContact || filterChannel;

  const truncate = (s: string | null, n = 70) => {
    if (!s) return '—';
    return s.length > n ? s.slice(0, n) + '…' : s;
  };

  const thCls = 'px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider cursor-pointer select-none hover:bg-gray-100 transition-colors';

  return (
    <>
      {selectedMsg   && <MessageModal msg={selectedMsg} onClose={() => setSelectedMsg(null)} />}
      {selectedPhone && <PhoneHistoryModal phone={selectedPhone} onClose={() => setSelectedPhone(null)} />}

      <div className="flex flex-col gap-4 h-full animate-fade-in">
        {/* Page header */}
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl font-bold text-gray-800">Mensagens GoTalk</h2>
            <p className="text-sm text-gray-500 mt-0.5">
              {total.toLocaleString('pt-BR')} mensagem{total !== 1 ? 's' : ''}
              {anyFilter ? ' (filtradas)' : ' no total'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFiltersOpen(o => !o)}
              className={`relative flex items-center gap-2 px-4 py-2 rounded-lg border text-sm font-medium transition-colors ${filtersOpen ? 'bg-moss-600 border-moss-600 text-white hover:bg-moss-700' : 'border-gray-300 text-gray-700 bg-white hover:bg-gray-50'}`}
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2a1 1 0 01-.293.707L13 13.414V19a1 1 0 01-.553.894l-4 2A1 1 0 017 21v-7.586L3.293 6.707A1 1 0 013 6V4z" />
              </svg>
              Filtros
              {anyFilter && (
                <span className="absolute -top-1.5 -right-1.5 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center">
                  {[filterChannel, filterOperator, filterContact, filterPhone, filterDirection].filter(Boolean).length}
                </span>
              )}
            </button>
            <button
              onClick={() => fetchMessages(filterOperator, filterPhone, filterDirection, filterContact, filterChannel, sortCol, sortDir, page)}
              className="flex items-center gap-2 px-4 py-2 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
              </svg>
              Atualizar
            </button>
          </div>
        </div>

        {/* Channels */}
        <ChannelsSection />

        {/* Chatbot menus */}
        <ChatbotMenusSection />

        {/* Standalone attendance history with unit filter */}
        <AttendancesSection />

        {/* Filters */}
        {filtersOpen && (
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm p-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            {msgChannels.length > 1 && (
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Canal</label>
                <select
                  value={filterChannel}
                  onChange={e => setFilterChannel(e.target.value)}
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none bg-white"
                >
                  <option value="">Todos os canais</option>
                  {msgChannels.map(ch => <option key={ch.id} value={ch.id}>{ch.name}{ch.phone_number ? ` (${ch.phone_number})` : ''}</option>)}
                </select>
              </div>
            )}
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Atendente / Operador</label>
              <select
                value={filterOperator}
                onChange={e => setFilterOperator(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none bg-white"
              >
                <option value="">Todos</option>
                {operators.map(op => <option key={op} value={op}>{op}</option>)}
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Contato / Cliente</label>
              <div className="relative">
                <input
                  type="text"
                  value={filterContact}
                  onChange={e => setFilterContact(e.target.value)}
                  placeholder="Nome do contato ou cliente"
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 pl-9 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none"
                />
                <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                </svg>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Telefone</label>
              <div className="relative">
                <input
                  type="text"
                  value={filterPhone}
                  onChange={e => setFilterPhone(e.target.value)}
                  placeholder="Ex: 11 98888-7777"
                  className="w-full rounded-lg border border-gray-300 px-3 py-2 pl-9 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none"
                />
                <svg className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" />
                </svg>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1 uppercase tracking-wide">Direção</label>
              <select
                value={filterDirection}
                onChange={e => setFilterDirection(e.target.value)}
                className="w-full rounded-lg border border-gray-300 px-3 py-2 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none bg-white"
              >
                <option value="">Entrada e Saída</option>
                <option value="IN">⬇ Entrada (recebidas)</option>
                <option value="OUT">⬆ Saída (enviadas)</option>
              </select>
            </div>
          </div>

          {anyFilter && (
            <div className="mt-3 flex flex-wrap items-center gap-2">
              <span className="text-xs text-gray-400">Filtros ativos:</span>
              {filterChannel   && <Chip label={`Canal: ${msgChannels.find(c => c.id === filterChannel)?.name ?? filterChannel}`} onRemove={() => setFilterChannel('')} color="moss" />}
              {filterOperator  && <Chip label={`Operador: ${filterOperator}`}  onRemove={() => setFilterOperator('')}  color="moss" />}
              {filterContact   && <Chip label={`Contato: ${filterContact}`}    onRemove={() => setFilterContact('')}   color="blue" />}
              {filterPhone     && <Chip label={`Tel: ${filterPhone}`}          onRemove={() => setFilterPhone('')}     color="indigo" />}
              {filterDirection && <Chip label={filterDirection === 'IN' ? 'Entrada' : 'Saída'} onRemove={() => setFilterDirection('')} color="orange" />}
              <button
                onClick={() => { setFilterOperator(''); setFilterContact(''); setFilterPhone(''); setFilterDirection(''); setFilterChannel(''); }}
                className="text-xs text-red-600 hover:text-red-800 font-medium ml-1"
              >
                Limpar tudo
              </button>
            </div>
          )}
        </div>
        )}

        {/* Active filter chips when filters are collapsed */}
        {!filtersOpen && anyFilter && (
          <div className="flex flex-wrap items-center gap-2 px-1">
            <span className="text-xs text-gray-400">Filtros ativos:</span>
            {filterChannel   && <Chip label={`Canal: ${msgChannels.find(c => c.id === filterChannel)?.name ?? filterChannel}`} onRemove={() => setFilterChannel('')} color="moss" />}
            {filterOperator  && <Chip label={`Operador: ${filterOperator}`}  onRemove={() => setFilterOperator('')}  color="moss" />}
            {filterContact   && <Chip label={`Contato: ${filterContact}`}    onRemove={() => setFilterContact('')}   color="blue" />}
            {filterPhone     && <Chip label={`Tel: ${filterPhone}`}          onRemove={() => setFilterPhone('')}     color="indigo" />}
            {filterDirection && <Chip label={filterDirection === 'IN' ? 'Entrada' : 'Saída'} onRemove={() => setFilterDirection('')} color="orange" />}
            <button
              onClick={() => { setFilterOperator(''); setFilterContact(''); setFilterPhone(''); setFilterDirection(''); setFilterChannel(''); }}
              className="text-xs text-red-600 hover:text-red-800 font-medium ml-1"
            >
              Limpar tudo
            </button>
          </div>
        )}

        {/* Table */}
        <div className="bg-white rounded-lg border border-gray-200 shadow-sm flex-1 flex flex-col overflow-hidden">
          {error && (
            <div className="bg-red-50 border-b border-red-200 px-4 py-3 text-sm text-red-700 flex items-center gap-2">
              <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
              {error}
            </div>
          )}

          <div ref={tableRef} className="overflow-x-auto flex-1">
            <table className="min-w-full divide-y divide-gray-200 text-sm data-grid-typography">
              <thead className="bg-gray-50 sticky top-0 z-10">
                <tr>
                  <th className={thCls} onClick={() => toggleSort('sent_at')}>
                    Data/Hora <SortIcon col="sent_at" active={sortCol} dir={sortDir} />
                  </th>
                  <th className={thCls} onClick={() => toggleSort('direction')}>
                    Direção <SortIcon col="direction" active={sortCol} dir={sortDir} />
                  </th>
                  <th className={thCls} onClick={() => toggleSort('phone_number')}>
                    Telefone <SortIcon col="phone_number" active={sortCol} dir={sortDir} />
                  </th>
                  <th className={thCls} onClick={() => toggleSort('contact_name')}>
                    Contato <SortIcon col="contact_name" active={sortCol} dir={sortDir} />
                  </th>
                  <th className={thCls} onClick={() => toggleSort('operator_name')}>
                    Operador <SortIcon col="operator_name" active={sortCol} dir={sortDir} />
                  </th>
                  <th className={thCls} onClick={() => toggleSort('message_type')}>
                    Tipo <SortIcon col="message_type" active={sortCol} dir={sortDir} />
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">
                    Conteúdo
                  </th>
                  <th className="px-4 py-3 text-center text-xs font-bold text-gray-500 uppercase tracking-wider w-10">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-100">
                {loading && (
                  <tr>
                    <td colSpan={8} className="px-4 py-8 text-center">
                      <div className="flex items-center justify-center gap-2 text-gray-400 text-sm">
                        <svg className="animate-spin w-4 h-4" fill="none" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                        </svg>
                        Carregando...
                      </div>
                    </td>
                  </tr>
                )}
                {!loading && messages.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-4 py-12 text-center text-gray-400 text-sm">
                      Nenhuma mensagem encontrada{anyFilter ? ' com os filtros aplicados' : ''}.
                    </td>
                  </tr>
                )}
                {!loading && (() => {
                  let tableDay = '';
                  return sortedMessages.map(msg => {
                    const hasMedia = !!(msg.attachment_url || msg.attachment_name);
                    const type     = msg.message_type?.toUpperCase();
                    const sz       = fmtBytes(msg.attachment_size);
                    const ext      = extFromMime(msg.attachment_mime_type, msg.attachment_name).toUpperCase().replace('.', '');
                    const dayLabel = msg.sent_at && sortCol === 'sent_at' && sortDir === 'desc'
                      ? formatDayLabel(msg.sent_at)
                      : '';
                    const showSep  = dayLabel && dayLabel !== tableDay;
                    if (showSep) tableDay = dayLabel;
                    return (
                      <React.Fragment key={msg.id}>
                        {showSep && (
                          <tr>
                            <td colSpan={8} className="px-4 py-2 bg-gray-50">
                              <div className="flex items-center gap-3">
                                <div className="flex-1 h-px bg-gray-200" />
                                <span className="text-[10px] font-bold uppercase tracking-widest text-gray-400 whitespace-nowrap">
                                  {dayLabel}
                                </span>
                                <div className="flex-1 h-px bg-gray-200" />
                              </div>
                            </td>
                          </tr>
                        )}
                        <tr className="hover:bg-gray-50 transition-colors cursor-default">
                          <td className="px-4 py-3 text-xs text-gray-500 whitespace-nowrap font-mono">
                            {fmtDate(msg.sent_at)}
                          </td>
                          <td className="px-4 py-3">
                            <DirBadge dir={msg.direction} />
                          </td>
                          <td className="px-4 py-3">
                            {msg.phone_number ? (
                              <button
                                onClick={() => setSelectedPhone(msg.phone_number)}
                                className="text-xs font-mono text-moss-700 hover:text-moss-900 hover:underline transition-colors text-left"
                                title="Ver todas as conversas deste número"
                              >
                                {msg.phone_number}
                              </button>
                            ) : <span className="text-xs text-gray-400">—</span>}
                          </td>
                          <td className="px-4 py-3">
                            {msg.client_name ? (
                              <div>
                                <span className="text-xs font-semibold text-gray-800">{msg.client_name}</span>
                                {msg.contact_name && msg.contact_name !== msg.client_name && (
                                  <span className="block text-[10px] text-gray-400">{msg.contact_name}</span>
                                )}
                              </div>
                            ) : (
                              <span className="text-xs text-gray-500">{msg.contact_name || '—'}</span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            {msg.operator_name ? (
                              <div>
                                <span className="text-xs font-medium text-gray-700">{msg.operator_name}</span>
                                {msg.department && (
                                  <span className="block text-[10px] text-gray-400">{msg.department}</span>
                                )}
                              </div>
                            ) : (
                              <span className="text-[10px] text-gray-400 italic">—</span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <TypeBadge type={msg.message_type} />
                          </td>
                          <td className="px-4 py-3 max-w-[220px]">
                            {type === 'AUDIO' && msg.audio_transcript ? (
                              <span className="text-xs text-gray-600 italic">{truncate(msg.audio_transcript)}</span>
                            ) : hasMedia ? (
                              <div>
                                <span className="text-xs text-amber-700 flex items-center gap-1">
                                  📎 {truncate(msg.attachment_name, 40)}
                                </span>
                                {(ext || sz) && (
                                  <span className="text-[10px] text-gray-400">{[ext, sz].filter(Boolean).join(' · ')}</span>
                                )}
                              </div>
                            ) : (
                              <span className="text-xs text-gray-700 break-words">{truncate(msg.body)}</span>
                            )}
                          </td>
                          <td className="px-4 py-3 text-center">
                            <button
                              onClick={() => setSelectedMsg(msg)}
                              title="Ver detalhes da mensagem"
                              className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-moss-50 text-moss-700 hover:bg-moss-100 transition-colors"
                            >
                              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                              </svg>
                            </button>
                          </td>
                        </tr>
                      </React.Fragment>
                    );
                  });
                })()}
              </tbody>
            </table>
          </div>

          {/* Pagination */}
          <div className="border-t border-gray-200 px-4 py-3 flex items-center justify-between bg-gray-50 flex-shrink-0">
            <span className="text-xs text-gray-500">
              {total > 0
                ? `Mostrando ${page * PAGE_SIZE + 1}–${Math.min((page + 1) * PAGE_SIZE, total)} de ${total.toLocaleString('pt-BR')}`
                : '0 resultados'}
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={() => setPage(p => Math.max(0, p - 1))}
                disabled={page === 0 || loading}
                className="px-3 py-1.5 rounded-lg border border-gray-300 text-xs font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                ← Anterior
              </button>
              <span className="text-xs text-gray-600 font-medium min-w-[60px] text-center">
                {totalPages > 0 ? `${page + 1} / ${totalPages}` : '—'}
              </span>
              <button
                onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                disabled={page >= totalPages - 1 || loading}
                className="px-3 py-1.5 rounded-lg border border-gray-300 text-xs font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed transition-colors"
              >
                Próxima →
              </button>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default GotalkMessagesTab;

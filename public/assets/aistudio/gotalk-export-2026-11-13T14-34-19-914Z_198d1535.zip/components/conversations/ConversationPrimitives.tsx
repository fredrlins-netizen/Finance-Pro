import React from 'react';

type DivProps = React.HTMLAttributes<HTMLDivElement>;

const classes = (...values: Array<string | undefined>) => values.filter(Boolean).join(' ');

export const ConversationSurface = React.forwardRef<HTMLDivElement, DivProps>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={classes('conversation-surface whatsapp-theme', className)} {...props} />
  ),
);
ConversationSurface.displayName = 'ConversationSurface';

export const ConversationTimeline = React.forwardRef<HTMLDivElement, DivProps>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={classes('conversation-timeline whatsapp-timeline', className)} {...props} />
  ),
);
ConversationTimeline.displayName = 'ConversationTimeline';

interface ConversationBubbleProps extends DivProps {
  outgoing: boolean;
}

export const ConversationBubble = React.forwardRef<HTMLDivElement, ConversationBubbleProps>(
  ({ outgoing, className, ...props }, ref) => (
    <div
      ref={ref}
      className={classes(
        'conversation-bubble',
        outgoing ? 'conversation-bubble-out whatsapp-bubble-out' : 'conversation-bubble-in whatsapp-bubble-in',
        className,
      )}
      {...props}
    />
  ),
);
ConversationBubble.displayName = 'ConversationBubble';

export const ConversationDateSeparator: React.FC<DivProps> = ({ className, children, ...props }) => (
  <div className="conversation-date-separator">
    <span className={classes('conversation-date-pill whatsapp-date-pill', className)} {...props}>
      {children}
    </span>
  </div>
);

export const ConversationComposerSurface = React.forwardRef<HTMLDivElement, DivProps>(
  ({ className, ...props }, ref) => (
    <div ref={ref} className={classes('conversation-composer whatsapp-theme', className)} {...props} />
  ),
);
ConversationComposerSurface.displayName = 'ConversationComposerSurface';
-- ============================================================
-- MIGRAÇÃO 015: Operadores e Atendimentos GoTalk
-- Criado em: 2026-03-19
-- Descrição: Adiciona tabelas para operadores GoTalk (atendentes) e
--            sessões de atendimento, permitindo rastrear quem conduziu
--            cada conversa e organizar mensagens por sessão de atendimento.
--            Também adiciona attendance_id nas mensagens para associação
--            à sessão correspondente.
-- ============================================================

-- 1. OPERADORES DO GOTALK
--    Sincronizados automaticamente pelo poller.
--    collaborator_id é opcional — vinculado ao colaborador do CRM quando possível.
CREATE TABLE IF NOT EXISTS gotalk_operators (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    gotalk_operator_id  VARCHAR(100) NOT NULL UNIQUE,
    name                VARCHAR(255),
    email               VARCHAR(255),
    phone               VARCHAR(30),
    active              BOOLEAN DEFAULT TRUE,
    collaborator_id     UUID REFERENCES collaborators(id) ON DELETE SET NULL,
    raw_data            JSONB DEFAULT '{}',
    imported_at         TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gotalk_operators_gotalk_id  ON gotalk_operators(gotalk_operator_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_operators_collab     ON gotalk_operators(collaborator_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_operators_active     ON gotalk_operators(active);

COMMENT ON TABLE gotalk_operators IS
    'Operadores/atendentes do GoTalk, sincronizados periodicamente. Vinculados opcionalmente aos colaboradores do CRM.';

-- 2. SESSÕES DE ATENDIMENTO (ATENDIMENTOS)
--    Cada atendimento agrupa um conjunto de mensagens entre um operador e um contato.
--    type distingue atendimentos com cliente (CLIENT) vs banco (BANK) — útil para Negociação.
CREATE TABLE IF NOT EXISTS gotalk_attendances (
    id                      UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    gotalk_attendance_id    VARCHAR(100) NOT NULL UNIQUE,
    operator_id             UUID REFERENCES gotalk_operators(id) ON DELETE SET NULL,
    gotalk_contact_id       UUID REFERENCES gotalk_contacts(id) ON DELETE SET NULL,
    client_id               UUID REFERENCES clients(id) ON DELETE SET NULL,
    gotalk_operator_id      VARCHAR(100),
    status                  VARCHAR(20) DEFAULT 'open' CHECK (status IN ('open','closed','waiting','transferred')),
    type                    VARCHAR(10) DEFAULT 'CLIENT' CHECK (type IN ('CLIENT','BANK')),
    department              VARCHAR(200),
    subject                 VARCHAR(500),
    started_at              TIMESTAMPTZ,
    ended_at                TIMESTAMPTZ,
    raw_data                JSONB DEFAULT '{}',
    imported_at             TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gotalk_attendances_gotalk_id     ON gotalk_attendances(gotalk_attendance_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_attendances_operator      ON gotalk_attendances(operator_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_attendances_contact       ON gotalk_attendances(gotalk_contact_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_attendances_client        ON gotalk_attendances(client_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_attendances_status        ON gotalk_attendances(status);
CREATE INDEX IF NOT EXISTS idx_gotalk_attendances_type          ON gotalk_attendances(type);
CREATE INDEX IF NOT EXISTS idx_gotalk_attendances_started_at    ON gotalk_attendances(started_at DESC);

COMMENT ON TABLE gotalk_attendances IS
    'Sessões de atendimento do GoTalk agrupando mensagens por operador e contato. type=CLIENT para atendimento ao cliente, type=BANK para contato com banco (Negociação).';

-- 3. ADICIONAR attendance_id ÀS MENSAGENS
--    Vincula cada mensagem à sessão de atendimento correspondente.
ALTER TABLE gotalk_messages
    ADD COLUMN IF NOT EXISTS attendance_id UUID REFERENCES gotalk_attendances(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_gotalk_messages_attendance ON gotalk_messages(attendance_id)
    WHERE attendance_id IS NOT NULL;

COMMENT ON COLUMN gotalk_messages.attendance_id IS
    'Sessão de atendimento do GoTalk à qual esta mensagem pertence. Preenchido pelo poller após importação dos atendimentos.';

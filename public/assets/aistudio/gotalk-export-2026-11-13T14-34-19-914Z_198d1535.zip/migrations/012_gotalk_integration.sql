-- ============================================================
-- MIGRAÇÃO 012: Integração Gotalk App
-- Criado em: 2026-03-18
-- Descrição: Tabelas para integração com o Gotalk App (WhatsApp CRM).
--            Todos os contatos e mensagens do Gotalk são armazenados
--            independentemente de haver cliente cadastrado correspondente.
--            A associação com clientes é feita retroativamente por telefone.
-- ============================================================

-- 1. ADICIONAR CAMPOS GOTALK À TABELA DE CLIENTES
ALTER TABLE clients
    ADD COLUMN IF NOT EXISTS gotalk_contact_id VARCHAR(100),
    ADD COLUMN IF NOT EXISTS gotalk_channel_id  VARCHAR(100);

CREATE INDEX IF NOT EXISTS idx_clients_gotalk_contact ON clients(gotalk_contact_id);

-- 2. CONTATOS IMPORTADOS DO GOTALK
--    Armazena TODOS os contatos do Gotalk, vinculados ou não a um cliente CRM.
CREATE TABLE IF NOT EXISTS gotalk_contacts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    gotalk_id       VARCHAR(100) NOT NULL UNIQUE,
    name            VARCHAR(255),
    phone_number    VARCHAR(30),
    client_id       UUID REFERENCES clients(id) ON DELETE SET NULL,
    channel_id      VARCHAR(100),
    raw_data        JSONB DEFAULT '{}',
    imported_at     TIMESTAMPTZ DEFAULT NOW(),
    linked_at       TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_gotalk_contacts_phone    ON gotalk_contacts(phone_number);
CREATE INDEX IF NOT EXISTS idx_gotalk_contacts_client   ON gotalk_contacts(client_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_contacts_gotalkid ON gotalk_contacts(gotalk_id);

-- 3. MENSAGENS DO GOTALK
--    Armazena todas as mensagens de todos os contatos.
--    client_id é NULLABLE — preenchido automaticamente quando a associação é feita.
CREATE TABLE IF NOT EXISTS gotalk_messages (
    id                  UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    gotalk_message_id   VARCHAR(100) UNIQUE,
    gotalk_contact_id   UUID REFERENCES gotalk_contacts(id) ON DELETE CASCADE,
    client_id           UUID REFERENCES clients(id) ON DELETE SET NULL,
    phone_number        VARCHAR(30),
    direction           VARCHAR(3) NOT NULL DEFAULT 'IN' CHECK (direction IN ('IN','OUT')),
    body                TEXT,
    message_type        VARCHAR(10) NOT NULL DEFAULT 'TEXT'
                            CHECK (message_type IN ('TEXT','IMAGE','DOCUMENT','AUDIO','VIDEO','STICKER')),
    attachment_url      TEXT,
    attachment_name     VARCHAR(255),
    attachment_mime_type VARCHAR(100),
    audio_transcript    TEXT,
    area                VARCHAR(20) CHECK (area IN ('COBRANCA','COBRANCA_COORD','COBRANCA_OP','ADMISSAO','JURIDICO','NEGOCIACAO','MENSAGENS')),
    operator_name       VARCHAR(200),
    department          VARCHAR(200),
    sent_at             TIMESTAMPTZ,
    read_at             TIMESTAMPTZ,
    imported_at         TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gotalk_messages_contact   ON gotalk_messages(gotalk_contact_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_client    ON gotalk_messages(client_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_phone     ON gotalk_messages(phone_number);
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_sent_at   ON gotalk_messages(sent_at DESC);
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_direction ON gotalk_messages(direction);

-- 4. TEMPLATES WHATSAPP
--    Gerenciados pela aba "Templates WhatsApp" nas Configurações.
CREATE TABLE IF NOT EXISTS whatsapp_templates (
    id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name          VARCHAR(200) NOT NULL,
    area          VARCHAR(20) NOT NULL
                      CHECK (area IN ('COBRANCA','COBRANCA_COORD','COBRANCA_OP','ADMISSAO','JURIDICO','NEGOCIACAO','MENSAGENS')),
    template_text TEXT NOT NULL,
    variables     JSONB DEFAULT '[]',
    active        BOOLEAN DEFAULT TRUE,
    created_at    TIMESTAMPTZ DEFAULT NOW(),
    updated_at    TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_whatsapp_templates_area   ON whatsapp_templates(area);
CREATE INDEX IF NOT EXISTS idx_whatsapp_templates_active ON whatsapp_templates(active);

-- ============================================================
-- MIGRAÇÃO 020: Arquivamento de gotalk_messages
-- Criado em: 2026-03-26
-- Descrição: Cria tabela de arquivo para mensagens WhatsApp
--            antigas e política de retenção configurável.
--
--            1. Tabela gotalk_messages_archive — mesma estrutura
--               da gotalk_messages (sem FKs para evitar falhas)
--               incluindo TODAS as colunas adicionadas em migrações
--               anteriores:
--               - ack_status (migração 013)
--               - attendance_id (migração 015)
--               - gotalk_attendance_id_ext (migração 015/016)
--               - attendance_history_id (migração 015/016)
--               - idwpp (migração 015/016)
--               - gotalk_channel_uuid (migração 016)
--               - deleted_in_gotalk / deleted_in_gotalk_at (migração 018)
--            2. Índices essenciais na tabela de arquivo
--            3. Tabela retention_config — configuração do período
--               de retenção (default: 90 dias)
-- ============================================================

-- 1. Tabela de arquivo com colunas compatíveis com gotalk_messages
--    (sem FK constraints para permitir arquivamento mesmo quando
--     contatos/clientes/atendimentos foram deletados)
CREATE TABLE IF NOT EXISTS gotalk_messages_archive (
    id                       UUID PRIMARY KEY,
    gotalk_message_id        VARCHAR(100),
    gotalk_contact_id        UUID,
    client_id                UUID,
    phone_number             VARCHAR(30),
    direction                VARCHAR(3) NOT NULL DEFAULT 'IN',
    body                     TEXT,
    message_type             VARCHAR(10) NOT NULL DEFAULT 'TEXT',
    attachment_url           TEXT,
    attachment_name          VARCHAR(255),
    attachment_mime_type     VARCHAR(100),
    audio_transcript         TEXT,
    area                     VARCHAR(20),
    operator_name            VARCHAR(200),
    department               VARCHAR(200),
    sent_at                  TIMESTAMPTZ,
    read_at                  TIMESTAMPTZ,
    imported_at              TIMESTAMPTZ DEFAULT NOW(),
    ack_status               SMALLINT,
    attendance_id            UUID,
    gotalk_attendance_id_ext VARCHAR(100),
    attendance_history_id    UUID,
    idwpp                    VARCHAR(200),
    gotalk_channel_uuid      UUID,
    deleted_in_gotalk        BOOLEAN NOT NULL DEFAULT FALSE,
    deleted_in_gotalk_at     TIMESTAMPTZ,
    archived_at              TIMESTAMPTZ DEFAULT NOW()
);

-- 2. Índices essenciais na tabela de arquivo
CREATE INDEX IF NOT EXISTS idx_gma_imported_at
    ON gotalk_messages_archive(imported_at DESC);

CREATE INDEX IF NOT EXISTS idx_gma_contact_id
    ON gotalk_messages_archive(gotalk_contact_id)
    WHERE gotalk_contact_id IS NOT NULL;

CREATE INDEX IF NOT EXISTS idx_gma_client_id
    ON gotalk_messages_archive(client_id)
    WHERE client_id IS NOT NULL;

-- 3. Tabela de configuração de retenção
CREATE TABLE IF NOT EXISTS retention_config (
    key   VARCHAR(100) PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Inserir configuração padrão de retenção (90 dias) se ainda não existir
INSERT INTO retention_config (key, value, description)
VALUES (
    'gotalk_messages_retention_days',
    '90',
    'Número de dias para manter mensagens WhatsApp na tabela principal antes de arquivar'
)
ON CONFLICT (key) DO NOTHING;

-- ============================================================
-- MIGRAÇÃO 013: ACK Status (confirmação de entrega) nas mensagens Gotalk
-- Criado em: 2026-03-18
-- Descrição: Adiciona coluna ack_status para rastrear o status de entrega
--            das mensagens WhatsApp (1=enviado, 2=entregue, 3=lido).
-- ============================================================

ALTER TABLE gotalk_messages
    ADD COLUMN IF NOT EXISTS ack_status SMALLINT;

COMMENT ON COLUMN gotalk_messages.ack_status IS
    '1=enviado ao servidor, 2=entregue no celular, 3=lido pelo destinatário. NULL=desconhecido.';

CREATE INDEX IF NOT EXISTS idx_gotalk_messages_ack ON gotalk_messages(ack_status)
    WHERE direction = 'OUT' AND ack_status IS NOT NULL AND ack_status < 3;

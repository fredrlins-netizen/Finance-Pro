-- Migration 035: Backfill prospection_contacts from gotalk_messages
-- Purpose: Ensures production environments are pre-populated with incoming
--          WhatsApp contacts from GoTalk historical messages on first deploy.
--          Safe to run multiple times (idempotent via ON CONFLICT DO UPDATE).

-- Step 1: Link gotalk_channels to the default unit when unit_id is missing.
-- Uses the single-company fallback: if there is exactly one company, all channels
-- without a unit are assigned to it automatically.
UPDATE gotalk_channels
SET unit_id = (
  SELECT id FROM companies ORDER BY created_at LIMIT 1
)
WHERE unit_id IS NULL
  AND (SELECT COUNT(*) FROM companies) = 1;

-- Step 2: Backfill prospection_contacts from gotalk_messages.
-- Groups incoming messages by phone number, computing:
--   - classification: RECUPERACAO when the phone appears on multiple distinct calendar days,
--                     LEAD otherwise (single-day burst of messages)
--   - total_contacts: total incoming messages for that phone
--   - first_contact_at / last_contact_at: timestamp range from actual messages
--   - unit_id: resolved from gotalk_channels via gotalk_channel_uuid FK
--   - source: always 'gotalk' for records seeded from this table
--
-- ON CONFLICT: existing phones have their aggregate counters refreshed but
--   unit_id is only updated when still NULL (preserves manual assignments).
INSERT INTO prospection_contacts
  (phone, contact_name, classification, total_contacts,
   first_contact_at, last_contact_at, unit_id, source)
SELECT
  gm.phone_number                                          AS phone,
  NULL                                                     AS contact_name,
  CASE
    WHEN COUNT(DISTINCT DATE(gm.sent_at)) > 1 THEN 'RECUPERACAO'
    ELSE 'LEAD'
  END                                                      AS classification,
  COUNT(*)                                                 AS total_contacts,
  MIN(gm.sent_at)                                          AS first_contact_at,
  MAX(gm.sent_at)                                          AS last_contact_at,
  -- Resolve unit_id through the channel that received each message group.
  -- Use the most recent channel for this phone if multiple channels exist.
  (
    SELECT gc.unit_id
    FROM gotalk_messages gm2
    JOIN gotalk_channels gc ON gc.id = gm2.gotalk_channel_uuid
    WHERE gm2.phone_number = gm.phone_number
      AND gm2.direction = 'IN'
      AND gc.unit_id IS NOT NULL
    ORDER BY gm2.sent_at DESC
    LIMIT 1
  )                                                        AS unit_id,
  'gotalk'                                                 AS source
FROM gotalk_messages gm
WHERE gm.direction = 'IN'
  AND gm.phone_number IS NOT NULL
  AND gm.phone_number != ''
GROUP BY gm.phone_number
ON CONFLICT (phone) DO UPDATE SET
  total_contacts  = EXCLUDED.total_contacts,
  last_contact_at = GREATEST(prospection_contacts.last_contact_at, EXCLUDED.last_contact_at),
  first_contact_at= LEAST(prospection_contacts.first_contact_at, EXCLUDED.first_contact_at),
  classification  = EXCLUDED.classification,
  unit_id         = COALESCE(prospection_contacts.unit_id, EXCLUDED.unit_id),
  updated_at      = NOW();

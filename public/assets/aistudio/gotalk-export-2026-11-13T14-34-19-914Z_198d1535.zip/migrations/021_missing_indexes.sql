-- ============================================================
-- MIGRAÇÃO 021: Índices Faltantes — Auditoria de Segurança
-- Criado em: 2026-04-08
-- Descrição: Adiciona índices identificados durante auditoria de
--            segurança e performance. Cobre colunas de filtragem
--            frequente que estavam sem suporte de índice.
-- ============================================================

-- ── financial_titles ────────────────────────────────────────
-- unit_id: filtragem por unidade para usuários não-ADMIN (compensação de RLS)
CREATE INDEX IF NOT EXISTS idx_ft_unit_id
    ON financial_titles(unit_id)
    WHERE unit_id IS NOT NULL;

-- collection_status: filtro usado nos painéis de Cobrança
CREATE INDEX IF NOT EXISTS idx_ft_collection_status
    ON financial_titles(collection_status)
    WHERE collection_status IS NOT NULL;

-- seller_id: atribuição de vendedor / colaborador responsável pelo título
CREATE INDEX IF NOT EXISTS idx_ft_seller
    ON financial_titles(seller_id)
    WHERE seller_id IS NOT NULL;

-- ── gotalk_messages ─────────────────────────────────────────
-- area: separação por módulo (COBRANCA, JURIDICO, NEGOCIACAO, etc.)
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_area
    ON gotalk_messages(area)
    WHERE area IS NOT NULL;

-- ── user_group_members ──────────────────────────────────────
-- group_id isolado: permite listar todos os usuários de um grupo
-- (o PK (user_id, group_id) já cobre user->group mas não group->user)
CREATE INDEX IF NOT EXISTS idx_ugm_group_id
    ON user_group_members(group_id);

-- ── user_allowed_units ──────────────────────────────────────
-- unit_id isolado: permite listar todos os usuários de uma unidade
-- (o PK (user_id, unit_id) cobre user->unit mas não unit->user)
CREATE INDEX IF NOT EXISTS idx_uau_unit_id
    ON user_allowed_units(unit_id);

-- ── legal_processes ─────────────────────────────────────────
-- type: filtragem por tipo de processo (ação, cautelar, etc.)
CREATE INDEX IF NOT EXISTS idx_legal_processes_type
    ON legal_processes(type)
    WHERE type IS NOT NULL;

-- distribution_date: ordenação e filtragem por data de distribuição
CREATE INDEX IF NOT EXISTS idx_legal_processes_dist_date
    ON legal_processes(distribution_date)
    WHERE distribution_date IS NOT NULL;

-- ── admissions ──────────────────────────────────────────────
-- contract_number: busca por número de contrato
CREATE INDEX IF NOT EXISTS idx_admissions_contract_number
    ON admissions(contract_number)
    WHERE contract_number IS NOT NULL;

-- ── audit_logs ──────────────────────────────────────────────
-- ip_address: análise forense por endereço IP (adiciona coluna se não existir)
ALTER TABLE audit_logs ADD COLUMN IF NOT EXISTS ip_address TEXT;

CREATE INDEX IF NOT EXISTS idx_audit_ip_address
    ON audit_logs(ip_address)
    WHERE ip_address IS NOT NULL;

-- entity_action composto: buscas por entidade + tipo de operação
CREATE INDEX IF NOT EXISTS idx_audit_entity_action
    ON audit_logs(entity, action);

-- ── ANALYZE ─────────────────────────────────────────────────
-- Atualiza estatísticas do planejador de queries para as tabelas afetadas
ANALYZE financial_titles;
ANALYZE gotalk_messages;
ANALYZE user_group_members;
ANALYZE user_allowed_units;
ANALYZE legal_processes;
ANALYZE admissions;
ANALYZE audit_logs;

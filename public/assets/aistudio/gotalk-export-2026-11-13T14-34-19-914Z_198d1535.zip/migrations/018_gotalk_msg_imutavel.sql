-- ============================================================
-- MIGRAÇÃO 018: Mensagens GoTalk imutáveis no CRM
-- Criado em: 2026-03-25
-- Descrição: Garante que mensagens armazenadas no CRM não possam
--            ser removidas por ações externas (GoTalk/WhatsApp).
--
--            1. Adiciona colunas de rastreio de deleção na origem:
--               - deleted_in_gotalk: flag indicando que a mensagem foi
--                 deletada/revogada no GoTalk/WhatsApp.
--               - deleted_in_gotalk_at: momento em que o evento de
--                 deleção foi recebido.
--               O CONTEÚDO da mensagem é preservado independentemente.
--
--            2. Altera a FK gotalk_messages.gotalk_contact_id de
--               ON DELETE CASCADE → ON DELETE SET NULL.
--               Assim, excluir um contato do CRM NÃO apaga as mensagens;
--               elas ficam com gotalk_contact_id = NULL e são mantidas.
-- ============================================================

-- 1. Colunas de rastreio de deleção na origem
ALTER TABLE gotalk_messages
    ADD COLUMN IF NOT EXISTS deleted_in_gotalk    BOOLEAN   NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS deleted_in_gotalk_at TIMESTAMPTZ;

COMMENT ON COLUMN gotalk_messages.deleted_in_gotalk IS
    'TRUE quando o GoTalk/WhatsApp sinalizou que esta mensagem foi deletada/revogada na origem. O conteúdo é preservado no CRM.';

COMMENT ON COLUMN gotalk_messages.deleted_in_gotalk_at IS
    'Momento em que o evento de deleção foi recebido pelo CRM (hora local do servidor). NULL se não foi deletada na origem.';

CREATE INDEX IF NOT EXISTS idx_gotalk_messages_deleted_in_gotalk
    ON gotalk_messages(deleted_in_gotalk)
    WHERE deleted_in_gotalk = TRUE;

-- 2. Trocar ON DELETE CASCADE → ON DELETE SET NULL na FK gotalk_contact_id
--    O nome padrão gerado pelo PostgreSQL para a constraint é:
--    gotalk_messages_gotalk_contact_id_fkey
ALTER TABLE gotalk_messages
    DROP CONSTRAINT IF EXISTS gotalk_messages_gotalk_contact_id_fkey;

ALTER TABLE gotalk_messages
    ADD CONSTRAINT gotalk_messages_gotalk_contact_id_fkey
    FOREIGN KEY (gotalk_contact_id)
    REFERENCES gotalk_contacts(id)
    ON DELETE SET NULL;

-- Migration 045: Imutabilidade de mensagens WhatsApp
-- Garante que o conteúdo das mensagens não possa ser apagado ou alterado após registro.

-- ─────────────────────────────────────────────────────────────────────────────
-- 1. Trigger de conteúdo imutável em gotalk_messages
-- ─────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION fn_gotalk_messages_immutable_content()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    IF OLD.body IS DISTINCT FROM NEW.body THEN
      RAISE EXCEPTION 'IMMUTABLE_FIELD: o campo body de gotalk_messages não pode ser alterado após inserção.';
    END IF;
    IF OLD.direction IS DISTINCT FROM NEW.direction THEN
      RAISE EXCEPTION 'IMMUTABLE_FIELD: o campo direction de gotalk_messages não pode ser alterado após inserção.';
    END IF;
    IF OLD.sent_at IS DISTINCT FROM NEW.sent_at THEN
      RAISE EXCEPTION 'IMMUTABLE_FIELD: o campo sent_at de gotalk_messages não pode ser alterado após inserção.';
    END IF;
    IF OLD.phone_number IS DISTINCT FROM NEW.phone_number THEN
      RAISE EXCEPTION 'IMMUTABLE_FIELD: o campo phone_number de gotalk_messages não pode ser alterado após inserção.';
    END IF;
    IF OLD.message_type IS DISTINCT FROM NEW.message_type THEN
      RAISE EXCEPTION 'IMMUTABLE_FIELD: o campo message_type de gotalk_messages não pode ser alterado após inserção.';
    END IF;
  END IF;

  IF TG_OP = 'DELETE' THEN
    -- Só permite DELETE se a linha já foi arquivada (job de retenção)
    IF NOT EXISTS (
      SELECT 1 FROM gotalk_messages_archive WHERE id = OLD.id
    ) THEN
      RAISE EXCEPTION 'IMMUTABLE_DELETE: mensagem % não pode ser excluída sem arquivamento prévio.', OLD.id;
    END IF;
  END IF;

  RETURN CASE TG_OP WHEN 'DELETE' THEN OLD ELSE NEW END;
END;
$$;

DROP TRIGGER IF EXISTS trg_gotalk_messages_immutable ON gotalk_messages;
CREATE TRIGGER trg_gotalk_messages_immutable
  BEFORE UPDATE OR DELETE ON gotalk_messages
  FOR EACH ROW EXECUTE FUNCTION fn_gotalk_messages_immutable_content();

-- ─────────────────────────────────────────────────────────────────────────────
-- 2. Trigger de imutabilidade total em gotalk_messages_archive
--    (arquivo histórico: nenhuma alteração ou exclusão permitida)
-- ─────────────────────────────────────────────────────────────────────────────

CREATE OR REPLACE FUNCTION fn_gotalk_messages_archive_immutable()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'DELETE' THEN
    RAISE EXCEPTION 'IMMUTABLE_ARCHIVE: mensagens arquivadas não podem ser excluídas (id: %).', OLD.id;
  END IF;
  IF TG_OP = 'UPDATE' THEN
    IF OLD.body IS DISTINCT FROM NEW.body THEN
      RAISE EXCEPTION 'IMMUTABLE_ARCHIVE: o campo body de gotalk_messages_archive não pode ser alterado.';
    END IF;
    IF OLD.direction IS DISTINCT FROM NEW.direction THEN
      RAISE EXCEPTION 'IMMUTABLE_ARCHIVE: o campo direction de gotalk_messages_archive não pode ser alterado.';
    END IF;
    IF OLD.sent_at IS DISTINCT FROM NEW.sent_at THEN
      RAISE EXCEPTION 'IMMUTABLE_ARCHIVE: o campo sent_at de gotalk_messages_archive não pode ser alterado.';
    END IF;
    IF OLD.phone_number IS DISTINCT FROM NEW.phone_number THEN
      RAISE EXCEPTION 'IMMUTABLE_ARCHIVE: o campo phone_number de gotalk_messages_archive não pode ser alterado.';
    END IF;
  END IF;
  RETURN CASE TG_OP WHEN 'DELETE' THEN OLD ELSE NEW END;
END;
$$;

DROP TRIGGER IF EXISTS trg_gotalk_messages_archive_immutable ON gotalk_messages_archive;
CREATE TRIGGER trg_gotalk_messages_archive_immutable
  BEFORE UPDATE OR DELETE ON gotalk_messages_archive
  FOR EACH ROW EXECUTE FUNCTION fn_gotalk_messages_archive_immutable();

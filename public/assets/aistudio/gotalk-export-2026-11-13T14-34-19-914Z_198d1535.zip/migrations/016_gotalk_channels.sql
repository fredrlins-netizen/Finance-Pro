-- ============================================================
-- MIGRAÇÃO 016: Canais GoTalk
-- Criado em: 2026-03-25
-- Descrição: Tabela de canais GoTalk para suporte multi-canal.
--            Cada canal corresponde a um número WhatsApp configurado
--            na conta GoTalk. O channel_id técnico é armazenado
--            somente no banco (nunca exposto ao frontend).
--            Canais podem ser vinculados opcionalmente a uma Unidade.
-- ============================================================

CREATE TABLE IF NOT EXISTS gotalk_channels (
    id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name         VARCHAR(255) NOT NULL,
    phone_number VARCHAR(30),
    channel_id   VARCHAR(100) UNIQUE,
    unit_id      UUID REFERENCES companies(id) ON DELETE SET NULL,
    is_primary   BOOLEAN NOT NULL DEFAULT FALSE,
    is_active    BOOLEAN NOT NULL DEFAULT TRUE,
    notes        TEXT,
    created_at   TIMESTAMPTZ DEFAULT NOW(),
    updated_at   TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_gotalk_channels_active     ON gotalk_channels(is_active);
CREATE INDEX IF NOT EXISTS idx_gotalk_channels_primary    ON gotalk_channels(is_primary);
CREATE INDEX IF NOT EXISTS idx_gotalk_channels_unit       ON gotalk_channels(unit_id);
CREATE INDEX IF NOT EXISTS idx_gotalk_channels_channel_id ON gotalk_channels(channel_id);

COMMENT ON TABLE gotalk_channels IS
    'Canais WhatsApp da conta GoTalk. is_primary=true é o canal principal (channelId retornado no login). '
    'O campo channel_id (ID técnico GoTalk) é armazenado somente no servidor — nunca retornado ao frontend.';

COMMENT ON COLUMN gotalk_channels.channel_id IS
    'ID técnico interno do GoTalk (ex: 68e94a011372f903d7f47e5b). '
    'Usado nas chamadas à API GoTalk. NUNCA exposto ao frontend.';

COMMENT ON COLUMN gotalk_channels.unit_id IS
    'Vínculo opcional com uma Unidade do CRM. Permite filtrar mensagens por unidade.';

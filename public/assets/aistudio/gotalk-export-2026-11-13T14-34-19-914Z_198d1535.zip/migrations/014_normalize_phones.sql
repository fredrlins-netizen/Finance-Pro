-- Migration 014: Normalize phone numbers in clients table
-- Strips all non-digit characters from phone and phone2 columns,
-- storing them in pure-digit format (e.g. 81981071630) matching GoTalk.
-- This enables direct phone-based linking between CRM clients and GoTalk contacts.

UPDATE clients
SET phone = REGEXP_REPLACE(phone, '[^0-9]', '', 'g')
WHERE phone IS NOT NULL AND phone ~ '[^0-9]';

UPDATE clients
SET phone2 = REGEXP_REPLACE(phone2, '[^0-9]', '', 'g')
WHERE phone2 IS NOT NULL AND phone2 ~ '[^0-9]';

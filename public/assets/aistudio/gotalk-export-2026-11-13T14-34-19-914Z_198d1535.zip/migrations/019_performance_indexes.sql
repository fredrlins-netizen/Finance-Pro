-- ============================================================
-- MIGRAÇÃO 019: Índices de Performance (GIN / Trigram)
-- Criado em: 2026-03-26
-- Descrição: Adiciona índices GIN para buscas em campos JSONB/arrays
--            e índices trigram (pg_trgm) para buscas textuais.
--
--            1. GIN em gotalk_messages.body      — busca full-text em mensagens
--            2. GIN em audit_logs.changes         — busca em diffs JSON de auditoria
--            3. GIN em financial_titles.origin_title_ids — busca em arrays UUID
--            4. Trigram em legal_processes.process_number — busca parcial rápida
--            5. Trigram em clients.name           — busca fuzzy por nome de cliente
-- ============================================================

-- Habilitar extensão pg_trgm (necessária para índices trigram)
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- 1. GIN full-text em gotalk_messages.body
--    Permite buscas rápidas por conteúdo de mensagem via to_tsvector
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_body_fts
    ON gotalk_messages
    USING gin(to_tsvector('portuguese', COALESCE(body, '')));

-- 2. GIN em audit_logs.changes (coluna JSONB)
--    Permite buscas por qualquer chave/valor dentro do diff de auditoria
CREATE INDEX IF NOT EXISTS idx_audit_logs_changes_gin
    ON audit_logs
    USING gin(changes)
    WHERE changes IS NOT NULL;

-- 3. GIN em financial_titles.origin_title_ids (coluna JSONB/array)
--    Permite buscar rapidamente quais títulos originaram uma fatura
CREATE INDEX IF NOT EXISTS idx_financial_titles_origin_ids_gin
    ON financial_titles
    USING gin(origin_title_ids)
    WHERE origin_title_ids IS NOT NULL;

-- 4. Trigram em legal_processes.process_number
--    Permite buscas parciais/fuzzy por número de processo CNJ
CREATE INDEX IF NOT EXISTS idx_legal_processes_process_number_trgm
    ON legal_processes
    USING gin(process_number gin_trgm_ops);

-- 5. Trigram em clients.name
--    Acelera ILIKE '%termo%' nas buscas por cliente
CREATE INDEX IF NOT EXISTS idx_clients_name_trgm
    ON clients
    USING gin(name gin_trgm_ops);

-- Índices compostos adicionais para queries mais comuns

-- financial_titles: filtro por status + vencimento (listagem principal)
CREATE INDEX IF NOT EXISTS idx_financial_titles_status_due_date
    ON financial_titles(title_scope, status, due_date)
    WHERE status NOT IN ('CANCELADO', 'PAGO');

-- gotalk_messages: filtro por contato + data (timeline do atendimento)
CREATE INDEX IF NOT EXISTS idx_gotalk_messages_contact_sent
    ON gotalk_messages(gotalk_contact_id, sent_at DESC)
    WHERE gotalk_contact_id IS NOT NULL;

-- audit_logs: filtro por entidade + data (log de auditoria)
CREATE INDEX IF NOT EXISTS idx_audit_logs_entity_created
    ON audit_logs(entity, entity_id, timestamp DESC);

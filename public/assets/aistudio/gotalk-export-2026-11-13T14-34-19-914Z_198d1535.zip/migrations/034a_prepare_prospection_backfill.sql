-- Compatibilidade para instalações novas antes de
-- 035_backfill_prospection_contacts.sql.
-- Bancos que já registraram o backfill preservam o esquema existente.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1
    FROM migrations_log
    WHERE filename = '035_backfill_prospection_contacts.sql'
  ) THEN
    ALTER TABLE gotalk_contacts
      ADD COLUMN IF NOT EXISTS gotalk_channel_uuid UUID
      REFERENCES gotalk_channels(id) ON DELETE SET NULL;

    UPDATE gotalk_contacts gc
    SET gotalk_channel_uuid = channel.id
    FROM gotalk_channels channel
    WHERE gc.channel_id = channel.channel_id
      AND gc.gotalk_channel_uuid IS NULL;

    ALTER TABLE gotalk_messages
      ADD COLUMN IF NOT EXISTS gotalk_channel_uuid UUID
      REFERENCES gotalk_channels(id) ON DELETE SET NULL;

    UPDATE gotalk_messages gm
    SET gotalk_channel_uuid = gc.gotalk_channel_uuid
    FROM gotalk_contacts gc
    WHERE gm.gotalk_contact_id = gc.id
      AND gm.gotalk_channel_uuid IS NULL
      AND gc.gotalk_channel_uuid IS NOT NULL;

    CREATE INDEX IF NOT EXISTS idx_gotalk_messages_channel_uuid
      ON gotalk_messages(gotalk_channel_uuid);
  END IF;
END $$;
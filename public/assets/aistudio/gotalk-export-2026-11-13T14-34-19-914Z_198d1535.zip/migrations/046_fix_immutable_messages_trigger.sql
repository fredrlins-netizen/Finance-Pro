-- Migration 046: Corrige trigger de imutabilidade de mensagens
-- gotalk_messages_archive.id é text (legado) enquanto gotalk_messages.id é uuid.
-- Usa cast explícito para evitar erro "operator does not exist: text = uuid".

CREATE OR REPLACE FUNCTION fn_gotalk_messages_immutable_content()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    IF OLD.body IS DISTINCT FROM NEW.body THEN
      RAISE EXCEPTION 'IMMUTABLE_FIELD: o campo body de gotalk_messages não pode ser alterado após inserção.';
    END IF;
    IF OLD.direction IS DISTINCT FROM NEW.direction THEN
      RAISE EXCEPTION 'IMMUTABLE_FIELD: o campo direction de gotalk_messages não pode ser alterado após inserção.';
    END IF;
    IF OLD.sent_at IS DISTINCT FROM NEW.sent_at THEN
      RAISE EXCEPTION 'IMMUTABLE_FIELD: o campo sent_at de gotalk_messages não pode ser alterado após inserção.';
    END IF;
    IF OLD.phone_number IS DISTINCT FROM NEW.phone_number THEN
      RAISE EXCEPTION 'IMMUTABLE_FIELD: o campo phone_number de gotalk_messages não pode ser alterado após inserção.';
    END IF;
    IF OLD.message_type IS DISTINCT FROM NEW.message_type THEN
      RAISE EXCEPTION 'IMMUTABLE_FIELD: o campo message_type de gotalk_messages não pode ser alterado após inserção.';
    END IF;
  END IF;

  IF TG_OP = 'DELETE' THEN
    -- gotalk_messages_archive.id pode ser text (tabela legada) ou uuid —
    -- usa cast para text em ambos os lados para garantir compatibilidade.
    IF NOT EXISTS (
      SELECT 1 FROM gotalk_messages_archive WHERE id::text = OLD.id::text
    ) THEN
      RAISE EXCEPTION 'IMMUTABLE_DELETE: mensagem % não pode ser excluída sem arquivamento prévio.', OLD.id;
    END IF;
  END IF;

  RETURN CASE TG_OP WHEN 'DELETE' THEN OLD ELSE NEW END;
END;
$$;

-- Recria o trigger (função já substituída acima)
DROP TRIGGER IF EXISTS trg_gotalk_messages_immutable ON gotalk_messages;
CREATE TRIGGER trg_gotalk_messages_immutable
  BEFORE UPDATE OR DELETE ON gotalk_messages
  FOR EACH ROW EXECUTE FUNCTION fn_gotalk_messages_immutable_content();

-- Type: SCHEMA
-- Minimal, idempotent grants for the seven verified runtime gaps.
-- Does not copy data, change role attributes, disable RLS, or grant DDL.
GRANT SELECT ON TABLE public.audit_unit_backfill_unclassified TO app_user;

GRANT SELECT, INSERT, UPDATE, DELETE
ON TABLE public.client_attachment_file_acl_overrides TO app_user;

GRANT SELECT, INSERT, DELETE
ON TABLE public.client_attachment_file_grants,
         public.client_attachment_folder_grants TO app_user;

GRANT SELECT, INSERT, UPDATE
ON TABLE public.client_attachment_folder_acl,
         public.user_preferences TO app_user;

GRANT SELECT ON TABLE public.v_gotalk_client_timeline TO app_user;

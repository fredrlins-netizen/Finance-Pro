# WhatsApp Worker — Serviço de Background GoTalk

Serviço **Node.js 18+** independente que roda continuamente em um Replit separado,
responsável por toda a integração com o GoTalk (WhatsApp):

- **Polling periódico** de contatos, operadores, atendimentos e mensagens
- **Webhook em tempo real** para receber mensagens e eventos instantaneamente
- **Transcrição automática** de mensagens de áudio via OpenAI Whisper
- **Compartilha o banco de dados** com o CRM — nenhuma mudança de schema necessária

O CRM lê os dados já processados por este worker. Os dois projetos coexistem
de forma independente: reiniciar o CRM não interrompe o recebimento de mensagens.

---

## Como criar o Replit do Worker

### 1. Criar o novo Replit

1. Acesse [replit.com](https://replit.com) e clique em **Create Repl**
2. Escolha o template **Node.js**
3. Dê um nome como `whatsapp-worker`

### 2. Copiar os arquivos

Copie os arquivos da pasta `whatsapp-worker/` do projeto CRM para a raiz do novo Replit:

```
whatsapp-worker/
├── server.js           → raiz do novo Repl
├── package.json        → raiz do novo Repl
├── .replit             → raiz do novo Repl
├── services/
│   ├── gotalkAuth.js   → services/gotalkAuth.js
│   ├── gotalkPoller.js → services/gotalkPoller.js
│   └── gotalkTranscription.js → services/gotalkTranscription.js
└── routes/
    └── webhook.js      → routes/webhook.js
```

### 3. Instalar dependências

No Shell do novo Replit, execute:

```bash
npm install
```

> **Requisito:** Node.js 18 ou superior (para suporte ao `fetch` global e `formdata-node`).
> O Replit Node.js template já usa Node 18+ por padrão.
>
> O projeto usa apenas três dependências:
> - **express** — servidor HTTP para receber webhooks
> - **pg** — cliente PostgreSQL
> - **formdata-node** — FormData para envio de arquivos ao OpenAI Whisper
>
> A transcrição de áudios é feita via chamada direta à API da OpenAI (sem pacote `openai`),
> usando o `fetch` nativo do Node 18+.

### 4. Configurar os Secrets

Vá em **Tools > Secrets** no novo Replit e adicione:

| Secret | Valor | Obrigatório? |
|--------|-------|--------------|
| `DATABASE_URL` | Mesma URL do banco do CRM | Sim |
| `GOTALK_LOGIN` | Login da conta GoTalk | Sim |
| `GOTALK_PASSWORD` | Senha da conta GoTalk | Sim |
| `GOTALK_WEBHOOK_SECRET` | Token secreto do webhook | Recomendado |
| `OPENAI_API_KEY` | Chave da OpenAI (transcrição) | Opcional |

**Importante:** `DATABASE_URL` deve ser a **mesma** do CRM — ambos os projetos
compartilham o mesmo banco de dados PostgreSQL.

### 5. Iniciar o worker

Clique em **Run** no Replit. O worker vai:

1. Conectar ao banco de dados
2. Autenticar no GoTalk
3. Iniciar o motor de polling em background
4. Abrir o servidor HTTP na porta 3001 para receber webhooks

### 6. Configurar o Webhook no GoTalk

Após o worker estar rodando:

1. No painel do GoTalk, vá em **Configurações > Webhooks**
2. Configure a URL como: `https://<DOMINIO_DO_WORKER_REPLIT>/api/gotalk/webhook`
3. Configure o token secreto com o mesmo valor do secret `GOTALK_WEBHOOK_SECRET`

**Dica:** O domínio do Worker Replit aparece na barra de URL do preview.
Copie a URL base (ex: `https://whatsapp-worker.seuusuario.repl.co`) e configure
o secret `GOTALK_WORKER_URL` no projeto CRM — isso faz o painel de Configurações
mostrar a URL correta do webhook para copiar ao GoTalk.

### 7. Remover o webhook do CRM (após confirmar que o worker está OK)

Quando o worker estiver recebendo webhooks com sucesso:

1. No projeto CRM, o servidor já foi limpo para não iniciar o poller
2. Atualize a URL do webhook no GoTalk para apontar para o worker (se ainda não fez)
3. O CRM pode ser reiniciado à vontade sem interromper o recebimento de mensagens

---

## Verificar se está funcionando

Acesse `GET /health` para ver o status do worker:

```
https://<DOMINIO_DO_WORKER>/health
```

Resposta esperada:
```json
{
  "status": "ok",
  "service": "whatsapp-worker",
  "uptime": 3600,
  "timestamp": "2026-03-25T10:00:00.000Z"
}
```

---

## Manter o worker sempre ativo

Por padrão, o Replit suspende projetos após inatividade. Para manter o worker
rodando 24/7:

- Use o plano **Replit Core** ou **Teams** com a opção **Always On** habilitada
- Ou configure um serviço externo (UptimeRobot, Betterstack) para fazer ping
  no endpoint `/health` a cada 5 minutos — isso evita a suspensão por inatividade

---

## Arquitetura resumida

```
┌─────────────────────────────────────────┐
│       WORKER (este Replit)               │
│  - Polling GoTalk a cada 30s/2min/10min │
│  - Recebe webhooks em tempo real         │
│  - Transcreve áudios (Whisper)           │
│  - Grava tudo no banco compartilhado     │
└──────────────────┬──────────────────────┘
                   │ DATABASE_URL (PostgreSQL compartilhado)
┌──────────────────▼──────────────────────┐
│           CRM (outro Replit)             │
│  - Interface visual para usuários        │
│  - Lê mensagens já processadas           │
│  - Envia mensagens via GoTalk API        │
│  - Gerencia templates HSM                │
└─────────────────────────────────────────┘
```

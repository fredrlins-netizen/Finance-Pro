/**
 * WhatsApp Worker — Servidor principal
 *
 * Este serviço roda de forma contínua e independente do CRM.
 * Responsabilidades:
 *   - Polling periódico do GoTalk (contatos, operadores, atendimentos, mensagens)
 *   - Recebimento de webhooks em tempo real do GoTalk
 *   - Transcrição automática de áudios (OpenAI Whisper)
 *   - Todas as operações gravam no banco PostgreSQL compartilhado com o CRM
 *
 * O CRM lê os dados já processados — não precisa mais fazer polling direto.
 */

import express from 'express';
import pg from 'pg';
import { startPoller } from './services/gotalkPoller.js';
import { createWebhookRoutes } from './routes/webhook.js';
import { syncAllChannels } from './services/gotalkChannels.js';

const app = express();
const PORT = process.env.PORT || 3001;

// ── Middleware básico ──────────────────────────────────────────────────────
app.use(express.json({ limit: '5mb' }));

// Remover X-Powered-By por segurança
app.disable('x-powered-by');

// ── Banco de dados ─────────────────────────────────────────────────────────
if (!process.env.DATABASE_URL) {
  console.error('[Worker] FATAL: DATABASE_URL não configurado. Configure o secret no Replit.');
  process.exit(1);
}

const pool = new pg.Pool({
  connectionString: process.env.DATABASE_URL,
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 5000,
  statement_timeout: 30000,
  query_timeout: 30000,
});

pool.on('error', (err) => {
  console.error('[Worker] Erro inesperado no pool de banco:', err.message);
});

// ── Rotas ──────────────────────────────────────────────────────────────────
// Webhook GoTalk e health check (/health)
const webhookRouter = createWebhookRoutes(pool);
app.use('/', webhookRouter);

// ── Inicialização ──────────────────────────────────────────────────────────
async function start() {
  // Verificar conectividade com o banco
  try {
    const client = await pool.connect();
    await client.query('SELECT 1');
    client.release();
    console.log('[Worker] Conectado ao banco de dados PostgreSQL.');
  } catch (err) {
    console.error('[Worker] FATAL: Não foi possível conectar ao banco de dados:', err.message);
    process.exit(1);
  }

  // ── Garantir tabela gotalk_channels ────────────────────────────────────────
  // O CRM normalmente cria essa tabela, mas o worker pode iniciar antes dele.
  // Criamos com CREATE TABLE IF NOT EXISTS para ser idempotente.
  try {
    const client2 = await pool.connect();
    try {
      await client2.query(`
        CREATE TABLE IF NOT EXISTS gotalk_channels (
          id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
          name         VARCHAR(255) NOT NULL,
          phone_number VARCHAR(30),
          channel_id   VARCHAR(100) UNIQUE,
          unit_id      UUID,
          is_primary   BOOLEAN NOT NULL DEFAULT FALSE,
          is_active    BOOLEAN NOT NULL DEFAULT TRUE,
          notes        TEXT,
          created_at   TIMESTAMPTZ DEFAULT NOW(),
          updated_at   TIMESTAMPTZ DEFAULT NOW()
        )
      `);
      // Idempotente: remover NOT NULL de channel_id se ainda estiver lá
      try { await client2.query(`ALTER TABLE gotalk_channels ALTER COLUMN channel_id DROP NOT NULL`); } catch (_) {}
      // Idempotente: adicionar gotalk_channel_uuid em gotalk_contacts para filtro multi-canal
      try {
        await client2.query(`ALTER TABLE gotalk_contacts ADD COLUMN IF NOT EXISTS gotalk_channel_uuid UUID REFERENCES gotalk_channels(id) ON DELETE SET NULL`);
        await client2.query(`CREATE INDEX IF NOT EXISTS idx_gotalk_contacts_channel_uuid ON gotalk_contacts(gotalk_channel_uuid)`);
      } catch (_) {}
      console.log('[Worker] Tabela gotalk_channels verificada.');
    } finally {
      client2.release();
    }
  } catch (tblErr) {
    console.warn('[Worker] Aviso ao verificar gotalk_channels:', tblErr.message);
  }

  // ── Descoberta e sincronização automática de canais ───────────────────────
  // Autentica, obtém o canal primário e busca todos os canais secundários via
  // GET /channel/secondary/channelId/:primaryId — upsertando todos na tabela.
  if (process.env.GOTALK_LOGIN && process.env.GOTALK_PASSWORD) {
    try {
      await syncAllChannels(pool);
    } catch (channelErr) {
      console.warn('[Worker] Aviso ao sincronizar canais GoTalk:', channelErr.message);
    }
  }

  // ── Iniciar o motor de polling em background ────────────────────────────────
  // O startPoller gerencia autenticação GoTalk internamente (com retry automático).
  if (!process.env.GOTALK_LOGIN || !process.env.GOTALK_PASSWORD) {
    console.warn('[Worker] AVISO: GOTALK_LOGIN e/ou GOTALK_PASSWORD não configurados.');
    console.warn('[Worker] O polling não será iniciado. Configure os secrets e reinicie.');
  } else {
    startPoller(pool);
    console.log('[Worker] Motor de polling GoTalk iniciado.');
  }

  // Iniciar o servidor HTTP para receber webhooks
  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Worker] Servidor HTTP escutando na porta ${PORT}`);
    console.log(`[Worker] Webhook URL: https://<SEU_DOMINIO_REPLIT>/api/gotalk/webhook`);
    console.log('[Worker] Health check: GET /health');
  });
}

// ── Graceful shutdown ──────────────────────────────────────────────────────
process.on('SIGTERM', async () => {
  console.log('[Worker] Recebido SIGTERM — encerrando gracefully...');
  await pool.end();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('[Worker] Recebido SIGINT — encerrando gracefully...');
  await pool.end();
  process.exit(0);
});

start().catch(err => {
  console.error('[Worker] Erro fatal na inicialização:', err);
  process.exit(1);
});

/**
 * Webhook route for the WhatsApp Worker.
 * Receives real-time events from GoTalk (new messages, ACK updates,
 * attendance open/close, contact updates, operator changes).
 *
 * This is a standalone extraction from server/routes/gotalk.js — only
 * the webhook handler is included here. The CRM server handles all
 * other GoTalk API routes (message reads, send, templates, etc.).
 */

import { Router } from 'express';
import crypto from 'crypto';
import rateLimit from 'express-rate-limit';
import { getChannelId, gotalkFetch } from '../services/gotalkAuth.js';
import {
  normalizePhone,
  departmentToArea,
  upsertAttendance,
  backfillMessagesForAttendance,
  upsertOperatorAttendance,
  upsertAttendanceHistory,
  importOperators,
} from '../services/gotalkPoller.js';
import { transcribeAudio } from '../services/gotalkTranscription.js';

/**
 * Maps a GoTalk channelId (internal hex ID) to the gotalk_channels UUID in our DB.
 * channel_id is NEVER exposed externally — this mapping is used only server-side
 * to log and route events to the correct channel record.
 * Returns null if no matching channel is found.
 */
async function resolveChannelUuid(pool, gotalkChannelId) {
  if (!gotalkChannelId) return null;
  try {
    const r = await pool.query(
      `SELECT id FROM gotalk_channels WHERE channel_id = $1 AND is_active = TRUE LIMIT 1`,
      [gotalkChannelId]
    );
    return r.rows[0]?.id ?? null;
  } catch (_) {
    return null;
  }
}

/**
 * 🔒 SEGURANÇA [VULN-6]: comparação de strings em tempo constante.
 * Previne timing attacks (CWE-208) ao comparar o webhook secret.
 * Retorna false se algum valor estiver ausente ou tiver tamanho diferente.
 */
function timingSafeEqualStr(provided, expected) {
  if (!provided || !expected) return false;
  const a = Buffer.from(String(provided));
  const b = Buffer.from(String(expected));
  if (a.length !== b.length) return false;
  return crypto.timingSafeEqual(a, b);
}

export function createWebhookRoutes(pool) {
  const router = Router();

  // ── Rate limiters ──────────────────────────────────────────────────────────
  // validate.keyGeneratorIpFallback: false suprime o aviso ERR_ERL_KEY_GEN_IPV6
  // porque usamos IP como chave primária intencional (webhooks chegam sem JWT).
  const BASE = { standardHeaders: true, legacyHeaders: false, validate: { keyGeneratorIpFallback: false } };
  const byIp = (req) => req.ip || 'anonymous';

  // Webhook GoTalk: permissivo para rajadas legítimas, bloqueia abuso
  const webhookLimiter = rateLimit({
    ...BASE,
    windowMs: 60 * 1000,
    max: 200,
    keyGenerator: byIp,
    message: { error: 'Muitas requisições ao webhook. Tente novamente em instantes.' },
  });

  // Health check: apenas liveness probe — não precisa ser chamado com frequência
  const healthLimiter = rateLimit({
    ...BASE,
    windowMs: 60 * 1000,
    max: 20,
    keyGenerator: byIp,
    message: { error: 'Limite de health check excedido.' },
  });
  // ──────────────────────────────────────────────────────────────────────────

  let _lastWebhookAt = null;

  // On startup: load GOTALK_WEBHOOK_SECRET from app_data if not in env.
  // This allows the CRM Settings UI to configure the secret and have it
  // automatically picked up by the worker when it restarts.
  (async () => {
    try {
      if (!process.env.GOTALK_WEBHOOK_SECRET) {
        const r = await pool.query(`SELECT value FROM app_data WHERE key = 'gotalk_webhook_secret' LIMIT 1`);
        const stored = r.rows[0]?.value?.secret;
        if (stored) {
          process.env.GOTALK_WEBHOOK_SECRET = stored;
          console.log('[Worker Webhook] GOTALK_WEBHOOK_SECRET carregado do banco de dados.');
        } else {
          console.warn('[Worker Webhook] AVISO: GOTALK_WEBHOOK_SECRET não configurado — ' +
            'o endpoint /api/gotalk/webhook está sem autenticação.');
        }
      }
    } catch (_) {}
  })();

  // GET /health — simple liveness check
  router.get('/health', healthLimiter, (req, res) => {
    res.json({
      status: 'ok',
      lastWebhookAt: _lastWebhookAt,
      uptime: Math.floor(process.uptime()),
      timestamp: new Date().toISOString(),
    });
  });

  // POST /api/gotalk/webhook — receive real-time events from GoTalk
  router.post('/api/gotalk/webhook', webhookLimiter, async (req, res) => {
    const webhookSecret = process.env.GOTALK_WEBHOOK_SECRET;
    if (webhookSecret) {
      const tokenHeader =
        req.headers['x-gotalk-token'] ||
        req.headers['x-webhook-token'] ||
        req.headers['x-hub-signature'] ||
        req.query.token ||
        null;
      // 🔒 SEGURANÇA [VULN-6]: comparação timing-safe — previne timing oracle que
      // permite deduzir o secret caractere por caractere (CWE-208).
      if (!timingSafeEqualStr(tokenHeader, webhookSecret)) {
        console.warn(`[Worker Webhook] Token inválido recusado. IP=${req.ip}`);
        return res.status(401).json({ error: 'Token inválido' });
      }
    }

    // Respond immediately — GoTalk expects a fast 200
    res.status(200).json({ ok: true });
    _lastWebhookAt = new Date().toISOString();

    // Process payload asynchronously so latency doesn't affect delivery
    setImmediate(async () => {
      try {
        const payload = req.body;
        if (!payload || typeof payload !== 'object') return;

        const eventRaw = (payload.event || payload.type || '').toLowerCase();
        // Resolve the GoTalk channelId (from payload) to our gotalk_channels DB UUID.
        // This mapping is purely server-side — the channelId (GoTalk internal hex) is never
        // returned to the frontend; the UUID is what consumers of our DB use.
        const webhookChannelId = payload.channelId || payload.channel_id || null;
        const webhookChannelUuid = await resolveChannelUuid(pool, webhookChannelId);
        if (webhookChannelId && !webhookChannelUuid) {
          console.warn(
            `[Worker Webhook] AVISO: channelId "${webhookChannelId}" não encontrado em gotalk_channels. ` +
            'Canal não registrado ou sincronização pendente. Evento será processado sem UUID de canal.'
          );
        }
        console.log(`[Worker Webhook] event="${eventRaw}" channelUuid=${webhookChannelUuid ?? 'unknown'} keys=${Object.keys(payload).join(',')}`);

        // Normalize ACK value from numeric or textual status
        function parseAckValue(raw) {
          if (raw === undefined || raw === null) return null;
          if (typeof raw === 'number') return raw >= 1 && raw <= 4 ? Math.min(raw, 3) : null;
          const map = {
            'SERVER': 1, 'DEVICE': 2, 'READ': 3, 'PLAYED': 3,
            'sent': 1, 'delivered': 2, 'read': 3,
            '1': 1, '2': 2, '3': 3,
          };
          return map[String(raw)] ?? null;
        }

        // ── ACK update ────────────────────────────────────────────────────
        const isExplicitAckEvent = eventRaw === 'ack' || eventRaw === 'messageack' || eventRaw === 'message.ack';
        const isImplicitAck = payload.ack !== undefined && !payload.message && !payload.data?.message && !payload.body;
        const isAck = isExplicitAckEvent || isImplicitAck;

        if (isAck) {
          const ackData = payload.data || payload;
          const msgId = ackData.messageId || ackData.id || ackData._id || null;
          const ackVal = parseAckValue(ackData.ack ?? ackData.status);
          if (msgId && ackVal !== null) {
            await pool.query(
              `UPDATE gotalk_messages
               SET ack_status = GREATEST(COALESCE(ack_status, 0), $1)
               WHERE gotalk_message_id = $2 AND direction = 'OUT'`,
              [ackVal, msgId]
            );
            console.log(`[Worker Webhook] ACK atualizado: msgId=${msgId} ack=${ackVal}`);
          }
          return;
        }

        // ── Contact-only event ────────────────────────────────────────────
        const isContactEvent =
          (eventRaw === 'contact' || eventRaw === 'newcontact' || eventRaw === 'contactupdate') &&
          !payload.message && !payload.data?.message;

        if (isContactEvent) {
          const rawC = payload.contact || payload.data?.contact || payload.data || null;
          const cId = payload.contactId || rawC?._id || rawC?.id || null;
          const cName = rawC?.name || rawC?.pushname || null;
          const cPhone = rawC?.number || rawC?.phone || null;

          if (cId && (cName || cPhone)) {
            const normPhone = cPhone ? normalizePhone(cPhone) : null;
            const channelId = payload.channelId || await getChannelId().catch(() => null);
            await pool.query(
              `INSERT INTO gotalk_contacts (gotalk_id, name, phone_number, channel_id, gotalk_channel_uuid, imported_at)
               VALUES ($1, $2, $3, $4, $5, NOW())
               ON CONFLICT (gotalk_id) DO UPDATE
                 SET name                = COALESCE(EXCLUDED.name, gotalk_contacts.name),
                     phone_number        = COALESCE(EXCLUDED.phone_number, gotalk_contacts.phone_number),
                     gotalk_channel_uuid = COALESCE(gotalk_contacts.gotalk_channel_uuid, EXCLUDED.gotalk_channel_uuid)`,
              [cId, cName, normPhone, channelId, webhookChannelUuid || null]
            );
            console.log(`[Worker Webhook] Contato upserted: gotalk_id=${cId} name=${cName}`);
          }
          return;
        }

        // ── Attendance event (open/close/update) ──────────────────────────
        const isAttendanceEvent =
          eventRaw === 'newattendance' || eventRaw === 'openattendance' ||
          eventRaw === 'closeattendance' || eventRaw === 'finishattendance' ||
          eventRaw === 'attendanceupdate' || eventRaw === 'attendancefinished' ||
          eventRaw === 'attendance' || eventRaw === 'transferattendance' ||
          eventRaw === 'attendancetransferred';

        if (isAttendanceEvent) {
          const rawAt = payload.attendance || payload.data?.attendance || payload.data || payload;
          const atId = rawAt._id || rawAt.id || null;
          if (atId) {
            try {
              const dbClient = await pool.connect();
              try {
                const attendanceDbId = await upsertAttendance(dbClient, rawAt, null, null, null, webhookChannelUuid || null);
                const isClose = eventRaw === 'closeattendance' || eventRaw === 'finishattendance' ||
                                eventRaw === 'attendancefinished';
                if (isClose) {
                  await dbClient.query(
                    `UPDATE gotalk_attendances SET status = 'closed', ended_at = COALESCE(ended_at, NOW()), updated_at = NOW()
                     WHERE gotalk_attendance_id = $1`,
                    [atId]
                  );
                  await dbClient.query(
                    `UPDATE gotalk_operator_attendances SET status = 'closed', updated_at = NOW()
                     WHERE gotalk_attendance_id = $1`,
                    [atId]
                  );
                }
                if (attendanceDbId) {
                  try { await backfillMessagesForAttendance(dbClient, attendanceDbId); } catch (_) {}
                }

                const isNewOrOpen = eventRaw === 'newattendance' || eventRaw === 'openattendance' || eventRaw === 'attendance';
                if (isNewOrOpen && atId) {
                  const _atPhone = rawAt.clientNumber || rawAt.phone || rawAt.clientPhone || null;
                  const _atChannelId = rawAt.channelId || payload.channelId || null;
                  setImmediate(async () => {
                    try {
                      const _rawPhone = _atPhone ? (normalizePhone(_atPhone) || _atPhone.replace(/\D/g, '')) : null;
                      let phone = _rawPhone;
                      if (phone && !phone.startsWith('55')) phone = '55' + phone;
                      const channelId = _atChannelId || await getChannelId().catch(() => null);
                      if (!phone || !channelId) return;
                      const normPhone = phone;
                      const last10 = normPhone.slice(-10);

                      const msgRes = await gotalkFetch('/message/load_messages', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ attendance: { _id: atId, clientNumber: phone, channelId } }),
                      });
                      if (!msgRes.ok) {
                        console.warn(`[Worker Webhook] Sync imediato falhou (${msgRes.status}) para atendimento ${atId}`);
                        return;
                      }

                      const msgData = await msgRes.json();
                      const messages = Array.isArray(msgData) ? msgData : (msgData.messages || msgData.data || []);

                      let cRow = null;
                      const cRes = await pool.query(
                        `SELECT * FROM gotalk_contacts WHERE RIGHT(COALESCE(phone_number,''), 10) = $1 LIMIT 1`,
                        [last10]
                      );
                      cRow = cRes.rows[0] || null;
                      if (!cRow) {
                        const crmRes = await pool.query(
                          `SELECT id FROM clients
                           WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''), '[^0-9]','','g'), 10) = $1
                              OR RIGHT(REGEXP_REPLACE(COALESCE(phone2,''), '[^0-9]','','g'), 10) = $1
                           LIMIT 1`,
                          [last10]
                        );
                        const crmClientId = crmRes.rows[0]?.id || null;
                        const ins = await pool.query(
                          `INSERT INTO gotalk_contacts (gotalk_id, phone_number, channel_id, gotalk_channel_uuid, client_id, imported_at)
                           VALUES ($1, $2, $3, $4, $5, NOW())
                           ON CONFLICT DO NOTHING RETURNING *`,
                          [`wh_${phone}`, normPhone, channelId, webhookChannelUuid || null, crmClientId]
                        );
                        cRow = ins.rows[0] || null;
                        if (!cRow) {
                          const retry = await pool.query(
                            `SELECT * FROM gotalk_contacts WHERE RIGHT(COALESCE(phone_number,''), 10) = $1 LIMIT 1`,
                            [last10]
                          );
                          cRow = retry.rows[0] || null;
                        }
                      }

                      let saved = 0;
                      const syncClient = await pool.connect();
                      try {
                        for (const msg of messages) {
                          const msgId = msg._id || msg.id;
                          if (!msgId) continue;
                          const dir = (msg.fromMe === true || msg.direction === 'OUT') ? 'OUT' : 'IN';
                          const ts = msg.timestamp;
                          const sentAt = ts ? new Date(typeof ts === 'number' && ts < 1e12 ? ts * 1000 : ts) : new Date();
                          const waMsgType = (msg.type || 'chat').toLowerCase();
                          let messageType = 'TEXT';
                          if (waMsgType === 'image') messageType = 'IMAGE';
                          else if (waMsgType === 'audio' || waMsgType === 'ptt') messageType = 'AUDIO';
                          else if (waMsgType === 'document') messageType = 'DOCUMENT';
                          else if (waMsgType === 'video') messageType = 'VIDEO';
                          const ackStatus = dir === 'OUT' ? (typeof msg.ack === 'number' ? Math.min(msg.ack, 3) : 1) : null;
                          try {
                            const syncMsgDept = rawAt.departmentName || rawAt.department || null;
                            await syncClient.query(
                              `INSERT INTO gotalk_messages
                                 (gotalk_message_id, gotalk_contact_id, client_id, phone_number,
                                  direction, body, message_type, attachment_url, attachment_name,
                                  attachment_mime_type, ack_status, area, gotalk_channel_uuid, sent_at)
                               VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)
                               ON CONFLICT (gotalk_message_id) DO UPDATE
                                 SET gotalk_contact_id   = COALESCE(EXCLUDED.gotalk_contact_id,   gotalk_messages.gotalk_contact_id),
                                     client_id           = COALESCE(EXCLUDED.client_id,           gotalk_messages.client_id),
                                     phone_number        = COALESCE(EXCLUDED.phone_number,        gotalk_messages.phone_number),
                                     area                = COALESCE(gotalk_messages.area, EXCLUDED.area),
                                     gotalk_channel_uuid = COALESCE(gotalk_messages.gotalk_channel_uuid, EXCLUDED.gotalk_channel_uuid)`,
                              [
                                msgId, cRow?.id || null, cRow?.client_id || null, normPhone,
                                dir, msg.body || msg.text || msg.caption || '', messageType,
                                msg.mediaUrl || msg.url || null, msg.fileName || null, msg.mimetype || null,
                                ackStatus, departmentToArea(syncMsgDept), webhookChannelUuid || null, sentAt,
                              ]
                            );
                            saved++;
                          } catch (rowErr) {
                            if (!rowErr.message?.includes('unique') && !rowErr.message?.includes('duplicate')) {
                              console.warn(`[Worker Webhook] Falha ao inserir msg ${msgId}:`, rowErr.message);
                            }
                          }
                        }
                      } finally { syncClient.release(); }

                      console.log(`[Worker Webhook] Sync imediato após ${eventRaw} id=${atId}: ${saved}/${messages.length} mensagem(ns) salva(s).`);
                    } catch (syncErr) {
                      console.warn('[Worker Webhook] Erro no sync imediato de atendimento:', syncErr.message);
                    }
                  });
                }

                if (rawAt.operatorId || rawAt.operatorName || rawAt.nickname) {
                  try {
                    const statusVal = isClose ? 'closed'
                      : (rawAt.status || (eventRaw.includes('transfer') ? 'transferred' : 'in_attendance'));
                    await upsertOperatorAttendance(dbClient, { ...rawAt, status: statusVal }, webhookChannelUuid || null);
                  } catch (opAttErr) {
                    console.warn('[Worker Webhook] Erro ao upsert em operator_attendances:', opAttErr.message);
                  }
                }
                try {
                  const histStatusVal = isClose ? 'closed'
                    : (rawAt.status || (eventRaw.includes('transfer') ? 'transferred'
                      : (eventRaw.includes('finish') ? 'finished' : 'in_attendance')));
                  await upsertAttendanceHistory(dbClient, { ...rawAt, status: histStatusVal }, null, webhookChannelUuid || null);
                } catch (histErr) {
                  console.warn('[Worker Webhook] Erro ao upsert em attendance_history:', histErr.message);
                }
                console.log(`[Worker Webhook] Atendimento processado: id=${atId} event=${eventRaw}`);
              } finally {
                dbClient.release();
              }
            } catch (atErr) {
              console.error('[Worker Webhook] Erro ao processar atendimento:', atErr.message);
            }
          }
          return;
        }

        // ── Message revoke / delete event ────────────────────────────────
        // When GoTalk signals that a message was deleted/revoked (on WhatsApp),
        // we NEVER delete it from the CRM. Instead we mark deleted_in_gotalk = true
        // so the CRM knows the content was removed on the origin while preserving
        // all stored data (body, media, transcript, etc.).
        const isMessageDeleteEvent =
          eventRaw === 'messagerevoked'  || eventRaw === 'message_revoked' ||
          eventRaw === 'messagerevoke'   || eventRaw === 'messagedeleted'  ||
          eventRaw === 'message_deleted' || eventRaw === 'messagedelete'   ||
          eventRaw === 'revoked'         || eventRaw === 'deleted';

        if (isMessageDeleteEvent) {
          const revokedMsg = payload.message || payload.data?.message || payload.data || payload;
          const revokedId  = revokedMsg._id || revokedMsg.id || payload.messageId || payload.id || null;

          if (revokedId) {
            try {
              const result = await pool.query(
                `UPDATE gotalk_messages
                 SET deleted_in_gotalk    = TRUE,
                     deleted_in_gotalk_at = NOW()
                 WHERE gotalk_message_id = $1
                   AND deleted_in_gotalk = FALSE
                 RETURNING id`,
                [revokedId]
              );
              if (result.rowCount > 0) {
                console.log(`[Worker Webhook] Mensagem marcada como deletada na origem (preservada no CRM): msgId=${revokedId}`);
              } else {
                console.log(`[Worker Webhook] Evento de deleção recebido para msgId=${revokedId} — não encontrada ou já marcada. Ignorado.`);
              }
            } catch (delErr) {
              console.error('[Worker Webhook] Erro ao marcar mensagem como deletada na origem:', delErr.message);
            }
          } else {
            console.log(`[Worker Webhook] Evento de deleção sem messageId identificável — ignorado. event="${eventRaw}"`);
          }
          return;
        }

        // ── Operator event (create / update / delete) ────────────────────
        const isOperatorEvent =
          eventRaw.includes('operator') ||
          eventRaw === 'newuser' || eventRaw === 'usercreated' ||
          eventRaw === 'userupdated' || eventRaw === 'userdeleted' ||
          eventRaw === 'agentcreated' || eventRaw === 'agentupdated' || eventRaw === 'agentdeleted';

        if (isOperatorEvent) {
          const rawOp = payload.operator || payload.user || payload.agent ||
                        payload.data?.operator || payload.data?.user || payload.data || null;

          if (rawOp && (rawOp._id || rawOp.id)) {
            try {
              const gotalkOpId = rawOp._id || rawOp.id;
              const name  = rawOp.name  || rawOp.nome  || rawOp.nickname || null;
              const email = rawOp.email || null;
              const phone = rawOp.phone || rawOp.telefone || rawOp.number || null;
              const isDeleted = rawOp.deleted === true ||
                                eventRaw.includes('delet') || eventRaw.includes('remov');
              const active = !isDeleted && rawOp.active !== false;

              await pool.query(
                `INSERT INTO gotalk_operators
                   (gotalk_operator_id, name, email, phone, active, raw_data)
                 VALUES ($1, $2, $3, $4, $5, $6::jsonb)
                 ON CONFLICT (gotalk_operator_id) DO UPDATE SET
                   name       = COALESCE(EXCLUDED.name,  gotalk_operators.name),
                   email      = COALESCE(EXCLUDED.email, gotalk_operators.email),
                   phone      = COALESCE(EXCLUDED.phone, gotalk_operators.phone),
                   active     = EXCLUDED.active,
                   raw_data   = EXCLUDED.raw_data,
                   updated_at = NOW()`,
                [gotalkOpId, name, email,
                 phone ? normalizePhone(phone) : null,
                 active, JSON.stringify(rawOp)]
              );
              console.log(`[Worker Webhook] Operador upserted: id=${gotalkOpId} name=${name} active=${active} event=${eventRaw}`);
            } catch (opErr) {
              console.error('[Worker Webhook] Erro ao processar operador:', opErr.message);
            }
          }

          importOperators().catch(e => console.error('[Worker Webhook] Re-sync de operadores falhou:', e.message));
          return;
        }

        // ── New message event ─────────────────────────────────────────────
        let rawMsg = null;
        let rawContact = null;

        if (payload.message) {
          rawMsg = payload.message;
          rawContact = payload.contact || null;
        } else if (payload.data?.message) {
          rawMsg = payload.data.message;
          rawContact = payload.data.contact || null;
        } else if (payload.data && (payload.data._id || payload.data.id)) {
          rawMsg = payload.data;
          rawContact = null;
        } else if (payload._id || (payload.id && typeof payload.id === 'string')) {
          rawMsg = payload;
          rawContact = null;
        }

        if (!rawMsg) {
          console.log('[Worker Webhook] Payload sem mensagem reconhecível — ignorado.');
          return;
        }

        const gotalkMsgId = rawMsg._id || rawMsg.id || null;
        const fromMe = rawMsg.fromMe === true || rawMsg.direction === 'OUT';
        const direction = fromMe ? 'OUT' : 'IN';
        const body = rawMsg.body || rawMsg.text || rawMsg.caption || '';
        const ts = rawMsg.timestamp;
        const sentAt = ts
          ? new Date(typeof ts === 'number' && ts < 1e12 ? ts * 1000 : ts)
          : new Date();

        let messageType = 'TEXT';
        let attachmentUrl = rawMsg.mediaUrl || rawMsg.url || null;
        let attachmentName = rawMsg.fileName || null;
        let attachmentMime = rawMsg.mimetype || null;
        const waMsgType = (rawMsg.type || 'chat').toLowerCase();
        if (waMsgType === 'image') { messageType = 'IMAGE'; attachmentMime = attachmentMime || 'image/jpeg'; }
        else if (waMsgType === 'audio' || waMsgType === 'ptt') { messageType = 'AUDIO'; attachmentMime = attachmentMime || 'audio/ogg'; }
        else if (waMsgType === 'document') { messageType = 'DOCUMENT'; attachmentMime = attachmentMime || 'application/octet-stream'; }
        else if (waMsgType === 'video') { messageType = 'VIDEO'; attachmentMime = attachmentMime || 'video/mp4'; }
        else if (waMsgType === 'sticker') { messageType = 'STICKER'; }

        const ackStatus = direction === 'OUT' ? (rawMsg.ack !== undefined ? parseInt(rawMsg.ack, 10) : 1) : null;

        const gotalkContactId = payload.contactId || rawContact?._id || rawMsg.contactId || null;
        const contactName = rawContact?.name || rawContact?.pushname || null;
        const contactPhone =
          rawContact?.number || rawContact?.phone ||
          rawMsg.clientNumber || payload.clientNumber ||
          (fromMe ? (rawMsg.to || rawMsg.phoneNumber) : null) || null;

        if (!gotalkContactId && !contactPhone) {
          if (fromMe) {
            console.warn(
              `[Worker Webhook] Mensagem OUT sem contato identificável. ` +
              `Payload preview: ${JSON.stringify(payload).slice(0, 500)}`
            );
          } else {
            console.log('[Worker Webhook] Sem contactId nem telefone — não é possível identificar o contato.');
          }
          return;
        }

        const dbClient = await pool.connect();
        try {
          let contactRow = null;

          if (gotalkContactId) {
            const r = await dbClient.query(
              `SELECT * FROM gotalk_contacts WHERE gotalk_id = $1`, [gotalkContactId]
            );
            contactRow = r.rows[0] || null;
          }

          if (!contactRow && contactPhone) {
            const normPhone = normalizePhone(contactPhone);
            const r = await dbClient.query(
              `SELECT * FROM gotalk_contacts WHERE phone_number = $1 LIMIT 1`, [normPhone]
            );
            contactRow = r.rows[0] || null;
          }

          if (!contactRow) {
            const normPhone = contactPhone ? normalizePhone(contactPhone) : null;
            const channelId = payload.channelId || await getChannelId().catch(() => null);
            const ins = await dbClient.query(
              `INSERT INTO gotalk_contacts (gotalk_id, name, phone_number, channel_id, gotalk_channel_uuid, imported_at)
               VALUES ($1, $2, $3, $4, $5, NOW())
               ON CONFLICT (gotalk_id) DO UPDATE
                 SET name                = COALESCE(EXCLUDED.name, gotalk_contacts.name),
                     gotalk_channel_uuid = COALESCE(EXCLUDED.gotalk_channel_uuid, gotalk_contacts.gotalk_channel_uuid)
               RETURNING *`,
              [gotalkContactId || `wh_${normPhone}`, contactName, normPhone, channelId, webhookChannelUuid]
            );
            contactRow = ins.rows[0];
          } else if (contactName && !contactRow.name) {
            await dbClient.query(
              `UPDATE gotalk_contacts SET name = $1 WHERE id = $2`, [contactName, contactRow.id]
            );
            contactRow.name = contactName;
          }
          // Backfill channel UUID if missing (e.g., contact was imported before multi-channel support)
          if (webhookChannelUuid && contactRow && !contactRow.gotalk_channel_uuid) {
            await dbClient.query(
              `UPDATE gotalk_contacts SET gotalk_channel_uuid = $1 WHERE id = $2`,
              [webhookChannelUuid, contactRow.id]
            );
            contactRow.gotalk_channel_uuid = webhookChannelUuid;
          }

          if (!contactRow.client_id && contactRow.phone_number) {
            const norm = normalizePhone(contactRow.phone_number);
            const last10 = norm.slice(-10);
            const clientMatch = await dbClient.query(
              `SELECT id FROM clients
               WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''), '[^0-9]','','g'), 10) = $1
                  OR RIGHT(REGEXP_REPLACE(COALESCE(phone2,''), '[^0-9]','','g'), 10) = $1
               LIMIT 1`,
              [last10]
            );
            if (clientMatch.rows.length > 0) {
              const clientId = clientMatch.rows[0].id;
              await dbClient.query(
                `UPDATE gotalk_contacts SET client_id = $1, linked_at = NOW() WHERE id = $2`,
                [clientId, contactRow.id]
              );
              await dbClient.query(
                `UPDATE gotalk_messages SET client_id = $1 WHERE gotalk_contact_id = $2 AND client_id IS NULL`,
                [clientId, contactRow.id]
              );
              await dbClient.query(
                `UPDATE clients SET gotalk_contact_id = $1 WHERE id = $2`,
                [contactRow.id, clientId]
              );
              contactRow.client_id = clientId;
              console.log(`[Worker Webhook] Contato ${contactRow.gotalk_id} vinculado ao cliente ${clientId} por telefone.`);
            }
          }

          if (gotalkMsgId) {
            const existing = await dbClient.query(
              `SELECT id, ack_status FROM gotalk_messages WHERE gotalk_message_id = $1`, [gotalkMsgId]
            );
            if (existing.rows.length > 0) {
              if (direction === 'OUT' && ackStatus !== null) {
                await dbClient.query(
                  `UPDATE gotalk_messages SET ack_status = GREATEST(COALESCE(ack_status, 0), $1) WHERE id = $2`,
                  [ackStatus, existing.rows[0].id]
                );
              }
              return;
            }
          }

          let audioTranscript = null;
          if (direction === 'IN' && messageType === 'AUDIO' && attachmentUrl) {
            try {
              audioTranscript = await transcribeAudio(attachmentUrl, attachmentMime || 'audio/ogg');
            } catch (tErr) {
              console.warn('[Worker Webhook] Falha ao transcrever áudio:', tErr.message);
            }
          }

          let attendanceDbId = null;
          let attendanceHistoryId = null;
          const gotalkAttendanceId = payload.attendanceId || payload.attendance?._id || payload.attendance?.id || rawMsg.attendanceId || null;
          const idwppVal = rawMsg.idWpp || null;
          if (gotalkAttendanceId) {
            const atRow = await dbClient.query(
              `SELECT id FROM gotalk_attendances WHERE gotalk_attendance_id = $1 LIMIT 1`,
              [gotalkAttendanceId]
            );
            attendanceDbId = atRow.rows[0]?.id || null;

            const histRow = await dbClient.query(
              `SELECT id FROM gotalk_attendance_history WHERE gotalk_attendance_id = $1 LIMIT 1`,
              [gotalkAttendanceId]
            );
            attendanceHistoryId = histRow.rows[0]?.id || null;
          }

          const whMsgDept = payload.attendance?.departmentName
            || payload.attendance?.department
            || payload.departmentName || payload.department || null;
          await dbClient.query(
            `INSERT INTO gotalk_messages
               (gotalk_message_id, idwpp, gotalk_contact_id, client_id, phone_number,
                direction, body, message_type,
                attachment_url, attachment_name, attachment_mime_type,
                audio_transcript, ack_status, attendance_id,
                gotalk_attendance_id_ext, attendance_history_id,
                area, gotalk_channel_uuid, sent_at)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
             ON CONFLICT (gotalk_message_id) DO UPDATE SET
               ack_status               = CASE WHEN EXCLUDED.ack_status IS NOT NULL THEN EXCLUDED.ack_status ELSE gotalk_messages.ack_status END,
               attendance_history_id    = COALESCE(EXCLUDED.attendance_history_id, gotalk_messages.attendance_history_id),
               gotalk_attendance_id_ext = COALESCE(EXCLUDED.gotalk_attendance_id_ext, gotalk_messages.gotalk_attendance_id_ext),
               idwpp                    = COALESCE(EXCLUDED.idwpp, gotalk_messages.idwpp),
               area                     = COALESCE(gotalk_messages.area, EXCLUDED.area),
               gotalk_channel_uuid      = COALESCE(gotalk_messages.gotalk_channel_uuid, EXCLUDED.gotalk_channel_uuid)`,
            [
              gotalkMsgId, idwppVal, contactRow.id, contactRow.client_id || null,
              normalizePhone(contactRow.phone_number || ''),
              direction, body, messageType,
              attachmentUrl, attachmentName, attachmentMime,
              audioTranscript, ackStatus, attendanceDbId,
              gotalkAttendanceId, attendanceHistoryId,
              departmentToArea(whMsgDept), webhookChannelUuid || contactRow.gotalk_channel_uuid || null, sentAt,
            ]
          );

          console.log(`[Worker Webhook] Mensagem salva: dir=${direction} type=${messageType} contact=${contactRow.gotalk_id}`);

          // Notifica o servidor CRM via PostgreSQL NOTIFY (apenas mensagens recebidas).
          // O servidor CRM escuta 'gotalk_new_message' e emite via Socket.io para o frontend,
          // eliminando o polling de 30s no cliente.
          if (direction === 'IN') {
            pool.query(`SELECT pg_notify('gotalk_new_message', $1)`, [
              JSON.stringify({
                direction,
                messageType,
                phone: normalizePhone(contactRow.phone_number || ''),
                clientId: contactRow.client_id || null,
              })
            ]).catch(() => {});
          }
        } finally {
          dbClient.release();
        }
      } catch (err) {
        console.error('[Worker Webhook] Erro ao processar payload:', err.message);
      }
    });
  });

  return router;
}

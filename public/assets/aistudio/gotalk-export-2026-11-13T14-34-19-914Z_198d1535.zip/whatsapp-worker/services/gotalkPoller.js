/**
 * Gotalk Polling Service
 * Continuously imports contacts and messages from Gotalk every 5 minutes.
 * Runs completely independently of the HTTP request cycle.
 */

import { gotalkFetch, getChannelId, authenticate } from './gotalkAuth.js';
import { transcribeAudio } from './gotalkTranscription.js';
import { syncAllChannels } from './gotalkChannels.js';
import { createBoundedPollerScheduler } from './boundedPollerScheduler.js';

// ─── Prospection auto-register ───────────────────────────────────────────
// prospection_contacts is kept in sync by the database trigger
// trg_sync_prospection_gotalk (migration 043), which fires on every inserted
// incoming gotalk_messages row regardless of which process performs the insert
// (worker webhook, this poller, CRM poller, recovery). The previous inline
// upsert was removed to make the trigger the single source of truth and avoid
// double-counting total_contacts.

// ─── Intervalos por criticidade ────────────────────────────────────────────
// Alta: atendimentos ativos (estado do atendimento)             → a cada 30s
// Reconciliação: mensagens (fallback para webhooks perdidos)    → a cada 5 min
// Média: histórico de atendimentos, mensagens históricas, ACK  → a cada 2 min
// Baixa: contatos, operadores (raramente mudam)                 → a cada 10 min
//
// NOTA: mensagens chegam via WEBHOOK em tempo real (webhook-first).
// O ciclo de reconciliação de 5 min cobre apenas mensagens que chegaram sem
// webhook (falhas de rede, reinicializações do uazapi etc.).
const INTERVAL_HIGH_MS    =   30 * 1000;  // 30 segundos
const INTERVAL_RECONCILE_MS = 5 * 60 * 1000; // 5 minutos (reconciliação de mensagens)
const INTERVAL_MEDIUM_MS  =  2 * 60 * 1000;  // 2 minutos
const INTERVAL_LOW_MS     = 10 * 60 * 1000;  // 10 minutos

let _pool = null;
let _timers = [];

// O worker também roda embutido no servidor HTTP e compartilha seu pool.
// Limitar tarefas distintas preserva conexões para as telas e outras rotinas.
const _scheduler = createBoundedPollerScheduler({ concurrency: 2 });
let _pollerGeneration = 0;

// ─── Phone normalisation ───────────────────────────────────────────────────
function normalizePhone(raw) {
  if (!raw) return null;
  // Strip everything except digits
  let digits = String(raw).replace(/\D/g, '');
  // Remove leading country code 55 (Brazil) if present, keep last 10-11 digits
  if (digits.startsWith('55') && digits.length > 11) digits = digits.slice(2);
  return digits || null;
}

function phonesMatch(a, b) {
  const na = normalizePhone(a);
  const nb = normalizePhone(b);
  if (!na || !nb) return false;
  // Compare last 10 digits (handles 8 or 9-digit local numbers)
  return na.slice(-10) === nb.slice(-10);
}

// ─── Department → Area mapping ─────────────────────────────────────────────
// Maps GoTalk department name to the gotalk_messages.area enum value.
// Returns null when no match is found (area remains null — not an error).
function departmentToArea(deptName) {
  if (!deptName) return null;
  const n = deptName.trim().toLowerCase();
  if (n.includes('cobran') && (n.includes('coord') || n.includes('gest'))) return 'COBRANCA_COORD';
  if (n.includes('cobran') && n.includes('op'))   return 'COBRANCA_OP';
  if (n.includes('cobran'))   return 'COBRANCA';
  if (n.includes('admiss'))   return 'ADMISSAO';
  if (n.includes('jur'))      return 'JURIDICO';
  if (n.includes('negoci'))   return 'NEGOCIACAO';
  return null;
}

// ─── Extract ACK status from a raw Gotalk message object ──────────────────
// WhatsApp ACK values: 1=sent to server, 2=delivered to device, 3=read
// Gotalk may expose this as msg.ack (numeric) or msg.status (string).
function extractAck(msg) {
  // Numeric ack field (most common in whatsapp-web.js based APIs)
  if (typeof msg.ack === 'number' && msg.ack >= 1 && msg.ack <= 4) {
    // Cap at 3 (some APIs use 4 for played audio)
    return Math.min(msg.ack, 3);
  }
  // String ack field
  if (typeof msg.ack === 'string') {
    const map = { 'SERVER': 1, 'DEVICE': 2, 'READ': 3, 'PLAYED': 3,
                  'sent': 1, 'delivered': 2, 'read': 3, '1': 1, '2': 2, '3': 3 };
    if (map[msg.ack] !== undefined) return map[msg.ack];
  }
  // Fallback: status string field
  if (typeof msg.status === 'string') {
    const map = { 'sent': 1, 'delivered': 2, 'read': 3,
                  'SERVER': 1, 'DEVICE': 2, 'READ': 3 };
    if (map[msg.status] !== undefined) return map[msg.status];
  }
  // For OUT messages with no ack info, assume at least sent=1
  return null;
}

// ─── Link contact to a CRM client by phone ────────────────────────────────
async function linkContactToClientByPhone(dbClient, gotalkContactId, phoneNumber) {
  if (!phoneNumber) return null;

  const norm = normalizePhone(phoneNumber);
  if (!norm) return null;

  // Find CRM client by phone (try both phone and phone2)
  const res = await dbClient.query(
    `SELECT id FROM clients
     WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''), '[^0-9]', '', 'g'), 10) = $1
        OR RIGHT(REGEXP_REPLACE(COALESCE(phone2,''), '[^0-9]', '', 'g'), 10) = $1
     LIMIT 1`,
    [norm.slice(-10)]
  );

  if (res.rows.length === 0) return null;
  const clientId = res.rows[0].id;

  // Link in gotalk_contacts
  await dbClient.query(
    `UPDATE gotalk_contacts SET client_id = $1, linked_at = NOW() WHERE id = $2`,
    [clientId, gotalkContactId]
  );

  // Retroactively fill client_id on all existing messages for this contact
  await dbClient.query(
    `UPDATE gotalk_messages SET client_id = $1
     WHERE gotalk_contact_id = $2 AND client_id IS NULL`,
    [clientId, gotalkContactId]
  );

  // Retroactively fill client_id on attendances already imported for this contact.
  // AND client_id IS NULL is intentional — it avoids overwriting manual links or
  // corrections already applied to previously imported attendances.
  await dbClient.query(
    `UPDATE gotalk_attendances SET client_id = $1
     WHERE gotalk_contact_id = $2 AND client_id IS NULL`,
    [clientId, gotalkContactId]
  );

  // Update clients table with gotalk_contact_id + gotalk_channel_id
  const contactRow = await dbClient.query(
    `SELECT channel_id FROM gotalk_contacts WHERE id = $1`, [gotalkContactId]
  );
  const channelId = contactRow.rows[0]?.channel_id || null;
  await dbClient.query(
    `UPDATE clients SET gotalk_contact_id = $1, gotalk_channel_id = $2
     WHERE id = $3 AND gotalk_contact_id IS NULL`,
    [gotalkContactId, channelId, clientId]
  );

  return clientId;
}

// ─── Import all contacts from Gotalk ──────────────────────────────────────
// channelId is optional — when provided (multi-channel mode) it is used directly;
// when omitted the primary channelId is fetched from the auth service.
async function importContacts(channelId, channelUuid = null) {
  if (!channelId) channelId = await getChannelId();
  if (!channelId) return;

  // Resolve channel UUID if not provided (enables FK population even for primary-channel calls)
  if (!channelUuid) {
    try {
      const chRes = await _pool.query(
        `SELECT id FROM gotalk_channels WHERE channel_id = $1 AND is_active = TRUE LIMIT 1`,
        [channelId]
      );
      channelUuid = chRes.rows[0]?.id || null;
    } catch (chErr) {
      console.warn('[Gotalk Poller] Erro ao resolver channel UUID em importContacts:', chErr.message);
    }
  }

  let page = 1;
  let imported = 0;
  let linked = 0;

  while (true) {
    const res = await gotalkFetch(`/contact/channel/${channelId}/page/${page}`);
    if (!res.ok) break;

    const data = await res.json();
    const contacts = Array.isArray(data) ? data : (data.contacts || data.data || []);
    if (contacts.length === 0) break;

    const dbClient = await _pool.connect();
    try {
      for (const contact of contacts) {
        const gotalkId = contact._id || contact.id;
        const name = contact.name || contact.nome || '';
        const phoneNumber = contact.number || contact.phone || contact.telefone || '';
        const rawData = JSON.stringify(contact);

        // Upsert contact — include gotalk_channel_uuid when known
        const upsertRes = await dbClient.query(
          `INSERT INTO gotalk_contacts (gotalk_id, name, phone_number, channel_id, gotalk_channel_uuid, raw_data)
           VALUES ($1, $2, $3, $4, $5, $6::jsonb)
           ON CONFLICT (gotalk_id) DO UPDATE SET
             name = EXCLUDED.name,
             phone_number = EXCLUDED.phone_number,
             channel_id = EXCLUDED.channel_id,
             gotalk_channel_uuid = COALESCE(EXCLUDED.gotalk_channel_uuid, gotalk_contacts.gotalk_channel_uuid),
             raw_data = EXCLUDED.raw_data
           RETURNING id, client_id`,
          [gotalkId, name, normalizePhone(phoneNumber), channelId, channelUuid, rawData]
        );

        const row = upsertRes.rows[0];
        imported++;

        // Auto-link to client if not yet linked
        if (!row.client_id && row.id) {
          const clientId = await linkContactToClientByPhone(dbClient, row.id, phoneNumber);
          if (clientId) linked++;
        }
      }
    } finally {
      dbClient.release();
    }

    if (contacts.length < 9) break; // Gotalk returns 9 per page
    page++;
  }

  if (imported > 0) {
    console.log(`[Gotalk Poller] Contatos importados: ${imported}, vinculados: ${linked}`);
  }
}

// ─── Import messages for a specific contact ───────────────────────────────
async function importMessagesForContact(contactRow) {
  const { id: contactDbId, gotalk_id: gotalkContactId } = contactRow;

  // Try to fetch attendance/messages for this contact
  // Gotalk returns messages through attendances (atendimentos)
  let res = await gotalkFetch(`/attendance/contact/${gotalkContactId}`);
  if (!res.ok) {
    // Fallback: try direct contact messages endpoint
    res = await gotalkFetch(`/messages/contact/${gotalkContactId}`);
    if (!res.ok) return;
  }

  const data = await res.json();
  const messages = Array.isArray(data) ? data : (data.messages || data.data || []);

  if (messages.length === 0) return;

  const dbClient = await _pool.connect();
  try {
    for (const msg of messages) {
      const gotalkMsgId = msg._id || msg.id;
      const direction = msg.fromMe === true || msg.direction === 'OUT' ? 'OUT' : 'IN';
      const body = msg.body || msg.message || msg.text || '';
      const sentAt = msg.timestamp
        ? new Date(typeof msg.timestamp === 'number' ? msg.timestamp * 1000 : msg.timestamp)
        : new Date();

      // Extract ack status for outgoing messages
      const ackStatus = direction === 'OUT' ? (extractAck(msg) || 1) : null;

      // Determine message type
      let messageType = 'TEXT';
      let attachmentUrl = null;
      let attachmentName = null;
      let attachmentMime = null;
      let audioTranscript = null;

      if (msg.type === 'audio' || msg.type === 'ptt') {
        messageType = 'AUDIO';
        attachmentUrl = msg.mediaUrl || msg.url || null;
        attachmentMime = msg.mimetype || 'audio/ogg';
      } else if (msg.type === 'image') {
        messageType = 'IMAGE';
        attachmentUrl = msg.mediaUrl || msg.url || null;
        attachmentMime = msg.mimetype || 'image/jpeg';
        attachmentName = msg.fileName || 'imagem';
      } else if (msg.type === 'document') {
        messageType = 'DOCUMENT';
        attachmentUrl = msg.mediaUrl || msg.url || null;
        attachmentName = msg.fileName || msg.caption || 'documento';
        attachmentMime = msg.mimetype || 'application/octet-stream';
      } else if (msg.type === 'video') {
        messageType = 'VIDEO';
        attachmentUrl = msg.mediaUrl || msg.url || null;
        attachmentMime = msg.mimetype || 'video/mp4';
      }

      // Check if message already exists
      const existing = await dbClient.query(
        `SELECT id, audio_transcript, ack_status FROM gotalk_messages WHERE gotalk_message_id = $1`,
        [gotalkMsgId]
      );

      if (existing.rows.length > 0) {
        const row = existing.rows[0];

        // IMUTABILIDADE: mensagens já armazenadas no CRM NUNCA são deletadas pelo poller,
        // mesmo que o GoTalk não as retorne mais (ex: deletadas no WhatsApp).
        // Apenas campos incrementais (ack_status, audio_transcript) são atualizados.

        // Update ack_status if we have a better (higher) value
        if (direction === 'OUT' && ackStatus !== null && (row.ack_status === null || ackStatus > row.ack_status)) {
          await dbClient.query(
            `UPDATE gotalk_messages SET ack_status = $1 WHERE id = $2`,
            [ackStatus, row.id]
          );
        }

        // Update audio transcript if missing
        if (messageType === 'AUDIO' && !row.audio_transcript && attachmentUrl) {
          audioTranscript = await transcribeAudio(attachmentUrl, attachmentMime);
          if (audioTranscript) {
            await dbClient.query(
              `UPDATE gotalk_messages SET audio_transcript = $1 WHERE id = $2`,
              [audioTranscript, row.id]
            );
          }
        }
        continue;
      }

      // For outgoing messages (OUT), check if we already have an optimistic insert
      // (gotalk_message_id IS NULL) for the same contact+body within the last 10 minutes
      if (direction === 'OUT') {
        const optimistic = await dbClient.query(
          `SELECT id FROM gotalk_messages
           WHERE gotalk_contact_id = $1
             AND direction = 'OUT'
             AND body = $2
             AND gotalk_message_id IS NULL
             AND sent_at > NOW() - INTERVAL '10 minutes'
           LIMIT 1`,
          [contactDbId, body]
        );
        if (optimistic.rows.length > 0) {
          // Update optimistic row with real gotalk_message_id and ack_status
          await dbClient.query(
            `UPDATE gotalk_messages SET gotalk_message_id = $1, ack_status = GREATEST(COALESCE(ack_status, 1), $2) WHERE id = $3`,
            [gotalkMsgId, ackStatus || 1, optimistic.rows[0].id]
          );
          continue;
        }
      }

      // Transcribe audio if needed
      if (messageType === 'AUDIO' && attachmentUrl) {
        audioTranscript = await transcribeAudio(attachmentUrl, attachmentMime);
      }

      const msgDeptName = msg.departmentName || msg.department || null;
      const insertResult = await dbClient.query(
        `INSERT INTO gotalk_messages
           (gotalk_message_id, gotalk_contact_id, client_id, phone_number,
            direction, body, message_type,
            attachment_url, attachment_name, attachment_mime_type, audio_transcript,
            operator_name, department, area, ack_status, sent_at)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16)
         ON CONFLICT (gotalk_message_id) DO UPDATE SET
           area = COALESCE(gotalk_messages.area, EXCLUDED.area)
         RETURNING (xmax = 0) AS inserted`,
        [
          gotalkMsgId,
          contactDbId,
          contactRow.client_id || null,
          normalizePhone(contactRow.phone_number),
          direction,
          body,
          messageType,
          attachmentUrl,
          attachmentName,
          attachmentMime,
          audioTranscript,
          msg.operatorName || msg.operator || null,
          msgDeptName,
          departmentToArea(msgDeptName),
          ackStatus,
          sentAt,
        ]
      );

      // prospection_contacts is kept in sync by the DB trigger
      // trg_sync_prospection_gotalk (migration 043), which fires on every
      // inserted incoming gotalk_messages row. No app-level upsert here to
      // avoid double-counting total_contacts.
    }
  } finally {
    dbClient.release();
  }
}

// ─── Refresh ACK status for recent OUT messages not yet fully confirmed ───
// Called each poll cycle to keep ack_status up-to-date for messages
// that were sent but haven't been marked as read (ack < 3) yet.
async function refreshStaleAckMessages() {
  const dbClient = await _pool.connect();
  let staleContacts;
  try {
    // Find contacts with OUT messages that have ack_status < 3 (or null) within last 24h.
    // Load full contact row (id, gotalk_id, phone_number, client_id) so importMessagesForContact
    // has complete data when inserting any newly discovered messages in the same re-fetch.
    const res = await dbClient.query(
      `SELECT DISTINCT gc.id, gc.gotalk_id, gc.phone_number, gc.client_id
       FROM gotalk_messages gm
       JOIN gotalk_contacts gc ON gc.id = gm.gotalk_contact_id
       WHERE gm.direction = 'OUT'
         AND (gm.ack_status IS NULL OR gm.ack_status < 3)
         AND gm.sent_at < NOW() - INTERVAL '5 minutes'
         AND gm.sent_at > NOW() - INTERVAL '24 hours'
       LIMIT 50`
    );
    staleContacts = res.rows;
  } finally {
    dbClient.release();
  }

  for (const contact of staleContacts) {
    try {
      // Re-fetch messages for this contact; importMessagesForContact will update ack
      await importMessagesForContact(contact);
    } catch (err) {
      // Best-effort, ignore errors
    }
  }
}

// ─── Import messages for all known contacts ───────────────────────────────
async function importAllMessages() {
  const dbClient = await _pool.connect();
  let contacts;
  try {
    const res = await dbClient.query(`SELECT id, gotalk_id, phone_number, client_id FROM gotalk_contacts`);
    contacts = res.rows;
  } finally {
    dbClient.release();
  }

  for (const contact of contacts) {
    try {
      await importMessagesForContact(contact);
    } catch (err) {
      console.error(`[Gotalk Poller] Erro ao importar mensagens do contato ${contact.gotalk_id}:`, err.message);
    }
  }
}

// ─── Timestamp parsing helper ─────────────────────────────────────────────
// GoTalk may return timestamps as ISO strings, Unix seconds (10-digit number),
// or Unix milliseconds (13-digit number). Returns a Date or null.
function parseGoTalkTimestamp(raw) {
  if (!raw) return null;
  if (raw instanceof Date) return raw;
  if (typeof raw === 'number') {
    // Heuristic: 10-digit = seconds, 13-digit = milliseconds
    const ts = raw < 1e12 ? raw * 1000 : raw;
    const d = new Date(ts);
    return isNaN(d.getTime()) ? null : d;
  }
  if (typeof raw === 'string') {
    // Try ISO parse first; if that fails try numeric coercion
    const d = new Date(raw);
    if (!isNaN(d.getTime())) return d;
    const n = Number(raw);
    if (!isNaN(n)) return parseGoTalkTimestamp(n);
  }
  return null;
}

// ─── Name-matching helpers for operator auto-link ─────────────────────────
// normalizeNameForMatch: strips accents, punctuation and extra whitespace,
// lowercases — returns a stable token string for comparison.
function normalizeNameForMatch(str) {
  if (!str) return '';
  return str
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '') // strip combining accents
    .replace(/[^a-z0-9\s]/gi, '')    // remove punctuation/symbols
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

// wordOverlapScore: Jaccard-like token overlap ratio.
// "joao silva" vs "joao m silva" → tokens shared / union = 2/3 ≈ 0.67
// A threshold of 0.75 is conservative (requires most name tokens to match).
function wordOverlapScore(a, b) {
  const ta = new Set(a.split(' ').filter(Boolean));
  const tb = new Set(b.split(' ').filter(Boolean));
  if (ta.size === 0 || tb.size === 0) return 0;
  let shared = 0;
  ta.forEach(w => { if (tb.has(w)) shared++; });
  return shared / (ta.size + tb.size - shared);
}

// ─── Import operators from GoTalk ─────────────────────────────────────────
// Fetches all operators/attendants registered in GoTalk and upserts them into
// gotalk_operators. Attempts to auto-link each operator to a CRM collaborator
// by matching on phone (last 10 digits) or similar name (normalized word overlap).
// channelId is optional — when provided (multi-channel mode) it is used in Strategy 0;
// when omitted the primary channelId is fetched from the auth service.
async function importOperators(channelId) {
  let imported = 0;
  let linked = 0;

  // Helper: extract operator list from various GoTalk response shapes.
  // Always returns a plain array — candidate fields are only used when they are arrays,
  // preventing TypeErrors when data.data or data.users is an object (common API pattern).
  const extractOperators = data => {
    if (Array.isArray(data)) return data;
    for (const key of ['operators', 'data', 'users', 'agents']) {
      if (Array.isArray(data[key])) return data[key];
    }
    return [];
  };

  // Helper: upsert a batch of operators and auto-link to collaborators.
  // Returns { imp, lnk } counts so callers can accumulate totals.
  async function processOperatorBatch(operators) {
    let batchImported = 0;
    let batchLinked = 0;
    const dbClient = await _pool.connect();
    try {
      for (const op of operators) {
        const gotalkOpId = op._id || op.id;
        if (!gotalkOpId) continue;

        const name  = op.name  || op.nome  || null;
        const email = op.email || null;
        const phone = normalizePhone(op.phone || op.telefone || op.number || null);

        const upsertRes = await dbClient.query(
          `INSERT INTO gotalk_operators
             (gotalk_operator_id, name, email, phone, active, raw_data)
           VALUES ($1, $2, $3, $4, $5, $6::jsonb)
           ON CONFLICT (gotalk_operator_id) DO UPDATE SET
             name       = COALESCE(EXCLUDED.name, gotalk_operators.name),
             email      = COALESCE(EXCLUDED.email, gotalk_operators.email),
             phone      = COALESCE(EXCLUDED.phone, gotalk_operators.phone),
             active     = EXCLUDED.active,
             raw_data   = EXCLUDED.raw_data,
             updated_at = NOW()
           RETURNING id, collaborator_id`,
          [gotalkOpId, name, email, phone, op.active !== false, JSON.stringify(op)]
        );

        const opRow = upsertRes.rows[0];
        batchImported++;

        if (opRow.collaborator_id) continue;

        // Auto-link: try phone match first
        if (phone) {
          const byPhone = await dbClient.query(
            `SELECT id FROM collaborators
             WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''), '[^0-9]', '', 'g'), 10) = $1
             LIMIT 1`,
            [phone.slice(-10)]
          );
          if (byPhone.rows.length > 0) {
            await dbClient.query(
              `UPDATE gotalk_operators SET collaborator_id = $1, updated_at = NOW() WHERE id = $2`,
              [byPhone.rows[0].id, opRow.id]
            );
            batchLinked++;
            continue;
          }
        }

        // Auto-link: try name similarity (normalized word overlap, accent-insensitive).
        // Uses unaccent() if available, falls back to plain LOWER LIKE.
        if (name) {
          const normOp = normalizeNameForMatch(name);
          if (normOp.length >= 3) {
            try {
              const prefix = normOp.split(' ')[0];
              let candidates;
              try {
                candidates = await dbClient.query(
                  `SELECT id, name FROM collaborators
                   WHERE unaccent(LOWER(name)) LIKE unaccent(LOWER($1)) || '%'
                   LIMIT 20`,
                  [prefix]
                );
              } catch (_unaccentErr) {
                candidates = await dbClient.query(
                  `SELECT id, name FROM collaborators
                   WHERE LOWER(name) LIKE LOWER($1) || '%'
                   LIMIT 20`,
                  [prefix]
                );
              }
              const matched = candidates.rows.find(row =>
                wordOverlapScore(normOp, normalizeNameForMatch(row.name)) >= 0.75
              );
              if (matched) {
                await dbClient.query(
                  `UPDATE gotalk_operators SET collaborator_id = $1, updated_at = NOW() WHERE id = $2`,
                  [matched.id, opRow.id]
                );
                batchLinked++;
              }
            } catch (nameErr) {
              console.warn(`[Gotalk Poller] Erro ao buscar colaborador por nome para operador ${gotalkOpId}:`, nameErr.message);
            }
          }
        }
      }
    } finally {
      dbClient.release();
    }
    return { imp: batchImported, lnk: batchLinked };
  }

  // ── Strategy 0: official documented endpoint /operator/channel/:channelId ─
  // This is the authoritative GoTalk API endpoint per official documentation.
  // If it returns operators we skip all other strategies.
  {
    let channelIdForPrimary = channelId || null;
    if (!channelIdForPrimary) {
      try { channelIdForPrimary = await getChannelId(); } catch (_) {}
    }

    if (channelIdForPrimary) {
      let res;
      try { res = await gotalkFetch(`/operator/channel/${channelIdForPrimary}`); } catch (_) {}

      if (res && res.ok) {
        let rawText;
        try { rawText = await res.text(); } catch (_) {}

        if (rawText) {
          let data;
          try { data = JSON.parse(rawText); } catch (_) {
            console.log(`[Gotalk Poller] /operator/channel/${channelIdForPrimary} retornou 2xx mas body inválido. Preview: ${rawText.slice(0, 500)}`);
          }

          if (data) {
            // Mark deleted operators: GoTalk API doc says field `deleted: true` means deleted.
            // Process all — upsert sets active = op.active !== false && op.deleted !== true.
            const operators = extractOperators(data);

            if (operators.length > 0) {
              // Apply `deleted` field from GoTalk to the active flag before processing.
              const normalized = operators.map(op => ({
                ...op,
                active: op.deleted === true ? false : op.active !== false,
              }));
              const { imp, lnk } = await processOperatorBatch(normalized);
              imported += imp;
              linked += lnk;
              console.log(`[Gotalk Poller] Operadores importados via /operator/channel/${channelIdForPrimary}: ${imp} (${lnk} vinculados)`);
              // Mark deleted operators as inactive in DB even if they don't appear in future calls
              const deletedOps = operators.filter(op => op.deleted === true);
              if (deletedOps.length > 0) {
                const dbClient = await _pool.connect();
                try {
                  for (const op of deletedOps) {
                    const gotalkOpId = op._id || op.id;
                    if (gotalkOpId) {
                      await dbClient.query(
                        `UPDATE gotalk_operators SET active = FALSE, updated_at = NOW()
                         WHERE gotalk_operator_id = $1`,
                        [gotalkOpId]
                      );
                    }
                  }
                } finally {
                  dbClient.release();
                }
                console.log(`[Gotalk Poller] ${deletedOps.length} operador(es) marcado(s) como inativo(s) (deleted=true).`);
              }
              // Success — skip all other strategies
              console.log(`[Gotalk Poller] Operadores importados: ${imported}, vinculados a colaboradores: ${linked}`);
              return;
            } else {
              console.log(`[Gotalk Poller] /operator/channel/${channelIdForPrimary} retornou 2xx mas sem operadores. Preview: ${rawText.slice(0, 500)}`);
            }
          }
        }
      }
    }
  }

  // ── Strategy A: paginated /operator/page/{n} ─────────────────────────────
  // This is the preferred path; if it returns data we skip the flat-list fallbacks.
  {
    let page = 1;
    let paginatedSuccess = false;
    while (true) {
      let res;
      try { res = await gotalkFetch(`/operator/page/${page}`); } catch (_) { break; }
      if (!res.ok) break;

      let rawText;
      try { rawText = await res.text(); } catch (_) { break; }
      let data;
      try { data = JSON.parse(rawText); } catch (_) {
        // Non-JSON or empty body — log preview and stop pagination
        if (page === 1) console.log(`[Gotalk Poller] /operator/page/1 retornou 2xx mas body inválido. Preview: ${rawText.slice(0, 500)}`);
        break;
      }
      const operators = extractOperators(data);

      if (operators.length === 0) {
        if (page === 1) {
          console.log(`[Gotalk Poller] /operator/page/1 retornou 2xx mas sem operadores. Preview: ${rawText.slice(0, 500)}`);
        }
        break;
      }

      paginatedSuccess = true;
      const { imp, lnk } = await processOperatorBatch(operators);
      imported += imp;
      linked += lnk;
      if (operators.length < 9) break;
      page++;
    }
    if (paginatedSuccess) {
      console.log(`[Gotalk Poller] Operadores importados: ${imported}, vinculados a colaboradores: ${linked}`);
      return;
    }
  }

  // ── Strategy B: flat-list fallbacks ─────────────────────────────────────
  // GoTalk accounts may expose operators under different paths. Try each
  // candidate until one returns a non-empty operator list.
  let fallbackChannelId = channelId;
  if (!fallbackChannelId) {
    try { fallbackChannelId = await getChannelId(); } catch (_) {}
  }

  const flatCandidates = [
    '/operator',
    '/user/list',
    '/user',
    '/agent/list',
    '/agent',
    ...(fallbackChannelId ? [`/channel/${fallbackChannelId}/operators`] : []),
  ];

  for (const path of flatCandidates) {
    let res;
    try { res = await gotalkFetch(path); } catch (_) { continue; }
    if (!res.ok) continue;

    let rawText;
    try { rawText = await res.text(); } catch (_) { continue; }
    let data;
    try { data = JSON.parse(rawText); } catch (_) {
      // Non-JSON or empty body — log preview for diagnosis, try next candidate
      console.log(`[Gotalk Poller] Endpoint ${path} retornou 2xx mas body inválido. Preview: ${rawText.slice(0, 500)}`);
      continue;
    }
    const operators = extractOperators(data);

    if (operators.length === 0) {
      // Diagnostic: log the raw payload so we can identify the correct shape in production
      console.log(`[Gotalk Poller] Endpoint ${path} retornou 2xx mas sem operadores. Preview: ${rawText.slice(0, 500)}`);
      continue;
    }

    console.log(`[Gotalk Poller] Endpoint de operadores descoberto: ${path} (${operators.length} operador(es))`);
    const { imp, lnk } = await processOperatorBatch(operators);
    imported += imp;
    linked += lnk;
    break; // Found a working endpoint — stop trying others
  }

  // Always emit the same summary pattern for consistent monitoring (includes zero case)
  const opSuffix = imported === 0 ? ' (nenhum endpoint disponível)' : '';
  console.log(`[Gotalk Poller] Operadores importados: ${imported}, vinculados a colaboradores: ${linked}${opSuffix}`);
}

// ─── Derive attendance type (CLIENT vs BANK) from GoTalk payload ──────────
// Priority: 1) explicit type field in payload  2) department/area keywords
//           3) typeHint from caller              4) default 'CLIENT'
function deriveAttendanceType(rawAt, typeHint) {
  // 1. Explicit type field sent by GoTalk
  const rawType = (rawAt.type || rawAt.attendanceType || '').toUpperCase();
  if (rawType === 'BANK' || rawType === 'BANCO') return 'BANK';
  if (rawType === 'CLIENT' || rawType === 'CLIENTE') return 'CLIENT';

  // 2. Area/department/tag keywords indicating bank contact
  const BANK_KEYWORDS = /banco|bank|credor|financ.*negoci/i;
  const checkFields = [
    rawAt.area, rawAt.department, rawAt.departmentName,
    rawAt.tag, rawAt.subject, rawAt.title,
  ].filter(Boolean).join(' ');
  if (BANK_KEYWORDS.test(checkFields)) return 'BANK';

  // 3. Caller hint
  if (typeHint === 'BANK' || typeHint === 'CLIENT') return typeHint;

  // 4. Default
  return 'CLIENT';
}

// ─── Backfill attendance_id on messages for a session window ──────────────
// Links existing gotalk_messages to this attendance based on the contact +
// timestamp window (started_at → ended_at or open-ended). Only updates rows
// that are currently unassigned (attendance_id IS NULL).
async function backfillMessagesForAttendance(dbClient, attendanceDbId) {
  // The WHERE attendance_id IS NULL guard is intentional: it avoids
  // re-assigning messages already linked to a different attendance session
  // (e.g., overlapping open sessions or manual overrides). If attendance
  // boundaries change after the fact, rows will retain their original
  // attendance_id — this is a safe, idempotent-by-default behaviour.
  // To force re-link, callers must UPDATE gotalk_messages SET attendance_id = NULL
  // for the target rows before calling this function.
  await dbClient.query(
    `UPDATE gotalk_messages gm
     SET attendance_id = $1
     FROM gotalk_attendances ga
     WHERE ga.id = $1
       AND gm.gotalk_contact_id = ga.gotalk_contact_id
       AND gm.attendance_id IS NULL
       AND gm.sent_at >= COALESCE(ga.started_at, NOW() - INTERVAL '365 days')
       AND (ga.ended_at IS NULL OR gm.sent_at <= ga.ended_at)`,
    [attendanceDbId]
  );
}

// ─── Upsert a single attendance session ───────────────────────────────────
// typeHint: optional 'CLIENT'|'BANK' passed by the caller when the context
// is already known (e.g., operator-loop always CLIENT for this CRM).
// Returns the local DB UUID of the attendance row, or null on failure.
async function upsertAttendance(dbClient, rawAt, defaultContactDbId, defaultClientId, typeHint, channelUuid = null) {
  const gotalkAtId = rawAt._id || rawAt.id;
  if (!gotalkAtId) return null;

  // Resolve gotalk_channel_uuid: use passed value or look up from rawAt.channelId
  if (!channelUuid) {
    const rawChanId = rawAt.channelId || rawAt.channel_id || null;
    if (rawChanId) {
      try {
        const chRes = await dbClient.query(
          `SELECT id FROM gotalk_channels WHERE channel_id = $1 AND is_active = TRUE LIMIT 1`,
          [rawChanId]
        );
        channelUuid = chRes.rows[0]?.id || null;
      } catch (chErr) {
        console.warn('[Gotalk Poller] Erro ao resolver channel UUID para atendimento:', chErr.message);
      }
    }
  }

  // Resolve operator
  let operatorDbId = null;
  const gotalkOpId = rawAt.operatorId || rawAt.operator?._id || rawAt.operator?.id || null;
  if (gotalkOpId) {
    const opRes = await dbClient.query(
      `SELECT id FROM gotalk_operators WHERE gotalk_operator_id = $1 LIMIT 1`,
      [gotalkOpId]
    );
    operatorDbId = opRes.rows[0]?.id || null;
  }

  // Resolve contact
  let contactDbId = defaultContactDbId;
  let clientId = defaultClientId;
  const gotalkContactId = rawAt.contactId || rawAt.contact?._id || rawAt.contact?.id || null;
  if (gotalkContactId && !contactDbId) {
    const cRes = await dbClient.query(
      `SELECT id, client_id FROM gotalk_contacts WHERE gotalk_id = $1 LIMIT 1`,
      [gotalkContactId]
    );
    if (cRes.rows.length > 0) {
      contactDbId = cRes.rows[0].id;
      clientId = cRes.rows[0].client_id || clientId;
    }
  }

  // Parse timestamps — GoTalk may return ISO strings, Unix seconds, or Unix ms
  const startedRaw = rawAt.createdAt || rawAt.startedAt || rawAt.started_at;
  const endedRaw   = rawAt.finishedAt || rawAt.endedAt || rawAt.ended_at;
  const startedAt  = parseGoTalkTimestamp(startedRaw);
  const endedAt    = parseGoTalkTimestamp(endedRaw);

  // Map status
  const rawStatus = (rawAt.status || 'open').toLowerCase();
  const statusMap = { open: 'open', opened: 'open', active: 'open', pending: 'waiting',
                      waiting: 'waiting', closed: 'closed', finished: 'closed',
                      finalized: 'closed', transferred: 'transferred' };
  const status = statusMap[rawStatus] || 'open';

  // Derive type (CLIENT vs BANK)
  const type = deriveAttendanceType(rawAt, typeHint);

  const upsertRes = await dbClient.query(
    `INSERT INTO gotalk_attendances
       (gotalk_attendance_id, operator_id, gotalk_contact_id, client_id,
        gotalk_operator_id, status, type, department, subject,
        started_at, ended_at, gotalk_channel_uuid, raw_data, updated_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13::jsonb,NOW())
     ON CONFLICT (gotalk_attendance_id) DO UPDATE SET
       operator_id         = COALESCE(EXCLUDED.operator_id,        gotalk_attendances.operator_id),
       gotalk_contact_id   = COALESCE(EXCLUDED.gotalk_contact_id,  gotalk_attendances.gotalk_contact_id),
       client_id           = COALESCE(EXCLUDED.client_id,          gotalk_attendances.client_id),
       gotalk_operator_id  = COALESCE(EXCLUDED.gotalk_operator_id, gotalk_attendances.gotalk_operator_id),
       status              = EXCLUDED.status,
       type                = CASE WHEN gotalk_attendances.type = 'CLIENT' THEN EXCLUDED.type ELSE gotalk_attendances.type END,
       department          = COALESCE(EXCLUDED.department, gotalk_attendances.department),
       subject             = COALESCE(EXCLUDED.subject,    gotalk_attendances.subject),
       started_at          = COALESCE(gotalk_attendances.started_at, EXCLUDED.started_at),
       ended_at            = COALESCE(EXCLUDED.ended_at,   gotalk_attendances.ended_at),
       gotalk_channel_uuid = COALESCE(gotalk_attendances.gotalk_channel_uuid, EXCLUDED.gotalk_channel_uuid),
       raw_data            = EXCLUDED.raw_data,
       updated_at          = NOW()
     RETURNING id`,
    [
      gotalkAtId,
      operatorDbId,
      contactDbId || null,
      clientId || null,
      gotalkOpId,
      status,
      type,
      rawAt.departmentName || rawAt.department || null,
      rawAt.subject || rawAt.title || null,
      startedAt,
      endedAt,
      channelUuid || null,
      JSON.stringify(rawAt),
    ]
  );

  return upsertRes.rows[0]?.id || null;
}

// ─── Helper: fetch, upsert and backfill a list of raw attendances ─────────
// Used by both sync strategies so backfill logic is always applied consistently.
// A single DB connection is acquired for the entire batch to reduce churn;
// per-item failures are caught and logged individually so one bad record
// does not abort the rest.
async function processAttendanceList(attendances, defaultContactDbId, defaultClientId, typeHint) {
  let count = 0;
  let failed = 0;
  const dbClient = await _pool.connect();
  try {
    for (const rawAt of attendances) {
      // Skip items that are clearly messages (no attendance-level ID or status)
      const isAttendanceLike =
        rawAt.status !== undefined ||
        rawAt.operatorId !== undefined ||
        rawAt.operator  !== undefined ||
        rawAt.startedAt !== undefined ||
        rawAt.createdAt !== undefined ||
        rawAt.finishedAt !== undefined;
      if (!isAttendanceLike) continue;

      try {
        const attendanceDbId = await upsertAttendance(
          dbClient, rawAt, defaultContactDbId, defaultClientId, typeHint
        );
        if (attendanceDbId) {
          count++;
          await backfillMessagesForAttendance(dbClient, attendanceDbId);
        }
      } catch (itemErr) {
        failed++;
        console.warn('[Gotalk Poller] Erro ao processar atendimento individual:', itemErr.message);
      }
    }
  } finally {
    dbClient.release();
  }
  if (failed > 0) {
    console.warn(`[Gotalk Poller] processAttendanceList: ${failed} atendimento(s) falharam (de ${attendances.length})`);
  }
  return count;
}

// ─── Import attendances for all linked contacts ────────────────────────────
// Strategy 1: iterate over active GoTalk operators and fetch both open and
//             closed attendances for each (catches sessions that pre-date
//             webhook setup or were missed due to delivery failures).
// Strategy 2: iterate over linked contacts and fetch their attendance history
//             directly (complementary coverage — important when operator
//             endpoints are unavailable or pagination is incomplete).
// After every upsert both strategies call backfillMessagesForAttendance() to
// deterministically link existing messages to their session.
async function importAttendances() {
  let totalImported = 0;
  let skippedOperators = 0;

  // ── Strategy 1: by operator ─────────────────────────────────────────────
  let operatorsRows = [];
  try {
    const res = await _pool.query(
      `SELECT gotalk_operator_id FROM gotalk_operators WHERE active = TRUE`
    );
    operatorsRows = res.rows;
  } catch (_) {}

  for (const op of operatorsRows) {
    // Try multiple status variants to cover both open and closed attendances.
    // We always attempt all variants: an empty response for one status
    // does NOT mean the endpoint is unavailable for another status.
    // Only a non-200 HTTP status from the base path (no query string) signals
    // the operator attendance endpoint is unsupported for this account.
    const statusPaths = ['', '?status=closed', '?status=finished', '?status=all'];
    let baseEndpointAvailable = null; // null = unknown, true = ok, false = unavailable
    for (const qs of statusPaths) {
      try {
        const res = await gotalkFetch(`/attendance/operator/${op.gotalk_operator_id}${qs}`);
        if (!res.ok) {
          if (qs === '') {
            baseEndpointAvailable = false;
            skippedOperators++;
            break; // Base unavailable — skip all variants for this operator
          }
          continue; // Variant-specific error — try next variant
        }
        if (qs === '') baseEndpointAvailable = true;

        let data;
        try { data = await res.json(); } catch (_) { continue; }

        const attendances = Array.isArray(data)
          ? data
          : (data.attendances || data.data || []);

        // Always process what we have; an empty list is valid — continue to next variant
        if (attendances.length > 0) {
          totalImported += await processAttendanceList(attendances, null, null, null);
        }
      } catch (_) { /* skip if endpoint unavailable */ }
    }
    // If base endpoint was unavailable, no point checking variants (already broke above)
  }

  // Strategy 2 (by-contact attendance loop) was removed:
  // All /attendance/contact/{id} endpoints return 404 for this account, making
  // the loop across 6,000+ contacts entirely wasteful. Incoming messages are
  // now handled in real-time by the GoTalk webhook.

  // Log summary every cycle for consistent observability (monitoring can rely on fixed log line)
  const summary = [
    `importados/atualizados: ${totalImported}`,
    ...(skippedOperators > 0 ? [`operadores com endpoint indisponível: ${skippedOperators}`] : []),
  ];
  console.log(`[Gotalk Poller] Atendimentos — ${summary.join(', ')}`);
}

// ─── Import messages for saved attendance sessions via POST /message/load_messages ────
// This is the definitive message import strategy for GoTalk accounts where
// /attendance/* endpoints return 404. Attendance IDs are captured when templates
// are sent via send-active-notification, or registered manually via sync-attendance.
// Only open or recently-active attendances are polled (last 24 hours by default).
async function importMessagesForActiveAttendances() {
  // Esta função é multi-canal por natureza: busca TODOS os atendimentos
  // ativos do banco, que já contêm channel_id do próprio canal de origem.
  // Para linhas legadas com channel_id nulo, usa o primário como fallback.
  const primaryChannelId = await getChannelId().catch(() => null);
  let rows;
  try {
    const res = await _pool.query(
      `SELECT ga.gotalk_attendance_id, ga.id AS db_id, ga.gotalk_contact_id, ga.client_id,
              gc.phone_number, gc.channel_id,
              gc.gotalk_channel_uuid,
              COALESCE(goa.operator_name, go.name) AS operator_name,
              goa.department_name AS department
       FROM gotalk_attendances ga
       JOIN gotalk_contacts gc ON gc.id = ga.gotalk_contact_id
       LEFT JOIN gotalk_operator_attendances goa ON goa.gotalk_attendance_id = ga.gotalk_attendance_id
       LEFT JOIN gotalk_operators go ON go.id = ga.operator_id
       WHERE ga.status != 'closed' OR ga.updated_at > NOW() - INTERVAL '24 hours'
       ORDER BY ga.updated_at DESC LIMIT 100`
    );
    rows = res.rows;
  } catch (e) {
    console.warn('[Gotalk Poller] Erro ao buscar atendimentos para poll de mensagens:', e.message);
    return;
  }

  if (rows.length === 0) return;

  let fetched = 0;
  let newMessages = 0;

  for (const at of rows) {
    let phone = at.phone_number || '';
    if (phone && !phone.startsWith('55')) phone = '55' + phone;
    if (!phone) continue;

    try {
      const effectiveChannelId = at.channel_id || primaryChannelId;
      const res = await gotalkFetch('/message/load_messages', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          attendance: { _id: at.gotalk_attendance_id, clientNumber: phone, channelId: effectiveChannelId },
        }),
      });

      if (!res.ok) continue;
      fetched++;

      const data = await res.json();
      const messages = Array.isArray(data) ? data : (data.messages || data.data || []);

      const dbClient = await _pool.connect();
      try {
        for (const msg of messages) {
          const gotalkMsgId = msg._id || msg.id;
          if (!gotalkMsgId) continue;

          const existing = await dbClient.query(
            `SELECT id FROM gotalk_messages WHERE gotalk_message_id = $1`, [gotalkMsgId]
          );
          if (existing.rows.length > 0) continue;

          const fromMe = msg.fromMe === true || msg.direction === 'OUT';
          const direction = fromMe ? 'OUT' : 'IN';
          const body = msg.body || msg.text || msg.caption || '';
          const ts = msg.timestamp;
          const sentAt = ts
            ? new Date(typeof ts === 'number' && ts < 1e12 ? ts * 1000 : ts)
            : new Date();

          const waMsgType = (msg.type || 'chat').toLowerCase();
          let messageType = 'TEXT';
          if (waMsgType === 'image') messageType = 'IMAGE';
          else if (waMsgType === 'audio' || waMsgType === 'ptt') messageType = 'AUDIO';
          else if (waMsgType === 'document') messageType = 'DOCUMENT';
          else if (waMsgType === 'video') messageType = 'VIDEO';

          const ackStatus = direction === 'OUT'
            ? (typeof msg.ack === 'number' ? Math.min(msg.ack, 3) : 1)
            : null;

          const msgOpName = msg.operatorName || msg.operator || at.operator_name || null;
          const msgDept   = msg.departmentName || msg.department || at.department || null;
          await dbClient.query(
            `INSERT INTO gotalk_messages
               (gotalk_message_id, gotalk_contact_id, client_id, phone_number,
                direction, body, message_type, attachment_url, attachment_name, attachment_mime_type,
                ack_status, operator_name, department, area, attendance_id, gotalk_channel_uuid, sent_at)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17)
             ON CONFLICT (gotalk_message_id) DO UPDATE SET
               operator_name       = COALESCE(EXCLUDED.operator_name, gotalk_messages.operator_name),
               department          = COALESCE(EXCLUDED.department,    gotalk_messages.department),
               area                = COALESCE(gotalk_messages.area, EXCLUDED.area),
               gotalk_channel_uuid = COALESCE(gotalk_messages.gotalk_channel_uuid, EXCLUDED.gotalk_channel_uuid)`,
            [
              gotalkMsgId, at.gotalk_contact_id, at.client_id, normalizePhone(at.phone_number),
              direction, body, messageType,
              msg.mediaUrl || msg.url || null,
              msg.fileName || null,
              msg.mimetype || null,
              ackStatus, msgOpName, msgDept, departmentToArea(msgDept), at.db_id, at.gotalk_channel_uuid || null, sentAt,
            ]
          );
          newMessages++;
        }
      } finally {
        dbClient.release();
      }
    } catch (_) { /* best-effort per attendance */ }
  }

  if (newMessages > 0) {
    console.log(`[Gotalk Poller] Mensagens importadas via atendimentos: ${newMessages} novas (${fetched}/${rows.length} atendimentos responderam).`);
  }
}

// ─── Import open attendances per operator via /attendance/operatorId/:id ──
// Fetches open attendances (in_attendance, waiting) for every active operator,
// upserts them into gotalk_operator_attendances, and closes rows that are no
// longer returned by the API (i.e. attendance was closed on GoTalk side).
async function importAttendancesPerOperator() {
  // Load all active operators from DB
  const dbClient = await _pool.connect();
  let operators = [];
  try {
    const res = await dbClient.query(
      `SELECT id AS operator_db_id, gotalk_operator_id, name
       FROM gotalk_operators
       WHERE active = TRUE`
    );
    operators = res.rows;
  } finally {
    dbClient.release();
  }

  if (operators.length === 0) return;

  let totalUpserted = 0;
  let totalClosed = 0;

  // Track all attendance IDs seen across all operators so we can close stale rows
  const seenAttendanceIds = new Set();

  for (const op of operators) {
    let res;
    try {
      res = await gotalkFetch(`/attendance/operatorId/${op.gotalk_operator_id}`);
    } catch (fetchErr) {
      console.warn(`[Gotalk Poller] Atendimentos operador ${op.gotalk_operator_id}: fetch error:`, fetchErr.message);
      continue;
    }
    if (!res.ok) continue;

    let data;
    try { data = await res.json(); } catch (_) { continue; }

    const attendances = Array.isArray(data) ? data : (data.attendances || data.data || []);
    if (!Array.isArray(attendances)) continue;

    const dbClient2 = await _pool.connect();
    try {
      for (const att of attendances) {
        const attId = att._id || att.id;
        if (!attId) continue;

        seenAttendanceIds.add(attId);

        const protocol    = att.protocol || null;
        const contactIdExt = att.contactId || null;
        const clientNumber = att.clientNumber ? normalizePhone(att.clientNumber) : null;
        const clientName   = att.clientName || null;
        const deptId       = att.departmentId || null;
        const deptName     = att.departmentName || null;
        const channelId    = att.channel || att.channelId || null;
        const status       = att.status || 'in_attendance';
        const opName       = att.operatorName || att.nickname || op.name || null;
        const startTime    = att.attendanceStartTime
          ? new Date(att.attendanceStartTime)
          : (att.createdAt ? new Date(att.createdAt) : null);
        const lastMsgAt    = att.lastMessage
          ? new Date(typeof att.lastMessage === 'number' && att.lastMessage > 1e12 ? att.lastMessage : att.lastMessage * 1000)
          : (att.lastMessageContact ? new Date(att.lastMessageContact) : null);

        // Resolve gotalk_channel_uuid from channel_id VARCHAR
        let channelUuid = null;
        if (channelId) {
          try {
            const chRes = await dbClient2.query(
              `SELECT id FROM gotalk_channels WHERE channel_id = $1 AND is_active = TRUE LIMIT 1`,
              [channelId]
            );
            channelUuid = chRes.rows[0]?.id || null;
          } catch (chErr) {
            console.warn('[Gotalk Poller] Erro ao resolver channel UUID em importAttendancesPerOperator:', chErr.message);
          }
        }

        // Try to resolve local gotalk_contact_db_id
        let contactDbId = null;
        if (contactIdExt) {
          const cRes = await dbClient2.query(
            `SELECT id FROM gotalk_contacts WHERE gotalk_id = $1 LIMIT 1`,
            [contactIdExt]
          );
          contactDbId = cRes.rows[0]?.id || null;
        }

        // Try to resolve local client by phone (last 10 digits)
        let clientId = null;
        if (clientNumber) {
          const last10 = clientNumber.slice(-10);
          const clRes = await dbClient2.query(
            `SELECT id FROM clients
             WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''), '[^0-9]', '', 'g'), 10) = $1
                OR RIGHT(REGEXP_REPLACE(COALESCE(phone2,''), '[^0-9]', '', 'g'), 10) = $1
             LIMIT 1`,
            [last10]
          );
          clientId = clRes.rows[0]?.id || null;
        }

        await dbClient2.query(
          `INSERT INTO gotalk_operator_attendances
             (gotalk_attendance_id, gotalk_operator_id, operator_db_id, operator_name,
              protocol, gotalk_contact_id_ext, gotalk_contact_db_id,
              client_number, client_name, client_id,
              department_id, department_name, channel_id, gotalk_channel_uuid,
              status, attendance_start_time, last_message_at, raw_data)
           VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18::jsonb)
           ON CONFLICT (gotalk_attendance_id) DO UPDATE SET
             gotalk_operator_id    = EXCLUDED.gotalk_operator_id,
             operator_db_id        = COALESCE(EXCLUDED.operator_db_id, gotalk_operator_attendances.operator_db_id),
             operator_name         = COALESCE(EXCLUDED.operator_name,  gotalk_operator_attendances.operator_name),
             protocol              = COALESCE(EXCLUDED.protocol,       gotalk_operator_attendances.protocol),
             gotalk_contact_id_ext = COALESCE(EXCLUDED.gotalk_contact_id_ext, gotalk_operator_attendances.gotalk_contact_id_ext),
             gotalk_contact_db_id  = COALESCE(EXCLUDED.gotalk_contact_db_id,  gotalk_operator_attendances.gotalk_contact_db_id),
             client_number         = COALESCE(EXCLUDED.client_number,  gotalk_operator_attendances.client_number),
             client_name           = COALESCE(EXCLUDED.client_name,    gotalk_operator_attendances.client_name),
             client_id             = COALESCE(EXCLUDED.client_id,      gotalk_operator_attendances.client_id),
             department_id         = COALESCE(EXCLUDED.department_id,  gotalk_operator_attendances.department_id),
             department_name       = COALESCE(EXCLUDED.department_name,gotalk_operator_attendances.department_name),
             channel_id            = COALESCE(EXCLUDED.channel_id,     gotalk_operator_attendances.channel_id),
             gotalk_channel_uuid   = COALESCE(gotalk_operator_attendances.gotalk_channel_uuid, EXCLUDED.gotalk_channel_uuid),
             status                = EXCLUDED.status,
             attendance_start_time = COALESCE(gotalk_operator_attendances.attendance_start_time, EXCLUDED.attendance_start_time),
             last_message_at       = COALESCE(EXCLUDED.last_message_at, gotalk_operator_attendances.last_message_at),
             raw_data              = EXCLUDED.raw_data,
             updated_at            = NOW()`,
          [attId, op.gotalk_operator_id, op.operator_db_id, opName,
           protocol, contactIdExt, contactDbId,
           clientNumber, clientName, clientId,
           deptId, deptName, channelId, channelUuid || null,
           status, startTime, lastMsgAt, JSON.stringify(att)]
        );
        totalUpserted++;
      }
    } finally {
      dbClient2.release();
    }
  }

  // Close attendances no longer returned by any operator (they were closed on GoTalk side).
  // Only close rows currently marked as open/in_attendance/waiting.
  if (seenAttendanceIds.size > 0) {
    const dbClient3 = await _pool.connect();
    try {
      const openRows = await dbClient3.query(
        `SELECT gotalk_attendance_id FROM gotalk_operator_attendances
         WHERE status NOT IN ('closed', 'finished', 'transferred')`
      );
      const toClose = openRows.rows
        .map(r => r.gotalk_attendance_id)
        .filter(id => !seenAttendanceIds.has(id));

      if (toClose.length > 0) {
        await dbClient3.query(
          `UPDATE gotalk_operator_attendances
           SET status = 'closed', updated_at = NOW()
           WHERE gotalk_attendance_id = ANY($1::text[])`,
          [toClose]
        );
        totalClosed = toClose.length;
      }
    } finally {
      dbClient3.release();
    }
  }

  if (totalUpserted > 0 || totalClosed > 0) {
    console.log(`[Gotalk Poller] Atendimentos por operador: ${totalUpserted} upserted, ${totalClosed} fechados.`);
  }
}

// ─── Upsert a single operator attendance from webhook payload ─────────────
// Used by the webhook handler for real-time updates. Returns the DB row id.
async function upsertOperatorAttendance(dbClient, rawAtt, channelUuid = null) {
  const attId = rawAtt._id || rawAtt.id;
  if (!attId) return null;

  const opId     = rawAtt.operatorId || rawAtt.operator?._id || rawAtt.operator?.id || null;
  const opName   = rawAtt.operatorName || rawAtt.nickname || rawAtt.operator?.name || null;
  const protocol = rawAtt.protocol || null;
  const contactIdExt = rawAtt.contactId || null;
  const clientNumber = rawAtt.clientNumber ? normalizePhone(rawAtt.clientNumber) : null;
  const clientName   = rawAtt.clientName || null;
  const deptId   = rawAtt.departmentId || null;
  const deptName = rawAtt.departmentName || null;
  const channelId = rawAtt.channel || rawAtt.channelId || null;
  const status   = rawAtt.status || 'in_attendance';
  const startTime = rawAtt.attendanceStartTime
    ? new Date(rawAtt.attendanceStartTime)
    : (rawAtt.createdAt ? new Date(rawAtt.createdAt) : null);
  const lastMsgAt = rawAtt.lastMessage
    ? new Date(typeof rawAtt.lastMessage === 'number' && rawAtt.lastMessage > 1e12 ? rawAtt.lastMessage : rawAtt.lastMessage * 1000)
    : (rawAtt.lastMessageContact ? new Date(rawAtt.lastMessageContact) : null);

  // Resolve operator_db_id
  let operatorDbId = null;
  if (opId) {
    const opRes = await dbClient.query(
      `SELECT id FROM gotalk_operators WHERE gotalk_operator_id = $1 LIMIT 1`,
      [opId]
    );
    operatorDbId = opRes.rows[0]?.id || null;
  }

  // Resolve contact_db_id
  let contactDbId = null;
  if (contactIdExt) {
    const cRes = await dbClient.query(
      `SELECT id FROM gotalk_contacts WHERE gotalk_id = $1 LIMIT 1`,
      [contactIdExt]
    );
    contactDbId = cRes.rows[0]?.id || null;
  }

  // Resolve client_id by phone
  let clientId = null;
  if (clientNumber) {
    const last10 = clientNumber.slice(-10);
    const clRes = await dbClient.query(
      `SELECT id FROM clients
       WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''), '[^0-9]', '', 'g'), 10) = $1
          OR RIGHT(REGEXP_REPLACE(COALESCE(phone2,''), '[^0-9]', '', 'g'), 10) = $1
       LIMIT 1`,
      [last10]
    );
    clientId = clRes.rows[0]?.id || null;
  }

  // Resolve gotalk_channel_uuid from channelId VARCHAR if not already provided
  if (!channelUuid && channelId) {
    try {
      const chRes = await dbClient.query(
        `SELECT id FROM gotalk_channels WHERE channel_id = $1 AND is_active = TRUE LIMIT 1`,
        [channelId]
      );
      channelUuid = chRes.rows[0]?.id || null;
    } catch (chErr) {
      console.warn('[Gotalk Poller] Erro ao resolver channel UUID em upsertOperatorAttendance:', chErr.message);
    }
  }

  const res = await dbClient.query(
    `INSERT INTO gotalk_operator_attendances
       (gotalk_attendance_id, gotalk_operator_id, operator_db_id, operator_name,
        protocol, gotalk_contact_id_ext, gotalk_contact_db_id,
        client_number, client_name, client_id,
        department_id, department_name, channel_id, gotalk_channel_uuid,
        status, attendance_start_time, last_message_at, raw_data)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18::jsonb)
     ON CONFLICT (gotalk_attendance_id) DO UPDATE SET
       gotalk_operator_id    = EXCLUDED.gotalk_operator_id,
       operator_db_id        = COALESCE(EXCLUDED.operator_db_id, gotalk_operator_attendances.operator_db_id),
       operator_name         = COALESCE(EXCLUDED.operator_name,  gotalk_operator_attendances.operator_name),
       protocol              = COALESCE(EXCLUDED.protocol,       gotalk_operator_attendances.protocol),
       gotalk_contact_id_ext = COALESCE(EXCLUDED.gotalk_contact_id_ext, gotalk_operator_attendances.gotalk_contact_id_ext),
       gotalk_contact_db_id  = COALESCE(EXCLUDED.gotalk_contact_db_id,  gotalk_operator_attendances.gotalk_contact_db_id),
       client_number         = COALESCE(EXCLUDED.client_number,  gotalk_operator_attendances.client_number),
       client_name           = COALESCE(EXCLUDED.client_name,    gotalk_operator_attendances.client_name),
       client_id             = COALESCE(EXCLUDED.client_id,      gotalk_operator_attendances.client_id),
       department_id         = COALESCE(EXCLUDED.department_id,  gotalk_operator_attendances.department_id),
       department_name       = COALESCE(EXCLUDED.department_name,gotalk_operator_attendances.department_name),
       channel_id            = COALESCE(EXCLUDED.channel_id,     gotalk_operator_attendances.channel_id),
       gotalk_channel_uuid   = COALESCE(gotalk_operator_attendances.gotalk_channel_uuid, EXCLUDED.gotalk_channel_uuid),
       status                = EXCLUDED.status,
       attendance_start_time = COALESCE(gotalk_operator_attendances.attendance_start_time, EXCLUDED.attendance_start_time),
       last_message_at       = COALESCE(EXCLUDED.last_message_at, gotalk_operator_attendances.last_message_at),
       raw_data              = EXCLUDED.raw_data,
       updated_at            = NOW()
     RETURNING id`,
    [attId, opId, operatorDbId, opName,
     protocol, contactIdExt, contactDbId,
     clientNumber, clientName, clientId,
     deptId, deptName, channelId, channelUuid || null,
     status, startTime, lastMsgAt, JSON.stringify(rawAtt)]
  );
  return res.rows[0]?.id || null;
}

// ─── Upsert one attendance record into gotalk_attendance_history ──────────
// Shared by importAttendanceHistory (poller) and webhook handler.
async function upsertAttendanceHistory(dbClient, rawAtt, contactRaw, channelUuid = null) {
  const attId = rawAtt._id || rawAtt.id;
  if (!attId) return null;

  const protocol    = rawAtt.protocol || null;
  const channelId   = rawAtt.channel  || rawAtt.channelId || null;
  const contactIdExt = rawAtt.contactId || null;
  const clientNumber = rawAtt.clientNumber ? normalizePhone(rawAtt.clientNumber) : null;
  const clientName   = rawAtt.clientName  || null;
  const opId         = rawAtt.operatorId  || rawAtt.operator?._id || null;
  const opName       = rawAtt.operatorName || rawAtt.nickname || rawAtt.operator?.name || null;
  const deptId       = rawAtt.departmentId  || null;
  const deptName     = rawAtt.departmentName || null;
  const status       = rawAtt.status || 'in_attendance';

  const startTime = rawAtt.attendanceStartTime
    ? new Date(rawAtt.attendanceStartTime)
    : (rawAtt.createdAt ? new Date(rawAtt.createdAt) : null);

  const lastMsgAt = rawAtt.lastMessage
    ? new Date(typeof rawAtt.lastMessage === 'number' && rawAtt.lastMessage > 1e12
        ? rawAtt.lastMessage : rawAtt.lastMessage * 1000)
    : (rawAtt.lastMessageContact ? new Date(rawAtt.lastMessageContact) : null);

  // finished_at from statusTracker (look for last status with finished/abandoned/closed)
  let finishedAt = rawAtt.updatedAt && ['finished','abandoned','closed'].includes(status)
    ? new Date(rawAtt.updatedAt)
    : null;
  if (!finishedAt && Array.isArray(rawAtt.statusTracker)) {
    const endEntry = [...rawAtt.statusTracker].reverse().find(s =>
      ['finished','abandoned','closed','transferred'].includes(s.status)
    );
    if (endEntry?.timestamp) {
      finishedAt = new Date(endEntry.timestamp > 1e12 ? endEntry.timestamp : endEntry.timestamp * 1000);
    }
  }

  // Resolve FK: gotalk_contact_db_id
  let contactDbId = null;
  if (contactIdExt) {
    const cRes = await dbClient.query(
      `SELECT id FROM gotalk_contacts WHERE gotalk_id = $1 LIMIT 1`, [contactIdExt]
    );
    contactDbId = cRes.rows[0]?.id || null;
  }

  // Resolve FK: operator_db_id
  let operatorDbId = null;
  if (opId) {
    const oRes = await dbClient.query(
      `SELECT id FROM gotalk_operators WHERE gotalk_operator_id = $1 LIMIT 1`, [opId]
    );
    operatorDbId = oRes.rows[0]?.id || null;
  }

  // Resolve FK: client_id by phone (last 10 digits)
  let clientId = null;
  if (clientNumber) {
    const last10 = clientNumber.slice(-10);
    const clRes = await dbClient.query(
      `SELECT id FROM clients
       WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''), '[^0-9]', '', 'g'), 10) = $1
          OR RIGHT(REGEXP_REPLACE(COALESCE(phone2,''), '[^0-9]', '', 'g'), 10) = $1
       LIMIT 1`,
      [last10]
    );
    clientId = clRes.rows[0]?.id || null;
  }

  // Resolve gotalk_channel_uuid from channelId VARCHAR if not already provided
  if (!channelUuid && channelId) {
    try {
      const chRes = await dbClient.query(
        `SELECT id FROM gotalk_channels WHERE channel_id = $1 AND is_active = TRUE LIMIT 1`,
        [channelId]
      );
      channelUuid = chRes.rows[0]?.id || null;
    } catch (chErr) {
      console.warn('[Gotalk Poller] Erro ao resolver channel UUID para history:', chErr.message);
    }
  }

  const res = await dbClient.query(
    `INSERT INTO gotalk_attendance_history
       (gotalk_attendance_id, protocol, channel_id,
        gotalk_contact_id_ext, gotalk_contact_db_id,
        client_number, client_name, client_id,
        gotalk_operator_id, operator_db_id, operator_name,
        department_id, department_name,
        status, attendance_start_time, last_message_at, finished_at,
        gotalk_channel_uuid, contact_raw_data, raw_data)
     VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19::jsonb,$20::jsonb)
     ON CONFLICT (gotalk_attendance_id) DO UPDATE SET
       protocol              = COALESCE(EXCLUDED.protocol,       gotalk_attendance_history.protocol),
       gotalk_contact_id_ext = COALESCE(EXCLUDED.gotalk_contact_id_ext, gotalk_attendance_history.gotalk_contact_id_ext),
       gotalk_contact_db_id  = COALESCE(EXCLUDED.gotalk_contact_db_id,  gotalk_attendance_history.gotalk_contact_db_id),
       client_number         = COALESCE(EXCLUDED.client_number,  gotalk_attendance_history.client_number),
       client_name           = COALESCE(EXCLUDED.client_name,    gotalk_attendance_history.client_name),
       client_id             = COALESCE(EXCLUDED.client_id,      gotalk_attendance_history.client_id),
       gotalk_operator_id    = COALESCE(EXCLUDED.gotalk_operator_id, gotalk_attendance_history.gotalk_operator_id),
       operator_db_id        = COALESCE(EXCLUDED.operator_db_id, gotalk_attendance_history.operator_db_id),
       operator_name         = COALESCE(EXCLUDED.operator_name,  gotalk_attendance_history.operator_name),
       department_id         = COALESCE(EXCLUDED.department_id,  gotalk_attendance_history.department_id),
       department_name       = COALESCE(EXCLUDED.department_name,gotalk_attendance_history.department_name),
       status                = EXCLUDED.status,
       attendance_start_time = COALESCE(gotalk_attendance_history.attendance_start_time, EXCLUDED.attendance_start_time),
       last_message_at       = COALESCE(EXCLUDED.last_message_at, gotalk_attendance_history.last_message_at),
       finished_at           = COALESCE(EXCLUDED.finished_at,    gotalk_attendance_history.finished_at),
       gotalk_channel_uuid   = COALESCE(gotalk_attendance_history.gotalk_channel_uuid, EXCLUDED.gotalk_channel_uuid),
       contact_raw_data      = CASE WHEN $19::jsonb IS NOT NULL THEN $19::jsonb ELSE gotalk_attendance_history.contact_raw_data END,
       raw_data              = EXCLUDED.raw_data,
       updated_at            = NOW()
     RETURNING id`,
    [attId, protocol, channelId,
     contactIdExt, contactDbId,
     clientNumber, clientName, clientId,
     opId, operatorDbId, opName,
     deptId, deptName,
     status, startTime, lastMsgAt, finishedAt,
     channelUuid || null,
     contactRaw ? JSON.stringify(contactRaw) : null,
     JSON.stringify(rawAtt)]
  );
  return res.rows[0]?.id || null;
}

// ─── Import attendance history per contact phone number ────────────────────
// Strategy: collect unique phone numbers from known sources (operator_attendances
// + contacts linked to CRM clients), then call the history endpoint for each.
// Scope is intentionally limited — fetching history for all 6 000+ GoTalk contacts
// would be too slow. We focus on contacts that already have activity.
async function importAttendanceHistory() {
  // Carrega todos os canais ativos — itera cada canal para buscar histórico.
  // Fallback: se nenhum canal estiver na tabela, usa o canal primário da auth.
  const channels = await loadActiveChannels();
  let channelList = channels;
  if (channelList.length === 0) {
    const primaryId = await getChannelId().catch(() => null);
    if (!primaryId) return;
    channelList = [{ channel_id: primaryId, id: null, name: 'primário' }];
  }

  // Collect unique phone numbers to fetch history for:
  // 1. Numbers seen in operator_attendances (known to have open attendances)
  // 2. Contacts in gotalk_contacts that are linked to CRM clients
  const dbClient = await _pool.connect();
  let phoneNumbers = new Set();
  try {
    const r1 = await dbClient.query(
      `SELECT DISTINCT client_number FROM gotalk_operator_attendances
       WHERE client_number IS NOT NULL AND LENGTH(client_number) >= 8`
    );
    for (const row of r1.rows) phoneNumbers.add(row.client_number);

    const r2 = await dbClient.query(
      `SELECT DISTINCT phone_number FROM gotalk_contacts
       WHERE client_id IS NOT NULL AND phone_number IS NOT NULL AND LENGTH(phone_number) >= 8`
    );
    for (const row of r2.rows) phoneNumbers.add(row.phone_number);
  } finally {
    dbClient.release();
  }

  if (phoneNumbers.size === 0) return;

  let totalUpserted = 0;
  let phonesProcessed = 0;

  for (const phone of phoneNumbers) {
    // GoTalk precisa do número com código de país; tenta variantes com/sem 55
    const variants = new Set();
    variants.add(phone);
    if (!phone.startsWith('55') && phone.length <= 11) variants.add(`55${phone}`);
    if (phone.startsWith('55') && phone.length > 11) variants.add(phone.slice(2));

    let attendances = [];
    let contactRaw = null;
    let matchedChannelUuid = null;

    // Tenta cada canal × cada variante de telefone.
    // Para no primeiro canal que retornar resultados (first-hit) — comportamento
    // intencional: um número de telefone pertence a UM canal GoTalk por vez;
    // importar do mesmo canal que o contato é o registro autorizado.
    // Se um número migrar de canal, o próximo ciclo resolverá via upsert.
    outerLoop:
    for (const ch of channelList) {
      for (const num of variants) {
        let res;
        try {
          res = await gotalkFetch(`/attendance/history/channelId/${ch.channel_id}/clientNumber/${num}`);
        } catch (_) { continue; }
        if (!res.ok) continue;

        let data;
        try { data = await res.json(); } catch (_) { continue; }

        const found = data.result?.attendances || [];
        if (found.length > 0) {
          attendances = found;
          contactRaw = data.result?.contact || null;
          matchedChannelUuid = ch.id || null;
          break outerLoop;
        }
      }
    }

    if (attendances.length === 0) continue;

    const dbClient2 = await _pool.connect();
    try {
      for (const att of attendances) {
        try {
          await upsertAttendanceHistory(dbClient2, att, contactRaw, matchedChannelUuid);
          totalUpserted++;
        } catch (rowErr) {
          console.warn('[Gotalk Poller] Erro ao upsert history row:', rowErr.message);
        }
      }
    } finally {
      dbClient2.release();
    }
    phonesProcessed++;
  }

  if (totalUpserted > 0) {
    console.log(`[Gotalk Poller] Histórico de atendimentos: ${totalUpserted} registros, ${phonesProcessed} contatos processados (${channelList.length} canal(is)).`);
  }
}

// ─── Import messages via GET /message/load/protocol/attendanceId/:id ──────
// Uses the confirmed-working endpoint to fetch all messages for each attendance
// stored in gotalk_attendance_history.
//
// Scope per cycle:
//   1. Active attendances (in_attendance / waiting)  — always re-fetched to pick up new messages
//   2. Closed/finished attendances never fetched yet  — fetched once, then messages_last_fetched_at set
// LIMIT 300 per cycle to keep cycle time manageable.
async function importMessagesForAttendanceHistory() {
  // Esta função usa GET /message/load/protocol/attendanceId/:id
  // que não requer channelId — é automaticamente multi-canal.
  if (!_pool) return;

  let rows;
  try {
    rows = (await _pool.query(
      `SELECT gah.id AS history_id,
              gah.gotalk_attendance_id,
              gah.gotalk_contact_id_ext,
              gah.client_number,
              gah.client_id,
              gah.status,
              gah.operator_name AS att_operator_name,
              gah.department_name AS att_department,
              gc.gotalk_channel_uuid
       FROM gotalk_attendance_history gah
       LEFT JOIN gotalk_contacts gc ON gc.id = gah.gotalk_contact_db_id
       WHERE gah.status IN ('in_attendance','waiting')
          OR gah.messages_last_fetched_at IS NULL
       ORDER BY
         (gah.status IN ('in_attendance','waiting')) DESC,
         gah.attendance_start_time DESC
       LIMIT 300`
    )).rows;
  } catch (e) {
    console.warn('[Gotalk Poller] importMessagesForAttendanceHistory query error:', e.message);
    return;
  }

  if (rows.length === 0) return;

  let totalNew = 0;
  let totalAttendances = 0;

  for (const row of rows) {
    const { history_id, gotalk_attendance_id, gotalk_contact_id_ext, client_number, client_id, status, att_operator_name, att_department, gotalk_channel_uuid } = row;

    let response;
    try {
      response = await gotalkFetch(`/message/load/protocol/attendanceId/${gotalk_attendance_id}`);
    } catch (_) { continue; }
    if (!response.ok) continue;

    let data;
    try { data = await response.json(); } catch (_) { continue; }

    const messages = data?.messages?.messages || data?.messages || [];
    if (!Array.isArray(messages)) continue;

    totalAttendances++;

    // Resolve contact DB id if not stored on the row
    let contactDbId = null;
    if (gotalk_contact_id_ext) {
      const cRes = await _pool.query(
        `SELECT id FROM gotalk_contacts WHERE gotalk_id = $1 LIMIT 1`, [gotalk_contact_id_ext]
      );
      contactDbId = cRes.rows[0]?.id || null;
    }

    const dbClient = await _pool.connect();
    try {
      for (const msg of messages) {
        const gotalkMsgId = msg._id || msg.id;
        if (!gotalkMsgId) continue;
        if (msg.deleted) continue;

        const fromMe   = msg.fromMe === true;
        const direction = fromMe ? 'OUT' : 'IN';
        const body     = msg.body || msg.caption || '';

        const ts = msg.timestamp;
        const sentAt = ts
          ? new Date(typeof ts === 'number' && ts > 1e12 ? ts : ts * 1000)
          : new Date(msg.createdAt || Date.now());

        const waMsgType = (msg.type || 'text').toLowerCase();
        let messageType = 'TEXT';
        if (waMsgType === 'image') messageType = 'IMAGE';
        else if (waMsgType === 'audio' || waMsgType === 'ptt') messageType = 'AUDIO';
        else if (waMsgType === 'document') messageType = 'DOCUMENT';
        else if (waMsgType === 'video') messageType = 'VIDEO';
        else if (waMsgType === 'sticker') messageType = 'STICKER';

        const ackStatus = direction === 'OUT'
          ? (typeof msg.statusAck === 'number' ? Math.min(msg.statusAck, 3)
            : (typeof msg.ack === 'number' ? Math.min(msg.ack, 3) : 1))
          : null;

        const attachUrl  = msg.mediaURL || msg.mediaUrl || msg.url || null;
        const attachName = msg.fileName || null;
        const attachMime = msg.mimetype || null;
        const idwpp      = msg.idWpp || null;
        const opName     = msg.operatorName || att_operator_name || null;
        const deptName   = msg.departmentName || att_department || null;

        // Resolve phone (normalise to last 10 digits)
        const rawPhone = msg.clientNumber || client_number || '';
        const normPhone = normalizePhone(rawPhone);

        // Resolve client_id if not on the attendance row
        let resolvedClientId = client_id;
        if (!resolvedClientId && normPhone) {
          const last10 = normPhone.slice(-10);
          const clRes = await dbClient.query(
            `SELECT id FROM clients
             WHERE RIGHT(REGEXP_REPLACE(COALESCE(phone,''), '[^0-9]', '', 'g'), 10) = $1
                OR RIGHT(REGEXP_REPLACE(COALESCE(phone2,''), '[^0-9]', '', 'g'), 10) = $1
             LIMIT 1`, [last10]
          );
          resolvedClientId = clRes.rows[0]?.id || null;
        }

        try {
          await dbClient.query(
            `INSERT INTO gotalk_messages
               (gotalk_message_id, idwpp, gotalk_contact_id, client_id, phone_number,
                direction, body, message_type,
                attachment_url, attachment_name, attachment_mime_type,
                ack_status, operator_name, department, area,
                gotalk_attendance_id_ext, attendance_history_id,
                gotalk_channel_uuid, sent_at)
             VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19)
             ON CONFLICT (gotalk_message_id) DO UPDATE SET
               ack_status              = CASE WHEN $12 IS NOT NULL THEN $12 ELSE gotalk_messages.ack_status END,
               attendance_history_id   = COALESCE(EXCLUDED.attendance_history_id, gotalk_messages.attendance_history_id),
               gotalk_attendance_id_ext= COALESCE(EXCLUDED.gotalk_attendance_id_ext, gotalk_messages.gotalk_attendance_id_ext),
               idwpp                   = COALESCE(EXCLUDED.idwpp, gotalk_messages.idwpp),
               operator_name           = COALESCE(gotalk_messages.operator_name, EXCLUDED.operator_name),
               department              = COALESCE(gotalk_messages.department,    EXCLUDED.department),
               area                    = COALESCE(gotalk_messages.area, EXCLUDED.area),
               gotalk_channel_uuid     = COALESCE(gotalk_messages.gotalk_channel_uuid, EXCLUDED.gotalk_channel_uuid)`,
            [gotalkMsgId, idwpp, contactDbId, resolvedClientId, normPhone,
             direction, body, messageType,
             attachUrl, attachName, attachMime,
             ackStatus, opName, deptName, departmentToArea(deptName),
             gotalk_attendance_id, history_id,
             gotalk_channel_uuid || null, sentAt]
          );
          totalNew++;
        } catch (rowErr) {
          if (!rowErr.message.includes('unique') && !rowErr.message.includes('duplicate')) {
            console.warn('[Gotalk Poller] Erro ao inserir mensagem:', rowErr.message);
          }
        }
      }
    } finally {
      dbClient.release();
    }

    // Mark this attendance as fetched (skip on next cycle if already closed)
    await _pool.query(
      `UPDATE gotalk_attendance_history SET messages_last_fetched_at = NOW() WHERE id = $1`,
      [history_id]
    );
  }

  if (totalNew > 0 || totalAttendances > 0) {
    console.log(`[Gotalk Poller] Mensagens via atendimento: ${totalNew} registros, ${totalAttendances} atendimentos processados.`);
  }
}

// ─── HSM Templates sync ───────────────────────────────────────────────────
// Itera todos os canais ativos para garantir que templates de canais secundários
// também sejam sincronizados.
async function importHSMTemplates() {
  const channels = await loadActiveChannels();
  let channelList = channels;
  if (channelList.length === 0) {
    const primaryId = await getChannelId().catch(() => null);
    if (!primaryId) return;
    channelList = [{ channel_id: primaryId, id: null, name: 'primário' }];
  }

  let totalUpserted = 0;
  let totalTemplates = 0;

  for (const ch of channelList) {
    let data;
    try {
      const res = await gotalkFetch(`/message/templates/channelId/${ch.channel_id}`);
      if (!res.ok) {
        console.warn(`[Gotalk Poller] importHSMTemplates [${ch.name}]: API respondeu ${res.status}`);
        continue;
      }
      data = await res.json();
    } catch (err) {
      console.warn(`[Gotalk Poller] importHSMTemplates [${ch.name}]: falha ao buscar templates:`, err.message);
      continue;
    }

    const templates = Array.isArray(data) ? data : (data?.templates || data?.data || data?.result || data?.content || []);
    if (!templates.length) continue;

    totalTemplates += templates.length;
    for (const t of templates) {
      const name = t.name || t.templateName || t.template_name;
      if (!name) continue;

      const components = Array.isArray(t.components) ? t.components : [];
      const bodyComp   = components.find(c => (c.type || '').toUpperCase() === 'BODY');
      const headerComp = components.find(c => (c.type || '').toUpperCase() === 'HEADER' && (!c.format || c.format === 'TEXT'));
      const footerComp = components.find(c => (c.type || '').toUpperCase() === 'FOOTER');

      try {
        await _pool.query(`
          INSERT INTO gotalk_hsm_templates
            (template_name, gotalk_template_id, category, language, status, body_text, header_text, footer_text, raw_data, synced_at)
          VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, NOW())
          ON CONFLICT (template_name) DO UPDATE SET
            gotalk_template_id = EXCLUDED.gotalk_template_id,
            category   = EXCLUDED.category,
            language   = EXCLUDED.language,
            status     = EXCLUDED.status,
            body_text  = EXCLUDED.body_text,
            header_text= EXCLUDED.header_text,
            footer_text= EXCLUDED.footer_text,
            raw_data   = EXCLUDED.raw_data,
            synced_at  = NOW()
        `, [
          name,
          t._id || t.id || null,
          t.category || null,
          t.language || null,
          t.status   || null,
          bodyComp?.text   || null,
          headerComp?.text || null,
          footerComp?.text || null,
          JSON.stringify(t),
        ]);
        totalUpserted++;
      } catch (err) {
        console.warn(`[Gotalk Poller] importHSMTemplates [${ch.name}]: erro ao upsert "${name}":`, err.message);
      }
    }
  }

  console.log(`[Gotalk Poller] HSM templates: ${totalUpserted}/${totalTemplates} sincronizados (${channelList.length} canal(is)).`);
}

// ─── Multi-channel helpers ─────────────────────────────────────────────────

// Load all active channels from the gotalk_channels table.
// Returns [] if the table doesn't exist yet or the pool isn't ready.
async function loadActiveChannels() {
  if (!_pool) return [];
  try {
    const res = await _pool.query(
      `SELECT id, channel_id, name FROM gotalk_channels WHERE is_active = TRUE AND channel_id IS NOT NULL ORDER BY is_primary DESC, name ASC`
    );
    return res.rows;
  } catch (err) {
    // Table may not exist yet on first boot — silently return empty
    if (err.code !== '42P01') {
      console.warn('[Gotalk Poller] Erro ao carregar canais ativos:', err.message);
    }
    return [];
  }
}

// Import contacts across ALL active channels.
// Falls back to single-channel (primary from auth) when no channels are registered.
async function importContactsAllChannels() {
  const channels = await loadActiveChannels();
  if (channels.length === 0) {
    await importContacts();
    return;
  }
  for (const ch of channels) {
    console.log(`[Gotalk Poller] Importando contatos — canal: ${ch.name}`);
    await importContacts(ch.channel_id, ch.id);
  }
}

// Import operators across ALL active channels.
// Falls back to single-channel (primary from auth) when no channels are registered.
async function importOperatorsAllChannels() {
  const channels = await loadActiveChannels();
  if (channels.length === 0) {
    await importOperators();
    return;
  }
  for (const ch of channels) {
    console.log(`[Gotalk Poller] Importando operadores — canal: ${ch.name}`);
    await importOperators(ch.channel_id);
  }
}

// Import attendances across ALL active channels by iterating operator-based
// attendance import once per channel. Falls back to single-channel when needed.
async function importAttendancesAllChannels() {
  // importAttendances already iterates all operators stored in the DB (which
  // covers all channels), so a direct call is sufficient. This wrapper exists
  // to provide explicit multi-channel logging and a clear hook for future
  // per-channel strategies if the API requires it.
  const channels = await loadActiveChannels();
  const count = channels.length;
  if (count > 0) {
    console.log(`[Gotalk Poller] importAttendances multi-canal: ${count} canal(is) ativo(s).`);
  }
  await importAttendances();
}

// ─── Wrapper genérico: executa fn com flag anti-sobreposição ─────────────
async function runGuarded(key, label, fn) {
  return _scheduler.submit(key, async () => {
    const t = Date.now();
    try {
      await fn();
      const s = ((Date.now() - t) / 1000).toFixed(1);
      console.log(`[Gotalk Poller] ${label} concluído em ${s}s.`);
    } catch (err) {
      console.error(`[Gotalk Poller] Erro em ${label}:`, err.message);
    }
  });
}

// ─── Public API ───────────────────────────────────────────────────────────
// Auth retry policy: 3 total attempts (initial + up to 2 retries) before pausing.
// Delays per retry: 60 s → 5 min.
const _MAX_AUTH_RETRIES = 2;  // max retries after initial attempt → 3 total
const _AUTH_RETRY_DELAYS_MS = [60_000, 5 * 60_000]; // per retry attempt 1..2

function startPoller(pool, retryCount = 0) {
  if (!process.env.GOTALK_LOGIN || !process.env.GOTALK_PASSWORD) {
    console.warn('[Gotalk Poller] Credenciais não configuradas. Poller não iniciado.');
    return;
  }

  _pool = pool;
  const generation = retryCount === 0 ? ++_pollerGeneration : _pollerGeneration;
  if (retryCount === 0) console.log('[Gotalk Poller] Iniciando...');

  authenticate()
    .then(() => {
      if (generation !== _pollerGeneration) return;
      if (retryCount > 0) {
        console.log(`[Gotalk Poller] Autenticação bem-sucedida na tentativa ${retryCount + 1}/${_MAX_AUTH_RETRIES + 1}.`);
      }
      console.log(
        `[Gotalk Poller] Timers ativos — ` +
        `alta (atendimentos): ${INTERVAL_HIGH_MS / 1000}s | ` +
        `reconciliação (mensagens): ${INTERVAL_RECONCILE_MS / 1000}s | ` +
        `média: ${INTERVAL_MEDIUM_MS / 1000}s | baixa: ${INTERVAL_LOW_MS / 1000}s`
      );

      // ── ALTA PRIORIDADE (30s): apenas atendimentos ativos ──────────────────
      // Mensagens chegam via webhook em tempo real; não precisam de polling a 30s.
      // A reconciliação de mensagens roda a cada 5 min (ciclo RECONCILE abaixo).
      const runHigh = () => {
        runGuarded('operatorAtt', 'importAttendancesPerOperator', importAttendancesPerOperator);
      };
      runHigh();
      _timers.push(setInterval(runHigh, INTERVAL_HIGH_MS));

      // ── RECONCILIAÇÃO (5 min): mensagens que falharam no webhook ────────────
      // Fallback para capturar mensagens que chegaram sem webhook (rede instável,
      // restart do GoTalk, janela sem worker). Idempotente: ON CONFLICT DO NOTHING.
      const runReconcile = () => {
        runGuarded('activeMessages', 'importMessagesForActiveAttendances', importMessagesForActiveAttendances);
      };
      _timers.push(setTimeout(() => { runReconcile(); _timers.push(setInterval(runReconcile, INTERVAL_RECONCILE_MS)); }, 10 * 1000));

      // ── MÉDIA PRIORIDADE (2 min): histórico e ACK ──────────────────────────
      const runMedium = () => {
        runGuarded('attendanceHistory', 'importAttendanceHistory',           importAttendanceHistory);
        runGuarded('msgHistory',        'importMessagesForAttendanceHistory', importMessagesForAttendanceHistory);
        runGuarded('ackRefresh',        'refreshStaleAckMessages',           refreshStaleAckMessages);
      };
      _timers.push(setTimeout(() => { runMedium(); _timers.push(setInterval(runMedium, INTERVAL_MEDIUM_MS)); }, 15 * 1000));

      // ── BAIXA PRIORIDADE (10 min): contatos, operadores e templates ──────────
      const runLow = () => {
        runGuarded('contacts',     'importContacts',          importContactsAllChannels);
        runGuarded('operators',    'importOperators',         importOperatorsAllChannels);
        runGuarded('attendances',  'importAttendancesAllChannels', importAttendancesAllChannels);
        runGuarded('hsmTemplates', 'importHSMTemplates',     importHSMTemplates);
      };
      _timers.push(setTimeout(() => { runLow(); _timers.push(setInterval(runLow, INTERVAL_LOW_MS)); }, 5 * 1000));

      // ── CANAL DISCOVERY (24h): re-sincroniza lista de canais periodicamente ─
      // Garante que novos canais secundários adicionados na GoTalk sejam
      // detectados sem precisar reiniciar o Worker.
      const CHANNEL_SYNC_MS = 24 * 60 * 60 * 1000; // 24 horas
      _timers.push(setInterval(() => {
        void runGuarded('channelDiscovery', 'syncAllChannels', () => syncAllChannels(pool));
      }, CHANNEL_SYNC_MS));
    })
    .catch(err => {
      const totalAttempts = _MAX_AUTH_RETRIES + 1; // 3 total
      if (generation !== _pollerGeneration) return;
      if (retryCount >= _MAX_AUTH_RETRIES) {
        console.error(
          `[Gotalk Poller] PAUSADO — autenticação falhou após ${totalAttempts} tentativa(s): ${err.message}. ` +
          'Verifique GOTALK_LOGIN / GOTALK_PASSWORD e reinicie o servidor para retomar.'
        );
        return; // Explicit pause — no further retries
      }
      const delayMs = _AUTH_RETRY_DELAYS_MS[retryCount] || 5 * 60_000;
      const delaySec = Math.round(delayMs / 1000);
      console.error(
        `[Gotalk Poller] Falha na autenticação (tentativa ${retryCount + 1}/${totalAttempts}): ${err.message}. ` +
        `Próxima tentativa em ${delaySec}s.`
      );
      _timers.push(setTimeout(() => {
        if (generation === _pollerGeneration) startPoller(pool, retryCount + 1);
      }, delayMs));
    });
}

function stopPoller() {
  _pollerGeneration++;
  _timers.forEach(t => clearInterval(t));
  _timers = [];
  _scheduler.cancelPending();
  console.log('[Gotalk Poller] Parado.');
}

async function linkClientRetroactively(pool, clientId, phone, phone2) {
  const dbClient = await pool.connect();
  let linksCreated = 0;
  try {
    // Find unlinked Gotalk contacts matching by phone (last 10 digits, pure digits)
    const norm1 = normalizePhone(phone);
    const norm2 = normalizePhone(phone2);

    const phonesToCheck = [norm1, norm2].filter(Boolean).map(p => p.slice(-10));
    if (phonesToCheck.length === 0) return 0;

    const res = await dbClient.query(
      `SELECT id FROM gotalk_contacts
       WHERE client_id IS NULL
         AND RIGHT(COALESCE(phone_number,''), 10) = ANY($1::text[])`,
      [phonesToCheck]
    );

    for (const contact of res.rows) {
      await dbClient.query(
        `UPDATE gotalk_contacts SET client_id = $1, linked_at = NOW() WHERE id = $2`,
        [clientId, contact.id]
      );
      await dbClient.query(
        `UPDATE gotalk_messages SET client_id = $1
         WHERE gotalk_contact_id = $2 AND client_id IS NULL`,
        [clientId, contact.id]
      );
      // Retroactively fill client_id on attendances already imported for this contact.
      // AND client_id IS NULL is intentional — avoids overwriting manual links or
      // corrections already applied to previously imported attendances.
      await dbClient.query(
        `UPDATE gotalk_attendances SET client_id = $1
         WHERE gotalk_contact_id = $2 AND client_id IS NULL`,
        [clientId, contact.id]
      );
      // Store GoTalk contact ID directly in clients so the link persists even if phone changes
      await dbClient.query(
        `UPDATE clients SET gotalk_contact_id = $1, gotalk_channel_id = (
           SELECT channel_id FROM gotalk_contacts WHERE id = $1
         ) WHERE id = $2 AND gotalk_contact_id IS NULL`,
        [contact.id, clientId]
      );
      console.log(`[Gotalk] Cliente ${clientId} vinculado retroativamente ao contato ${contact.id}`);
      linksCreated++;
    }
  } finally {
    dbClient.release();
  }
  return linksCreated;
}

// Exposed for manual sync trigger (POST /api/gotalk/sync)
async function runOneCycle() {
  if (!_pool) {
    console.warn('[Gotalk] runOneCycle chamado antes de startPoller. Sem pool.');
    return;
  }
  await importContactsAllChannels();
  await importOperatorsAllChannels();
  await importAttendancesPerOperator();
  await importAttendanceHistory();
  await importAttendancesAllChannels();
  await importMessagesForAttendanceHistory();
  await importMessagesForActiveAttendances();
  await refreshStaleAckMessages();
}

export {
  startPoller,
  stopPoller,
  linkClientRetroactively,
  normalizePhone,
  departmentToArea,
  runOneCycle,
  importContacts,
  importOperators,
  importAttendancesPerOperator,
  upsertOperatorAttendance,
  importAttendanceHistory,
  upsertAttendanceHistory,
  importMessagesForAttendanceHistory,
  importAttendances,
  upsertAttendance,
  backfillMessagesForAttendance,
  importMessagesForActiveAttendances,
  importHSMTemplates,
};

/**
 * Gotalk Channel Discovery Service
 *
 * After authentication, fetches the primary channel (from login) and all
 * secondary channels via the API, then upserts them into gotalk_channels.
 *
 * Endpoints used:
 *   POST  /user/login                                  → primary channelId + token
 *   GET   /channel/secondary/channelId/:primaryId      → secondary channels list
 */

import { getChannelId, gotalkFetch } from './gotalkAuth.js';

/**
 * Syncs all GoTalk channels (primary + secondary) to the gotalk_channels table.
 * Safe to call multiple times — uses ON CONFLICT upsert.
 *
 * @param {import('pg').Pool} pool
 */
async function syncAllChannels(pool) {
  let primaryChannelId;
  try {
    primaryChannelId = await getChannelId();
  } catch (err) {
    console.warn('[Worker Channels] Não foi possível autenticar para buscar canais:', err.message);
    return;
  }

  if (!primaryChannelId) {
    console.warn('[Worker Channels] channelId primário não disponível após autenticação.');
    return;
  }

  // ── 1. Busca canais secundários via API ────────────────────────────────────
  let secondaries = [];
  try {
    const res = await gotalkFetch(`/channel/secondary/channelId/${primaryChannelId}`);
    if (res.ok) {
      const raw = await res.json();
      // API pode retornar array direto, { channels: [...] } ou { data: [...] }
      secondaries = Array.isArray(raw)
        ? raw
        : (raw.channels || raw.data || raw.result || []);
    } else {
      console.warn(`[Worker Channels] API de canais secundários respondeu ${res.status}.`);
    }
  } catch (err) {
    console.warn('[Worker Channels] Erro ao buscar canais secundários:', err.message);
  }

  // ── 2. Monta lista completa: primário + secundários ────────────────────────
  // O canal primário vem do login; name/phone podem vir dos secundários
  // caso a API retorne info sobre o próprio canal primário no array.
  const channelMap = new Map();

  // Sempre garantir o primário na tabela
  channelMap.set(primaryChannelId, {
    channelId: primaryChannelId,
    name: null,
    phone: null,
    isPrimary: true,
  });

  // Processar canais retornados pela API de secundários
  for (const ch of secondaries) {
    const id = ch._id || ch.id || ch.channelId || ch.channel_id || null;
    if (!id) continue;

    const name  = ch.name || ch.channelName || ch.channel_name || null;
    const phone = ch.phone || ch.phoneNumber || ch.phone_number || ch.number || null;

    if (channelMap.has(id)) {
      // Enriquecer o canal primário com nome/telefone se retornado na listagem
      const existing = channelMap.get(id);
      channelMap.set(id, {
        ...existing,
        name:  existing.name  || name,
        phone: existing.phone || phone,
      });
    } else {
      channelMap.set(id, {
        channelId: id,
        name:      name     || 'Canal Secundário',
        phone:     phone    || null,
        isPrimary: false,
      });
    }
  }

  // ── 3. Upsert no banco ─────────────────────────────────────────────────────
  let synced = 0;
  for (const ch of channelMap.values()) {
    const fallbackName = ch.isPrimary ? 'Canal Principal' : 'Canal Secundário';
    try {
      await pool.query(
        `INSERT INTO gotalk_channels (name, phone_number, channel_id, is_primary, is_active)
         VALUES ($1, $2, $3, $4, TRUE)
         ON CONFLICT (channel_id) DO UPDATE SET
           name         = COALESCE(EXCLUDED.name,         gotalk_channels.name),
           phone_number = COALESCE(EXCLUDED.phone_number, gotalk_channels.phone_number),
           is_primary   = EXCLUDED.is_primary,
           is_active    = TRUE,
           updated_at   = NOW()`,
        [ch.name || fallbackName, ch.phone || null, ch.channelId, ch.isPrimary]
      );
      synced++;
    } catch (err) {
      console.warn(`[Worker Channels] Erro ao upsert canal ${ch.channelId}:`, err.message);
    }
  }

  const total = channelMap.size;
  const secondaryCount = total - 1;
  console.log(
    `[Worker Channels] Canais sincronizados: ${synced}/${total} ` +
    `(1 primário + ${secondaryCount} secundário(s)).`
  );
}

export { syncAllChannels };

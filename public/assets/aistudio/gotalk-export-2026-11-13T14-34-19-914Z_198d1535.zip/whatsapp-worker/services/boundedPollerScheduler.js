/**
 * FIFO with one pending/running entry per task key. Poll intervals cannot grow
 * the queue while a previous execution is waiting or still using the database.
 */
export function createBoundedPollerScheduler({ concurrency = 2 } = {}) {
  if (!Number.isInteger(concurrency) || concurrency < 1) {
    throw new Error('Poller concurrency must be a positive integer.');
  }
  const pending = [];
  const jobs = new Map();
  let active = 0;

  function finish(job, success, result) {
    active--;
    jobs.delete(job.key);
    drain();
    if (success) job.resolve(result);
    else job.reject(result);
  }

  function drain() {
    while (active < concurrency && pending.length) {
      const job = pending.shift();
      active++;
      Promise.resolve().then(job.run).then(
        result => finish(job, true, result),
        error => finish(job, false, error),
      );
    }
  }

  return {
    submit(key, run) {
      if (jobs.has(key)) return jobs.get(key).promise;
      let resolve, reject;
      const promise = new Promise((ok, fail) => { resolve = ok; reject = fail; });
      const job = { key, run, promise, resolve, reject };
      jobs.set(key, job);
      pending.push(job);
      drain();
      return promise;
    },
    cancelPending() {
      const count = pending.length;
      for (const job of pending.splice(0)) {
        jobs.delete(job.key);
        job.resolve(undefined);
      }
      return count;
    },
    get activeCount() { return active; },
    get pendingCount() { return pending.length; },
  };
}

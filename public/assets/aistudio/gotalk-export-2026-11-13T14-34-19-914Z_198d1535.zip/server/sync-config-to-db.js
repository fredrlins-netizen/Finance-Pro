import crypto from 'crypto';
import { validateReferenceIds, validateClientRelationshipOwnership } from './lib/referenceIdentity.js';

const NAMESPACE_UUID = '6ba7b810-9dad-11d1-80b4-00c04fd430c8';

function deterministicUUID(input) {
  const hash = crypto.createHash('sha1').update(NAMESPACE_UUID + String(input)).digest('hex');
  const uuid = [
    hash.substring(0, 8),
    hash.substring(8, 12),
    '5' + hash.substring(13, 16),
    ((parseInt(hash.substring(16, 18), 16) & 0x3f) | 0x80).toString(16).padStart(2, '0') + hash.substring(18, 20),
    hash.substring(20, 32)
  ].join('-');
  return uuid;
}

function isValidUUID(str) {
  return /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(str);
}

function toUUID(id) {
  if (!id) return deterministicUUID('unknown-' + Math.random());
  if (isValidUUID(String(id))) return String(id);
  return deterministicUUID(String(id));
}

function parseDate(val) {
  if (!val) return null;
  const d = new Date(val);
  return isNaN(d.getTime()) ? null : d.toISOString().split('T')[0];
}

function parseTimestamp(val) {
  if (!val) return null;
  const d = new Date(val);
  return isNaN(d.getTime()) ? null : d.toISOString();
}

function parseNumber(val) {
  if (val === null || val === undefined || val === '') return 0;
  const n = Number(val);
  return isNaN(n) ? 0 : n;
}

function parseIntOrNull(val) {
  if (val === null || val === undefined || val === '') return null;
  const n = parseInt(val, 10);
  return isNaN(n) ? null : n;
}

const idMap = new Map();

function mapId(entity, originalId) {
  if (!originalId) return null;
  const uuid = toUUID(originalId);
  idMap.set(`${entity}:${originalId}`, uuid);
  return uuid;
}

function lookupId(entity, originalId) {
  if (!originalId) return null;
  if (isValidUUID(String(originalId))) return String(originalId);
  return idMap.get(`${entity}:${originalId}`) || toUUID(originalId);
}

async function syncConfigToDB(pool) {
  const dbClient = await pool.connect();
  try {
    const result = await dbClient.query("SELECT value FROM app_data WHERE key = 'portal_config'");
    if (result.rows.length === 0) {
      console.log('Sync: No portal_config found. Skipping.');
      return;
    }
    const config = result.rows[0].value;

    const migrationCheck = await dbClient.query(
      "SELECT value FROM app_data WHERE key = 'migration_status'"
    );
    const lastMigration = migrationCheck.rows.length > 0 ? migrationCheck.rows[0].value : null;

    await dbClient.query('BEGIN');

    const counts = {};

    const syncSteps = [
      ['units', syncUnits],
      ['userGroups', syncUserGroups],
      ['clients', syncClients],
      ['departments', syncDepartments],
      ['collaborators', syncCollaborators],
      ['banks', syncBanks],
      ['bankAccounts', syncBankAccounts],
      ['modalities', syncModalities],
      ['measurementUnits', syncMeasurementUnits],
      ['products', syncProducts],
      ['series', syncSeries],
      ['documentTypes', syncDocumentTypes],
      ['bearers', syncBearers],
      ['defaultBearers', (dbClient) => ensureDefaultBearers(dbClient)],
      ['chartOfAccounts', syncChartOfAccounts],
      ['users', syncUsers],
      ['admissions', syncAdmissions],
      ['financialTitles', syncFinancialTitles],
      ['appointments', syncAppointments],
      ['scheduleBlocks', syncScheduleBlocks],
      ['legalProcesses', syncLegalProcesses],
      ['configOptions', syncConfigOptions],
    ];

    const errors = [];
    for (const [name, fn] of syncSteps) {
      try {
        await dbClient.query(`SAVEPOINT sp_${name}`);
        counts[name] = await fn(dbClient, config);
        await dbClient.query(`RELEASE SAVEPOINT sp_${name}`);
      } catch (err) {
        await dbClient.query(`ROLLBACK TO SAVEPOINT sp_${name}`);
        console.warn(`Sync warning: ${name} failed - ${err.message}`);
        errors.push({ entity: name, error: err.message });
        counts[name] = 0;
      }
    }

    await dbClient.query(
      `INSERT INTO app_data (key, value, updated_at)
       VALUES ('migration_status', $1, NOW())
       ON CONFLICT (key) DO UPDATE SET value = $1, updated_at = NOW()`,
      [JSON.stringify({ lastMigration: new Date().toISOString(), counts })]
    );

    await dbClient.query('COMMIT');

    const summary = Object.entries(counts)
      .filter(([, v]) => v > 0)
      .map(([k, v]) => `${v} ${k}`)
      .join(', ');
    console.log(`Sync complete: ${summary || 'no data to sync'}.`);
  } catch (err) {
    await dbClient.query('ROLLBACK').catch(() => {});
    console.error('Error syncing config to DB:', err.message);
  } finally {
    dbClient.release();
  }
}

async function syncUnits(dbClient, config) {
  const units = config.units || [];
  let count = 0;
  for (const u of units) {
    const uuid = mapId('unit', u.id);
    await dbClient.query(`
      INSERT INTO companies (id, razao_social, cnpj, email, telefone, cep, endereco, numero, complemento, bairro, cidade, estado,
        email_sender_name, email_host, email_port, email_user, email_security,
        google_connected, google_account_email, created_at, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,NOW(),NOW())
      ON CONFLICT (id) DO UPDATE SET
        razao_social=EXCLUDED.razao_social, cnpj=EXCLUDED.cnpj, email=EXCLUDED.email, telefone=EXCLUDED.telefone,
        cep=EXCLUDED.cep, endereco=EXCLUDED.endereco, numero=EXCLUDED.numero, complemento=EXCLUDED.complemento,
        bairro=EXCLUDED.bairro, cidade=EXCLUDED.cidade, estado=EXCLUDED.estado,
        email_sender_name=EXCLUDED.email_sender_name, email_host=EXCLUDED.email_host, email_port=EXCLUDED.email_port,
        email_user=EXCLUDED.email_user, email_security=EXCLUDED.email_security,
        google_connected=EXCLUDED.google_connected, google_account_email=EXCLUDED.google_account_email,
        updated_at=NOW()
    `, [
      uuid,
      u.razaoSocial || u.razao_social || 'Sem nome',
      u.cnpj || null,
      u.email || null,
      u.telefone || null,
      u.cep || null,
      u.endereco || null,
      u.numero || null,
      u.complemento || null,
      u.bairro || null,
      u.cidade || null,
      u.estado || null,
      u.emailConfig?.senderName || null,
      u.emailConfig?.host || null,
      u.emailConfig?.port || null,
      u.emailConfig?.user || null,
      u.emailConfig?.security || 'TLS',
      u.googleIntegration?.isConnected === true,
      u.googleIntegration?.accountEmail || null
    ]);
    count++;
  }
  return count;
}

async function syncUserGroups(dbClient, config) {
  const groups = config.userGroups || [];
  let count = 0;
  for (const g of groups) {
    const uuid = mapId('userGroup', g.id);
    await dbClient.query(`
      INSERT INTO user_groups (id, name, created_at, updated_at)
      VALUES ($1, $2, NOW(), NOW())
      ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, updated_at=NOW()
    `, [uuid, g.name || 'Sem nome']);

    await dbClient.query(`DELETE FROM user_group_permissions WHERE group_id = $1`, [uuid]);
    const permissions = g.permissions || [];
    for (const perm of permissions) {
      await dbClient.query(`
        INSERT INTO user_group_permissions (group_id, permission)
        VALUES ($1, $2)
        ON CONFLICT (group_id, permission) DO NOTHING
      `, [uuid, perm]);
    }
    count++;
  }
  return count;
}

async function syncClients(dbClient, config) {
  const clients = config.clients || [];
  let count = 0;
  for (const c of clients) {
    const uuid = mapId('client', c.id);
    await dbClient.query(`
      INSERT INTO clients (id, name, type, document, rg, phone, phone2, is_whatsapp, email, profession, marital_status, birth_date, cep, address, number, complement, district, city, state, notes, created_at, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,NOW(),NOW())
      ON CONFLICT (id) DO UPDATE SET
        name=EXCLUDED.name, type=EXCLUDED.type, document=EXCLUDED.document, rg=EXCLUDED.rg,
        phone=EXCLUDED.phone, phone2=EXCLUDED.phone2, is_whatsapp=EXCLUDED.is_whatsapp, email=EXCLUDED.email,
        profession=EXCLUDED.profession, marital_status=EXCLUDED.marital_status, birth_date=EXCLUDED.birth_date,
        cep=EXCLUDED.cep, address=EXCLUDED.address, number=EXCLUDED.number, complement=EXCLUDED.complement,
        district=EXCLUDED.district, city=EXCLUDED.city, state=EXCLUDED.state, notes=EXCLUDED.notes, updated_at=NOW()
    `, [
      uuid,
      c.name || null,
      c.type || 'FISICA',
      c.document || null,
      c.rg || null,
      c.phone || null,
      c.phone2 || null,
      c.isWhatsapp === true,
      c.email || null,
      c.profession || null,
      c.maritalStatus || null,
      parseDate(c.birthDate),
      c.cep || null,
      c.address || null,
      c.number || null,
      c.complement || null,
      c.district || null,
      c.city || null,
      c.state || null,
      c.notes || null
    ]);
    count++;
  }
  return count;
}

async function syncCollaborators(dbClient, config) {
  const collaborators = config.collaborators || [];
  let count = 0;
  for (const co of collaborators) {
    const uuid = mapId('collaborator', co.id);
    const unitId = co.unitId ? lookupId('unit', co.unitId) : null;
    const departmentId = co.departmentId ? lookupId('department', co.departmentId) : null;
    await dbClient.query(`
      INSERT INTO collaborators (id, name, photo_url, job_title, phone, is_whatsapp, email, marital_status, birth_date, cep, address, number, complement, district, city, state, notes, unit_id, department_id, active, created_at, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,NOW(),NOW())
      ON CONFLICT (id) DO UPDATE SET
        name=EXCLUDED.name, photo_url=EXCLUDED.photo_url, job_title=EXCLUDED.job_title, phone=EXCLUDED.phone,
        is_whatsapp=EXCLUDED.is_whatsapp, email=EXCLUDED.email, marital_status=EXCLUDED.marital_status,
        birth_date=EXCLUDED.birth_date, cep=EXCLUDED.cep, address=EXCLUDED.address, number=EXCLUDED.number,
        complement=EXCLUDED.complement, district=EXCLUDED.district, city=EXCLUDED.city, state=EXCLUDED.state,
        notes=EXCLUDED.notes, unit_id=EXCLUDED.unit_id, department_id=EXCLUDED.department_id, active=EXCLUDED.active,
        updated_at=NOW()
    `, [
      uuid,
      co.name || null,
      co.photoUrl || null,
      co.jobTitle || null,
      co.phone || null,
      co.isWhatsapp === true,
      co.email || null,
      co.maritalStatus || null,
      parseDate(co.birthDate),
      co.cep || null,
      co.address || null,
      co.number || null,
      co.complement || null,
      co.district || null,
      co.city || null,
      co.state || null,
      co.notes || null,
      unitId,
      departmentId,
      co.active !== false
    ]);
    count++;
  }
  return count;
}

async function syncBanks(dbClient, config) {
  const banks = config.banks || [];
  let count = 0;
  for (const b of banks) {
    const uuid = mapId('bank', b.id);
    await dbClient.query(`
      INSERT INTO banks (id, name, status, febraban_code, notes, created_at, updated_at)
      VALUES ($1,$2,$3,$4,$5,NOW(),NOW())
      ON CONFLICT (id) DO UPDATE SET
        name=EXCLUDED.name, status=EXCLUDED.status, febraban_code=EXCLUDED.febraban_code,
        notes=EXCLUDED.notes, updated_at=NOW()
    `, [
      uuid,
      b.name || 'Sem nome',
      b.status || 'ATIVO',
      b.febrabanCode || null,
      b.notes || null
    ]);

    await dbClient.query(`DELETE FROM bank_services WHERE bank_id = $1`, [uuid]);
    const services = b.services || [];
    for (const s of services) {
      const sUuid = mapId('bankService', s.id);
      await dbClient.query(`
        INSERT INTO bank_services (id, bank_id, name, negotiation_percentage)
        VALUES ($1, $2, $3, $4)
        ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, negotiation_percentage=EXCLUDED.negotiation_percentage
      `, [sUuid, uuid, s.name || '', parseNumber(s.negotiationPercentage)]);
    }
    count++;
  }
  return count;
}

async function syncBankAccounts(dbClient, config) {
  const accounts = config.bankAccounts || [];
  let count = 0;
  for (const a of accounts) {
    const uuid = mapId('bankAccount', a.id);
    const bankId = a.bankId ? lookupId('bank', a.bankId) : null;
    await dbClient.query(`
      INSERT INTO bank_accounts (id, description, account_type, bank_id, bank_name, agency, account_number,
        account_nature, agency_name, assignor_number, initial_balance, initial_balance_date,
        current_balance, is_default, status, created_at, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,NOW(),NOW())
      ON CONFLICT (id) DO UPDATE SET
        description=EXCLUDED.description, account_type=EXCLUDED.account_type, bank_id=EXCLUDED.bank_id,
        bank_name=EXCLUDED.bank_name, agency=EXCLUDED.agency, account_number=EXCLUDED.account_number,
        account_nature=EXCLUDED.account_nature, agency_name=EXCLUDED.agency_name, assignor_number=EXCLUDED.assignor_number,
        initial_balance=EXCLUDED.initial_balance, initial_balance_date=EXCLUDED.initial_balance_date,
        current_balance=EXCLUDED.current_balance, is_default=EXCLUDED.is_default, status=EXCLUDED.status, updated_at=NOW()
    `, [
      uuid,
      a.description || 'Sem descrição',
      a.accountType || 'CORRENTE',
      bankId,
      a.bankName || null,
      a.agency || null,
      a.accountNumber || null,
      a.accountNature || null,
      a.agencyName || null,
      a.assignorNumber || null,
      parseNumber(a.initialBalance),
      parseDate(a.initialBalanceDate),
      parseNumber(a.currentBalance),
      a.isDefault === true,
      a.status || 'ATIVA'
    ]);
    count++;
  }
  return count;
}

async function syncModalities(dbClient, config) {
  const modalities = config.modalities || [];
  let count = 0;
  for (const m of modalities) {
    const uuid = mapId('modality', m.id);
    await dbClient.query(`
      INSERT INTO modalities (id, type, description)
      VALUES ($1, $2, $3)
      ON CONFLICT (id) DO UPDATE SET type=EXCLUDED.type, description=EXCLUDED.description
    `, [uuid, m.type || '', m.description || null]);
    count++;
  }
  return count;
}

async function syncMeasurementUnits(dbClient, config) {
  const units = config.measurementUnits || [];
  let count = 0;
  for (const mu of units) {
    const uuid = mapId('measurementUnit', mu.id);
    await dbClient.query(`
      INSERT INTO measurement_units (id, name, conversion_factor)
      VALUES ($1, $2, $3)
      ON CONFLICT (id) DO UPDATE SET name=EXCLUDED.name, conversion_factor=EXCLUDED.conversion_factor
    `, [uuid, mu.name || '', parseNumber(mu.conversionFactor || 1)]);
    count++;
  }
  return count;
}

async function syncProducts(dbClient, config) {
  const products = config.products || [];
  let count = 0;
  for (const p of products) {
    const uuid = mapId('product', p.id);
    const unitId = p.unitId ? lookupId('measurementUnit', p.unitId) : null;
    await dbClient.query(`
      INSERT INTO products (id, type, description, unit_id, created_at)
      VALUES ($1, $2, $3, $4, NOW())
      ON CONFLICT (id) DO UPDATE SET type=EXCLUDED.type, description=EXCLUDED.description, unit_id=EXCLUDED.unit_id
    `, [uuid, p.type || 'SERVICO', p.description || '', unitId]);
    count++;
  }
  return count;
}

async function syncSeries(dbClient, config) {
  const seriesList = config.series || [];
  let count = 0;
  for (const s of seriesList) {
    const uuid = mapId('series', s.id);
    await dbClient.query(`
      INSERT INTO series (id, sigla, description, general_number)
      VALUES ($1, $2, $3, $4)
      ON CONFLICT (id) DO UPDATE SET sigla=EXCLUDED.sigla, description=EXCLUDED.description, general_number=EXCLUDED.general_number
    `, [uuid, s.sigla || '', s.description || null, parseIntOrNull(s.generalNumber) || 0]);

    const numbering = s.unitNumbering || [];
    for (const un of numbering) {
      const unitUuid = lookupId('unit', un.unitId);
      if (unitUuid) {
        const sunId = deterministicUUID(`sun-${s.id}-${un.unitId}`);
        await dbClient.query(`
          INSERT INTO series_unit_numbering (id, series_id, unit_id, current_number)
          VALUES ($1, $2, $3, $4)
          ON CONFLICT (series_id, unit_id) DO UPDATE SET current_number=EXCLUDED.current_number
        `, [sunId, uuid, unitUuid, parseIntOrNull(un.currentNumber) || 0]);
      }
    }
    count++;
  }
  return count;
}

async function syncDocumentTypes(dbClient, config) {
  const types = config.documentTypes || [];
  let count = 0;
  for (const dt of types) {
    const uuid = mapId('documentType', dt.id);
    await dbClient.query(`
      INSERT INTO document_types (id, description, category, is_fiscal, status, requires_doc_number)
      VALUES ($1, $2, $3, $4, $5, $6)
      ON CONFLICT (id) DO UPDATE SET
        description=EXCLUDED.description, category=EXCLUDED.category, is_fiscal=EXCLUDED.is_fiscal,
        status=EXCLUDED.status, requires_doc_number=EXCLUDED.requires_doc_number
    `, [
      uuid,
      dt.description || '',
      dt.category || 'AMBOS',
      dt.isFiscal === true,
      dt.status || 'ATIVO',
      dt.requiresDocNumber === true
    ]);
    count++;
  }
  return count;
}

async function syncBearers(dbClient, config) {
  const bearers = config.bearers || [];
  let count = 0;
  for (const b of bearers) {
    const uuid = mapId('bearer', b.id);
    const assocAccountId = b.associatedBankAccountId ? lookupId('bankAccount', b.associatedBankAccountId) : null;
    await dbClient.query(`
      INSERT INTO bearers (id, code, name, type, associated_bank_account_id, status, agency_code, contract_code)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
      ON CONFLICT (id) DO UPDATE SET
        code=EXCLUDED.code, name=EXCLUDED.name, type=EXCLUDED.type,
        associated_bank_account_id=EXCLUDED.associated_bank_account_id, status=EXCLUDED.status,
        agency_code=EXCLUDED.agency_code, contract_code=EXCLUDED.contract_code
    `, [
      uuid,
      b.code || '',
      b.name || '',
      b.type || 'CARTEIRA',
      assocAccountId,
      b.status || 'ATIVO',
      b.agencyCode || null,
      b.contractCode || null
    ]);
    count++;
  }
  return count;
}

async function ensureDefaultBearers(dbClient) {
  const { rows } = await dbClient.query('SELECT COUNT(*) as cnt FROM bearers');
  if (parseInt(rows[0].cnt) > 0) return 0;

  const defaults = [
    { code: '001', name: 'CARTEIRA PRÓPRIA', type: 'CARTEIRA' },
    { code: '002', name: 'COBRANÇA BANCÁRIA', type: 'BANCO' },
    { code: '003', name: 'CARTÓRIO', type: 'CARTORIO' },
    { code: '004', name: 'JURÍDICO', type: 'JURIDICO' },
    { code: '005', name: 'TERCEIROS', type: 'TERCEIROS' },
  ];
  let count = 0;
  for (const b of defaults) {
    const id = deterministicUUID('default-bearer-' + b.code);
    await dbClient.query(
      'INSERT INTO bearers (id, code, name, type, status) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (id) DO NOTHING',
      [id, b.code, b.name, b.type, 'ATIVO']
    );
    count++;
  }
  return count;
}

async function syncChartOfAccounts(dbClient, config) {
  const accounts = config.chartOfAccounts || [];
  let count = 0;
  for (const a of accounts) {
    mapId('chartOfAccount', a.id);
  }
  for (const a of accounts) {
    const uuid = lookupId('chartOfAccount', a.id);
    const parentId = a.parentId ? lookupId('chartOfAccount', a.parentId) : null;
    await dbClient.query(`
      INSERT INTO chart_of_accounts (id, code, name, type, parent_id, is_analytical, is_system)
      VALUES ($1, $2, $3, $4, $5, $6, $7)
      ON CONFLICT (id) DO UPDATE SET
        code=EXCLUDED.code, name=EXCLUDED.name, type=EXCLUDED.type, parent_id=EXCLUDED.parent_id,
        is_analytical=EXCLUDED.is_analytical, is_system=EXCLUDED.is_system
    `, [
      uuid,
      a.code || '',
      a.name || '',
      a.type || 'DESPESA',
      parentId,
      a.isAnalytical === true,
      a.isSystem === true
    ]);
    count++;
  }
  return count;
}

async function syncDepartments(dbClient, config) {
  const departments = config.departments || [];
  let count = 0;
  for (const d of departments) {
    const uuid = mapId('department', d.id);
    await dbClient.query(`
      INSERT INTO departments (id, code, name, manager_name, status)
      VALUES ($1, $2, $3, $4, $5)
      ON CONFLICT (id) DO UPDATE SET
        code=EXCLUDED.code, name=EXCLUDED.name, manager_name=EXCLUDED.manager_name, status=EXCLUDED.status
    `, [
      uuid,
      d.code || null,
      d.name || '',
      d.managerName || null,
      d.status || 'ATIVO'
    ]);
    count++;
  }
  return count;
}

async function syncUsers(dbClient, config) {
  const users = config.users || [];
  let count = 0;
  for (const u of users) {
    const uuid = mapId('user', u.id);
    const collaboratorId = u.collaboratorId ? lookupId('collaborator', u.collaboratorId) : null;
    await dbClient.query(`
      INSERT INTO users (id, name, email, role, status, photo_url, initial_password, force_change_password, collaborator_id, created_at, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,NOW(),NOW())
      ON CONFLICT (id) DO UPDATE SET
        name=EXCLUDED.name, email=EXCLUDED.email, role=EXCLUDED.role, status=EXCLUDED.status,
        photo_url=EXCLUDED.photo_url, initial_password=EXCLUDED.initial_password,
        force_change_password=EXCLUDED.force_change_password, collaborator_id=EXCLUDED.collaborator_id, updated_at=NOW()
    `, [
      uuid,
      u.name || 'Sem nome',
      u.email || `user-${uuid}@placeholder.local`,
      u.role || 'USER',
      u.status || 'ATIVO',
      u.photoUrl || null,
      u.initialPassword || null,
      u.forceChangePassword === true,
      collaboratorId
    ]);

    await dbClient.query(`DELETE FROM user_allowed_units WHERE user_id = $1`, [uuid]);
    const allowedUnits = u.allowedUnitIds || [];
    for (const unitId of allowedUnits) {
      const unitUuid = lookupId('unit', unitId);
      if (unitUuid) {
        await dbClient.query(`
          INSERT INTO user_allowed_units (user_id, unit_id) VALUES ($1, $2)
          ON CONFLICT DO NOTHING
        `, [uuid, unitUuid]);
      }
    }

    await dbClient.query(`DELETE FROM user_group_members WHERE user_id = $1`, [uuid]);
    const groupIds = u.groupIds || [];
    for (const gId of groupIds) {
      const groupUuid = lookupId('userGroup', gId);
      if (groupUuid) {
        await dbClient.query(`
          INSERT INTO user_group_members (user_id, group_id) VALUES ($1, $2)
          ON CONFLICT DO NOTHING
        `, [uuid, groupUuid]);
      }
    }
    count++;
  }
  return count;
}

async function syncAdmissions(dbClient, config) {
  const admissions = config.admissions || [];
  let count = 0;
  for (const a of admissions) {
    const uuid = mapId('admission', a.id);
    const clientId = a.clientId ? lookupId('client', a.clientId) : null;
    const bankId = a.bankId ? lookupId('bank', a.bankId) : null;
    const collaboratorId = a.collaboratorId ? lookupId('collaborator', a.collaboratorId) : null;
    const seriesId = a.seriesId ? lookupId('series', a.seriesId) : null;
    const modalityId = a.modalityId ? lookupId('modality', a.modalityId) : null;
    const unitId = a.unitId ? lookupId('unit', a.unitId) : null;
    const titularClientId = a.titularClientId ? lookupId('client', a.titularClientId) : null;
    await validateReferenceIds(dbClient, { unitId, titularClientId }, [
      ['unitId', 'companies', 'Unidade'], ['titularClientId', 'clients', 'Cliente titular'],
    ]);

    await dbClient.query(`
      INSERT INTO admissions (id, date, client_id, client_name, bank_id, collaborator_id, series_id, modality_id,
        contract_number, total_installments, paid_installments, overdue_installments,
        financed_amount, installment_value, due_day, payment_type, indication_type, status,
        vehicle_brand, vehicle_model, vehicle_color, vehicle_year, vehicle_plate, vehicle_chassis, vehicle_renavam,
        is_electric_vehicle, first_installment_due_date, has_bank_fee_included, is_third_party_contract,
        audit_critique, parcela1, parcela2, taxa_cobranca, other_info1, other_info2, unit_id, titular_client_id, created_at, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,NOW(),NOW())
      ON CONFLICT (id) DO UPDATE SET
        date=EXCLUDED.date, client_id=EXCLUDED.client_id, client_name=EXCLUDED.client_name,
        bank_id=EXCLUDED.bank_id, collaborator_id=EXCLUDED.collaborator_id, series_id=EXCLUDED.series_id,
        modality_id=EXCLUDED.modality_id, contract_number=EXCLUDED.contract_number,
        total_installments=EXCLUDED.total_installments, paid_installments=EXCLUDED.paid_installments,
        overdue_installments=EXCLUDED.overdue_installments, financed_amount=EXCLUDED.financed_amount,
        installment_value=EXCLUDED.installment_value, due_day=EXCLUDED.due_day,
        payment_type=EXCLUDED.payment_type, indication_type=EXCLUDED.indication_type, status=EXCLUDED.status,
        vehicle_brand=EXCLUDED.vehicle_brand, vehicle_model=EXCLUDED.vehicle_model, vehicle_color=EXCLUDED.vehicle_color,
        vehicle_year=EXCLUDED.vehicle_year, vehicle_plate=EXCLUDED.vehicle_plate, vehicle_chassis=EXCLUDED.vehicle_chassis,
        vehicle_renavam=EXCLUDED.vehicle_renavam, is_electric_vehicle=EXCLUDED.is_electric_vehicle,
        first_installment_due_date=EXCLUDED.first_installment_due_date, has_bank_fee_included=EXCLUDED.has_bank_fee_included,
        is_third_party_contract=EXCLUDED.is_third_party_contract, audit_critique=EXCLUDED.audit_critique,
        parcela1=EXCLUDED.parcela1, parcela2=EXCLUDED.parcela2, taxa_cobranca=EXCLUDED.taxa_cobranca,
        other_info1=EXCLUDED.other_info1, other_info2=EXCLUDED.other_info2,
        unit_id=EXCLUDED.unit_id, titular_client_id=EXCLUDED.titular_client_id, updated_at=NOW()
    `, [
      uuid,
      parseTimestamp(a.date) || new Date().toISOString(),
      clientId,
      a.clientName || null,
      bankId,
      collaboratorId,
      seriesId,
      modalityId,
      a.contractNumber || null,
      a.totalInstallments || null,
      a.paidInstallments || null,
      a.overdueInstallments || null,
      a.financedAmount || null,
      a.installmentValue || null,
      a.dueDay || null,
      a.paymentType || null,
      a.indicationType || null,
      a.status || 'PENDENTE',
      a.vehicleBrand || null,
      a.vehicleModel || null,
      a.vehicleColor || null,
      a.vehicleYear || null,
      a.vehiclePlate || null,
      a.vehicleChassis || null,
      a.vehicleRenavam || null,
      a.isElectricVehicle === true,
      parseDate(a.firstInstallmentDueDate),
      a.hasBankFeeIncluded === true,
      a.isThirdPartyContract === true,
      a.auditCritique || null,
      a.parcela1 || null,
      a.parcela2 || null,
      a.taxaCobranca || null,
      a.otherInfo1 || null,
      a.otherInfo2 || null,
      unitId, titularClientId
    ]);

    await dbClient.query(`DELETE FROM recalc_scenarios WHERE admission_id = $1`, [uuid]);
    const scenarios = a.recalcScenarios || [];
    for (const sc of scenarios) {
      const scUuid = toUUID(sc.id || `recalc-${a.id}-${Math.random()}`);
      await dbClient.query(`
        INSERT INTO recalc_scenarios (id, admission_id, label, installments_to_pay, original_debt, installment_value, new_debt, savings, due_day)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
        ON CONFLICT (id) DO UPDATE SET
          admission_id = EXCLUDED.admission_id,
          label = EXCLUDED.label,
          installments_to_pay = EXCLUDED.installments_to_pay,
          original_debt = EXCLUDED.original_debt,
          installment_value = EXCLUDED.installment_value,
          new_debt = EXCLUDED.new_debt,
          savings = EXCLUDED.savings,
          due_day = EXCLUDED.due_day
      `, [
        scUuid, uuid, sc.label || null, sc.installmentsToPay || null,
        sc.originalDebt || null, sc.installmentValue || null,
        sc.newDebt || null, sc.savings || null, sc.dueDay || null
      ]);
    }

    await dbClient.query(`DELETE FROM admission_attachments WHERE admission_id = $1`, [uuid]);
    const attachments = a.attachments || [];
    for (const att of attachments) {
      const attUuid = toUUID(att.id || `att-${a.id}-${Math.random()}`);
      await dbClient.query(`
        INSERT INTO admission_attachments (id, admission_id, title, file_name, file_data)
        VALUES ($1,$2,$3,$4,$5)
      `, [attUuid, uuid, att.title || null, att.fileName || null, att.fileData || null]);
    }

    if (a.legalScan) {
      const ls = a.legalScan;
      await dbClient.query(`
        INSERT INTO admission_legal_scans (id, admission_id, found, process_number, court, last_movement, last_update, plaintiff)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
        ON CONFLICT (admission_id) DO UPDATE SET
          found=EXCLUDED.found, process_number=EXCLUDED.process_number, court=EXCLUDED.court,
          last_movement=EXCLUDED.last_movement, last_update=EXCLUDED.last_update, plaintiff=EXCLUDED.plaintiff
      `, [
        deterministicUUID(`legal-scan-${a.id}`),
        uuid,
        ls.found === true,
        ls.processNumber || null,
        ls.court || null,
        ls.lastMovement || null,
        parseTimestamp(ls.lastUpdate),
        ls.plaintiff || null
      ]);
    }

    count++;
  }
  return count;
}

async function syncFinancialTitles(dbClient, config) {
  const titles = config.receivableTitles || [];
  let count = 0;

  for (const t of titles) {
    mapId('financialTitle', t.id);
  }

  for (const t of titles) {
    const uuid = lookupId('financialTitle', t.id);
    const clientId = t.clientId ? lookupId('client', t.clientId) : null;
    const categoryId = t.categoryId ? lookupId('chartOfAccount', t.categoryId) : null;
    const documentTypeId = t.documentTypeId ? lookupId('documentType', t.documentTypeId) : null;
    const bearerId = t.bearerId ? lookupId('bearer', t.bearerId) : null;
    const departmentId = t.departmentId ? lookupId('department', t.departmentId) : null;
    const bankAccountId = t.bankAccountId ? lookupId('bankAccount', t.bankAccountId) : null;
    const unitId = t.unitId ? lookupId('unit', t.unitId) : null;
    const sellerId = t.sellerId ? lookupId('collaborator', t.sellerId) : null;
    const parentId = t.parentId ? lookupId('financialTitle', t.parentId) : null;
    const admissionId = t.admissionId ? lookupId('admission', t.admissionId) : null;
    const assignedCollabId = t.assignedCollaboratorId ? lookupId('collaborator', t.assignedCollaboratorId) : null;
    await validateClientRelationshipOwnership(dbClient, { client_id: clientId, admission_id: admissionId });

    const originIds = (t.originTitleIds || []).map(id => lookupId('financialTitle', id)).filter(Boolean);

    await dbClient.query(`
      INSERT INTO financial_titles (id, title_scope, description, category_id, document_type_id, bearer_id,
        department_id, value, status, client_id, client_name, issue_date, due_date, original_value,
        current_balance, document_number, source, type, recurrence_id, parent_id, installment_number,
        total_installments, is_protested, is_provision, accounting_type, expected_date, protest_days,
        return_date, interest_value, discount_value, penalty_value, discount_validity, bank_account_id,
        unit_id, seller_id, invoice_group_id, origin_title_ids, collection_status,
        assigned_collaborator_id, admission_id,
        protest_release_user, protest_release_date, protest_release_reason,
        provision_release_user, provision_release_date, provision_release_reason,
        creation_date, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,$30,$31,$32,$33,$34,$35,$36,$37,$38,$39,$40,$41,$42,$43,$44,$45,$46,COALESCE($47,NOW()),NOW())
      ON CONFLICT (id) DO UPDATE SET
        title_scope=EXCLUDED.title_scope, description=EXCLUDED.description, category_id=EXCLUDED.category_id,
        document_type_id=EXCLUDED.document_type_id, bearer_id=EXCLUDED.bearer_id, department_id=EXCLUDED.department_id,
        value=EXCLUDED.value, status=EXCLUDED.status, client_id=EXCLUDED.client_id, client_name=EXCLUDED.client_name,
        issue_date=EXCLUDED.issue_date, due_date=EXCLUDED.due_date, original_value=EXCLUDED.original_value,
        current_balance=EXCLUDED.current_balance, document_number=EXCLUDED.document_number,
        source=EXCLUDED.source, type=EXCLUDED.type, recurrence_id=EXCLUDED.recurrence_id, parent_id=EXCLUDED.parent_id,
        installment_number=EXCLUDED.installment_number, total_installments=EXCLUDED.total_installments,
        is_protested=EXCLUDED.is_protested, is_provision=EXCLUDED.is_provision, accounting_type=EXCLUDED.accounting_type,
        expected_date=EXCLUDED.expected_date, protest_days=EXCLUDED.protest_days, return_date=EXCLUDED.return_date,
        interest_value=EXCLUDED.interest_value, discount_value=EXCLUDED.discount_value, penalty_value=EXCLUDED.penalty_value,
        discount_validity=EXCLUDED.discount_validity, bank_account_id=EXCLUDED.bank_account_id,
        unit_id=EXCLUDED.unit_id, seller_id=EXCLUDED.seller_id, invoice_group_id=EXCLUDED.invoice_group_id,
        origin_title_ids=EXCLUDED.origin_title_ids, collection_status=EXCLUDED.collection_status,
        assigned_collaborator_id=EXCLUDED.assigned_collaborator_id, admission_id=EXCLUDED.admission_id,
        protest_release_user=EXCLUDED.protest_release_user, protest_release_date=EXCLUDED.protest_release_date,
        protest_release_reason=EXCLUDED.protest_release_reason,
        provision_release_user=EXCLUDED.provision_release_user, provision_release_date=EXCLUDED.provision_release_date,
        provision_release_reason=EXCLUDED.provision_release_reason, updated_at=NOW()
    `, [
      uuid,
      'RECEBER',
      t.description || null,
      categoryId,
      documentTypeId,
      bearerId,
      departmentId,
      parseNumber(t.value),
      t.status || 'ABERTO',
      clientId,
      t.clientName || null,
      parseDate(t.issueDate),
      parseDate(t.dueDate),
      parseNumber(t.originalValue),
      parseNumber(t.currentBalance),
      t.documentNumber || null,
      t.source || 'MANUAL',
      t.type || 'PADRAO',
      t.recurrenceId ? toUUID(t.recurrenceId) : null,
      parentId,
      parseIntOrNull(t.installmentNumber),
      parseIntOrNull(t.totalInstallments),
      t.isProtested === true,
      t.isProvision === true,
      t.accountingType || 'CONTABIL',
      parseDate(t.expectedDate),
      parseIntOrNull(t.protestDays),
      parseDate(t.returnDate),
      parseNumber(t.interestValue),
      parseNumber(t.discountValue),
      parseNumber(t.penaltyValue),
      parseDate(t.discountValidity),
      bankAccountId,
      unitId,
      sellerId,
      t.invoiceGroupId ? toUUID(t.invoiceGroupId) : null,
      originIds.length > 0 ? originIds : null,
      t.collectionStatus || null,
      assignedCollabId,
      admissionId,
      t.protestReleaseLog?.userName || null,
      parseTimestamp(t.protestReleaseLog?.date),
      t.protestReleaseLog?.reason || null,
      t.provisionReleaseLog?.userName || null,
      parseTimestamp(t.provisionReleaseLog?.date),
      t.provisionReleaseLog?.reason || null,
      parseTimestamp(t.creationDate)
    ]);

    const settlements = t.settlements || [];
    if (settlements.length > 0) {
      await dbClient.query(`DELETE FROM title_settlements WHERE title_id = $1`, [uuid]);
      for (const s of settlements) {
        const sUuid = toUUID(s.id || `settlement-${t.id}-${Math.random()}`);
        await dbClient.query(`
          INSERT INTO title_settlements (id, title_id, date, amount, interest, penalty, discount, source, history, user_name, movement_id, created_at)
          VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,NOW())
        `, [
          sUuid, uuid, parseDate(s.date) || new Date().toISOString().split('T')[0],
          parseNumber(s.amount), parseNumber(s.interest), parseNumber(s.penalty),
          parseNumber(s.discount), s.source || null, s.history || null,
          s.userName || null, s.movementId ? toUUID(s.movementId) : null
        ]);
      }
    }

    const advanceLinks = t.advanceLinks || [];
    if (advanceLinks.length > 0) {
      await dbClient.query(`DELETE FROM title_advance_links WHERE source_title_id = $1`, [uuid]);
      for (const link of advanceLinks) {
        const linkedId = lookupId('financialTitle', link.titleId);
        if (linkedId) {
          await dbClient.query(`
            INSERT INTO title_advance_links (id, source_title_id, linked_title_id, amount, date)
            VALUES ($1,$2,$3,$4,$5)
          `, [
            deterministicUUID(`adv-${t.id}-${link.titleId}`),
            uuid, linkedId, parseNumber(link.amount), parseDate(link.date)
          ]);
        }
      }
    }

    const returnLinks = t.returnLinks || [];
    if (returnLinks.length > 0) {
      await dbClient.query(`DELETE FROM title_return_links WHERE source_title_id = $1`, [uuid]);
      for (const link of returnLinks) {
        const linkedId = lookupId('financialTitle', link.titleId);
        if (linkedId) {
          await dbClient.query(`
            INSERT INTO title_return_links (id, source_title_id, linked_title_id, amount, date)
            VALUES ($1,$2,$3,$4,$5)
          `, [
            deterministicUUID(`ret-${t.id}-${link.titleId}`),
            uuid, linkedId, parseNumber(link.amount), parseDate(link.date)
          ]);
        }
      }
    }

    count++;
  }
  return count;
}

async function syncAppointments(dbClient, config) {
  const appointments = config.appointments || [];
  let count = 0;
  for (const a of appointments) {
    const uuid = mapId('appointment', a.id);
    const clientId = a.clientId ? lookupId('client', a.clientId) : null;
    const collaboratorId = a.collaboratorId ? lookupId('collaborator', a.collaboratorId) : null;
    const serviceId = a.serviceId ? lookupId('service', a.serviceId) : null;
    const unitId = a.unitId ? lookupId('unit', a.unitId) : null;
    await validateReferenceIds(dbClient, { clientId, collaboratorId, serviceId, unitId }, [
      ['clientId', 'clients', 'Cliente'], ['collaboratorId', 'collaborators', 'Colaborador'],
      ['serviceId', 'service_items', 'Serviço'], ['unitId', 'companies', 'Unidade'],
    ]);

    await dbClient.query(`
      INSERT INTO appointments (id, client_id, client_name, collaborator_id, service_id, date, start_time, end_time, status, notes, unit_id, created_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,NOW())
      ON CONFLICT (id) DO UPDATE SET
        client_id=EXCLUDED.client_id, client_name=EXCLUDED.client_name, collaborator_id=EXCLUDED.collaborator_id,
        service_id=EXCLUDED.service_id, date=EXCLUDED.date, start_time=EXCLUDED.start_time, end_time=EXCLUDED.end_time,
        status=EXCLUDED.status, notes=EXCLUDED.notes, unit_id=EXCLUDED.unit_id
    `, [
      uuid,
      clientId,
      a.clientName || null,
      collaboratorId,
      serviceId,
      parseDate(a.date),
      a.startTime || '08:00',
      a.endTime || '08:30',
      a.status || 'AGENDADO',
      a.notes || null,
      unitId
    ]);
    count++;
  }
  return count;
}

async function syncScheduleBlocks(dbClient, config) {
  const blocks = config.scheduleBlocks || [];
  let count = 0;
  for (const b of blocks) {
    const uuid = mapId('scheduleBlock', b.id);
    const collaboratorId = b.collaboratorId ? lookupId('collaborator', b.collaboratorId) : null;
    await dbClient.query(`
      INSERT INTO schedule_blocks (id, collaborator_id, is_whole_day, start_date, end_date, start_time, end_time, repeat_days, reason)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9)
      ON CONFLICT (id) DO UPDATE SET
        collaborator_id=EXCLUDED.collaborator_id, is_whole_day=EXCLUDED.is_whole_day,
        start_date=EXCLUDED.start_date, end_date=EXCLUDED.end_date, start_time=EXCLUDED.start_time,
        end_time=EXCLUDED.end_time, repeat_days=EXCLUDED.repeat_days, reason=EXCLUDED.reason
    `, [
      uuid,
      collaboratorId,
      b.isWholeDay === true,
      parseDate(b.startDate) || new Date().toISOString().split('T')[0],
      parseDate(b.endDate) || new Date().toISOString().split('T')[0],
      b.startTime || null,
      b.endTime || null,
      b.repeatDays || [],
      b.reason || null
    ]);
    count++;
  }
  return count;
}

async function syncLegalProcesses(dbClient, config) {
  const processes = config.companyLegalProcesses || [];
  let count = 0;
  for (const p of processes) {
    const uuid = mapId('legalProcess', p.id);
    const unitId = p.unitId ? lookupId('unit', p.unitId) : null;
    const partnerId = p.partnerId ? lookupId('client', p.partnerId) : null;
    const clientId = p.clientId ? lookupId('client', p.clientId) : null;
    const admissionId = p.admissionId ? lookupId('admission', p.admissionId) : null;
    const relations = { client_id: clientId, admission_id: admissionId, unit_id: unitId, partner_id: partnerId };
    await validateReferenceIds(dbClient, relations, [
      ['client_id', 'clients', 'Cliente'], ['admission_id', 'admissions', 'Admissão'],
      ['unit_id', 'companies', 'Unidade'], ['partner_id', 'clients', 'Parceiro'],
    ]);
    await validateClientRelationshipOwnership(dbClient, relations);

    await dbClient.query(`
      INSERT INTO legal_processes (id, unit_id, process_number, court, jurisdiction, type, role,
        opposing_party, opposing_party_document, opposing_party_lawyer, opposing_party_lawyer_oab,
        partner_id, responsible_lawyer, responsible_lawyer_oab, status, subject,
        cause_value, provision_value, risk_level, distribution_date, last_movement_date,
        notes, notes_header, notes_footer, tags, client_id, admission_id, client_name, contract_number, created_at, updated_at)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15,$16,$17,$18,$19,$20,$21,$22,$23,$24,$25,$26,$27,$28,$29,NOW(),NOW())
      ON CONFLICT (id) DO UPDATE SET
        unit_id=EXCLUDED.unit_id, process_number=EXCLUDED.process_number, court=EXCLUDED.court,
        jurisdiction=EXCLUDED.jurisdiction, type=EXCLUDED.type, role=EXCLUDED.role,
        opposing_party=EXCLUDED.opposing_party, opposing_party_document=EXCLUDED.opposing_party_document,
        opposing_party_lawyer=EXCLUDED.opposing_party_lawyer, opposing_party_lawyer_oab=EXCLUDED.opposing_party_lawyer_oab,
        partner_id=EXCLUDED.partner_id, responsible_lawyer=EXCLUDED.responsible_lawyer,
        responsible_lawyer_oab=EXCLUDED.responsible_lawyer_oab, status=EXCLUDED.status, subject=EXCLUDED.subject,
        cause_value=EXCLUDED.cause_value, provision_value=EXCLUDED.provision_value, risk_level=EXCLUDED.risk_level,
        distribution_date=EXCLUDED.distribution_date, last_movement_date=EXCLUDED.last_movement_date,
        notes=EXCLUDED.notes, notes_header=EXCLUDED.notes_header, notes_footer=EXCLUDED.notes_footer,
        tags=EXCLUDED.tags, client_id=EXCLUDED.client_id, admission_id=EXCLUDED.admission_id,
        client_name=EXCLUDED.client_name, contract_number=EXCLUDED.contract_number, updated_at=NOW()
    `, [
      uuid,
      unitId,
      p.processNumber || '',
      p.court || null,
      p.jurisdiction || null,
      p.type || null,
      p.role || null,
      p.opposingParty || null,
      p.opposingPartyDocument || null,
      p.opposingPartyLawyer || null,
      p.opposingPartyLawyerOAB || null,
      partnerId,
      p.responsibleLawyer || null,
      p.responsibleLawyerOAB || null,
      p.status || 'ATIVO',
      p.subject || null,
      p.causeValue || null,
      p.provisionValue || null,
      p.riskLevel || 'MEDIO',
      parseDate(p.distributionDate),
      parseTimestamp(p.lastMovementDate),
      p.notes || null,
      p.notesHeader || null,
      p.notesFooter || null,
      p.tags || [],
      clientId, admissionId, p.clientName || null, p.contractNumber || null
    ]);

    await dbClient.query(`DELETE FROM legal_process_movements WHERE process_id = $1`, [uuid]);
    const movements = p.movements || [];
    for (const m of movements) {
      const mUuid = toUUID(m.id || `lpm-${p.id}-${Math.random()}`);
      await dbClient.query(`
        INSERT INTO legal_process_movements (id, process_id, date, description, type)
        VALUES ($1,$2,$3,$4,$5)
      `, [mUuid, uuid, parseTimestamp(m.date), m.description || null, m.type || null]);
    }

    await dbClient.query(`DELETE FROM legal_process_deadlines WHERE process_id = $1`, [uuid]);
    const deadlines = p.deadlines || [];
    for (const d of deadlines) {
      const dUuid = toUUID(d.id || `lpd-${p.id}-${Math.random()}`);
      await dbClient.query(`
        INSERT INTO legal_process_deadlines (id, process_id, type, description, due_date, status, notes)
        VALUES ($1,$2,$3,$4,$5,$6,$7)
      `, [dUuid, uuid, d.type || null, d.description || null, parseDate(d.dueDate), d.status || 'PENDENTE', d.notes || null]);
    }

    await dbClient.query(`DELETE FROM legal_process_hearings WHERE process_id = $1`, [uuid]);
    const hearings = p.hearings || [];
    for (const h of hearings) {
      const hUuid = toUUID(h.id || `lph-${p.id}-${Math.random()}`);
      await dbClient.query(`
        INSERT INTO legal_process_hearings (id, process_id, type, date, time, location, status, notes)
        VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
      `, [hUuid, uuid, h.type || null, parseDate(h.date), h.time || null, h.location || null, h.status || 'AGENDADA', h.notes || null]);
    }

    await dbClient.query(`DELETE FROM legal_process_attachments WHERE process_id = $1`, [uuid]);
    const attachments = p.attachments || [];
    for (const att of attachments) {
      const attUuid = toUUID(att.id || `lpa-${p.id}-${Math.random()}`);
      await dbClient.query(`
        INSERT INTO legal_process_attachments (id, process_id, title, file_name, file_data)
        VALUES ($1,$2,$3,$4,$5)
      `, [attUuid, uuid, att.title || null, att.fileName || null, att.fileData || null]);
    }

    count++;
  }
  return count;
}

async function syncConfigOptions(dbClient, config) {
  let count = 0;

  const optionMappings = [
    { key: 'maritalStatusOptions', type: 'maritalStatus' },
    { key: 'jobTitles', type: 'jobTitle' },
    { key: 'modalityTypes', type: 'modalityType' },
    { key: 'paymentTypes', type: 'paymentType' }
  ];

  for (const mapping of optionMappings) {
    const values = config[mapping.key] || [];
    if (values.length === 0) continue;

    await dbClient.query(`DELETE FROM config_options WHERE option_type = $1`, [mapping.type]);

    for (let i = 0; i < values.length; i++) {
      const val = values[i];
      if (!val) continue;
      await dbClient.query(`
        INSERT INTO config_options (id, option_type, value, sort_order)
        VALUES ($1, $2, $3, $4)
      `, [deterministicUUID(`config-${mapping.type}-${val}`), mapping.type, val, i]);
      count++;
    }
  }

  const roles = config.roles || [];
  if (roles.length > 0) {
    await dbClient.query(`DELETE FROM config_options WHERE option_type = 'role'`);
    for (let i = 0; i < roles.length; i++) {
      const r = roles[i];
      const roleValue = JSON.stringify({
        name: r.name,
        participatesInScheduling: r.participatesInScheduling === true
      });
      await dbClient.query(`
        INSERT INTO config_options (id, option_type, value, sort_order)
        VALUES ($1, 'role', $2, $3)
      `, [toUUID(r.id), roleValue, i]);
      count++;
    }
  }

  return count;
}

export { syncConfigToDB };

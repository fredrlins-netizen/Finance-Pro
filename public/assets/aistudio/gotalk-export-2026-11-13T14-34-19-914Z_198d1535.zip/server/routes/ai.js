/**
 * Rotas IA — Assistente de Treinamento, Análise de Dados, Resumo de Relatórios e Auditoria IA.
 * Todas as rotas requerem autenticação. Análise e Resumo requerem ADMIN ou COORDENADOR.
 */

import { Router } from 'express';
import { chat, isGeminiAvailable } from '../services/geminiClient.js';
import { getTrainingKnowledge, getRelevantArticles } from '../services/trainingKnowledge.js';
import { aiChatLimiter, aiAnalysisLimiter, aiHeavyLimiter } from '../middleware/rateLimit.js';

// ── Whitelist de tabelas permitidas para análise de dados ─────────────────────
const ALLOWED_TABLES = new Set([
  'clients', 'admissions', 'financial_titles', 'title_settlements',
  'negotiations', 'appointments', 'legal_processes', 'bank_movements',
  'bank_reconciliations', 'collaborators', 'companies', 'modalities',
  'products', 'roles', 'departments', 'collection_notes',
  'commercial_deals', 'recalc_scenarios', 'admissions_addendums',
]);

const ALLOWED_TABLES_AUDIT = new Set([...ALLOWED_TABLES, 'audit_logs']);

// Esquema simplificado das tabelas para contexto do Gemini
const DB_SCHEMA_DESCRIPTION = `
Banco de dados PostgreSQL do sistema FinancePro Assessoria.
Tabelas disponíveis para consulta:

clients: id, name, cpf_cnpj, phone, email, address, city, state, status, created_at
  - status: ATIVO, BLOQUEADO, SUSPENSO

admissions: id, client_id, client_name, unit_id, collaborator_id, status, parcela1, parcela2,
  total_savings, created_at, updated_at
  - status: NOVO, EM_ANALISE, APROVADA, RETORNO_AUDITORIA, CONCLUIDO, CANCELADO

financial_titles: id, document_number, client_id, client_name, type, status, issue_date, due_date,
  original_value, current_balance, unit_id, collaborator_id, description
  - type: RECEBER, PAGAR, FATURA, AGRUPADO
  - status: ABERTO, PAGO, PARCIAL, CANCELADO, VENCIDO, AGRUPADO

title_settlements: id, title_id, settlement_date, amount, payment_method, account, source, created_at

negotiations: id, client_id, client_name, status, total_debt, negotiated_value, collaborator_id,
  unit_id, created_at
  - status: ABERTA, PROPOSTA, ACORDADA, ENCERRADA, CANCELADA

appointments: id, client_id, client_name, collaborator_id, service_id, date, start_time, end_time,
  status, unit_id, modalidade
  - status: AGENDADO, CONFIRMADO, REALIZADO, CANCELADO, FALTOU

legal_processes: id, process_number, client_id, type, status, risk_level, cause_value,
  provisioned_value, unit_id, responsible_lawyer, created_at
  - type: TRABALHISTA, CIVEL, TRIBUTARIO, CONSUMIDOR, CRIMINAL, ADMINISTRATIVO, OUTRO
  - status: ATIVO, SUSPENSO, ARQUIVADO, ENCERRADO_PROCEDENTE, ENCERRADO_IMPROCEDENTE, ACORDO
  - risk_level: BAIXO, MEDIO, ALTO, CRITICO

bank_movements: id, bank_account_id, type, amount, description, movement_date, category, created_at
  - type: CREDITO, DEBITO

collaborators: id, name, email, phone, role, unit_id, status, created_at

companies: id, name, cnpj, city, state, status

collection_notes: id, title_id, client_id, note, collaborator_id, created_at

commercial_deals: id, client_id, status, total_value, collaborator_id, unit_id, created_at

audit_logs: id, user_id, user_name, entity, entity_id, action, changes, description, timestamp
  - action: CREATE, UPDATE, DELETE
`;

// ── Validação de SQL ──────────────────────────────────────────────────────────
function validateSQL(sql, auditAllowed = false) {
  if (!sql || typeof sql !== 'string') return { valid: false, reason: 'Query vazia.' };

  const normalized = sql.trim().replace(/\s+/g, ' ').toUpperCase();

  // Só permite SELECT
  if (!normalized.startsWith('SELECT')) {
    return { valid: false, reason: 'Apenas consultas SELECT são permitidas.' };
  }

  // Bloqueia operações perigosas
  const dangerous = ['INSERT', 'UPDATE', 'DELETE', 'DROP', 'ALTER', 'TRUNCATE', 'CREATE',
    'GRANT', 'REVOKE', 'EXEC', 'EXECUTE', 'CALL', 'COPY', 'VACUUM'];
  for (const kw of dangerous) {
    if (normalized.includes(kw)) {
      return { valid: false, reason: `Operação '${kw}' não permitida.` };
    }
  }

  // Bloqueia acesso a tabelas de sistema
  const systemKeywords = ['PG_', 'INFORMATION_SCHEMA', 'APP_DATA', 'MIGRATIONS_LOG',
    'PORTAL_CONFIG', 'USERS', 'JWT', 'PASSWORD', 'HASH', 'SECRET',
    'GOTALK_CHANNELS', 'UNIT_WHATSAPP_CREDENTIALS', 'BACKGROUND_JOBS'];
  for (const kw of systemKeywords) {
    if (normalized.includes(kw)) {
      return { valid: false, reason: `Acesso à tabela '${kw}' não permitido.` };
    }
  }

  // Verifica tabelas na whitelist
  const tableSet = auditAllowed ? ALLOWED_TABLES_AUDIT : ALLOWED_TABLES;
  const tableMatch = sql.match(/\bFROM\s+(\w+)|\bJOIN\s+(\w+)/gi) || [];
  for (const match of tableMatch) {
    const tableName = match.replace(/\bFROM\s+|\bJOIN\s+/i, '').trim().toLowerCase();
    if (!tableSet.has(tableName)) {
      return { valid: false, reason: `Tabela '${tableName}' não está na lista de tabelas permitidas.` };
    }
  }

  // Limita tamanho
  if (sql.length > 2000) {
    return { valid: false, reason: 'Query muito longa.' };
  }

  return { valid: true };
}

// ── Queries de agregação por módulo (para resumo de relatórios) ───────────────
async function collectReportData(pool, modules) {
  const results = {};

  if (modules.includes('financeiro') || modules.includes('todos')) {
    try {
      const r = await pool.query(`
        SELECT
          COUNT(*) FILTER (WHERE status = 'ABERTO') AS titulos_abertos,
          COUNT(*) FILTER (WHERE status = 'VENCIDO') AS titulos_vencidos,
          COUNT(*) FILTER (WHERE status = 'PAGO') AS titulos_pagos,
          SUM(current_balance) FILTER (WHERE status IN ('ABERTO','VENCIDO') AND type = 'RECEBER') AS total_receber,
          SUM(current_balance) FILTER (WHERE status IN ('ABERTO','VENCIDO') AND type = 'PAGAR') AS total_pagar,
          COUNT(DISTINCT client_id) FILTER (WHERE status = 'VENCIDO') AS clientes_inadimplentes
        FROM financial_titles
        WHERE created_at >= NOW() - INTERVAL '90 days'
      `);
      results.financeiro = r.rows[0];
    } catch {}
  }

  if (modules.includes('comercial') || modules.includes('todos')) {
    try {
      const r = await pool.query(`
        SELECT
          COUNT(*) AS total_admissoes,
          COUNT(*) FILTER (WHERE status = 'APROVADA') AS aprovadas,
          COUNT(*) FILTER (WHERE status = 'CONCLUIDO') AS concluidas,
          COUNT(*) FILTER (WHERE status = 'CANCELADO') AS canceladas,
          COUNT(*) FILTER (WHERE status = 'EM_ANALISE') AS em_analise,
          COUNT(DISTINCT unit_id) AS unidades_ativas
        FROM admissions
        WHERE created_at >= NOW() - INTERVAL '90 days'
      `);
      results.comercial = r.rows[0];
    } catch {}
  }

  if (modules.includes('juridico') || modules.includes('todos')) {
    try {
      const r = await pool.query(`
        SELECT
          COUNT(*) AS total_processos,
          COUNT(*) FILTER (WHERE status = 'ATIVO') AS ativos,
          COUNT(*) FILTER (WHERE risk_level = 'CRITICO') AS risco_critico,
          COUNT(*) FILTER (WHERE risk_level = 'ALTO') AS risco_alto,
          SUM(provisioned_value) AS total_provisionado,
          SUM(cause_value) AS total_causa
        FROM legal_processes
      `);
      results.juridico = r.rows[0];
    } catch {}
  }

  if (modules.includes('negociacao') || modules.includes('todos')) {
    try {
      const r = await pool.query(`
        SELECT
          COUNT(*) AS total_negociacoes,
          COUNT(*) FILTER (WHERE status = 'ABERTA') AS abertas,
          COUNT(*) FILTER (WHERE status = 'ACORDADA') AS acordadas,
          COUNT(*) FILTER (WHERE status = 'CANCELADA') AS canceladas,
          SUM(total_debt) AS total_divida,
          SUM(negotiated_value) AS total_negociado
        FROM negotiations
        WHERE created_at >= NOW() - INTERVAL '90 days'
      `);
      results.negociacao = r.rows[0];
    } catch {}
  }

  if (modules.includes('auditoria') || modules.includes('todos')) {
    try {
      const r = await pool.query(`
        SELECT
          COUNT(*) AS total_logs,
          COUNT(DISTINCT user_id) AS usuarios_ativos,
          COUNT(*) FILTER (WHERE action = 'CREATE') AS criados,
          COUNT(*) FILTER (WHERE action = 'UPDATE') AS editados,
          COUNT(*) FILTER (WHERE action = 'DELETE') AS excluidos,
          COUNT(DISTINCT entity) AS entidades_afetadas
        FROM audit_logs
        WHERE timestamp >= NOW() - INTERVAL '90 days'
      `);
      results.auditoria = r.rows[0];
    } catch {}
  }

  return results;
}

// ── Factory ───────────────────────────────────────────────────────────────────
function createAIRoutes(pool) {
  const router = Router();

  // ── GET /api/ai/status — sempre acessível, independente da disponibilidade ──
  // DEVE ficar ANTES do middleware de verificação do Gemini
  router.get('/status', (req, res) => {
    res.json({ available: isGeminiAvailable(), model: 'gemini-2.5-flash' });
  });

  // Verifica disponibilidade do Gemini nas rotas de IA (exceto /status acima)
  router.use((req, res, next) => {
    if (!isGeminiAvailable()) {
      return res.status(503).json({
        error: 'Integração IA não disponível',
        details: 'A integração com o Google Gemini não está configurada. Ative a integração Gemini no painel Replit.'
      });
    }
    next();
  });

  // ── POST /api/ai/training-chat ────────────────────────────────────────────
  // Chat com o Léo — restrito ao sistema FinancePro
  router.post('/training-chat', aiChatLimiter, async (req, res) => {
    try {
      const { message, history = [] } = req.body;

      if (!message || typeof message !== 'string' || message.trim().length === 0) {
        return res.status(400).json({ error: 'Mensagem inválida.' });
      }
      if (message.length > 1000) {
        return res.status(400).json({ error: 'Mensagem muito longa (máx. 1000 caracteres).' });
      }

      const systemPrompt = getTrainingKnowledge();

      // Limita histórico a 20 mensagens
      const limitedHistory = history.slice(-20).map(m => ({
        role: m.role === 'leo' ? 'assistant' : 'user',
        content: String(m.content).substring(0, 2000)
      }));

      const messages = [
        ...limitedHistory,
        { role: 'user', content: message }
      ];

      // Busca artigos relevantes da base de conhecimento
      const relevantArticles = await getRelevantArticles(message, pool);

      // Constrói partes extras: texto dos artigos + imagens (máx 3 no total)
      const extraParts = [];
      let imageCount = 0;
      if (relevantArticles.length > 0) {
        let articleContext = '\n\n--- BASE DE CONHECIMENTO RELEVANTE ---\n';
        for (const article of relevantArticles) {
          articleContext += `\n## Artigo: "${article.title}" (Categoria: ${article.category})\n`;
          // Strip HTML tags from content for text part
          const plainContent = article.content.replace(/<[^>]*>/g, ' ').replace(/\s+/g, ' ').trim();
          articleContext += plainContent.substring(0, 3000);
          articleContext += '\n';

          // Add images (up to 3 total across all articles)
          const imgs = Array.isArray(article.images) ? article.images : [];
          for (const img of imgs) {
            if (imageCount >= 3) break;
            if (img?.data && img?.mimeType) {
              extraParts.push({ type: 'image', mimeType: img.mimeType, data: img.data });
              imageCount++;
            }
          }
        }
        articleContext += '\n--- FIM DA BASE DE CONHECIMENTO ---\n';
        extraParts.unshift({ type: 'text', text: articleContext });
      }

      const reply = await chat(systemPrompt, messages, 8192, extraParts);

      res.json({ reply, model: 'gemini-2.5-flash' });
    } catch (err) {
      console.error('[AI] training-chat error:', err.message);
      res.status(500).json({ error: 'Erro ao processar sua pergunta. Tente novamente.' });
    }
  });

  // ── POST /api/ai/data-analysis ────────────────────────────────────────────
  // Análise de dados em linguagem natural → SQL → resultado → análise
  router.post('/data-analysis', aiAnalysisLimiter, async (req, res) => {
    try {
      const user = req.currentUser;
      if (!user || (!user.isAdmin && user.role !== 'COORDENADOR')) {
        return res.status(403).json({ error: 'Acesso negado. Requer perfil ADMIN ou COORDENADOR.' });
      }

      const { question } = req.body;
      if (!question || typeof question !== 'string' || question.trim().length === 0) {
        return res.status(400).json({ error: 'Pergunta inválida.' });
      }
      if (question.length > 500) {
        return res.status(400).json({ error: 'Pergunta muito longa (máx. 500 caracteres).' });
      }

      // Passo 1: Gemini gera a SQL
      const sqlSystemPrompt = `Você é um gerador de SQL para o sistema FinancePro Assessoria.
Dado o esquema do banco abaixo, gere APENAS uma query SQL SELECT válida para PostgreSQL que responda à pergunta do usuário.
NÃO use markdown, NÃO use blocos de código, NÃO inclua explicações. Retorne SOMENTE a query SQL pura.
A query DEVE conter LIMIT (máximo 500 linhas). Use alias legíveis em português (AS "Total", AS "Nome", etc.).

${DB_SCHEMA_DESCRIPTION}

IMPORTANTE: Use apenas as tabelas listadas acima. Se não for possível responder com estas tabelas, retorne: IMPOSSIVEL`;

      const sqlRaw = await chat(sqlSystemPrompt, [{ role: 'user', content: question }], 2048);
      const sqlQuery = sqlRaw.trim().replace(/```sql|```/gi, '').trim();

      if (sqlQuery === 'IMPOSSIVEL' || sqlQuery.toUpperCase().startsWith('IMPOSSIVEL')) {
        return res.json({
          sql: null,
          data: [],
          analysis: 'Não foi possível gerar uma consulta para esta pergunta com os dados disponíveis no sistema.',
          rowCount: 0
        });
      }

      // Passo 2: Valida a SQL
      const validation = validateSQL(sqlQuery);
      if (!validation.valid) {
        return res.status(400).json({
          error: `Query gerada inválida: ${validation.reason}`,
          sql: sqlQuery
        });
      }

      // Passo 3: Executa a query
      let rows = [];
      try {
        const result = await pool.query(sqlQuery);
        rows = result.rows;
      } catch (dbErr) {
        return res.status(400).json({
          error: 'Erro ao executar a consulta gerada.',
          details: dbErr.message,
          sql: sqlQuery
        });
      }

      // Passo 4: Gemini analisa os resultados
      const analysisPrompt = `Você é um analista de dados do sistema FinancePro Assessoria.
Analise os seguintes dados e forneça um resumo executivo em português.
Seja objetivo, identifique padrões, destaques e pontos de atenção.
Máximo 3 parágrafos. Use **negrito** para números importantes.`;

      const dataPreview = JSON.stringify(rows.slice(0, 50), null, 2).substring(0, 8000);
      const analysis = await chat(analysisPrompt, [
        { role: 'user', content: `Pergunta original: "${question}"\n\nDados retornados (${rows.length} linhas):\n${dataPreview}` }
      ], 4096);

      res.json({
        sql: sqlQuery,
        data: rows,
        analysis,
        rowCount: rows.length
      });
    } catch (err) {
      console.error('[AI] data-analysis error:', err.message);
      res.status(500).json({ error: 'Erro ao processar análise. Tente novamente.' });
    }
  });

  // ── POST /api/ai/report-summary ───────────────────────────────────────────
  // Resumo executivo dos relatórios selecionados
  router.post('/report-summary', aiHeavyLimiter, async (req, res) => {
    try {
      const user = req.currentUser;
      if (!user || (!user.isAdmin && user.role !== 'COORDENADOR')) {
        return res.status(403).json({ error: 'Acesso negado. Requer perfil ADMIN ou COORDENADOR.' });
      }

      const { modules = ['todos'] } = req.body;
      const validModules = ['financeiro', 'comercial', 'juridico', 'negociacao', 'auditoria', 'todos'];
      const selectedModules = modules.filter(m => validModules.includes(m));

      if (selectedModules.length === 0) {
        return res.status(400).json({ error: 'Nenhum módulo válido selecionado.' });
      }

      const reportData = await collectReportData(pool, selectedModules);

      if (Object.keys(reportData).length === 0) {
        return res.json({ summary: 'Nenhum dado disponível para os módulos selecionados.', data: {} });
      }

      const systemPrompt = `Você é um analista executivo do sistema FinancePro Assessoria.
Sua função é criar um resumo executivo profissional em português dos dados fornecidos.
Estruture o resumo com:
1. **Visão Geral** — principais números e situação atual
2. **Destaques Positivos** — o que está funcionando bem
3. **Pontos de Atenção** — riscos, inadimplências, processos críticos
4. **Recomendações** — 2-3 ações concretas baseadas nos dados

Use linguagem clara e profissional. Destaque números importantes em **negrito**.
Os dados representam os últimos 90 dias, exceto onde indicado.`;

      const dataContext = `Dados coletados dos módulos: ${selectedModules.join(', ')}\n\n${JSON.stringify(reportData, null, 2)}`;

      const summary = await chat(systemPrompt, [{ role: 'user', content: dataContext }], 8192);

      res.json({ summary, data: reportData, modules: selectedModules });
    } catch (err) {
      console.error('[AI] report-summary error:', err.message);
      res.status(500).json({ error: 'Erro ao gerar resumo. Tente novamente.' });
    }
  });

  // ── POST /api/ai/audit-analysis ───────────────────────────────────────────
  // Análise inteligente dos logs de auditoria
  router.post('/audit-analysis', aiHeavyLimiter, async (req, res) => {
    try {
      const user = req.currentUser;
      if (!user || (!user.isAdmin && user.role !== 'COORDENADOR')) {
        return res.status(403).json({ error: 'Acesso negado. Requer perfil ADMIN ou COORDENADOR.' });
      }

      const { entities = [], days = 30 } = req.body;
      const safeDays = Math.min(Math.max(1, parseInt(days) || 30), 365);

      let whereExtra = '';
      const params = [safeDays];

      if (entities.length > 0) {
        const placeholders = entities.map((_, i) => `$${i + 2}`).join(', ');
        whereExtra = `AND entity IN (${placeholders})`;
        params.push(...entities);
      }

      // Busca logs e estatísticas
      const [logsResult, statsResult, userResult] = await Promise.all([
        pool.query(
          `SELECT entity, action, user_name, description, timestamp
           FROM audit_logs
           WHERE timestamp >= NOW() - ($1 || ' days')::interval
           ${whereExtra}
           ORDER BY timestamp DESC LIMIT 200`,
          params
        ),
        pool.query(
          `SELECT entity, action, COUNT(*) as total
           FROM audit_logs
           WHERE timestamp >= NOW() - ($1 || ' days')::interval
           ${whereExtra}
           GROUP BY entity, action ORDER BY total DESC LIMIT 50`,
          params
        ),
        pool.query(
          `SELECT user_name, COUNT(*) as actions
           FROM audit_logs
           WHERE timestamp >= NOW() - ($1 || ' days')::interval
           ${whereExtra}
           GROUP BY user_name ORDER BY actions DESC LIMIT 20`,
          params
        )
      ]);

      const auditData = {
        periodo_dias: safeDays,
        total_logs: logsResult.rows.length,
        por_entidade_acao: statsResult.rows,
        por_usuario: userResult.rows,
        ultimos_registros: logsResult.rows.slice(0, 30)
      };

      const systemPrompt = `Você é um auditor do sistema FinancePro Assessoria.
Analise os logs de auditoria fornecidos e produza um relatório profissional em português com:
1. **Resumo do Período** — visão geral das atividades
2. **Padrões de Uso** — quais módulos/entidades foram mais modificados
3. **Usuários Mais Ativos** — destaque os principais usuários e suas atividades
4. **Alterações Críticas** — exclusões ou modificações em massa que merecem atenção
5. **Observações** — anomalias ou padrões incomuns

Use **negrito** para destacar informações importantes.`;

      const analysis = await chat(systemPrompt, [
        { role: 'user', content: `Logs de auditoria dos últimos ${safeDays} dias:\n\n${JSON.stringify(auditData, null, 2).substring(0, 12000)}` }
      ], 8192);

      res.json({
        analysis,
        stats: statsResult.rows,
        userStats: userResult.rows,
        totalLogs: logsResult.rows.length,
        periodDays: safeDays
      });
    } catch (err) {
      console.error('[AI] audit-analysis error:', err.message);
      res.status(500).json({ error: 'Erro ao analisar logs. Tente novamente.' });
    }
  });

  return router;
}

export { createAIRoutes };

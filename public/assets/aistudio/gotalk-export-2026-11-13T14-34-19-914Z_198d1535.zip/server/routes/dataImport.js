import { Router } from 'express';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { randomInt } from 'node:crypto';
import ExcelJS from 'exceljs';
import archiver from 'archiver';
import path from 'node:path';
import { access, mkdtemp, readFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { requireAdmin } from '../middleware/auth.js';
import { logAudit } from '../middleware/audit.js';
import { createRateLimiter, pdfExtractLimiter } from '../middleware/rateLimit.js';
import { logger } from '../logger.js';
import { parseAdmissionRecalculation, persistAdmissionRecalculation } from '../lib/admissionRecalculationImport.js';
import { validateClientRelationshipOwnership } from '../lib/referenceIdentity.js';
import { chat, isGeminiAvailable } from '../services/geminiClient.js';
import {
  MAX_IMPORT_FILE_BYTES,
  MAX_IMPORT_ROWS,
  parseImportMappingHeader,
  validateImportXlsxArchiveContent,
} from '../../utils/importSpreadsheet.js';
import { issuePhotoChallenge, verifyPhotoChallenge } from '../lib/photoChallenge.js';
import { enqueueDataImport } from '../queues/dataImportQueue.js';
import {
  claimJobForExecution,
  getJob,
  hasLocalQueueMetricWriteFailure,
  updateJob,
} from '../queues/jobStore.js';
import {
  createImportObjectKey,
  deleteImportObject,
  downloadImportObject,
  uploadImportObject,
} from '../services/importStorage.js';

/**
 * MOTOR DE IMPORTAÇÃO EXCEL — whitelist de tabelas de negócio.
 *
 * Segurança:
 *  - Apenas tabelas e colunas desta whitelist podem ser escritas (nunca tabelas
 *    sensíveis: users, mfa, tokens/segredos, audit_logs, app_data).
 *  - Toda escrita usa queries parametrizadas e roda dentro de transação.
 *  - Todas as rotas exigem admin (requireAdmin) e passam por rate limiting.
 *  - A execução real exige um token de step-up (senha + 2FA) de curta duração.
 *
 * Cada entrada define `fields` (fonte única). As listas de colunas, campos
 * obrigatórios e enums são derivadas de `fields` para evitar divergência.
 */

// Sentinela para vínculos cujo PAI será inserido no MESMO lote, mas ainda não
// tem id real durante a validação (preview). Nunca é um valor de usuário nem um
// uuid válido — usado para não disparar dedup por FK contra um pai inexistente.
const SAME_RUN_PENDING = '__samerun_pending__';
const SAME_RUN_AMBIGUOUS = '__samerun_ambiguous__';

function importIdentityKey(value) {
  return String(value ?? '').trim().toLowerCase();
}

function dedupIdentityKey(table, column, value) {
  return table === 'clients' && column === 'document'
    ? normalizeClientDocument(value)
    : importIdentityKey(value);
}

function dedupIdentitySql(table, column) {
  return table === 'clients' && column === 'document'
    ? `regexp_replace(COALESCE(${column}::text, ''), '[^0-9]', '', 'g')`
    : `LOWER(BTRIM(${column}::text))`;
}

function ambiguousDuplicateError(cfg) {
  return {
    column: cfg.dedupKeys[0],
    message: 'Há mais de um cadastro com esta identificação. Revise os cadastros duplicados antes de importar; nenhum deles será escolhido automaticamente.',
  };
}

const IMPORT_SCHEMA = {
  clients: {
    label: 'Clientes',
    description: 'Pessoas físicas ou jurídicas cadastradas no sistema.',
    naturalKey: 'name',
    dedupKeys: ['document'],
    defaultDuplicateStrategy: 'update',
    parentLinks: [],
    relationsText: [],
    fields: [
      { key: 'name',           label: 'Nome / Razão Social',        type: 'text',    required: true },
      { key: 'type',           label: 'Tipo',                       type: 'select',  required: false, options: ['FISICA', 'JURIDICA'], hint: 'Padrão: FISICA' },
      { key: 'document',       label: 'CPF / CNPJ',                 type: 'text',    required: false, hint: 'Usado para detectar duplicados' },
      { key: 'rg',             label: 'RG',                         type: 'text',    required: false },
      { key: 'phone',          label: 'Telefone',                   type: 'text',    required: false },
      { key: 'phone2',         label: 'Telefone 2',                 type: 'text',    required: false },
      { key: 'is_whatsapp',    label: 'WhatsApp? (sim/não)',         type: 'boolean', required: false },
      { key: 'email',          label: 'E-mail',                     type: 'text',    required: false },
      { key: 'profession',     label: 'Profissão',                  type: 'text',    required: false },
      { key: 'marital_status', label: 'Estado Civil',               type: 'text',    required: false },
      { key: 'birth_date',     label: 'Data de Nascimento',         type: 'date',    required: false, hint: 'DD/MM/AAAA ou AAAA-MM-DD' },
      { key: 'cep',            label: 'CEP',                        type: 'text',    required: false },
      { key: 'address',        label: 'Endereço',                   type: 'text',    required: false },
      { key: 'number',         label: 'Número',                     type: 'text',    required: false },
      { key: 'complement',     label: 'Complemento',                type: 'text',    required: false },
      { key: 'district',       label: 'Bairro',                     type: 'text',    required: false },
      { key: 'city',           label: 'Cidade',                     type: 'text',    required: false },
      { key: 'state',          label: 'UF',                         type: 'text',    required: false, hint: '2 letras, ex: SP' },
      { key: 'natureza',       label: 'Natureza',                   type: 'select',  required: false, options: ['C', 'F', 'E'], hint: 'Padrão: C — C=Cliente, F=Fornecedor, E=Empresa' },
      { key: 'blocked',        label: 'Bloqueado? (sim/não)',        type: 'boolean', required: false, hint: 'Padrão: não — sim = cliente bloqueado/inativo' },
      { key: 'block_status',   label: 'Situação do Bloqueio',       type: 'select',  required: false, options: ['BLOQUEADO', 'SUSPENSO'] },
      { key: 'block_reason',   label: 'Motivo do Bloqueio',         type: 'text',    required: false },
      { key: 'notes',          label: 'Observações',                type: 'text',    required: false },
    ],
  },
  collaborators: {
    label: 'Colaboradores',
    description: 'Funcionários e parceiros da empresa.',
    naturalKey: 'name',
    dedupKeys: ['name'],
    defaultDuplicateStrategy: 'update',
    fkColumns: ['unit_id', 'department_id'],
    parentLinks: [
      { childKey: 'unit_name',       parentTable: 'companies',    parentKeySql: "COALESCE(NULLIF(nome_fantasia, ''), razao_social)", fkColumn: 'unit_id',       label: 'Unidade' },
      { childKey: 'department_name', parentTable: 'departments',  parentKey: 'name',                                    fkColumn: 'department_id', label: 'Departamento' },
    ],
    relationsText: ['Unidade (vinculada por nome)', 'Departamento (vinculado por nome)'],
    fields: [
      { key: 'name',            label: 'Nome',                       type: 'text',    required: true,  hint: 'Usado para detectar duplicados' },
      { key: 'job_title',       label: 'Cargo',                      type: 'text',    required: false },
      { key: 'phone',           label: 'Telefone',                   type: 'text',    required: false },
      { key: 'is_whatsapp',     label: 'WhatsApp? (sim/não)',         type: 'boolean', required: false },
      { key: 'email',           label: 'E-mail',                     type: 'text',    required: false },
      { key: 'marital_status',  label: 'Estado Civil',               type: 'text',    required: false },
      { key: 'birth_date',      label: 'Data de Nascimento',         type: 'date',    required: false, hint: 'DD/MM/AAAA ou AAAA-MM-DD' },
      { key: 'cep',             label: 'CEP',                        type: 'text',    required: false },
      { key: 'address',         label: 'Endereço',                   type: 'text',    required: false },
      { key: 'number',          label: 'Número',                     type: 'text',    required: false },
      { key: 'complement',      label: 'Complemento',                type: 'text',    required: false },
      { key: 'district',        label: 'Bairro',                     type: 'text',    required: false },
      { key: 'city',            label: 'Cidade',                     type: 'text',    required: false },
      { key: 'state',           label: 'UF',                         type: 'text',    required: false, hint: '2 letras, ex: SP' },
      { key: 'active',          label: 'Ativo? (sim/não)',            type: 'boolean', required: false, hint: 'Padrão: sim' },
      { key: 'photo_url',       label: 'Foto (URL)',                  type: 'text',    required: false, hint: 'URL permanente; links temporários ou assinados não devem ser usados' },
      { key: 'unit_name',       label: 'Unidade',                    type: 'text',    required: false, virtual: true, hint: 'Nome da unidade (resolve para unit_id)' },
      { key: 'department_name', label: 'Departamento',               type: 'text',    required: false, virtual: true, hint: 'Nome do departamento (resolve para department_id)' },
      { key: 'notes',           label: 'Observações',                type: 'text',    required: false },
    ],
  },
  banks: {
    label: 'Bancos',
    description: 'Instituições financeiras disponíveis no sistema.',
    naturalKey: 'name',
    dedupKeys: ['name'],
    defaultDuplicateStrategy: 'update',
    parentLinks: [],
    relationsText: ['Contatos do banco (bank_contacts)', 'Serviços bancários (bank_services)'],
    fields: [
      { key: 'name',          label: 'Nome do Banco',   type: 'text',   required: true },
      { key: 'febraban_code', label: 'Código Febraban', type: 'text',   required: false, hint: 'Validado contra a BrasilAPI (aviso se o código não for encontrado)' },
      { key: 'status',        label: 'Status',          type: 'select', required: false, options: ['ATIVO', 'INATIVO'], hint: 'Padrão: ATIVO' },
      { key: 'notes',         label: 'Observações',     type: 'text',   required: false },
    ],
  },
  bank_contacts: {
    label: 'Contatos do Banco',
    description: 'Contatos por banco (nome, setor, telefones, e-mail). Dedup por banco + nome do contato.',
    naturalKey: 'name',
    dedupKeys: ['bank_id', 'name'],
    defaultDuplicateStrategy: 'update',
    fkColumns: ['bank_id'],
    parentLinks: [
      { childKey: 'bank_name',          parentTable: 'banks', parentKey: 'name',          fkColumn: 'bank_id', label: 'Banco' },
      { childKey: 'bank_febraban_code', parentTable: 'banks', parentKey: 'febraban_code', fkColumn: 'bank_id', label: 'Banco (Febraban)', fallback: true },
    ],
    relationsText: ['Banco (vinculado por nome ou código Febraban)'],
    fields: [
      { key: 'bank_name',          label: 'Nome do Banco',            type: 'text',    required: false, virtual: true, hint: 'Nome do banco — resolve para bank_id (prioritário sobre Código Febraban)' },
      { key: 'bank_febraban_code', label: 'Código Febraban do Banco', type: 'text',    required: false, virtual: true, hint: 'Fallback: resolve bank_id pelo código Febraban quando Nome do Banco não for informado' },
      { key: 'name',               label: 'Nome do Contato',          type: 'text',    required: true,  hint: 'Junto com o banco, forma a chave de deduplicação' },
      { key: 'sector',             label: 'Setor',                    type: 'text',    required: false },
      { key: 'phone',              label: 'Telefone',                 type: 'text',    required: false },
      { key: 'mobile',             label: 'Celular',                  type: 'text',    required: false },
      { key: 'is_whatsapp',        label: 'WhatsApp? (sim/não)',       type: 'boolean', required: false, hint: 'Padrão: não' },
      { key: 'email',              label: 'E-mail',                   type: 'text',    required: false },
    ],
  },
  bank_services: {
    label: 'Serviços Bancários',
    description: 'Serviços oferecidos por banco com percentual de negociação. Dedup por banco + nome do serviço.',
    naturalKey: 'name',
    dedupKeys: ['bank_id', 'name'],
    defaultDuplicateStrategy: 'update',
    fkColumns: ['bank_id', 'modality_id'],
    parentLinks: [
      { childKey: 'bank_name',          parentTable: 'banks',      parentKey: 'name',          fkColumn: 'bank_id',     label: 'Banco' },
      { childKey: 'bank_febraban_code', parentTable: 'banks',      parentKey: 'febraban_code', fkColumn: 'bank_id',     label: 'Banco (Febraban)', fallback: true },
      { childKey: 'modality_name',      parentTable: 'modalities', parentKey: 'description',   fkColumn: 'modality_id', label: 'Modalidade' },
    ],
    relationsText: ['Banco (vinculado por nome ou código Febraban)', 'Modalidade (vinculada por descrição)'],
    fields: [
      { key: 'bank_name',              label: 'Nome do Banco',            type: 'text',   required: false, virtual: true, hint: 'Nome do banco — resolve para bank_id (prioritário sobre Código Febraban)' },
      { key: 'bank_febraban_code',     label: 'Código Febraban do Banco', type: 'text',   required: false, virtual: true, hint: 'Fallback: resolve bank_id pelo código Febraban quando Nome do Banco não for informado' },
      { key: 'name',                   label: 'Nome do Serviço',          type: 'text',   required: true,  hint: 'Junto com o banco, forma a chave de deduplicação' },
      { key: 'negotiation_percentage', label: 'Percentual de Negociação', type: 'number', required: false, hint: 'Ex: 15.50 (sem % — apenas o número)' },
      { key: 'modality_name',          label: 'Modalidade',               type: 'text',   required: false, virtual: true, hint: 'Descrição da modalidade — resolve para modality_id' },
    ],
  },
  products: {
    label: 'Produtos',
    description: 'Produtos cadastrados no sistema (SERVICO ou MATERIAL).',
    naturalKey: 'description',
    dedupKeys: ['description'],
    fkColumns: ['unit_id'],
    parentLinks: [
      { childKey: 'measurement_unit_name', parentTable: 'measurement_units', parentKey: 'name', fkColumn: 'unit_id', label: 'Unidade de medida' },
    ],
    relationsText: [],
    fields: [
      { key: 'description', label: 'Descrição', type: 'text',   required: true, hint: 'Usado para detectar duplicados' },
      { key: 'type',        label: 'Tipo',      type: 'select', required: false, options: ['SERVICO', 'MATERIAL'], hint: 'Padrão: SERVICO' },
      { key: 'measurement_unit_name', label: 'Unidade de Medida', type: 'text', required: false, virtual: true, hint: 'Nome da unidade já cadastrada' },
    ],
  },
  chart_of_accounts: {
    label: 'Plano de Contas',
    description: 'Categorias contábeis de receitas e despesas.',
    naturalKey: 'code',
    dedupKeys: ['code'],
    fkColumns: ['parent_id'],
    parentLinks: [
      { childKey: 'parent_code', parentTable: 'chart_of_accounts', parentKey: 'code', fkColumn: 'parent_id', label: 'Conta-pai', optional: true },
    ],
    relationsText: ['Conta-pai (vinculada pelo código de uma conta já cadastrada ou incluída antes no lote)'],
    fields: [
      { key: 'code',          label: 'Código',                type: 'text',    required: true, hint: 'Usado para detectar duplicados' },
      { key: 'name',          label: 'Nome da Conta',         type: 'text',    required: true },
      { key: 'type',          label: 'Tipo',                  type: 'select',  required: true, options: ['RECEITA', 'DESPESA'] },
      { key: 'is_analytical', label: 'Analítica? (sim/não)',  type: 'boolean', required: false, hint: 'Analítica = aceita lançamentos diretos' },
      { key: 'parent_code',   label: 'Código da Conta-pai',   type: 'text',    required: false, virtual: true },
    ],
  },
  admissions: {
    label: 'Admissões',
    description: 'Propostas e contratos de financiamento.',
    naturalKey: 'contract_number',
    dedupKeys: ['contract_number'],
    fkColumns: ['client_id', 'bank_id', 'collaborator_id', 'series_id', 'modality_id', 'unit_id', 'titular_client_id'],
    parentLinks: [
      { childKey: 'client_name',        documentChildKey: 'client_document', parentDocumentColumn: 'document', parentTable: 'clients', parentKey: 'name', fkColumn: 'client_id', label: 'Cliente' },
      { childKey: 'bank_name',          parentTable: 'banks',         parentKey: 'name',                                    fkColumn: 'bank_id',          label: 'Banco' },
      { childKey: 'collaborator_name',  parentTable: 'collaborators', parentKey: 'name',                                    fkColumn: 'collaborator_id',  label: 'Colaborador' },
      { childKey: 'series_name',        parentTable: 'series',        parentKey: 'description',                             fkColumn: 'series_id',        label: 'Série' },
      { childKey: 'modality_name',      parentTable: 'modalities',    parentKey: 'description',                             fkColumn: 'modality_id',      label: 'Modalidade' },
      { childKey: 'unit_name',          parentTable: 'companies',     parentKeySql: "COALESCE(NULLIF(nome_fantasia, ''), razao_social)", fkColumn: 'unit_id',          label: 'Unidade' },
      { childKey: 'titular_client_name', documentChildKey: 'titular_client_document', parentDocumentColumn: 'document', parentTable: 'clients', parentKey: 'name', fkColumn: 'titular_client_id', label: 'Cliente Titular' },
    ],
    relationsText: [
      'Cliente (vinculado por nome e, opcionalmente, CPF/CNPJ)',
      'Banco (vinculado por nome)',
      'Colaborador (vinculado por nome)',
      'Modalidade (vinculada por descrição)',
      'Série (vinculada por descrição)',
      'Unidade (vinculada por nome)',
      'Cliente Titular (vinculado por nome e, opcionalmente, CPF/CNPJ)',
    ],
    fields: [
      { key: 'client_name',           label: 'Nome do Cliente',           type: 'text',    required: false, hint: 'Vincula à tabela Clientes pelo nome', exportSource: { fkColumn: 'client_id', column: 'name' } },
      { key: 'client_document',       label: 'CPF/CNPJ do Cliente',       type: 'text',    required: false, virtual: true, hint: 'Opcional; identifica o cliente quando há nomes iguais', exportSource: { fkColumn: 'client_id', column: 'document' } },
      { key: 'client_address',        label: 'Endereço do Cliente',       type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'client_id', nameField: 'client_name', column: 'address', roleLabel: 'Cliente' } },
      { key: 'client_number',         label: 'Número do Cliente',         type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'client_id', nameField: 'client_name', column: 'number', roleLabel: 'Cliente' } },
      { key: 'client_complement',     label: 'Complemento do Cliente',    type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'client_id', nameField: 'client_name', column: 'complement', roleLabel: 'Cliente' } },
      { key: 'client_district',       label: 'Bairro do Cliente',         type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'client_id', nameField: 'client_name', column: 'district', roleLabel: 'Cliente' } },
      { key: 'client_city',           label: 'Cidade do Cliente',         type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'client_id', nameField: 'client_name', column: 'city', roleLabel: 'Cliente' } },
      { key: 'client_state',          label: 'Estado/UF do Cliente',      type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'client_id', nameField: 'client_name', column: 'state', roleLabel: 'Cliente' } },
      { key: 'client_cep',            label: 'CEP do Cliente',            type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'client_id', nameField: 'client_name', column: 'cep', roleLabel: 'Cliente' } },
      { key: 'client_notes',          label: 'Observação do Cliente',    type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'client_id', nameField: 'client_name', column: 'notes', roleLabel: 'Cliente' } },
      { key: 'contract_number',       label: 'Número do Contrato',        type: 'text',    required: false, hint: 'Usado para detectar duplicados' },
      { key: 'date',                  label: 'Data da Admissão',          type: 'date',    required: false, hint: 'DD/MM/AAAA' },
      { key: 'status',                label: 'Status',                    type: 'select',  required: false,
        options: ['PENDENTE', 'NEGOCIAÇÃO', 'APROVADA', 'ANÁLISE CLIENTE', 'REPROVADA', 'AUDITADA', 'FINALIZADA', 'CONCLUIDO', 'RETORNO AUDITORIA'], hint: 'Padrão: PENDENTE' },
      { key: 'bank_name',             label: 'Banco',                     type: 'text',    required: false, virtual: true, hint: 'Nome do banco (resolve para bank_id)' },
      { key: 'collaborator_name',     label: 'Colaborador',               type: 'text',    required: false, virtual: true, hint: 'Nome do colaborador (resolve para collaborator_id)' },
      { key: 'series_name',           label: 'Série',                     type: 'text',    required: false, virtual: true, hint: 'Descrição da série (resolve para series_id)' },
      { key: 'modality_name',         label: 'Modalidade',                type: 'text',    required: false, virtual: true, hint: 'Descrição da modalidade (resolve para modality_id)' },
      { key: 'unit_name',             label: 'Unidade',                   type: 'text',    required: false, virtual: true, hint: 'Nome da unidade (resolve para unit_id)' },
      { key: 'titular_client_name',   label: 'Cliente Titular',           type: 'text',    required: false, virtual: true, hint: 'Nome do cliente titular (resolve para titular_client_id)' },
      { key: 'titular_client_document', label: 'CPF/CNPJ do Titular',     type: 'text',    required: false, virtual: true, hint: 'Opcional; identifica o titular quando há nomes iguais', exportSource: { fkColumn: 'titular_client_id', column: 'document' } },
      { key: 'titular_address',       label: 'Endereço do Titular',       type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'titular_client_id', nameField: 'titular_client_name', column: 'address', roleLabel: 'Titular' } },
      { key: 'titular_number',        label: 'Número do Titular',         type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'titular_client_id', nameField: 'titular_client_name', column: 'number', roleLabel: 'Titular' } },
      { key: 'titular_complement',    label: 'Complemento do Titular',    type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'titular_client_id', nameField: 'titular_client_name', column: 'complement', roleLabel: 'Titular' } },
      { key: 'titular_district',      label: 'Bairro do Titular',         type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'titular_client_id', nameField: 'titular_client_name', column: 'district', roleLabel: 'Titular' } },
      { key: 'titular_city',          label: 'Cidade do Titular',         type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'titular_client_id', nameField: 'titular_client_name', column: 'city', roleLabel: 'Titular' } },
      { key: 'titular_state',         label: 'Estado/UF do Titular',      type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'titular_client_id', nameField: 'titular_client_name', column: 'state', roleLabel: 'Titular' } },
      { key: 'titular_cep',           label: 'CEP do Titular',            type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'titular_client_id', nameField: 'titular_client_name', column: 'cep', roleLabel: 'Titular' } },
      { key: 'titular_notes',         label: 'Observação do Titular',     type: 'text',    required: false, virtual: true, profileSource: { fkColumn: 'titular_client_id', nameField: 'titular_client_name', column: 'notes', roleLabel: 'Titular' } },
      { key: 'financed_amount',       label: 'Valor Financiado',          type: 'number',  required: false },
      { key: 'installment_value',     label: 'Valor da Parcela',          type: 'number',  required: false },
      { key: 'total_installments',    label: 'Total de Parcelas',         type: 'number',  required: false },
      { key: 'paid_installments',     label: 'Parcelas Pagas',            type: 'number',  required: false },
      { key: 'overdue_installments',  label: 'Parcelas Atrasadas',        type: 'number',  required: false },
      { key: 'due_day',               label: 'Dia de Vencimento',         type: 'number',  required: false },
      { key: 'payment_type',          label: 'Tipo de Pagamento',         type: 'text',    required: false },
      { key: 'indication_type',       label: 'Tipo de Indicação',         type: 'text',    required: false },
      { key: 'origin_type',           label: 'Origem',                    type: 'text',    required: false },
      { key: 'tipo_cliente',          label: 'Tipo de Cliente',           type: 'text',    required: false },
      { key: 'first_installment_due_date', label: '1ª Parcela Vencimento', type: 'date',  required: false, hint: 'DD/MM/AAAA' },
      { key: 'desconto',              label: 'Desconto',                  type: 'number',  required: false },
      { key: 'acrescimo',             label: 'Acréscimo',                 type: 'number',  required: false },
      { key: 'is_electric_vehicle',   label: 'Veículo Elétrico? (sim/não)', type: 'boolean', required: false },
      { key: 'has_bank_fee_included', label: 'Taxa Banco Inclusa? (sim/não)', type: 'boolean', required: false },
      { key: 'is_third_party_contract', label: 'Contrato de Terceiros? (sim/não)', type: 'boolean', required: false },
      { key: 'vehicle_brand',         label: 'Marca do Veículo',          type: 'text',    required: false },
      { key: 'vehicle_model',         label: 'Modelo do Veículo',         type: 'text',    required: false },
      { key: 'vehicle_color',         label: 'Cor do Veículo',            type: 'text',    required: false },
      { key: 'vehicle_year',          label: 'Ano do Veículo',            type: 'text',    required: false },
      { key: 'vehicle_plate',         label: 'Placa',                     type: 'text',    required: false },
      { key: 'vehicle_chassis',       label: 'Chassi',                    type: 'text',    required: false },
      { key: 'vehicle_renavam',       label: 'RENAVAM',                   type: 'text',    required: false },
      { key: 'parcela1',              label: 'Parcela 1',                 type: 'text',    required: false },
      { key: 'parcela2',              label: 'Parcela 2',                 type: 'text',    required: false },
      { key: 'taxa_cobranca',         label: 'Taxa de Cobrança',          type: 'text',    required: false },
      { key: 'audit_critique',        label: 'Crítica de Auditoria',      type: 'text',    required: false },
      { key: 'other_info1',           label: 'Outras Informações 1',      type: 'text',    required: false },
      { key: 'other_info2',           label: 'Outras Informações 2',      type: 'text',    required: false },
    ],
  },
  legal_processes: {
    label: 'Processos Jurídicos',
    description: 'Processos legais cadastrados no sistema.',
    naturalKey: 'process_number',
    dedupKeys: ['process_number'],
    fkColumns: ['client_id', 'unit_id', 'partner_id', 'admission_id'],
    parentLinks: [
      { childKey: 'client_name', parentTable: 'clients',   parentKey: 'name',                                    fkColumn: 'client_id', label: 'Cliente' },
      { childKey: 'unit_name',   parentTable: 'companies', parentKeySql: "COALESCE(NULLIF(nome_fantasia, ''), razao_social)", fkColumn: 'unit_id',   label: 'Unidade' },
      { childKey: 'partner_name', parentTable: 'clients', parentKey: 'name', fkColumn: 'partner_id', label: 'Cliente parceiro', optional: true },
      { childKey: 'admission_contract_number', parentTable: 'admissions', parentKey: 'contract_number', fkColumn: 'admission_id', label: 'Contrato de admissão', optional: true },
    ],
    relationsText: ['Cliente (vinculado automaticamente por nome)', 'Unidade (vinculada por nome)'],
    fields: [
      { key: 'process_number',          label: 'Número do Processo',      type: 'text',    required: true,  hint: 'Usado para detectar duplicados' },
      { key: 'client_name',             label: 'Nome do Cliente',         type: 'text',    required: false, hint: 'Vincula à tabela Clientes pelo nome' },
      { key: 'unit_name',               label: 'Unidade',                 type: 'text',    required: false, virtual: true, hint: 'Nome da unidade (resolve para unit_id)' },
      { key: 'court',                   label: 'Tribunal / Vara',         type: 'text',    required: false },
      { key: 'jurisdiction',            label: 'Comarca',                 type: 'text',    required: false },
      { key: 'type',                    label: 'Tipo de Processo',        type: 'text',    required: false },
      { key: 'status',                  label: 'Status',                  type: 'select',  required: false, options: ['ATIVO', 'INATIVO', 'SUSPENSO', 'ARQUIVADO', 'ACORDO', 'ENCERRADO_PROCEDENTE', 'ENCERRADO_IMPROCEDENTE'], hint: 'Padrão: ATIVO' },
      { key: 'role',                    label: 'Polo (Ativo/Passivo)',     type: 'text',    required: false },
      { key: 'subject',                 label: 'Assunto',                 type: 'text',    required: false },
      { key: 'opposing_party',          label: 'Parte Contrária',         type: 'text',    required: false },
      { key: 'opposing_party_document', label: 'CPF/CNPJ Parte Contrária', type: 'text',  required: false },
      { key: 'opposing_party_lawyer',   label: 'Advogado Contrário',      type: 'text',    required: false },
      { key: 'opposing_party_lawyer_oab', label: 'OAB do Advogado Contrário', type: 'text', required: false },
      { key: 'responsible_lawyer',      label: 'Advogado Responsável',    type: 'text',    required: false },
      { key: 'responsible_lawyer_oab', label: 'OAB do Advogado Responsável', type: 'text', required: false },
      { key: 'partner_name',            label: 'Cliente Parceiro',       type: 'text',    required: false, virtual: true, hint: 'Resolve para o cliente vinculado como parceiro' },
      { key: 'admission_contract_number', label: 'Contrato de Admissão', type: 'text', required: false, virtual: true, hint: 'Número do contrato da admissão relacionada' },
      { key: 'cause_value',             label: 'Valor da Causa (R$)',     type: 'number',  required: false },
      { key: 'provision_value',         label: 'Valor de Provisão (R$)', type: 'number',  required: false },
      { key: 'risk_level',              label: 'Nível de Risco',          type: 'text',    required: false },
      { key: 'contract_number',         label: 'Número do Contrato Relacionado', type: 'text', required: false },
      { key: 'distribution_date',       label: 'Data de Distribuição',    type: 'date',    required: false, hint: 'DD/MM/AAAA' },
      { key: 'last_movement_date',      label: 'Data da Última Movimentação', type: 'text', required: false },
      { key: 'notes',                   label: 'Observações',             type: 'text',    required: false },
      { key: 'notes_header',            label: 'Cabeçalho das Observações', type: 'text', required: false },
      { key: 'notes_footer',            label: 'Rodapé das Observações', type: 'text', required: false },
      { key: 'tags',                    label: 'Marcadores (JSON)',       type: 'json',    required: false, hint: 'Lista JSON, por exemplo: ["urgente","revisar"]' },
    ],
  },
  financial_titles: {
    label: 'Títulos Financeiros',
    description: 'Contas a Receber (RECEBER) e a Pagar (PAGAR).',
    naturalKey: 'document_number',
    dedupKeys: ['document_number'],
    fkColumns: ['client_id', 'category_id', 'document_type_id', 'bearer_id', 'department_id', 'unit_id', 'seller_id', 'bank_account_id', 'assigned_collaborator_id', 'admission_id', 'parent_id'],
    parentLinks: [
      { childKey: 'client_name',          parentTable: 'clients',          parentKey: 'name',                                    fkColumn: 'client_id',        label: 'Cliente' },
      { childKey: 'category_code',        parentTable: 'chart_of_accounts', parentKey: 'code',                                   fkColumn: 'category_id',      label: 'Categoria (Plano de Contas)' },
      { childKey: 'document_type_name',   parentTable: 'document_types',   parentKey: 'description',                             fkColumn: 'document_type_id', label: 'Tipo de Documento' },
      { childKey: 'bearer_name',          parentTable: 'bearers',          parentKey: 'name',                                    fkColumn: 'bearer_id',        label: 'Portador' },
      { childKey: 'department_name',      parentTable: 'departments',      parentKey: 'name',                                    fkColumn: 'department_id',    label: 'Departamento' },
      { childKey: 'unit_name',            parentTable: 'companies',        parentKeySql: "COALESCE(NULLIF(nome_fantasia, ''), razao_social)", fkColumn: 'unit_id',          label: 'Unidade' },
      { childKey: 'seller_name',          parentTable: 'collaborators',    parentKey: 'name',                                    fkColumn: 'seller_id',        label: 'Vendedor' },
      { childKey: 'bank_account_name',    parentTable: 'bank_accounts',    parentKey: 'description',                             fkColumn: 'bank_account_id',  label: 'Conta Bancária' },
      { childKey: 'assigned_collaborator_name', parentTable: 'collaborators', parentKey: 'name', fkColumn: 'assigned_collaborator_id', label: 'Responsável pela cobrança', optional: true },
      { childKey: 'admission_contract_number', parentTable: 'admissions', parentKey: 'contract_number', fkColumn: 'admission_id', label: 'Contrato de admissão', optional: true },
      { childKey: 'parent_document_number', parentTable: 'financial_titles', parentKey: 'document_number', fkColumn: 'parent_id', label: 'Título original', optional: true },
    ],
    relationsText: [
      'Cliente (vinculado automaticamente por nome)',
      'Categoria (vinculada por código do Plano de Contas)',
      'Tipo de Documento (vinculado por descrição)',
      'Portador (vinculado por nome)',
      'Departamento (vinculado por nome)',
      'Unidade (vinculada por nome)',
      'Vendedor (vinculado por nome do colaborador)',
      'Conta Bancária (vinculada por descrição)',
    ],
    fields: [
      { key: 'title_scope',          label: 'Escopo (RECEBER/PAGAR)',      type: 'select',  required: true,  options: ['RECEBER', 'PAGAR'] },
      { key: 'value',                label: 'Valor (R$)',                   type: 'number',  required: true },
      { key: 'description',          label: 'Descrição',                   type: 'text',    required: false },
      { key: 'due_date',             label: 'Vencimento',                  type: 'date',    required: false, hint: 'DD/MM/AAAA ou AAAA-MM-DD' },
      { key: 'issue_date',           label: 'Data de Emissão',             type: 'date',    required: false, hint: 'DD/MM/AAAA ou AAAA-MM-DD' },
      { key: 'expected_date',        label: 'Data Prevista',               type: 'date',    required: false, hint: 'DD/MM/AAAA ou AAAA-MM-DD' },
      { key: 'document_number',      label: 'Nº do Documento',             type: 'text',    required: false, hint: 'Usado para detectar duplicados' },
      { key: 'contract_number',      label: 'Nº do Contrato (referência)', type: 'text',    required: false },
      { key: 'client_name',          label: 'Nome do Cliente',             type: 'text',    required: false, hint: 'Vincula à tabela Clientes pelo nome' },
      { key: 'status',               label: 'Status',                      type: 'select',  required: false, options: ['ABERTO', 'PAGO', 'PARCIAL', 'CANCELADO', 'ADIANTAMENTO', 'ADIANTAMENTO_PARCIAL', 'DEVOLUCAO', 'DEVOLUCAO_PARCIAL', 'DEVOLUCAO_VINCULADA', 'AGRUPADO', 'FATURA_GERADA', 'PROTESTADO', 'PROVISAO'], hint: 'Padrão: ABERTO' },
      { key: 'category_code',        label: 'Categoria (código)',          type: 'text',    required: false, virtual: true, hint: 'Código do Plano de Contas — ex: 1.1.01 (resolve para category_id)' },
      { key: 'document_type_name',   label: 'Tipo de Documento',           type: 'text',    required: false, virtual: true, hint: 'Descrição do tipo de documento (resolve para document_type_id)' },
      { key: 'bearer_name',          label: 'Portador',                    type: 'text',    required: false, virtual: true, hint: 'Nome do portador (resolve para bearer_id)' },
      { key: 'department_name',      label: 'Departamento',                type: 'text',    required: false, virtual: true, hint: 'Nome do departamento (resolve para department_id)' },
      { key: 'unit_name',            label: 'Unidade',                     type: 'text',    required: false, virtual: true, hint: 'Nome da unidade (resolve para unit_id)' },
      { key: 'seller_name',          label: 'Vendedor',                    type: 'text',    required: false, virtual: true, hint: 'Nome do colaborador vendedor (resolve para seller_id)' },
      { key: 'bank_account_name',    label: 'Conta Bancária',              type: 'text',    required: false, virtual: true, hint: 'Descrição da conta bancária (resolve para bank_account_id)' },
      { key: 'assigned_collaborator_name', label: 'Responsável pela Cobrança', type: 'text', required: false, virtual: true, hint: 'Resolve para o colaborador responsável' },
      { key: 'admission_contract_number', label: 'Contrato de Admissão', type: 'text', required: false, virtual: true, hint: 'Número do contrato da admissão relacionada' },
      { key: 'parent_document_number', label: 'Documento do Título Original', type: 'text', required: false, virtual: true, hint: 'Número do documento do título de origem' },
      { key: 'type',                 label: 'Tipo de Título',              type: 'text',    required: false },
      { key: 'source',               label: 'Origem',                      type: 'text',    required: false },
      { key: 'accounting_type',      label: 'Tipo Contábil',               type: 'text',    required: false },
      { key: 'original_value',       label: 'Valor Original (R$)',         type: 'number',  required: false },
      { key: 'interest_value',       label: 'Juros (R$)',                  type: 'number',  required: false },
      { key: 'discount_value',       label: 'Desconto (R$)',               type: 'number',  required: false },
      { key: 'penalty_value',        label: 'Multa (R$)',                  type: 'number',  required: false },
      { key: 'discount_validity',    label: 'Validade do Desconto',        type: 'date',    required: false, hint: 'DD/MM/AAAA' },
      { key: 'return_date',          label: 'Data de Retorno',              type: 'date',    required: false, hint: 'DD/MM/AAAA' },
      { key: 'protest_days',         label: 'Dias para Protesto',          type: 'number',  required: false },
      { key: 'total_installments',   label: 'Total de Parcelas',           type: 'number',  required: false },
      { key: 'installment_number',   label: 'Nº da Parcela',               type: 'number',  required: false },
      { key: 'current_balance',      label: 'Saldo Atual (R$)',            type: 'number',  required: false, hint: 'Se não informado, o sistema usa o Valor como saldo inicial' },
      { key: 'is_protested',         label: 'Protestado? (sim/não)',        type: 'boolean', required: false },
      { key: 'is_provision',         label: 'Provisão? (sim/não)',          type: 'boolean', required: false },
      { key: 'collection_status',    label: 'Situação da Cobrança',         type: 'select', required: false, options: ['EM_DIA', 'COBRAR', 'NAO_COBRAR'] },
    ],
  },
};

// Ordem de processamento — tabelas "principais" (sem dependências) primeiro,
// depois as que referenciam outras (parent-before-child / regra 03.07).
// bank_contacts e bank_services dependem de banks → sempre após banks.
const IMPORT_ORDER = [
  'clients', 'collaborators', 'banks', 'products', 'chart_of_accounts',
  'bank_contacts', 'bank_services',
  'admissions', 'legal_processes', 'financial_titles',
];
const EXPORT_UNIT_TABLES = new Set(['collaborators', 'admissions', 'legal_processes', 'financial_titles']);
// admissions.unit_id remains varchar in the schema contract while companies.id
// is uuid. Keep other UUID foreign-key joins native so PostgreSQL can use their
// indexes during paginated exports.
const EXPORT_TEXT_FK_COLUMNS = new Set(['admissions.unit_id']);
const EXPORT_PAGE_SIZE = 1000;

// Preserve original indexes (row decisions/errors) while processing parents first.
export function getImportRowOrder(table, rows) {
  const links = (IMPORT_SCHEMA[table]?.parentLinks || []).filter(link => link.parentTable === table);
  const normalize = value => String(value ?? '').trim().toLowerCase();
  const parents = links.map(link => {
    const map = new Map();
    rows.forEach((row, index) => {
      const value = normalize(row[link.parentKey]);
      if (value && !map.has(value)) map.set(value, index);
    });
    return map;
  });
  const dependents = rows.map(() => new Set());
  const remaining = rows.map((row, index) => {
    const dependencies = new Set();
    links.forEach((link, linkIndex) => {
      const parent = parents[linkIndex].get(normalize(row[link.childKey]));
      if (parent !== undefined) dependencies.add(parent);
    });
    for (const parent of dependencies) dependents[parent].add(index);
    return dependencies.size;
  });
  const indices = remaining.flatMap((count, index) => count === 0 ? [index] : []);
  for (let cursor = 0; cursor < indices.length; cursor++) {
    for (const child of dependents[indices[cursor]]) {
      remaining[child]--;
      if (remaining[child] === 0) indices.push(child);
    }
  }
  const cyclic = new Set(remaining.flatMap((count, index) => count > 0 ? [index] : []));
  return { indices: [...indices, ...cyclic], cyclic };
}

function addHierarchyError(errors, hierarchy, index) {
  if (hierarchy.cyclic.has(index)) {
    errors.push({ column: 'parent', message: 'Vínculo circular entre registros: revise a referência ao registro-pai.' });
  }
}

function fieldsByKey(cfg) {
  const map = {};
  for (const f of cfg.fields) map[f.key] = f;
  return map;
}

function normalize(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/[\s_\-\/]/g, '');
}

function normalizeClientDocument(value) {
  return String(value ?? '').replace(/\D/g, '');
}

function insertableColumns(cfg) {
  // virtual:true → campos de lookup (ex: bank_name) que servem só para resolver FKs;
  // não são colunas reais no banco e não devem entrar no INSERT/UPDATE.
  return [...cfg.fields.filter(f => !f.virtual).map(f => f.key), ...(cfg.fkColumns || [])];
}

export function parseImportNumber(raw) {
  let value = String(raw).trim().replace(/\s/g, '');
  if (!value) return null;

  const hasComma = value.includes(',');
  const hasDot = value.includes('.');
  if (hasComma && hasDot) {
    if (value.lastIndexOf(',') > value.lastIndexOf('.')) {
      value = value.replace(/\./g, '').replace(',', '.');
    } else {
      value = value.replace(/,/g, '');
    }
  } else if (hasComma) {
    value = /^-?\d{1,3}(,\d{3})+$/.test(value)
      ? value.replace(/,/g, '')
      : value.replace(',', '.');
  } else if (hasDot) {
    if (/^-?\d{1,3}(\.\d{3})+$/.test(value)) {
      value = value.replace(/\./g, '');
    } else if ((value.match(/\./g) || []).length > 1) {
      const decimalAt = value.lastIndexOf('.');
      value = `${value.slice(0, decimalAt).replace(/\./g, '')}${value.slice(decimalAt)}`;
    }
  }

  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function coerceValue(field, raw) {
  if (raw === null || raw === undefined || String(raw).trim() === '') return null;
  const s = String(raw).trim();

  if (field.type === 'boolean') {
    const l = s.toLowerCase();
    return l === 'true' || l === '1' || l === 'sim' || l === 'yes' || l === 's';
  }

  if (field.type === 'number') {
    return parseImportNumber(s);
  }

  if (field.type === 'date') {
    if (/^\d{2}\/\d{2}\/\d{4}$/.test(s)) {
      const [d, m, y] = s.split('/');
      return `${y}-${m}-${d}`;
    }
    if (/^\d{4}-\d{2}-\d{2}/.test(s)) return s.slice(0, 10);
    return null;
  }
  if (field.type === 'json') {
    try {
      const parsed = JSON.parse(s);
      // pg encodes JS arrays as PostgreSQL arrays, not JSONB parameters.
      return Array.isArray(parsed) && parsed.every(item => typeof item === 'string') ? JSON.stringify(parsed) : null;
    } catch {
      return null;
    }
  }

  // Campos que devem ser gravados somente com dígitos (sem máscara)
  const DIGITS_ONLY_KEYS = new Set([
    'document', 'client_document', 'titular_client_document', 'cep', 'phone', 'phone2',
  ]);
  if (DIGITS_ONLY_KEYS.has(field.key)) {
    const digits = s.replace(/\D/g, '');
    return digits === '' ? null : digits;
  }

  return s;
}

/**
 * Valida uma linha já mapeada (chaves = campos do sistema) e retorna erros
 * por coluna: { column, message }. Também devolve os valores coeridos.
 */
function validateRowCells(rawRow, cfg) {
  const fbk = fieldsByKey(cfg);
  const errors = [];
  const coerced = {};

  for (const field of cfg.fields) {
    const raw = rawRow[field.key];
    const coercionField = field.profileSource
      ? { ...field, key: field.profileSource.column }
      : field;
    const value = coerceValue(coercionField, raw);
    coerced[field.key] = value;

    const rawPresent = raw !== null && raw !== undefined && String(raw).trim() !== '';

    if (field.required && (value === null || value === '')) {
      errors.push({ column: field.key, message: `Campo obrigatório "${field.label}" está vazio.` });
      continue;
    }

    if (rawPresent && value === null && (field.type === 'date' || field.type === 'number' || field.type === 'json')) {
      errors.push({
        column: field.key,
        message: field.type === 'date'
          ? `Data inválida em "${field.label}": "${raw}". Use DD/MM/AAAA.`
        : field.type === 'number'
          ? `Número inválido em "${field.label}": "${raw}".`
          : `JSON inválido em "${field.label}": use uma lista JSON de textos.`,
      });
      continue;
    }

    if ((field.type === 'select' || field.options) && value !== null && value !== '') {
      const opts = field.options || [];
      const up = String(value).toUpperCase();
      if (!opts.includes(value) && !opts.includes(up)) {
        errors.push({ column: field.key, message: `Valor inválido em "${field.label}": "${value}". Aceito: ${opts.join(', ')}.` });
      } else if (opts.includes(up) && !opts.includes(value)) {
        coerced[field.key] = up; // normaliza para o enum aceito
      }
    }
  }

  for (const field of cfg.fields.filter(candidate => candidate.profileSource)) {
    const value = coerced[field.key];
    const name = coerced[field.profileSource.nameField];
    if (value !== null && value !== undefined && String(value).trim() !== ''
      && (name === null || name === undefined || String(name).trim() === '')) {
      errors.push({
        column: field.key,
        message: `Preencha "${field.profileSource.roleLabel}" para vincular os dados de "${field.label}" ao cadastro correto.`,
      });
    }
  }

  if (cfg === IMPORT_SCHEMA.admissions) {
    errors.push(...parseAdmissionRecalculation(coerced.other_info2).errors);
    // Admission currency columns are varchar and the form expects BRL strings.
    // A number 40824 inserted as "40824" is otherwise displayed as 408,24.
    for (const key of ['financed_amount', 'installment_value', 'desconto', 'acrescimo', 'parcela1', 'parcela2', 'taxa_cobranca']) {
      const value = coerced[key];
      if (value == null || value === '') continue;
      const number = typeof value === 'number' ? value : parseImportNumber(value);
      if (number === null || !Number.isFinite(number)) {
        errors.push({ column: key, message: `Valor monetário inválido em "${fbk[key]?.label || key}".` });
      } else {
        coerced[key] = number.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2, useGrouping: false });
      }
    }
  }
  // ignore unknown keys (não fazem parte da whitelist) silenciosamente
  return { coerced, errors };
}

const DATABASE_IMPORT_ERROR_MESSAGES = {
  '22001': 'O valor informado excede o limite de caracteres permitido para este campo.',
  '23502': 'Um campo obrigatório ficou sem valor.',
  '23503': 'O vínculo informado não corresponde a um registro existente.',
  '23505': 'Já existe um registro com esta informação.',
  '22P02': 'O valor informado não corresponde ao formato esperado.',
  '22003': 'O valor numérico está fora do limite permitido.',
  '22007': 'A data ou horário informado está em formato inválido.',
  '23514': 'O valor informado não atende às regras permitidas para este campo.',
};

async function explainDatabaseImportError(client, table, dbErr, row, attemptedColumns, lengthCache) {
  if (dbErr.code === '22001') {
    let limits = lengthCache.get(table);
    if (!limits) {
      const result = await client.query(`
        SELECT a.attname AS column_name, a.atttypmod - 4 AS max_length
          FROM pg_attribute a
          JOIN pg_type t ON t.oid = a.atttypid
         WHERE a.attrelid = to_regclass($1)
           AND a.attnum > 0
           AND NOT a.attisdropped
           AND t.typname IN ('varchar', 'bpchar')
           AND a.atttypmod > 4
      `, [table]);
      limits = new Map(result.rows.map(({ column_name, max_length }) => [column_name, Number(max_length)]));
      lengthCache.set(table, limits);
    }

    const fieldsOverLimit = attemptedColumns
      .filter(column => limits.has(column) && typeof row[column] === 'string'
        && Array.from(row[column]).length > limits.get(column))
      .map(column => ({
        column,
        message: `O valor excede o limite de ${limits.get(column)} caracteres permitido para este campo.`,
      }));
    if (fieldsOverLimit.length > 0) return fieldsOverLimit;
  }

  const column = dbErr.column && IMPORT_SCHEMA[table]?.fields.some(field => field.key === dbErr.column)
    ? dbErr.column
    : undefined;
  return [{
    ...(column ? { column } : {}),
    message: DATABASE_IMPORT_ERROR_MESSAGES[dbErr.code]
      || 'Não foi possível importar esta linha devido a uma inconsistência nos dados.',
  }];
}

// Pré-carrega, em UMA ÚNICA query, os ids de duplicatas para toda a tabela de
// um grupo. Funciona apenas para dedupKeys de tamanho 1 (caso mais comum: clients,
// banks, products…). Retorna Map<valorDedup, id> ou null (chave composta → fallback
// por linha via findDuplicateId).
async function preloadDedupMap(client, table, cfg, rawRows) {
  const dedupKeys = cfg.dedupKeys || [];
  if (dedupKeys.length !== 1) return null;
  const key = dedupKeys[0];
  const vals = [...new Set(
    rawRows
      .map(r => { const v = r[key]; return (v !== null && v !== undefined) ? dedupIdentityKey(table, key, v) : ''; })
      .filter(v => v !== '' && v !== SAME_RUN_PENDING)
  )];
  if (vals.length === 0) return new Map();
  const r = await client.query(
    `SELECT id, ${dedupIdentitySql(table, key)} AS dedup_val FROM ${table} WHERE ${dedupIdentitySql(table, key)} = ANY($1::text[])`,
    [vals]
  );
  const map = new Map();
  for (const row of r.rows) {
    map.set(row.dedup_val, map.has(row.dedup_val) ? SAME_RUN_AMBIGUOUS : row.id);
  }
  return map;
}

async function findDuplicateId(client, table, cfg, coerced) {
  const dedupKeys = cfg.dedupKeys || [];
  if (dedupKeys.length === 0) return null;
  // Dedup composto estrito: TODOS os campos da chave devem estar presentes.
  // Se qualquer campo estiver nulo (ex: bank_id não resolvido), ignora dedup
  // para evitar falsos positivos entre entidades diferentes (ex: mesmo nome em bancos distintos).
  const values = dedupKeys.map(k => coerced[k]);
  const allPresent = values.every(v => v !== null && v !== undefined && String(v).trim() !== '');
  if (!allPresent) return null;
  // Vínculo cujo PAI ainda será inserido neste lote (validação/preview): o pai
  // não existe no banco, logo não há filho duplicado dele — pula o dedup e evita
  // consultar uma coluna uuid com o sentinela (que quebraria a validação).
  if (values.some(v => v === SAME_RUN_PENDING)) return null;
  const identities = values.map((value, index) => dedupIdentityKey(table, dedupKeys[index], value));
  if (identities.some(value => !value)) return null;
  const where = dedupKeys.map((k, i) => `${dedupIdentitySql(table, k)} = $${i + 1}`).join(' AND ');
  const r = await client.query(`SELECT id FROM ${table} WHERE ${where} LIMIT 2`, identities);
  if (r.rows.length > 1) return SAME_RUN_AMBIGUOUS;
  return r.rows.length > 0 ? r.rows[0].id : null;
}

// --- Enriquecimento de endereço por CEP (ViaCEP) ---
// Mapeia o retorno do ViaCEP para os campos de endereço das tabelas de importação.
// O NÚMERO nunca vem do CEP (continua vindo da planilha).
const CEP_FIELD_MAP = {
  address: 'logradouro',
  district: 'bairro',
  city: 'localidade',
  state: 'uf',
  complement: 'complemento',
};
const CEP_FIELD_LABELS = {
  address: 'Endereço',
  district: 'Bairro',
  city: 'Cidade',
  state: 'UF',
  complement: 'Complemento',
};

const CEP_LOOKUP_CONCURRENCY = 12;
let activeCepLookups = 0;
const cepLookupWaiters = [];

async function withCepLookupSlot(task) {
  if (activeCepLookups >= CEP_LOOKUP_CONCURRENCY) {
    await new Promise(resolve => cepLookupWaiters.push(resolve));
  } else {
    activeCepLookups++;
  }

  try {
    return await task();
  } finally {
    const next = cepLookupWaiters.shift();
    if (next) next();
    else activeCepLookups--;
  }
}

// Consulta o ViaCEP com tempo-limite e cache (por requisição). Nunca lança:
// retorna o objeto do ViaCEP ou null (não encontrado / falha / timeout).
async function fetchViaCep(cep8, cache) {
  if (cache.has(cep8)) return cache.get(cep8);
  let result = null;
  try {
    result = await withCepLookupSlot(async () => {
      const controller = new AbortController();
      const timer = setTimeout(() => controller.abort(), 4000);
      try {
        const resp = await fetch(`https://viacep.com.br/ws/${cep8}/json/`, { signal: controller.signal });
        if (!resp.ok) return null;
        const data = await resp.json();
        return data && !data.erro ? data : null;
      } finally {
        clearTimeout(timer);
      }
    });
  } catch {
    result = null;
  }
  cache.set(cep8, result);
  return result;
}

// Completa, apenas nos campos de endereço VAZIOS, os dados retornados pelo CEP.
// Preserva valores já informados na planilha. Retorna { filled:[labels], warning:string|null }.
async function enrichAddressByCep(coerced, cache) {
  const rawCep = coerced.cep === null || coerced.cep === undefined ? '' : String(coerced.cep).trim();
  if (rawCep === '') return { filled: [], warning: null };
  // Se todos os campos de endereço já vieram preenchidos na planilha, não há o que
  // completar: evita chamadas desnecessárias ao ViaCEP (importações de até 5.000 linhas).
  const anyEmpty = Object.keys(CEP_FIELD_MAP).some(field => {
    const v = coerced[field];
    return v === null || v === undefined || String(v).trim() === '';
  });
  if (!anyEmpty) return { filled: [], warning: null };
  const cep8 = rawCep.replace(/\D/g, '');
  if (cep8.length !== 8) {
    return { filled: [], warning: `CEP "${rawCep}" inválido (precisa de 8 dígitos) — endereço não preenchido pelo CEP.` };
  }
  const data = await fetchViaCep(cep8, cache);
  if (!data) {
    return { filled: [], warning: `CEP "${rawCep}" não encontrado ou serviço indisponível — endereço não preenchido pelo CEP.` };
  }
  const filled = [];
  for (const [field, viacepKey] of Object.entries(CEP_FIELD_MAP)) {
    const current = coerced[field];
    const isEmpty = current === null || current === undefined || String(current).trim() === '';
    const incoming = data[viacepKey];
    if (isEmpty && incoming !== null && incoming !== undefined && String(incoming).trim() !== '') {
      coerced[field] = String(incoming).trim();
      filled.push(CEP_FIELD_LABELS[field] || field);
    }
  }
  return { filled, warning: null };
}

// Busca CEPs únicos em paralelo limitado, antes de validar/gravar linha a linha.
// Assim, arquivos grandes não ficam aguardando uma chamada externa por registro.
function collectPendingCepLookups(rawRows, cfg, cache) {
  const uniqueCeps = new Set();
  for (const rawRow of rawRows) {
    const { coerced, errors } = validateRowCells(rawRow, cfg);
    if (errors.length > 0) continue;

    const rawCep = coerced.cep === null || coerced.cep === undefined ? '' : String(coerced.cep).trim();
    if (!rawCep) continue;
    const cep8 = rawCep.replace(/\D/g, '');
    if (cep8.length !== 8) continue;

    const hasEmptyAddressField = Object.keys(CEP_FIELD_MAP).some(field => {
      const value = coerced[field];
      return value === null || value === undefined || String(value).trim() === '';
    });
    if (hasEmptyAddressField) uniqueCeps.add(cep8);
  }

  return [...uniqueCeps].filter(cep8 => !cache.has(cep8));
}

async function preloadCepLookupCache(rawRows, cfg, cache, onLookupComplete) {
  const pendingCeps = collectPendingCepLookups(rawRows, cfg, cache);
  let nextIndex = 0;
  let completed = 0;
  const workerCount = Math.min(CEP_LOOKUP_CONCURRENCY, pendingCeps.length);
  await Promise.all(Array.from({ length: workerCount }, async () => {
    while (nextIndex < pendingCeps.length) {
      const cep8 = pendingCeps[nextIndex++];
      await fetchViaCep(cep8, cache);
      completed += 1;
      await onLookupComplete?.(completed, pendingCeps.length);
    }
  }));
}

async function importRelationshipErrors(client, table, row, parentResult) {
  if (!['legal_processes', 'financial_titles'].includes(table) || parentResult.errors.length > 0) return [];
  try {
    await validateClientRelationshipOwnership(client, { ...row, ...parentResult.applied }, {}, { pendingId: SAME_RUN_PENDING });
    return [];
  } catch (error) {
    if (error.statusCode !== 400) throw error;
    return [{ column: 'admission_contract_number', message: error.message }];
  }
}

async function resolveParentLinks(client, cfg, coerced, sameRunMaps, importedTables) {
  // Retorna { errors:[{column,message}], applied: {fkColumn: id} }
  //
  // Estratégia por grupo de fkColumn (suporte a fallback:true):
  //  - Links para o mesmo fkColumn são tentados em ordem: primários primeiro, fallback depois.
  //  - Identificações fornecidas que resolvem precisam concordar no mesmo ID.
  //  - Erros só são emitidos quando NENHUM link do grupo resolveu o FK.
  //  - Isso evita que o erro do link primário persista quando o fallback resolve.
  const errors = [];
  const applied = {};

  // Agrupa links por fkColumn preservando a ordem original
  const groups = {};
  const groupOrder = [];
  for (const link of (cfg.parentLinks || [])) {
    if (!groups[link.fkColumn]) {
      groups[link.fkColumn] = [];
      groupOrder.push(link.fkColumn);
    }
    groups[link.fkColumn].push(link);
  }

  for (const fkColumn of groupOrder) {
    const links = groups[fkColumn];
    let resolved = false;
    let anyValueProvided = false;
    const notFoundErrors = [];
    const candidateIds = new Set();

    for (const link of links) {
      const childVal = coerced[link.childKey];
      const hasValue = childVal !== null && childVal !== undefined && String(childVal).trim() !== '';
      const documentValue = link.documentChildKey ? coerced[link.documentChildKey] : null;
      const hasDocument = documentValue !== null && documentValue !== undefined
        && String(documentValue).trim() !== '';
      if (!hasValue && !hasDocument) continue; // campo vazio: tenta próximo link do grupo

      anyValueProvided = true;
      const key = hasValue ? String(childVal).trim() : '';

      if (hasDocument) {
        const documentKey = normalizeClientDocument(documentValue);
        if (!documentKey) {
          notFoundErrors.push({
            column: link.documentChildKey,
            message: `${link.label}: informe um CPF/CNPJ válido para localizar o cadastro.`,
          });
          continue;
        }

        const nameKey = hasValue ? normalize(key) : '';
        const documentMatch = sameRunMaps?.clientsByDocument?.get(documentKey) || null;
        let documentId = null;
        if (documentMatch === SAME_RUN_AMBIGUOUS) {
          notFoundErrors.push({
            column: link.documentChildKey,
            message: `${link.label}: o CPF/CNPJ informado está associado a mais de um cliente na planilha.`,
          });
          continue;
        }
        if (documentMatch) {
          if (nameKey && normalize(documentMatch.name) !== nameKey) {
            notFoundErrors.push({
              column: link.documentChildKey,
              message: `${link.label}: o nome informado não corresponde ao CPF/CNPJ na aba Clientes.`,
            });
            continue;
          }
          documentId = documentMatch.id;
        } else {
          const matchingClients = await client.query(
            `SELECT id, name FROM clients
              WHERE regexp_replace(COALESCE(${quoteSqlIdentifier(link.parentDocumentColumn)}, ''), '[^0-9]', '', 'g') = $1
              LIMIT 2`,
            [documentKey],
          );
          if (matchingClients.rows.length > 1) {
            notFoundErrors.push({
              column: link.documentChildKey,
              message: `${link.label}: o CPF/CNPJ informado está associado a mais de um cliente cadastrado.`,
            });
            continue;
          }
          if (matchingClients.rows.length === 1) {
            const match = matchingClients.rows[0];
            if (nameKey && normalize(match.name) !== nameKey) {
              notFoundErrors.push({
                column: link.documentChildKey,
                message: `${link.label}: o nome informado não corresponde ao CPF/CNPJ cadastrado.`,
              });
              continue;
            }
            documentId = match.id;
          }
        }

        if (documentId) {
          applied[fkColumn] = documentId;
          if (documentId !== SAME_RUN_PENDING) candidateIds.add(String(documentId));
          resolved = true;
        } else {
          notFoundErrors.push({
            column: link.documentChildKey,
            message: `${link.label}: CPF/CNPJ não encontrado. Confira o documento ou importe o cliente primeiro.`,
          });
        }
        continue;
      }

      // Busca primeiro no mapa do lote atual (evita round-trip ao DB para pais recém-inseridos)
      let id = link.parentKey === IMPORT_SCHEMA[link.parentTable]?.naturalKey
        ? (sameRunMaps?.[link.parentTable]?.get(importIdentityKey(key)) || null)
        : null;
      if (id === SAME_RUN_AMBIGUOUS) {
        notFoundErrors.push({
          column: link.childKey,
          message: `${link.label} ambíguo: "${key}" identifica mais de um cadastro na importação. Informe uma identificação única.`,
        });
        continue;
      }
      {
        // parentKeySql suporta expressões SQL compostas (ex: COALESCE para companies)
        const colExpr = link.parentKeySql || link.parentKey;
        const r = await client.query(
          `SELECT id FROM ${link.parentTable} WHERE LOWER(BTRIM(${colExpr}::text)) = LOWER(BTRIM($1)) LIMIT 2`,
          [key]
        );
        if (r.rows.length > 1 || (id && id !== SAME_RUN_PENDING && r.rows.length === 1 && String(r.rows[0].id) !== String(id))) {
          notFoundErrors.push({
            column: link.childKey,
            message: `${link.label} ambíguo: há mais de um cadastro com a identificação "${key}".`,
          });
          continue;
        }
        if (r.rows.length > 0) id = r.rows[0].id;
      }

      if (id) {
        if (id !== SAME_RUN_PENDING) candidateIds.add(String(id));
        if (!applied[fkColumn] || id !== SAME_RUN_PENDING) applied[fkColumn] = id;
        resolved = true;
      } else {
        // Valor informado mas não encontrado — guarda o erro para emitir só se nenhum resolver
        notFoundErrors.push({ column: link.childKey, message: `${link.label} não encontrado: "${key}". Verifique o valor ou importe a tabela principal primeiro.` });
      }
    }

    if (candidateIds.size > 1) {
      delete applied[fkColumn];
      errors.push({
        column: links[0].childKey,
        message: `${links[0].label}: as identificações informadas apontam para cadastros diferentes. Corrija o vínculo antes de importar.`,
      });
    } else if (!resolved) {
      if (anyValueProvided) {
        // Pelo menos um campo foi preenchido mas nenhum resolveu — reporta os erros de "não encontrado"
        errors.push(...notFoundErrors);
      } else {
        // Nenhum campo do grupo foi preenchido
        // Regra 03.07: quando a tabela principal está sendo importada no mesmo lote,
        // o vínculo é obrigatório — usa o link primário (primeiro não-fallback) para reportar.
        const primaryLink = links.find(l => !l.fallback) || links[0];
        if (!primaryLink.optional && importedTables && importedTables.has(primaryLink.parentTable)) {
          errors.push({ column: primaryLink.childKey, message: `${primaryLink.label} é obrigatório: preencha o vínculo com a tabela principal "${IMPORT_SCHEMA[primaryLink.parentTable]?.label || primaryLink.parentTable}".` });
        }
        // Quando a tabela principal NÃO está no lote: FK fica nula (constraint do banco protege)
      }
    }
  }

  return { errors, applied };
}

function normalizeComparableProfileValue(value) {
  if (value === null || value === undefined) return '';
  return String(value).normalize('NFKC').trim().toLocaleLowerCase('pt-BR');
}

function validateResolvedAdmissionProfileConflicts(coerced, resolvedParentIds) {
  const seenValues = new Map();
  const errors = [];
  for (const field of IMPORT_SCHEMA.admissions.fields.filter(candidate => candidate.profileSource)) {
    const value = coerced[field.key];
    if (value === null || value === undefined || String(value).trim() === '') continue;
    const { fkColumn, column, roleLabel } = field.profileSource;
    const parentId = resolvedParentIds?.[fkColumn];
    if (!parentId) continue; // resolveParentLinks returns the actionable link error.

    const identity = `${String(parentId)}:${column}`;
    const prior = seenValues.get(identity);
    if (prior && normalizeComparableProfileValue(prior.value) !== normalizeComparableProfileValue(value)) {
      errors.push({
        column: field.key,
        message: `Os dados de "${field.label}" divergem dos dados de "${prior.field.label}" para o mesmo cliente. Corrija os campos antes de importar.`,
      });
      continue;
    }
    seenValues.set(identity, { value, field, roleLabel });
  }
  return errors;
}

async function persistAdmissionClientProfiles(client, coerced, resolvedParentIds) {
  const profilesById = new Map();
  for (const field of IMPORT_SCHEMA.admissions.fields.filter(candidate => candidate.profileSource)) {
    const value = coerced[field.key];
    if (value === null || value === undefined || String(value).trim() === '') continue;
    const { fkColumn, column } = field.profileSource;
    const id = resolvedParentIds?.[fkColumn];
    if (!id || id === SAME_RUN_PENDING || id === SAME_RUN_AMBIGUOUS) continue;
    if (!profilesById.has(String(id))) {
      profilesById.set(String(id), { id, values: new Map(), fieldKeysByColumn: new Map(), rolesByColumn: new Map() });
    }
    const profile = profilesById.get(String(id));
    profile.values.set(column, value);
    if (!profile.fieldKeysByColumn.has(column)) profile.fieldKeysByColumn.set(column, field.key);
    if (!profile.rolesByColumn.has(column)) profile.rolesByColumn.set(column, new Set());
    profile.rolesByColumn.get(column).add(fkColumn === 'client_id' ? 'responsible' : 'titular');
  }

  const changedProfiles = [];
  for (const profile of profilesById.values()) {
    const entries = [...profile.values.entries()];
    if (entries.length === 0) continue;
    const selectColumns = entries.map(([column]) => quoteSqlIdentifier(column));
    let existing;
    try {
      const result = await client.query(
        `SELECT ${selectColumns.join(', ')} FROM clients WHERE id = $1 FOR UPDATE`,
        [profile.id],
      );
      existing = result.rows[0];
    } catch (dbErr) {
      dbErr.importContext = {
        table: 'clients',
        row: Object.fromEntries(entries),
        columns: entries.map(([column]) => column),
        fieldKeysByColumn: Object.fromEntries(profile.fieldKeysByColumn),
      };
      throw dbErr;
    }
    if (!existing) continue;

    const changedEntries = entries.filter(([column, value]) => existing[column] !== value);
    if (changedEntries.length === 0) continue;
    const changedRoles = new Set(
      changedEntries.flatMap(([column]) => [...profile.rolesByColumn.get(column)]),
    );

    const columns = changedEntries.map(([column]) => column);
    const values = changedEntries.map(([, value]) => value);
    const assignments = columns.map((column, index) => `${quoteSqlIdentifier(column)} = $${index + 1}`);
    const params = [...values, profile.id];
    try {
      const result = await client.query(
        `UPDATE clients SET ${assignments.join(', ')} WHERE id = $${params.length} RETURNING id`,
        params,
      );
      if (result.rowCount > 0) {
        changedProfiles.push({ id: String(profile.id), roles: [...changedRoles] });
      }
    } catch (dbErr) {
      dbErr.importContext = {
        table: 'clients',
        row: Object.fromEntries(changedEntries),
        columns,
        fieldKeysByColumn: Object.fromEntries(profile.fieldKeysByColumn),
      };
      throw dbErr;
    }
  }
  return { changedProfiles };
}

function signCaptchaToken(answer, photoChallengeId) {
  const secret = process.env.JWT_SECRET;
  // O resultado esperado vai assinado no token (não trafega em claro) — impede
  // que o /stepup seja chamado direto sem resolver o captcha emitido pelo servidor.
  return jwt.sign(
    { type: 'import_captcha', a: Number(answer), photoChallengeId },
    secret,
    { expiresIn: '5m' }
  );
}

function verifyCaptcha(token, answer, photoChallengeId) {
  try {
    if (!token) return false;
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    return payload.type === 'import_captcha'
      && payload.photoChallengeId === photoChallengeId
      && Number.isInteger(Number(payload.a))
      && Number(payload.a) === Number(answer);
  } catch {
    return false;
  }
}

// Step-up de uso único: cada token carrega um `jti` registrado server-side e é
// invalidado na primeira execução — garante re-autenticação "a cada importação".
const activeStepUps = new Map(); // jti -> expiresAt (ms)

function pruneStepUps() {
  const now = Date.now();
  for (const [jti, exp] of activeStepUps) { if (exp <= now) activeStepUps.delete(jti); }
}

async function signStepUpToken(userId) {
  pruneStepUps();
  const secret = process.env.JWT_SECRET;
  const { randomUUID } = await import('crypto');
  const jti = randomUUID();
  activeStepUps.set(jti, Date.now() + 5 * 60 * 1000);
  return jwt.sign({ type: 'import_stepup', userId, jti }, secret, { expiresIn: '5m' });
}

// Retorna o `jti` (string) quando válido, ou null. NÃO consome o token.
function verifyStepUpToken(token, userId) {
  try {
    const secret = process.env.JWT_SECRET;
    const payload = jwt.verify(token, secret);
    if (payload.type !== 'import_stepup' || payload.userId !== userId || !payload.jti) return null;
    const exp = activeStepUps.get(payload.jti);
    if (!exp || exp <= Date.now()) return null; // ausente/expirado/já consumido
    return payload.jti;
  } catch {
    return null;
  }
}

function consumeStepUp(jti) {
  if (jti) activeStepUps.delete(jti);
}

async function buildLayoutWorkbook(tableKeys) {
  const wb = new ExcelJS.Workbook();
  wb.creator = 'FinancePro Assessoria';
  wb.created = new Date();
  const ordered = IMPORT_ORDER.filter(k => tableKeys.includes(k));
  for (const key of ordered) {
    const cfg = IMPORT_SCHEMA[key];
    const ws = wb.addWorksheet(cfg.label.slice(0, 31));
    ws.columns = cfg.fields.map(f => ({
      header: f.label,
      key: f.key,
      width: Math.min(40, Math.max(14, f.label.length, (f.hint || '').length) + 4),
    }));
    const headerRow = ws.getRow(1);
    headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF3F6212' } };
    headerRow.alignment = { vertical: 'middle', horizontal: 'center' };
    headerRow.height = 22;
    const hintRow = ws.addRow(cfg.fields.map(f => `${f.required ? '[OBRIGATÓRIO] ' : ''}${f.hint || ''}`.trim()));
    hintRow.font = { italic: true, size: 9, color: { argb: 'FF6B7280' } };
    hintRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF3F4F6' } };
    ws.views = [{ state: 'frozen', ySplit: 2 }];
    ws.autoFilter = { from: { row: 1, column: 1 }, to: { row: 1, column: cfg.fields.length } };
    cfg.fields.forEach((field, index) => {
      const choices = field.type === 'select'
        ? field.options
        : field.type === 'boolean' ? ['sim', 'não'] : null;
      if (!choices?.length) return;
      const formula = `"${choices.map(value => String(value).replace(/"/g, '""')).join(',')}"`;
      if (formula.length > 255) {
        throw new Error(`A lista de opções de "${field.label}" excede o limite do Excel.`);
      }
      const column = ws.getColumn(index + 1).letter;
      ws.dataValidations.add(`${column}3:${column}1048576`, {
        type: 'list',
        allowBlank: true,
        formulae: [formula],
        showErrorMessage: true,
        errorTitle: 'Valor inválido',
        error: 'Selecione uma das opções disponíveis.',
      });
    });
  }
  return wb.xlsx.writeBuffer();
}

function quoteSqlIdentifier(value) {
  return `"${String(value).replace(/"/g, '""')}"`;
}

function buildExportJoinCondition(tableKey, link, alias) {
  const childFk = `t.${quoteSqlIdentifier(link.fkColumn)}`;
  if (EXPORT_TEXT_FK_COLUMNS.has(`${tableKey}.${link.fkColumn}`)) {
    return `(${alias}.id)::text = (${childFk})::text`;
  }
  return `${alias}.id = ${childFk}`;
}

function buildExportQuery(tableKey, cfg, unitId, lastId) {
  const joins = [];
  const fields = cfg.fields.map((field, index) => {
    const profileSource = field.profileSource || field.exportSource;
    if (profileSource) {
      const alias = `profile_${index}`;
      const quotedAlias = quoteSqlIdentifier(alias);
      const joinCondition = buildExportJoinCondition(tableKey, {
        fkColumn: profileSource.fkColumn,
      }, quotedAlias);
      joins.push(
        `LEFT JOIN "clients" AS ${quotedAlias} ON ${joinCondition}`,
      );
      return `${quotedAlias}.${quoteSqlIdentifier(profileSource.column)} AS ${quoteSqlIdentifier(field.key)}`;
    }

    if (!field.virtual) {
      return `t.${quoteSqlIdentifier(field.key)} AS ${quoteSqlIdentifier(field.key)}`;
    }

    const link = (cfg.parentLinks || []).find(candidate => candidate.childKey === field.key);
    if (!link) throw new Error(`Campo virtual sem vínculo de exportação: ${tableKey}.${field.key}`);
    const alias = `parent_${index}`;
    const quotedAlias = quoteSqlIdentifier(alias);
    const parentTable = quoteSqlIdentifier(link.parentTable);
    const joinCondition = buildExportJoinCondition(tableKey, link, quotedAlias);

    if (link.parentKeySql) {
      joins.push(
        `LEFT JOIN (SELECT id, ${link.parentKeySql} AS import_value FROM ${parentTable}) AS ${quotedAlias} ON ${joinCondition}`,
      );
      return `${quotedAlias}.import_value AS ${quoteSqlIdentifier(field.key)}`;
    }

    if (!link.parentKey) throw new Error(`Campo virtual sem coluna de referência: ${tableKey}.${field.key}`);
      joins.push(`LEFT JOIN ${parentTable} AS ${quotedAlias} ON ${joinCondition}`);
    return `${quotedAlias}.${quoteSqlIdentifier(link.parentKey)} AS ${quoteSqlIdentifier(field.key)}`;
  });
  const unitScoped = EXPORT_UNIT_TABLES.has(tableKey);
  const where = unitScoped
    ? 't."unit_id"::text = $1 AND t."id"::text > $2'
    : 't."id"::text > $1';

  return {
    sql: `SELECT t."id"::text AS "__export_id", ${fields.join(', ')} FROM ${quoteSqlIdentifier(tableKey)} AS t ${joins.join(' ')} WHERE ${where} ORDER BY t."id"::text LIMIT ${EXPORT_PAGE_SIZE}`,
    params: unitScoped ? [unitId, lastId] : [lastId],
  };
}

function exportCellValue(field, value) {
  if (value === null || value === undefined) return null;
  if (field.type === 'json') return JSON.stringify(value);
  if (field.type === 'date') {
    if (value instanceof Date) return value.toISOString().slice(0, 10);
    const text = String(value);
    return /^\d{4}-\d{2}-\d{2}/.test(text) ? text.slice(0, 10) : text;
  }
  if (field.type === 'number') {
    const number = Number(value);
    return Number.isFinite(number) ? number : String(value);
  }
  if (field.type === 'boolean') {
    if (typeof value === 'boolean') return value;
    return ['true', 't', '1', 'sim', 'yes', 's'].includes(String(value).toLowerCase());
  }
  return String(value);
}

async function buildDataExportFile(pool, unitId) {
  let client;
  let exportDir;
  let workbook;
  let transactionStarted = false;
  try {
    exportDir = await mkdtemp(path.join(tmpdir(), 'business-data-export-'));
    const filePath = path.join(exportDir, 'dados_importacao.xlsx');
    client = await pool.connect();
    await client.query('BEGIN ISOLATION LEVEL REPEATABLE READ READ ONLY');
    transactionStarted = true;

    workbook = new ExcelJS.stream.xlsx.WorkbookWriter({
      filename: filePath,
      useStyles: true,
      useSharedStrings: false,
    });
    workbook.creator = 'FinancePro Assessoria';
    workbook.created = new Date();

    for (const tableKey of IMPORT_ORDER) {
      const cfg = IMPORT_SCHEMA[tableKey];
      const worksheet = workbook.addWorksheet(cfg.label.slice(0, 31), {
        views: [{ state: 'frozen', ySplit: 1 }],
        autoFilter: {
          from: { row: 1, column: 1 },
          to: { row: 1, column: cfg.fields.length },
        },
      });
      worksheet.columns = cfg.fields.map(field => ({
        header: field.label,
        key: field.key,
        width: Math.min(40, Math.max(14, field.label.length + 4)),
      }));
      const headerRow = worksheet.getRow(1);
      headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF3F6212' } };
      headerRow.commit();

      let lastId = '';
      while (true) {
        const { sql, params } = buildExportQuery(tableKey, cfg, unitId, lastId);
        const { rows } = await client.query(sql, params);
        for (const row of rows) {
          worksheet.addRow(cfg.fields.map(field => exportCellValue(field, row[field.key]))).commit();
        }
        if (rows.length < EXPORT_PAGE_SIZE) break;
        lastId = rows[rows.length - 1].__export_id;
      }
      worksheet.commit();
    }

    await workbook.commit();
    await client.query('COMMIT');
    transactionStarted = false;
    return { exportDir, filePath };
  } catch (error) {
    try { workbook?.zip?.abort(); } catch {}
    try { workbook?.stream?.destroy(); } catch {}
    if (transactionStarted && client) {
      try { await client.query('ROLLBACK'); } catch {}
    }
    if (exportDir) {
      try { await rm(exportDir, { recursive: true, force: true }); } catch {}
    }
    throw error;
  } finally {
    client?.release();
  }
}

function xlsxCellText(value) {
  if (value === null || value === undefined) return '';
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  if (typeof value === 'object') {
    if (Array.isArray(value.richText)) return value.richText.map(part => part.text || '').join('');
    if (Object.prototype.hasOwnProperty.call(value, 'result')) return xlsxCellText(value.result);
    if (Object.prototype.hasOwnProperty.call(value, 'text')) return String(value.text || '');
  }
  return String(value);
}

/**
 * Lê e mapeia o XLSX no worker. O arquivo e as linhas não passam pelo JSON da
 * requisição: o endpoint apenas grava o binário e enfileira os metadados pequenos.
 */
export async function parseXlsxImport(buffer, requestedTables, mappingByTable = {}, onProgress) {
  await validateImportXlsxArchiveContent(buffer);
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer);
  const sheetNames = workbook.worksheets.map(sheet => sheet.name);
  const selectedSheets = [];
  const usedSheets = new Set();
  const requestedKeys = new Set(requestedTables || []);
  const tableKeys = IMPORT_ORDER.filter(key => requestedKeys.has(key));
  const canUseSingleSheetFallback = tableKeys.length === 1;

  for (const tableKey of tableKeys) {
    const cfg = IMPORT_SCHEMA[tableKey];
    if (!cfg) continue;
    const normalizedLabel = normalize(cfg.label);
    let sheetName = sheetNames.find(name => normalize(name) === normalizedLabel)
      || sheetNames.find(name => normalize(name) === normalize(cfg.key))
      || sheetNames.find(name => {
        const normalizedName = normalize(name);
        return normalizedName.length >= 4 && normalizedLabel.length >= 4
          && (normalizedName.includes(normalizedLabel) || normalizedLabel.includes(normalizedName));
      });
    if (!sheetName && canUseSingleSheetFallback && usedSheets.size === 0 && sheetNames.length === 1) {
      sheetName = sheetNames[0];
    }
    if (!sheetName || usedSheets.has(sheetName)) continue;
    usedSheets.add(sheetName);

    const worksheet = workbook.getWorksheet(sheetName);
    const firstRow = worksheet?.getRow(1);
    const headers = (firstRow?.values || []).slice(1).map(xlsxCellText);
    if (headers.length === 0) continue;
    selectedSheets.push({
      tableKey,
      cfg,
      worksheet,
      headers,
      rowCount: worksheet.rowCount,
    });
  }

  const totalReadRows = selectedSheets.reduce(
    (total, sheet) => total + Math.max(0, sheet.rowCount - 1),
    0,
  );
  if (typeof onProgress === 'function') {
    await onProgress({ stage: 'reading', completed: 0, total: totalReadRows }, true);
  }
  let completedReadRows = 0;
  let totalImportRows = 0;
  const groups = [];

  for (const { tableKey, cfg, worksheet, headers, rowCount } of selectedSheets) {
    const headerIndexes = new Map();
    headers.forEach((header, index) => {
      if (!headerIndexes.has(header)) headerIndexes.set(header, index + 1);
    });
    const mapping = Array.isArray(mappingByTable[tableKey])
      ? mappingByTable[tableKey]
      : [];
    const mappedRows = [];
    for (let rowNumber = 2; rowNumber <= rowCount; rowNumber += 1) {
      const row = worksheet.getRow(rowNumber);
      const values = headers.map((_, index) => xlsxCellText(row.getCell(index + 1).value));
      const isTemplateHintRow = rowNumber === 2 && (
        cfg.fields.every((field, index) =>
          (values[index] || '').trim()
            === `${field.required ? '[OBRIGATÓRIO] ' : ''}${field.hint || ''}`.trim())
        || values.some(value => /^\s*\[OBRIGATÓRIO\]/i.test(value))
        || headers.some((_, index) => {
          const cell = row.getCell(index + 1);
          return cell.font?.italic === true && cell.fill?.pattern === 'solid';
        })
      );
      if (!isTemplateHintRow
        && values.some(value => value.trim() !== '')
        && !values.some(value => /^\s*\[OBRIGATÓRIO\]/i.test(value))) {
        totalImportRows += 1;
        if (totalImportRows > MAX_IMPORT_ROWS) {
          throw new Error(
            `A planilha excede o limite de ${MAX_IMPORT_ROWS.toLocaleString('pt-BR')} linhas por importação. Divida os dados em arquivos menores e tente novamente.`,
          );
        }
        const mapped = {};
        for (const entry of mapping) {
          if (!entry?.fieldKey || !entry.sheetColumn || entry.sheetColumn === '__ignore__') continue;
          const columnIndex = headerIndexes.get(String(entry.sheetColumn));
          if (columnIndex) mapped[entry.fieldKey] = xlsxCellText(row.getCell(columnIndex).value);
        }
        mappedRows.push(mapped);
      }
      completedReadRows += 1;
      if (typeof onProgress === 'function'
        && (completedReadRows % 100 === 0 || completedReadRows === totalReadRows)) {
        await onProgress({
          stage: 'reading',
          completed: completedReadRows,
          total: totalReadRows,
        });
      }
    }
    if (mappedRows.length > 0) groups.push({ table: tableKey, rows: mappedRows });
  }
  return groups;
}

export async function validateImportGroups(
  pool,
  groups,
  cepAutofill = false,
  onProgress,
  { includeParentSnapshots = false } = {},
) {
  const cepCache = new Map();
  const totalRows = groups.reduce((total, group) => total + group.rows.length, 0);
  const notifyProgress = async (progress, force = false) => {
    if (typeof onProgress === 'function') await onProgress(progress, force);
  };
  const eligibleCepGroups = cepAutofill
    ? groups.filter(group => group.table === 'clients' || group.table === 'collaborators')
    : [];
  const cepLookupTotal = new Set(eligibleCepGroups.flatMap(group =>
    collectPendingCepLookups(group.rows, IMPORT_SCHEMA[group.table], cepCache),
  )).size;
  let cepLookupsCompleted = 0;

  if (cepAutofill) {
    for (const group of eligibleCepGroups) {
      if (cepLookupTotal > 0) {
        await notifyProgress({
          stage: 'address_lookup',
          completed: 0,
          total: totalRows,
          activityCompleted: cepLookupsCompleted,
          activityTotal: cepLookupTotal,
        }, true);
      }
      await preloadCepLookupCache(group.rows, IMPORT_SCHEMA[group.table], cepCache, async () => {
        cepLookupsCompleted += 1;
        await notifyProgress({
          stage: 'address_lookup',
          completed: 0,
          total: totalRows,
          activityCompleted: cepLookupsCompleted,
          activityTotal: cepLookupTotal,
        });
      });
    }
  }
  await notifyProgress({ stage: 'validating', completed: 0, total: totalRows }, true);

  const client = await pool.connect();
  try {
    const clientNameConflicts = await analyzeClientNameConflicts(client, groups);
    const sameRunKeys = buildSameRunKeySets(groups, clientNameConflicts);
    const importedTables = new Set(groups.map(group => group.table));
    const out = [];
    let completedRows = 0;
    for (const key of IMPORT_ORDER) {
      const group = groups.find(item => item.table === key);
      if (!group) continue;
      const cfg = IMPORT_SCHEMA[key];
      const rows = [];
      const hierarchy = getImportRowOrder(key, group.rows);
      const dedupPreload = await preloadDedupMap(client, key, cfg, group.rows);
      for (let i = 0; i < group.rows.length; i++) {
        const { coerced, errors } = validateRowCells(group.rows[i], cfg);
        addHierarchyError(errors, hierarchy, i);
        let cepFilled = [];
        let cepWarning = null;
        if (cepAutofill && (key === 'clients' || key === 'collaborators') && errors.length === 0) {
          const enriched = await enrichAddressByCep(coerced, cepCache);
          cepFilled = enriched.filled;
          cepWarning = enriched.warning;
        }
        const parentRes = await resolveParentLinks(client, cfg, coerced, sameRunKeys, importedTables);
        const allErrors = [
          ...errors,
          ...(key === 'clients' ? (clientNameConflicts.errorsByRow.get(i) || []) : []),
          ...(key === 'admissions' ? (clientNameConflicts.admissionProfileErrorsByRow.get(i) || []) : []),
          ...parentRes.errors,
          ...await importRelationshipErrors(client, key, coerced, parentRes),
          ...(key === 'admissions'
            ? validateResolvedAdmissionProfileConflicts(coerced, parentRes.applied)
            : []),
        ];
        let status = allErrors.length > 0 ? 'error' : 'ok';
        let duplicateId = null;
        let rowWarning = cepWarning || null;
        if (status === 'ok') {
          Object.assign(coerced, parentRes.applied);
          if (dedupPreload !== null) {
            const dedupKey = cfg.dedupKeys[0];
            const dedupValue = coerced[dedupKey];
            duplicateId = dedupValue !== null && dedupValue !== undefined
              && String(dedupValue).trim() !== '' && dedupValue !== SAME_RUN_PENDING
              ? (dedupPreload.get(dedupIdentityKey(key, dedupKey, dedupValue)) || null)
              : null;
          } else {
            duplicateId = await findDuplicateId(client, key, cfg, coerced);
          }
          if (duplicateId === SAME_RUN_AMBIGUOUS) {
            allErrors.push(ambiguousDuplicateError(cfg));
            duplicateId = null;
            status = 'error';
          } else if (duplicateId) status = 'duplicate';
          if (key === 'banks' && coerced.febraban_code) {
            const rawFebraban = String(coerced.febraban_code).replace(/\D/g, '');
            const paddedFebraban = rawFebraban.padStart(3, '0');
            const febrabanResult = await client.query(
              'SELECT 1 FROM febraban_banks WHERE code = $1 LIMIT 1',
              [paddedFebraban],
            );
            if (febrabanResult.rows.length === 0) {
              rowWarning = `Código Febraban "${coerced.febraban_code}" não encontrado na base BrasilAPI. O banco será cadastrado, mas verifique o código.`;
            }
          }
        }
        const row = { index: i, status, errors: allErrors, duplicate: !!duplicateId };
        if (key === 'admissions') {
          const recalc = parseAdmissionRecalculation(coerced.other_info2).scenario;
          if (recalc) rowWarning = [rowWarning, `Recálculo extraído: ${recalc.installments_to_pay} parcelas; dívida original R$ ${recalc.original_debt}; parcela R$ ${recalc.installment_value}; dívida recalculada R$ ${recalc.new_debt}; economia R$ ${recalc.savings}; vencimento dia ${recalc.due_day}.`].filter(Boolean).join(' ');
        }
        if (includeParentSnapshots && Object.keys(parentRes.applied).length > 0) {
          row.parentIds = parentRes.applied;
        }
        if (cepFilled.length > 0) row.cepFilled = cepFilled;
        if (rowWarning) row.warning = rowWarning;
        rows.push(row);
        completedRows += 1;
        await notifyProgress({
          stage: 'validating',
          completed: completedRows,
          total: totalRows,
        });
      }
      out.push({
        table: key,
        label: cfg.label,
        total: rows.length,
        ok: rows.filter(row => row.status === 'ok').length,
        duplicate: rows.filter(row => row.status === 'duplicate').length,
        error: rows.filter(row => row.status === 'error').length,
        rows,
      });
    }
    await notifyProgress({ stage: 'validating', completed: totalRows, total: totalRows }, true);
    return out;
  } finally {
    cepCache.clear();
    client.release();
  }
}

export function createDataImportRoutes(pool, dependencies = {}) {
  const router = Router();
  const log = dependencies.logger || logger;
  const enqueueDataImportFn = dependencies.enqueueDataImport || enqueueDataImport;
  const getJobFn = dependencies.getJob || getJob;
  const claimJobForExecutionFn = dependencies.claimJobForExecution || claimJobForExecution;
  const updateJobFn = dependencies.updateJob || updateJob;
  const uploadImportObjectFn = dependencies.uploadImportObject || uploadImportObject;
  const downloadImportObjectFn = dependencies.downloadImportObject || downloadImportObject;
  const deleteImportObjectFn = dependencies.deleteImportObject || deleteImportObject;
  const verifyStepUpTokenFn = dependencies.verifyStepUpToken || verifyStepUpToken;
  const consumeStepUpFn = dependencies.consumeStepUp || consumeStepUp;
  const logAuditFn = dependencies.logAudit || logAudit;

  const importLimiter = createRateLimiter({
    windowMs: 60 * 1000,
    maxRequests: 30,
    message: 'Muitas requisições de importação. Aguarde 1 minuto.',
  });
  // O cliente consulta o status a cada 500 ms durante a leitura. Esse tráfego
  // precisa de um bucket próprio para não consumir o limite das ações manuais.
  const jobPollLimiter = createRateLimiter({
    windowMs: 60 * 1000,
    maxRequests: 150,
    message: 'Muitas consultas de processamento. Aguarde 1 minuto.',
  });
  const executeLimiter = createRateLimiter({
    windowMs: 60 * 1000,
    maxRequests: 10,
    message: 'Muitas execuções de importação. Aguarde 1 minuto.',
  });

  router.use(requireAdmin);
  router.use((req, res, next) => {
    const isJobStatusRead = req.method === 'GET' && /^\/job\/[^/]+$/.test(req.path);
    return isJobStatusRead ? next() : importLimiter(req, res, next);
  });

  router.get('/queue-health', async (req, res) => {
    const periods = {
      '24h': { interval: '24 hours', durationMs: 24 * 60 * 60 * 1000, bucket: 'hour', step: '1 hour' },
      '7d': { interval: '7 days', durationMs: 7 * 24 * 60 * 60 * 1000, bucket: 'day', step: '1 day' },
      '30d': { interval: '30 days', durationMs: 30 * 24 * 60 * 60 * 1000, bucket: 'day', step: '1 day' },
    };
    const selectedPeriod = periods[req.query.period || '24h'];
    if (!selectedPeriod) {
      return res.status(400).json({ error: 'Período inválido. Use 24h, 7d ou 30d.' });
    }

    try {
      const result = await pool.query(
        `WITH bounds AS (
           SELECT NOW() - $1::interval AS starts_at, NOW() AS ends_at
         ),
         buckets AS (
           SELECT generate_series(
             date_trunc('${selectedPeriod.bucket}', bounds.starts_at),
             date_trunc('${selectedPeriod.bucket}', bounds.ends_at),
             '${selectedPeriod.step}'::interval
           ) AS period_start
           FROM bounds
         ),
         event_types AS (
           SELECT unnest(ARRAY[
             'data_import_queue_full',
             'data_import_queue_reservation_timeout',
             'data_import_queue_reservation_slow'
           ]::varchar[]) AS event_type
         ),
         aggregates AS (
           SELECT date_trunc('${selectedPeriod.bucket}', event.occurred_at) AS period_start,
                  event.event_type,
                  COUNT(*)::int AS event_count,
                  ROUND(AVG(event.reservation_duration_ms), 1) AS average_duration_ms,
                  MAX(event.reservation_duration_ms) AS maximum_duration_ms
             FROM data_import_queue_events AS event
             CROSS JOIN bounds
            WHERE event.occurred_at >= bounds.starts_at
              AND event.occurred_at <= bounds.ends_at
            GROUP BY 1, 2
         )
         SELECT buckets.period_start,
                event_types.event_type,
                COALESCE(aggregates.event_count, 0)::int AS event_count,
                aggregates.average_duration_ms,
                aggregates.maximum_duration_ms
           FROM buckets
           CROSS JOIN event_types
           LEFT JOIN aggregates
             ON aggregates.period_start = buckets.period_start
            AND aggregates.event_type = event_types.event_type
          ORDER BY buckets.period_start, event_types.event_type`,
        [selectedPeriod.interval],
      );

      const failureWindowStart = new Date(Date.now() - selectedPeriod.durationMs);
      let telemetryIncomplete = hasLocalQueueMetricWriteFailure(pool, failureWindowStart);
      try {
        const failures = await pool.query(
          `SELECT EXISTS (
             SELECT 1
               FROM data_import_queue_metric_failures
              WHERE occurred_at >= NOW() - $1::interval
           ) AS has_failures`,
          [selectedPeriod.interval],
        );
        telemetryIncomplete ||= failures.rows[0]?.has_failures === true;
      } catch {
        // If the marker store cannot be checked, do not present aggregates as complete.
        telemetryIncomplete = true;
      }

      const bucketsByPeriod = new Map();
      for (const row of result.rows) {
        const periodStart = new Date(row.period_start).toISOString();
        if (!bucketsByPeriod.has(periodStart)) {
          bucketsByPeriod.set(periodStart, {
            periodStart,
            queueFull: { count: 0, averageDurationMs: null, maximumDurationMs: null },
            reservationTimeout: { count: 0, averageDurationMs: null, maximumDurationMs: null },
            reservationSlow: { count: 0, averageDurationMs: null, maximumDurationMs: null },
          });
        }
        const targetMetric = {
          data_import_queue_full: 'queueFull',
          data_import_queue_reservation_timeout: 'reservationTimeout',
          data_import_queue_reservation_slow: 'reservationSlow',
        }[row.event_type];
        const target = bucketsByPeriod.get(periodStart)[targetMetric];
        target.count = Number(row.event_count);
        target.averageDurationMs = row.average_duration_ms == null
          ? null
          : Number(row.average_duration_ms);
        target.maximumDurationMs = row.maximum_duration_ms == null
          ? null
          : Number(row.maximum_duration_ms);
      }

      return res.json({
        period: req.query.period || '24h',
        bucket: selectedPeriod.bucket,
        buckets: [...bucketsByPeriod.values()],
        telemetryIncomplete,
      });
    } catch {
      log.error('[import/queue] Falha ao consultar o resumo operacional da fila.');
      return res.status(503).json({ error: 'Resumo operacional da fila indisponível.' });
    }
  });

  const invictaFiles = {
    script: {
      path: path.resolve(process.cwd(), 'scripts/invicta/Invoke-InvictaInventory.ps1'),
      name: 'Invoke-InvictaInventory.ps1',
    },
    validation: {
      path: path.resolve(process.cwd(), 'scripts/invicta/Invicta.Validation.ps1'),
      name: 'Invicta.Validation.ps1',
    },
    checkpoint: {
      path: path.resolve(process.cwd(), 'scripts/invicta/Invicta.Checkpoint.ps1'),
      name: 'Invicta.Checkpoint.ps1',
    },
    instructions: {
      path: path.resolve(process.cwd(), 'scripts/invicta/README.md'),
      name: 'README.md',
    },
    template: {
      path: path.resolve(process.cwd(), 'attached_assets/layout_importacao_clients_admissions_financial_titles_legal_p_1790023803470.xlsx'),
      name: 'layout_importacao_invicta.xlsx',
    },
    launcher: {
      path: path.resolve(process.cwd(), 'scripts/invicta/Executar-AssistenteInvicta.ps1'),
      name: 'Executar-AssistenteInvicta.ps1',
    },
    start: {
      path: path.resolve(process.cwd(), 'scripts/invicta/INICIAR.cmd'),
      name: 'INICIAR.cmd',
    },
  };

  router.get('/invicta-package', async (_req, res) => {
    const packageFiles = ['script', 'validation', 'checkpoint', 'instructions', 'template', 'launcher', 'start'].map(key => invictaFiles[key]);
    try {
      await Promise.all(packageFiles.map(file => access(file.path)));
      const contents = await Promise.all(packageFiles.map(async file => {
        const content = await readFile(file.path);
        if (file.name.endsWith('.ps1')) {
          const withoutBom = content[0] === 0xef && content[1] === 0xbb && content[2] === 0xbf
            ? content.subarray(3)
            : content;
          return Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), withoutBom]);
        }
        if (file.name.endsWith('.cmd')) {
          return Buffer.from(content.toString('utf8').replace(/\r?\n/g, '\r\n'), 'utf8');
        }
        return content;
      }));
      res.attachment('Assistente-Invicta-Windows.zip');
      res.type('application/zip');
      res.set('Cache-Control', 'private, no-store');
      const archive = archiver('zip', { zlib: { level: 9 } });
      archive.on('warning', err => logger.warn('[import] Aviso ao gerar pacote Invicta:', err.message));
      archive.on('error', err => {
        logger.error('[import] Falha ao gerar pacote Invicta:', err.message);
        if (!res.headersSent) res.status(500).json({ error: 'Não foi possível gerar o pacote Windows.' });
        else res.destroy(err);
      });
      archive.pipe(res);
      packageFiles.forEach((file, index) => archive.append(contents[index], { name: file.name }));
      await archive.finalize();
    } catch (err) {
      logger.error('[import] Pacote Invicta indisponível:', err.message);
      if (!res.headersSent) return res.status(500).json({ error: 'Pacote Windows temporariamente indisponível.' });
    }
  });

  router.get('/invicta-files/:fileKey', async (req, res) => {
    const file = invictaFiles[req.params.fileKey];
    if (!file) return res.status(404).json({ error: 'Arquivo do assistente não encontrado.' });
    try {
      await access(file.path);
      return res.download(file.path, file.name);
    } catch (err) {
      logger.error('[import] Arquivo Invicta indisponível:', err.message);
      return res.status(500).json({ error: 'Arquivo do assistente temporariamente indisponível.' });
    }
  });

  // Schema/whitelist completo (para o painel de tabelas e relacionamentos).
  router.get('/schema', (_req, res) => {
    const tables = IMPORT_ORDER.map(key => {
      const cfg = IMPORT_SCHEMA[key];
      return {
        key,
        label: cfg.label,
        description: cfg.description,
        dedupKeys: cfg.dedupKeys || [],
        relationsText: cfg.relationsText || [],
        parentLinks: (cfg.parentLinks || []).map(l => ({
          childKey: l.childKey,
          parentTable: l.parentTable,
          parentKey: l.parentKey,
          parentKeySql: l.parentKeySql,
          fkColumn: l.fkColumn,
          label: l.label,
        })),
        relatedTables: IMPORT_ORDER.filter(other => other !== key && isRelated(key, other)),
        fields: cfg.fields,
      };
    });
    res.json({ tables });
  });

  // Geração do layout Excel (parent-first) das tabelas selecionadas.
  router.post('/layout', async (req, res) => {
    const tables = Array.isArray(req.body?.tables) ? req.body.tables : [];
    const valid = [...new Set(tables.filter(t => IMPORT_SCHEMA[t]))];
    if (valid.length === 0) {
      return res.status(400).json({ error: 'Selecione ao menos uma tabela válida.' });
    }
    try {
      const buffer = await buildLayoutWorkbook(valid);
      const fname = `layout_importacao_${valid.join('_')}.xlsx`.slice(0, 120);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Content-Disposition', `attachment; filename="${fname}"`);
      res.send(Buffer.from(buffer));
    } catch (err) {
      logger.error('[import] Erro ao gerar layout:', err.message);
      res.status(500).json({ error: 'Erro ao gerar o layout.' });
    }
  });

  // Exportação administrativa: apenas os campos aceitos pelo importador são
  // incluídos; tabelas com unit_id ficam limitadas à unidade ativa.
  router.post('/export', async (req, res) => {
    const unitId = String(req.currentUser?.currentUnitId || '').trim();
    if (!unitId) {
      return res.status(400).json({ error: 'Selecione uma unidade antes de exportar os dados.' });
    }

    let file;
    try {
      file = await buildDataExportFile(pool, unitId);
      res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
      res.setHeader('Cache-Control', 'private, no-store');
      return res.download(file.filePath, 'dados_importacao.xlsx', error => {
        if (error) logger.error('[import] Falha ao enviar a exportação Excel:', error.message);
        void rm(file.exportDir, { recursive: true, force: true })
          .catch(cleanupError => logger.warn('[import] Falha ao remover arquivo temporário:', cleanupError.message));
      });
    } catch (err) {
      logger.error('[import] Erro ao exportar dados Excel:', err.message);
      if (file?.exportDir) {
        try { await rm(file.exportDir, { recursive: true, force: true }); } catch {}
      }
      return res.status(500).json({ error: 'Não foi possível exportar os dados cadastrados.' });
    }
  });

  // Upload binário do XLSX. O corpo contém somente o arquivo; as linhas ficam
  // no Object Storage até a execução, portanto não entram no payload JSON.
  router.post('/upload', async (req, res) => {
    const bytes = req.body;
    if (!Buffer.isBuffer(bytes) || bytes.length === 0) {
      return res.status(400).json({ error: 'Envie um arquivo XLSX válido.' });
    }
    if (bytes.length > MAX_IMPORT_FILE_BYTES) {
      return res.status(413).json({ error: 'Planilha muito grande. Tamanho máximo: 22 MB.' });
    }
    try {
      await validateImportXlsxArchiveContent(bytes);
    } catch (error) {
      const status = error.code === 'IMPORT_XLSX_EXPANSION_LIMIT' ? 413 : 400;
      return res.status(status).json({ error: error.message });
    }

    let tables;
    let mappingByTable;
    try {
      tables = JSON.parse(req.headers['x-import-tables'] || '[]');
      mappingByTable = parseImportMappingHeader(req.headers['x-import-mapping']);
    } catch {
      return res.status(400).json({ error: 'Metadados da importação inválidos.' });
    }
    if (!Array.isArray(tables) || tables.length === 0 || tables.some(table => !IMPORT_SCHEMA[table])) {
      return res.status(400).json({ error: 'Selecione ao menos uma tabela válida.' });
    }
    if (!mappingByTable || typeof mappingByTable !== 'object' || Array.isArray(mappingByTable)) {
      return res.status(400).json({ error: 'Mapeamento da planilha inválido.' });
    }

    const fileKey = createImportObjectKey('xlsx');
    try {
      await uploadImportObjectFn(fileKey, bytes);
      const jobId = await enqueueDataImportFn({
        fileKey,
        fileName: (() => {
          try {
            return decodeURIComponent(String(req.headers['x-import-file-name'] || 'importacao.xlsx')).slice(0, 255);
          } catch {
            return 'importacao.xlsx';
          }
        })(),
        tables,
        mappingByTable,
        cepAutofill: req.headers['x-import-cep-autofill'] === 'true',
        userId: req.currentUser?.id,
        unitId: req.currentUser?.currentUnitId || null,
      });
      return res.status(202).json({ jobId });
    } catch (err) {
      await deleteImportObjectFn(fileKey).catch(() => {});
      if (err?.code === 'DATA_IMPORT_QUEUE_FULL') {
        return res.status(429).json({
          error: 'A fila de importação está cheia. Aguarde a conclusão de uma leitura e tente novamente.',
        });
      }
      if (err?.code === 'DATA_IMPORT_QUEUE_LOCK_TIMEOUT') {
        res.set('Retry-After', '1');
        return res.status(503).json({
          error: 'A fila de importação está ocupada. Tente novamente em instantes.',
        });
      }
      log.error('[import] Falha ao enfileirar XLSX:', err.message);
      return res.status(500).json({ error: 'Não foi possível enfileirar a leitura da planilha.' });
    }
  });

  router.get('/job/:jobId', jobPollLimiter, async (req, res) => {
    const job = await getJobFn(req.params.jobId);
    if (!job || job.queue !== 'data-import-xlsx') {
      return res.status(404).json({ error: 'Job de importação não encontrado.' });
    }
    if (String(job.payload?.userId || '') !== String(req.currentUser?.id || '')
      || (job.payload?.unitId && job.payload.unitId !== req.currentUser?.currentUnitId)) {
      return res.status(403).json({ error: 'Job de importação não pertence à sessão atual.' });
    }
    if (job.status === 'failed') {
      // A falha é um estado terminal conhecido do job, não uma falha da
      // requisição de consulta. Retornar 200 evita retries do cliente e deixa
      // o wizard encerrar o polling imediatamente com a mensagem do worker.
      return res.json({ jobId: job.id, status: job.status, error: job.error || 'Falha ao processar a planilha.' });
    }
    const storedProgress = job.status === 'processing' ? job.result?.progress : null;
    const progressStages = new Set(['reading', 'address_lookup', 'validating', 'preparing']);
    const safeCount = value => Number.isSafeInteger(value) && value >= 0 ? value : 0;
    const progress = storedProgress && progressStages.has(storedProgress.stage)
      ? {
          stage: storedProgress.stage,
          completed: safeCount(storedProgress.completed),
          total: safeCount(storedProgress.total),
          ...(Number.isSafeInteger(storedProgress.activityCompleted) && storedProgress.activityCompleted >= 0
            ? { activityCompleted: storedProgress.activityCompleted }
            : {}),
          ...(Number.isSafeInteger(storedProgress.activityTotal) && storedProgress.activityTotal >= 0
            ? { activityTotal: storedProgress.activityTotal }
            : {}),
          ...(typeof storedProgress.lastProgressAt === 'string'
            && Number.isFinite(Date.parse(storedProgress.lastProgressAt))
            ? { lastProgressAt: new Date(storedProgress.lastProgressAt).toISOString() }
            : {}),
        }
      : undefined;
    return res.json({
      jobId: job.id,
      status: job.status,
      progress,
      groups: job.status === 'completed' ? (job.result?.groups || []) : undefined,
      fileName: job.status === 'completed' ? job.result?.fileName : undefined,
    });
  });

  // Validação pré-execução (dry): por linha e coluna, com detecção de duplicados.
  router.post('/validate', async (req, res) => {
    const groups = normalizeGroups(req.body?.groups, req.body);
    if (!groups) return res.status(400).json({ error: 'Nenhum dado enviado para validação.' });

    try {
      const groupsResult = await validateImportGroups(pool, groups, req.body?.cepAutofill === true);
      res.json({ groups: groupsResult });
    } catch (err) {
      logger.error('[import] Erro na validação:', err.message);
      res.status(500).json({ error: 'Erro interno durante a validação.' });
    }
  });

  // Emite os desafios matemático e de fotos vinculados à importação.
  router.get('/captcha', async (_req, res) => {
    try {
      const a = randomInt(1, 10);
      const b = randomInt(1, 10);
      const photoChallenge = await issuePhotoChallenge('import', {}, pool);
      res.json({
        captchaToken: signCaptchaToken(a + b, photoChallenge.id),
        question: `${a} + ${b}`,
        photoChallenge,
      });
    } catch (error) {
      logger.error('[import] Não foi possível emitir o desafio de fotos:', error.message);
      res.status(500).json({ error: 'Não foi possível carregar as verificações de segurança.' });
    }
  });

  // Step-up: senha, captcha matemático e desafio de fotos validados no servidor.
  router.post('/stepup', async (req, res) => {
    const {
      password, captchaToken, captchaAnswer, photoChallengeId, photoSelections,
    } = req.body || {};
    const userId = req.currentUser?.id;
    if (!userId) return res.status(401).json({ error: 'Sessão inválida.' });
    if (!password) return res.status(400).json({ error: 'Informe sua senha para confirmar a importação.' });
    if (!verifyCaptcha(captchaToken, captchaAnswer, photoChallengeId)) {
      return res.status(400).json({ error: 'Captcha incorreto ou expirado. Gere um novo desafio.' });
    }
    const photoResult = await verifyPhotoChallenge('import', photoChallengeId, photoSelections, undefined, pool);
    if (!photoResult.valid) {
      return res.status(400).json({ error: 'Desafio de fotos incorreto, expirado ou já utilizado. Gere um novo desafio.' });
    }

    try {
      const r = await pool.query('SELECT initial_password, mfa_enabled, mfa_secret, mfa_backup_codes, role, status, locked_at FROM users WHERE id = $1', [userId]);
      if (r.rows.length === 0) return res.status(404).json({ error: 'Usuário não encontrado.' });
      const user = r.rows[0];

      // Revalida estado da conta no banco (não confia apenas no claim do JWT).
      if (user.status === 'INATIVO' || user.locked_at) {
        return res.status(403).json({ error: 'Conta inativa ou bloqueada. Faça login novamente.' });
      }
      if (user.role !== 'ADMIN') {
        return res.status(403).json({ error: 'Apenas administradores podem executar importações.' });
      }

      const storedHash = user.initial_password || '';
      let passwordValid = false;
      if (storedHash.startsWith('$2b$') || storedHash.startsWith('$2a$')) {
        passwordValid = await bcrypt.compare(password, storedHash);
      } else if (storedHash.length === 64) {
        const { createHash } = await import('crypto');
        passwordValid = createHash('sha256').update(password).digest('hex') === storedHash;
      }
      if (!passwordValid) return res.status(401).json({ error: 'Senha incorreta.' });

      if (!user.mfa_enabled) {
        return res.status(403).json({ error: 'É necessário ativar a verificação em duas etapas (2FA) para executar importações.' });
      }

      return res.json({ stepUpToken: await signStepUpToken(userId) });
    } catch (err) {
      logger.error('[import] Erro no step-up:', err.message);
      return res.status(500).json({ error: 'Erro interno na re-autenticação.' });
    }
  });

  // Execução transacional — exige step-up token válido.
  router.post('/execute', executeLimiter, async (req, res) => {
    // Importações grandes não têm limite de tempo — desativa o timeout de socket
    // para esta requisição específica (não afeta outras rotas).
    req.setTimeout(0);
    const userId = req.currentUser?.id;
    const {
      stepUpToken,
      importJobId,
      duplicateStrategy = 'ignore',
      rowDecisions = {},
      mode = 'approved_only',
    } = req.body || {};
    const stepUpJti = verifyStepUpTokenFn(stepUpToken, userId);
    if (!stepUpJti) {
      return res.status(401).json({ error: 'Re-autenticação necessária. Refaça a verificação (senha + 2FA).' });
    }
    if (!req.currentUser?.currentUnitId) {
      return res.status(400).json({ error: 'Selecione uma unidade antes de executar a importação.' });
    }
    // Uso único: invalida imediatamente, independentemente do resultado da importação.
    consumeStepUpFn(stepUpJti);
    let groups = normalizeGroups(req.body?.groups, req.body);
    let importDataKey = null;
    let claimedImportJob = null;
    let preparedParentSnapshots = null;
    const restoreClaimedImportJob = async () => {
      if (!claimedImportJob) return;
      await updateJobFn(
        importJobId,
        'completed',
        claimedImportJob.result,
        null,
        claimedImportJob.lease_token,
      ).catch(error => {
        logger.error('[import] Falha ao restaurar job preparado:', error.message);
      });
      claimedImportJob = null;
    };
    const finishClaimedImportJob = async preparedObjectDeleted => {
      if (!claimedImportJob) return;
      const result = { ...(claimedImportJob.result || {}), executedAt: new Date().toISOString() };
      if (preparedObjectDeleted) delete result.dataKey;
      await updateJobFn(
        importJobId,
        'completed',
        result,
        null,
        claimedImportJob.lease_token,
      ).catch(error => {
        logger.error('[import] Falha ao finalizar job preparado:', error.message);
      });
      claimedImportJob = null;
    };
    const deletePreparedObject = async () => {
      if (!importDataKey) return true;
      try {
        await deleteImportObjectFn(importDataKey);
        return true;
      } catch (error) {
        logger.error('[import] Falha ao remover dados preparados:', error.message);
        return false;
      }
    };
    if (importJobId) {
      let job = await getJobFn(importJobId);
      if (!job || job.queue !== 'data-import-xlsx'
        || String(job.payload?.userId || '') !== String(userId || '')
        || (job.payload?.unitId && job.payload.unitId !== req.currentUser?.currentUnitId)
        || job.status !== 'completed') {
        return res.status(400).json({ error: 'A leitura da planilha ainda não está pronta ou não pertence à sessão atual.' });
      }
      job = await claimJobForExecutionFn(importJobId);
      if (!job) {
        return res.status(400).json({ error: 'A leitura da planilha já está em execução, expirou ou não está disponível.' });
      }
      claimedImportJob = job;
      importDataKey = job.result?.dataKey || null;
      if (!importDataKey) {
        await restoreClaimedImportJob();
        return res.status(400).json({ error: 'Resultado da leitura da planilha não está disponível.' });
      }
      try {
        const stored = JSON.parse((await downloadImportObjectFn(importDataKey)).toString('utf8'));
        groups = normalizeGroups(stored.groups, stored);
        preparedParentSnapshots = stored.parentSnapshots || null;
      } catch (err) {
        await restoreClaimedImportJob();
        logger.error('[import] Falha ao carregar dados enfileirados:', err.message);
        return res.status(500).json({ error: 'Não foi possível carregar os dados preparados da planilha.' });
      }
    }
    if (!groups) {
      await restoreClaimedImportJob();
      return res.status(400).json({ error: 'Nenhum dado enviado para importação.' });
    }

    const cepAutofill = req.body?.cepAutofill === true; // padrão: desligado (opt-in)
    const cepCache = new Map();
    const totalRows = groups.reduce((acc, g) => acc + g.rows.length, 0);
    if (totalRows > MAX_IMPORT_ROWS) {
      await restoreClaimedImportJob();
      return res.status(400).json({
        error: `Máximo de ${MAX_IMPORT_ROWS.toLocaleString('pt-BR')} linhas por importação.`,
      });
    }

    // Modo de execução:
    //  - 'approved_only'      → importa as linhas válidas e pula as inconsistentes (padrão)
    //  - 'abort_on_any_error' → cancela TODA a importação se houver qualquer inconsistência
    const abortOnError = mode === 'abort_on_any_error';

    if (cepAutofill) {
      for (const group of groups) {
        if (group.table !== 'clients' && group.table !== 'collaborators') continue;
        await preloadCepLookupCache(group.rows, IMPORT_SCHEMA[group.table], cepCache);
      }
    }

    const client = await pool.connect();
    const summary = {
      total: totalRows,
      inserted: 0,
      updated: 0,
      ignored: 0,
      inconsistent: 0,
      clientProfilesUpdated: 0,
      responsibleClientProfilesUpdated: 0,
      titularClientProfilesUpdated: 0,
      groups: [],
    };
    const characterLimitCache = new Map();
    let abortReason = null;
    try {
      const clientNameConflicts = await analyzeClientNameConflicts(client, groups);
      // Pré-validação no modo "cancelar tudo": nada é inserido se houver inconsistência.
      if (abortOnError) {
        const sameRunKeys = buildSameRunKeySets(groups, clientNameConflicts);
        const importedTables = new Set(groups.map(g => g.table));
        const problems = [];
        for (const key of IMPORT_ORDER) {
          const group = groups.find(g => g.table === key);
          if (!group) continue;
          const cfg = IMPORT_SCHEMA[key];
          const hierarchy = getImportRowOrder(key, group.rows);
          for (let i = 0; i < group.rows.length; i++) {
            const { coerced, errors } = validateRowCells(group.rows[i], cfg);
            addHierarchyError(errors, hierarchy, i);
            const parentRes = await resolveParentLinks(client, cfg, coerced, sameRunKeys, importedTables);
            const rowErrors = [
              ...errors,
              ...(key === 'clients' ? (clientNameConflicts.errorsByRow.get(i) || []) : []),
              ...(key === 'admissions' ? (clientNameConflicts.admissionProfileErrorsByRow.get(i) || []) : []),
              ...parentRes.errors,
              ...await importRelationshipErrors(client, key, coerced, parentRes),
              ...(key === 'admissions'
                ? validateResolvedAdmissionProfileConflicts(coerced, parentRes.applied)
                : []),
              ...preparedRelationshipErrors(
                key, i, group.rows[i], parentRes.applied, preparedParentSnapshots, Boolean(importJobId), true,
              ),
            ];
            if (rowErrors.length > 0) {
              problems.push({ table: key, label: cfg.label, row: i + 1, errors: rowErrors.map(e => ({ column: e.column, message: e.message })) });
            }
          }
        }
        if (problems.length > 0) {
          client.release();
          const preparedObjectDeleted = await deletePreparedObject();
          await finishClaimedImportJob(preparedObjectDeleted);
          return res.json({
            aborted: true,
            error: 'Importação cancelada: há inconsistências e o modo "cancelar tudo" está ativo.',
            total: totalRows,
            inserted: 0, updated: 0, ignored: 0,
            inconsistent: problems.length,
            problems,
            groups: [],
          });
        }
      }

      await client.query('BEGIN');
      const sameRunMaps = {}; // parentTable -> Map(lowerKey -> id)
      if (clientNameConflicts.ambiguousNames.size > 0) {
        sameRunMaps.clients = new Map(
          [...clientNameConflicts.ambiguousNames].map(name => [name, SAME_RUN_AMBIGUOUS]),
        );
      }
      if (clientNameConflicts.ambiguousDocuments.size > 0) {
        sameRunMaps.clientsByDocument = new Map(
          [...clientNameConflicts.ambiguousDocuments].map(document => [document, SAME_RUN_AMBIGUOUS]),
        );
      }
      const importedTables = new Set(groups.map(g => g.table));

      for (const key of IMPORT_ORDER) {
        const group = groups.find(g => g.table === key);
        if (!group) continue;
        const cfg = IMPORT_SCHEMA[key];
        const cols = insertableColumns(cfg);
        const decisions = rowDecisions[key] || {};
        const gRes = {
          table: key,
          label: cfg.label,
          inserted: 0,
          updated: 0,
          ignored: 0,
          inconsistent: 0,
          ...(key === 'admissions' ? {
            clientProfilesUpdated: 0,
            responsibleClientProfilesUpdated: 0,
            titularClientProfilesUpdated: 0,
          } : {}),
          errors: [],
        };
        // Count distinct client profiles changed during this admission group, not
        // profile writes per row; role totals are distinct within each role too.
        const admissionProfileCounts = key === 'admissions'
          ? { total: new Set(), responsible: new Set(), titular: new Set() }
          : null;
        const hierarchy = getImportRowOrder(key, group.rows);

        for (const i of hierarchy.indices) {
          const { coerced, errors } = validateRowCells(group.rows[i], cfg);
          addHierarchyError(errors, hierarchy, i);
          const parentRes = await resolveParentLinks(client, cfg, coerced, sameRunMaps, importedTables);
          const rowErrors = [
            ...errors,
            ...(key === 'clients' ? (clientNameConflicts.errorsByRow.get(i) || []) : []),
            ...(key === 'admissions' ? (clientNameConflicts.admissionProfileErrorsByRow.get(i) || []) : []),
            ...parentRes.errors,
            ...await importRelationshipErrors(client, key, coerced, parentRes),
            ...(key === 'admissions'
              ? validateResolvedAdmissionProfileConflicts(coerced, parentRes.applied)
              : []),
            ...preparedRelationshipErrors(
              key, i, group.rows[i], parentRes.applied, preparedParentSnapshots, Boolean(importJobId),
            ),
          ];
          if (rowErrors.length > 0) {
            if (abortOnError) { abortReason = `${cfg.label} linha ${i + 1}: ${rowErrors.map(e => e.message).join('; ')}`; throw new Error('ABORT_IMPORT'); }
            gRes.inconsistent++;
            gRes.errors.push({ row: i + 1, errors: rowErrors.map(e => ({ column: e.column, message: e.message })) });
            continue;
          }
          Object.assign(coerced, parentRes.applied);
          if (cepAutofill && (key === 'clients' || key === 'collaborators')) {
            await enrichAddressByCep(coerced, cepCache);
          }

          const dupId = await findDuplicateId(client, key, cfg, coerced);
          if (dupId === SAME_RUN_AMBIGUOUS) {
            const error = ambiguousDuplicateError(cfg);
            if (abortOnError) {
              abortReason = `${cfg.label} linha ${i + 1}: ${error.message}`;
              throw new Error('ABORT_IMPORT');
            }
            gRes.inconsistent++;
            gRes.errors.push({ row: i + 1, errors: [error] });
            continue;
          }
          // A tabela pode ter um padrão próprio (ex: banks → 'update'); o global
          // do request serve de fallback, e decisões por linha têm prioridade máxima.
          const tableDefaultStrategy = cfg.defaultDuplicateStrategy || duplicateStrategy;
          const decision = decisions[i] || tableDefaultStrategy;

          const attemptedColumns = cols.filter(column => coerced[column] !== undefined && coerced[column] !== null);
          const savepoint = `sp_${key}_${i}`;
          try {
            await client.query(`SAVEPOINT ${savepoint}`);
            let resultId = dupId;
            let rowOutcome = null;
            let clientProfileUpdates = { changedProfiles: [] };
            if (dupId) {
              if (decision === 'ignore') {
                gRes.ignored++;
                await client.query(`RELEASE SAVEPOINT ${savepoint}`);
                registerNaturalKey(sameRunMaps, cfg, key, coerced, dupId);
                continue;
              }
              // update
              const setCols = cols.filter(c => coerced[c] !== undefined && coerced[c] !== null);
              if (setCols.length > 0) {
                const setClause = setCols.map((c, idx) => {
                  if (key === 'admissions' && c === 'unit_id') {
                    // O número do contrato é a chave de deduplicação. Permita
                    // preencher um vínculo ausente e manter o mesmo vínculo,
                    // mas não mova uma admissão vinculada a outra unidade.
                    return `${c} = CASE WHEN ${c} IS NULL OR ${c}::text = $${idx + 1}::text`
                      + ` THEN $${idx + 1} ELSE ${c} END`;
                  }
                  return `${c} = $${idx + 1}`;
                }).join(', ');
                const values = setCols.map(c => coerced[c]);
                values.push(dupId);
                await client.query(`UPDATE ${key} SET ${setClause} WHERE id = $${values.length}`, values);
              }
              rowOutcome = 'updated';
            } else {
              const insCols = cols.filter(c => coerced[c] !== undefined && coerced[c] !== null);
              if (insCols.length === 0) {
                await client.query(`ROLLBACK TO SAVEPOINT ${savepoint}`);
                if (abortOnError) { abortReason = `${cfg.label} linha ${i + 1}: nenhum campo com valor válido.`; throw new Error('ABORT_IMPORT'); }
                gRes.inconsistent++;
                gRes.errors.push({ row: i + 1, errors: [{ message: 'Nenhum campo com valor válido.' }] });
                continue;
              }
              const placeholders = insCols.map((_, idx) => `$${idx + 1}`).join(', ');
              const values = insCols.map(c => coerced[c]);
              const r = await client.query(
                `INSERT INTO ${key} (${insCols.join(', ')}) VALUES (${placeholders}) RETURNING id`,
                values
              );
              resultId = r.rows[0].id;
              rowOutcome = 'inserted';
            }
            if (key === 'admissions') {
              clientProfileUpdates = await persistAdmissionClientProfiles(
                client,
                coerced,
                parentRes.applied,
              );
            }
            if (key === 'admissions') await persistAdmissionRecalculation(client, resultId, coerced.other_info2);
            await client.query(`RELEASE SAVEPOINT ${savepoint}`);
            if (rowOutcome === 'updated') gRes.updated++;
            if (rowOutcome === 'inserted') gRes.inserted++;
            if (key === 'admissions') {
              for (const profile of clientProfileUpdates.changedProfiles) {
                admissionProfileCounts.total.add(profile.id);
                for (const role of profile.roles) admissionProfileCounts[role].add(profile.id);
              }
              gRes.clientProfilesUpdated = admissionProfileCounts.total.size;
              gRes.responsibleClientProfilesUpdated = admissionProfileCounts.responsible.size;
              gRes.titularClientProfilesUpdated = admissionProfileCounts.titular.size;
            }
            registerNaturalKey(sameRunMaps, cfg, key, coerced, resultId);
          } catch (dbErr) {
            if (dbErr.message === 'ABORT_IMPORT') throw dbErr;
            await client.query(`ROLLBACK TO SAVEPOINT ${savepoint}`);
            const context = dbErr.importContext;
            const rawDbErrors = await explainDatabaseImportError(
              client,
              context?.table || key,
              dbErr,
              context?.row || coerced,
              context?.columns || attemptedColumns,
              characterLimitCache,
            );
            const dbErrors = context?.fieldKeysByColumn
              ? rawDbErrors.map(error => ({
                ...error,
                column: context.fieldKeysByColumn[error.column] || error.column,
              }))
              : rawDbErrors;
            if (abortOnError) {
              const descriptions = dbErrors.map(error => {
                const fieldLabel = cfg.fields.find(field => field.key === error.column)?.label;
                return `${fieldLabel ? `${fieldLabel}: ` : ''}${error.message}`;
              });
              abortReason = `${cfg.label} linha ${i + 1}: ${descriptions.join('; ')}`;
              throw new Error('ABORT_IMPORT');
            }
            gRes.inconsistent++;
            gRes.errors.push({ row: i + 1, errors: dbErrors });
          }
        }

        summary.inserted += gRes.inserted;
        summary.updated += gRes.updated;
        summary.ignored += gRes.ignored;
        summary.inconsistent += gRes.inconsistent;
        summary.clientProfilesUpdated += gRes.clientProfilesUpdated || 0;
        summary.responsibleClientProfilesUpdated += gRes.responsibleClientProfilesUpdated || 0;
        summary.titularClientProfilesUpdated += gRes.titularClientProfilesUpdated || 0;
        summary.groups.push(gRes);
      }

      await client.query('COMMIT');
    } catch (txErr) {
      await client.query('ROLLBACK').catch(() => {});
      client.release();
      if (txErr.message === 'ABORT_IMPORT') {
        const preparedObjectDeleted = await deletePreparedObject();
        await finishClaimedImportJob(preparedObjectDeleted);
        return res.json({
          aborted: true,
          error: `Importação cancelada: ${abortReason}`,
          total: totalRows,
          inserted: 0, updated: 0, ignored: 0, inconsistent: 1,
          problems: [], groups: [],
        });
      }
      logger.error('[import] Erro de transação:', txErr.message);
      await restoreClaimedImportJob();
      return res.status(500).json({ error: 'Erro interno durante a importação.' });
    }
    client.release();

    try {
      await logAuditFn(pool, {
        userId: req.currentUser?.id || null,
        userName: req.currentUser?.name || 'ADMIN',
        unitId: req.currentUser?.currentUnitId,
        entityType: 'IMPORT_EXCEL',
        entityId: null,
        action: 'CREATE',
        description: `Importação Excel: ${summary.inserted} inseridos, ${summary.updated} atualizados, ${summary.ignored} ignorados, ${summary.inconsistent} inconsistentes`,
        changes: [{
          total: summary.total,
          inserted: summary.inserted,
          updated: summary.updated,
          ignored: summary.ignored,
          inconsistent: summary.inconsistent,
          tables: summary.groups.map(g => g.table),
        }],
        required: true,
      });
    } catch (auditErr) {
      logger.error('[import] Falha ao registrar auditoria:', auditErr.message);
    }

    const preparedObjectDeleted = await deletePreparedObject();
    await finishClaimedImportJob(preparedObjectDeleted);
    res.json(summary);
  });

  // ── PDF extraction via Gemini ────────────────────────────────────────────
  // POST /api/import/extract-pdf
  // Body: { table: string, pdfBase64: string, mimeType?: string }
  // Returns: { rows: Array<Record<string,unknown>>, warnings: string[] }
  //
  // Envia o PDF inline ao Gemini com um prompt estruturado baseado no
  // IMPORT_SCHEMA da tabela solicitada e parseia o JSON retornado.
  // Campos virtual:true são incluídos no prompt — o Gemini preenche o nome
  // textual; a resolução de FK fica para o /validate já existente.
  router.post('/extract-pdf', pdfExtractLimiter, async (req, res) => {
    if (!isGeminiAvailable()) {
      return res.status(503).json({ error: 'IA não disponível. Configure a integração Gemini no painel do Replit.' });
    }

    const { table, pdfBase64, mimeType = 'application/pdf' } = req.body || {};

    if (!table || typeof table !== 'string') {
      return res.status(400).json({ error: 'Campo "table" é obrigatório.' });
    }
    if (!IMPORT_SCHEMA[table]) {
      return res.status(400).json({ error: `Tabela "${table}" não reconhecida. Use GET /api/import/schema para listar as tabelas disponíveis.` });
    }
    if (!pdfBase64 || typeof pdfBase64 !== 'string') {
      return res.status(400).json({ error: 'Campo "pdfBase64" é obrigatório (PDF em base64).' });
    }
    if (mimeType !== 'application/pdf') {
      return res.status(400).json({ error: 'Apenas PDFs são aceitos (mimeType: application/pdf).' });
    }

    // Validação de tamanho: base64 ≈ 4/3 do tamanho binário; 13,6 MB base64 ≈ 10 MB PDF
    const MAX_BASE64_LENGTH = 13_600_000;
    if (pdfBase64.length > MAX_BASE64_LENGTH) {
      return res.status(413).json({ error: 'PDF muito grande. Tamanho máximo: 10 MB.' });
    }

    const cfg = IMPORT_SCHEMA[table];

    // Monta lista de campos para o prompt, incluindo virtuais
    const fieldLines = cfg.fields.map(f => {
      const parts = [`- **${f.key}** (${f.label})`, `tipo: ${f.type}`];
      if (f.required) parts.push('obrigatório');
      if (f.options)  parts.push(`opções válidas: ${f.options.join(', ')}`);
      if (f.hint)     parts.push(`dica: ${f.hint}`);
      if (f.virtual)  parts.push('preencha com o texto/nome encontrado no documento');
      return parts.join(' | ');
    }).join('\n');

    const systemPrompt =
      `Você é um assistente especializado em extração de dados estruturados de documentos para importação em sistemas de gestão financeira.\n` +
      `Analise o PDF fornecido e extraia todos os registros do tipo "${cfg.label}" encontrados.\n\n` +
      `Retorne APENAS um array JSON válido (sem markdown, sem explicações, sem texto fora do JSON).\n` +
      `Cada elemento do array deve ser um objeto com EXATAMENTE as chaves listadas abaixo.\n` +
      `Omita campos não encontrados no documento (não invente valores).\n` +
      `Para campos booleanos: use true ou false. Para datas: use o formato DD/MM/AAAA.\n` +
      `Para valores monetários: use número decimal (ex: 1500.50, não "R$ 1.500,50").\n\n` +
      `CAMPOS DISPONÍVEIS:\n${fieldLines}\n\n` +
      `Se nenhum registro for encontrado, retorne [].`;

    const userMessage = `Extraia os dados de "${cfg.label}" do PDF em anexo e retorne o JSON.`;

    const warnings = [];
    let rows = [];

    try {
      const rawText = await chat(
        systemPrompt,
        [{ role: 'user', content: userMessage }],
        8192,
        [{ type: 'pdf', data: pdfBase64 }],
      );

      // Remove markdown code fences se presentes (```json ... ```)
      const cleaned = rawText
        .replace(/^```(?:json)?\s*/i, '')
        .replace(/\s*```\s*$/, '')
        .trim();

      let parsed;
      try {
        parsed = JSON.parse(cleaned);
      } catch {
        warnings.push('O modelo retornou texto que não é JSON válido. Tente novamente ou revise o PDF.');
        logger.warn('[import/extract-pdf] Resposta do Gemini não é JSON:', cleaned.substring(0, 200));
        return res.json({ rows: [], warnings });
      }

      if (!Array.isArray(parsed)) {
        // Às vezes o Gemini retorna { data: [...] } ou similar
        if (parsed && typeof parsed === 'object') {
          const firstArray = Object.values(parsed).find(v => Array.isArray(v));
          if (firstArray) {
            parsed = firstArray;
            warnings.push('O modelo retornou um objeto em vez de array; os dados foram extraídos do primeiro campo array encontrado.');
          } else {
            warnings.push('O modelo não retornou um array de registros. Tente novamente.');
            return res.json({ rows: [], warnings });
          }
        } else {
          warnings.push('O modelo não retornou um array de registros. Tente novamente.');
          return res.json({ rows: [], warnings });
        }
      }

      // Filtra apenas chaves reconhecidas pelo schema (evita campos extras inventados)
      const validKeys = new Set(cfg.fields.map(f => f.key));
      rows = parsed.map((record, idx) => {
        if (!record || typeof record !== 'object') {
          warnings.push(`Registro ${idx + 1} ignorado: não é um objeto válido.`);
          return null;
        }
        const filtered = {};
        for (const [k, v] of Object.entries(record)) {
          if (validKeys.has(k)) filtered[k] = v;
          // Ignora chaves desconhecidas silenciosamente
        }
        return filtered;
      }).filter(Boolean);

      if (rows.length === 0 && parsed.length > 0) {
        warnings.push('Registros extraídos não tinham campos reconhecidos pelo schema desta tabela.');
      }

      logger.info(`[import/extract-pdf] table=${table} registros=${rows.length} avisos=${warnings.length}`);
      return res.json({ rows, warnings });

    } catch (err) {
      const msg = err?.message || String(err);
      logger.error('[import/extract-pdf] Erro Gemini:', msg);

      if (msg.includes('503') || msg.includes('unavailable') || msg.includes('overloaded')) {
        return res.status(503).json({ error: 'O serviço de IA está temporariamente indisponível. Tente novamente em instantes.' });
      }
      return res.status(500).json({ error: 'Erro ao processar o PDF. Tente novamente.' });
    }
  });

  return router;
}

// --- Helpers de relacionamento / agrupamento ---

function isRelated(a, b) {
  const ca = IMPORT_SCHEMA[a];
  const cb = IMPORT_SCHEMA[b];
  const aRefsB = (ca.parentLinks || []).some(l => l.parentTable === b);
  const bRefsA = (cb.parentLinks || []).some(l => l.parentTable === a);
  return aRefsB || bRefsA;
}

function normalizeGroups(groups, body) {
  // Aceita {groups:[{table,rows}]} ou o formato legado {table, rows}.
  let list = null;
  if (Array.isArray(groups)) {
    list = groups;
  } else if (body && body.table && Array.isArray(body.rows)) {
    list = [{ table: body.table, rows: body.rows }];
  }
  if (!list) return null;
  const valid = list
    .filter(g => g && IMPORT_SCHEMA[g.table] && Array.isArray(g.rows) && g.rows.length > 0)
    .map(g => ({ table: g.table, rows: g.rows }));
  return valid.length > 0 ? valid : null;
}

async function analyzeClientNameConflicts(client, groups) {
  const group = groups.find(item => item.table === 'clients');
  const errorsByRow = new Map();
  const ambiguousNames = new Set();
  const ambiguousDocuments = new Set();
  const admissionProfileErrorsByRow = new Map();
  if (!group) return { errorsByRow, ambiguousNames, ambiguousDocuments, admissionProfileErrorsByRow };

  const normalize = value => String(value ?? '').trim().toLowerCase();
  const byName = new Map();
  const byDocument = new Map();
  group.rows.forEach((row, index) => {
    const { coerced, errors } = validateRowCells(row, IMPORT_SCHEMA.clients);
    if (errors.length > 0) return;
    const name = normalize(coerced.name);
    if (!name) return;
    const document = normalizeClientDocument(coerced.document);
    if (!byName.has(name)) byName.set(name, []);
    byName.get(name).push({ index, document });
    if (document) {
      if (!byDocument.has(document)) byDocument.set(document, []);
      byDocument.get(document).push({ index, name });
    }
  });

  const existingNames = new Set();
  if (byName.size > 0) {
    const found = await client.query(
      'SELECT id, document, LOWER(BTRIM(name)) AS name_key FROM clients WHERE LOWER(BTRIM(name)) = ANY($1::text[])',
      [[...byName.keys()]],
    );
    const existingByName = new Map();
    for (const row of found.rows) {
      existingNames.add(row.name_key);
      if (!existingByName.has(row.name_key)) existingByName.set(row.name_key, []);
      existingByName.get(row.name_key).push(row);
    }
    for (const [name, existingRows] of existingByName) {
      if (existingRows.length > 1 || byName.get(name).some(entry => entry.document
        && normalizeClientDocument(existingRows[0].document) !== entry.document)) {
        ambiguousNames.add(name);
      }
    }
  }

  const addRowError = (index, message) => {
    if (!errorsByRow.has(index)) errorsByRow.set(index, []);
    errorsByRow.get(index).push({ column: 'name', message });
  };

  for (const [document, entries] of byDocument) {
    const names = new Set(entries.map(entry => entry.name));
    if (names.size < 2) continue;
    ambiguousDocuments.add(document);
    for (const entry of entries) {
      if (!errorsByRow.has(entry.index)) errorsByRow.set(entry.index, []);
      errorsByRow.get(entry.index).push({
        column: 'document',
        message: `O CPF/CNPJ "${document}" está associado a nomes diferentes na planilha. Corrija o documento ou os nomes antes de importar.`,
      });
    }
  }

  for (const [name, entries] of byName) {
    const missingEntries = entries.filter(entry => !entry.document);
    const documents = new Set(entries.map(entry => entry.document).filter(Boolean));
    if (entries.length > 1 && missingEntries.length === 0 && documents.size === entries.length) {
      // Nomes iguais são válidos quando cada pessoa tem um documento diferente.
      // O nome continua ambíguo para vínculos que não informem CPF/CNPJ.
      ambiguousNames.add(name);
      continue;
    }
    const repeatedInFile = entries.length > 1
      && (missingEntries.length > 0 || documents.size > 1);
    if (repeatedInFile) {
      ambiguousNames.add(name);
      for (const entry of entries) {
        const message = missingEntries.length > 0
          ? `O nome "${group.rows[entry.index].name}" foi repetido na planilha sem identificação suficiente. Informe CPF/CNPJ distintos ou remova as duplicidades.`
          : `O nome "${group.rows[entry.index].name}" está associado a mais de um CPF/CNPJ na planilha e não permite vincular Cliente/Titular com segurança.`;
        addRowError(entry.index, message);
      }
      continue;
    }
    if (missingEntries.length === 0) continue;
    const alreadyExists = existingNames.has(name);
    if (repeatedInFile || alreadyExists) {
      if (missingEntries.length > 1) ambiguousNames.add(name);
      for (const entry of missingEntries) {
        const message = repeatedInFile
          ? `Cliente sem CPF/CNPJ com o nome "${group.rows[entry.index].name}" repetido na planilha. Informe o documento ou remova a linha duplicada.`
          : `Já existe um cliente com o nome "${group.rows[entry.index].name}". Informe o CPF/CNPJ para evitar criar um cadastro duplicado.`;
        addRowError(entry.index, message);
      }
    }
  }

  const admissionGroup = groups.find(item => item.table === 'admissions');
  if (admissionGroup) {
    const clientRowsByName = new Map();
    group.rows.forEach((row, index) => {
      const { coerced, errors } = validateRowCells(row, IMPORT_SCHEMA.clients);
      if (errors.length > 0 || !coerced.name) return;
      const name = String(coerced.name).trim().toLowerCase();
      if (!clientRowsByName.has(name)) clientRowsByName.set(name, []);
      clientRowsByName.get(name).push({ index, coerced });
    });

    const addProfileError = (map, index, error) => {
      if (!map.has(index)) map.set(index, []);
      map.get(index).push(error);
    };
    for (const [admissionIndex, row] of admissionGroup.rows.entries()) {
      const { coerced: admission } = validateRowCells(row, IMPORT_SCHEMA.admissions);
      const profileSources = new Map();
      for (const field of IMPORT_SCHEMA.admissions.fields.filter(candidate => candidate.profileSource)) {
        const source = field.profileSource;
        if (!profileSources.has(source.nameField)) {
          profileSources.set(source.nameField, source.roleLabel);
        }
      }

      for (const [nameField, roleLabel] of profileSources) {
        const name = String(admission[nameField] ?? '').trim().toLowerCase();
        let candidates = clientRowsByName.get(name) || [];
        const documentField = nameField === 'client_name'
          ? 'client_document'
          : 'titular_client_document';
        const admissionDocument = normalizeClientDocument(admission[documentField]);
        if (admissionDocument) {
          candidates = candidates.filter(candidate =>
            normalizeClientDocument(candidate.coerced.document) === admissionDocument);
        }
        if (!name || candidates.length !== 1) continue;
        const [clientRow] = candidates;
        for (const field of IMPORT_SCHEMA.admissions.fields.filter(candidate =>
          candidate.profileSource?.nameField === nameField)) {
          const admissionValue = admission[field.key];
          const clientValue = clientRow.coerced[field.profileSource.column];
          if (admissionValue === null || admissionValue === undefined || String(admissionValue).trim() === ''
            || clientValue === null || clientValue === undefined || String(clientValue).trim() === ''
            || normalizeComparableProfileValue(admissionValue) === normalizeComparableProfileValue(clientValue)) {
            continue;
          }

          const clientField = IMPORT_SCHEMA.clients.fields.find(candidate =>
            candidate.key === field.profileSource.column);
          const detail = `O campo "${field.label}" diverge dos dados do mesmo ${roleLabel.toLowerCase()} na aba Clientes. Corrija as duas abas antes de importar.`;
          addProfileError(admissionProfileErrorsByRow, admissionIndex, {
            column: field.key,
            message: detail,
          });
          addProfileError(errorsByRow, clientRow.index, {
            column: field.profileSource.column,
            message: `O campo "${clientField?.label || field.profileSource.column}" diverge dos dados do ${roleLabel.toLowerCase()} na aba Admissões. Corrija as duas abas antes de importar.`,
          });
        }
      }
    }
  }

  return { errorsByRow, ambiguousNames, ambiguousDocuments, admissionProfileErrorsByRow };
}

function buildSameRunKeySets(groups, clientNameConflicts = null) {
  // Para validação: só consideramos "disponível no lote" uma linha-pai que
  // passaria na validação de células (espelha o que a execução realmente insere).
  // Linhas-pai inválidas não resolvem o vínculo do filho — evita preview "ok" enganoso.
  const maps = {};
  for (const g of groups) {
    const cfg = IMPORT_SCHEMA[g.table];
    if (!cfg.naturalKey) continue;
    if (!maps[g.table]) maps[g.table] = new Map();
    for (const [index, row] of g.rows.entries()) {
      const { coerced, errors } = validateRowCells(row, cfg);
      if (errors.length > 0) continue; // pai inválido não será inserido
      if (g.table === 'clients' && clientNameConflicts?.errorsByRow.has(index)) continue;
      const v = coerced[cfg.naturalKey];
      if (v !== null && v !== undefined && String(v).trim() !== '') {
        maps[g.table].set(importIdentityKey(v), SAME_RUN_PENDING);
      }
      if (g.table === 'clients' && coerced.document) {
        const documentKey = normalizeClientDocument(coerced.document);
        if (documentKey) {
          if (!maps.clientsByDocument) maps.clientsByDocument = new Map();
          const existing = maps.clientsByDocument.get(documentKey);
          if (existing && normalize(existing.name) !== normalize(coerced.name)) {
            maps.clientsByDocument.set(documentKey, SAME_RUN_AMBIGUOUS);
          } else if (existing !== SAME_RUN_AMBIGUOUS) {
            maps.clientsByDocument.set(documentKey, { id: SAME_RUN_PENDING, name: coerced.name });
          }
        }
      }
    }
  }
  if (clientNameConflicts?.ambiguousNames.size > 0) {
    if (!maps.clients) maps.clients = new Map();
    for (const name of clientNameConflicts.ambiguousNames) {
      maps.clients.set(name, SAME_RUN_AMBIGUOUS);
    }
  }
  if (clientNameConflicts?.ambiguousDocuments.size > 0) {
    if (!maps.clientsByDocument) maps.clientsByDocument = new Map();
    for (const document of clientNameConflicts.ambiguousDocuments) {
      maps.clientsByDocument.set(document, SAME_RUN_AMBIGUOUS);
    }
  }
  return maps;
}

function preparedRelationshipErrors(tableKey, rowIndex, row, resolvedParentIds, snapshots, isPreparedJob, allowPending = false) {
  if (!isPreparedJob) {
    return [];
  }

  const errors = [];
  const previewIds = snapshots?.[tableKey]?.[rowIndex] || {};
  for (const link of IMPORT_SCHEMA[tableKey]?.parentLinks || []) {
    if (String(row[link.childKey] ?? '').trim() === ''
      && String(row[link.documentChildKey] ?? '').trim() === '') continue;
    const previewId = previewIds[link.fkColumn];
    const currentId = resolvedParentIds?.[link.fkColumn];

    if (previewId === SAME_RUN_PENDING) {
      if (allowPending && currentId === SAME_RUN_PENDING) continue;
      if (currentId === null || currentId === undefined
        || currentId === SAME_RUN_PENDING || currentId === SAME_RUN_AMBIGUOUS) {
        errors.push({
          column: link.childKey,
          message: `O vínculo de "${link.label}" não foi confirmado após a prévia. Refaça a leitura da planilha.`,
        });
      }
      continue;
    }

    if (previewId === SAME_RUN_AMBIGUOUS) continue; // A resolução atual já aponta o nome ambíguo.
    if (previewId === null || previewId === undefined) {
      if (currentId !== null && currentId !== undefined) {
        errors.push({
          column: link.childKey,
          message: `O vínculo de "${link.label}" não estava resolvido na prévia. Refaça a leitura da planilha.`,
        });
      }
      continue;
    }
    if (currentId === null || currentId === undefined || String(currentId) !== String(previewId)) {
      errors.push({
        column: link.childKey,
        message: link.fkColumn === 'unit_id'
          ? 'A unidade foi alterada desde a prévia. Refaça a leitura da planilha antes de confirmar.'
          : `O vínculo de "${link.label}" mudou desde a prévia. Refaça a leitura da planilha antes de confirmar.`,
      });
    }
  }
  return errors;
}

function registerNaturalKey(sameRunMaps, cfg, table, coerced, id) {
  if (!cfg.naturalKey || !id) return;
  const v = coerced[cfg.naturalKey];
  if (v === null || v === undefined || String(v).trim() === '') return;
  if (!sameRunMaps[table]) sameRunMaps[table] = new Map();
  const key = importIdentityKey(v);
  const previous = sameRunMaps[table].get(key);
  if (previous !== SAME_RUN_AMBIGUOUS) {
    sameRunMaps[table].set(key, previous && previous !== SAME_RUN_PENDING && previous !== id
      ? SAME_RUN_AMBIGUOUS : id);
  }
  if (table === 'clients' && coerced.document) {
    const documentKey = normalizeClientDocument(coerced.document);
    if (documentKey) {
      if (!sameRunMaps.clientsByDocument) sameRunMaps.clientsByDocument = new Map();
      const current = sameRunMaps.clientsByDocument.get(documentKey);
      if (current && (current === SAME_RUN_AMBIGUOUS
        || (String(current.id) !== String(id) && normalize(current.name) !== normalize(coerced.name)))) {
        sameRunMaps.clientsByDocument.set(documentKey, SAME_RUN_AMBIGUOUS);
      } else {
        sameRunMaps.clientsByDocument.set(documentKey, { id, name: coerced.name });
      }
    }
  }
}

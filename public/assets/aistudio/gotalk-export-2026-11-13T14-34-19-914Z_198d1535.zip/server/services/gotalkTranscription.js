/**
 * Gotalk Audio Transcription Service
 * Transcribes audio messages using OpenAI Whisper API.
 */

import fs from 'fs';
import path from 'path';
import os from 'os';
import crypto from 'crypto';

// Allowed hostnames for audio URL fetching (SSRF prevention)
const ALLOWED_AUDIO_HOSTS = ['app.gotalk.digital', 'api.gotalk.digital', 'gotalk.digital'];

/**
 * Transcribe audio from a base64-encoded string (for locally stored files).
 * Does not perform any URL fetching — uses the raw audio data directly.
 */
async function transcribeAudioFromBase64(base64Data, mimeType = 'audio/webm') {
  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    console.warn('[Gotalk Transcription] OPENAI_API_KEY não configurado. Transcrição ignorada.');
    return null;
  }

  let tempFilePath = null;
  try {
    const buffer = Buffer.from(base64Data, 'base64');
    const ext = getExtFromMime(mimeType);
    tempFilePath = path.join(os.tmpdir(), `gotalk_audio_${crypto.randomUUID()}${ext}`);
    fs.writeFileSync(tempFilePath, buffer);

    const { FormData, Blob } = await import('formdata-node');
    const form = new FormData();
    const fileBlob = new Blob([fs.readFileSync(tempFilePath)], { type: mimeType });
    form.set('file', fileBlob, `audio${ext}`);
    form.set('model', 'whisper-1');
    form.set('language', 'pt');

    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${apiKey}` },
      body: form,
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenAI Whisper error ${response.status}: ${errText}`);
    }

    const data = await response.json();
    return data.text || null;
  } catch (err) {
    console.error('[Gotalk Transcription] Erro ao transcrever áudio (base64):', err.message);
    return null;
  } finally {
    if (tempFilePath) {
      try { fs.unlinkSync(tempFilePath); } catch {}
    }
  }
}

function isAllowedAudioUrl(rawUrl) {
  try {
    const { hostname } = new URL(rawUrl);
    return ALLOWED_AUDIO_HOSTS.some(h => hostname === h || hostname.endsWith(`.${h}`));
  } catch {
    return false;
  }
}

async function transcribeAudio(audioUrl, mimeType = 'audio/ogg') {
  const apiKey = process.env.OPENAI_API_KEY;

  if (!apiKey) {
    console.warn('[Gotalk Transcription] OPENAI_API_KEY não configurado. Transcrição ignorada.');
    return null;
  }

  if (!isAllowedAudioUrl(audioUrl)) {
    console.warn('[Gotalk Transcription] URL de áudio bloqueada (host não permitido):', audioUrl);
    return null;
  }

  let tempFilePath = null;

  try {
    // Download the audio file
    const audioResponse = await fetch(audioUrl);
    if (!audioResponse.ok) {
      throw new Error(`Falha ao baixar áudio: ${audioResponse.status}`);
    }

    const audioBuffer = await audioResponse.arrayBuffer();
    const ext = getExtFromMime(mimeType);
    tempFilePath = path.join(os.tmpdir(), `gotalk_audio_${crypto.randomUUID()}${ext}`);
    fs.writeFileSync(tempFilePath, Buffer.from(audioBuffer));

    // Build FormData for OpenAI Whisper
    const { FormData, Blob } = await import('formdata-node');
    const form = new FormData();
    const fileBlob = new Blob([fs.readFileSync(tempFilePath)], { type: mimeType });
    form.set('file', fileBlob, `audio${ext}`);
    form.set('model', 'whisper-1');
    form.set('language', 'pt');

    const response = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${apiKey}` },
      body: form,
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`OpenAI Whisper error ${response.status}: ${errText}`);
    }

    const data = await response.json();
    return data.text || null;
  } catch (err) {
    console.error('[Gotalk Transcription] Erro ao transcrever áudio:', err.message);
    return null;
  } finally {
    if (tempFilePath && fs.existsSync(tempFilePath)) {
      try { fs.unlinkSync(tempFilePath); } catch {}
    }
  }
}

function getExtFromMime(mimeType) {
  const map = {
    'audio/ogg': '.ogg',
    'audio/mpeg': '.mp3',
    'audio/mp4': '.m4a',
    'audio/wav': '.wav',
    'audio/webm': '.webm',
    'audio/aac': '.aac',
    'audio/opus': '.opus',
  };
  return map[mimeType] || '.ogg';
}

export { transcribeAudio, transcribeAudioFromBase64 };

# Manual funcional — Configurações

**Produto:** Meu Gestor Inteligente / FinancePro  
**Escopo:** telas e comportamentos implementados no projeto, sem dados reais de clientes.  
**Objetivo:** inventariar campos, grades/listagens, operações CRUD, modais e acionamentos.

## 1. Escopo e leitura

Foram incluídas as abas **Portal**, **Unidades**, **Auditoria**, **Central de Ajuda**, **Mensagens GoTalk** e **Histórico uazapi**. Foram excluídas a pedido: **E-mails**, **API's**, **Escala de Trabalho**, **Importação Excel**, **Fila de Importação**, **Base4/Conhecimento**, **Console SQL** e **Usuários** (incluindo Grupos de Acesso).

“Data Grid” é usado aqui como nome genérico para tabela, lista de cartões ou listagem de registros. Onde a tela não possui uma grade tabular, isso é indicado explicitamente. **CRUD** significa criar, consultar, alterar e excluir; quando a tela não permite uma dessas operações, isso também é informado. Os dados listados nas grades variam conforme o ambiente.

> **Observação de escopo:** o campo **E-mail** do cadastro de Unidade está incluído porque é dado de contato da própria unidade; a aba de configuração de envio de e-mails foi excluída.

## 2. Mapa das abas incluídas

| Aba | Finalidade | Tipo de tela | CRUD principal |
|---|---|---|---|
| Portal | Identidade visual do login e aparência interna | Formulário dividido em duas sub-abas | Consultar e alterar configurações |
| Unidades | Cadastro de filiais/unidades e integração WhatsApp/uazapi por unidade | Lista de cartões + formulário | CRUD de unidades; operações de conexão |
| Auditoria | Configurar cartões do checklist de auditoria de processos e consultar ocorrências históricas sem unidade | Lista ordenada + relatório tabular somente leitura | Criar, consultar, alterar, ativar/inativar; sem exclusão física |
| Central de Ajuda | Administrar os tópicos e artigos de ajuda | Lista pesquisável + formulário de edição | CRUD de tópicos e restauração do conteúdo padrão |
| Mensagens GoTalk | Consultar mensagens, canais, menus do chatbot e atendimentos | Tabela paginada, listas e painéis expansíveis | CRUD de canais; mensagens e menus são leitura; atendimentos permitem responder |
| Histórico uazapi | Consultar mensagens importadas da uazapi | Tabela paginada com filtros | Consulta e importação; sem edição/exclusão de mensagens pela tela |

## 3. Portal

### 3.1 Sub-aba “Login & Identidade”

#### Seção “Identidade Visual”

| Campo/controle | Conteúdo e efeito |
|---|---|
| Nome da Empresa (Título) | Texto exibido como identidade da empresa no login e no cabeçalho. |
| Cor Principal (Fundo) | Cor escolhida por seletor de cor e campo hexadecimal. A alteração sincroniza as cores de fundo do painel lateral, cabeçalho e área esquerda do login. |
| Cor do Texto | Cor escolhida por seletor e hexadecimal; sincroniza textos do painel lateral, cabeçalho e área esquerda do login. |
| Logotipo da Empresa | Upload de imagem; recomenda-se PNG com fundo transparente. A miniatura mostra a imagem atual. |
| Carregar Imagem / Trocar Imagem | Abre o seletor de arquivos de imagem. O logo é enviado/salvo imediatamente após o carregamento. |
| Remover | Remove o logo e envia a alteração imediatamente. Só aparece quando já existe logo. |
| Restaurar Padrão | Restaura nome, logo e cores de identidade para os valores padrão no estado da tela; para persistir os outros valores restaurados, usar **Salvar**. |

#### Seção “Conteúdo de Marketing”

| Campo/controle | Conteúdo e efeito |
|---|---|
| Título de Destaque | Frase principal da área de apresentação do login. |
| Texto Promocional | Texto complementar, em área de texto de várias linhas. |
| Restaurar Padrão | Recoloca título e texto padrão localmente; usar **Salvar** para persistir. |

#### Seção “Personalização de Estilo”

| Campo/controle | Conteúdo e efeito |
|---|---|
| Lado Esquerdo (Login) — Fundo | Cor de fundo do painel de apresentação do login. |
| Lado Esquerdo (Login) — Texto | Cor do texto nesse painel. |
| Imagem de Fundo | URL opcional para imagem; o botão de upload permite escolher arquivo. Quando preenchida, há prévia e controle para limpar a imagem. |
| Lado Direito (Formulário) — Fundo | Cor de fundo do painel que contém o formulário de acesso. |
| Lado Direito (Formulário) — Texto | Cor dos textos do lado do formulário. |
| Restaurar Padrão | Restaura localmente as cores e a imagem padrão dos dois lados do login; usar **Salvar** para persistir. |

#### Botões da sub-aba

- **Salvar:** registra auditoria da alteração e envia as configurações de marca/tema. Exibe confirmação de sucesso.
- **Cancelar:** pergunta se deve descartar as alterações locais; em caso afirmativo, recarrega os valores recebidos do sistema.
- **Fechar:** fecha o painel de Configurações.
- O seletor de logo e de imagem abre o diálogo nativo de arquivos do navegador; não é um modal próprio do sistema.

### 3.2 Sub-aba “Layout Interno (Dashboard)”

| Área | Campo | Efeito |
|---|---|---|
| Menu Lateral | Cor de Fundo | Cor do fundo da navegação lateral. |
| Menu Lateral | Cor do Texto | Cor dos textos e ícones da navegação; há valor visual padrão quando não informado. |
| Cabeçalho | Cor de Fundo | Cor da barra superior. |
| Cabeçalho | Cor do Texto | Cor dos textos da barra superior; há valor visual padrão quando não informado. |
| Área de Conteúdo | Cor de Fundo | Cor de fundo da área principal de trabalho. |
| Área de Conteúdo | Imagem de Fundo (URL Opcional) | Endereço opcional de imagem de fundo. |

**Salvar/Cancelar/Fechar:** têm o mesmo comportamento da sub-aba de login. Alterações nesta área são mantidas localmente até salvar, salvo quando a ação específica indicar envio imediato.

**Grade/CRUD:** não há Data Grid nem cadastro de registros nesta aba. É uma tela de configuração de propriedades visuais.

## 4. Unidades

### 4.1 Lista de unidades

A listagem é composta por **cartões**, não por uma tabela com cabeçalho. Cada cartão pode exibir:

- Razão Social;
- Nome Fantasia, quando preenchido;
- CNPJ;
- Telefone;
- E-mail de contato;
- Número WhatsApp padrão;
- Endereço resumido (logradouro/número, complemento, bairro, cidade/UF e CEP).

**Ações do cartão**

- **Histórico (ícone de relógio):** abre o histórico de auditoria do registro, quando disponível.
- **WhatsApp:** tenta conectar/reconectar a instância WhatsApp da unidade via QR Code. O sistema verifica o estado primeiro; informa se já está conectado, se falta instância configurada ou se o token é inválido.
- **Editar:** abre o formulário com os dados da unidade e carrega as instâncias uazapi existentes.
- **Duplicar:** abre formulário novo com cópia dos dados. O CNPJ fica vazio; razão social e nome fantasia recebem prefixo “Cópia de”. Credenciais uazapi não são copiadas como uma nova conexão.
- **Excluir:** exige permissão e verifica dependências. Se outro dado depender da unidade, bloqueia e informa as dependências. Caso contrário, pede confirmação e exclui sem possibilidade de desfazer.
- **Nova Unidade:** abre formulário em branco.

### 4.2 Campos do cadastro da unidade

| Campo | Conteúdo, máscara ou validação |
|---|---|
| Razão Social | Nome jurídico da unidade. |
| Nome Fantasia | Nome comercial apresentado no sistema. |
| CNPJ | Máscara de CNPJ; valida o dígito verificador quando há 14 números. Valor inválido impede salvar. |
| CEP | Máscara `00000-000`. O botão de busca consulta o CEP e preenche endereço, bairro, cidade e UF; o complemento existente é preservado. |
| Endereço | Logradouro. |
| Número | Número do endereço. |
| Complemento | Complemento do endereço. |
| Bairro | Bairro. |
| Cidade | Município. |
| Estado | Unidade federativa. |
| E-mail | E-mail de contato; formato é validado quando preenchido. Não é a configuração SMTP excluída. |
| Telefone | Telefone de contato com máscara. |
| Taxa Mínima | Valor monetário com máscara em reais. |
| Número WhatsApp padrão da unidade (com DDI e DDD) | Telefone que pode servir de referência para a integração. |

**Salvar/Cancelar:** **Salvar** valida CNPJ/e-mail, cria ou altera o registro e atualiza a lista; **Cancelar** descarta o formulário em edição. Se o CEP não for encontrado ou houver erro de conexão, o sistema apresenta aviso e permite preenchimento manual.

### 4.3 Área “WhatsApp / uazapi”

As instâncias cadastradas aparecem como cartões expansíveis com rótulo/ID e estado da conexão. Cada instância pode indicar conectada, desconectada ou erro; também pode exibir telefone e horário da conexão.

#### Campos para adicionar uma instância

| Campo | Obrigatoriedade e uso |
|---|---|
| Rótulo | Opcional; nome amigável como “Atendimento” ou “Vendas”. |
| ID da Instância | Obrigatório; identificador da instância no provedor. |
| URL do servidor uazapi | Obrigatória no formulário; exemplo apresentado: `centralhub.uazapi.com`. |
| Número WhatsApp (com DDI) | Obrigatório; usa o número digitado ou, se vazio, o número padrão da unidade. |
| Token uazapi | Obrigatório para conexão inicial; campo protegido do tipo senha. |

**Conectar instância:** valida ID, token e telefone; envia credenciais para conexão, tenta registrar webhook automaticamente e mostra sucesso/aviso/erro. O novo cadastro só fica disponível para unidades já salvas.

#### Campos para editar instância existente

- **Rótulo:** nome de exibição.
- **URL do servidor uazapi:** endereço do servidor usado pela instância.
- **Novo token:** opcional; em branco mantém o token armazenado, preenchido substitui.

#### Ações da instância

- **Conectar via QR Code / Reconectar via QR:** inicia a conexão do WhatsApp; o modal apresenta estados de carregamento, QR/código de pareamento, conexão concluída ou erro.
- **Verificar conexão:** testa/revalida credenciais e estado do provedor.
- **Salvar alterações:** salva rótulo e servidor sem alterar token quando o campo está vazio.
- **Atualizar credenciais:** salva novo token e configura os dados da instância.
- **Remover:** abre confirmação embutida “Remover esta instância permanentemente?”; **Confirmar** remove credenciais, **Cancelar** mantém. Em erro do provedor, o fluxo pode oferecer remoção forçada local.
- **Adicionar instância WhatsApp:** abre o formulário acima.

#### Modal “Conectar ao WhatsApp”

Não tem campos digitáveis: apresenta o nome/ID da instância, QR Code, eventual código de pareamento e contador de verificação. A interface instrui abrir WhatsApp > Dispositivos Vinculados > Vincular Dispositivo e ler o QR.

- **Gerar novo QR code:** reinicia a tentativa.
- **Fechar:** fecha o modal quando a conexão ainda não foi confirmada.
- Em sucesso, exibe telefone conectado e botão **Concluir**; o modal também se fecha automaticamente.
- Em erro, mostra a mensagem e opções **Fechar** e **Tentar novamente**.

#### Remoção de unidade

Há confirmação nativa do navegador com texto informando que a exclusão é irreversível. Antes dela, as dependências são verificadas; dependência existente bloqueia a exclusão.

## 5. Auditoria

### 5.1 Cartões de Auditoria de Processo

Esta parte da aba administra os itens do checklist exibidos no formulário de Auditoria de Processo. A listagem é uma sequência de cartões ordenada por número, e não um Data Grid tabular.

**Conteúdo por cartão:** número de ordem, título, descrição, condição de exibição (quando preenchida), status e ações.

**Controles da lista**

- **Mostrar inativos:** alterna entre somente itens ativos e ativos + inativos.
- **Subir/Descer:** troca a posição do item com o vizinho; indisponível nas extremidades.
- **Histórico:** abre auditoria do item.
- **Editar:** abre formulário de alteração.
- **Inativar/Ativar:** muda o status. Inativar pede confirmação; ativar grava diretamente.
- Menu **Migrar / Duplicar:** abre ações descritas abaixo.
- **Novo Item:** cria um novo item com ordem seguinte e status inicial ativo.

#### Formulário “Novo/Editar Item de Auditoria”

| Campo | Padrão/validação |
|---|---|
| Nº Ordem | Numérico, mínimo 1; novo item recebe próxima posição. |
| Status | Ativo ou Inativo; padrão Ativo em novo cadastro. |
| Título | Obrigatório; exemplo de placeholder: “Validação de Prazo (15 Dias)”. |
| Descrição | Opcional, texto multilinha. |
| Condição de Exibição (Tipo de Modalidade) | “Sempre visível (sem condição)” ou um tipo de modalidade cadastrado. Quando escolhido, só exibe o item para admissões daquela modalidade. |

**Salvar:** cria ou atualiza o item e registra auditoria. **Cancelar:** fecha o formulário sem salvar. Não há exclusão física de item no fluxo apresentado; o ciclo de remoção é substituído por inativação.

#### Modal de migração/duplicação

O menu abre um modal com as opções:

- **Trocar Posição:** requer selecionar um **Item de Destino**; troca apenas a ordem entre os dois itens.
- **Sobrescrever Dados:** requer **Item de Destino**; copia título, descrição e condição para o destino, substituindo esses dados.
- **Duplicar Item:** não pede destino; cria uma cópia no fim da sequência, com título acrescido de “(Cópia)”, mesma descrição e condição e status ativo.

Botões: **Cancelar** fecha e limpa o destino; **Confirmar** executa. Nas duas primeiras opções, Confirmar fica desabilitado sem destino. A cópia e sobrescrita mantêm o ID/status do destino apropriado, em vez de duplicar o identificador.

### 5.2 Auditorias históricas sem unidade

Painel de consulta exibido para administradores. É **somente leitura**; não corrige nem exclui registros.

**Filtro**

- **Motivo:** Todos os motivos; Identificador ausente; Identificador inválido; Entidade relacionada não encontrada; Entidade relacionada sem unidade; Unidades ambíguas; Entidade não suportada.
- A contagem de registros por motivo é mostrada junto ao item do filtro.

**Colunas da tabela**

1. Motivo;
2. Entidade / identificador;
3. Unidades candidatas;
4. Primeira observação;
5. Última observação.

**Paginação:** 25 registros por página; mostra total e controles **Anterior/Próxima**. Estados vazios informam que nenhuma auditoria histórica sem unidade foi encontrada.

> A aba atual não exibe uma grade geral de todos os eventos de auditoria. O conteúdo implementado aqui é a gestão dos cartões de checklist e esse relatório histórico de exceções. Botões de histórico em cadastros individuais são acessos contextuais, não CRUD desta aba.

## 6. Central de Ajuda

### 6.1 Lista de tópicos

A listagem mostra cada tópico como cartão com caminho do menu, título e resumo.

**Pesquisa:** procura texto em título, caminho do menu e resumo. O contador informa quantos tópicos correspondem.

**Ações:** **Editar**, **Excluir** e ícone de histórico. **Novo Tópico** abre o formulário. **Restaurar Padrão** substitui a lista personalizada pelos tópicos padrão do sistema; a implementação não pede confirmação adicional.

### 6.2 Formulário “Novo/Editar Tópico de Ajuda”

| Campo | Conteúdo |
|---|---|
| ID do Tópico | Identificador interno; editável somente ao criar. Exemplo: `fin_receber`. |
| Caminho do Menu | Caminho navegacional relacionado; exemplo: “Financeiro > Contas a Receber”. Obrigatório para salvar. |
| Título | Nome visível ao usuário. Obrigatório para salvar. |
| Resumo | Breve descrição, recomendado 1–2 frases. |
| Palavras-chave | Lista separada por vírgulas; espaços laterais são removidos e entradas vazias descartadas. |
| Conteúdo (HTML) | Corpo do artigo em HTML. |
| Pré-visualização | Quando há conteúdo, apresenta a renderização sanitizada do HTML. |

**Salvar:** cria/atualiza o tópico. Se título ou caminho do menu estiver vazio, impede a gravação e informa a validação. **Cancelar:** volta à lista sem persistir a edição. **Excluir:** remove o tópico diretamente após a checagem de permissão; a tela não apresenta modal próprio de confirmação.

**CRUD:** inclusão, consulta, alteração e exclusão de tópicos. A busca filtra a listagem, não altera os registros.

## 7. Mensagens GoTalk

Esta aba reúne quatro áreas expansíveis/funcionais: **mensagens**, **canais configurados**, **menus do chatbot** e **histórico de atendimentos**.

### 7.1 Grade de mensagens

**Filtros** (painel abre pelo botão **Filtros**):

- Canal (aparece quando há mais de um canal);
- Atendente / Operador;
- Contato / Cliente;
- Telefone;
- Direção: entrada/recebidas ou saída/enviadas.

Cada filtro é aplicado com pequeno atraso após a digitação/seleção; há chips para remover um filtro e **Limpar tudo** para zerar todos. **Atualizar** recarrega a consulta.

**Colunas**

| Coluna | Comportamento |
|---|---|
| Data/Hora | Ordenável crescente/decrescente. |
| Direção | Ordenável; identifica entrada ou saída. |
| Telefone | Ordenável; clicar no número abre histórico daquele telefone. |
| Contato | Ordenável; mostra cliente e, quando diferente, nome do contato. |
| Operador | Ordenável; departamento aparece como informação complementar. |
| Tipo | Ordenável; identifica tipo de mensagem. |
| Conteúdo | Prévia de texto, transcrição de áudio ou nome do anexo. |
| Ações | Abre detalhes da mensagem. |

**Paginação:** 50 mensagens por página. Na ordenação padrão mais recente primeiro, mensagens do mesmo dia podem ser agrupadas por contato/horário. A primeira página é atualizada automaticamente a cada minuto. Mensagens são somente leitura nessa grade; ações permitem consultar detalhes e mídia, não criar/alterar/excluir mensagens.

### 7.2 Modal “Detalhes da mensagem”

Exibe nome/contato/telefone, data e hora, direção, tipo e estado de leitura. Quando houver os dados, mostra:

- Telefone;
- Contato / Cliente;
- Operador;
- Departamento;
- Leitura (data/hora ou “Não lida”);
- Mídia/anexo com pré-visualização e opção de baixar, se aplicável;
- Conteúdo textual completo, ou transcrição de áudio, quando disponível.

**Fechar:** botão, clique fora do conteúdo ou tecla Esc.

### 7.3 Modal “Histórico do número”

Abre ao clicar em um telefone na grade. Mostra conversas em sequência, direção, tipo, operador, data/hora, mídia/texto e departamento quando disponível. Pagina 50 mensagens por vez; cada mensagem tem ação para abrir o modal de detalhes. Permite carregar mensagens anteriores/próximas e informa o total.

**Fechar:** botão no cabeçalho, clique no fundo ou Esc. O modal de detalhe pode ser aberto sobre o histórico e fechado para voltar ao histórico.

### 7.4 Canais configurados

Painel expansível; ao abrir, carrega os canais existentes. A tabela contém:

| Coluna | Conteúdo/ação |
|---|---|
| Nome | Nome do canal e notas, se houver. |
| Telefone | Número WhatsApp do canal. |
| Unidade | Unidade vinculada ou “—”. |
| Tipo | Principal ou Secundário. |
| Ativo | Alternador para ativar/desativar. |
| Ações | Editar e Remover. |

#### Cadastro “Adicionar canal”

| Campo | Padrão/validação |
|---|---|
| Nome do canal | Obrigatório. |
| Telefone (WhatsApp) | Opcional. |
| Unidade | Opcional; opção padrão “Sem unidade”. |
| Notas | Opcional. |
| Canal principal | Checkbox, padrão desmarcado. |
| Ativo | Checkbox, padrão marcado. |

**Salvar canal** cria o canal; **Cancelar** limpa e fecha o formulário. O campo de nome vazio impede salvar.

#### Edição inline

Campos: **Nome***, **Telefone**, **Unidade**, **Notas**, checkbox **Canal principal** e checkbox **Ativo**. **Salvar** grava alterações; **Cancelar** sai do modo de edição sem gravar.

#### Outras ações dos canais

- **Ativar/Desativar:** altera o status ativo sem abrir formulário.
- **Remover:** pergunta “Remover o canal ‘…’? Esta ação não pode ser desfeita.”; confirmando, exclui.
- **Detectar canal primário:** consulta o canal da conta GoTalk. Se encontrar canal ainda não cadastrado, preenche sugestão e abre o formulário para revisão/confirmação; se já estiver cadastrado, recarrega a lista.
- **Sincronizar todos:** procura canais e dados pendentes; canais encontrados que não estejam cadastrados aparecem como sugestões, cada uma com **Adicionar** ou **Dispensar sugestões**. Não grava cada sugestão sem confirmação.
- **Recarregar:** busca novamente a lista de canais.

### 7.5 Menus do Chatbot

Painel expansível **somente leitura**. Apresenta menus com nome/título, descrição e quantidade de opções. Ao expandir um menu, mostra as opções em árvore; cada opção pode exibir nome/título, descrição, ação e opções-filhas. **Recarregar menus** atualiza o conteúdo. Se a consulta falhar, **Tentar novamente** repete a carga. Não há operações CRUD nessa tela.

### 7.6 Histórico de Atendimentos GoTalk

Painel expansível com filtro de tipo **Todos / Cliente / Banco** e filtro **Unidade** (quando a tela é geral). Lista paginada, 20 atendimentos por página, com:

- contato/cliente/telefone;
- operador e colaborador, se vinculados;
- departamento ou assunto;
- status e tipo;
- data/hora de início;
- quantidade de mensagens e horário da última mensagem.

Ao selecionar um atendimento, abre a conversa (não um modal): permite voltar à lista, carrega mensagens por lotes de até 100 e exibe mídia, transcrições e templates. Atendimentos encerrados são somente leitura. Em atendimento aberto, com telefone e identificador GoTalk disponíveis, a caixa **Responder no atendimento...** envia texto; Enter envia e Shift+Enter insere linha. Se não houver canal GoTalk ativo, o envio é desabilitado e um aviso é exibido.

#### Modal “Enviar Template HSM”

Aparece em atendimento aberto com telefone:

- **Canal WhatsApp:** canais ativos; seleciona automaticamente o principal ou o primeiro canal ativo;
- **Template:** modelos disponíveis para o canal escolhido;
- **Variáveis do template:** um campo por marcador `{{n}}` detectado no corpo do template; todos precisam ser preenchidos para liberar envio;
- cabeçalho, corpo e rodapé são usados para a prévia/renderização quando disponíveis.

**Enviar:** dispara a mensagem/template para o contato; mostra erro ou confirmação de sucesso e fecha automaticamente após sucesso. Atalho Ctrl/⌘+Enter também envia. **Fechar** interrompe o modal.

## 8. Histórico uazapi

### 8.1 Importação do histórico

**Importar Histórico Completo** inicia a importação do histórico disponível na instância uazapi. Enquanto estiver em execução, o botão fica desabilitado e a tela mostra:

- chats processados / total de chats;
- mensagens inseridas;
- barra de progresso quando o total permite calcular percentual;
- eventual último erro.

Após concluir, exibe data/hora de início e total inserido, além de aviso se houve erro. A tela consulta o estado da importação periodicamente enquanto ela está ativa. Essa função é diferente da aba excluída “Fila de Importação”.

### 8.2 Filtros

| Campo | Valores/uso |
|---|---|
| Número | Busca por telefone; placeholder de exemplo `11999...`. |
| Direção | Todas, Recebidas ou Enviadas. |
| Instância | Filtra por ID da instância. |
| De | Data inicial. |
| Até | Data final. |

**Filtrar** aplica os valores e volta à primeira página. **Limpar** remove todos os filtros e consulta novamente. O total de resultados é exibido ao lado dos controles.

### 8.3 Grade de mensagens importadas

Tabela somente leitura, com 50 mensagens por página:

1. **Data/Hora** do envio;
2. **Número**;
3. **Dir.** — recebida ou enviada;
4. **Tipo** de mensagem;
5. **Mensagem** — texto truncado ou nome do anexo; também pode indicar encaminhamento, estrela ou reação;
6. **Unidade**;
7. **Instância**;
8. **Importado em**.

**Paginação:** Anterior/Próxima, com número da página. Mensagens podem ser consultadas após importação; não há edição, exclusão ou modal de detalhes nesta aba.

## 9. Referência resumida de modais e confirmações

| Tela/ação | Tipo | Dados ou escolhas | Resultado |
|---|---|---|---|
| Logo/imagem de fundo do Portal | Seletor de arquivo do navegador | Arquivo de imagem | Carrega a imagem selecionada; o logo salva imediatamente, as demais opções dependem de Salvar. |
| Excluir Unidade | Confirmação nativa + validação prévia | Confirmar/cancelar | Exclui somente se não houver dependências. |
| Conectar WhatsApp/uazapi | Modal de estado | QR, código opcional, estado e nova tentativa | Conecta a instância ou apresenta erro. |
| Remover instância uazapi | Confirmação embutida | Cancelar/Confirmar | Remove credenciais locais e, quando possível, encerra a sessão do provedor. |
| Migrar/Duplicar item de auditoria | Modal de operação | Tipo de operação; destino para troca/sobrescrita | Troca ordem, copia dados para destino ou cria cópia nova. |
| Excluir tópico de ajuda | Sem modal próprio | Não há campos adicionais | Remove o tópico após validação de permissão. |
| Restaurar Ajuda padrão | Sem modal próprio | Nenhum | Substitui os tópicos configurados pelos padrões. |
| Remover canal GoTalk | Confirmação nativa | Confirmar/cancelar | Exclui o canal. |
| Detalhes da mensagem GoTalk | Modal de consulta | Informações da mensagem e mídia | Fecha e retorna à lista/histórico. |
| Histórico por telefone | Modal de consulta | Telefone fixo; mensagens paginadas | Permite consultar e abrir detalhes das mensagens. |
| Enviar Template HSM | Modal de envio | Canal, template e variáveis `{{n}}` | Envia o template para o contato e informa sucesso/erro. |

## 10. Observações sobre permissões e persistência

- As abas Portal, Unidades, Auditoria e Central de Ajuda dependem das permissões correspondentes do usuário.
- A aba Mensagens GoTalk e o Histórico uazapi dependem da permissão de integração/API; essa permissão não altera o escopo desta documentação.
- Ações de gravação exibem mensagens de sucesso/erro. Em telas com dados somente leitura, a interface não oferece CRUD de registros.
- Não foram inventados campos que não apareçam na interface analisada. Campos protegidos, como tokens, são descritos pelo papel e comportamento, sem incluir valores de credenciais.

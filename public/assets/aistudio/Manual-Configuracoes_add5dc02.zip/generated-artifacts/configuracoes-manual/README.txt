DOCUMENTAÇÃO DA OPÇÃO CONFIGURAÇÕES

Abra o arquivo manual-configuracoes.md em qualquer editor de texto que suporte
Markdown. O manual descreve as telas, campos, grades/listagens, operações CRUD,
modais e ações observadas na implementação do projeto.

ESCOPO INCLUÍDO
- Portal
- Unidades
- Auditoria
- Central de Ajuda
- Mensagens GoTalk
- Histórico uazapi

ESCOPO EXCLUÍDO A PEDIDO
- E-mails e API's
- Escala de Trabalho
- Importação Excel e Fila de Importação
- Base4 / Base de Conhecimento
- Console SQL
- Usuários (incluindo Grupos de Acesso)

Observação: o campo de e-mail de contato da unidade continua documentado, pois
faz parte do cadastro da unidade e não da aba E-mails.

O documento descreve os controles implementados na interface do projeto.
Registros, nomes e dados exibidos dependem da instalação e da conexão com os
serviços correspondentes. A auditoria de telas foi feita pelo código-fonte;
não foi usada uma sessão autenticada da aplicação.

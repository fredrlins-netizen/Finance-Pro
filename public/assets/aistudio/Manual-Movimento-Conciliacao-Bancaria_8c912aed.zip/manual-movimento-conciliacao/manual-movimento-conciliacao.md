# Financeiro > Conta Corrente

## Manual detalhado de Movimento e Conciliação Bancária

### Escopo e método

Relação das telas **Financeiro → Conta Corrente → Movimento** e **Financeiro → Conta Corrente → Conciliação Bancária**, com seus campos, opções, grades, CRUD, modais, padrões, integrações e relacionamentos.

O levantamento foi realizado no código disponível nesta sessão. Não houve autenticação, consulta a dados reais, criação/edição/exclusão de registros, importação de extratos, conciliação ou operação bancária. As limitações descritas são achados de código, não falhas reproduzidas em uma sessão real.

**Termos usados**

- **Padrão:** valor atribuído na abertura da tela/formulário; não descreve dados da empresa.
- **Crédito:** entrada; o valor armazenado é positivo, separado do tipo.
- **Débito:** saída; o sinal é apresentado visualmente, separado do valor armazenado.
- **Status:** campo PENDENTE/CONCILIADO.
- **Marca de conciliação:** campo lógico `reconciled`; não é necessariamente igual ao status.
- **Extrato importado:** linhas do arquivo mantidas no estado local da tela.
- **Movimento do sistema:** registro persistido na API de movimentações.
- **CRUD:** criar, consultar, alterar e excluir.

## 1. Visão geral e navegação

| Caminho | Título | Função |
|---|---|---|
| Financeiro → Conta Corrente → Movimento | Movimentação Bancária | Consultar entradas/saídas, saldos, registrar lançamentos, depósitos, saques e transferências; editar/excluir movimentos não vinculados. |
| Financeiro → Conta Corrente → Conciliação Bancária | Conciliação Bancária | Importar extrato e comparar com registros internos, marcar/desfazer conciliação e criar/editar movimentos. |

As duas opções usam as contas cadastradas em **Conta Corrente → Cadastro** e classificações do **Plano de Contas**. Não são telas de acesso direto à instituição bancária.

## 2. Movimento — todas as áreas da tela

### 2.1 Barra de ações

| Controle | Estado inicial / acionamento | Resultado |
|---|---|---|
| Mostrar Filtros / Ocultar Filtros | Filtros começam recolhidos | Alterna a exibição dos campos de filtro. Recolher não apaga filtros ativos. |
| Depósito | Clique | Abre modal Depósito com campos reinicializados. |
| Saque | Clique | Abre modal Saque com campos reinicializados. |
| Transferência | Clique | Abre Transferência entre Contas. |
| Novo Lançamento | Clique | Abre formulário modal de lançamento genérico. |

### 2.2 Conta e saldo de cabeçalho

| Campo / informação | Padrão | Funcionamento |
|---|---|---|
| Conta Corrente | Todas as Contas | Lista descrições das contas recebidas, sem filtro local explícito por status. Selecionar restringe a grade e o cálculo de saldo à conta. |
| Saldo Atual da Conta / Saldo Total (Todas as Contas) | Calculado sobre os movimentos carregados | Soma saldo inicial da conta e créditos menos débitos de todo o conjunto carregado para a conta. Sem conta selecionada, soma o resultado das contas cadastradas. |

Esse saldo de cabeçalho **não é restringido pelos filtros de período, tipo, origem, status e texto**. Também não é consulta on-line ao banco nem simples leitura do saldo atual armazenado no cadastro.

### 2.3 Indicadores e rodapé

| Informação | Regra |
|---|---|
| Total Entradas | Soma dos créditos do conjunto filtrado. |
| Total Saídas | Soma dos débitos do conjunto filtrado. |
| Saldo Período | Saldo inicial da conta (ou soma dos saldos iniciais) + entradas filtradas − saídas filtradas. |
| Quantidade de movimentos | Número de linhas após filtros. |
| Totais no rodapé | Repete entradas, saídas e saldo do período. |

**Distinção:** Saldo Período não calcula explicitamente o saldo de abertura na data inicial usando todos os movimentos anteriores; a fórmula parte do saldo inicial cadastrado. Não confundir esse indicador com extrato bancário acumulado oficial.

### 2.4 Todos os filtros

| Campo | Padrão | Opções / comportamento |
|---|---|---|
| De | Primeiro dia do mês atual | Limite inicial inclusivo pela data do movimento. |
| Até | Último dia do mês atual | Limite final inclusivo. |
| Tipo | Todos | Todos, Crédito, Débito. |
| Origem | Todos | Todos, Baixa Receber, Baixa Pagar, Manual, Tarifa, Transferência, Depósito, Saque. |
| Status | Todos | Todos, Conciliado, Pendente; usa o campo status. |
| Pesquisar | Vazio | Trecho de descrição ou documento, sem distinguir maiúsculas/minúsculas. |

Filtros são locais sobre o conjunto recebido; não há botão Aplicar/Limpar Todos. Alterar o valor reflete no conjunto exibido. Por padrão, o período do mês já filtra a grade mesmo com o painel recolhido.

## 3. Movimento — Data Grid e ações

### 3.1 Todas as colunas

| Coluna | Conteúdo | Ordenação |
|---|---|---|
| Data | Data em formato brasileiro | Sim |
| Descrição | Texto; símbolo de vínculo se há título e origem do título | Sim |
| Documento | Número ou “-” | Sim |
| Origem | Etiqueta Recebimento, Pagamento, Manual, Tarifa, Transferência, Depósito ou Saque | Sim, pelo código interno |
| Entrada | Valor dos créditos | Sim |
| Saída | Valor dos débitos com indicação negativa | Sim |
| Saldo Acumulado | Saldo após o movimento na sequência cronológica do conjunto da conta | Não |
| Status | Conciliado ou Pendente, conforme campo status | Sim |
| Ações | Editar, Excluir, Ver título quando integrado e Auditoria | Não |

- Padrão de ordenação: data crescente.
- Clicar no mesmo cabeçalho alterna crescente/decrescente; outro cabeçalho inicia crescente.
- Cabeçalhos ordenáveis também respondem a Enter/Espaço.
- A grade usa virtualização de linhas e rolagem; isso não é paginação nem carregamento de todas as páginas da API.
- Não há checkbox, edição em célula, duplicação, exclusão em lote, importação ou exportação nesta grade.
- Vazio: **“Nenhuma movimentação encontrada para o período selecionado.”**
- A conta não aparece como coluna; em Todas as Contas as linhas de várias contas são combinadas.

### 3.2 Saldo acumulado

É calculado a partir do saldo inicial e de todos os movimentos carregados da conta, em ordem cronológica, **antes** dos filtros de período/tipo/origem/status/texto. Cada linha conserva esse valor mesmo se o usuário ordenar a exibição por descrição ou valor.

Sem conta selecionada, usa a soma dos saldos iniciais e a sequência combinada dos movimentos carregados. Empates de data não têm uma ordenação secundária de horário definida nesse cálculo local.

### 3.3 Vínculo com título

- Em Movimento, o bloqueio visual considera a presença de **titleId e titleSource**.
- Com vínculo: os botões de editar/excluir abrem explicação de bloqueio, não permitem alteração direta pela grade.
- Sem vínculo: editar abre o modal; excluir abre confirmação.
- Não há bloqueio de edição/exclusão baseado apenas em status Conciliado nessa grade.
- A descrição pode oferecer navegação para o título quando existe a função de navegação do componente.
- **Condição atual do Hub:** a montagem examinada não repassa `onViewTitle` ao componente de Movimento. Portanto, o botão Ver Título e a navegação por clique na linha não estão efetivamente disponibilizados por essa montagem, embora o componente tenha o recurso condicional.

### 3.4 Destaque de um movimento

Ao receber um ID destacado de um fluxo financeiro, a grade tenta rolar até a linha após breve espera e marca-a em azul temporariamente, limpando o destaque após cerca de quatro segundos. Não limpa automaticamente filtros para revelar uma linha que esteja fora do conjunto exibido.

## 4. Movimento — modal Novo Lançamento / Editar Lançamento

### 4.1 Campos completos e padrões de inclusão

| Campo | Controle / opções | Padrão novo | Regras e efeito |
|---|---|---|---|
| Conta Corrente | Lista de contas | Conta do filtro; sem seleção específica, primeira da lista | Obrigatória. A marca Conta Padrão do cadastro não é procurada. |
| Data | Data | Data ISO/UTC do momento da abertura | Obrigatória. |
| Tipo | Crédito (Entrada), Débito (Saída) | Débito | Trocar limpa a categoria e refaz as opções. |
| Valor (R$) | Máscara monetária brasileira | 0,00 | Deve ser maior que zero. |
| Nº Documento | Texto | Vazio | Opcional; não é o tipo documental. |
| Descrição | Texto | Vazio | Obrigatória; sugestão visual “Ex: Tarifa bancária mensal”. |
| Categoria | Lista do Plano de Contas | Sem seleção | Obrigatória; mostra código e nome. Apenas analíticas: Receita para Crédito, Despesa para Débito. |
| Origem | Manual, Tarifa, Transferência | Manual | Classificação; escolher Transferência aqui não cria o segundo movimento. |
| Status | Conciliado, Pendente | Pendente | Altera somente status no payload desse modal; não preenche explicitamente marca/data de conciliação. |

Organização: **Dados do Lançamento** (conta, data, tipo, valor, documento, descrição) e **Classificação** (categoria, origem e status).

### 4.2 Edição e opções legadas

O modal de edição carrega os valores do registro, mantendo o ID. Depósito/Saque podem ser editados pelo fluxo genérico se não houver título; porém, o seletor Origem não oferece DEPOSITO/SAQUE, embora o valor existente possa ser carregado. Não confundir ausência da opção na lista com um formulário dedicado de edição dessas operações.

**Campos não expostos:** tipo de documento, portador, departamento, centro de custo, ID do título, origem do título, marca/data de conciliação, data de compensação e ID de transferência. Alguns existem no modelo/API, mas não têm controles aqui.

### 4.3 Salvar e fechar

- Valida conta, data, descrição, valor positivo e categoria.
- Novo: solicita criação e registra auditoria; não espera a conclusão assíncrona do callback antes de fechar e mostrar sucesso.
- Editar: espera a atualização; mostra indicador de salvamento e desabilita Salvar. Em falha, informa **“Não foi possível atualizar o lançamento.”**
- Cancelar, X ou clique no fundo fecha sem salvar.
- Não há confirmação de alterações não salvas.
- Ctrl+Enter/Command+Enter registra a ação de salvar para esse modal. Não há Escape implementado pelo contexto geral examinado.

**Aviso:** o fechamento e a mensagem de sucesso em inclusão não comprovam, isoladamente, persistência no servidor.

## 5. Movimento — modal Depósito

### 5.1 Todos os campos

| Campo | Padrão | Opções / efeito |
|---|---|---|
| Conta | Primeira conta da lista | Lista de contas; não usa obrigatoriamente a conta do filtro nem a marca padrão. Obrigatória. |
| Data | Data ISO/UTC atual | Obrigatória. |
| Valor (R$) | 0,00 | Máscara monetária; maior que zero. |
| Descrição | Vazio | Obrigatória. |
| Categoria (Plano de Contas) | Sem seleção | Opcional; apenas receitas analíticas. |
| Status | Pendente | Conciliado ou Pendente. |

### 5.2 Acionamentos e dados gerados

- **Registrar Depósito:** cria um movimento CREDITO, origem DEPOSITO, com conta/data/valor/descrição/categoria/status informados.
- Sem categoria, o componente envia identificador vazio; aceitação pode depender da validação de referências do servidor.
- Não há campo de documento, portador ou data de compensação.
- Cancelar/X fecha. Clique no fundo não possui ação de fechamento nesse modal.
- Não transfere dinheiro para a conta real.
- Se não há histórico carregado ou a data é anterior ao primeiro movimento da conta, apresenta **“Saldo Inicial Atualizado”**. Contudo, o método apenas cria o movimento; não altera explicitamente `initialBalance`. O Hub examinado atualiza saldo atual da configuração após a criação, não o saldo inicial. A mensagem não comprova alteração efetiva do saldo inicial.
- Não aguarda a conclusão do callback de criação antes de fechar e anunciar sucesso.

## 6. Movimento — modal Saque

| Campo | Padrão | Opções / efeito |
|---|---|---|
| Conta | Primeira conta da lista | Obrigatória. |
| Data | Data ISO/UTC atual | Obrigatória. |
| Valor (R$) | 0,00 | Obrigatório e positivo. |
| Descrição | Vazio | Obrigatória. |
| Categoria (Plano de Contas) | Sem seleção | Opcional; apenas despesas analíticas. |
| Status | Pendente | Conciliado ou Pendente. |

- **Registrar Saque:** cria DEBITO, origem SAQUE.
- Não existe validação explícita de saldo suficiente no método do formulário.
- Cancelar/X fecha; fundo não fecha.
- As mesmas ressalvas do depósito se aplicam à categoria vazia, confirmação assíncrona e aviso de “Saldo Inicial Atualizado”.
- Não efetua saque em banco ou caixa eletrônico.

## 7. Movimento — modal Transferência entre Contas

| Campo | Padrão | Opções / efeito |
|---|---|---|
| Conta de Origem (Débito) | Primeira conta | Obrigatória. |
| Conta de Destino (Crédito) | Sem seleção | Lista exclui origem; obrigatória e diferente da origem. |
| Data | Data ISO/UTC atual | Obrigatória. |
| Valor (R$) | 0,00 | Obrigatório e positivo. |
| Descrição | Vazio | Obrigatória. |
| Categoria (Plano de Contas — opcional) | Sem seleção | Oferece despesas analíticas; a mesma categoria é copiada para ambos os movimentos. |
| Status | Pendente | Conciliado ou Pendente, copiado aos dois movimentos. |

**Confirmar Transferência**

1. Valida origem, destino diferente, data, descrição e valor.
2. Gera um identificador comum de transferência.
3. Solicita débito na origem e crédito no destino, no mesmo valor.
4. Registra auditoria agregada da transferência.
5. Fecha e mostra mensagem de dois lançamentos criados.

**Limites observados**

- São duas chamadas independentes de criação; o componente não espera ambas nem usa uma operação atômica única. A mensagem não garante sucesso conjunto das duas pernas.
- Não há validação local de saldo suficiente.
- O vínculo é por `transferId`; não por título financeiro.
- A grade oferece edição/exclusão individual de movimento sem título, sem ação específica para alterar/excluir o par inteiro.
- Mudar origem no formulário genérico para Transferência cria apenas um movimento; use o modal dedicado para solicitar o par.
- Trocar a conta de origem muda as opções de destino, mas não limpa explicitamente o destino já selecionado; a validação rejeita origem=destino ao confirmar.
- Cancelar/X fecha; clique no fundo não fecha.
- Não executa TED, DOC, Pix ou transferência bancária externa.

## 8. Movimento — demais modais

### 8.1 Lançamento Vinculado

Abre ao tentar editar/excluir linha que possui título e origem do título.

**Conteúdo**

- Título “Lançamento Vinculado”.
- Explica que o movimento veio de baixa em Contas a Receber/Pagar.
- Campos de leitura: descrição, data e valor.
- Orienta localizar o título e cancelar a baixa para remover o lançamento.
- **Entendido** ou clique no fundo fecha.
- **Ver Título** só aparece quando a função de navegação é fornecida; não é repassada na montagem do Hub examinada.

Não contém campos editáveis, confirmação de exclusão ou cancelamento da baixa dentro do modal.

### 8.2 Confirmar Exclusão

Abre pelo botão Excluir em movimento não bloqueado.

- Mostra descrição, data, Entrada/Saída e valor.
- Avisa que a exclusão é permanente e não pode ser desfeita.
- **Cancelar:** fecha sem excluir.
- **Excluir:** solicita remoção pelo ID, mostra indicador e bloqueia os botões enquanto espera.
- Sucesso: registra auditoria e fecha; falha: informa **“Não foi possível excluir o lançamento.”**
- Não há fechamento por clique no fundo implementado nesse modal.
- Excluir um lado de transferência não solicita automaticamente exclusão do outro.

### 8.3 Histórico de Movimentações — auditoria

Acionado pelo relógio da linha; consulta eventos pelo ID do movimento, não extrato do banco.

| Coluna | Conteúdo |
|---|---|
| Data/Hora | Momento do evento |
| Usuário | Responsável |
| Ação | Tipo de operação |
| Campo | Campo alterado |
| De | Valor anterior |
| → | Separador |
| Para | Valor novo ou descrição |

- Somente leitura; sem criar/editar/excluir eventos ou restaurar dados.
- Solicita até 500 eventos e ordena do mais recente para o mais antigo.
- Cada campo alterado pode gerar uma linha; contador de eventos pode diferir da quantidade de linhas.
- Paginação de 15 linhas, Anterior/Próxima.
- Estados de carregamento e ausência de movimentação registrada.
- Fechar/X/fundo encerra; contador pode mostrar 99+ após carga.
- A auditoria agregada da transferência usa o ID da transferência; o relógio de cada perna consulta o ID do movimento. Esse evento agregado não é automaticamente o mesmo histórico de cada linha.

## 9. Conciliação Bancária — estado inicial e cabeçalho

Sem conta selecionada, mostra **“Selecione uma Conta Corrente”**. As duas grades e barra de operações ficam disponíveis após escolher uma conta.

| Campo | Padrão | Efeito |
|---|---|---|
| Conta Corrente | Sem seleção | Opções mostram descrição e, quando presentes, agência e conta. Determina movimentos do sistema. |
| Período De | Vazio | Filtra as duas grades a partir da data. |
| Período Até | Vazio | Filtra as duas grades até a data. |
| Data Conciliação | Data ISO/UTC atual | Usada ao marcar movimentos conciliados. |
| Data Compensação | Vazio | Opcional no estado da tela; veja ressalva de persistência na seção 15. |

Não há filtros de texto, valor, tipo ou status nessa tela. Não há botão Aplicar: as datas atualizam a visualização local.

**Troca de conta:** o manipulador apenas altera o ID selecionado. Não limpa explicitamente extrato importado, marcações ou seleções já realizadas. Não presuma que o arquivo foi validado como pertencente à nova conta.

## 10. Conciliação — barra de operações

| Ação | Disponibilidade / resultado |
|---|---|
| Importar Extrato | Com conta selecionada; abre seletor de arquivo. Não é modal de mapeamento. |
| Novo Lançamento | Quando o callback de inclusão está disponível; na montagem examinada está fornecido. |
| Nome do arquivo e quantidade de linhas | Após seleção de arquivo; nome é definido antes de terminar a análise. Não é comprovante isolado de importação bem-sucedida. |
| Limpar | Limpa extrato local, nome do arquivo e seleção de linhas do extrato. Não exclui movimentos do sistema. |
| Auto-Conciliar | Procura pares por data/tipo/valor, sem confirmação adicional. |
| Conciliar (N) | Habilitado quando existe seleção em pelo menos uma grade. N soma itens dos dois lados; não significa N pares. |

Não há exportação de resultado, botão de salvar arquivo conciliado ou histórico de lotes nessa tela.

## 11. Importação do extrato — formatos e todos os campos

### 11.1 Formatos

- **OFX:** aceito e processado no navegador.
- **XLSX:** aceito, analisado com ExcelJS; usa somente a primeira planilha.
- **XLS:** aparece na aceitação do seletor e em texto de tela, mas o tratamento rejeita o formato antigo e orienta salvar como XLSX.
- Outros formatos: mensagem de que apenas XLSX ou OFX são suportados.
- Sem assistente de mapeamento, escolha de planilha, upload para armazenamento ou consulta bancária automática.
- Importação bem-sucedida substitui as linhas locais anteriores, não acrescenta um lote ao anterior.
- Não existe criação automática de movimentos a partir de cada linha importada.
- Reimportar não possui deduplicação persistente contra arquivos anteriores.

### 11.2 XLSX — reconhecimento de cabeçalhos

Primeira linha contém cabeçalhos; reconhecimento por trechos em minúsculas.

| Dado | Trechos reconhecidos |
|---|---|
| Data | data, date |
| Descrição | descri, hist, memo, description |
| Valor único | valor, value, amount, quantia |
| Crédito | crédit, credit, entrada |
| Débito | débit, debit, saída, saida |
| Documento | doc, número, numero |

**Formato recomendado:** Data, Descrição, Valor, Documento; valores positivos para crédito e negativos para débito. Alternativamente, colunas Crédito e Débito separadas.

**Interpretação**

- Se existem ambas as colunas Crédito e Débito, elas prevalecem sobre Valor. Crédito positivo tem prioridade; caso contrário usa débito positivo.
- Com Valor único, guarda o módulo; sinal não negativo = crédito, negativo = débito.
- Documento é opcional e fica no registro importado, mas não é coluna das grades de conciliação.
- Data aceita célula Date, número serial Excel ou texto com DD/MM/AAAA; outros textos são mantidos como vieram, sem um validador completo de datas nessa etapa.
- Números de células são preferíveis para valores. O parser textual troca vírgula por ponto sem remover de forma completa pontos de milhar: não se deve garantir leitura correta de texto “1.234,56”.
- Fórmulas com resultado armazenado e rich text têm tratamento de texto para descrição/valores; data e cabeçalho têm lógica própria.
- Só ignora a linha quando o valor é zero e a data também está vazia. Não há validação estrita de todos os campos antes de listar linhas.
- Planilha sem pelo menos duas linhas: aviso de arquivo vazio/dados insuficientes.
- Falha de análise: mensagem de erro com a causa capturada.

### 11.3 OFX — campos reconhecidos

| Tag / dado | Uso |
|---|---|
| STMTTRN | Delimita cada transação |
| DTPOSTED | Data; usa os oito primeiros caracteres como AAAAMMDD |
| TRNAMT | Valor; sinal determina crédito/débito, módulo é armazenado |
| MEMO | Primeira opção de descrição |
| NAME | Descrição alternativa quando não há MEMO |
| TRNTYPE | Alternativa de descrição quando faltam MEMO/NAME |
| CHECKNUM | Número do documento, opcional |
| FITID | Identificador local da transação quando disponível |

Sem descrição disponível usa “Sem descrição”. Valores não numéricos são ignorados. Não há validação explícita de instituição, agência, conta ou moeda do arquivo contra a conta escolhida; não há reconciliação por saldo oficial do OFX.

### 11.4 Persistência do extrato

As linhas e marcas de extrato são mantidas no estado React da tela, não gravadas em uma entidade de extrato nesse fluxo. Limpar ou desmontar/sair do componente pode perdê-las. Um status de conciliado à esquerda não é prova de um registro persistido de correspondência no servidor.

## 12. Conciliação — as duas Data Grids

### 12.1 Extrato Bancário, lado esquerdo

| Coluna | Conteúdo / acionamento |
|---|---|
| Seleção | Checkbox em pendentes; em conciliados, ícone para Desconciliar |
| Data | Data formatada |
| Descrição | Texto truncado; descrição completa no título ao passar o mouse |
| Valor | Crédito positivo; débito com sinal negativo |
| Tipo | C ou D |
| Status | Pendente/Conciliado conforme `matched` local |

- Cabeçalho mostra quantidade filtrada.
- Checkbox do cabeçalho seleciona/desmarca as linhas pendentes do extrato no conjunto filtrado.
- Não há editar data/valor/descrição, excluir linha individual ou criar movimento por clique na linha.
- Desconciliar à esquerda apenas remove a marca local do extrato e a referência local de par; não desfaz o movimento à direita.
- Sem arquivo, solicita importar extrato; com arquivo e filtro sem linhas, avisa ausência no período.
- Sem ordenação interativa/paginação; mantém ordem importada.

### 12.2 Movimentos do Sistema, lado direito

Mesmas colunas: seleção, data, descrição, valor, tipo e status.

- Somente movimentos da conta escolhida, filtrados pelo período e ordenados por data crescente.
- Seleção de cabeçalho considera os não conciliados por `reconciled`.
- Conciliados mostram botão Desconciliar e, quando há, data de conciliação sob o status.
- **Duplo clique** abre edição quando o callback está disponível.
- Se há `titleId`, a tentativa de edição avisa para cancelar a baixa em Receber/Pagar; a verificação aqui usa apenas o ID do título, diferentemente da grade Movimento.
- Não há botão Excluir, auditoria por linha, documento, origem ou categoria como colunas.
- Estado vazio: nenhum movimento para conta/período.
- Sem ordenação interativa/paginação.

### 12.3 Totais de cada grade

| Total | Extrato | Sistema |
|---|---|---|
| Entradas | Créditos filtrados | Créditos filtrados da conta |
| Saídas | Débitos filtrados | Débitos filtrados da conta |
| Saldo Movimentado | Entradas − saídas | Entradas − saídas |
| Saldo Conciliado | Soma com sinais dos `matched` locais | Soma com sinais dos movimentos com `reconciled` |

Não incluem saldo inicial da conta. O código não calcula um campo “diferença entre lados” nem bloqueia a operação quando os totais divergem. A formatação de totais negativos deve ser conferida no uso real, pois o formatador compartilhado não preserva o sinal em todas as formas de entrada.

## 13. Conciliar manualmente

1. Selecionar conta.
2. Importar extrato se desejar comparar os dois lados.
3. Marcar linhas do extrato, movimentos do sistema ou itens em ambos.
4. Informar Data Conciliação; Data Compensação é opcional.
5. Clicar **Conciliar (N)**.

**Validações**

- Exige pelo menos um item selecionado em qualquer lado.
- Exige Data Conciliação não vazia.
- Não exige um item de cada lado.
- Não compara igualdade de valores, datas, tipos ou totais.
- Não cria uma associação par-a-par explícita na conciliação manual.

**Efeitos**

- Marca linhas do extrato como `matched = true`, localmente.
- Para movimentos selecionados define `reconciled = true`, status CONCILIADO, data de conciliação e compensação no objeto local.
- Solicita atualização no Hub e auditoria por movimento.
- Limpa as seleções e mostra quantidade de itens conciliados.
- Não espera a conclusão das atualizações do Hub antes de mostrar sucesso; ver seção 15 sobre persistência.

Não há modal de prévia nem confirmação adicional.

## 14. Auto-Conciliar e Desconciliar

### 14.1 Critérios automáticos

Exige linhas importadas e movimentos disponíveis da conta. Para cada linha ainda não marcada, procura o primeiro movimento:

- Não conciliado por `reconciled`.
- Ainda não utilizado nessa execução do automático.
- **Mesma data exata.**
- **Mesmo tipo** Crédito/Débito.
- **Diferença absoluta de valor menor que 0,02.**

Não utiliza documento, descrição, FITID, nome do banco ou saldo como critério. Não há tolerância de dias nem pareamento por soma de vários registros.

**Aplicação**

- Marca par no extrato com ID do movimento.
- Atualiza movimentos correspondentes para conciliados, usando as datas da tela, e solicita auditoria.
- Mostra quantidade de pares identificados.
- Não há prévia/aceitação individual dos pares.
- Usa todas as linhas importadas, mas os movimentos candidatos já estão filtrados por conta/período. Assim, o recorte dos dois lados no algoritmo não é implementado exatamente pela mesma lista filtrada.
- Diferentemente do manual, o método automático não valida explicitamente se Data Conciliação está vazia antes de executar.

### 14.2 Desconciliar movimento

Botão de check verde na linha da direita:

- Solicita `reconciled = false` e status PENDENTE.
- Tenta retirar datas no objeto local.
- Solicita auditoria e informa “Movimento marcado como pendente.”
- Não exclui movimento, não cancela baixa e não desmarca automaticamente uma linha do extrato.
- Não pede confirmação.

### 14.3 Desconciliar linha do extrato

Check verde à esquerda:

- Marca `matched = false` e remove referência local do movimento.
- Informa “Lançamento do extrato desmarcado.”
- Não atualiza o movimento do sistema correspondente.
- Não pede confirmação e não persiste uma alteração de extrato no servidor.

## 15. Persistência, status e limites importantes da conciliação

### 15.1 Status não é a mesma coisa que marca

- Movimento exibe o campo **status**.
- Conciliação exibe a condição **reconciled**.
- O modal de lançamento permite selecionar Conciliado, mas seus payloads não preenchem explicitamente `reconciled`, data de conciliação ou compensação.
- Por isso, selecionar status Conciliado no lançamento não garante que a outra tela mostrará a mesma marca de conciliação.
- Conciliar/Desconciliar define status e marca juntos no objeto local; persistência depende do callback.

### 15.2 O que o Hub encaminha

O callback examinado compara movimentos anteriores e atualizados. Só solicita atualização quando status ou `reconciled` mudou. Envia:

- status;
- reconciled;
- reconciliationDate.

**Data Compensação não é encaminhada por esse callback**, embora exista no formulário, no objeto local, na auditoria e na API. Não se deve prometer persistência desse campo por esse caminho.

Alterar apenas data de conciliação/compensação sem mudar status/marca também não satisfaz o critério de envio do callback.

Ao desfazer, as datas são atribuídas como `undefined` no objeto local; a serialização JSON pode omitir essas propriedades. Não está garantida a limpeza da data já armazenada no servidor por esse mecanismo.

### 15.3 Confirmações e seleção

- O componente de conciliação não espera o callback do Hub antes da mensagem de sucesso.
- O Hub trata erros por movimento no console e continua as demais atualizações; não apresenta nesse caminho um resumo de falhas ao usuário.
- Trocar conta, filtro ou importar outro arquivo não limpa de forma geral todos os IDs selecionados. Revise seleções antes de executar; não se deve garantir que a mudança de filtro descarte itens antes marcados.
- Checkbox “selecionar todos” alterna com base na quantidade selecionada comparada à quantidade pendente, e não por comparação completa de todos os IDs.
- Não existe lote transacional único para marcar/desmarcar todos os movimentos nesse fluxo.

## 16. Conciliação — modal Novo/Editar Lançamento

### 16.1 Abertura

- Novo Lançamento abre inclusão na conta selecionada.
- Duplo clique em movimento do sistema abre edição; título vinculado impede a abertura e mostra aviso.
- Cabeçalho mostra Novo/Editar Lançamento e descrição da conta selecionada.
- Não há seletor de conta dentro do modal; a conta é carregada pelo contexto/registro.

### 16.2 Todos os campos

| Campo | Padrão na inclusão | Opções / regra |
|---|---|---|
| Data * | Data ISO/UTC atual | Obrigatória. |
| Tipo * | Saída (Débito) | Saída (Débito) ou Entrada (Crédito); trocar limpa categoria. |
| Valor * | 0,00 | Maior que zero. Digitação aceita dígitos e vírgula, e formata ao sair do campo. |
| Descrição * | Vazio | Obrigatória. |
| Nº Documento | Vazio | Opcional. |
| Status | Pendente | Pendente ou Conciliado. |
| Categoria * | Sem seleção | Analítica de Despesa para Débito ou Receita para Crédito; mostra código e nome. |

**Campos de contexto, sem controle:** conta; origem MANUAL na inclusão ou origem existente na edição. Não há seletor de origem, portador, departamento, centro de custo, tipo de documento, data de compensação ou referência ao extrato nesse modal.

### 16.3 Ações

- Salvar valida conta do contexto, data, descrição, valor positivo e categoria.
- Edição espera API; mostra Salvando... e bloqueia Salvar/Cancelar enquanto espera.
- Inclusão chama callback sem esperar o resultado antes de fechar e anunciar sucesso.
- Cancelar fecha. Não há X nem fechamento por fundo implementados nesse modal.
- Não registra o atalho de salvar no contexto da mesma forma que o modal de Movimento.
- Criar por esse modal não vincula automaticamente a nova linha a uma transação importada nem a marca como conciliada com o extrato.

## 17. Relacionamentos, API e integrações

### 17.1 Conta bancária e saldos

- Movimentos guardam ID da conta; seletores usam descrição da configuração.
- A API valida referência à conta relacional.
- Contas recém-salvas apenas na configuração podem depender da sincronização relacional existente no projeto; os seletores não comprovam que toda referência será aceita.
- No Hub, após criar movimento, tenta somar crédito ou subtrair débito no saldo atual da configuração da conta.
- A gravação dessa configuração exige administrador na rota de seção; a criação do movimento tem caminho próprio.
- Editar/excluir movimento no Hub atualiza a API/lista, sem a mesma atualização explícita de saldo configurado nessas funções.
- A tela Movimento calcula seu saldo por saldo inicial + lançamentos carregados; isso pode diferir da coluna Saldo Atual do cadastro.

### 17.2 Plano de Contas

- Vínculo por `categoryId`, com nome copiado para `categoryName`.
- Seletores genéricos: receitas analíticas para crédito e despesas analíticas para débito.
- Depósito: receita analítica opcional. Saque: despesa analítica opcional.
- Transferência dedicada usa lista de despesas analíticas e repete a categoria nos dois lados.
- Escolher categoria não cria conta no plano nem operação fiscal/contábil externa.

### 17.3 Títulos financeiros e baixas

- `titleId` e `titleSource` identificam vínculo com Receber/Pagar.
- Origens BAIXA_RECEBER e BAIXA_PAGAR são apresentadas como Recebimento/Pagamento na grade.
- Alteração/exclusão direta na grade é bloqueada quando o vínculo visual está completo.
- Orientação do modal: cancelar a baixa no título original.
- A conciliação pode marcar o movimento vinculado como conciliado sem editar seus dados de valor/conta pelo modal.
- O bloqueio visual encontrado não é, sozinho, comprovação de regra equivalente em toda rota de servidor; não houve teste de segurança ou perfil.

### 17.4 Referências adicionais

O modelo/API de movimentos admite:

| Campo | Relação / uso | Campo editável nos modais descritos? |
|---|---|---|
| bankAccountId | Conta bancária | Sim em Movimento; implícito na Conciliação |
| categoryId / categoryName | Plano de contas | Sim |
| documentNumber | Nº de documento | Sim no genérico, não nos rápidos |
| documentTypeId | Tipo de documento | Não |
| bearerId | Portador | Não |
| departmentId | Departamento | Não |
| costCenterId | Centro de custo | Não |
| titleId / titleSource | Título e origem Receber/Pagar | Não |
| transferId | Par de transferência | Gerado pelo fluxo dedicado |
| reconciled | Marca interna | Ações de conciliação, não campo do modal genérico |
| reconciliationDate | Data de conciliação | Cabeçalho da Conciliação |
| compensationDate | Data de compensação | Cabeçalho da Conciliação; limitação no encaminhamento pelo Hub |

Departamentos, tipos de documento e portadores são recebidos como propriedades por Movimento, mas não possuem seletores no modal atual. Não listar esses vínculos de modelo como campos visíveis.

### 17.5 API e carga

- Movimentos são carregados/criados/alterados/excluídos na rota `/api/bank-movements`.
- API aceita tipos CREDITO/DEBITO, status CONCILIADO/PENDENTE e origens definidas.
- Requer conta, data, descrição, valor e tipo na criação; o formulário genérico acrescenta exigência local de categoria/valor positivo.
- API rejeita valor negativo; o tipo representa o sentido financeiro.
- Referências de conta/categoria/tipo de documento/portador/departamento/título são validadas quando fornecidas.
- **Limite de carga:** o Hub solicita página com 5.000 movimentos, mas o validador geral da API limita cada resposta a **500**. As duas telas não apresentam paginação para percorrer todas as páginas desse conjunto.
- Assim, filtros, saldos, seleção e auto-conciliação operam sobre o que foi efetivamente carregado, não comprovadamente todo o histórico.
- A virtualização da grade Movimento não resolve a ausência de carregamento das páginas seguintes.
- O Hub habilita atualização por invalidação de dashboard para Movimento; a lista de telas dessa inscrição não inclui Conciliação no trecho examinado. Não se deve prometer atualização automática idêntica entre as duas telas.

### 17.6 Permissões e integrações externas

- Os componentes consultados não fazem verificações explícitas por ação com `validarPermissao` nos botões de movimento/conciliação. Navegação, sessão e servidor podem ter outras restrições; não foram testadas por perfil.
- Não há conexão direta com banco, Open Finance, Pix, TED, remessa CNAB, consulta bancária de saldo, envio de e-mail ou WhatsApp nessas ações.
- A integração de extrato é leitura de arquivo local; não transmissão ou autenticação bancária.
- Auditoria registra operações, mas não é recibo de persistência bancária externa.

## 18. Matriz de CRUD e operações

| Operação | Movimento | Extrato na Conciliação | Movimentos na Conciliação |
|---|---|---|---|
| Criar lançamento | Sim, genérico e rápidos | Importa linhas locais; não cria movimento automaticamente | Sim, Novo Lançamento |
| Consultar | Grade, filtros, saldos e auditoria | Grade e totais | Grade e totais |
| Alterar dados | Modal, se não bloqueado por título | Não | Duplo clique, se não vinculado |
| Excluir | Confirmação, se não bloqueado | Limpar todo extrato local, não excluir linha individual | Não há ação Excluir |
| Conciliar / desfazer | Status editável não equivale à marca | Marca local e desfazer local | Manual, automático e desfazer |
| Seleção múltipla | Não | Sim, pendentes | Sim, não conciliados |
| Importar arquivo | Não | OFX/XLSX | Não importa diretamente movimentos |
| Exportar | Não | Não | Não |
| Auditoria por botão | Sim | Não | Não há botão nessa grade |
| Paginação visual | Não | Não | Não |

## 19. Roteiros de acionamento

### Registrar lançamento

Movimento → Novo Lançamento → conta → data → tipo → valor → documento opcional → descrição → categoria → origem/status → Salvar. Tipo exige reescolher categoria. Status Conciliado não é garantia de `reconciled` marcado.

### Registrar depósito ou saque

Movimento → Depósito/Saque → conferir conta (primeira da lista, não necessariamente filtro) → data, valor positivo, descrição → categoria opcional → status → Registrar. Acompanhar atualização efetiva da lista; sucesso visual é anterior à confirmação do callback nesse fluxo.

### Transferir

Transferência → origem → destino diferente → data/valor/descrição → categoria opcional/status → Confirmar Transferência. Solicita dois registros internos independentes; não é operação bancária externa.

### Editar/excluir

Editar/lixeira na linha. Se vinculado ao título, abre orientação para agir no título original; se livre, abre edição ou confirmação de exclusão. Excluir é permanente; transferência não tem exclusão automática de par.

### Conciliar manual

Conciliação → selecionar conta → importar extrato se necessário → filtrar período → selecionar itens → Data Conciliação → Conciliar (N). A aplicação não exige que os dois lados tenham o mesmo total.

### Conciliar automaticamente

Selecionar conta → importar XLSX/OFX → conferir datas da tela → Auto-Conciliar. Critério: mesma data/tipo e diferença menor que dois centavos; não usa descrição/documento.

### Desfazer

Check verde no lado desejado → remove a marca daquele lado. Não existe desfazer simultâneo garantido dos dois lados.

## 20. Fontes e limites finais

Código conferido:

- `components/financeiro/BankMovementManager.tsx`: grade, filtros, saldos, CRUD e modais.
- `components/financeiro/BankReconciliationManager.tsx`: importação, duas grades, seleção, conciliação e modal.
- `components/financeiro/FinancialPanel.tsx`: callbacks de persistência, carga, saldos e montagem.
- `utils/ofxParser.ts`: interpretação OFX.
- `utils/currencyUtils.ts` e `components/ui/Input.tsx`: moeda e máscara.
- `components/ui/AuditLogButton.tsx`: histórico em modal.
- `server/routes/bankMovements.js`, `server/routes/crudFactory.js` e `server/middleware/validation.js`: campos/referências, CRUD e limite de página.
- `contexts/KeyboardShortcutContext.tsx`: atalho de salvar.

Os modais e telas foram documentados a partir do código, sem alterar o aplicativo para corrigir limites identificados. Este pacote não contém extratos, dados reais, credenciais ou cópia de banco de dados.

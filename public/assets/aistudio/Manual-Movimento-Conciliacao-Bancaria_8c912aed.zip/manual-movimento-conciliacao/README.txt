FINANCEIRO > CONTA CORRENTE
MOVIMENTO E CONCILIAÇÃO BANCÁRIA

Abra manual-movimento-conciliacao.html para ler no navegador ou imprimir.
A versão Markdown também está incluída.

O manual cobre telas, campos, filtros, totais, grades, CRUD, todos os modais
identificados, importação XLSX/OFX, conciliação manual/automática/desfazer,
valores padrão, integrações, relacionamentos e limites observados no código.

Base: código disponível nesta sessão. Não houve autenticação, consulta a dados
reais, alteração de movimentos, conciliação, importação ou operação bancária.
Os padrões descritos são de abertura dos formulários, não registros da empresa.

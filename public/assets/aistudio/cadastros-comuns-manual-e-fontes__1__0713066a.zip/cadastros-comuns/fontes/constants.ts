/**
 * TÍTULO: CONSTANTES E DADOS INICIAIS
 */

import React from 'react';
import { PortalConfig, UserGroup, User, UserRole, MenuItem, Client, Collaborator, Bank, ServiceItem, Appointment, AgendaConfig, Modality, Product, MeasurementUnit, Series, Admission, DocumentType, Bearer, FinancialAccount, Department, BankAccount, AuditCheckItem, FormContextDefinition } from './types';

// --- MENU STRUCTURE DEFINITION ---
export const APP_MENU_STRUCTURE: MenuItem[] = [
  { 
    id: 'home',
    label: 'Home', 
  },
  {
    id: 'agenda',
    label: 'Agenda',
  },
  { 
    id: 'cadastros',
    label: 'Cadastros Comuns',
    subItems: [
        { id: 'cad_clientes', label: 'Clientes' },
        { id: 'cad_cargos', label: 'Cargos' },
        { id: 'cad_colaboradores', label: 'Colaboradores' },
        { id: 'cad_departamentos', label: 'Departamentos' },
        { id: 'cad_bancos', label: 'Bancos' },
        { id: 'cad_modalidades', label: 'Modalidades' },
        { id: 'cad_produtos', label: 'Produtos' },
        { id: 'cad_series', label: 'Série/Números' }
    ]
  },
  { 
    id: 'atendimento',
    label: 'Atendimento', 
    subItems: [
        { 
          id: 'comercial', 
          label: 'Comercial',
          subItems: [
            { id: 'com_prospeccao', label: 'Prospecção' },
            { id: 'com_admissao', label: 'Admissão' },
            { id: 'com_negociacao', label: 'Negociação' }
          ]
        },
        { id: 'auditoria', label: 'Auditoria' },
        { id: 'juridico', label: 'Jurídico' }
    ]
  },
  {
    id: 'acomp_juridico',
    label: 'Acompanhamento Jurídico',
    subItems: [
        { id: 'jur_dashboard', label: 'Dashboard' },
        { id: 'jur_processos', label: 'Processos' },
        { id: 'jur_prazos', label: 'Prazos e Audiências' }
    ]
  },
  { 
    id: 'financeiro',
    label: 'Financeiro',
    subItems: [
        { 
          id: 'fin_cadastros', 
          label: 'Cadastros',
          subItems: [
            { id: 'fin_fornecedores', label: 'Fornecedores' },
            { id: 'fin_tipo_documento', label: 'Tipo Documento' },
            { id: 'fin_portador', label: 'Portador' },
            { id: 'fin_plano_contas', label: 'Plano de Contas' }
          ]
        },
        { 
          id: 'fin_conta_corrente', 
          label: 'Conta Corrente',
          subItems: [
            { id: 'fin_cc_cadastro', label: 'Cadastro' },
            { id: 'fin_cc_movimento', label: 'Movimento' },
            { id: 'fin_cc_conciliacao', label: 'Conciliação Bancária' }
          ]
        },
        { id: 'fin_receber', label: 'Contas a Receber' },
        { id: 'fin_pagar', label: 'Contas a Pagar' },
        { id: 'fin_gerenciamento', label: 'Gerenciamento' }
    ]
  },
  { id: 'fin_cobranca', label: 'Cobrança', subItems: [
      { id: 'fin_cob_coordenador', label: 'Coordenadores' },
      { id: 'fin_cob_operacional', label: 'Operacionais' }
  ] },
  { id: 'fin_negociacao', label: 'Negociação' },
  { 
    id: 'relatorios',
    label: 'Relatórios',
    subItems: [
        { id: 'rel_consultas', label: 'Consultas' },
        { id: 'rel_formularios', label: 'Formulários' },
        { id: 'rel_gerais', label: 'Relatórios Gerais' }
    ]
  },
  {
    id: 'ia_analise',
    label: 'IA & Análise',
    subItems: [
      { id: 'ia_chat', label: 'Chat com Léo IA' },
      { id: 'ia_dados', label: 'Analisar Dados' },
      { id: 'ia_relatorios', label: 'Resumo de Relatórios' },
      { id: 'ia_auditoria', label: 'Auditoria IA' },
    ]
  },
  {
    id: 'mensagens',
    label: 'Mensagens',
  },
  {
    id: 'conversas',
    label: 'Conversas WhatsApp',
  },
  { 
    id: 'settings',
    label: 'Configurações',
    subItems: [
      { id: 'settings_portal', label: 'Portal (Aparência)', hidden: true },
      { id: 'settings_units', label: 'Gestão de Unidades', hidden: true },
      { id: 'settings_users', label: 'Gestão de Usuários', hidden: true },
      { id: 'settings_emails', label: 'Configuração de E-mail', hidden: true },
      { id: 'settings_api', label: 'Integrações (API)', hidden: true },
      { id: 'settings_audit', label: 'Auditoria (Configuração)', hidden: true },
      { id: 'settings_import', label: 'Importação Excel', hidden: true },
      { id: 'settings_help', label: 'Central de Ajuda', hidden: true }
    ]
  },
];

// --- FORM CONTEXT REGISTRY ---
// Define quais rotinas/módulos podem utilizar formulários e como.
// Para adicionar suporte a um novo módulo: basta incluir uma nova entrada aqui.
// O FormsBuilder e o FormTemplateButton lerão este registro automaticamente.
export const FORM_CONTEXT_REGISTRY: FormContextDefinition[] = [
    {
        menuId: 'com_admissao',
        label: 'Admissão',
        module: 'Comercial',
        targetTypes: ['modal', 'grid'],
        entityType: 'admission',
        availableVariablePrefixes: ['cliente', 'admissao', 'banco', 'colaborador', 'empresa', 'modalidade', 'recalculo', 'serie', 'geral'],
        description: 'Formulários disponíveis na tela de Admissão (grid e modal de detalhes)'
    },
    {
        menuId: 'com_negociacao',
        label: 'Negociação Comercial',
        module: 'Comercial',
        targetTypes: ['modal', 'grid'],
        entityType: 'negotiation',
        availableVariablePrefixes: ['cliente', 'colaborador', 'empresa', 'geral'],
        description: 'Formulários disponíveis na tela de Negociação Comercial'
    },
    {
        menuId: 'cad_clientes',
        label: 'Clientes',
        module: 'Cadastros',
        targetTypes: ['modal', 'grid'],
        entityType: 'client',
        availableVariablePrefixes: ['cliente', 'empresa', 'geral'],
        description: 'Formulários disponíveis no cadastro de Clientes'
    },
    {
        menuId: 'cad_colaboradores',
        label: 'Colaboradores',
        module: 'Cadastros',
        targetTypes: ['modal'],
        entityType: 'collaborator',
        availableVariablePrefixes: ['colaborador', 'empresa', 'geral'],
        description: 'Formulários disponíveis no cadastro de Colaboradores'
    },
    {
        menuId: 'juridico',
        label: 'Jurídico',
        module: 'Atendimento',
        targetTypes: ['modal', 'grid'],
        entityType: 'legal',
        availableVariablePrefixes: ['cliente', 'colaborador', 'empresa', 'geral'],
        description: 'Formulários disponíveis na tela Jurídica'
    },
    {
        menuId: 'fin_receber',
        label: 'Contas a Receber',
        module: 'Financeiro',
        targetTypes: ['grid'],
        entityType: 'financial_receivable',
        availableVariablePrefixes: ['cliente', 'empresa', 'portador', 'tipo_documento', 'geral'],
        description: 'Formulários disponíveis na tela de Contas a Receber'
    },
    {
        menuId: 'fin_pagar',
        label: 'Contas a Pagar',
        module: 'Financeiro',
        targetTypes: ['grid'],
        entityType: 'financial_payable',
        availableVariablePrefixes: ['empresa', 'portador', 'tipo_documento', 'geral'],
        description: 'Formulários disponíveis na tela de Contas a Pagar'
    },
    {
        menuId: 'fin_negociacao',
        label: 'Negociação Financeira',
        module: 'Financeiro',
        targetTypes: ['modal', 'grid'],
        entityType: 'financial_negotiation',
        availableVariablePrefixes: ['cliente', 'empresa', 'geral'],
        description: 'Formulários disponíveis na tela de Negociação Financeira'
    },
    {
        menuId: 'fin_cob_coordenador',
        label: 'Cobrança - Coordenadores',
        module: 'Financeiro',
        targetTypes: ['grid'],
        entityType: 'collection',
        availableVariablePrefixes: ['cliente', 'colaborador', 'admissao', 'empresa', 'geral'],
        description: 'Formulários disponíveis na visão de Coordenadores de Cobrança'
    },
    {
        menuId: 'fin_cob_operacional',
        label: 'Cobrança - Operacional',
        module: 'Financeiro',
        targetTypes: ['grid'],
        entityType: 'collection',
        availableVariablePrefixes: ['cliente', 'colaborador', 'admissao', 'empresa', 'geral'],
        description: 'Formulários disponíveis na visão Operacional de Cobrança'
    },
    {
        menuId: 'auditoria',
        label: 'Auditoria',
        module: 'Atendimento',
        targetTypes: ['modal', 'grid'],
        entityType: 'audit',
        availableVariablePrefixes: ['cliente', 'admissao', 'banco', 'colaborador', 'empresa', 'geral'],
        description: 'Formulários disponíveis no painel de Auditoria'
    },
    {
        menuId: 'jur_processos',
        label: 'Acomp. Jurídico - Processos',
        module: 'Acompanhamento Jurídico',
        targetTypes: ['grid', 'modal'],
        entityType: 'company_legal_process',
        availableVariablePrefixes: ['cliente', 'empresa', 'colaborador', 'processo', 'geral'],
        description: 'Formulários disponíveis na gestão de Processos Judiciais da Empresa'
    },
];

const DEFAULT_COMPANY_INFO = {
  id: '1',
  razaoSocial: 'FinancePro Assessoria Ltda',
  cnpj: '00.000.000/0001-91',
  telefone: '(11) 3000-0000',
  email: 'contato@financepro.com',
  cep: '01001-000',
  endereco: 'Praça da Sé',
  numero: '100',
  complemento: '1º Andar',
  bairro: 'Sé',
  cidade: 'São Paulo',
  estado: 'SP'
};

const DEFAULT_USER_GROUPS: UserGroup[] = [
  {
    id: 'g1',
    name: 'Administradores',
    permissions: [
      'home', 'agenda', 'cadastros', 'cad_clientes', 'cad_cargos', 'cad_colaboradores', 'cad_bancos', 'cad_modalidades', 'cad_produtos', 'cad_series',
      'atendimento', 'comercial', 'com_admissao', 'com_negociacao', 'auditoria', 'juridico', 
      'financeiro', 'fin_cadastros', 'fin_fornecedores', 'fin_tipo_documento', 'fin_portador', 'fin_plano_contas', 'fin_conta_corrente', 'fin_cc_cadastro', 'fin_cc_movimento', 'fin_cc_conciliacao', 'fin_receber', 'fin_pagar', 'fin_gerenciamento', 'fin_cobranca', 'fin_cob_coordenador', 'fin_cob_operacional', 'fin_negociacao',
      'cad_departamentos',
      'relatorios', 'rel_consultas', 'rel_formularios', 'rel_gerais',
      'ia_analise', 'ia_chat', 'ia_dados', 'ia_relatorios', 'ia_auditoria',
      'mensagens', 'conversas',
      'settings', 'settings_portal', 'settings_units', 'settings_users', 'settings_emails', 'settings_api', 'settings_audit', 'settings_import', 'settings_help',
      'INCLUIR', 'ALTERAR', 'EXCLUIR', 'VALIDATE'
    ]
  },
  {
    id: 'g2',
    name: 'Atendentes',
    permissions: ['home', 'agenda', 'atendimento', 'cadastros', 'cad_clientes']
  }
];

const DEFAULT_USERS: User[] = [
  {
    id: 'admin-01',
    name: 'Master',
    email: 'master@invicta.com.br',
    role: UserRole.ADMIN,
    status: 'ATIVO',
    allowedUnitIds: ['1'],
    groupIds: ['g1']
  }
];

const DEFAULT_SERIES: Series[] = [
    { id: 's1', sigla: 'CONTR', description: 'Contratos de Assessoria', generalNumber: 150, unitNumbering: [] },
    { id: 's2', sigla: 'PROCUR', description: 'Procurações Judiciais', generalNumber: 85, unitNumbering: [] }
];

// --- MOCK CLIENTS ---
const MOCK_CLIENTS: Client[] = [
  {
    id: '1001',
    name: 'CARLOS ALBERTO DE NOBREGA',
    type: 'FISICA',
    document: '123.456.789-00',
    rg: '12.345.678-9',
    phone: '(11) 98888-7777',
    isWhatsapp: true,
    email: 'carlos.alberto@gmail.com',
    profession: 'Aposentado',
    maritalStatus: 'Casado(a)',
    birthDate: '1955-03-12',
    cep: '01001-000',
    address: 'RUA DAS FLORES',
    number: '450',
    complement: 'APT 12',
    district: 'CENTRO',
    city: 'SÃO PAULO',
    state: 'SP',
    notes: 'Cliente prioritário, negociação de dívida de cartão.'
  },
  {
    id: '1002',
    name: 'TRANSPORTES RAPIDÃO LTDA',
    type: 'JURIDICA',
    document: '00.111.222/0001-33',
    phone: '(11) 3333-4444',
    email: 'contato@rapidao.com.br',
    cep: '04555-000',
    address: 'AVENIDA PAULISTA',
    number: '1500',
    complement: '15º ANDAR',
    district: 'BELA VISTA',
    city: 'SÃO PAULO',
    state: 'SP',
    notes: 'Empresa com 3 veículos em busca e apreensão.'
  }
];

// --- MOCK ADMISSIONS ---
const MOCK_ADMISSIONS: Admission[] = [
    {
        id: 'adm-01',
        date: new Date().toISOString(),
        clientId: '1001',
        clientName: 'CARLOS ALBERTO DE NOBREGA',
        bankId: '3001',
        collaboratorId: '2001',
        seriesId: 's1',
        modalityId: 'm1',
        contractNumber: '151',
        totalInstallments: '48',
        paidInstallments: '12',
        overdueInstallments: '0',
        financedAmount: '50000.00',
        installmentValue: '1500.00',
        dueDay: '10',
        paymentType: 'BOLETO BANCÁRIO',
        indicationType: 'REDE_SOCIAL',
        status: 'APROVADA', 
        recalcScenarios: [
            { id: 'sc-1', label: 'Recálculo %', installmentsToPay: '36', originalDebt: '54000.00', installmentValue: '1100.00', newDebt: '39600.00', savings: '14400.00', dueDay: '10' },
            { id: 'sc-2', label: 'Recálculo %', installmentsToPay: '36', originalDebt: '54000.00', installmentValue: '900.00', newDebt: '32400.00', savings: '21600.00', dueDay: '10' },
            { id: 'sc-3', label: 'Recálculo %', installmentsToPay: '36', originalDebt: '54000.00', installmentValue: '750.00', newDebt: '27000.00', savings: '27000.00', dueDay: '10' }
        ],
        otherInfo1: '1500.00',
        otherInfo2: '800.00'
    },
    {
        id: 'adm-02',
        date: new Date().toISOString(),
        clientId: '1002',
        clientName: 'TRANSPORTES RAPIDÃO LTDA',
        bankId: '3001',
        collaboratorId: '2001',
        seriesId: 's1',
        modalityId: 'm1',
        contractNumber: '152',
        totalInstallments: '48',
        paidInstallments: '0',
        overdueInstallments: '5',
        financedAmount: '120000.00',
        installmentValue: '3500.00',
        dueDay: '15',
        paymentType: 'BOLETO BANCÁRIO',
        indicationType: 'INDICAÇÃO',
        status: 'APROVADA',
        recalcScenarios: [
            { id: 'sc-1', label: 'Recálculo %', installmentsToPay: '48', originalDebt: '168000.00', installmentValue: '2100.00', newDebt: '100800.00', savings: '67200.00', dueDay: '15' }
        ],
        otherInfo1: 'Empresa com restrições.',
        otherInfo2: ''
    }
];

// --- MOCK COLLABORATORS ---
const MOCK_COLLABORATORS: Collaborator[] = [
  {
    id: '2001',
    name: 'RICARDO SOUZA',
    jobTitle: 'Gerente Comercial',
    phone: '(11) 95555-1111',
    isWhatsapp: true,
    email: 'ricardo.souza@financepro.com',
    maritalStatus: 'Casado(a)',
    birthDate: '1980-05-10',
    cep: '01000-000',
    address: 'RUA GENERAL OSORIO',
    number: '100',
    complement: '',
    district: 'CENTRO',
    city: 'SÃO PAULO',
    state: 'SP'
  }
];

// --- MOCK APPOINTMENTS ---
const todayStr = new Date().toISOString().split('T')[0];

const MOCK_APPOINTMENTS: Appointment[] = [
  {
    id: 'appt-1',
    clientId: '1001',
    clientName: 'CARLOS ALBERTO DE NOBREGA',
    collaboratorId: '2001',
    serviceId: 'svc1',
    date: todayStr,
    startTime: '09:00',
    endTime: '09:30',
    status: 'CONFIRMADO',
    notes: 'Consultoria inicial para revisão de contrato bancário.'
  }
];

// --- MOCK BANKS ---
const MOCK_BANKS: Bank[] = [
  {
    id: '3001',
    name: 'BANCO DO BRASIL S.A.',
    status: 'ATIVO',
    febrabanCode: '001',
    services: [
      { id: 's1', name: 'CDC VEÍCULOS', negotiationPercentage: 25.5 }
    ],
    notes: 'Aceita quitação com até 70% de desconto após 180 dias.'
  }
];

// --- MOCK MODALITIES ---
const MOCK_MODALITIES: Modality[] = [
  { id: 'm1', type: 'VEÍCULOS', description: 'REVISÃO DE FINANCIAMENTO DE VEÍCULOS' },
  { id: 'm2', type: 'CARTÕES', description: 'REVISÃO DE DÍVIDAS DE CARTÃO DE CRÉDITO' },
  { id: 'm3', type: 'CONSIGNADO', description: 'REVISÃO DE EMPRÉSTIMO CONSIGNADO' },
  { id: 'm4', type: 'EMPRÉSTIMOS', description: 'REVISÃO DE EMPRÉSTIMOS PESSOAIS' },
  { id: 'm5', type: 'OUTROS', description: 'OUTRAS NEGOCIAÇÕES FINANCEIRAS' }
];

// --- MOCK DOCUMENT TYPES (INITIAL) ---
const INITIAL_DOCUMENT_TYPES: DocumentType[] = [
    { id: 'doc-1', description: 'NOTA FISCAL', category: 'AMBOS', isFiscal: true, status: 'ATIVO', requiresDocNumber: true },
    { id: 'doc-2', description: 'BOLETO BANCÁRIO', category: 'AMBOS', isFiscal: false, status: 'ATIVO', requiresDocNumber: true },
    { id: 'doc-3', description: 'RECIBO', category: 'AMBOS', isFiscal: false, status: 'ATIVO', requiresDocNumber: false },
    { id: 'doc-4', description: 'DUPLICATA', category: 'RECEBER', isFiscal: true, status: 'ATIVO', requiresDocNumber: true }
];

// --- MOCK BEARERS (INITIAL) ---
const INITIAL_BEARERS: Bearer[] = [
    { id: 'b-1', code: 'CRT', name: 'CARTEIRA (LOCAL)', type: 'CARTEIRA', status: 'ATIVO', associatedBankAccountId: '' },
    { id: 'b-2', code: 'BB-01', name: 'COBRANÇA BB', type: 'BANCO', status: 'ATIVO', associatedBankAccountId: 'bk-1' },
];

// --- MOCK CHART OF ACCOUNTS (INITIAL) ---
const INITIAL_CHART_OF_ACCOUNTS: FinancialAccount[] = [
    { id: 'rec-1', code: '1', name: 'Receitas Operacionais', type: 'RECEITA', isAnalytical: false, isSystem: true },
    { id: 'rec-1-1', code: '1.01', name: 'Honorários e Serviços', type: 'RECEITA', parentId: 'rec-1', isAnalytical: false },
    { id: 'rec-1-1-1', code: '1.01.01', name: 'Honorários de Consultoria', type: 'RECEITA', parentId: 'rec-1-1', isAnalytical: true },
    { id: 'rec-1-1-2', code: '1.01.02', name: 'Comissões sobre Êxito', type: 'RECEITA', parentId: 'rec-1-1', isAnalytical: true },
    { id: 'des-2', code: '2', name: 'Despesas', type: 'DESPESA', isAnalytical: false, isSystem: true },
    { id: 'des-2-1', code: '2.01', name: 'Despesas Administrativas', type: 'DESPESA', parentId: 'des-2', isAnalytical: false },
    { id: 'des-2-1-1', code: '2.01.01', name: 'Aluguel e Condomínio', type: 'DESPESA', parentId: 'des-2-1', isAnalytical: true },
    { id: 'des-2-1-2', code: '2.01.02', name: 'Energia Elétrica', type: 'DESPESA', parentId: 'des-2-1', isAnalytical: true }
];

// --- MOCK DEPARTMENTS (INITIAL) ---
const INITIAL_DEPARTMENTS: Department[] = [
    { id: 'dep-1', code: '01', name: 'ADMINISTRATIVO', managerName: 'Carlos Silva', status: 'ATIVO' },
    { id: 'dep-2', code: '02', name: 'COMERCIAL', managerName: 'Ricardo Souza', status: 'ATIVO' },
    { id: 'dep-3', code: '03', name: 'JURÍDICO', managerName: 'Dra. Ana', status: 'ATIVO' }
];

// --- MOCK BANK ACCOUNTS (INITIAL) ---
const INITIAL_BANK_ACCOUNTS: BankAccount[] = [
    { 
        id: 'bk-1', 
        description: 'BANCO DO BRASIL - PRINCIPAL', 
        accountType: 'CORRENTE', 
        bankId: '3001', 
        bankName: 'BANCO DO BRASIL S.A.',
        agency: '1234-5', 
        accountNumber: '998877-X', 
        initialBalance: 15000.00, 
        initialBalanceDate: '2023-01-01', 
        currentBalance: 22500.50,
        isDefault: true,
        status: 'ATIVA'
    },
    { 
        id: 'bk-2', 
        description: 'CAIXA PEQUENO', 
        accountType: 'CAIXA', 
        initialBalance: 500.00, 
        initialBalanceDate: '2023-01-01', 
        currentBalance: 320.00,
        isDefault: false,
        status: 'ATIVA'
    }
];

export const DEFAULT_AUDIT_CHECK_ITEMS: AuditCheckItem[] = [
    { id: 'aci_01', order: 1, label: 'Validação de Prazo (15 Dias)', description: 'Prazo de vencimento da primeira parcela não poderá extrapolar o prazo máximo de 15 (quinze) dias.', status: 'ATIVO' },
    { id: 'aci_02', order: 2, label: 'Verificação de Titularidade', description: 'Verificar se o contrato está no nome do contratante dos serviços da Invicta ou em nome de terceiros.', status: 'ATIVO' },
    { id: 'aci_03', order: 3, label: 'Dados Coincidentes?', description: 'Documentação vs Folha de Rosto', status: 'ATIVO' },
    { id: 'aci_04', order: 4, label: 'Validar Tarifa Bancária', description: 'Verificar cobrança indevida', status: 'ATIVO' },
    { id: 'aci_05', order: 5, label: 'E-mail Obrigatório', description: 'E-mail válido informado', status: 'ATIVO' },
    { id: 'aci_06', order: 6, label: 'Senha do Cartão', description: 'Cliente ciente da senha', status: 'ATIVO', conditionField: 'CARTÕES' },
    { id: 'aci_07', order: 7, label: 'Assinatura Monitorada', description: 'Online ou presencial confirmado', status: 'ATIVO' },
    { id: 'aci_08', order: 8, label: 'Notificação Jurídico', description: 'Alerta de risco disparado', status: 'ATIVO' },
    { id: 'aci_09', order: 9, label: 'Gerar Procurações/Contratos', description: 'Emissão de documentos', status: 'ATIVO' },
];

export const DEFAULT_PORTAL_CONFIG: PortalConfig = {
  companyName: 'FinancePro Assessoria',
  logoUrl: 'https://picsum.photos/id/433/200/200', 
  marketingTitle: 'Sua Liberdade Financeira Começa Aqui',
  marketingText: 'Especialistas em negociação de dívidas e planejamento estratégico.',
  companyInfo: DEFAULT_COMPANY_INFO,
  units: [DEFAULT_COMPANY_INFO],
  userGroups: DEFAULT_USER_GROUPS,
  users: DEFAULT_USERS,
  emailTemplates: [],
  apiIntegrations: [],
  clients: MOCK_CLIENTS,
  collaborators: MOCK_COLLABORATORS,
  roles: [],
  banks: MOCK_BANKS,
  bankAccounts: INITIAL_BANK_ACCOUNTS, // Inicializado
  modalities: MOCK_MODALITIES,
  products: [],
  series: DEFAULT_SERIES,
  admissions: MOCK_ADMISSIONS,
  measurementUnits: [{ id: 'u1', name: 'UN', conversionFactor: 1 }],
  services: [
    { id: 'svc1', name: 'Consultoria Inicial', durationMinutes: 30, price: 150, color: '#3b82f6' }
  ],
  appointments: MOCK_APPOINTMENTS,
  agendaConfig: { startHour: '08:00', endHour: '18:00', slotInterval: 30 },
  auditLogs: [],
  documentTypes: INITIAL_DOCUMENT_TYPES,
  bearers: INITIAL_BEARERS, 
  chartOfAccounts: INITIAL_CHART_OF_ACCOUNTS, 
  departments: INITIAL_DEPARTMENTS, // Novo
  maritalStatusOptions: ['Solteiro(a)', 'Casado(a)', 'Divorciado(a)', 'Viúvo(a)', 'União Estável'],
  jobTitles: ['Gerente Comercial', 'Consultor(a) de Negócios', 'Analista Jurídico', 'Atendente'],
  modalityTypes: ['VEÍCULOS', 'CARTÕES', 'CONSIGNADO', 'EMPRÉSTIMOS', 'OUTROS'],
  paymentTypes: ['BOLETO BANCÁRIO', 'DÉBITO EM CONTA', 'PIX', 'CARTÃO DE CRÉDITO', 'DINHEIRO'],
  auditCheckItems: DEFAULT_AUDIT_CHECK_ITEMS,
  theme: {
    loginLeftBgColor: '#284332',
    loginLeftTextColor: '#ffffff',
    loginRightBgColor: '#ffffff', 
    loginRightTextColor: '#1f2937', 
    sidebarBgColor: '#2f543d',
    sidebarTextColor: '#ffffff',
    headerBgColor: '#2f543d',
    headerTextColor: '#ffffff',
    mainContentBgColor: '#f3f4f6',
  }
};

export const MASTER_ADMIN_EMAIL = 'master@invicta.com.br';
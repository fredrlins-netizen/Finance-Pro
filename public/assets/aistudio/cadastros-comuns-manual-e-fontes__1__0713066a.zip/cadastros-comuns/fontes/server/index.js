import http from 'http';
import express from 'express';
import compression from 'compression';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';
import { monitorEventLoopDelay } from 'node:perf_hooks';
import bcrypt from 'bcryptjs';
import cookieParser from 'cookie-parser';
import { fileURLToPath } from 'url';
import { initSocketServer, getOnlineUserIds } from './socket.js';
import { pool } from './db.js';
import { runReadOnlyDatabasePreflight } from './lib/startupDatabaseRetry.js';
import { configureProductionFrontend } from './productionFrontend.js';
import { startDataImportWorker } from './workers/dataImportWorker.js';
import { startClientAttachmentAuditWorker } from './workers/clientAttachmentAuditWorker.js';
import { startAdmissionAttachmentMigrationWorker } from './services/admissionAttachmentMigration.js';
import { migrateNextAdmissionAttachment } from './routes/clientAttachments.js';
const homologationEventLoopDelay = monitorEventLoopDelay({ resolution: 20 });
if (process.env.HOMOLOGATION_ISOLATED === 'true') homologationEventLoopDelay.enable();

import { seedReportTemplates } from './seed-report-templates.js';
import { runProductionSeed } from './seed-production.js';
import { extractUser, requireAuth, requireAdmin } from './middleware/auth.js';
import jwt from 'jsonwebtoken';
import { createAuthRoutes, COOKIE_NAME } from './routes/auth.js';
import { createClientsRoutes } from './routes/clients.js';
import { createCollaboratorsRoutes } from './routes/collaborators.js';
import { createBanksRoutes } from './routes/banks.js';
import { createFebrabanBanksRoutes, syncFebrabanBanks } from './routes/febrabanBanks.js';
import { createUnitsRoutes } from './routes/units.js';
import { createModalitiesRoutes } from './routes/modalities.js';
import { createProductsRoutes } from './routes/products.js';
import { createSeriesRoutes } from './routes/series.js';
import { createRolesRoutes } from './routes/roles.js';
import { createLookupsRoutes } from './routes/lookups.js';
import { createConfigOptionsRoutes } from './routes/configOptions.js';
import { createAdmissionsRoutes } from './routes/admissions.js';
import { createFinancialTitlesRoutes } from './routes/financialTitles.js';
import { createFinancialDashboardRoutes } from './routes/financialDashboard.js';
import { createSettlementsRoutes } from './routes/settlements.js';
import { createAppointmentsRoutes } from './routes/appointments.js';
import { createScheduleBlocksRoutes } from './routes/scheduleBlocks.js';
import { createLegalProcessesRoutes } from './routes/legalProcesses.js';
import { createUsersRoutes } from './routes/users.js';
import { createUserGroupsRoutes } from './routes/userGroups.js';
import { createUserPreferencesRoutes } from './routes/userPreferences.js';
import { createFormTemplatesRoutes } from './routes/formTemplates.js';
import { createReportQueriesRoutes } from './routes/reportQueries.js';
import { createBankMovementsRoutes } from './routes/bankMovements.js';
import { createAuditLogsRoute, logAudit } from './middleware/audit.js';
import { createGotalkRoutes } from './routes/gotalk.js';
import { createUazapiWebhookRoutes } from './routes/uazapiWebhook.js';
import { createUazapiChatsRoutes } from './routes/uazapiChats.js';
import { createUazapiAdvancedRoutes } from './routes/uazapiAdvanced.js';
import { startScheduledMessagesJob } from './lib/scheduledMessages.js';
import { startUazapiRecoveryJob } from './lib/uazapiRecovery.js';
import { startClientAttachmentReconciliationJob } from './lib/clientAttachmentReconciliation.js';
import { startPhotoChallengeCleanupJob } from './lib/photoChallenge.js';
import { createWhatsappTemplatesRoutes } from './routes/whatsappTemplates.js';
import { createWebhookRoutes as createWorkerWebhookRoutes } from '../whatsapp-worker/routes/webhook.js';
import { startPoller as startGotalkPoller } from '../whatsapp-worker/services/gotalkPoller.js';
import { syncAllChannels as syncGotalkChannels } from '../whatsapp-worker/services/gotalkChannels.js';
import { createCollectionNotesRoutes } from './routes/collectionNotes.js';
import { createClientAttachmentsRoutes } from './routes/clientAttachments.js';
import { createBucketAdminRoutes } from './routes/bucketAdmin.js';
import { createNegotiationsRoutes, createNegotiationGoalsRoutes } from './routes/negotiations.js';
import { createCommercialDealsRoutes } from './routes/commercialDeals.js';
import { createDataImportRoutes } from './routes/dataImport.js';
import { createProspectionRoutes } from './routes/prospection.js';
import { createLeoKnowledgeRoutes } from './routes/leoKnowledge.js';
import { Router } from 'express';
import { createSecurityMiddleware, createCorsMiddleware, requestSizeLimiter, sanitizeAllInputs, logFailedAuth, sanitizeServerErrors, createValidateApiAccess } from './middleware/security.js';
import { readLimiter, writeLimiter, messageSendLimiter } from './middleware/rateLimit.js';
import { createAIRoutes } from './routes/ai.js';
import { isGeminiAvailable } from './services/geminiClient.js';
import { createBullBoardAdapter } from './queues/bullBoard.js';
import { getRedisStatus, closeRedisConnection } from './queues/connection.js';
import basicAuth from 'express-basic-auth';
import { logger, requestLogger, requestIdMiddleware } from './logger.js';
import { createAdmissionClientsRoutes } from './lib/configClients.js';
import { hasCurrentSessionVersion, validateOpenSession } from './lib/sessionVersion.js';
import { startSseSessionHeartbeat } from './lib/sseSessionHeartbeat.js';
import { validateStartupMigrations } from './lib/startupMigrationPolicy.js';
import {
  getVisibleReportTemplate,
  isReadOnlyQuery,
  validateReportDefinition,
  validateReportSql,
  wrapReadOnlyQueryWithLimit,
} from './lib/reportSecurity.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function validateEnv() {
  const isProd = process.env.NODE_ENV === 'production';

  // Critical vars — app cannot start without these
  const critical = ['JWT_SECRET', 'DATABASE_URL', ...(isProd ? ['APP_DB_PASSWORD'] : [])];
  const missing = critical.filter(v => !process.env[v]);
  if (missing.length > 0) {
    missing.forEach(v => logger.error(`[ENV] CRITICO — variavel obrigatoria ausente: ${v}`));
    logger.error('[ENV] Encerrando — configure as variaveis faltantes antes de iniciar.');
    process.exit(1);
  }

  // Security audit table
  const checks = [
    { key: 'DATABASE_URL',      risk: 'CRITICO',      note: isProd ? 'Host e banco gerenciados pelo Replit' : 'Conexao com o banco de dados' },
    ...(isProd ? [{ key: 'APP_DB_PASSWORD', risk: 'CRITICO', note: 'Senha da role restrita app_user' }] : []),
    { key: 'JWT_SECRET',        risk: 'CRITICO',      note: 'Assinatura dos tokens de sessao' },
    { key: 'ENCRYPTION_KEY',    risk: 'RECOMENDADO',  note: 'AES-256 para tokens WhatsApp — usa JWT_SECRET como fallback inseguro' },
    { key: 'REDIS_URL',         risk: 'RECOMENDADO',  note: 'BullMQ + Socket.io — jobs em memoria sem Redis' },
    { key: 'ALLOWED_ORIGINS',   risk: 'RECOMENDADO',  note: 'CORS — fallback para dominios Replit' },
    { key: 'BULL_BOARD_USER',   risk: 'RECOMENDADO',  note: 'Painel /admin/filas — fallback para JWT-ADMIN' },
    { key: 'BULL_BOARD_PASS',   risk: 'RECOMENDADO',  note: 'Painel /admin/filas — fallback para JWT-ADMIN' },
    { key: 'GOTALK_LOGIN',      risk: 'OPCIONAL',     note: 'WhatsApp GoTalk' },
    { key: 'GEMINI_API_KEY',    risk: 'OPCIONAL',     note: 'IA Gemini / Leo' },
  ];

  const lines = checks.map(c => {
    const present = !!process.env[c.key];
    let badge;
    if (present)              badge = '[OK]        ';
    else if (c.risk === 'CRITICO')     badge = '[AUSENTE]   ';
    else if (c.risk === 'RECOMENDADO') badge = '[ATENCAO]   ';
    else                               badge = '[OPCIONAL]  ';
    const note = present ? '' : `  <- ${c.note}`;
    return `[ENV]   ${badge}${c.key}${note}`;
  });

  logger.info('[ENV] ================================================================');
  logger.info('[ENV] Verificacao de variaveis de ambiente (NODE_ENV=' + (process.env.NODE_ENV || 'development') + ')');
  lines.forEach(l => logger.info(l));
  logger.info('[ENV] ================================================================');

  // VITE_* runtime audit: VITE_-prefixed env vars are bundled into the frontend at build time
  // and become publicly visible in the browser. Detect any that are present in the runtime
  // environment so they can be reviewed for accidental secret exposure.
  const viteVars = Object.keys(process.env).filter(k => k.startsWith('VITE_'));
  if (viteVars.length > 0) {
    const prefix = isProd ? 'PRODUCAO — ' : '';
    logger.warn(`[ENV] ${prefix}VITE_* variaveis detectadas no ambiente: ${viteVars.join(', ')}`);
    logger.warn('[ENV] Variaveis VITE_* sao incorporadas no bundle do browser — nunca coloque segredos de servidor nelas.');
  }

  if (isProd) {
    if (!process.env.ENCRYPTION_KEY) {
      logger.error(
        '[ENV] CRITICO — PRODUCAO sem ENCRYPTION_KEY: tokens WhatsApp (uazapi) dependem do ' +
        'fallback JWT_SECRET. Todos os endpoints de credenciais WhatsApp retornarao 503 ate ' +
        'que ENCRYPTION_KEY seja definido nos Secrets. Use: openssl rand -hex 32'
      );
    }
    if (!process.env.REDIS_URL) {
      logger.warn(
        '[ENV] PRODUCAO — REDIS_URL ausente:\n' +
        '  • BullMQ usara EventEmitter em memoria (jobs perdidos no restart)\n' +
        '  • Socket.io sem adaptador Redis (impossivel escalar horizontalmente)\n' +
        '  • WhatsApp e jobs assincronos nao sobrevivem a reinicializacoes\n' +
        '  Configure REDIS_URL (ex: Redis Upstash) antes de ir a producao.'
      );
    }
    if (!process.env.ALLOWED_ORIGINS) {
      logger.warn('[ENV] PRODUCAO — ALLOWED_ORIGINS ausente: CORS derivado dos dominios Replit. Configure explicitamente em producao.');
    }
    if (!process.env.BULL_BOARD_USER || !process.env.BULL_BOARD_PASS) {
      logger.warn('[ENV] PRODUCAO — BULL_BOARD_USER/PASS ausentes: /admin/filas protegido apenas por JWT-ADMIN. Configure HTTP Basic Auth.');
    }
  } else {
    if (!process.env.REDIS_URL) {
      logger.warn('[ENV] REDIS_URL nao configurado — usando fallback em memoria (OK para desenvolvimento).');
    }
    if (!process.env.ALLOWED_ORIGINS) {
      logger.warn('[ENV] ALLOWED_ORIGINS nao definido — origens derivadas dos dominios Replit.');
    }
  }
}

validateEnv();

const app = express();
app.set('trust proxy', 1);

app.use(compression({
  level: 6,
  threshold: 1024,
  filter: (req, res) => {
    if (req.headers['x-no-compression']) return false;
    return compression.filter(req, res);
  },
}));

app.use(requestIdMiddleware);
app.use(createSecurityMiddleware());

const allowedOrigins = process.env.ALLOWED_ORIGINS ? process.env.ALLOWED_ORIGINS.split(',').map(o => o.trim()) : [];
app.use(createCorsMiddleware(allowedOrigins));

app.use(cookieParser());
// This must precede the request-size limiter: it can return 413 before the
// attachment parser or routes run, and those responses must remain private.
app.use('/api/client-attachments', (_req, res, next) => {
  res.setHeader('Cache-Control', 'private, no-store');
  next();
});
app.use(requestSizeLimiter('1mb', '22mb'));

app.use('/api/messages', express.json({ limit: '5mb' }));
app.use('/api/settings/theme', express.json({ limit: '10mb' }));
app.use('/api/form-templates', express.json({ limit: '20mb' }));
app.use('/api/uazapi/send-media', express.json({ limit: '25mb' }));
app.use('/api/import/extract-pdf', express.json({ limit: '20mb' }));
// O importador XLSX recebe o arquivo como binário e não como JSON/base64.
app.use('/api/import/upload', express.raw({
  type: [
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'application/octet-stream',
  ],
  limit: '22mb',
}));
// Client attachment imports carry base64 payloads; this parser must be registered
// before the global 1 MB parser below.
app.use('/api/client-attachments', express.json({ limit: '30mb' }));
app.use(express.json({ limit: '1mb' }));

app.use(logFailedAuth);
app.use(sanitizeServerErrors);
app.use(sanitizeAllInputs);
app.use(createValidateApiAccess(pool));

app.use(requestLogger);

app.use((req, res, next) => {
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
    return readLimiter(req, res, next);
  }
  return writeLimiter(req, res, next);
});

// SSE clients: Map<userId, { res, groupIds: string[] }>
// Mantido para o sistema de mensagens internas (SSE).
const sseClients = new Map();

async function broadcastToRecipient(message) {
  const deliveries = [];
  for (const [uid, client] of sseClients) {
    try {
      const isCurrent = await validateOpenSession(
        pool,
        { userId: uid, sessionVersion: client.sessionVersion },
        () => {
          client.res.end();
          sseClients.delete(uid);
        }
      );
      if (!isCurrent) continue;

      const shouldReceive =
        (message.recipient_type === 'USER' && message.recipient_id === uid) ||
        (message.recipient_type === 'GROUP' && client.groupIds && client.groupIds.includes(message.recipient_id)) ||
        (message.recipient_type === 'ALL') ||
        (message.sender_id === uid);
      if (shouldReceive) {
        client.res.write(`data: ${JSON.stringify({ type: 'NEW_MESSAGE', message })}\n\n`);
        if (uid !== message.sender_id) deliveries.push(uid);
      }
    } catch (e) {
      sseClients.delete(uid);
    }
  }
  if (deliveries.length > 0) {
    try {
      const values = deliveries.map((_, i) => `($1, $${i + 2})`).join(', ');
      await pool.query(
        `INSERT INTO message_deliveries (message_id, user_id) VALUES ${values} ON CONFLICT DO NOTHING`,
        [message.id, ...deliveries]
      );
    } catch {}
  }
}

async function getPortalConfig() {
  try {
    const result = await pool.query("SELECT value FROM app_data WHERE key = 'portal_config'");
    return result.rows.length > 0 ? result.rows[0].value : null;
  } catch {
    return null;
  }
}

// ── Auto-migration on startup ─────────────────────────────────────────────────
// Applies any pending SQL migrations from the migrations/ directory at server
// startup. Safe for multi-instance deployments via PostgreSQL advisory lock:
// only the instance that acquires the lock applies migrations; others skip
// (by the time they reach this point, migrations are already in migrations_log).
// A migration failure calls process.exit(1) — the server never starts against
// a broken schema.

const MIGRATIONS_ADVISORY_LOCK_ID = 739461; // unique int for this project

async function applyMigrations() {
  const MIGRATIONS_DIR = path.join(__dirname, '..', 'migrations');
  if (!fs.existsSync(MIGRATIONS_DIR)) {
    logger.warn('[Migrations] Pasta migrations/ não encontrada — pulando.');
    return;
  }

  validateStartupMigrations(MIGRATIONS_DIR);

  const client = await pool.connect();
  let lockAcquired = false;
  try {
    // Ensure migrations_log exists before attempting lock so all instances can
    // check applied migrations even when they don't hold the leader lock.
    await client.query(`
      CREATE TABLE IF NOT EXISTS migrations_log (
        id SERIAL PRIMARY KEY,
        filename VARCHAR(255) NOT NULL UNIQUE,
        applied_at TIMESTAMPTZ DEFAULT NOW()
      )
    `);

    // Only one instance applies migrations — others see an up-to-date log
    // and skip cleanly.
    const lockResult = await client.query(
      'SELECT pg_try_advisory_lock($1) AS acquired',
      [MIGRATIONS_ADVISORY_LOCK_ID]
    );
    lockAcquired = lockResult.rows[0]?.acquired === true;

    const appliedResult = await client.query('SELECT filename FROM migrations_log ORDER BY filename');
    const applied = new Set(appliedResult.rows.map(r => r.filename));

    const files = fs
      .readdirSync(MIGRATIONS_DIR)
      .filter(f => f.endsWith('.sql'))
      .sort();

    const pending = files.filter(f => !applied.has(f));

    if (pending.length === 0) {
      logger.info('[Migrations] Banco atualizado — nenhuma migration pendente.');
      return;
    }

    if (!lockAcquired) {
      // Another instance holds the lock and is applying migrations.
      // Poll until the pending list is empty (max 60s) before continuing — this
      // prevents the server from booting against a partially-migrated schema.
      logger.info('[Migrations] Outra instância está aplicando migrations — aguardando conclusão...');
      const deadline = Date.now() + 60_000;
      while (Date.now() < deadline) {
        await new Promise(r => setTimeout(r, 2000));
        const recheck = await client.query('SELECT filename FROM migrations_log ORDER BY filename');
        const recheckApplied = new Set(recheck.rows.map(r => r.filename));
        const stillPending = files.filter(f => !recheckApplied.has(f));
        if (stillPending.length === 0) {
          logger.info('[Migrations] Migrations aplicadas pela instância líder. Prosseguindo.');
          return;
        }
      }
      // Timeout — log a warning but allow startup (the leader may still be running)
      logger.warn('[Migrations] Timeout aguardando migrations da instância líder. Prosseguindo com cautela.');
      return;
    }

    logger.info(`[Migrations] ${pending.length} migration(s) pendente(s). Aplicando...`);

    for (const filename of pending) {
      const filePath = path.join(MIGRATIONS_DIR, filename);
      const sql = fs.readFileSync(filePath, 'utf8');
      try {
        await client.query('BEGIN');
        await client.query(sql);
        await client.query('INSERT INTO migrations_log (filename) VALUES ($1)', [filename]);
        await client.query('COMMIT');
        logger.info(`[Migrations] [OK] ${filename}`);
      } catch (err) {
        await client.query('ROLLBACK');
        logger.error(`[Migrations] [FATAL] ${filename}: ${err.message}`);
        logger.error('[Migrations] O servidor não pode iniciar com uma migration falha. Encerrando.');
        process.exit(1);
      }
    }

    logger.info(`[Migrations] ${pending.length} migration(s) aplicada(s) com sucesso.`);
  } finally {
    if (lockAcquired) {
      // Release the session-level advisory lock before handing off the client.
      await client.query('SELECT pg_advisory_unlock($1)', [MIGRATIONS_ADVISORY_LOCK_ID]).catch(() => {});
    }
    client.release();
  }
}

async function verifyProductionSchema() {
  // Publish promotes schema, not migration-log data. Validate concrete runtime
  // dependencies through catalog reads instead of requiring data mutations.
  const requiredRelations = [
    'background_jobs',
    'client_attachments',
    'data_backfill_runs',
    'data_backfill_attempts',
    'gotalk_attendance_history',
    'gotalk_operator_attendances',
    'v_gotalk_client_timeline',
    'v_gotalk_attendance_summary',
    'user_preferences',
    'photo_challenges',
    'login_mfa_attempts',
    'data_import_queue_events',
    'data_import_queue_metric_failures',
  ];
  const requiredColumns = [
    ['client_attachments', 'batch_key'],
    ['client_attachments', 'target_id'],
    ['background_jobs', 'lease_token'],
    ['gotalk_messages', 'attendance_history_id'],
    ['gotalk_messages', 'uazapi_instance_id'],
    ['users', 'session_version'],
    ['user_preferences', 'width_scale'],
    ['user_preferences', 'height_scale'],
    ['photo_challenges', 'context'],
    ['photo_challenges', 'binding'],
    ['photo_challenges', 'answer_ids'],
    ['photo_challenges', 'image_ids'],
    ['photo_challenges', 'expires_at'],
    ['photo_challenges', 'attempts'],
    ['photo_challenges', 'created_at'],
    ['login_mfa_attempts', 'attempt_id'],
    ['login_mfa_attempts', 'attempt_number'],
    ['login_mfa_attempts', 'expires_at'],
  ];
  const relations = await pool.query(
    `SELECT required.name
       FROM unnest($1::text[]) AS required(name)
      WHERE to_regclass('public.' || required.name) IS NULL`,
    [requiredRelations],
  );
  const columns = await pool.query(
    `SELECT required.table_name, required.column_name
       FROM unnest($1::text[], $2::text[]) AS required(table_name, column_name)
       LEFT JOIN information_schema.columns c
         ON c.table_schema = 'public'
        AND c.table_name = required.table_name
        AND c.column_name = required.column_name
      WHERE c.column_name IS NULL`,
    [requiredColumns.map(item => item[0]), requiredColumns.map(item => item[1])],
  );
  const queueTablePermissions = await pool.query(
    `SELECT required.name,
            to_regclass('public.' || required.name) IS NOT NULL AS relation_exists,
            has_table_privilege(current_user, to_regclass('public.' || required.name), 'SELECT') AS can_select,
            has_table_privilege(current_user, to_regclass('public.' || required.name), 'INSERT') AS can_insert,
            has_table_privilege(current_user, to_regclass('public.' || required.name), 'DELETE') AS can_delete
       FROM unnest($1::text[]) AS required(name)`,
    [['data_import_queue_events', 'data_import_queue_metric_failures']],
  );
  const missing = [
    ...relations.rows.map(row => `relação public.${row.name}`),
    ...columns.rows.map(row => `coluna public.${row.table_name}.${row.column_name}`),
  ];
  for (const access of queueTablePermissions.rows) {
    if (access.relation_exists
      && (!access.can_select || !access.can_insert || !access.can_delete)) {
      missing.push(`permissões SELECT, INSERT e DELETE em public.${access.name}`);
    }
  }
  if (missing.length) {
    throw new Error(`[Migrations] Schema de produção incompatível — ausente: ${missing.join(', ')}`);
  }
  logger.info('[Migrations] Contrato mínimo de runtime validado somente leitura.');
}

async function verifyBackgroundJobsLeaseSchema() {
  const { rows } = await pool.query(
    `SELECT 1
       FROM information_schema.columns
      WHERE table_schema = 'public'
        AND table_name = 'background_jobs'
        AND column_name = 'lease_token'`,
  );
  if (rows.length === 0) {
    throw new Error(
      '[Migrations] Schema incompatível — o worker não pode iniciar sem a coluna public.background_jobs.lease_token.',
    );
  }
  logger.info('[Migrations] Proteção de lease dos workers validada somente leitura.');
}

async function initDB() {
  // Development migrations may write and must never be replayed by this retry.
  if (process.env.NODE_ENV !== 'production') return initializeDatabase();
  return runReadOnlyDatabasePreflight(initializeDatabase, {
    onRetry: ({ attempt, delayMs }) => logger.warn(
      `[INIT] Conexão temporariamente indisponível; nova tentativa ${attempt + 1}/3 em ${delayMs}ms.`,
    ),
  });
}

async function initializeDatabase() {
  if (process.env.NODE_ENV === 'production') {
    // Replit Publish applies the development → production schema diff before
    // starting the container. Re-running SQL migrations here can collide with
    // objects that Publish has just created, so production startup stays
    // read-only and only development/test environments execute this runner.
    logger.info('[Migrations] Produção usa o schema aplicado pelo Publish; runner de startup desativado.');
    await verifyProductionSchema();
  } else {
    await applyMigrations();
  }
  // Workers use lease_token in their claim, heartbeat, and terminal-update
  // queries. Never start them against an old or partially promoted schema.
  await verifyBackgroundJobsLeaseSchema();
  // Schema changes belong exclusively in ordered SQL migrations. Keep startup
  // checks read-only so the application can never mutate database structure.
  const { rows } = await pool.query(
    `SELECT rolname AS username, rolsuper, rolcreatedb, rolcreaterole, rolbypassrls
     FROM pg_roles WHERE rolname = current_user`
  );
  const role = rows[0];
  if (!role) throw new Error('[INIT] FALHA DE SEGURANCA — não foi possível identificar o role do banco.');
  if (process.env.NODE_ENV === 'production' &&
      (role.rolsuper || role.rolcreatedb || role.rolcreaterole || role.rolbypassrls)) {
    throw new Error(`[INIT] FALHA DE SEGURANCA — role privilegiado "${role.username}" em produção.`);
  }
  logger.info(`[INIT] DB role: ${role.username} (superuser=${role.rolsuper})`);
  return;
}

const DEFAULT_BEARERS = [
  { id: 'bbbbbbbb-1001-4000-8000-000000000001', code: '001', name: 'CARTEIRA PRÓPRIA',  type: 'CARTEIRA' },
  { id: 'bbbbbbbb-1002-4000-8000-000000000002', code: '002', name: 'COBRANÇA BANCÁRIA', type: 'BANCO' },
  { id: 'bbbbbbbb-1003-4000-8000-000000000003', code: '003', name: 'CARTÓRIO',          type: 'CARTORIO' },
  { id: 'bbbbbbbb-1004-4000-8000-000000000004', code: '004', name: 'JURÍDICO',          type: 'JURIDICO' },
  { id: 'bbbbbbbb-1005-4000-8000-000000000005', code: '005', name: 'TERCEIROS',         type: 'TERCEIROS' },
];

async function ensureDefaultBearers(dbPool) {
  try {
    const { rows } = await dbPool.query('SELECT COUNT(*) as cnt FROM bearers');
    if (parseInt(rows[0].cnt) > 0) return;

    for (const b of DEFAULT_BEARERS) {
      await dbPool.query(
        'INSERT INTO bearers (id, code, name, type, status) VALUES ($1,$2,$3,$4,$5) ON CONFLICT (id) DO NOTHING',
        [b.id, b.code, b.name, b.type, 'ATIVO']
      );
    }
    console.log('[INIT] 5 portadores padrão inseridos.');

    const configBearers = DEFAULT_BEARERS.map(b => ({ id: b.id, code: b.code, name: b.name, type: b.type, status: 'ATIVO' }));
    const bearersJson = JSON.stringify(configBearers);
    const { rowCount } = await dbPool.query(
      `UPDATE app_data SET value = jsonb_set(value, '{bearers}', $1::jsonb) WHERE key = 'portal_config'`,
      [bearersJson]
    );
    if (rowCount === 0) {
      await dbPool.query(
        `INSERT INTO app_data (key, value) VALUES ('portal_config', jsonb_build_object('bearers', $1::jsonb)) ON CONFLICT (key) DO UPDATE SET value = jsonb_set(app_data.value, '{bearers}', $1::jsonb)`,
        [bearersJson]
      );
    }
    console.log('[INIT] portal_config.bearers atualizado.');
  } catch (err) {
    logger.warn('[INIT] ensureDefaultBearers falhou:', err.message);
  }
}

// 🔒 SEGURANÇA [VULN-9]: revalida o status da conta no banco em escritas sensíveis.
// O JWT pode permanecer válido por horas após um admin INATIVAR/BLOQUEAR a conta.
// Este middleware reconfere status/locked_at no DB para operações de escrita
// (POST/PUT/PATCH/DELETE). Decisões de segurança (Zero-Trust):
//  - SEM cache positivo: contas ATIVAS são reconferidas a cada escrita → a
//    desativação por um admin tem efeito IMEDIATO (sem janela de 15s).
//  - Cache APENAS negativo (10s): evita marteladas de 403 sem atrasar liberação.
//  - FAIL-CLOSED: se a checagem no DB falhar, a escrita é bloqueada (503), pois
//    não é possível garantir que a conta continua ativa.
const _accountBlockedCache = new Map(); // userId -> { reason, exp }
const ACCOUNT_BLOCKED_TTL_MS = 10_000;

async function validateAccountStatus(req, res, next) {
  // Apenas escritas precisam de revalidação imediata; leituras seguem o JWT.
  if (req.method === 'GET' || req.method === 'HEAD' || req.method === 'OPTIONS') {
    return next();
  }
  const userId = req.currentUser?.id;
  if (!userId) return next(); // requireAuth (quando presente) trata ausência de auth

  const now = Date.now();
  const blocked = _accountBlockedCache.get(userId);
  if (blocked && blocked.exp > now) {
    return res.status(403).json({ error: blocked.reason });
  }

  try {
    const r = await pool.query('SELECT status, locked_at FROM users WHERE id = $1', [userId]);
    if (r.rows.length === 0) {
      const reason = 'Conta não encontrada. Faça login novamente.';
      _accountBlockedCache.set(userId, { reason, exp: now + ACCOUNT_BLOCKED_TTL_MS });
      return res.status(403).json({ error: reason });
    }
    const { status, locked_at } = r.rows[0];
    let reason = null;
    if (status === 'INATIVO') {
      reason = 'Conta inativa. Entre em contato com o administrador.';
    } else if (locked_at) {
      // Conta bloqueada por tentativas de login — a janela de bloqueio é tratada no login.
      reason = 'Conta temporariamente bloqueada. Faça login novamente.';
    }
    if (reason) {
      _accountBlockedCache.set(userId, { reason, exp: now + ACCOUNT_BLOCKED_TTL_MS });
      return res.status(403).json({ error: reason });
    }
    // Conta ativa: não cacheia (revalida a cada escrita) → desativação imediata.
    _accountBlockedCache.delete(userId);
    return next();
  } catch (err) {
    logger.error('[validateAccountStatus] erro:', err.message);
    // 🔒 FAIL-CLOSED: sem confirmação do status, a escrita sensível é negada.
    return res.status(503).json({ error: 'Não foi possível validar a sessão. Tente novamente.' });
  }
}

app.use('/api/auth', extractUser, createAuthRoutes(pool));
app.use('/api/clients', extractUser, requireAuth, validateAccountStatus, createClientsRoutes(pool));
app.use('/api/admission-clients', extractUser, requireAuth, validateAccountStatus, createAdmissionClientsRoutes(pool));
app.use('/api/collaborators', extractUser, createCollaboratorsRoutes(pool));
app.use('/api/banks', extractUser, createBanksRoutes(pool));
app.use('/api/febraban-banks', extractUser, createFebrabanBanksRoutes(pool));
app.use('/api/units', extractUser, createUnitsRoutes(pool));
app.use('/api/modalities', extractUser, createModalitiesRoutes(pool));
app.use('/api/products', extractUser, createProductsRoutes(pool));
app.use('/api/series', extractUser, createSeriesRoutes(pool));
app.use('/api/roles', extractUser, createRolesRoutes(pool));
app.use('/api/lookups', extractUser, createLookupsRoutes(pool));
app.use('/api/config-options', extractUser, createConfigOptionsRoutes(pool));
app.use('/api/admissions', extractUser, requireAuth, validateAccountStatus, createAdmissionsRoutes(pool));
app.use('/api/financial-titles', extractUser, requireAuth, validateAccountStatus, createFinancialTitlesRoutes(pool));
app.use('/api/financial-dashboard', extractUser, requireAuth, validateAccountStatus, createFinancialDashboardRoutes(pool));
app.use('/api/settlements', extractUser, requireAuth, validateAccountStatus, createSettlementsRoutes(pool));
app.use('/api/appointments', extractUser, createAppointmentsRoutes(pool));
app.use('/api/schedule-blocks', extractUser, createScheduleBlocksRoutes(pool));
app.use('/api/legal-processes', extractUser, createLegalProcessesRoutes(pool));
app.use('/api/user-preferences', extractUser, createUserPreferencesRoutes(pool));
app.use('/api/users', extractUser, requireAuth, createUsersRoutes(pool));
app.use('/api/user-groups', extractUser, requireAuth, requireAdmin, createUserGroupsRoutes(pool));
app.use('/api/form-templates', extractUser, requireAuth, createFormTemplatesRoutes(pool));
app.use('/api/bank-movements', extractUser, createBankMovementsRoutes(pool));
app.use('/api/reports/queries', extractUser, requireAuth, createReportQueriesRoutes(pool));
app.use('/api/audit-logs', extractUser, requireAuth, createAuditLogsRoute(pool, Router));
// GoTalk webhook routes montados em todos os ambientes.
// Em produção eram montados somente ali; agora também em dev para que o worker
// standalone (que falha com timeout de DB) não seja o único ponto de entrada.
{
  const workerWebhookRouter = createWorkerWebhookRoutes(pool);
  app.use('/', workerWebhookRouter);
  logger.info('[INIT] WhatsApp Worker webhook routes mounted (all environments).');
}
app.use('/api/uazapi', extractUser, createUazapiWebhookRoutes(pool));
app.use('/api/uazapi', extractUser, createUazapiChatsRoutes(pool));
app.use('/api/uazapi', extractUser, createUazapiAdvancedRoutes(pool));
const _gotalkRouter = createGotalkRoutes(pool);
app.use('/api/gotalk', extractUser, _gotalkRouter);
// Alias: GET /api/whatsapp/messages → /api/gotalk/messages-list
// Preserves original query string so all filters/pagination params are forwarded.
app.get('/api/whatsapp/messages', extractUser, (req, res, next) => {
  const qs = req.originalUrl.includes('?') ? req.originalUrl.slice(req.originalUrl.indexOf('?')) : '';
  req.url = '/messages-list' + qs;
  _gotalkRouter(req, res, next);
});
app.use('/api/whatsapp-templates', extractUser, createWhatsappTemplatesRoutes(pool));
app.use('/api/collection-notes', extractUser, createCollectionNotesRoutes(pool));
app.use('/api/client-attachments', extractUser, createClientAttachmentsRoutes(pool));
app.use('/api/bucket-admin', extractUser, createBucketAdminRoutes(pool));
app.use('/api/negotiations', extractUser, createNegotiationsRoutes(pool));
app.use('/api/negotiation-goals', extractUser, createNegotiationGoalsRoutes(pool));
app.use('/api/commercial-deals', extractUser, createCommercialDealsRoutes(pool));
app.use('/api/import', extractUser, requireAuth, validateAccountStatus, createDataImportRoutes(pool));
app.use('/api/prospection', extractUser, createProspectionRoutes(pool));

// ── IA & Análise ──────────────────────────────────────────────────────────────
// Status: rota pública (só extractUser), sem requireAuth, sem aiRouter intermediário
app.get('/api/ai/status', extractUser, (req, res) => {
  res.json({ available: isGeminiAvailable(), model: 'gemini-2.5-flash' });
});

// Todas as rotas /api/ai/* (exceto /status já registrado acima) requerem auth
// Rate limiters por rota ficam dentro do aiRouter (server/routes/ai.js)
const aiRouter = createAIRoutes(pool);
app.use('/api/ai', extractUser, requireAuth, aiRouter);

app.use('/api/leo-knowledge', express.json({ limit: '10mb' }), extractUser, requireAuth, createLeoKnowledgeRoutes(pool));

app.get('/api/config', async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT value FROM app_data WHERE key = 'portal_config'"
    );
    if (result.rows.length > 0) {
      const cfg = result.rows[0].value;

      // Soft JWT check: /api/config is a public path so validateApiAccess does not
      // verify the cookie. We do it here manually.
      // - Unauthenticated callers (login page) receive only branding fields.
      // - Authenticated callers receive the full config as before.
      let isAuthenticated = false;
      let configUser = null;
      const authToken = req.cookies?.[COOKIE_NAME];
      if (authToken && process.env.JWT_SECRET) {
        try {
          const payload = jwt.verify(authToken, process.env.JWT_SECRET);
          isAuthenticated = await hasCurrentSessionVersion(pool, payload);
          if (isAuthenticated) configUser = payload;
        } catch {}
      }

      if (!isAuthenticated) {
        return res.json({
          data: {
            companyName: cfg.companyName || null,
            logoUrl: cfg.logoUrl || null,
            theme: cfg.theme || null,
            marketingTitle: cfg.marketingTitle || null,
            marketingText: cfg.marketingText || null,
          }
        });
      }

      const groupIds = Array.isArray(configUser?.groupIds) ? configUser.groupIds : [];
      const userIsAdmin = configUser?.userRole === 'ADMIN';
      let formPermissions = new Set();
      if (!userIsAdmin && groupIds.length > 0) {
        const permissionsResult = await pool.query(
          'SELECT permission FROM user_group_permissions WHERE group_id = ANY($1::uuid[])',
          [groupIds]
        );
        formPermissions = new Set(permissionsResult.rows.map(row => row.permission));
      }
      const canManageForms = userIsAdmin || formPermissions.has('rel_formularios:VISUALIZAR');
      const canUseForm = (template) => {
        if (userIsAdmin || canManageForms) return true;
        const menuIds = Array.isArray(template.menu_ids) ? template.menu_ids : [];
        return menuIds.some(menuId => [
          'VISUALIZAR', 'INCLUIR', 'ALTERAR', 'EXCLUIR', 'CANCELAR', 'INATIVAR', 'IMPRIMIR',
        ].some(action => formPermissions.has(`${menuId}:${action}`)));
      };

      const [
        rolesResult,
        collabsResult,
        apptResult,
        companiesResult,
        formTplResult,
        usersResult,
        groupsResult,
        legalProcessesResult,
      ] = await Promise.all([
        pool.query(
          `SELECT id, value, sort_order FROM config_options WHERE option_type = 'role' ORDER BY sort_order ASC, value ASC`
        ),
        pool.query(
          `SELECT id, name, photo_url, job_title, phone, is_whatsapp, email,
                  marital_status, birth_date, cep, address, number, complement,
                  district, city, state, notes, unit_id, department_id, active
           FROM collaborators ORDER BY name ASC`
        ),
        pool.query(
          `SELECT id, client_id, client_name, collaborator_id, service_id,
                  to_char(date, 'YYYY-MM-DD') AS date,
                  start_time, end_time, status, notes,
                  unit_id, group_id, modalidade, created_at, updated_at
           FROM appointments ORDER BY date ASC, start_time ASC`
        ),
        pool.query(
          `SELECT id, razao_social, nome_fantasia, cnpj, telefone, email, cep, endereco,
                  numero, complemento, bairro, cidade, estado, taxa_minima, whatsapp_number
           FROM companies ORDER BY razao_social ASC`
        ),
        pool.query(
          `SELECT id, name, description, content, header, footer, menu_ids, docx_template, updated_at
           FROM form_templates ORDER BY updated_at DESC`
        ).then(result => ({
          ...result,
          rows: result.rows.filter(canUseForm),
        })).catch(() => null),
        pool.query(
          `SELECT u.id, u.name, u.email, u.role, u.status, u.photo_url,
                  u.force_change_password, u.collaborator_id,
                  u.failed_attempts, u.locked_at,
                  COALESCE((SELECT json_agg(uau.unit_id) FROM user_allowed_units uau WHERE uau.user_id = u.id), '[]') AS allowed_units,
                  COALESCE((SELECT json_agg(ugm.group_id) FROM user_group_members ugm WHERE ugm.user_id = u.id), '[]') AS group_ids
           FROM users u ORDER BY u.name ASC`
        ).catch(err => { logger.warn('[config] Falha ao carregar usuários do banco:', err.message); return null; }),
        pool.query(
          `SELECT ug.id, ug.name,
                  COALESCE((SELECT json_agg(ugp.permission) FROM user_group_permissions ugp WHERE ugp.group_id = ug.id), '[]') AS permissions
           FROM user_groups ug ORDER BY ug.name ASC`
        ).catch(err => { logger.warn('[config] Falha ao carregar grupos do banco:', err.message); return null; }),
        pool.query(
          `SELECT lp.*,
            COALESCE((SELECT json_agg(m ORDER BY m.date DESC) FROM legal_process_movements m WHERE m.process_id = lp.id), '[]') AS movements,
            COALESCE((SELECT json_agg(d ORDER BY d.due_date ASC) FROM legal_process_deadlines d WHERE d.process_id = lp.id), '[]') AS deadlines,
            COALESCE((SELECT json_agg(h ORDER BY h.date ASC) FROM legal_process_hearings h WHERE h.process_id = lp.id), '[]') AS hearings
           FROM legal_processes lp ORDER BY lp.updated_at DESC`
        ).catch(err => { logger.warn('[config] Falha ao carregar processos jurídicos do banco:', err.message); return null; }),
      ]);

      cfg.roles = rolesResult.rows.map(row => {
        try {
          const parsed = JSON.parse(row.value);
          if (typeof parsed === 'object' && parsed.name) {
            return { id: row.id, name: parsed.name, participatesInScheduling: !!parsed.participatesInScheduling };
          }
        } catch {}
        return { id: row.id, name: row.value, participatesInScheduling: false };
      });

      // Profiles are loaded by the screen that needs them, never on startup.
      cfg.clients = [];
      cfg.collaborators = collabsResult.rows.map(r => ({
        id: r.id,
        name: r.name,
        photoUrl: r.photo_url,
        jobTitle: r.job_title,
        phone: r.phone,
        isWhatsapp: r.is_whatsapp,
        email: r.email,
        maritalStatus: r.marital_status,
        birthDate: r.birth_date,
        cep: r.cep,
        address: r.address,
        number: r.number,
        complement: r.complement,
        district: r.district,
        city: r.city,
        state: r.state,
        notes: r.notes,
        unitId: r.unit_id,
        departmentId: r.department_id,
        active: r.active,
      }));

      cfg.appointments = apptResult.rows.map(r => ({
        id: r.id,
        clientId: r.client_id,
        clientName: r.client_name,
        collaboratorId: r.collaborator_id,
        serviceId: r.service_id,
        date: r.date,
        startTime: r.start_time,
        endTime: r.end_time,
        status: r.status,
        notes: r.notes,
        unitId: r.unit_id,
        groupId: r.group_id,
        modalidade: r.modalidade,
        createdAt: r.created_at,
        updatedAt: r.updated_at,
      }));

      if (companiesResult.rows.length > 0) {
        const cfgUnitsById = {};
        (cfg.units || []).forEach(u => { if (u.id) cfgUnitsById[u.id] = u; });
        cfg.units = companiesResult.rows.map(r => ({
          ...(cfgUnitsById[r.id] || {}),
          id: r.id,
          razaoSocial: r.razao_social,
          nomeFantasia: r.nome_fantasia || cfgUnitsById[r.id]?.nomeFantasia || null,
          cnpj: r.cnpj,
          telefone: r.telefone,
          email: r.email,
          cep: r.cep,
          endereco: r.endereco,
          numero: r.numero,
          complemento: r.complemento,
          bairro: r.bairro,
          cidade: r.cidade,
          estado: r.estado,
          taxaMinima: r.taxa_minima != null
            ? new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(Number(r.taxa_minima))
            : '',
          whatsappNumber: r.whatsapp_number || '',
        }));
      }

      if (formTplResult) {
        cfg.formTemplates = formTplResult.rows.map(r => ({
          id: r.id,
          name: r.name,
          description: r.description || '',
          content: r.content || '',
          header: r.header || '',
          footer: r.footer || '',
          menuIds: r.menu_ids || [],
          docxTemplate: r.docx_template || undefined,
          updatedAt: r.updated_at,
        }));
      } else {
        cfg.formTemplates = [];
      }

      if (usersResult) {
        cfg.users = usersResult.rows.map(u => ({
          id: u.id,
          name: u.name,
          email: u.email,
          role: u.role,
          status: u.status,
          photoUrl: u.photo_url || '',
          forceChangePassword: u.force_change_password || false,
          collaboratorId: u.collaborator_id || undefined,
          failedAttempts: u.failed_attempts || 0,
          lockedAt: u.locked_at || undefined,
          allowedUnitIds: u.allowed_units || [],
          groupIds: u.group_ids || [],
        }));
      }

      if (groupsResult) {
        cfg.userGroups = groupsResult.rows.map(g => ({
          id: g.id,
          name: g.name,
          permissions: g.permissions || [],
        }));
      }

      if (legalProcessesResult) {
        cfg.companyLegalProcesses = legalProcessesResult.rows.map(r => ({
          id: r.id,
          unitId: r.unit_id || null,
          processNumber: r.process_number || '',
          court: r.court || '',
          jurisdiction: r.jurisdiction || '',
          type: r.type || '',
          role: r.role || '',
          opposingParty: r.opposing_party || '',
          opposingPartyDocument: r.opposing_party_document || '',
          opposingPartyLawyer: r.opposing_party_lawyer || '',
          opposingPartyLawyerOab: r.opposing_party_lawyer_oab || '',
          partnerId: r.partner_id || null,
          responsibleLawyer: r.responsible_lawyer || '',
          responsibleLawyerOab: r.responsible_lawyer_oab || '',
          status: r.status || 'ATIVO',
          subject: r.subject || '',
          causeValue: r.cause_value ? String(r.cause_value) : '',
          provisionValue: r.provision_value ? String(r.provision_value) : '',
          riskLevel: r.risk_level || '',
          distributionDate: r.distribution_date ? new Date(r.distribution_date).toISOString().split('T')[0] : '',
          lastMovementDate: r.last_movement_date ? new Date(r.last_movement_date).toISOString().split('T')[0] : '',
          notes: r.notes || '',
          notesHeader: r.notes_header || '',
          notesFooter: r.notes_footer || '',
          tags: Array.isArray(r.tags) ? r.tags : (r.tags ? [r.tags] : []),
          movements: Array.isArray(r.movements) ? r.movements.map(m => ({
            id: m.id,
            processId: m.process_id,
            date: m.date ? new Date(m.date).toISOString().split('T')[0] : '',
            description: m.description || '',
            type: m.type || '',
            source: m.source || '',
            createdAt: m.created_at,
          })) : [],
          deadlines: Array.isArray(r.deadlines) ? r.deadlines.map(d => ({
            id: d.id,
            processId: d.process_id,
            type: d.type || '',
            description: d.description || '',
            dueDate: d.due_date ? new Date(d.due_date).toISOString().split('T')[0] : '',
            status: d.status || 'PENDENTE',
            responsibleId: d.responsible_id || undefined,
            notes: d.notes || '',
            createdAt: d.created_at,
          })) : [],
          hearings: Array.isArray(r.hearings) ? r.hearings.map(h => ({
            id: h.id,
            processId: h.process_id,
            type: h.type || '',
            date: h.date ? new Date(h.date).toISOString().split('T')[0] : '',
            time: h.time || '',
            location: h.location || '',
            status: h.status || 'AGENDADA',
            notes: h.notes || '',
            createdAt: h.created_at,
          })) : [],
          admissionId: r.admission_id || null,
          clientId: r.client_id || null,
          clientName: r.client_name || '',
          contractNumber: r.contract_number || '',
          createdAt: r.created_at,
          updatedAt: r.updated_at,
        }));
      } else {
        cfg.companyLegalProcesses = cfg.companyLegalProcesses || [];
      }

      // Redact credential/session fields from the portal_config blob before sending to browser.
      // These keys may exist from legacy config formats (e.g. bearers = GoTalk JWT tokens).
      ['bearers', 'tokens', 'secrets', 'privateKeys', 'apiKeys'].forEach(k => { delete cfg[k]; });

      res.json({ data: cfg });
    } else {
      res.json({ data: null });
    }
  } catch (err) {
    logger.error('Error loading config:', err.message);
    res.status(500).json({ error: 'Failed to load config' });
  }
});

app.get('/api/settings/theme', async (req, res) => {
  try {
    const result = await pool.query("SELECT value FROM app_data WHERE key = 'portal_config'");
    if (result.rows.length > 0) {
      const cfg = result.rows[0].value;
      res.json({
        companyName: cfg.companyName,
        logoUrl: cfg.logoUrl,
        marketingTitle: cfg.marketingTitle,
        marketingText: cfg.marketingText,
        theme: cfg.theme,
      });
    } else {
      res.json({});
    }
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/settings/theme', extractUser, requireAdmin, async (req, res) => {
  try {
    const { companyName, logoUrl, marketingTitle, marketingText, theme } = req.body;
    const result = await pool.query("SELECT value FROM app_data WHERE key = 'portal_config'");
    if (result.rows.length === 0) return res.status(404).json({ error: 'Config not found' });
    const cfg = result.rows[0].value;
    if (companyName !== undefined) cfg.companyName = companyName;
    if (logoUrl !== undefined) cfg.logoUrl = logoUrl;
    if (marketingTitle !== undefined) cfg.marketingTitle = marketingTitle;
    if (marketingText !== undefined) cfg.marketingText = marketingText;
    if (theme !== undefined) cfg.theme = { ...cfg.theme, ...theme };
    await pool.query(
      `UPDATE app_data SET value = $1, updated_at = NOW() WHERE key = 'portal_config'`,
      [JSON.stringify(cfg)]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/settings/section', extractUser, requireAdmin, async (req, res) => {
  try {
    const { key, value } = req.body;
    if (!key || value === undefined) return res.status(400).json({ error: 'key and value required' });
    const allowedKeys = [
      'emailTemplates', 'apiIntegrations', 'helpTopics', 'auditCheckItems',
      'escalas', 'services', 'agendaConfig', 'statusColors', 'schedulingQueue',
      'waitlist', 'maritalStatusOptions', 'companyLegalProcesses', 'formTemplates',
      'series', 'departments', 'documentTypes', 'bearers', 'chartOfAccounts',
      'bankAccounts', 'receivableTitles', 'admissions', 'users', 'userGroups', 'units',
    ];
    if (!allowedKeys.includes(key)) return res.status(400).json({ error: 'Key not allowed' });
    const result = await pool.query("SELECT value FROM app_data WHERE key = 'portal_config'");
    if (result.rows.length === 0) return res.status(404).json({ error: 'Config not found' });
    const cfg = result.rows[0].value;
    cfg[key] = value;
    await pool.query(
      `UPDATE app_data SET value = $1, updated_at = NOW() WHERE key = 'portal_config'`,
      [JSON.stringify(cfg)]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/settings/seed-apis', extractUser, requireAdmin, async (req, res) => {
  try {
    const added = await seedApiIntegrations();
    res.json({ success: true, added: added || 0, message: added ? `${added} integração(ões) adicionada(s).` : 'Nenhuma integração nova para adicionar.' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/ping', (req, res) => {
  res.status(200).send('OK');
});

app.get('/api/health', async (req, res) => {
  let database = 'disconnected';
  try {
    await pool.query('SELECT 1');
    database = 'connected';
  } catch {}

  const redisStatus = getRedisStatus();
  const redis = redisStatus === 'connected' ? 'connected' : 'fallback';

  res.json({ status: 'ok', database, redis });
});

// Read-only, admin-only metrics used by the isolated attachment harness.
// It is intentionally unavailable unless the process declares isolation.
app.get('/api/homologation/metrics', extractUser, requireAdmin, async (req, res) => {
  if (process.env.HOMOLOGATION_ISOLATED !== 'true') return res.status(404).json({ error: 'not available' });
  try {
    const [audit, storage, database] = await Promise.all([
      pool.query(`SELECT
        count(*) FILTER (WHERE status IN ('pending','processing'))::int AS pending,
        count(*) FILTER (WHERE status='completed')::int AS completed,
        count(*) FILTER (WHERE status='failed')::int AS failed
        FROM background_jobs WHERE queue='client_attachment_audit'`),
      pool.query('SELECT count(*)::int AS count FROM client_attachments'),
      pool.query(`SELECT
        count(*) FILTER (WHERE state='active')::int AS active,
        count(*) FILTER (WHERE state='active' AND wait_event IS NOT NULL)::int AS waiting,
        count(*) FILTER (WHERE state='active' AND query_start < NOW() - INTERVAL '1 second')::int AS slow_active,
        (SELECT count(*)::int FROM pg_locks WHERE NOT granted) AS ungranted_locks
        FROM pg_stat_activity WHERE datname=current_database()`),
    ]);
    const memory = process.memoryUsage();
    const cpu = process.cpuUsage();
    const nsToMs = value => Number.isFinite(value) ? value / 1e6 : 0;
    res.json({
      system: {
        rssBytes: memory.rss, heapUsedBytes: memory.heapUsed, externalBytes: memory.external,
        uptimeSeconds: process.uptime(), cpuUserMicros: cpu.user, cpuSystemMicros: cpu.system,
        eventLoopMs: {
          mean: nsToMs(homologationEventLoopDelay.mean),
          p95: nsToMs(homologationEventLoopDelay.percentile(95)),
          p99: nsToMs(homologationEventLoopDelay.percentile(99)),
          max: nsToMs(homologationEventLoopDelay.max),
        },
      },
      db: {
        poolTotal: pool.totalCount, poolIdle: pool.idleCount, poolWaiting: pool.waitingCount,
        ...database.rows[0],
      },
      storage: { indexedAttachments: Number(storage.rows[0].count) },
      audit: audit.rows[0],
    });
    homologationEventLoopDelay.reset();
  } catch { res.status(503).json({ error: 'metrics unavailable' }); }
});

app.get('/api/env', (req, res) => {
  res.json({ environment: process.env.NODE_ENV === 'production' ? 'production' : 'development' });
});

app.get('/api/cep/:cep', async (req, res) => {
  const cep = (req.params.cep || '').replace(/\D/g, '');
  if (cep.length !== 8) {
    return res.status(400).json({ erro: true, message: 'CEP deve ter 8 dígitos.' });
  }
  try {
    const upstream = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
    if (!upstream.ok) {
      return res.status(502).json({ erro: true, message: 'Erro ao consultar ViaCEP.' });
    }
    const data = await upstream.json();
    res.json(data);
  } catch (err) {
    logger.warn('[CEP] Falha na consulta:', err.message);
    res.status(502).json({ erro: true, message: 'Falha na consulta de CEP.' });
  }
});

// POST /api/admin/sync-uazapi-creds-from-prod
// Copia as credenciais uazapi da base de produção (PROD_DATABASE_URL) para a base DEV atual.
// RESTRITO: apenas NODE_ENV !== 'production' + usuário autenticado com role ADMIN (requireAdmin).
// Pré-requisito: definir a variável de ambiente PROD_DATABASE_URL no ambiente DEV.
app.post('/api/admin/sync-uazapi-creds-from-prod', extractUser, requireAdmin, async (req, res) => {
  const isDev = (process.env.NODE_ENV || 'development') !== 'production';
  if (!isDev) {
    return res.status(403).json({ error: 'Endpoint disponível apenas no ambiente de desenvolvimento.' });
  }
  const prodUrl = process.env.PROD_DATABASE_URL;
  if (!prodUrl) {
    return res.status(503).json({
      error: 'PROD_DATABASE_URL não configurado. Defina essa variável de ambiente no ambiente DEV apontando para o banco de produção.',
    });
  }

  let prodPool;
  try {
    const { Pool } = await import('pg');
    prodPool = new Pool({
      connectionString: prodUrl,
      max: 3,
      connectionTimeoutMillis: 8000,
      idleTimeoutMillis: 10000,
    });

    const prodRows = await prodPool.query(`
      SELECT unit_id, uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url, label,
             webhook_url, webhook_registered_at, created_at
      FROM unit_whatsapp_credentials
      WHERE uazapi_token_encrypted IS NOT NULL AND uazapi_token_encrypted <> ''
      ORDER BY unit_id, created_at
    `);

    if (prodRows.rows.length === 0) {
      return res.json({ copied: 0, message: 'Nenhuma credencial uazapi encontrada na base de produção.' });
    }

    let copied = 0;
    let skipped = 0;
    for (const row of prodRows.rows) {
      try {
        const r = await pool.query(`
          INSERT INTO unit_whatsapp_credentials
            (unit_id, uazapi_instance_id, uazapi_token_encrypted, uazapi_server_url, label,
             webhook_url, webhook_registered_at)
          VALUES ($1,$2,$3,$4,$5,$6,$7)
          ON CONFLICT (uazapi_instance_id) DO UPDATE SET
            uazapi_token_encrypted = EXCLUDED.uazapi_token_encrypted,
            uazapi_server_url      = EXCLUDED.uazapi_server_url,
            label                  = COALESCE(EXCLUDED.label, unit_whatsapp_credentials.label),
            webhook_url            = COALESCE(EXCLUDED.webhook_url, unit_whatsapp_credentials.webhook_url),
            webhook_registered_at  = COALESCE(EXCLUDED.webhook_registered_at, unit_whatsapp_credentials.webhook_registered_at)
          RETURNING (xmax = 0) AS inserted
        `, [
          row.unit_id,
          row.uazapi_instance_id,
          row.uazapi_token_encrypted,
          row.uazapi_server_url,
          row.label,
          row.webhook_url,
          row.webhook_registered_at,
        ]);
        if (r.rows[0]?.inserted) copied++; else skipped++;
      } catch (rowErr) {
        logger.warn(`[sync-uazapi-creds] Erro ao copiar instância ${row.uazapi_instance_id}: ${rowErr.message}`);
        skipped++;
      }
    }

    logger.info(`[sync-uazapi-creds] Sincronização concluída: ${copied} inseridas, ${skipped} atualizadas/ignoradas.`);
    return res.json({
      ok: true,
      copied,
      skipped,
      total: prodRows.rows.length,
      message: `${copied} credencial(is) copiada(s) de produção para DEV. ${skipped} já existiam ou tiveram erro.`,
      warning: 'As credenciais são copiadas com a criptografia da base de origem. Para funcionar no DEV, a variável ENCRYPTION_KEY deve ser IDÊNTICA à de produção.',
    });
  } catch (err) {
    logger.error(`[sync-uazapi-creds] Erro: ${err.message}`);
    return res.status(500).json({ error: `Falha ao conectar à base de produção: ${err.message}` });
  } finally {
    if (prodPool) await prodPool.end().catch(() => {});
  }
});

app.post('/api/admin/seed-production', async (req, res) => {
  const token = req.headers['x-seed-token'] || req.body?.token;
  const validToken = process.env.SEED_TOKEN;
  if (!validToken) return res.status(503).json({ error: 'SEED_TOKEN não configurado no ambiente' });
  if (token !== validToken) return res.status(401).json({ error: 'Token inválido' });
  try {
    const result = await runProductionSeed(pool);
    res.json(result);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// --- REPORT BUILDER API ---

// 🔒 SEGURANÇA [VULN-2]: réplica server-side do buildParameterizedQuery do frontend.
// Substitui placeholders ({{nome}} ou :nome) do SQL ARMAZENADO no template por $N
// e monta o array de params a partir dos filterValues enviados pelo cliente.
// O cliente nunca controla o corpo do SQL — apenas os VALORES dos filtros.
function buildParameterizedQueryServer(sql, filters, filterValues) {
  const params = [];
  let paramIndex = 1;
  let processedSql = sql;
  const vals = (filterValues && typeof filterValues === 'object') ? filterValues : {};
  for (const f of (Array.isArray(filters) ? filters : [])) {
    if (!f || typeof f.placeholder !== 'string') continue;
    const val = vals[f.id] !== undefined ? vals[f.id] : (f.defaultValue || '');
    const escapedName = f.placeholder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const doubleBrace = new RegExp('\\{\\{' + escapedName + '\\}\\}', 'g');
    const colonStyle = new RegExp(':' + escapedName + '\\b', 'g');
    const matchesBrace = doubleBrace.test(processedSql);
    doubleBrace.lastIndex = 0;
    const matchesColon = !matchesBrace && colonStyle.test(processedSql);
    colonStyle.lastIndex = 0;
    if (matchesBrace) {
      const token = `$${paramIndex}`;
      processedSql = processedSql.replace(doubleBrace, () => token);
      params.push(val);
      paramIndex++;
    } else if (matchesColon) {
      const token = `$${paramIndex}`;
      processedSql = processedSql.replace(colonStyle, () => token);
      params.push(val);
      paramIndex++;
    }
  }
  return { sql: processedSql, params };
}

app.get('/api/reports/schema/tables', extractUser, requireAdmin, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT table_name
      FROM information_schema.tables
      WHERE table_schema = 'public'
      ORDER BY table_name
    `);
    res.json({ tables: result.rows.map(r => r.table_name) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/reports/schema/columns', extractUser, requireAdmin, async (req, res) => {
  const { table } = req.query;
  if (!table) return res.status(400).json({ error: 'table parameter required' });
  try {
    const result = await pool.query(`
      SELECT column_name, data_type, is_nullable, column_default, ordinal_position,
             character_maximum_length, numeric_precision, numeric_scale
      FROM information_schema.columns
      WHERE table_schema = 'public' AND table_name = $1
      ORDER BY ordinal_position
    `, [table]);
    res.json({ columns: result.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/reports/schema/foreign-keys', extractUser, requireAdmin, async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT
        tc.table_name AS source_table,
        kcu.column_name AS source_column,
        ccu.table_name AS foreign_table,
        ccu.column_name AS foreign_column
      FROM information_schema.table_constraints AS tc
      JOIN information_schema.key_column_usage AS kcu
        ON tc.constraint_name = kcu.constraint_name AND tc.table_schema = kcu.table_schema
      JOIN information_schema.constraint_column_usage AS ccu
        ON ccu.constraint_name = tc.constraint_name AND ccu.table_schema = tc.table_schema
      WHERE tc.constraint_type = 'FOREIGN KEY' AND tc.table_schema = 'public'
      ORDER BY tc.table_name, kcu.column_name
    `);
    res.json({ foreignKeys: result.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/reports/preview-query', extractUser, requireAdmin, async (req, res) => {
  const { sql, params, limit } = req.body;
  if (!sql || typeof sql !== 'string') return res.status(400).json({ error: 'SQL query required' });
  if (!isReadOnlyQuery(sql)) return res.status(403).json({ error: 'Apenas consultas SELECT são permitidas.' });
  const requestedLimit = Number.parseInt(limit, 10);
  const maxLimit = Number.isInteger(requestedLimit) ? Math.max(1, Math.min(requestedLimit, 500)) : 50;
  const wrappedSql = wrapReadOnlyQueryWithLimit(sql, maxLimit + 1);
  const start = Date.now();
  try {
    const client = await pool.connect();
    let result;
    try {
      await client.query('BEGIN READ ONLY');
      await client.query("SET LOCAL statement_timeout = '15s'");
      result = await client.query(wrappedSql, Array.isArray(params) ? params : []);
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      throw err;
    } finally {
      client.release();
    }
    const duration = Date.now() - start;
    const fields = (result.fields || []).map(f => ({ name: f.name, dataTypeID: f.dataTypeID }));
    const rows = result.rows.slice(0, maxLimit);
    res.json({ rows, fields, rowCount: rows.length, limit: maxLimit, truncated: result.rows.length > maxLimit, duration });
  } catch (err) {
    const duration = Date.now() - start;
    res.status(400).json({ error: err.message, duration });
  }
});

app.post('/api/reports/execute-query', extractUser, requireAuth, async (req, res) => {
  const { sql, params, templateId, subreportId, filterValues } = req.body;
  const { id: userId, isAdmin, groupIds } = req.currentUser;

  // 🔒 SEGURANÇA [VULN-2]: o SQL a executar é decidido pelo servidor, nunca pelo cliente.
  //  - Não-admin: SEMPRE executa o sql_query ARMAZENADO no template (ou subrelatório),
  //    reconstruindo os placeholders → $N no servidor. O cliente envia apenas filterValues.
  //  - Admin: pode executar SQL read-only arbitrário (necessário para o builder/preview).
  let sqlToRun;
  let paramsToRun;

  if (!isAdmin) {
    if (!templateId || typeof templateId !== 'string') {
      return res.status(403).json({ error: 'Apenas administradores podem executar consultas SQL arbitrárias. Informe o templateId do relatório.' });
    }
    let tplResult;
    try {
      const template = await getVisibleReportTemplate(pool, req.currentUser, templateId);
      tplResult = { rows: template ? [template] : [] };
    } catch (err) {
      logger.error('[execute-query] verificação de acesso:', err.message);
      return res.status(500).json({ error: 'Erro ao verificar acesso ao relatório.' });
    }
    if (tplResult.rows.length === 0) {
      return res.status(403).json({ error: 'Acesso não autorizado a este relatório.' });
    }
    const template = tplResult.rows[0];
    const templateFilters = Array.isArray(template.filters) ? template.filters : [];

    // Resolve o SQL armazenado: principal ou de um subrelatório específico do template.
    let storedSql = template.sql_query;
    if (subreportId) {
      const subreports = Array.isArray(template.subreports) ? template.subreports : [];
      const sr = subreports.find(s => s.id === subreportId);
      if (!sr || sr.type !== 'query' || typeof sr.sql_query !== 'string') {
        return res.status(403).json({ error: 'Subrelatório não pertence ao template informado.' });
      }
      storedSql = sr.sql_query;
    }

    if (!storedSql || typeof storedSql !== 'string' || !isReadOnlyQuery(storedSql)) {
      return res.status(403).json({ error: 'SQL do template inválido.' });
    }

    // Reconstrói a query parametrizada a partir do SQL ARMAZENADO + filterValues do cliente.
    const built = buildParameterizedQueryServer(storedSql, templateFilters, filterValues);
    sqlToRun = built.sql;
    paramsToRun = built.params;
  } else {
    // Admin: SQL read-only arbitrário enviado pelo cliente (builder/preview).
    if (!sql || typeof sql !== 'string') return res.status(400).json({ error: 'SQL query required' });
    if (!isReadOnlyQuery(sql)) return res.status(403).json({ error: 'Apenas consultas SELECT são permitidas.' });
    sqlToRun = sql;
    paramsToRun = params || [];
  }

  const requestedLimit = Number.parseInt(req.body.limit, 10);
  const maxLimit = Number.isInteger(requestedLimit) ? Math.max(1, Math.min(requestedLimit, 500)) : 500;
  const wrappedSql = wrapReadOnlyQueryWithLimit(sqlToRun, maxLimit + 1);
  const start = Date.now();
  try {
    const client = await pool.connect();
    let result;
    try {
      await client.query('BEGIN READ ONLY');
      await client.query("SET LOCAL statement_timeout = '15s'");
      result = await client.query(wrappedSql, paramsToRun);
      await client.query('COMMIT');
    } catch (err) {
      await client.query('ROLLBACK').catch(() => {});
      throw err;
    } finally {
      client.release();
    }
    const duration = Date.now() - start;
    const truncated = result.rows.length > maxLimit;
    const rows = result.rows.slice(0, maxLimit);
    const fields = (result.fields || []).map(f => ({ name: f.name, dataTypeID: f.dataTypeID }));
    res.json({ rows, fields, rowCount: rows.length, limit: maxLimit, truncated, duration });
  } catch (err) {
    const duration = Date.now() - start;
    // 🔒 SEGURANÇA [VULN-8]: logar internamente; mensagem genérica ao cliente.
    logger.error('[execute-query] erro:', err.message);
    res.status(400).json({ error: 'Erro ao executar consulta. Verifique os parâmetros.', duration });
  }
});

app.get('/api/reports/templates', extractUser, requireAuth, async (req, res) => {
  // isAdmin, userId, groupIds MUST come from the verified JWT — never from req.query.
  // Reading these from query params allows any unauthenticated client to pass
  // ?isAdmin=true and bypass all per-user/per-group visibility controls.
  const { id: userId, isAdmin, groupIds } = req.currentUser;
  try {
    let query;
    let params;
    if (isAdmin) {
      query = `SELECT * FROM report_templates WHERE is_active = true ORDER BY category, name`;
      params = [];
    } else {
      query = `
        SELECT * FROM report_templates
        WHERE is_active = true
          AND (
            allowed_users IS NULL AND allowed_groups IS NULL
            OR allowed_users @> ARRAY[$1]::uuid[]
            OR allowed_groups && $2::uuid[]
          )
        ORDER BY category, name
      `;
      const groupIdArray = Array.isArray(groupIds) ? groupIds : [];
      params = [userId, groupIdArray];
    }
    const result = await pool.query(query, params);
    res.json({ templates: result.rows });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/reports/templates/:id', extractUser, requireAuth, async (req, res) => {
  try {
    let result;
    if (req.currentUser.isAdmin) {
      result = await pool.query('SELECT * FROM report_templates WHERE id = $1 AND is_active = true', [req.params.id]);
    } else {
      const groupIds = Array.isArray(req.currentUser.groupIds) ? req.currentUser.groupIds : [];
      result = await pool.query(`
        SELECT * FROM report_templates
        WHERE id = $1 AND is_active = true
          AND (
            allowed_users IS NULL AND allowed_groups IS NULL
            OR allowed_users @> ARRAY[$2]::uuid[]
            OR allowed_groups && $3::uuid[]
          )
      `, [req.params.id, req.currentUser.id, groupIds]);
    }
    if (result.rows.length === 0) return res.status(404).json({ error: 'Template não encontrado' });
    res.json({ template: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Middleware: require ADMIN role for report template write operations
function requireAdminRole(req, res, next) {
  const role = req.jwtPayload?.userRole;
  if (!role || role !== 'ADMIN') {
    return res.status(403).json({ error: 'Apenas administradores podem criar ou editar templates de relatório.' });
  }
  next();
}

app.post('/api/reports/templates', requireAdminRole, async (req, res) => {
  const { name, description, category, target_layout, content_mode, sql_query, layout, filters, subreports, charts, allowed_users, allowed_groups } = req.body;
  // 🔒 SEGURANÇA [VULN-7]: created_by derivado do JWT verificado, NUNCA de req.body —
  // previne falsificação de autoria no audit trail (mass assignment, CWE-915).
  const created_by = req.jwtPayload?.userId || null;
  if (!name || !sql_query) return res.status(400).json({ error: 'name and sql_query are required' });
  const sqlError = validateReportSql(sql_query);
  if (sqlError) return res.status(400).json({ error: sqlError });
  const definitionError = validateReportDefinition(req.body);
  if (definitionError) return res.status(400).json({ error: definitionError });
  try {
    const result = await pool.query(`
      INSERT INTO report_templates (name, description, category, target_layout, content_mode, sql_query, layout, filters, subreports, charts, allowed_users, allowed_groups, created_by)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
      RETURNING *
    `, [
      name, description || null, category || 'Outros', target_layout || 'responsive', content_mode || 'both',
      sql_query, JSON.stringify(layout || {}), JSON.stringify(filters || []), JSON.stringify(subreports || []),
      JSON.stringify(charts || []), allowed_users || null, allowed_groups || null, created_by
    ]);
    res.json({ template: result.rows[0] });
  } catch (err) {
    // 🔒 SEGURANÇA [VULN-8]: logar internamente; retornar mensagem genérica.
    logger.error('[reports/templates POST] erro:', err.message);
    res.status(500).json({ error: 'Erro interno no servidor.' });
  }
});

app.put('/api/reports/templates/:id', requireAdminRole, async (req, res) => {
  const { name, description, category, target_layout, content_mode, sql_query, layout, filters, subreports, charts, allowed_users, allowed_groups } = req.body;
  if (sql_query !== undefined) {
    const sqlError = validateReportSql(sql_query);
    if (sqlError) return res.status(400).json({ error: sqlError });
  }
  const definitionError = validateReportDefinition(req.body);
  if (definitionError) return res.status(400).json({ error: definitionError });
  try {
    const result = await pool.query(`
      UPDATE report_templates
      SET name = COALESCE($1, name), description = $2, category = COALESCE($3, category),
          target_layout = COALESCE($4, target_layout), content_mode = COALESCE($5, content_mode),
          sql_query = COALESCE($6, sql_query), layout = COALESCE($7, layout),
          filters = COALESCE($8, filters), subreports = COALESCE($9, subreports),
          charts = COALESCE($10, charts), allowed_users = $11, allowed_groups = $12,
          updated_at = NOW()
      WHERE id = $13 AND is_active = true
      RETURNING *
    `, [
      name, description, category, target_layout, content_mode, sql_query,
      layout ? JSON.stringify(layout) : null, filters ? JSON.stringify(filters) : null,
      subreports ? JSON.stringify(subreports) : null, charts ? JSON.stringify(charts) : null,
      allowed_users || null, allowed_groups || null, req.params.id
    ]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Template não encontrado' });
    res.json({ template: result.rows[0] });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/reports/templates/:id', requireAdminRole, async (req, res) => {
  try {
    const result = await pool.query(
      'UPDATE report_templates SET is_active = false, updated_at = NOW() WHERE id = $1 RETURNING id',
      [req.params.id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Template não encontrado' });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// --- END REPORT BUILDER API ---

// /api/sql is a raw database executor for admin tooling.
// Protected by requireAdminRole — only ADMIN users can execute queries.
// Every execution is recorded in audit_logs for full traceability.
app.post('/api/sql', extractUser, requireAdmin, async (req, res) => {
  const { query, params } = req.body;
  if (!query || typeof query !== 'string') {
    return res.status(400).json({ error: 'Query inválida ou ausente.' });
  }
  const start = Date.now();
  let result;
  let execError = null;
  try {
    result = await pool.query(query, params || []);
  } catch (err) {
    execError = err;
  }
  const duration = Date.now() - start;

  // Audit every /api/sql execution regardless of success or failure
  try {
    const userId = req.currentUser?.id || null;
    const userName = req.currentUser?.name || 'ADMIN';
    const truncatedQuery = query.length > 2000 ? query.slice(0, 2000) + '…' : query;
    const auditChanges = [{
      field: 'query',
      new: truncatedQuery,
      status: execError ? 'ERRO' : 'OK',
      command: result?.command || null,
      rowCount: result?.rowCount ?? null,
      durationMs: duration,
      error: execError?.message || null,
    }];
    await logAudit(pool, {
      userId,
      userName,
      entityType: 'SQL_EXECUTOR',
      entityId: null,
      action: 'UPDATE',
      description: `SQL manual via /api/sql — ${execError ? 'ERRO' : result?.command || 'OK'} (${duration}ms, ${result?.rowCount ?? 0} linhas)`,
      changes: auditChanges,
      ipAddress: req.ip,
      globalEvent: true,
      required: true,
    });
  } catch (auditErr) {
    logger.error('[/api/sql] Falha ao registrar auditoria:', auditErr.message);
  }

  if (execError) {
    return res.status(400).json({ error: execError.message, duration });
  }

  const safeRows = Array.isArray(result.rows) ? result.rows : [];
  const rows = safeRows.slice(0, 500);
  const fields = (result.fields || []).map(f => ({ name: f.name, dataTypeID: f.dataTypeID }));
  const rowCount = result.rowCount ?? safeRows.length;
  const command = result.command || null;
  res.json({ rows, fields, rowCount, duration, truncated: safeRows.length > 500, command });
});

// --- MESSAGES API ---

// GET online users — combina Socket.io (presença em tempo real) com SSE (fallback)
// 🔒 SEGURANÇA [VULN-4]: presença online é dado sensível (revela usuários ativos e
// horários de trabalho). Exige autenticação — não é endpoint público.
app.get('/api/online-users', extractUser, requireAuth, (req, res) => {
  const socketIds = getOnlineUserIds();
  const sseIds = Array.from(sseClients.keys());
  const merged = Array.from(new Set([...socketIds, ...sseIds]));
  res.json({ onlineUserIds: merged });
});

// SSE stream — validates user against portal_config, does NOT trust groupIds from URL
app.get('/api/messages/stream', async (req, res) => {
  const userId = req.jwtPayload?.userId;
  if (!userId || typeof userId !== 'string') {
    return res.status(401).json({ error: 'Autenticação necessária' });
  }

  const config = await getPortalConfig();
  const user = config?.users?.find(u => u.id === userId);
  if (!user && userId !== 'SYSTEM') {
    return res.status(403).json({ error: 'Unauthorized' });
  }

  let realGroupIds = [];
  if (config?.userGroups) {
    realGroupIds = config.userGroups
      .filter(g => (user?.groupIds || []).includes(g.id))
      .map(g => g.id);
  }

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('X-Accel-Buffering', 'no');
  res.flushHeaders();

  res.write(':connected\n\n');

  const streamClient = {
    res,
    groupIds: realGroupIds,
    sessionVersion: req.jwtPayload.sessionVersion,
  };
  sseClients.set(userId, streamClient);

  const stopHeartbeat = startSseSessionHeartbeat({
    pool,
    payload: { userId, sessionVersion: req.jwtPayload.sessionVersion },
    res,
    onClose: () => {
      // A previous connection closing must not remove its replacement.
      if (sseClients.get(userId) === streamClient) {
        sseClients.delete(userId);
      }
    },
  });
  res.on('close', stopHeartbeat);
});

// GET messages with pagination
app.get('/api/messages', async (req, res) => {
  const { userId, before, limit } = req.query;
  if (!userId) return res.status(400).json({ error: 'userId required' });

  // Enforce identity: only allow reading your own messages unless ADMIN
  const jwtUserId = req.jwtPayload?.userId;
  const jwtRole = req.jwtPayload?.userRole;
  if (jwtUserId !== userId && jwtRole !== 'ADMIN') {
    return res.status(403).json({ error: 'Acesso negado' });
  }

  const config = await getPortalConfig();
  const user = config?.users?.find(u => u.id === userId);
  if (!user) return res.status(403).json({ error: 'Unauthorized' });

  const realGroupIds = (config?.userGroups || [])
    .filter(g => (user.groupIds || []).includes(g.id))
    .map(g => g.id);

  const pageLimit = Math.min(parseInt(limit) || 50, 100);

  try {
    let query = `
      SELECT m.*,
        CASE WHEN mr.user_id IS NOT NULL THEN TRUE ELSE FALSE END as read,
        CASE WHEN EXISTS (SELECT 1 FROM message_deliveries md WHERE md.message_id = m.id AND md.user_id != m.sender_id) THEN TRUE ELSE FALSE END as delivered
      FROM messages m
      LEFT JOIN message_reads mr ON mr.message_id = m.id AND mr.user_id = $1
      WHERE (
        (m.recipient_type = 'USER' AND m.recipient_id = $1)
        OR (m.recipient_type = 'ALL')
        OR (m.sender_id = $1)
        ${realGroupIds.length > 0 ? `OR (m.recipient_type = 'GROUP' AND m.recipient_id = ANY($2))` : ''}
      )
      ${before ? `AND m.created_at < $${realGroupIds.length > 0 ? 3 : 2}` : ''}
      ORDER BY m.created_at DESC
      LIMIT $${realGroupIds.length > 0 ? (before ? 4 : 3) : (before ? 3 : 2)}
    `;
    const params = [userId];
    if (realGroupIds.length > 0) params.push(realGroupIds);
    if (before) params.push(before);
    params.push(pageLimit);

    const result = await pool.query(query, params);
    res.json({ messages: result.rows, hasMore: result.rows.length === pageLimit });
  } catch (err) {
    logger.error('Error loading messages:', err.message);
    res.status(500).json({ error: 'Failed to load messages' });
  }
});

// POST new message — rate limit via express-rate-limit (messageSendLimiter)
app.post('/api/messages', messageSendLimiter, async (req, res) => {
  // Derive sender identity from JWT — never trust senderId/senderName from body.
  const senderId = req.jwtPayload?.userId;
  const senderName = req.jwtPayload?.userName;

  if (!senderId || !senderName) {
    return res.status(401).json({ error: 'Autenticação necessária' });
  }

  const { recipientType, recipientId, subject, body, attachments, isSystem, metadata } = req.body;

  if (!recipientType || !recipientId || !body) {
    return res.status(400).json({ error: 'Missing required fields' });
  }

  if (!['USER', 'GROUP', 'ALL'].includes(recipientType)) {
    return res.status(400).json({ error: 'Invalid recipientType' });
  }

  // Validate attachments — block SVG
  const safeAttachments = (attachments || []).filter(a => {
    if (!a.type || !a.data) return false;
    if (a.type === 'image/svg+xml' || (a.name && a.name.toLowerCase().endsWith('.svg'))) return false;
    return true;
  });

  try {
    const result = await pool.query(
      `INSERT INTO messages (sender_id, sender_name, recipient_type, recipient_id, subject, body, attachments, is_system, metadata)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [senderId, senderName, recipientType, recipientId, subject || null, body, JSON.stringify(safeAttachments), isSystem || false, JSON.stringify(metadata || {})]
    );
    const message = result.rows[0];
    broadcastToRecipient(message);
    res.json({ message });
  } catch (err) {
    logger.error('Error creating message:', err.message);
    res.status(500).json({ error: 'Failed to create message' });
  }
});

// PATCH mark as read
app.patch('/api/messages/:id/read', async (req, res) => {
  const { id } = req.params;
  // Use userId from JWT — do not trust body.userId
  const userId = req.jwtPayload?.userId;
  if (!userId) return res.status(401).json({ error: 'Autenticação necessária' });
  try {
    await pool.query(
      `INSERT INTO message_reads (message_id, user_id) VALUES ($1, $2) ON CONFLICT DO NOTHING`,
      [id, userId]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to mark as read' });
  }
});

// PATCH mark all as read for user
app.patch('/api/messages/read-all', async (req, res) => {
  // Use userId from JWT — do not trust body.userId or body.groupIds
  const userId = req.jwtPayload?.userId;
  if (!userId) return res.status(401).json({ error: 'Autenticação necessária' });

  const config = await getPortalConfig();
  const user = config?.users?.find(u => u.id === userId);
  if (!user) return res.status(403).json({ error: 'Unauthorized' });

  const realGroupIds = (config?.userGroups || [])
    .filter(g => (user.groupIds || []).includes(g.id))
    .map(g => g.id);

  try {
    await pool.query(
      `INSERT INTO message_reads (message_id, user_id)
       SELECT m.id, $1
       FROM messages m
       WHERE (
         (m.recipient_type = 'USER' AND m.recipient_id = $1)
         OR (m.recipient_type = 'ALL')
         OR (m.sender_id = $1)
         ${realGroupIds.length > 0 ? `OR (m.recipient_type = 'GROUP' AND m.recipient_id = ANY($2))` : ''}
       )
       ON CONFLICT DO NOTHING`,
      realGroupIds.length > 0 ? [userId, realGroupIds] : [userId]
    );
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'Failed to mark all as read' });
  }
});

let BUILD_VERSION = 'dev';
try {
  const distPath2 = path.join(__dirname, '..', 'dist');
  if (fs.existsSync(path.join(distPath2, 'index.html'))) {
    const indexContent = fs.readFileSync(path.join(distPath2, 'index.html'), 'utf-8');
    BUILD_VERSION = crypto.createHash('md5').update(indexContent).digest('hex').slice(0, 12);
  }
} catch {}

app.get('/api/version', (req, res) => {
  res.json({ version: BUILD_VERSION, timestamp: Date.now() });
});

// --- BULL-BOARD: painel de monitoramento de filas ---
// Proteção em duas camadas:
//   1ª (primária)  — HTTP Basic Auth via BULL_BOARD_USER / BULL_BOARD_PASS (env vars).
//                    Dispara o diálogo nativo do navegador; credenciais independentes do CRM.
//   1ª (fallback)  — requireAdminRole (JWT ADMIN) quando as env vars não estão configuradas.
//                    Garante que o painel NUNCA fique sem proteção.
try {
  const bullBoardAdapter = createBullBoardAdapter();

  const bbUser = process.env.BULL_BOARD_USER;
  const bbPass = process.env.BULL_BOARD_PASS;

  let bbAuthMiddleware;
  if (bbUser && bbPass) {
    bbAuthMiddleware = basicAuth({
      users: { [bbUser]: bbPass },
      challenge: true,
      realm: 'Painel de Filas CRM',
    });
    console.log('[Bull-Board] Proteção: HTTP Basic Auth (BULL_BOARD_USER / BULL_BOARD_PASS).');
  } else {
    bbAuthMiddleware = requireAdminRole;
    logger.warn(
      '[Bull-Board] ATENÇÃO: BULL_BOARD_USER / BULL_BOARD_PASS não configurados. ' +
      'Usando fallback JWT-ADMIN. Defina essas variáveis nos Secrets para ativar o Basic Auth.'
    );
  }

  app.use('/admin/filas', bbAuthMiddleware, bullBoardAdapter.getRouter());
  console.log('[Bull-Board] Painel disponível em /admin/filas.');
} catch (err) {
  logger.warn('[Bull-Board] Falha ao inicializar o painel — servidor continua normalmente.', err.message);
}

if (process.env.NODE_ENV === 'production') {
  const distPath = path.join(__dirname, '..', 'dist');
  configureProductionFrontend(app, distPath);
}

const PORT = process.env.PORT || 5000;

async function ensureMasterUser() {
  const MASTER_ID    = '55555555-0001-4000-8000-000000000001';
  const UNIT_ID      = 'aaaaaaaa-0001-4000-8000-000000000001';
  const MASTER_EMAIL = 'master@invicta.com.br';
  const MASTER_PWD_RESET = process.env.MASTER_PASSWORD_RESET;
  const client = await pool.connect();
  try {
    const existing = await client.query(
      'SELECT id, initial_password FROM users WHERE email = $1',
      [MASTER_EMAIL]
    );

    if (existing.rows.length === 0) {
      const plainPwd = MASTER_PWD_RESET || (process.env.NODE_ENV === 'production' ? crypto.randomBytes(16).toString('hex') : 'Invicta@2025');
      const hashedPassword = await bcrypt.hash(plainPwd, 12);
      const forceChange = !MASTER_PWD_RESET;
      await client.query(`
        INSERT INTO users (id, name, email, role, status, initial_password, force_change_password, failed_attempts, created_at, updated_at)
        VALUES ($1, 'Master Admin', $2, 'ADMIN', 'ATIVO', $3, $4, 0, NOW(), NOW())
      `, [MASTER_ID, MASTER_EMAIL, hashedPassword, forceChange]);
      if (MASTER_PWD_RESET) {
        console.log('[MASTER] master@invicta.com.br criado com a senha definida em MASTER_PASSWORD_RESET. Remova a secret.');
      } else if (process.env.NODE_ENV === 'production') {
        console.log('[MASTER] master@invicta.com.br criado com senha temporária aleatória. Use MASTER_PASSWORD_RESET para definir uma senha conhecida.');
      } else {
        console.log('[MASTER] master@invicta.com.br criado com senha padrão de desenvolvimento: Invicta@2025');
      }
    } else {
      if (MASTER_PWD_RESET) {
        const hashed = await bcrypt.hash(MASTER_PWD_RESET, 12);
        await client.query(
          'UPDATE users SET name=$1, role=$2, status=$3, initial_password=$4, force_change_password=false, failed_attempts=0, locked_at=NULL, session_version=session_version+1, updated_at=NOW() WHERE email=$5',
          ['Master Admin', 'ADMIN', 'ATIVO', hashed, MASTER_EMAIL]
        );
        console.log('[MASTER] Senha de master@invicta.com.br atualizada via MASTER_PASSWORD_RESET. Remova a secret.');
      } else {
        await client.query(
          'UPDATE users SET name=$1, role=$2, status=$3, updated_at=NOW() WHERE email=$4',
          ['Master Admin', 'ADMIN', 'ATIVO', MASTER_EMAIL]
        );
        console.log('[MASTER] master@invicta.com.br verificado (role/status ok).');
      }
    }

    const masterDefaults = JSON.stringify({
      id: MASTER_ID, name: 'Master Admin', role: 'ADMIN',
      email: MASTER_EMAIL, status: 'ATIVO', unitId: UNIT_ID,
      groupIds: ['g1']
    });
    await client.query(`
      UPDATE app_data
      SET value = jsonb_set(
        value::jsonb, '{users}',
        CASE
          WHEN value::jsonb->'users' @> $1::jsonb
          THEN (SELECT jsonb_agg(
                  CASE WHEN u->>'email' = $2
                  THEN $3::jsonb || u
                  ELSE u END)
                FROM jsonb_array_elements(value::jsonb->'users') u)
          ELSE value::jsonb->'users' || $3::jsonb
        END
      )
      WHERE key = 'portal_config'
    `, [JSON.stringify([{email: MASTER_EMAIL}]), MASTER_EMAIL, masterDefaults]);

  } catch (err) {
    logger.warn('[MASTER] ensureMasterUser failed:', err.message);
  } finally {
    client.release();
  }
}

async function ensureRoles() {
  const client = await pool.connect();
  try {
    const REQUIRED_ROLES = [
      {name:'Gerente Comercial',       participatesInScheduling:true,  sort:0},
      {name:'Consultor(a) de Negócios',participatesInScheduling:false, sort:1},
      {name:'Analista Jurídico',       participatesInScheduling:false, sort:2},
      {name:'Atendente',               participatesInScheduling:false, sort:3},
      {name:'Analista Comercial',      participatesInScheduling:true,  sort:5},
      {name:'Assistente Comercial',    participatesInScheduling:true,  sort:6},
      {name:'Analista Financeiro',     participatesInScheduling:false, sort:7},
      {name:'Auditora',                participatesInScheduling:false, sort:8},
    ];
    const existing = await client.query(`SELECT value FROM config_options WHERE option_type='role'`);
    const existingNames = new Set(existing.rows.map(r => {
      try { return JSON.parse(r.value).name; } catch { return r.value; }
    }));
    let added = 0;
    for (const r of REQUIRED_ROLES) {
      if (!existingNames.has(r.name)) {
        await client.query(
          `INSERT INTO config_options (id,option_type,value,sort_order) VALUES (gen_random_uuid(),'role',$1,$2)`,
          [JSON.stringify({name:r.name,participatesInScheduling:r.participatesInScheduling}), r.sort]
        );
        added++;
      }
    }
    if (added > 0) console.log(`[ROLES] Added ${added} missing role(s) to config_options`);
  } catch (err) {
    logger.warn('[ROLES] ensureRoles failed:', err.message);
  } finally {
    client.release();
  }
}

const SYSTEM_API_INTEGRATIONS = [
  {
    id: 'api-gotalk-login',
    name: 'GoTalk — Login',
    description: 'Autenticação no GoTalk. Retorna token Bearer válido por 24h.',
    baseUrl: 'https://app.gotalk.digital/user/login',
    method: 'POST',
    authType: 'BASIC',
    authUsername: '(env: GOTALK_LOGIN)',
    authPassword: '(env: GOTALK_PASSWORD)',
    headers: [{ key: 'Content-Type', value: 'application/json' }],
    bodyTemplate: '{\n  "login": "{{GOTALK_LOGIN}}",\n  "password": "{{GOTALK_PASSWORD}}"\n}',
  },
  {
    id: 'api-gotalk-send-message',
    name: 'GoTalk — Enviar Mensagem',
    description: 'Envia mensagem de texto para um contato via WhatsApp.',
    baseUrl: 'https://app.gotalk.digital/websocket/send-message',
    method: 'POST',
    authType: 'BEARER',
    authToken: '(token obtido via login)',
    headers: [{ key: 'Content-Type', value: 'application/json' }],
    bodyTemplate: '{\n  "channelId": "{{channelId}}",\n  "phone": "{{phone}}",\n  "message": "{{message}}"\n}',
  },
  {
    id: 'api-gotalk-send-file',
    name: 'GoTalk — Enviar Arquivo/Mídia',
    description: 'Envia arquivo (imagem, áudio, vídeo, documento) via WhatsApp.',
    baseUrl: 'https://app.gotalk.digital/websocket/send-message',
    method: 'POST',
    authType: 'BEARER',
    authToken: '(token obtido via login)',
    headers: [{ key: 'Content-Type', value: 'application/json' }],
    bodyTemplate: '{\n  "channelId": "{{channelId}}",\n  "phone": "{{phone}}",\n  "mediaUrl": "{{fileUrl}}",\n  "mediaName": "{{fileName}}"\n}',
  },
  {
    id: 'api-gotalk-contacts',
    name: 'GoTalk — Listar Contatos',
    description: 'Retorna página de contatos do canal. Paginado (9 por página).',
    baseUrl: 'https://app.gotalk.digital/contact/channel/:channelId/page/:page',
    method: 'GET',
    authType: 'BEARER',
    authToken: '(token obtido via login)',
    headers: [],
    bodyTemplate: '',
  },
  {
    id: 'api-gotalk-messages',
    name: 'GoTalk — Mensagens do Contato',
    description: 'Retorna atendimentos/mensagens de um contato específico.',
    baseUrl: 'https://app.gotalk.digital/attendance/contact/:contactId',
    method: 'GET',
    authType: 'BEARER',
    authToken: '(token obtido via login)',
    headers: [],
    bodyTemplate: '',
  },
  {
    id: 'api-gotalk-channel',
    name: 'GoTalk — Status do Canal',
    description: 'Verifica status de conexão do canal WhatsApp (channelConnected, status).',
    baseUrl: 'https://app.gotalk.digital/channel/:channelId',
    method: 'GET',
    authType: 'BEARER',
    authToken: '(token obtido via login)',
    headers: [],
    bodyTemplate: '',
  },
  {
    id: 'api-gotalk-templates-hsm',
    name: 'GoTalk — Templates HSM',
    description: 'Lista templates HSM aprovados pela Meta para o canal.',
    baseUrl: 'https://app.gotalk.digital/message/templates/channelId/:channelId',
    method: 'GET',
    authType: 'BEARER',
    authToken: '(token obtido via login)',
    headers: [],
    bodyTemplate: '',
  },
  {
    id: 'api-gotalk-active-notification',
    name: 'GoTalk — Comunicação Ativa (HSM)',
    description: 'Envia template HSM aprovado para contato fora da janela de 24h do WhatsApp.',
    baseUrl: 'https://app.gotalk.digital/message/send-active-notification',
    method: 'POST',
    authType: 'BEARER',
    authToken: '(token obtido via login)',
    headers: [{ key: 'Content-Type', value: 'application/json' }],
    bodyTemplate: '{\n  "channelId": "{{channelId}}",\n  "phone": "55{{phone}}",\n  "phoneIsFixed": false,\n  "contactName": "{{contactName}}",\n  "templateId": "{{templateId}}",\n  "category": "attendance",\n  "tag": { "1": "{{var1}}", "2": "{{var2}}" }\n}',
  },
  {
    id: 'api-openai-whisper',
    name: 'OpenAI — Transcrição Whisper',
    description: 'Transcreve áudios WhatsApp para texto usando o modelo whisper-1.',
    baseUrl: 'https://api.openai.com/v1/audio/transcriptions',
    method: 'POST',
    authType: 'BEARER',
    authToken: '(env: OPENAI_API_KEY)',
    headers: [{ key: 'Content-Type', value: 'multipart/form-data' }],
    bodyTemplate: '{\n  "model": "whisper-1",\n  "language": "pt"\n}',
  },
  {
    id: 'api-viacep',
    name: 'ViaCEP — Consulta de CEP',
    description: 'Busca endereço completo a partir do CEP brasileiro. API pública, sem autenticação.',
    baseUrl: 'https://viacep.com.br/ws/:cep/json/',
    method: 'GET',
    authType: 'NONE',
    headers: [],
    bodyTemplate: '',
  },
];

async function seedApiIntegrations() {
  try {
    const result = await pool.query("SELECT value FROM app_data WHERE key = 'portal_config'");
    if (result.rows.length === 0) return;

    const cfg = result.rows[0].value;
    const existing = Array.isArray(cfg.apiIntegrations) ? cfg.apiIntegrations : [];

    // Deduplicate by stable ID OR by functional key (name + method + baseUrl) to avoid
    // duplicating entries that the user may have added manually with different IDs.
    const existingIds = new Set(existing.map(a => a.id));
    const existingKeys = new Set(existing.map(a => `${a.method}|${(a.baseUrl || '').toLowerCase()}|${(a.name || '').toLowerCase()}`));

    const toAdd = SYSTEM_API_INTEGRATIONS.filter(api => {
      const funcKey = `${api.method}|${api.baseUrl.toLowerCase()}|${api.name.toLowerCase()}`;
      return !existingIds.has(api.id) && !existingKeys.has(funcKey);
    });

    if (toAdd.length === 0) return;

    cfg.apiIntegrations = [...existing, ...toAdd];
    await pool.query(
      `UPDATE app_data SET value = $1, updated_at = NOW() WHERE key = 'portal_config'`,
      [JSON.stringify(cfg)]
    );
    console.log(`[INIT] API Integrations: ${toAdd.length} entrada(s) adicionada(s) à guia API's.`);
    return toAdd.length;
  } catch (err) {
    logger.warn('[INIT] seedApiIntegrations falhou:', err.message);
    throw err;
  }
}

async function autoSeedIfNeeded() {
  // Auto-seed is DISABLED by default in all environments.
  // It only runs when AUTO_SEED=true is explicitly set — never in production
  // without this explicit opt-in. This prevents accidental data population
  // of the production database on deploy or restart.
  if (process.env.AUTO_SEED !== 'true') return;
  if (process.env.NODE_ENV === 'production') {
    logger.warn('[SEED] AUTO_SEED=true detectado em produção. Use ALLOW_SEED=true com o script scripts/seed.js para popular o banco de produção de forma controlada. Auto-seed ignorado.');
    return;
  }
  try {
    const check = await pool.query('SELECT COUNT(*) as cnt FROM admissions');
    const cnt = parseInt(check.rows[0].cnt, 10);
    if (cnt < 5) {
      console.log('[SEED] DEV DB vazio, executando seed de desenvolvimento...');
      const result = await runProductionSeed(pool);
      if (result.success) {
        console.log('[SEED] Seed concluído:', result.log.join(' | '));
      } else {
        logger.error('[SEED] Seed falhou:', result.error);
      }
    }
  } catch (err) {
    logger.warn('[SEED] Verificação de auto-seed falhou:', err.message);
  }
}

// ── Gotalk Messages Retention Job ─────────────────────────────────────────
// Runs once at startup and then every 24 hours.
// Moves gotalk_messages older than the configured retention period into the
// archive table and deletes them from the main table.
async function runRetentionJob() {
  try {
    const cfgRow = await pool.query(`SELECT value FROM retention_config WHERE key = 'gotalk_messages_retention_days'`);
    const retentionDays = cfgRow.rows.length ? parseInt(cfgRow.rows[0].value, 10) : 90;
    if (isNaN(retentionDays) || retentionDays <= 0) {
      console.log('[Retention] gotalk_messages retention disabled (days <= 0).');
      return;
    }

    // Explicit column list keeps INSERT/SELECT aligned regardless of table column order.
    // Includes all columns added by migrations 013–018 so no metadata is discarded.
    const result = await pool.query(`
      WITH archived AS (
        INSERT INTO gotalk_messages_archive
          (id, gotalk_message_id, gotalk_contact_id, client_id, phone_number,
           direction, body, message_type, attachment_url, attachment_name,
           attachment_mime_type, audio_transcript, area, operator_name, department,
           sent_at, read_at, imported_at, ack_status,
           attendance_id, gotalk_attendance_id_ext, attendance_history_id,
           idwpp, gotalk_channel_uuid,
           deleted_in_gotalk, deleted_in_gotalk_at, archived_at)
        SELECT
          id, gotalk_message_id, gotalk_contact_id, client_id, phone_number,
          direction, body, message_type, attachment_url, attachment_name,
          attachment_mime_type, audio_transcript, area, operator_name, department,
          sent_at, read_at, imported_at, ack_status,
          attendance_id, gotalk_attendance_id_ext, attendance_history_id,
          idwpp, gotalk_channel_uuid,
          deleted_in_gotalk, deleted_in_gotalk_at, NOW()
        FROM gotalk_messages
        WHERE imported_at < NOW() - ($1::INTEGER * INTERVAL '1 day')
        ON CONFLICT (id) DO NOTHING
        RETURNING id
      )
      DELETE FROM gotalk_messages
      WHERE id IN (SELECT id FROM archived)
    `, [retentionDays]);

    if (result.rowCount > 0) {
      console.log(`[Retention] Archived and deleted ${result.rowCount} gotalk_messages older than ${retentionDays} days.`);
    } else {
      console.log(`[Retention] No gotalk_messages to archive (threshold: ${retentionDays} days).`);
    }
  } catch (err) {
    logger.warn('[Retention] gotalk_messages retention job error:', err.message);
  }
}

function scheduleRetentionJob() {
  const TWENTY_FOUR_HOURS = 24 * 60 * 60 * 1000;
  // Run once 5 minutes after startup (allow DB to warm up) then daily
  setTimeout(() => {
    runRetentionJob();
    setInterval(runRetentionJob, TWENTY_FOUR_HOURS);
  }, 5 * 60 * 1000);
  console.log('[Retention] gotalk_messages retention job scheduled (daily, starting in 5 min).');
}


async function applyAdminPasswordResetIfRequested() {
  const newPassword = process.env.ADMIN_PASSWORD_RESET;
  if (!newPassword) return;
  try {
    const hash = await bcrypt.hash(newPassword, 12);
    const result = await pool.query(
      `UPDATE users
          SET initial_password    = $1,
              force_change_password = false,
              failed_attempts     = 0,
               locked_at           = NULL,
               session_version     = session_version + 1,
               updated_at          = NOW()
        WHERE email = 'admin@financepro.com'
        RETURNING email`,
      [hash]
    );
    if (result.rowCount > 0) {
      console.log('[ADMIN_RESET] Senha do admin@financepro.com atualizada com sucesso. Remova a secret ADMIN_PASSWORD_RESET.');
    } else {
      logger.warn('[ADMIN_RESET] Usuário admin@financepro.com não encontrado.');
    }
  } catch (err) {
    logger.error('[ADMIN_RESET] Falha ao atualizar senha do admin:', err.message);
  }
}

app.use((err, req, res, next) => {
  const status = err.status || err.statusCode || 500;
  logger.error('Unhandled server error', {
    requestId: req.requestId,
    method: req.method,
    path: req.path,
    status,
    message: err.message,
    stack: process.env.NODE_ENV !== 'production' ? err.stack : undefined,
  });
  if (res.headersSent) return next(err);
  const body = { error: 'Internal Server Error' };
  if (process.env.NODE_ENV !== 'production') {
    body.details = err.message;
  }
  res.status(status).json(body);
});

const httpServer = http.createServer(app);

initDB().then(() => {
  // Nenhum subsistema com acesso ao banco inicia antes do preflight terminar.
  return initSocketServer(httpServer, pool);
}).then(() => {
  httpServer.listen(PORT, '0.0.0.0', async () => {
    console.log(`API server running on port ${PORT}`);
    if (process.env.NODE_ENV !== 'production') {
      await applyAdminPasswordResetIfRequested();
      await ensureRoles();
      await ensureMasterUser();
      autoSeedIfNeeded();
      seedApiIntegrations().catch(err => logger.warn('[INIT] seedApiIntegrations startup error:', err.message));
      // Sincroniza a tabela de bancos (FEBRABAN) com a BrasilAPI a cada inicialização.
      // Não bloqueia o startup — roda em background e é resiliente a falhas de rede.
      syncFebrabanBanks(pool, logger).catch(err => logger.warn('[INIT] syncFebrabanBanks startup error:', err.message));
      scheduleRetentionJob();
    } else {
      logger.info('[INIT] Produção: escritas administrativas, seeds, sincronização de bancos e retenção automática desativadas.');
    }
    startScheduledMessagesJob(pool);
    startClientAttachmentReconciliationJob(pool);
    startPhotoChallengeCleanupJob(pool);
    startDataImportWorker(pool);
    startClientAttachmentAuditWorker();
    startAdmissionAttachmentMigrationWorker(pool, migrateNextAdmissionAttachment);
    // GoTalk poller runs in all environments (dev + production).
    // Previously restricted to production; now enabled everywhere so that the
    // failing standalone WhatsApp Worker doesn't block GoTalk polling in dev.
    try {
      if (process.env.GOTALK_LOGIN && process.env.GOTALK_PASSWORD) {
        const POLLER_LOCK_ID = 839271;
        let gotPollerLock = false;
        try {
          const lockResult = await pool.query('SELECT pg_try_advisory_lock($1) AS acquired', [POLLER_LOCK_ID]);
          gotPollerLock = lockResult.rows[0]?.acquired === true;
        } catch (lockErr) {
          logger.error('[INIT] Could not verify poller leadership; poller will remain stopped:', lockErr.message);
          gotPollerLock = false;
        }
        if (gotPollerLock) {
          await syncGotalkChannels(pool).catch(err =>
            logger.warn('[INIT] Aviso ao sincronizar canais GoTalk:', err.message)
          );
          startGotalkPoller(pool);
          logger.info('[INIT] GoTalk poller started (embedded in main server).');
        } else {
          logger.info('[INIT] GoTalk poller skipped — another instance holds the leader lock.');
        }
      } else {
        logger.warn('[INIT] GOTALK_LOGIN/GOTALK_PASSWORD not configured — GoTalk poller not started.');
      }
    } catch (workerErr) {
      logger.error('[INIT] Failed to start embedded GoTalk worker:', workerErr.message);
    }

    // uazapi recovery: job periódico que reconcilia mensagens perdidas entre webhooks.
    // Roda a cada 5 min, usa advisory lock para evitar duplicação em multi-réplica.
    startUazapiRecoveryJob(pool);

    // ── Keep-Alive — auto-ping a cada 3 min para evitar hibernação no Replit ──
    // O próprio servidor faz uma requisição HTTP para /ping, mantendo o processo
    // Node.js ativo. Isso evita que o Replit entre em modo de suspensão por
    // inatividade. Usa a URL interna (localhost) para não depender de DNS externo.
    startKeepAlive(PORT);
  });
}).catch(err => {
  logger.fatal('Failed to initialize database:', err.message);
  if (process.env.NODE_ENV === 'production') {
    // Do not leave a partially initialized production process alive. Socket
    // listeners and background clients may otherwise keep the event loop open
    // after a failed read-only schema/role check.
    process.exit(1);
  } else {
    process.exitCode = 1;
    pool.end().catch(() => {});
  }
});

// ── Keep-Alive — evita hibernação do processo no Replit
// O próprio servidor faz uma requisição HTTP para /ping a cada 3 minutos.
// Isso mantém o processo Node.js ativo e evita suspensão por inatividade.
// • Usa a URL interna (localhost) — não depende de DNS externo.
// • Response body é explicitamente consumido para evitar memory leaks.
// • Erros são silenciosos (apenas log) — não quebram o loop.
// • Interval é armazenado para cleanup no graceful shutdown.

let _keepAliveInterval = null;

function startKeepAlive(port) {
  if (_keepAliveInterval) {
    clearInterval(_keepAliveInterval);
    _keepAliveInterval = null;
  }

  const url = `http://localhost:${port}/ping`;
  const intervalMs = 3 * 60 * 1000; // 3 minutos

  _keepAliveInterval = setInterval(async () => {
    try {
      const res = await fetch(url, { method: 'GET' });
      const body = await res.text(); // consume body to free socket
      logger.info(`[Keep-Alive] Self-ping OK — status=${res.status} body="${body}"`);
    } catch (err) {
      logger.warn(`[Keep-Alive] Self-ping failed: ${err.message}`);
    }
  }, intervalMs);

  logger.info(`[Keep-Alive] Auto-ping ativo — ${url} a cada ${intervalMs / 1000}s.`);
}

function stopKeepAlive() {
  if (_keepAliveInterval) {
    clearInterval(_keepAliveInterval);
    _keepAliveInterval = null;
    logger.info('[Keep-Alive] Intervalo de auto-ping encerrado.');
  }
}

// ── Graceful shutdown ─────────────────────────────────────────────────────────
// Fecha conexões Redis e PostgreSQL de forma limpa antes de encerrar o processo.
// Isso garante deploy sem perda de conexão no Autoscale (SIGTERM) e em Ctrl+C (SIGINT).
async function gracefulShutdown(signal) {
  logger.info(`[Shutdown] Recebido ${signal} — encerrando gracefully...`);
  stopKeepAlive();
  try {
    await closeRedisConnection();
    logger.info('[Shutdown] Conexões Redis fechadas.');
  } catch (err) {
    logger.warn('[Shutdown] Erro ao fechar Redis:', err.message);
  }
  try {
    await pool.end();
    logger.info('[Shutdown] Pool PostgreSQL encerrado.');
  } catch (err) {
    logger.warn('[Shutdown] Erro ao fechar pool PostgreSQL:', err.message);
  }
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT',  () => gracefulShutdown('SIGINT'));

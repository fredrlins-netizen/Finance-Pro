import { createCrudRoutes } from './crudFactory.js';

export function createProductsRoutes(pool) {
  return createCrudRoutes(pool, {
    table: 'products',
    columns: ['type', 'description', 'unit_id'],
    requiredFields: ['description'],
    searchColumns: ['description'],
    defaultSort: 'description',
    defaultOrder: 'ASC',
    dependencies: []
  });
}

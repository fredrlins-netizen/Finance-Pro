import { Router } from 'express';
import { createCrudRoutes } from './crudFactory.js';
import { isValidUUID } from '../middleware/validation.js';
import { linkClientRetroactively } from '../services/gotalkPoller.js';

// Normalize phone to pure digits (strip all non-digit characters)
function stripPhoneFormatting(v) {
  return v ? String(v).replace(/\D/g, '') : v;
}

export function createClientsRoutes(pool) {
  const baseRouter = createCrudRoutes(pool, {
    table: 'clients',
    columns: [
      'name', 'type', 'document', 'rg', 'phone', 'phone2',
      'is_whatsapp', 'email', 'profession', 'marital_status',
      'birth_date', 'cep', 'address', 'number', 'complement',
      'district', 'city', 'state', 'notes', 'natureza', 'blocked'
    ],
    requiredFields: ['name'],
    searchColumns: ['name', 'document', 'email', 'phone'],
    defaultSort: 'name',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'admissions', fk: 'client_id', label: 'Admissões' },
      { table: 'financial_titles', fk: 'client_id', label: 'Títulos Financeiros' },
      { table: 'appointments', fk: 'client_id', label: 'Agendamentos' },
      { table: 'client_attachments', fk: 'client_id', label: 'Documentos no Bucket' }
    ],
    beforeCreate: (body) => {
      if (body.phone) body.phone = stripPhoneFormatting(body.phone);
      if (body.phone2) body.phone2 = stripPhoneFormatting(body.phone2);
      return body;
    },
    beforeUpdate: (body) => {
      if (body.phone !== undefined) body.phone = stripPhoneFormatting(body.phone);
      if (body.phone2 !== undefined) body.phone2 = stripPhoneFormatting(body.phone2);
      return body;
    },
    afterCreate: async (record) => {
      if (record.phone || record.phone2) {
        linkClientRetroactively(pool, record.id, record.phone, record.phone2)
          .catch(err => console.warn('[Gotalk] afterCreate retrolink error:', err.message));
      }
    },
    afterUpdate: async (newRecord, _oldRecord) => {
      if (newRecord.phone || newRecord.phone2) {
        linkClientRetroactively(pool, newRecord.id, newRecord.phone, newRecord.phone2)
          .catch(err => console.warn('[Gotalk] afterUpdate retrolink error:', err.message));
      }
    },
  });

  const router = Router();
  router.use('/', baseRouter);

  router.get('/:id/admission-links', async (req, res) => {
    const { id } = req.params;
    if (!isValidUUID(id)) {
      return res.status(400).json({ error: 'ID inválido' });
    }
    try {
      const result = await pool.query(
        `SELECT
          a.id,
          a.contract_number,
          a.date,
          a.status,
          CASE
            WHEN a.client_id = $1 THEN 'RESPONSÁVEL'
            WHEN a.titular_client_id = $1 THEN 'TITULAR'
          END AS role,
          CASE
            WHEN a.client_id = $1 AND a.titular_client_id IS NOT NULL
              THEN json_build_object('clientId', a.titular_client_id, 'clientName', tc.name, 'role', 'TITULAR')
            WHEN a.titular_client_id = $1
              THEN json_build_object('clientId', a.client_id, 'clientName', rc.name, 'role', 'RESPONSÁVEL')
            ELSE NULL
          END AS other_client
        FROM admissions a
        LEFT JOIN clients tc ON tc.id = a.titular_client_id
        LEFT JOIN clients rc ON rc.id = a.client_id
        WHERE a.client_id = $1 OR a.titular_client_id = $1
        ORDER BY a.created_at DESC`,
        [id]
      );
      res.json({ data: result.rows });
    } catch (err) {
      console.error('GET /clients/:id/admission-links error:', err.message);
      res.status(500).json({ error: 'Erro ao buscar vínculos de admissão', details: err.message });
    }
  });

  return router;
}

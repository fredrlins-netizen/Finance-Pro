import { createCrudRoutes } from './crudFactory.js';

export function createSeriesRoutes(pool) {
  return createCrudRoutes(pool, {
    table: 'series',
    columns: ['sigla', 'description', 'general_number'],
    requiredFields: ['sigla'],
    searchColumns: ['sigla', 'description'],
    defaultSort: 'sigla',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'admissions', fk: 'series_id', label: 'Admissões' },
      { table: 'series_unit_numbering', fk: 'series_id', label: 'Numeração por unidade' }
    ]
  });
}

import { createCrudRoutes } from './crudFactory.js';

export function createCollaboratorsRoutes(pool) {
  return createCrudRoutes(pool, {
    table: 'collaborators',
    columns: [
      'name', 'photo_url', 'job_title', 'phone', 'is_whatsapp',
      'email', 'marital_status', 'birth_date', 'cep', 'address',
      'number', 'complement', 'district', 'city', 'state', 'notes',
      'unit_id', 'department_id', 'active'
    ],
    requiredFields: ['name'],
    searchColumns: ['name', 'email', 'phone', 'job_title'],
    defaultSort: 'name',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'admissions', fk: 'collaborator_id', label: 'Admissões' },
      { table: 'appointments', fk: 'collaborator_id', label: 'Agendamentos' },
      { table: 'schedule_blocks', fk: 'collaborator_id', label: 'Bloqueios de Agenda' }
    ]
  });
}

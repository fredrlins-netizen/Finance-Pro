import { createCrudRoutes } from './crudFactory.js';

export function createRolesRoutes(pool) {
  return createCrudRoutes(pool, {
    table: 'config_options',
    columns: ['option_type', 'value', 'sort_order'],
    requiredFields: ['value'],
    searchColumns: ['value'],
    defaultSort: 'sort_order',
    defaultOrder: 'ASC',
    dependencies: [],
    customListQuery: async (pool, req) => {
      const { limit, offset } = req.pagination;
      const searchTerm = req.searchTerm;

      const params = ['role'];
      let whereClause = 'WHERE "option_type" = $1';

      if (searchTerm) {
        params.push(`%${searchTerm}%`);
        whereClause += ` AND "value" ILIKE $${params.length}`;
      }

      const countResult = await pool.query(
        `SELECT COUNT(*) FROM "config_options" ${whereClause}`,
        params
      );
      const total = parseInt(countResult.rows[0].count, 10);

      const dataParams = [...params];
      dataParams.push(limit);
      dataParams.push(offset);

      const dataResult = await pool.query(
        `SELECT * FROM "config_options" ${whereClause} ORDER BY "sort_order" ASC, "value" ASC LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
        dataParams
      );

      return {
        data: dataResult.rows,
        total,
        page: req.pagination.page,
        limit,
        totalPages: Math.ceil(total / limit)
      };
    },
    beforeCreate: async (data, client, req) => {
      data.option_type = 'role';
      return data;
    }
  });
}

import { Router } from 'express';
import { createCrudRoutes } from './crudFactory.js';

export function createLookupsRoutes(pool) {
  const router = Router();

  const bearersRouter = createCrudRoutes(pool, {
    table: 'bearers',
    columns: ['code', 'name', 'type', 'associated_bank_account_id', 'status', 'agency_code', 'contract_code'],
    requiredFields: ['code', 'name'],
    searchColumns: ['code', 'name'],
    defaultSort: 'name',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'financial_titles', fk: 'bearer_id', label: 'Títulos financeiros' }
    ]
  });

  const departmentsRouter = createCrudRoutes(pool, {
    table: 'departments',
    columns: ['code', 'name', 'manager_name', 'status'],
    requiredFields: ['name'],
    searchColumns: ['code', 'name', 'manager_name'],
    defaultSort: 'name',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'financial_titles', fk: 'department_id', label: 'Títulos financeiros' }
    ]
  });

  const documentTypesRouter = createCrudRoutes(pool, {
    table: 'document_types',
    columns: ['description', 'category', 'is_fiscal', 'status', 'requires_doc_number'],
    requiredFields: ['description'],
    searchColumns: ['description'],
    defaultSort: 'description',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'financial_titles', fk: 'document_type_id', label: 'Títulos financeiros' }
    ]
  });

  const chartOfAccountsRouter = createCrudRoutes(pool, {
    table: 'chart_of_accounts',
    columns: ['code', 'name', 'type', 'parent_id', 'is_analytical', 'is_system'],
    requiredFields: ['code', 'name', 'type'],
    searchColumns: ['code', 'name'],
    defaultSort: 'code',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'financial_titles', fk: 'category_id', label: 'Títulos financeiros' }
    ]
  });

  const measurementUnitsRouter = createCrudRoutes(pool, {
    table: 'measurement_units',
    columns: ['name', 'conversion_factor'],
    requiredFields: ['name'],
    searchColumns: ['name'],
    defaultSort: 'name',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'products', fk: 'unit_id', label: 'Produtos' }
    ]
  });

  router.use('/bearers', bearersRouter);
  router.use('/departments', departmentsRouter);
  router.use('/document-types', documentTypesRouter);
  router.use('/chart-of-accounts', chartOfAccountsRouter);
  router.use('/measurement-units', measurementUnitsRouter);

  return router;
}

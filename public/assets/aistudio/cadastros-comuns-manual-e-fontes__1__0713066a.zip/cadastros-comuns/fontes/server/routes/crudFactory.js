import { Router } from 'express';
import { validateUUIDParam, validateBody, validateQueryParams } from '../middleware/validation.js';
import { createAuditHooks } from '../middleware/audit.js';
import { validateReferenceIds, stripReferenceColumns } from '../lib/referenceIdentity.js';

function toSnakeCase(str) {
  return str.replace(/([A-Z])/g, '_$1').toLowerCase();
}

function toCamelCase(str) {
  return str.replace(/_([a-z])/g, (_, c) => c.toUpperCase());
}

function rowToCamel(row) {
  if (!row || typeof row !== 'object') return row;
  const out = {};
  for (const key of Object.keys(row)) {
    if (key.startsWith('_reference_')) continue;
    out[toCamelCase(key)] = row[key];
  }
  return out;
}

function sanitizeFkValue(col, value) {
  if (value === '' && (col.endsWith('_id') || col === 'id')) {
    return null;
  }
  return value;
}

function normalizeBody(body, columns) {
  const out = {};
  for (const col of columns) {
    const camelKey = toCamelCase(col);
    if (body[col] !== undefined) {
      out[col] = sanitizeFkValue(col, body[col]);
    } else if (body[camelKey] !== undefined) {
      out[col] = sanitizeFkValue(col, body[camelKey]);
    }
  }
  return out;
}

async function rollbackTransaction(client) {
  if (!client) return;
  try {
    await client.query('ROLLBACK');
  } catch (error) {
    console.error('Falha ao reverter transação CRUD:', error.message);
  }
}

const ALLOWED_TABLES = new Set([
  'clients', 'collaborators', 'banks', 'bank_accounts', 'units',
  'modalities', 'products', 'series', 'bearers', 'departments',
  'document_types', 'chart_of_accounts', 'measurement_units',
  'admissions', 'financial_titles', 'title_settlements',
  'appointments', 'schedule_blocks', 'users', 'user_groups',
  'service_items', 'config_options', 'companies', 'legal_processes',
  'bank_movements', 'whatsapp_templates'
]);

function createCrudRoutes(pool, config) {
  const {
    table,
    columns,
    requiredFields = [],
    searchColumns = [],
    defaultSort = 'created_at',
    defaultOrder = 'DESC',
    dependencies = [],
    references = [],
    beforeCreate,
    beforeUpdate,
    beforeDelete,
    afterCreate: userAfterCreate,
    afterUpdate: userAfterUpdate,
    afterDelete: userAfterDelete,
    customListQuery,
    customGetQuery,
    disableAudit = false
  } = config;

  const auditHooks = disableAudit ? null : createAuditHooks(pool, table);

  const afterCreate = async (record, client, req) => {
    if (userAfterCreate) await userAfterCreate(record, client, req);
    if (auditHooks) await auditHooks.afterCreate(record, client, req);
  };
  const afterUpdate = async (newRecord, oldRecord, client, req) => {
    if (userAfterUpdate) await userAfterUpdate(newRecord, oldRecord, client, req);
    if (auditHooks) await auditHooks.afterUpdate(newRecord, oldRecord, client, req);
  };
  const afterDelete = async (record, client, req) => {
    if (userAfterDelete) await userAfterDelete(record, client, req);
    if (auditHooks) await auditHooks.afterDelete(record, client, req);
  };

  if (!ALLOWED_TABLES.has(table)) {
    throw new Error(`Table "${table}" is not in the allowed tables list`);
  }

  const router = Router();

  router.get('/', validateQueryParams, async (req, res) => {
    try {
      const { limit, offset } = req.pagination;
      const searchTerm = req.searchTerm;
      let sortField = req.sortField;
      const sortOrder = req.sortOrder || defaultOrder;

      if (sortField && !columns.includes(sortField)) {
        sortField = '';
      }
      const orderBy = sortField || defaultSort;

      if (customListQuery) {
        const result = await customListQuery(pool, req);
        return res.json(result);
      }

      const params = [];
      const conditions = [];

      if (searchTerm && searchColumns.length > 0) {
        const searchConditions = searchColumns.map((col) => {
          params.push(`%${searchTerm}%`);
          return `"${col}" ILIKE $${params.length}`;
        });
        conditions.push(`(${searchConditions.join(' OR ')})`);
      }

      if (req.queryFilters) {
        const allowedCols = new Set(columns.concat(['id', 'created_at', 'updated_at']));
        for (const [col, val] of Object.entries(req.queryFilters)) {
          if (allowedCols.has(col)) {
            params.push(val);
            conditions.push(`"${col}" = $${params.length}`);
          }
        }
      }

      if (req.queryIlikeFilters) {
        const allowedCols = new Set(columns.concat(['id', 'created_at', 'updated_at']));
        for (const [col, val] of Object.entries(req.queryIlikeFilters)) {
          if (allowedCols.has(col)) {
            params.push(`%${val}%`);
            conditions.push(`"${col}" ILIKE $${params.length}`);
          }
        }
      }

      const whereClause = conditions.length ? `WHERE ${conditions.join(' AND ')}` : '';

      const countResult = await pool.query(
        `SELECT COUNT(*) FROM "${table}" ${whereClause}`,
        params
      );
      const total = parseInt(countResult.rows[0].count, 10);

      const dataParams = [...params];
      dataParams.push(limit);
      dataParams.push(offset);

      const dataResult = await pool.query(
        `SELECT * FROM "${table}" ${whereClause} ORDER BY "${orderBy}" ${sortOrder} LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
        dataParams
      );

      res.json({
        data: dataResult.rows.map(rowToCamel),
        total,
        page: req.pagination.page,
        limit,
        totalPages: Math.ceil(total / limit)
      });
    } catch (err) {
      console.error(`GET /${table} error:`, err.message);
      res.status(500).json({ error: 'Erro ao listar registros', details: err.message });
    }
  });

  router.get('/:id', validateUUIDParam, async (req, res) => {
    try {
      if (customGetQuery) {
        const result = await customGetQuery(pool, req.params.id, req);
        if (!result) return res.status(404).json({ error: 'Registro não encontrado' });
        return res.json({ data: stripReferenceColumns(result) });
      }

      const result = await pool.query(`SELECT * FROM "${table}" WHERE id = $1`, [req.params.id]);
      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Registro não encontrado' });
      }
      res.json({ data: rowToCamel(result.rows[0]) });
    } catch (err) {
      console.error(`GET /${table}/:id error:`, err.message);
      if (err.statusCode >= 400 && err.statusCode < 500)
        return res.status(err.statusCode).json({ error: err.message });
      res.status(500).json({ error: 'Erro ao buscar registro', details: err.message });
    }
  });

  router.post('/', validateBody(requiredFields), async (req, res) => {
    let client;
    try {
      client = await pool.connect();
      await client.query('BEGIN');

      let data = { ...req.body, ...normalizeBody(req.body, columns) };
      delete data.id;
      await validateReferenceIds(client, data, references);

      if (beforeCreate) {
        data = await beforeCreate(data, client, req);
        if (!data) {
          await client.query('ROLLBACK');
          return;
        }
      }

      const allowedData = normalizeBody(data, columns);

      const fields = Object.keys(allowedData);
      const values = Object.values(allowedData);
      const placeholders = values.map((_, i) => `$${i + 1}`);

      const result = await client.query(
        `INSERT INTO "${table}" (${fields.map(f => `"${f}"`).join(', ')}) VALUES (${placeholders.join(', ')}) RETURNING *`,
        values
      );

      if (afterCreate) {
        await afterCreate(result.rows[0], client, req);
      }

      await client.query('COMMIT');
      res.status(201).json({ data: rowToCamel(result.rows[0]) });
    } catch (err) {
      await rollbackTransaction(client);
      console.error(`POST /${table} error:`, err.message);
      if (err.code === '23505') {
        return res.status(409).json({ error: 'Registro duplicado', details: err.detail });
      }
      if (err.code === '23503' || (err.code === '23514' && err.constraint?.endsWith('_identity'))) {
        return res.status(400).json({ error: 'Referência inválida', details: err.detail });
      }
      const status = err.statusCode && err.statusCode >= 400 && err.statusCode < 500 ? err.statusCode : 500;
      res.status(status).json({ error: 'Erro ao criar registro', details: err.message });
    } finally {
      client?.release();
    }
  });

  router.put('/:id', validateUUIDParam, validateBody([]), async (req, res) => {
    let client;
    try {
      client = await pool.connect();
      await client.query('BEGIN');

      const existing = await client.query(`SELECT * FROM "${table}" WHERE id = $1`, [req.params.id]);
      if (existing.rows.length === 0) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Registro não encontrado' });
      }

      let data = { ...req.body, ...normalizeBody(req.body, columns) };
      delete data.id;
      delete data.created_at;
      delete data.createdAt;
      await validateReferenceIds(client, data, references);

      if (beforeUpdate) {
        data = await beforeUpdate(data, existing.rows[0], client, req);
        if (!data) {
          await client.query('ROLLBACK');
          return;
        }
      }

      const allowedData = normalizeBody(data, columns);

      if (Object.keys(allowedData).length === 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Nenhum campo válido para atualizar' });
      }

      // Some lookup tables intentionally have no update timestamp.
      if (Object.hasOwn(existing.rows[0], 'updated_at')) {
        allowedData.updated_at = new Date().toISOString();
      }

      const setClauses = [];
      const values = [];
      let paramIndex = 1;
      for (const [field, value] of Object.entries(allowedData)) {
        setClauses.push(`"${field}" = $${paramIndex}`);
        values.push(value);
        paramIndex++;
      }
      values.push(req.params.id);

      const result = await client.query(
        `UPDATE "${table}" SET ${setClauses.join(', ')} WHERE id = $${paramIndex} RETURNING *`,
        values
      );

      if (afterUpdate) {
        await afterUpdate(result.rows[0], existing.rows[0], client, req);
      }

      await client.query('COMMIT');
      res.json({ data: rowToCamel(result.rows[0]) });
    } catch (err) {
      await rollbackTransaction(client);
      console.error(`PUT /${table}/:id error:`, err.message);
      if (err.code === '23505') {
        return res.status(409).json({ error: 'Registro duplicado', details: err.detail });
      }
      if (err.code === '23503' || (err.code === '23514' && err.constraint?.endsWith('_identity'))) {
        return res.status(400).json({ error: 'Referência inválida', details: err.detail });
      }
      const status = err.statusCode && err.statusCode >= 400 && err.statusCode < 500 ? err.statusCode : 500;
      res.status(status).json({ error: 'Erro ao atualizar registro', details: err.message });
    } finally {
      client?.release();
    }
  });

  router.delete('/:id', validateUUIDParam, async (req, res) => {
    let client;
    try {
      client = await pool.connect();
      await client.query('BEGIN');

      // Serialize client removal with foreign-key inserts, so a concurrent
      // attachment cannot arrive after dependency checks and be cascaded away.
      const existing = await client.query(`SELECT * FROM "${table}" WHERE id = $1${table === 'clients' ? ' FOR UPDATE' : ''}`, [req.params.id]);
      if (existing.rows.length === 0) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Registro não encontrado' });
      }

      for (const dep of dependencies) {
        const depResult = await client.query(
          `SELECT COUNT(*) FROM "${dep.table}" WHERE "${dep.fk}" = $1`,
          [req.params.id]
        );
        if (parseInt(depResult.rows[0].count, 10) > 0) {
          await client.query('ROLLBACK');
          return res.status(409).json({
            error: 'Não é possível excluir',
            details: `Existem ${depResult.rows[0].count} registro(s) vinculado(s) em ${dep.label || dep.table}`
          });
        }
      }

      if (beforeDelete) {
        const canDelete = await beforeDelete(existing.rows[0], client, req);
        if (canDelete === false) {
          await client.query('ROLLBACK');
          return;
        }
      }

      await client.query(`DELETE FROM "${table}" WHERE id = $1`, [req.params.id]);

      if (afterDelete) {
        await afterDelete(existing.rows[0], client, req);
      }

      await client.query('COMMIT');
      res.json({ success: true, message: 'Registro excluído com sucesso' });
    } catch (err) {
      await rollbackTransaction(client);
      console.error(`DELETE /${table}/:id error:`, err.message);
      if (err.code === '23503') {
        return res.status(409).json({ error: 'Não é possível excluir um cadastro que possui registros vinculados.' });
      }
      const statusCode = Number.isInteger(err.statusCode) && err.statusCode >= 400 && err.statusCode < 500
        ? err.statusCode
        : 500;
      res.status(statusCode).json({
        error: statusCode === 500 ? 'Erro ao excluir registro' : err.message,
        details: err.message
      });
    } finally {
      client?.release();
    }
  });

  return router;
}

export { createCrudRoutes };

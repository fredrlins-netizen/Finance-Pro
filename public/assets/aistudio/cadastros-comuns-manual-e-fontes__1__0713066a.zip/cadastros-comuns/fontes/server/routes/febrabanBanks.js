import { Router } from 'express';

const BRASILAPI_URL = 'https://brasilapi.com.br/api/banks/v1';

/**
 * Busca a lista de bancos na BrasilAPI e faz upsert na tabela febraban_banks.
 * Apenas registros COM código (code != null) são gravados — instituições sem
 * código de compensação são ignoradas (decisão do produto: ocultar do dropdown).
 *
 * É resiliente: qualquer falha de rede/API apenas registra um aviso e mantém os
 * dados já existentes na tabela. Nunca lança para não derrubar o startup.
 */
export async function syncFebrabanBanks(pool, logger = console) {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);
    let res;
    try {
      res = await fetch(BRASILAPI_URL, { signal: controller.signal });
    } finally {
      clearTimeout(timeout);
    }
    if (!res.ok) {
      logger.warn(`[FebrabanBanks] BrasilAPI retornou status ${res.status} — mantendo dados existentes.`);
      return { ok: false, count: 0 };
    }
    const data = await res.json();
    if (!Array.isArray(data)) {
      logger.warn('[FebrabanBanks] Resposta inesperada da BrasilAPI — mantendo dados existentes.');
      return { ok: false, count: 0 };
    }

    const rows = data
      .filter(b => b && b.code !== null && b.code !== undefined)
      .map(b => ({
        code: String(b.code).padStart(3, '0'),
        name: String(b.name || b.fullName || '').trim(),
        full_name: b.fullName ? String(b.fullName).trim() : null,
        ispb: b.ispb ? String(b.ispb).trim() : null,
      }))
      .filter(b => b.name);

    let count = 0;
    for (const b of rows) {
      await pool.query(
        `INSERT INTO febraban_banks (code, name, full_name, ispb, updated_at)
         VALUES ($1, $2, $3, $4, NOW())
         ON CONFLICT (code) DO UPDATE SET
           name = EXCLUDED.name,
           full_name = EXCLUDED.full_name,
           ispb = EXCLUDED.ispb,
           updated_at = NOW()`,
        [b.code, b.name, b.full_name, b.ispb]
      );
      count++;
    }
    logger.info(`[FebrabanBanks] Sincronizados ${count} bancos da BrasilAPI.`);
    return { ok: true, count };
  } catch (err) {
    logger.warn(`[FebrabanBanks] Falha ao sincronizar com a BrasilAPI: ${err.message} — mantendo dados existentes.`);
    return { ok: false, count: 0 };
  }
}

export function createFebrabanBanksRoutes(pool) {
  const router = Router();

  // GET /api/febraban-banks — lista completa para o dropdown do cadastro de bancos.
  router.get('/', async (_req, res) => {
    try {
      const result = await pool.query(
        `SELECT code, name, full_name AS "fullName", ispb
         FROM febraban_banks
         ORDER BY name ASC`
      );
      res.json({ banks: result.rows });
    } catch (err) {
      console.error('[FebrabanBanks] GET / error:', err.message);
      res.status(500).json({ error: err.message });
    }
  });

  return router;
}

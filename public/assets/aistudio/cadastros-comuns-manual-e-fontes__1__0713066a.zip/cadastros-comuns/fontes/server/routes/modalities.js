import { createCrudRoutes } from './crudFactory.js';

export function createModalitiesRoutes(pool) {
  return createCrudRoutes(pool, {
    table: 'modalities',
    columns: ['type', 'description'],
    requiredFields: ['type'],
    searchColumns: ['type', 'description'],
    defaultSort: 'type',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'admissions', fk: 'modality_id', label: 'Admissões' }
    ]
  });
}

import { Router } from 'express';
import { createCrudRoutes } from './crudFactory.js';
import { validateUUIDParam, validateBody, validateQueryParams } from '../middleware/validation.js';

export function createBanksRoutes(pool) {
  const bankRouter = createCrudRoutes(pool, {
    table: 'banks',
    columns: ['name', 'status', 'febraban_code', 'notes'],
    requiredFields: ['name'],
    searchColumns: ['name', 'febraban_code'],
    defaultSort: 'name',
    defaultOrder: 'ASC',
    dependencies: [
      { table: 'admissions', fk: 'bank_id', label: 'Admissões' },
      { table: 'bank_accounts', fk: 'bank_id', label: 'Contas Bancárias' }
    ]
  });

  bankRouter.get('/:id/accounts', validateUUIDParam, validateQueryParams, async (req, res) => {
    try {
      const { limit, offset } = req.pagination;
      const searchTerm = req.searchTerm;

      const params = [req.params.id];
      let whereClause = 'WHERE "bank_id" = $1';

      if (searchTerm) {
        params.push(`%${searchTerm}%`);
        whereClause += ` AND ("description" ILIKE $${params.length} OR "account_number" ILIKE $${params.length})`;
      }

      const countResult = await pool.query(
        `SELECT COUNT(*) FROM "bank_accounts" ${whereClause}`,
        params
      );
      const total = parseInt(countResult.rows[0].count, 10);

      const dataParams = [...params];
      dataParams.push(limit);
      dataParams.push(offset);

      const dataResult = await pool.query(
        `SELECT * FROM "bank_accounts" ${whereClause} ORDER BY "description" ASC LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
        dataParams
      );

      res.json({
        data: dataResult.rows,
        total,
        page: req.pagination.page,
        limit,
        totalPages: Math.ceil(total / limit)
      });
    } catch (err) {
      console.error('GET /banks/:id/accounts error:', err.message);
      res.status(500).json({ error: 'Erro ao listar contas bancárias', details: err.message });
    }
  });

  bankRouter.post('/:id/accounts', validateUUIDParam, validateBody(['description']), async (req, res) => {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      const bankCheck = await client.query('SELECT id, name FROM "banks" WHERE id = $1', [req.params.id]);
      if (bankCheck.rows.length === 0) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Banco não encontrado' });
      }

      const data = { ...req.body };
      delete data.id;
      data.bank_id = req.params.id;
      if (!data.bank_name) {
        data.bank_name = bankCheck.rows[0].name;
      }

      const allowedColumns = [
        'description', 'account_type', 'bank_id', 'bank_name', 'agency',
        'account_number', 'account_nature', 'agency_name', 'assignor_number',
        'initial_balance', 'initial_balance_date', 'current_balance',
        'is_default', 'status'
      ];

      const allowedData = {};
      for (const col of allowedColumns) {
        if (data[col] !== undefined) {
          allowedData[col] = data[col];
        }
      }

      const fields = Object.keys(allowedData);
      const values = Object.values(allowedData);
      const placeholders = values.map((_, i) => `$${i + 1}`);

      const result = await client.query(
        `INSERT INTO "bank_accounts" (${fields.map(f => `"${f}"`).join(', ')}) VALUES (${placeholders.join(', ')}) RETURNING *`,
        values
      );

      await client.query('COMMIT');
      res.status(201).json({ data: result.rows[0] });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error('POST /banks/:id/accounts error:', err.message);
      if (err.code === '23505') {
        return res.status(409).json({ error: 'Conta duplicada', details: err.detail });
      }
      res.status(500).json({ error: 'Erro ao criar conta bancária', details: err.message });
    } finally {
      client.release();
    }
  });

  bankRouter.put('/:bankId/accounts/:accountId', async (req, res) => {
    const { bankId, accountId } = req.params;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      const existing = await client.query(
        'SELECT * FROM "bank_accounts" WHERE id = $1 AND bank_id = $2',
        [accountId, bankId]
      );
      if (existing.rows.length === 0) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Conta bancária não encontrada' });
      }

      const data = { ...req.body };
      delete data.id;
      delete data.created_at;
      delete data.bank_id;

      const allowedColumns = [
        'description', 'account_type', 'bank_name', 'agency',
        'account_number', 'account_nature', 'agency_name', 'assignor_number',
        'initial_balance', 'initial_balance_date', 'current_balance',
        'is_default', 'status'
      ];

      const allowedData = {};
      for (const col of allowedColumns) {
        if (data[col] !== undefined) {
          allowedData[col] = data[col];
        }
      }

      if (Object.keys(allowedData).length === 0) {
        await client.query('ROLLBACK');
        return res.status(400).json({ error: 'Nenhum campo válido para atualizar' });
      }

      allowedData.updated_at = new Date().toISOString();

      const setClauses = [];
      const values = [];
      let paramIndex = 1;
      for (const [field, value] of Object.entries(allowedData)) {
        setClauses.push(`"${field}" = $${paramIndex}`);
        values.push(value);
        paramIndex++;
      }
      values.push(accountId);
      values.push(bankId);

      const result = await client.query(
        `UPDATE "bank_accounts" SET ${setClauses.join(', ')} WHERE id = $${paramIndex} AND bank_id = $${paramIndex + 1} RETURNING *`,
        values
      );

      await client.query('COMMIT');
      res.json({ data: result.rows[0] });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error('PUT /banks/:bankId/accounts/:accountId error:', err.message);
      res.status(500).json({ error: 'Erro ao atualizar conta bancária', details: err.message });
    } finally {
      client.release();
    }
  });

  bankRouter.delete('/:bankId/accounts/:accountId', async (req, res) => {
    const { bankId, accountId } = req.params;
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      const existing = await client.query(
        'SELECT * FROM "bank_accounts" WHERE id = $1 AND bank_id = $2',
        [accountId, bankId]
      );
      if (existing.rows.length === 0) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Conta bancária não encontrada' });
      }

      const depCheck = await pool.query(
        'SELECT COUNT(*) FROM "bank_movements" WHERE "bank_account_id" = $1',
        [accountId]
      );
      if (parseInt(depCheck.rows[0].count, 10) > 0) {
        await client.query('ROLLBACK');
        return res.status(409).json({
          error: 'Não é possível excluir',
          details: `Existem ${depCheck.rows[0].count} movimento(s) bancário(s) vinculado(s)`
        });
      }

      await client.query('DELETE FROM "bank_accounts" WHERE id = $1 AND bank_id = $2', [accountId, bankId]);

      await client.query('COMMIT');
      res.json({ success: true, message: 'Conta bancária excluída com sucesso' });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error('DELETE /banks/:bankId/accounts/:accountId error:', err.message);
      res.status(500).json({ error: 'Erro ao excluir conta bancária', details: err.message });
    } finally {
      client.release();
    }
  });

  bankRouter.get('/:id/services', validateUUIDParam, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT bs.*, m.description AS modality_description
         FROM "bank_services" bs
         LEFT JOIN "modalities" m ON m.id = bs.modality_id
         WHERE bs."bank_id" = $1 ORDER BY bs."name" ASC`,
        [req.params.id]
      );
      res.json({ data: result.rows, total: result.rows.length });
    } catch (err) {
      console.error('GET /banks/:id/services error:', err.message);
      res.status(500).json({ error: 'Erro ao listar serviços bancários', details: err.message });
    }
  });

  bankRouter.put('/:id/services', validateUUIDParam, async (req, res) => {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      const bankId = req.params.id;
      const bankCheck = await client.query('SELECT id FROM "banks" WHERE id = $1', [bankId]);
      if (bankCheck.rows.length === 0) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Banco não encontrado' });
      }

      await client.query('DELETE FROM "bank_services" WHERE "bank_id" = $1', [bankId]);

      const services = Array.isArray(req.body.services) ? req.body.services : [];
      for (const srv of services) {
        const srvId = srv.id && /^[0-9a-f-]{36}$/i.test(srv.id) ? srv.id : undefined;
        const modalityId = srv.modalityId && /^[0-9a-f-]{36}$/i.test(srv.modalityId) ? srv.modalityId : null;
        if (srvId) {
          await client.query(
            'INSERT INTO "bank_services" (id, bank_id, name, negotiation_percentage, modality_id) VALUES ($1, $2, $3, $4, $5)',
            [srvId, bankId, srv.name || '', parseFloat(srv.negotiationPercentage) || 0, modalityId]
          );
        } else {
          await client.query(
            'INSERT INTO "bank_services" (bank_id, name, negotiation_percentage, modality_id) VALUES ($1, $2, $3, $4)',
            [bankId, srv.name || '', parseFloat(srv.negotiationPercentage) || 0, modalityId]
          );
        }
      }

      await client.query('COMMIT');
      const updated = await pool.query(
        `SELECT bs.*, m.description AS modality_description
         FROM "bank_services" bs
         LEFT JOIN "modalities" m ON m.id = bs.modality_id
         WHERE bs."bank_id" = $1 ORDER BY bs."name" ASC`,
        [bankId]
      );
      res.json({ data: updated.rows, total: updated.rows.length });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error('PUT /banks/:id/services error:', err.message);
      res.status(500).json({ error: 'Erro ao salvar serviços bancários', details: err.message });
    } finally {
      client.release();
    }
  });

  // ── Contatos do banco ───────────────────────────────────────────────────────

  bankRouter.get('/:id/contacts', validateUUIDParam, async (req, res) => {
    try {
      const result = await pool.query(
        `SELECT id, bank_id, name, sector, phone, mobile, is_whatsapp, email, created_at
         FROM bank_contacts
         WHERE bank_id = $1
         ORDER BY name ASC`,
        [req.params.id]
      );
      res.json({ data: result.rows, total: result.rows.length });
    } catch (err) {
      console.error('GET /banks/:id/contacts error:', err.message);
      res.status(500).json({ error: 'Erro ao listar contatos', details: err.message });
    }
  });

  bankRouter.put('/:id/contacts', validateUUIDParam, async (req, res) => {
    const client = await pool.connect();
    try {
      await client.query('BEGIN');

      const bankId = req.params.id;
      const bankCheck = await client.query('SELECT id FROM banks WHERE id = $1', [bankId]);
      if (bankCheck.rows.length === 0) {
        await client.query('ROLLBACK');
        return res.status(404).json({ error: 'Banco não encontrado' });
      }

      await client.query('DELETE FROM bank_contacts WHERE bank_id = $1', [bankId]);

      const contacts = Array.isArray(req.body.contacts) ? req.body.contacts : [];
      for (const c of contacts) {
        const cId = c.id && /^[0-9a-f-]{36}$/i.test(c.id) ? c.id : undefined;
        if (cId) {
          await client.query(
            `INSERT INTO bank_contacts (id, bank_id, name, sector, phone, mobile, is_whatsapp, email)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8)`,
            [cId, bankId, c.name || '', c.sector || null, c.phone || null,
             c.mobile || null, c.isWhatsapp === true, c.email || null]
          );
        } else {
          await client.query(
            `INSERT INTO bank_contacts (bank_id, name, sector, phone, mobile, is_whatsapp, email)
             VALUES ($1, $2, $3, $4, $5, $6, $7)`,
            [bankId, c.name || '', c.sector || null, c.phone || null,
             c.mobile || null, c.isWhatsapp === true, c.email || null]
          );
        }
      }

      await client.query('COMMIT');
      const updated = await pool.query(
        `SELECT id, bank_id, name, sector, phone, mobile, is_whatsapp, email, created_at
         FROM bank_contacts WHERE bank_id = $1 ORDER BY name ASC`,
        [bankId]
      );
      res.json({ data: updated.rows, total: updated.rows.length });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error('PUT /banks/:id/contacts error:', err.message);
      res.status(500).json({ error: 'Erro ao salvar contatos', details: err.message });
    } finally {
      client.release();
    }
  });

  return bankRouter;
}

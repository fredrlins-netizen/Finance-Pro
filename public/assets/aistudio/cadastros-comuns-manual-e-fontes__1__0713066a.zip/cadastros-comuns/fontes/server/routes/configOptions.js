import { Router } from 'express';
import { validateUUIDParam, validateBody, validateQueryParams } from '../middleware/validation.js';

const VALID_OPTION_TYPES = [
  'maritalStatus',
  'jobTitle',
  'modalityType',
  'paymentType',
  'indicationType',
  'role'
];

export function createConfigOptionsRoutes(pool) {
  const router = Router();

  router.get('/types', (req, res) => {
    res.json({ data: VALID_OPTION_TYPES });
  });

  router.get('/:optionType', validateQueryParams, async (req, res) => {
    try {
      const { optionType } = req.params;
      if (!VALID_OPTION_TYPES.includes(optionType)) {
        return res.status(400).json({ error: 'Tipo de opção inválido', details: `Tipos válidos: ${VALID_OPTION_TYPES.join(', ')}` });
      }

      const { limit, offset } = req.pagination;
      const searchTerm = req.searchTerm;

      const params = [optionType];
      let whereClause = 'WHERE "option_type" = $1';

      if (searchTerm) {
        params.push(`%${searchTerm}%`);
        whereClause += ` AND "value" ILIKE $${params.length}`;
      }

      const countResult = await pool.query(
        `SELECT COUNT(*) FROM "config_options" ${whereClause}`,
        params
      );
      const total = parseInt(countResult.rows[0].count, 10);

      const dataParams = [...params];
      dataParams.push(limit);
      dataParams.push(offset);

      const dataResult = await pool.query(
        `SELECT * FROM "config_options" ${whereClause} ORDER BY "sort_order" ASC, "value" ASC LIMIT $${dataParams.length - 1} OFFSET $${dataParams.length}`,
        dataParams
      );

      res.json({
        data: dataResult.rows,
        total,
        page: req.pagination.page,
        limit,
        totalPages: Math.ceil(total / limit)
      });
    } catch (err) {
      console.error(`GET /config-options/${req.params.optionType} error:`, err.message);
      res.status(500).json({ error: 'Erro ao listar opções', details: err.message });
    }
  });

  router.post('/:optionType', validateBody(['value']), async (req, res) => {
    try {
      const { optionType } = req.params;
      if (!VALID_OPTION_TYPES.includes(optionType)) {
        return res.status(400).json({ error: 'Tipo de opção inválido' });
      }

      const { value, sort_order } = req.body;

      const existing = await pool.query(
        'SELECT id FROM "config_options" WHERE "option_type" = $1 AND "value" = $2',
        [optionType, value]
      );
      if (existing.rows.length > 0) {
        return res.status(409).json({ error: 'Opção já existe', details: `O valor "${value}" já existe para o tipo "${optionType}"` });
      }

      const result = await pool.query(
        'INSERT INTO "config_options" ("option_type", "value", "sort_order") VALUES ($1, $2, $3) RETURNING *',
        [optionType, value, sort_order || 0]
      );

      res.status(201).json({ data: result.rows[0] });
    } catch (err) {
      console.error(`POST /config-options/${req.params.optionType} error:`, err.message);
      res.status(500).json({ error: 'Erro ao criar opção', details: err.message });
    }
  });

  router.put('/:optionType/:id', validateUUIDParam, validateBody([]), async (req, res) => {
    try {
      const { optionType, id } = req.params;
      if (!VALID_OPTION_TYPES.includes(optionType)) {
        return res.status(400).json({ error: 'Tipo de opção inválido' });
      }

      const { value, sort_order } = req.body;

      const existing = await pool.query(
        'SELECT * FROM "config_options" WHERE id = $1 AND "option_type" = $2',
        [id, optionType]
      );
      if (existing.rows.length === 0) {
        return res.status(404).json({ error: 'Opção não encontrada' });
      }

      const setClauses = [];
      const values = [];
      let paramIndex = 1;

      if (value !== undefined) {
        setClauses.push(`"value" = $${paramIndex}`);
        values.push(value);
        paramIndex++;
      }
      if (sort_order !== undefined) {
        setClauses.push(`"sort_order" = $${paramIndex}`);
        values.push(sort_order);
        paramIndex++;
      }

      if (setClauses.length === 0) {
        return res.status(400).json({ error: 'Nenhum campo válido para atualizar' });
      }

      values.push(id);
      values.push(optionType);

      const result = await pool.query(
        `UPDATE "config_options" SET ${setClauses.join(', ')} WHERE id = $${paramIndex} AND "option_type" = $${paramIndex + 1} RETURNING *`,
        values
      );

      res.json({ data: result.rows[0] });
    } catch (err) {
      console.error(`PUT /config-options/${req.params.optionType}/${req.params.id} error:`, err.message);
      res.status(500).json({ error: 'Erro ao atualizar opção', details: err.message });
    }
  });

  router.delete('/:optionType/:id', validateUUIDParam, async (req, res) => {
    try {
      const { optionType, id } = req.params;
      if (!VALID_OPTION_TYPES.includes(optionType)) {
        return res.status(400).json({ error: 'Tipo de opção inválido' });
      }

      const result = await pool.query(
        'DELETE FROM "config_options" WHERE id = $1 AND "option_type" = $2 RETURNING id',
        [id, optionType]
      );

      if (result.rows.length === 0) {
        return res.status(404).json({ error: 'Opção não encontrada' });
      }

      res.json({ success: true, message: 'Opção excluída com sucesso' });
    } catch (err) {
      console.error(`DELETE /config-options/${req.params.optionType}/${req.params.id} error:`, err.message);
      res.status(500).json({ error: 'Erro ao excluir opção', details: err.message });
    }
  });

  router.post('/:optionType/bulk', validateBody(['values']), async (req, res) => {
    const client = await pool.connect();
    try {
      const { optionType } = req.params;
      if (!VALID_OPTION_TYPES.includes(optionType)) {
        return res.status(400).json({ error: 'Tipo de opção inválido' });
      }

      const { values } = req.body;
      if (!Array.isArray(values)) {
        return res.status(400).json({ error: 'O campo "values" deve ser um array de strings' });
      }

      await client.query('BEGIN');

      await client.query(
        'DELETE FROM "config_options" WHERE "option_type" = $1',
        [optionType]
      );

      const inserted = [];
      for (let i = 0; i < values.length; i++) {
        const val = typeof values[i] === 'string' ? values[i] : String(values[i]);
        const result = await client.query(
          'INSERT INTO "config_options" ("option_type", "value", "sort_order") VALUES ($1, $2, $3) RETURNING *',
          [optionType, val, i]
        );
        inserted.push(result.rows[0]);
      }

      await client.query('COMMIT');
      res.json({ data: inserted, total: inserted.length });
    } catch (err) {
      await client.query('ROLLBACK');
      console.error(`POST /config-options/${req.params.optionType}/bulk error:`, err.message);
      res.status(500).json({ error: 'Erro ao salvar opções em lote', details: err.message });
    } finally {
      client.release();
    }
  });

  return router;
}

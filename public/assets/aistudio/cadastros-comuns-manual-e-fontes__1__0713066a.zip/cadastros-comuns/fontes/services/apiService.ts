const API_BASE = '';
const MAX_RETRIES = 3;
const RETRY_BASE_DELAY = 500;
const DEFAULT_TIMEOUT = 15000;

export class ApiError extends Error {
  status: number;
  details?: string;

  constructor(message: string, status: number, details?: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.details = details;
  }
}

function getAuthHeaders(): Record<string, string> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  try {
    const stored = localStorage.getItem('finpro_unit');
    if (stored) {
      const unitId = JSON.parse(stored);
      if (unitId) headers['x-unit-id'] = unitId;
    }
  } catch {}
  return headers;
}

async function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

export interface ApiRequestOptions {
  method?: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
  body?: any;
  params?: Record<string, string | number | boolean | undefined>;
  timeout?: number;
  retries?: number;
  signal?: AbortSignal;
}

export interface ApiListResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface ApiItemResponse<T> {
  data: T;
}

function buildUrl(path: string, params?: Record<string, string | number | boolean | undefined>): string {
  const url = new URL(`${API_BASE}${path}`, window.location.origin);
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== '') {
        url.searchParams.set(key, String(value));
      }
    }
  }
  return url.toString();
}

export async function apiRequest<T = any>(
  path: string,
  options: ApiRequestOptions = {}
): Promise<T> {
  const {
    method = 'GET',
    body,
    params,
    timeout = DEFAULT_TIMEOUT,
    retries = MAX_RETRIES,
    signal: externalSignal,
  } = options;

  const url = buildUrl(path, params);
  const headers = getAuthHeaders();
  const isFormData = typeof FormData !== 'undefined' && body instanceof FormData;
  if (isFormData) delete headers['Content-Type'];
  const totalAttempts = Math.max(1, retries);

  for (let attempt = 1; attempt <= totalAttempts; attempt++) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeout);

    if (externalSignal) {
      if (externalSignal.aborted) {
        clearTimeout(timeoutId);
        throw new ApiError('Request aborted', 0);
      }
      externalSignal.addEventListener('abort', () => controller.abort(), { once: true });
    }

    try {
      const fetchOptions: RequestInit = {
        method,
        headers,
        signal: controller.signal,
        credentials: 'include',
      };

      if (body && method !== 'GET') {
        fetchOptions.body = isFormData ? body : JSON.stringify(body);
      }

      const response = await fetch(url, fetchOptions);
      clearTimeout(timeoutId);

      if (response.ok) {
        const json = await response.json();
        return json as T;
      }

      if (response.status < 500 || attempt === totalAttempts) {
        let errorBody: any = {};
        try {
          errorBody = await response.json();
        } catch {}
        throw new ApiError(
          errorBody.error || `Request failed with status ${response.status}`,
          response.status,
          errorBody.details
        );
      }

      await sleep(RETRY_BASE_DELAY * attempt);
    } catch (err) {
      clearTimeout(timeoutId);

      if (err instanceof ApiError) {
        throw err;
      }

      if ((err as Error).name === 'AbortError') {
        throw new ApiError('Request timeout or aborted', 0);
      }

      if (attempt === totalAttempts) {
        throw new ApiError(
          (err as Error).message || 'Network error',
          0,
          'Failed after all retry attempts'
        );
      }

      await sleep(RETRY_BASE_DELAY * attempt);
    }
  }

  throw new ApiError('All retry attempts failed', 0);
}

export const api = {
  get<T = any>(path: string, params?: Record<string, string | number | boolean | undefined>, signal?: AbortSignal) {
    return apiRequest<T>(path, { method: 'GET', params, signal });
  },

  post<T = any>(path: string, body: any, options: { timeout?: number; retries?: number } = {}) {
    return apiRequest<T>(path, { method: 'POST', body, ...options });
  },

  put<T = any>(path: string, body: any) {
    return apiRequest<T>(path, { method: 'PUT', body });
  },

  delete<T = any>(path: string) {
    return apiRequest<T>(path, { method: 'DELETE' });
  },

  patch<T = any>(path: string, body: any) {
    return apiRequest<T>(path, { method: 'PATCH', body });
  },
};

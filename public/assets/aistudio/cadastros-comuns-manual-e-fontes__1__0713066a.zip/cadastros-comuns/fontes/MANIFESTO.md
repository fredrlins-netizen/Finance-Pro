# Manifesto dos arquivos-fonte

Os arquivos abaixo foram copiados do projeto sem alteração para documentar as telas, chamadas de API, permissões e vínculos. Os caminhos dentro de `fontes/` refletem os caminhos do repositório, exceto os arquivos de esquema, agrupados em `schema/`.

## Navegação e tipos

- `constants.ts`
- `types.ts`
- `components/layout/Sidebar.tsx`
- `components/layout/DashboardLayout.tsx`

## Painéis de Cadastros Comuns

- `components/cadastros/ClientsPanel.tsx`
- `components/cadastros/RolesPanel.tsx`
- `components/cadastros/CollaboratorsPanel.tsx`
- `components/cadastros/DepartamentosPanel.tsx`
- `components/cadastros/BanksPanel.tsx`
- `components/cadastros/ModalitiesPanel.tsx`
- `components/cadastros/ProductsPanel.tsx`
- `components/cadastros/SeriesPanel.tsx`

## Componentes e suporte usados pelas telas

- `components/ui/AdmissionViewerModal.tsx`
- `components/ui/AuditLogButton.tsx`
- `components/ui/BlockClientModal.tsx`
- `components/ui/BlockedClientBanner.tsx`
- `components/ui/Button.tsx`
- `components/ui/CameraCapture.tsx`
- `components/ui/FormActions.tsx`
- `components/ui/Input.tsx`
- `components/ui/Pagination.tsx`
- `components/ui/PaginationBar.tsx`
- `components/attachments/ClientAttachmentsPanel.tsx`
- `components/gotalk/GotalkConversationsTab.tsx`
- `components/gotalk/GotalkPhoneLink.tsx`
- `components/conversas/ConversasPanel.tsx`
- `contexts/AuditContext.tsx`
- `contexts/KeyboardShortcutContext.tsx`
- `contexts/SecurityContext.tsx`
- `hooks/useEntityCRUD.ts`
- `services/apiService.ts`
- `utils/dependencyCheck.ts`

## Rotas de API e persistência

- `server/routes/banks.js`
- `server/routes/clients.js`
- `server/routes/collaborators.js`
- `server/routes/configOptions.js`
- `server/routes/crudFactory.js`
- `server/routes/febrabanBanks.js`
- `server/routes/lookups.js`
- `server/routes/modalities.js`
- `server/routes/products.js`
- `server/routes/roles.js`
- `server/routes/series.js`
- `server/index.js`
- `schema/supabase-schema.sql`
- `schema/migrations/001_initial_schema.sql`
- `schema/migrations/007_integrity_fixes.sql`
- `schema/migrations/024_bank_contacts.sql`
- `schema/migrations/065_crud_runtime_schema.sql`

## Exclusões intencionais

Não foram incluídos `.env`, segredos, dados de produção, `node_modules`, histórico Git, build, arquivos temporários, nem o restante do aplicativo. O pacote não substitui o repositório completo nem é um build instalável.

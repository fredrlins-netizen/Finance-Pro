

/**
 * TÍTULO: LAYOUT DO DASHBOARD
 * 
 * Atualizado para suportar navegação de retorno (sub-fluxos) para múltiplos cadastros.
 */

import React, { useState, useEffect, useCallback, useRef, Suspense, lazy } from 'react';
import { useLegacyViewClients } from '../../hooks/useLegacyViewClients';
import Sidebar from './Sidebar';
import UnitSwitcher from './UnitSwitcher';
import Button from '../ui/Button';
import VisualPreferencesControl from '../ui/VisualPreferencesControl';
import DashboardHome from '../dashboard/DashboardHome';
const TrainingStepOverlay = lazy(() => import('../training/TrainingStepOverlay'));
const TrainingPresentationOverlay = lazy(() => import('../training/TrainingPresentationOverlay'));
import IdleWarningModal from '../ui/IdleWarningModal';
import ScheduleEndWarningModal from '../ui/ScheduleEndWarningModal';
import { DEFAULT_HELP_TOPICS } from '../help/HelpContentData';

const SettingsPanel = lazy(() => import('../settings/SettingsPanel'));
const SchedulerPanel = lazy(() => import('../settings/SchedulerPanel'));
const ClientsPanel = lazy(() => import('../cadastros/ClientsPanel'));
const CollaboratorsPanel = lazy(() => import('../cadastros/CollaboratorsPanel'));
const RolesPanel = lazy(() => import('../cadastros/RolesPanel'));
const BanksPanel = lazy(() => import('../cadastros/BanksPanel'));
const ModalitiesPanel = lazy(() => import('../cadastros/ModalitiesPanel'));
const ProductsPanel = lazy(() => import('../cadastros/ProductsPanel'));
const SeriesPanel = lazy(() => import('../cadastros/SeriesPanel'));
const FormsBuilder = lazy(() => import('../relatorios/FormsBuilder'));
const ConsultasPanel = lazy(() => import('../relatorios/ConsultasPanel'));
const ReportBuilder = lazy(() => import('../relatorios/report-builder/ReportBuilder'));
const AdmissionPanel = lazy(() => import('../comercial/AdmissionPanel'));
const NegotiationPanel = lazy(() => import('../comercial/NegotiationPanel'));
const ProspeccaoPanel = lazy(() => import('../comercial/ProspeccaoPanel'));
const AuditPanel = lazy(() => import('../atendimento/AuditPanel'));
const LegalPanel = lazy(() => import('../juridico/LegalPanel'));
const FinancialPanel = lazy(() => import('../financeiro/FinancialPanel'));
const DepartamentosPanel = lazy(() => import('../cadastros/DepartamentosPanel'));
const CollectionPanel = lazy(() => import('../financeiro/CollectionPanel'));
const LegalTrackingPanel = lazy(() => import('../acompanhamento-juridico/LegalTrackingPanel'));
const HelpAgentPanel = lazy(() => import('../help/HelpAgentPanel'));
const TrainingPanel = lazy(() => import('../training/TrainingPanel'));
const InboxPanel = lazy(() => import('../mensagens/InboxPanel'));
const ConversasPanel = lazy(() => import('../conversas/ConversasPanel'));
const AIAnalysisPanel = lazy(() => import('../relatorios/AIAnalysisPanel'));
const LeoChat = lazy(() => import('../training/LeoChat'));
import { useIdleTimeout } from '../../hooks/useIdleTimeout';
import { useScheduleTimeout } from '../../hooks/useScheduleTimeout';
import { useGotalk } from '../../contexts/GotalkContext';
import { useSecurity } from '../../contexts/SecurityContext';
import { useViewport } from '../../contexts/ViewportContext';
import { PortalConfig, User } from '../../types';

type NetworkInformation = {
  saveData?: boolean;
  effectiveType?: string;
};

type NavigatorWithConnection = Navigator & {
  connection?: NetworkInformation;
  mozConnection?: NetworkInformation;
  webkitConnection?: NetworkInformation;
};

const viewImporters: Record<string, () => Promise<unknown>> = {
  settings: () => import('../settings/SettingsPanel'),
  agenda: () => import('../settings/SchedulerPanel'),
  cad_clientes: () => import('../cadastros/ClientsPanel'),
  cad_colaboradores: () => import('../cadastros/CollaboratorsPanel'),
  cad_cargos: () => import('../cadastros/RolesPanel'),
  cad_bancos: () => import('../cadastros/BanksPanel'),
  cad_modalidades: () => import('../cadastros/ModalitiesPanel'),
  cad_produtos: () => import('../cadastros/ProductsPanel'),
  cad_series: () => import('../cadastros/SeriesPanel'),
  cad_departamentos: () => import('../cadastros/DepartamentosPanel'),
  rel_formularios: () => import('../relatorios/FormsBuilder'),
  rel_gerais: () => import('../relatorios/report-builder/ReportBuilder'),
  com_admissao: () => import('../comercial/AdmissionPanel'),
  com_negociacao: () => import('../comercial/NegotiationPanel'),
  com_prospeccao: () => import('../comercial/ProspeccaoPanel'),
  auditoria: () => import('../atendimento/AuditPanel'),
  juridico: () => import('../juridico/LegalPanel'),
  financeiro: () => import('../financeiro/FinancialPanel'),
  fin_cobranca: () => import('../financeiro/CollectionPanel'),
  acomp_juridico: () => import('../acompanhamento-juridico/LegalTrackingPanel'),
  mensagens: () => import('../mensagens/InboxPanel'),
  conversas: () => import('../conversas/ConversasPanel'),
  ia_analise: () => import('../relatorios/AIAnalysisPanel'),
  ia_chat: () => import('../training/LeoChat'),
};

Object.assign(viewImporters, {
  jur_dashboard: viewImporters.acomp_juridico,
  jur_processos: viewImporters.acomp_juridico,
  jur_prazos: viewImporters.acomp_juridico,
  fin_negociacao: viewImporters.fin_cobranca,
  fin_cob_coordenador: viewImporters.fin_cobranca,
  fin_cob_operacional: viewImporters.fin_cobranca,
  fin_gerenciamento: viewImporters.financeiro,
  fin_receber: viewImporters.financeiro,
  fin_pagar: viewImporters.financeiro,
  fin_conta_corrente: viewImporters.financeiro,
  fin_cc_cadastro: viewImporters.financeiro,
  fin_cc_movimento: viewImporters.financeiro,
  fin_cc_conciliacao: viewImporters.financeiro,
  fin_tipo_documento: viewImporters.financeiro,
  fin_portador: viewImporters.financeiro,
  fin_plano_contas: viewImporters.financeiro,
  ia_dados: viewImporters.ia_analise,
  ia_relatorios: viewImporters.ia_analise,
  ia_auditoria: viewImporters.ia_analise,
});

const canPrefetchForCurrentConnection = () => {
  if (typeof navigator === 'undefined') return false;
  const networkNavigator = navigator as NavigatorWithConnection;
  const connection = networkNavigator.connection
    || networkNavigator.mozConnection
    || networkNavigator.webkitConnection;
  return !connection?.saveData && !['slow-2g', '2g'].includes(connection?.effectiveType || '');
};

const TRAINING_STORAGE_KEY = 'financepro_training_progress';
const VIEWS_SEM_GUARDA_ACESSO = ['home'];

interface DashboardLayoutProps {
  config: PortalConfig;
  currentUser: User | null;
  onLogout: (reason?: 'idle' | 'manual' | 'schedule_end') => void;
  onRefresh?: () => void;
  lastRefreshedAt?: Date | null;
}

async function sendSystemMessageLocal(config: PortalConfig, recipientType: 'USER' | 'GROUP' | 'ALL', recipientId: string, body: string, metadata?: Record<string, any>) {
  try {
    await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ senderId: 'SYSTEM', senderName: 'Sistema Invicta', recipientType, recipientId, body, attachments: [], isSystem: true, metadata: metadata || {} }),
    });
  } catch {}
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ 
  config: baseConfig,
  currentUser, 
  onLogout,
  onRefresh,
  lastRefreshedAt,
}) => {
  const [currentView, setCurrentView] = useState('home');
  const legacyClients = useLegacyViewClients(currentView, currentUser?.currentUnitId);
  const config = { ...baseConfig, clients: legacyClients.clients };
  const { showWarning, secondsLeft, resetIdle } = useIdleTimeout(() => onLogout('idle'));
  const { showWarning: showScheduleWarning, secondsLeft: scheduleSecondsLeft, endTimeStr, dismiss: dismissScheduleWarning } =
      useScheduleTimeout(currentUser, config.escalas || [], () => onLogout('schedule_end'));
  const { pendingClientId, clearPendingClient, pendingConversasNav, clearConversasNav } = useGotalk();
  const { temAcesso, addToast } = useSecurity();

  const { isMobile, isDesktop, height: vpHeight } = useViewport();
  const [isSidebarOpen, setIsSidebarOpen] = useState(() => isDesktop);
  const desktopSidebarOpenRef = useRef(true);
  const [gotalkJumpClientId, setGotalkJumpClientId] = useState<string | undefined>(undefined);
  
  const [previousView, setPreviousView] = useState('home');

  const [isTrainingPanelOpen, setIsTrainingPanelOpen] = useState(false);
  const [activeTrainingModule, setActiveTrainingModule] = useState<string | null>(null);
  const [completedModules, setCompletedModules] = useState<string[]>(() => {
    try { const d = localStorage.getItem(TRAINING_STORAGE_KEY); return d ? JSON.parse(d).completed || [] : []; } catch { return []; }
  });
  const [completedSteps, setCompletedSteps] = useState<Record<string, number>>(() => {
    try { const d = localStorage.getItem(TRAINING_STORAGE_KEY); return d ? JSON.parse(d).steps || {} : {}; } catch { return {}; }
  });
  const [trainingInitialStep, setTrainingInitialStep] = useState(0);
  const [activePresentationModule, setActivePresentationModule] = useState<string | null>(null);
  const [showLeoPulse, setShowLeoPulse] = useState(true);
  const [isHelpOpen, setIsHelpOpen] = useState(false);

  const saveTrainingProgress = useCallback((completed: string[], steps: Record<string, number>) => {
    localStorage.setItem(TRAINING_STORAGE_KEY, JSON.stringify({ completed, steps }));
  }, []);

  useEffect(() => {
    const t = setTimeout(() => setShowLeoPulse(false), 5000);
    return () => clearTimeout(t);
  }, []);

  useEffect(() => {
    setIsSidebarOpen(isMobile ? false : desktopSidebarOpenRef.current);
  }, [isMobile]);

  const handleStartModule = (moduleId: string) => {
    const resumeStep = completedSteps[moduleId] || 0;
    setTrainingInitialStep(completedModules.includes(moduleId) ? 0 : resumeStep);
    setActiveTrainingModule(moduleId);
    setIsTrainingPanelOpen(false);
  };

  const handleStartPresentation = (moduleId: string) => {
    const resumeStep = completedSteps[moduleId] || 0;
    setTrainingInitialStep(completedModules.includes(moduleId) ? 0 : resumeStep);
    setActivePresentationModule(moduleId);
    setIsTrainingPanelOpen(false);
  };

  const handleStepChange = (moduleId: string, stepIndex: number) => {
    const newSteps = { ...completedSteps, [moduleId]: Math.max(completedSteps[moduleId] || 0, stepIndex + 1) };
    setCompletedSteps(newSteps);
    saveTrainingProgress(completedModules, newSteps);
  };

  const handleTrainingComplete = (moduleId: string) => {
    const newCompleted = completedModules.includes(moduleId) ? completedModules : [...completedModules, moduleId];
    setCompletedModules(newCompleted);
    const newSteps = { ...completedSteps };
    delete newSteps[moduleId];
    setCompletedSteps(newSteps);
    saveTrainingProgress(newCompleted, newSteps);
    setActiveTrainingModule(null);
    setActivePresentationModule(null);
  };

  // --- SUB-FLOW STATE ---
  const [subFlowData, setSubFlowData] = useState<any>(null);
  const [isSubFlowActive, setIsSubFlowActive] = useState(false);
  const [subFlowTargetId, setSubFlowTargetId] = useState<string | undefined>(undefined);
  const [subFlowClientRole, setSubFlowClientRole] = useState<'responsible' | 'holder'>('responsible');

  const toggleSidebar = () => {
    setIsSidebarOpen(current => {
      const next = !current;
      if (isDesktop) desktopSidebarOpenRef.current = next;
      return next;
    });
  };

  useEffect(() => {
    if (pendingClientId) {
      setGotalkJumpClientId(pendingClientId);
      setPreviousView(currentView);
      setCurrentView('cad_clientes');
      clearPendingClient();
      if (isMobile) setIsSidebarOpen(false);
    }
  }, [pendingClientId]);

  useEffect(() => {
    if (pendingConversasNav) {
      clearConversasNav();
      if (!temAcesso('conversas')) {
        addToast('error', 'Acesso Restrito', 'Você não tem permissão para acessar o módulo de Conversas.');
      } else {
        setPreviousView(currentView);
        setCurrentView('conversas');
        if (isMobile) setIsSidebarOpen(false);
      }
    }
  }, [pendingConversasNav]);

  useEffect(() => {
    if (currentView !== 'cad_clientes') {
      setGotalkJumpClientId(undefined);
    }
  }, [currentView]);

  const handleNavigate = (view: string) => {
    if (view === currentView) return;
    if (!VIEWS_SEM_GUARDA_ACESSO.includes(view) && !temAcesso(view)) {
      addToast(
        'error',
        'Acesso Restrito',
        'Você pode visualizar este módulo no menu, mas não tem permissão de acesso. Contate o administrador.'
      );
      return;
    }
    setPreviousView(currentView);
    setCurrentView(view);
    if (isMobile) setIsSidebarOpen(false);
  };

  const handlePrefetch = useCallback((view: string) => {
    if (!canPrefetchForCurrentConnection()) return;
    const importer = viewImporters[view];
    if (importer) void importer().catch(() => undefined);
  }, []);

  const handleCloseSettings = () => {
    const target = previousView === 'settings' ? 'home' : previousView;
    setCurrentView(target);
  };

  // HANDLER GENÉRICO PARA SOLICITAÇÃO DE CADASTRO/EDIÇÃO EXTERNA
  const handleRequestExternalAction = (entity: 'CLIENT' | 'BANK' | 'COLLAB', currentFormData: any, idToEdit?: string, clientRole: 'responsible' | 'holder' = 'responsible') => {
      setSubFlowData(currentFormData);
      setIsSubFlowActive(true);
      setSubFlowTargetId(idToEdit);
      setSubFlowClientRole(clientRole);

      const viewMap = {
          'CLIENT': 'cad_clientes',
          'BANK': 'cad_bancos',
          'COLLAB': 'cad_colaboradores'
      };
      setCurrentView(viewMap[entity]);
  };

  const handleSubFlowSuccess = (newId: string) => {
      // Reconstrói o dado da admissão com o novo ID vinculado ao campo correto
      const updatedData = { ...subFlowData };
      
      // Mapeia qual campo deve ser atualizado baseado na view atual
      if (currentView === 'cad_clientes') updatedData[subFlowClientRole === 'holder' ? 'titularClientId' : 'clientId'] = newId;
      if (currentView === 'cad_bancos') updatedData.bankId = newId;
      if (currentView === 'cad_colaboradores') updatedData.collaboratorId = newId;

      setSubFlowData(updatedData);
      setIsSubFlowActive(false);
      setSubFlowTargetId(undefined);
      setCurrentView('com_admissao');
  };

  const handleSubFlowCancel = () => {
      setIsSubFlowActive(false);
      setSubFlowTargetId(undefined);
      setCurrentView('com_admissao');
  };

  const handleUpdateConfig = async (key: string, value: any) => {
      try {
          await fetch('/api/settings/section', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key, value }) });
          if (onRefresh) onRefresh();
      } catch (e) { console.error('handleUpdateConfig error:', e); }
  };

  const renderContent = () => {
    if (legacyClients.loading || legacyClients.error) {
      return <div role="status" className="p-6">{legacyClients.error || 'Carregando clientes deste módulo...'}</div>;
    }
    if (currentView.startsWith('jur_') || currentView === 'acomp_juridico') {
        return <LegalTrackingPanel config={config} activeView={currentView} />;
    }

    // Tratamento especial para views financeiras (submenus)
    if (currentView === 'fin_cobranca' || currentView === 'fin_cob_coordenador' || currentView === 'fin_cob_operacional' || currentView === 'fin_negociacao') {
        return <CollectionPanel config={config} activeView={currentView} currentUserId={currentUser?.id} onRefresh={onRefresh} onNavigate={handleNavigate} />;
    }

    if (currentView.startsWith('fin_') || currentView === 'financeiro') {
        return <FinancialPanel config={config} activeView={currentView} onNavigate={handleNavigate} currentUserId={currentUser?.id} onRefresh={onRefresh} />;
    }

    switch (currentView) {
      case 'settings':
        return <SettingsPanel config={config} onClose={handleCloseSettings} currentUser={currentUser} onRefresh={onRefresh} />;
      case 'agenda':
        return <SchedulerPanel config={config} currentUnitId={currentUser?.currentUnitId} currentUser={currentUser ?? undefined} onRefresh={onRefresh} lastRefreshedAt={lastRefreshedAt} />;
      case 'cad_clientes':
        return (
          <ClientsPanel 
            config={config} 
            autoStartCreate={isSubFlowActive && !subFlowTargetId} 
            externalEditId={isSubFlowActive ? subFlowTargetId : gotalkJumpClientId}
            onClientSelect={isSubFlowActive ? handleSubFlowSuccess : undefined} 
            onCancelSubFlow={isSubFlowActive ? handleSubFlowCancel : undefined}
          />
        );
      case 'cad_cargos':
        return <RolesPanel config={config} />;
      case 'cad_colaboradores':
        return (
          <CollaboratorsPanel 
            config={config} 
            autoStartCreate={isSubFlowActive && !subFlowTargetId} 
            externalEditId={subFlowTargetId}
            onCollaboratorSelect={isSubFlowActive ? handleSubFlowSuccess : undefined}
            onCancelSubFlow={isSubFlowActive ? handleSubFlowCancel : undefined}
          />
        );
      case 'cad_departamentos':
        return <DepartamentosPanel config={config} onUpdate={(d) => handleUpdateConfig('departments', d)} />;
      case 'cad_bancos':
        return (
          <BanksPanel 
            config={config} 
            autoStartCreate={isSubFlowActive && !subFlowTargetId} 
            externalEditId={subFlowTargetId}
            onBankSelect={isSubFlowActive ? handleSubFlowSuccess : undefined}
            onCancelSubFlow={isSubFlowActive ? handleSubFlowCancel : undefined}
          />
        );
      case 'cad_modalidades':
        return <ModalitiesPanel config={config} />;
      case 'cad_produtos':
        return <ProductsPanel config={config} />;
      case 'cad_series':
        return <SeriesPanel config={config} />;
      case 'com_prospeccao':
        return <ProspeccaoPanel />;
      case 'com_admissao': 
        return <AdmissionPanel 
                  config={config} 
                  currentUser={currentUser}
                  onClose={handleCloseSettings} 
                  initialData={subFlowData} 
                  onRequestExternalAction={handleRequestExternalAction}
                  onRefresh={onRefresh}
                />;
      case 'com_negociacao': 
        return <NegotiationPanel config={config} />;
      case 'auditoria':
        return <AuditPanel config={config} onSendSystemMessage={(rt, rid, body, meta) => sendSystemMessageLocal(config, rt, rid, body, meta)} onRefresh={onRefresh} />;
      case 'juridico':
        return <LegalPanel config={config} />;
      case 'rel_formularios':
        return <FormsBuilder config={config} onRefresh={onRefresh} />;
      case 'rel_gerais':
        return <ReportBuilder config={config} currentUser={currentUser} />;
      case 'rel_consultas':
        return <ConsultasPanel />;
      case 'mensagens':
        return <InboxPanel config={config} currentUser={currentUser} />;
      case 'conversas':
        return <ConversasPanel config={config} />;
      case 'ia_analise':
      case 'ia_dados':
        return <AIAnalysisPanel initialTab="dados" />;
      case 'ia_relatorios':
        return <AIAnalysisPanel initialTab="relatorios" />;
      case 'ia_auditoria':
        return <AIAnalysisPanel initialTab="auditoria" />;
      case 'ia_chat':
        return (
          <div className="flex flex-col h-full">
            <div className="bg-white border-b border-gray-200 px-6 py-4 shadow-sm flex-shrink-0 flex items-center gap-3">
              <img src="/leo-avatar.png" alt="Léo" className="w-9 h-9 rounded-full border border-moss-200 object-cover bg-white" />
              <div>
                <h1 className="text-lg font-bold text-gray-800">Chat com Léo IA</h1>
                <p className="text-xs text-gray-500">Assistente inteligente para dúvidas sobre o sistema</p>
              </div>
            </div>
            <div className="flex-1 overflow-hidden min-h-0">
              <Suspense fallback={<div className="flex h-full items-center justify-center"><div className="w-8 h-8 border-2 border-moss-500 border-t-transparent rounded-full animate-spin" /></div>}>
                <LeoChat />
              </Suspense>
            </div>
          </div>
        );
      case 'home':
      default:
        return <DashboardHome config={config} />;
    }
  };

  return (
    <div
      data-visual-shell="true"
      data-sidebar-collapsed={String(!isMobile && !isSidebarOpen)}
      className="dashboard-shell flex bg-gray-50 overflow-hidden"
      style={{ height: `max(0px, ${vpHeight}px)` }}
    >
      {showScheduleWarning && (
        <ScheduleEndWarningModal
          secondsLeft={scheduleSecondsLeft}
          endTimeStr={endTimeStr}
          onDismiss={dismissScheduleWarning}
          onLogout={() => onLogout('schedule_end')}
        />
      )}
      {showWarning && (
        <IdleWarningModal
          secondsLeft={secondsLeft}
          onContinue={resetIdle}
          onLogout={() => onLogout('idle')}
        />
      )}

      {/* Mobile overlay backdrop */}
      {isMobile && isSidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 backdrop-blur-sm"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      <Sidebar
        isOpen={isSidebarOpen}
        toggleSidebar={toggleSidebar}
        config={config}
        currentUser={currentUser}
        onLogout={onLogout}
        currentView={currentView}
        onNavigate={handleNavigate}
        onPrefetch={handlePrefetch}
        isMobile={isMobile}
      />

      <div className="flex-1 flex flex-col min-w-0">
        <header className="dashboard-topbar shadow-md border-b z-10 h-14 transition-colors duration-300 flex-shrink-0" style={{ backgroundColor: config.theme.headerBgColor, color: config.theme.headerTextColor, borderColor: 'rgba(0,0,0,0.1)' }}>
          <div className="dashboard-header-inner relative flex items-center h-full px-2 sm:px-3 gap-1.5 sm:gap-2">
            {/* Hamburger — always visible on mobile */}
            {isMobile && (
              <button
                onClick={toggleSidebar}
                className="flex-shrink-0 p-2 rounded-lg hover:bg-white/10 transition-colors"
                title="Menu"
              >
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                </svg>
              </button>
            )}

            {/* Branding */}
            <div className={`items-center gap-2 min-w-0 ${isMobile && currentView !== 'home' ? 'hidden' : 'flex'}`}>
              {isMobile ? (
                /* Logo compacto em mobile */
                <div className="h-7 w-7 rounded-full bg-white/10 p-0.5 flex-shrink-0">
                  <img src={config.logoUrl} alt="Logo" className="w-full h-full object-cover rounded-full" />
                </div>
              ) : (
                <>
                  <h2 className="text-sm font-bold tracking-wide truncate hidden md:block">{config.companyName}</h2>
                  {(() => {
                    const isProduction = typeof window !== 'undefined' && window.location.hostname.includes('invictafinanceira.com');
                    return isProduction
                      ? <span className="text-[10px] font-extrabold tracking-widest uppercase px-2 py-0.5 rounded-full bg-red-500/20 text-red-200 border border-red-400/40 select-none hidden md:inline-flex">OFICIAL</span>
                      : <span className="text-[10px] font-extrabold tracking-widest uppercase px-2 py-0.5 rounded-full bg-blue-400/20 text-blue-200 border border-blue-400/40 select-none hidden md:inline-flex">DESENVOLVIMENTO</span>;
                  })()}
                </>
              )}
            </div>

            {/* Spacer */}
            <div className="flex-1" />

            {/* Unit Switcher — centered absolutely */}
            <div className="unit-switcher-anchor absolute left-1/2 -translate-x-1/2 flex items-center pointer-events-none max-w-[42%]">
              <div className="pointer-events-auto">
                <UnitSwitcher
                  currentUser={currentUser}
                  config={config}
                  headerTextColor={config.theme.headerTextColor}
                />
              </div>
            </div>

            {/* User info — oculto em mobile */}
            <div className="text-right hidden lg:block">
              <p className="text-xs font-medium">Olá, {currentUser?.name?.split(' ')[0]}</p>
              <p className="text-[10px] opacity-70 truncate max-w-[150px]">{currentUser?.email}</p>
            </div>

            {/* Léo — Treinamento */}
            <VisualPreferencesControl />
            <button
              onClick={() => setIsTrainingPanelOpen(true)}
              className="relative flex-shrink-0 group"
              title="Treinamento com o Léo"
            >
              <div className={`w-9 h-9 rounded-full border-2 border-white/40 overflow-hidden bg-white shadow hover:scale-110 transition-transform ${showLeoPulse ? 'animate-bounce' : ''}`}>
                <img src="/leo-avatar.png" alt="Léo" className="w-full h-full object-cover" />
              </div>
              {showLeoPulse && (
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-amber-400 rounded-full border border-white animate-pulse" />
              )}
              <span className="absolute top-11 right-0 bg-gray-900 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none shadow-lg">
                Treinamento
              </span>
            </button>

            {/* Ajuda */}
            <button
              onClick={() => setIsHelpOpen(true)}
              className="relative flex-shrink-0 w-9 h-9 rounded-full flex items-center justify-center text-base font-bold shadow hover:scale-110 transition-transform group"
              style={{ backgroundColor: '#4a7c59', color: '#fff' }}
              title="Central de Ajuda"
            >
              ?
              <span className="absolute top-11 right-0 bg-gray-900 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap pointer-events-none shadow-lg">
                Central de Ajuda
              </span>
            </button>

            {/* Logout */}
            <Button variant="primary" onClick={() => onLogout()} className="!w-auto !py-1.5 !px-3 text-xs bg-red-600 hover:bg-red-700 text-white border-none shadow-lg font-bold tracking-wide flex-shrink-0" title="Sair do sistema com segurança">
              <span className="hidden sm:inline">SAIR</span>
              <svg className="w-4 h-4 sm:hidden" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
              </svg>
            </Button>
          </div>
        </header>
        <main
          data-specialized-layout={['mensagens', 'fin_cob_operacional', 'fin_negociacao', 'agenda', 'com_prospeccao', 'conversas'].includes(currentView) ? 'true' : undefined}
          className={`dashboard-main flex-1 min-h-0 overflow-x-hidden scroll-smooth ${['mensagens', 'fin_cob_operacional', 'fin_negociacao', 'agenda', 'com_prospeccao', 'conversas'].includes(currentView) ? 'overflow-hidden p-0' : 'overflow-y-auto'}`}
          style={{ backgroundColor: config.theme.mainContentBgColor, backgroundImage: config.theme.mainContentBgImage ? `url(${config.theme.mainContentBgImage})` : 'none', backgroundSize: 'cover', backgroundPosition: 'center' }}
        >
          <Suspense fallback={
            <div className="flex items-center justify-center h-full">
              <div className="text-center">
                <div className="inline-block w-10 h-10 border-4 border-gray-200 border-t-green-600 rounded-full animate-spin mb-3"></div>
                <p className="text-gray-400 text-sm">Carregando...</p>
              </div>
            </div>
          }>
            {renderContent()}
          </Suspense>
        </main>
      </div>
      {isHelpOpen && (
        <Suspense fallback={null}>
          <HelpAgentPanel
            currentView={currentView}
            helpTopics={config.helpTopics || DEFAULT_HELP_TOPICS}
            hideTrigger={true}
            externalOpen={isHelpOpen}
            onExternalClose={() => setIsHelpOpen(false)}
            currentUser={currentUser}
            onRefresh={onRefresh}
          />
        </Suspense>
      )}

      {isTrainingPanelOpen && (
        <Suspense fallback={null}>
          <TrainingPanel
            isOpen={isTrainingPanelOpen}
            onClose={() => setIsTrainingPanelOpen(false)}
            onStartModule={handleStartModule}
            onStartPresentation={handleStartPresentation}
            completedModules={completedModules}
            completedSteps={completedSteps}
          />
        </Suspense>
      )}

      {activeTrainingModule && (
        <Suspense fallback={null}>
          <TrainingStepOverlay
            moduleId={activeTrainingModule}
            initialStep={trainingInitialStep}
            onClose={() => setActiveTrainingModule(null)}
            onStepChange={handleStepChange}
            onComplete={handleTrainingComplete}
          />
        </Suspense>
      )}

      <Suspense fallback={null}>
        {activePresentationModule && (
          <TrainingPresentationOverlay
            moduleId={activePresentationModule}
            initialStep={trainingInitialStep}
            onClose={() => setActivePresentationModule(null)}
            onStepChange={handleStepChange}
            onComplete={handleTrainingComplete}
          />
        )}
      </Suspense>
    </div>
  );
};

export default DashboardLayout;
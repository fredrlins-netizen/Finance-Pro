import React, { useState, useEffect } from 'react';
import { Client } from '../../types';
import { useKeyboardShortcut } from '../../contexts/KeyboardShortcutContext';

interface BlockClientModalProps {
    client: Client | null;
    isOpen: boolean;
    onClose: () => void;
    onConfirm: (status: 'BLOQUEADO' | 'SUSPENSO', reason: string) => void;
    onUnblock: () => void;
    currentUserName: string;
    canUnblock?: boolean;
}

const MIN_REASON_LENGTH = 20;

const BlockClientModal: React.FC<BlockClientModalProps> = ({
    client,
    isOpen,
    onClose,
    onConfirm,
    onUnblock,
    currentUserName,
    canUnblock = false,
}) => {
    const { registerFormActions, unregisterFormActions } = useKeyboardShortcut();
    const [status, setStatus] = useState<'BLOQUEADO' | 'SUSPENSO'>('BLOQUEADO');
    const [reason, setReason] = useState('');
    const [showUnblockConfirm, setShowUnblockConfirm] = useState(false);

    useEffect(() => {
        if (isOpen) {
            setStatus('BLOQUEADO');
            setReason('');
            setShowUnblockConfirm(false);
        }
    }, [isOpen, client?.id]);

    const isReasonValid = reason.trim().length >= MIN_REASON_LENGTH;

    useEffect(() => {
        if (isOpen && isReasonValid) {
            registerFormActions(() => onConfirm(status, reason.trim()), onClose);
        } else if (isOpen) {
            registerFormActions(undefined, onClose);
        } else {
            unregisterFormActions();
        }
        return () => unregisterFormActions();
    }, [isOpen, isReasonValid, status, reason, onConfirm, onClose, registerFormActions, unregisterFormActions]);

    if (!isOpen || !client) return null;
    const isAlreadyBlocked = client.blocked;

    const handleConfirm = () => {
        if (!isReasonValid) return;
        onConfirm(status, reason.trim());
    };

    return (
        <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black bg-opacity-60 backdrop-blur-sm animate-fade-in">
            <div className="bg-white rounded-xl shadow-2xl border border-gray-200 w-full max-w-lg flex flex-col overflow-hidden">
                <div className={`px-6 py-4 flex items-center gap-3 ${isAlreadyBlocked ? 'bg-red-700' : 'bg-amber-700'}`}>
                    <svg className="w-6 h-6 text-white flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                    <div>
                        <h3 className="text-base font-bold text-white">
                            {isAlreadyBlocked ? 'Gerenciar Restrição' : 'Bloquear / Suspender Cliente'}
                        </h3>
                        <p className="text-xs text-white/70">{client.name} — {client.document}</p>
                    </div>
                </div>

                <div className="p-6 space-y-5">
                    {isAlreadyBlocked && (
                        <div className={`rounded-lg p-3 border text-sm ${client.blockStatus === 'BLOQUEADO' ? 'bg-red-50 border-red-200 text-red-700' : 'bg-amber-50 border-amber-200 text-amber-700'}`}>
                            <p className="font-bold mb-1">Situação atual: {client.blockStatus}</p>
                            <p className="text-xs">Aplicado em {client.blockedAt ? new Date(client.blockedAt).toLocaleString('pt-BR') : '—'} por {client.blockedBy || '—'}</p>
                            <p className="mt-2 text-xs font-medium">Motivo: {client.blockReason}</p>
                        </div>
                    )}

                    <div>
                        <p className="text-sm font-semibold text-gray-700 mb-2">Tipo de Restrição</p>
                        <div className="flex gap-4">
                            <label className="flex items-center gap-2 cursor-pointer">
                                <input
                                    type="radio"
                                    name="blockStatus"
                                    value="BLOQUEADO"
                                    checked={status === 'BLOQUEADO'}
                                    onChange={() => setStatus('BLOQUEADO')}
                                    className="h-4 w-4 text-red-600 focus:ring-red-500"
                                />
                                <span className="text-sm font-medium text-red-700">Bloqueado</span>
                                <span className="text-xs text-gray-400">(total)</span>
                            </label>
                            <label className="flex items-center gap-2 cursor-pointer">
                                <input
                                    type="radio"
                                    name="blockStatus"
                                    value="SUSPENSO"
                                    checked={status === 'SUSPENSO'}
                                    onChange={() => setStatus('SUSPENSO')}
                                    className="h-4 w-4 text-amber-600 focus:ring-amber-500"
                                />
                                <span className="text-sm font-medium text-amber-700">Suspenso</span>
                                <span className="text-xs text-gray-400">(temporário)</span>
                            </label>
                        </div>
                    </div>

                    <div>
                        <label className="block text-sm font-semibold text-gray-700 mb-1">
                            Justificativa <span className="text-red-500">*</span>
                            <span className="ml-2 text-xs font-normal text-gray-400">
                                ({reason.trim().length}/{MIN_REASON_LENGTH} caracteres mínimos)
                            </span>
                        </label>
                        <textarea
                            className={`w-full border rounded-lg px-4 py-3 text-sm focus:ring-2 outline-none resize-none h-28 transition-colors ${
                                reason.trim().length > 0 && !isReasonValid
                                    ? 'border-red-300 focus:ring-red-400'
                                    : 'border-gray-300 focus:ring-amber-400'
                            }`}
                            placeholder={`Descreva o motivo do ${status === 'BLOQUEADO' ? 'bloqueio' : 'suspensão'} (mínimo ${MIN_REASON_LENGTH} caracteres)...`}
                            value={reason}
                            onChange={e => setReason(e.target.value)}
                        />
                        {reason.trim().length > 0 && !isReasonValid && (
                            <p className="text-xs text-red-500 mt-1">Justificativa muito curta. Detalhe o motivo adequadamente.</p>
                        )}
                    </div>

                    <p className="text-xs text-gray-400">Responsável: {currentUserName}</p>
                </div>

                <div className="px-6 pb-6 flex items-center justify-between gap-3">
                    <div>
                        {isAlreadyBlocked && canUnblock && !showUnblockConfirm && (
                            <button
                                onClick={() => setShowUnblockConfirm(true)}
                                className="px-4 py-2 rounded-lg text-sm font-medium text-green-700 bg-green-50 border border-green-200 hover:bg-green-100 transition-colors"
                            >
                                Remover Restrição
                            </button>
                        )}
                        {showUnblockConfirm && (
                            <div className="flex items-center gap-2">
                                <span className="text-xs text-gray-600">Confirmar remoção?</span>
                                <button onClick={() => { onUnblock(); setShowUnblockConfirm(false); }} className="px-3 py-1.5 rounded text-xs font-bold text-white bg-green-600 hover:bg-green-700">Sim</button>
                                <button onClick={() => setShowUnblockConfirm(false)} className="px-3 py-1.5 rounded text-xs font-medium text-gray-600 bg-gray-100 hover:bg-gray-200">Não</button>
                            </div>
                        )}
                    </div>
                    <div className="flex gap-3">
                        <button
                            onClick={onClose}
                            className="px-5 py-2.5 rounded-lg text-sm font-medium text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 transition-colors"
                        >
                            Cancelar
                        </button>
                        <button
                            onClick={handleConfirm}
                            disabled={!isReasonValid}
                            className={`px-5 py-2.5 rounded-lg text-sm font-bold text-white transition-colors ${
                                isReasonValid
                                    ? status === 'BLOQUEADO'
                                        ? 'bg-red-600 hover:bg-red-700'
                                        : 'bg-amber-600 hover:bg-amber-700'
                                    : 'bg-gray-300 cursor-not-allowed'
                            }`}
                        >
                            {isAlreadyBlocked ? 'Atualizar Restrição' : `Aplicar ${status === 'BLOQUEADO' ? 'Bloqueio' : 'Suspensão'}`}
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default BlockClientModal;

/**
 * TÍTULO: COMPONENTE DE BOTÃO REUTILIZÁVEL (UI)
 * 
 * Componente genérico de botão utilizado em toda a aplicação.
 * 
 * Funcionalidades:
 * - Suporte a variantes visuais (primary, secondary, outline, ghost, search, new).
 * - Estado de carregamento (isLoading) com spinner.
 * - Repasse de referências (refs) para manipulação do DOM.
 * - Estilização baseada em Tailwind CSS.
 */

import React, { forwardRef } from 'react';

interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost' | 'search' | 'new';
  isLoading?: boolean;
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(({ 
  children, 
  variant = 'primary', 
  isLoading = false, 
  className = '', 
  ...props 
}, ref) => {
  
  const baseStyles = "w-full min-w-0 min-h-11 py-2.5 px-4 rounded-lg font-semibold text-sm sm:text-base transition-[background-color,border-color,color,box-shadow,transform] duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed flex justify-center items-center whitespace-normal sm:whitespace-nowrap active:translate-y-px";
  
  const variants = {
    primary: "bg-moss-800 hover:bg-moss-700 text-white focus:ring-moss-500 shadow-sm hover:shadow-md",
    secondary: "bg-moss-200 text-moss-900 hover:bg-moss-300 focus:ring-moss-400",
    outline: "border-2 border-moss-800 text-moss-800 hover:bg-moss-50 focus:ring-moss-500",
    ghost: "text-moss-700 hover:bg-moss-50 hover:text-moss-900",
    // New variants added
    search: "bg-blue-600 hover:bg-blue-700 text-white focus:ring-blue-500 shadow-sm",
    new: "bg-emerald-600 hover:bg-emerald-700 text-white focus:ring-emerald-500 shadow-sm hover:shadow-md"
  };

  return (
    <button 
      ref={ref}
      className={`${baseStyles} ${variants[variant]} ${className}`}
      disabled={isLoading || props.disabled}
      {...props}
    >
      {isLoading ? (
        <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
        </svg>
      ) : null}
      {children}
    </button>
  );
});

Button.displayName = 'Button';

export default Button;
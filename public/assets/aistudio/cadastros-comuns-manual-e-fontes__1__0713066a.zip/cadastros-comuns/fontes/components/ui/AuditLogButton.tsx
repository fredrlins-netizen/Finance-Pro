import React, { useState, useMemo, useEffect } from 'react';
import { AuditLog } from '../../types';
import { getFieldLabel, getValueLabel, getActionLabel, formatAuditDateTime } from '../../utils/auditLabels';

interface AuditLogButtonProps {
  entityId: string;
  entityName: string;
  logs?: AuditLog[];
}

const ACTION_CLASS: Record<string, string> = {
  CREATE: 'bg-green-100 text-green-800',
  UPDATE: 'bg-blue-100 text-blue-800',
  DELETE: 'bg-red-100 text-red-800',
  BAIXA: 'bg-emerald-100 text-emerald-800',
  BAIXA_PARCIAL: 'bg-yellow-100 text-yellow-800',
  CANCELAR_BAIXA: 'bg-orange-100 text-orange-800',
  CANCELAR: 'bg-red-100 text-red-800',
  INVOICE: 'bg-sky-100 text-sky-800',
  RECORRENCIA: 'bg-purple-100 text-purple-800',
  LINK: 'bg-slate-100 text-slate-700',
  DEDUCAO: 'bg-gray-100 text-gray-700',
};

const PAGE_SIZE = 15;

interface GridRow {
  logId: string;
  timestamp: string;
  userName: string;
  actionRaw: string;
  actionLabel: string;
  field: string;
  oldValue: string;
  newValue: string;
  description: string;
}

function normalizeDbLog(row: any): AuditLog {
  let changes: any[] = [];
  try {
    changes = typeof row.changes === 'string' ? JSON.parse(row.changes) : (row.changes || []);
  } catch { changes = []; }
  return {
    id: row.id,
    timestamp: row.timestamp,
    userId: row.user_id || '',
    userName: row.user_name || 'Sistema',
    unitId: row.unit_id || 'GLOBAL',
    entity: row.entity,
    entityId: row.entity_id,
    action: row.action,
    changes,
    description: row.description || '',
  };
}

const AuditLogButton: React.FC<AuditLogButtonProps> = ({ entityId, entityName }) => {
  const [open, setOpen] = useState(false);
  const [page, setPage] = useState(0);
  const [dbLogs, setDbLogs] = useState<AuditLog[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!open || !entityId) return;
    setLoading(true);
    fetch(`/api/audit-logs?entity_id=${encodeURIComponent(entityId)}&limit=500`)
      .then(r => r.json())
      .then(data => {
        if (data && Array.isArray(data.data)) {
          setDbLogs(data.data.map(normalizeDbLog));
        }
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [open, entityId]);

  const filtered = useMemo(() => {
    return [...dbLogs].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
  }, [dbLogs]);

  const rows: GridRow[] = useMemo(() => {
    const result: GridRow[] = [];
    for (const log of filtered) {
      const hasChanges = log.changes && log.changes.length > 0;
      if (hasChanges) {
        for (const c of log.changes) {
          result.push({
            logId: log.id,
            timestamp: formatAuditDateTime(log.timestamp),
            userName: log.userName,
            actionRaw: log.action,
            actionLabel: getActionLabel(log.action),
            field: getFieldLabel(c.field),
            oldValue: getValueLabel(c.oldValue),
            newValue: getValueLabel(c.newValue),
            description: log.description,
          });
        }
      } else {
        result.push({
          logId: log.id,
          timestamp: formatAuditDateTime(log.timestamp),
          userName: log.userName,
          actionRaw: log.action,
          actionLabel: getActionLabel(log.action),
          field: '—',
          oldValue: '—',
          newValue: log.description || '—',
          description: log.description,
        });
      }
    }
    return result;
  }, [filtered]);

  const totalPages = Math.max(1, Math.ceil(rows.length / PAGE_SIZE));
  const safePage = Math.min(page, totalPages - 1);
  const pagedRows = rows.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE);

  const count = filtered.length;

  const handleOpen = () => {
    setPage(0);
    setDbLogs([]);
    setOpen(true);
  };

  return (
    <>
      <button
        onClick={handleOpen}
        title="Histórico de movimentações (somente leitura)"
        className="relative text-slate-400 hover:text-slate-700 transition-colors flex items-center"
      >
        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
            d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        {count > 0 && (
          <span className="absolute -top-1.5 -right-1.5 min-w-[14px] h-[14px] px-0.5 bg-slate-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center leading-none">
            {count > 99 ? '99+' : count}
          </span>
        )}
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4" onClick={() => setOpen(false)}>
          <div className="bg-white rounded-xl shadow-2xl w-full max-w-5xl flex flex-col max-h-[85vh]" onClick={e => e.stopPropagation()}>

            <div className="flex items-start justify-between px-6 py-4 border-b border-gray-200">
              <div className="flex-1 min-w-0 mr-4">
                <div className="flex items-center gap-2 flex-wrap">
                  <h2 className="text-base font-bold text-gray-900">Histórico de Movimentações</h2>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-gray-100 text-gray-500 text-[10px] font-bold uppercase rounded-full border border-gray-200 select-none">
                    <svg className="w-2.5 h-2.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                    Somente Leitura
                  </span>
                  {loading && (
                    <span className="text-[10px] text-blue-500 flex items-center gap-1">
                      <svg className="w-3 h-3 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/></svg>
                      Carregando...
                    </span>
                  )}
                </div>
                <p className="text-sm text-gray-500 mt-0.5 truncate max-w-md">{entityName}</p>
              </div>
              <button onClick={() => setOpen(false)} className="text-gray-400 hover:text-gray-700 flex-shrink-0">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>

            <div className="overflow-auto flex-1">
              {rows.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-gray-400">
                  <svg className="w-10 h-10 mb-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5}
                      d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <p className="text-sm">{loading ? 'Carregando histórico...' : 'Nenhuma movimentação registrada para este item.'}</p>
                </div>
              ) : (
                <table className="w-full text-xs data-grid-typography">
                  <thead className="bg-gray-50 sticky top-0 z-10">
                    <tr>
                      <th className="text-left px-3 py-2.5 font-semibold text-gray-600 border-b border-gray-200 whitespace-nowrap">Data/Hora</th>
                      <th className="text-left px-3 py-2.5 font-semibold text-gray-600 border-b border-gray-200 whitespace-nowrap">Usuário</th>
                      <th className="text-left px-3 py-2.5 font-semibold text-gray-600 border-b border-gray-200 whitespace-nowrap">Ação</th>
                      <th className="text-left px-3 py-2.5 font-semibold text-gray-600 border-b border-gray-200 whitespace-nowrap">Campo</th>
                      <th className="text-left px-3 py-2.5 font-semibold text-gray-600 border-b border-gray-200 whitespace-nowrap">De</th>
                      <th className="text-center px-1 py-2.5 font-semibold text-gray-400 border-b border-gray-200"></th>
                      <th className="text-left px-3 py-2.5 font-semibold text-gray-600 border-b border-gray-200 whitespace-nowrap">Para</th>
                    </tr>
                  </thead>
                  <tbody>
                    {pagedRows.map((row, idx) => {
                      const actionCls = ACTION_CLASS[row.actionRaw] || 'bg-gray-100 text-gray-700';
                      return (
                        <tr key={`${row.logId}-${idx}`} className={idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/50'}>
                          <td className="px-3 py-2 text-gray-500 whitespace-nowrap align-top">{row.timestamp}</td>
                          <td className="px-3 py-2 font-medium text-gray-700 whitespace-nowrap align-top">{row.userName}</td>
                          <td className="px-3 py-2 align-top">
                            <span className={`inline-block px-2 py-0.5 text-[10px] font-bold rounded-full uppercase ${actionCls}`}>
                              {row.actionLabel}
                            </span>
                          </td>
                          <td className="px-3 py-2 text-gray-700 align-top">{row.field}</td>
                          <td className="px-3 py-2 align-top">
                            {row.oldValue !== '—' ? (
                              <span className="bg-red-50 text-red-700 px-1.5 py-0.5 rounded text-[11px]">{row.oldValue}</span>
                            ) : (
                              <span className="text-gray-300">—</span>
                            )}
                          </td>
                          <td className="px-1 py-2 text-gray-400 text-center align-top">→</td>
                          <td className="px-3 py-2 align-top">
                            {row.newValue !== '—' ? (
                              <span className="bg-green-50 text-green-700 px-1.5 py-0.5 rounded text-[11px]">{row.newValue}</span>
                            ) : (
                              <span className="text-gray-300">—</span>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              )}
            </div>

            <div className="px-6 py-3 border-t border-gray-100 flex items-center justify-between">
              <span className="text-xs text-gray-400 flex items-center gap-1">
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                {count} {count === 1 ? 'registro' : 'registros'} — histórico protegido, sem edição
              </span>

              {totalPages > 1 && (
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => setPage(p => Math.max(0, p - 1))}
                    disabled={safePage === 0}
                    className="px-2 py-1 text-xs rounded border border-gray-200 hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    ‹ Anterior
                  </button>
                  <span className="text-xs text-gray-500 px-2">
                    {safePage + 1} / {totalPages}
                  </span>
                  <button
                    onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                    disabled={safePage >= totalPages - 1}
                    className="px-2 py-1 text-xs rounded border border-gray-200 hover:bg-gray-50 disabled:opacity-30 disabled:cursor-not-allowed"
                  >
                    Próxima ›
                  </button>
                </div>
              )}

              <button onClick={() => setOpen(false)} className="text-sm text-gray-500 hover:text-gray-800 px-4 py-1.5 rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors flex items-center gap-1.5">
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
                Fechar
              </button>
            </div>

          </div>
        </div>
      )}
    </>
  );
};

export default AuditLogButton;

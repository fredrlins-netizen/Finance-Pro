/**
 * TÍTULO: COMPONENTE DE PAGINAÇÃO (UI)
 * 
 * Componente reutilizável para navegação em listas de dados.
 * 
 * Funcionalidades:
 * - Controle de itens por página.
 * - Navegação (Anterior, Próximo, Números de página).
 * - Exibição de contagem de registros (Mostrando X-Y de Z).
 */

import React from 'react';

interface PaginationProps {
  totalItems: number;
  itemsPerPage: number;
  currentPage: number;
  onPageChange: (page: number) => void;
  onItemsPerPageChange: (items: number) => void;
}

const Pagination: React.FC<PaginationProps> = ({
  totalItems,
  itemsPerPage,
  currentPage,
  onPageChange,
  onItemsPerPageChange,
}) => {
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  
  if (totalItems === 0) return null;

  const startItem = (currentPage - 1) * itemsPerPage + 1;
  const endItem = Math.min(currentPage * itemsPerPage, totalItems);

  // Lógica para mostrar número de páginas limitado (ex: 1, 2, ..., 10)
  const getPageNumbers = () => {
    const delta = 1; // Quantas páginas mostrar ao redor da atual
    const range = [];
    for (let i = Math.max(2, currentPage - delta); i <= Math.min(totalPages - 1, currentPage + delta); i++) {
      range.push(i);
    }

    if (currentPage - delta > 2) {
      range.unshift("...");
    }
    if (currentPage + delta < totalPages - 1) {
      range.push("...");
    }

    range.unshift(1);
    if (totalPages !== 1) {
      range.push(totalPages);
    }

    return range;
  };

  const pages = getPageNumbers();

  return (
    <div data-pagination="compact" className="px-6 py-4 flex items-center justify-between border-t border-gray-200 bg-gray-50">
      
      {/* Mobile View (Simple) */}
      <div className="flex-1 flex justify-between sm:hidden">
        <button
          onClick={() => onPageChange(Math.max(1, currentPage - 1))}
          disabled={currentPage === 1}
          className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Anterior
        </button>
        <button
          onClick={() => onPageChange(Math.min(totalPages, currentPage + 1))}
          disabled={currentPage === totalPages}
          className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          Próximo
        </button>
      </div>

      {/* Desktop View (Full) */}
      <div data-pagination-layout className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between gap-3 min-w-0">
        <div className="flex items-center gap-4 min-w-0 flex-shrink-0 whitespace-nowrap">
          <p data-pagination-summary className="text-sm text-gray-700 whitespace-nowrap flex-shrink-0">
            Mostrando <span className="font-medium">{startItem}</span> a <span className="font-medium">{endItem}</span> de{' '}
            <span className="font-medium">{totalItems}</span> registros
          </p>
          
          <div data-pagination-page-size className="flex items-center gap-2 flex-shrink-0 whitespace-nowrap">
              <span data-pagination-page-size-label className="text-sm text-gray-500 whitespace-nowrap">Exibir:</span>
              <select 
                data-pagination-page-size-select
                value={itemsPerPage}
                onChange={(e) => {
                    onItemsPerPageChange(Number(e.target.value));
                    onPageChange(1); // Reset to page 1 on size change
                }}
                className="block w-16 min-w-[4rem] flex-shrink-0 pl-2 pr-7 py-1 text-xs border-gray-300 focus:outline-none focus:ring-moss-500 focus:border-moss-500 sm:text-sm rounded-md bg-white border"
              >
                  <option value={5}>5</option>
                  <option value={10}>10</option>
                  <option value={20}>20</option>
                  <option value={50}>50</option>
                  <option value={100}>100</option>
              </select>
          </div>
        </div>

        <div data-pagination-controls className="flex-shrink-0">
          <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
            <button
              onClick={() => onPageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:bg-gray-100 disabled:cursor-not-allowed"
            >
              <span className="sr-only">Anterior</span>
              <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </button>
            
            {pages.map((p, idx) => (
                <React.Fragment key={idx}>
                    {p === "..." ? (
                        <span className="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">
                            ...
                        </span>
                    ) : (
                        <button
                            onClick={() => onPageChange(Number(p))}
                            className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                                currentPage === p
                                    ? 'z-10 bg-moss-50 border-moss-500 text-moss-600'
                                    : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                            }`}
                        >
                            {p}
                        </button>
                    )}
                </React.Fragment>
            ))}

            <button
              onClick={() => onPageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:bg-gray-100 disabled:cursor-not-allowed"
            >
              <span className="sr-only">Próximo</span>
              <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
              </svg>
            </button>
          </nav>
        </div>
      </div>
    </div>
  );
};

export default Pagination;
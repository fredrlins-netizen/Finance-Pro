import React, { useState, useEffect, useCallback } from 'react';
import { Admission, AdmissionAttachment, Client, Bank, LegalScanData } from '../../types';
import ClientAttachmentsPanel from '../attachments/ClientAttachmentsPanel';
import { apiRequest } from '../../services/apiService';
import HistoricalLegalScan from '../atendimento/HistoricalLegalScan';

interface AdmissionViewerModalProps {
    admission: Admission;
    clientName: string;
    onClose: () => void;
    client?: Client;
    titular?: Client;
    bank?: Bank;
    modality?: { type?: string; description?: string };
    collaboratorName?: string;
    seriesSigla?: string;
    unitName?: string;
}

const fmt = (v: string | undefined | null) => v || '—';

const AdmissionViewerModal: React.FC<AdmissionViewerModalProps> = ({
    admission, clientName, onClose, client, titular, bank, modality, collaboratorName, seriesSigla, unitName,
}) => {
    const [tab, setTab] = useState<'FICHA' | 'FINANCEIRO' | 'DOCUMENTOS' | 'AUDITORIA'>('FICHA');
    const [bucketCount, setBucketCount] = useState(0);

    // Self-fetch attachments when DOCUMENTOS tab is opened (file_data is not included in the admission object from most callers)
    const [fetchedAttachments, setFetchedAttachments] = useState<AdmissionAttachment[] | null>(null);
    const [attachmentsLoading, setAttachmentsLoading] = useState(false);
    const [attachmentsError, setAttachmentsError] = useState<string | null>(null);

    const fetchAttachments = useCallback(async () => {
        if (!admission.id) return;
        setAttachmentsLoading(true);
        setAttachmentsError(null);
        try {
            const json = await apiRequest<{ data: { id: string; title: string; file_name: string; file_data: string }[] }>(`/api/admissions/${admission.id}/attachments`, { retries: 1 });
            const rows = json.data || [];
            setFetchedAttachments(rows.map((r): AdmissionAttachment => ({
                id: r.id,
                title: r.title,
                fileName: r.file_name,
                fileData: r.file_data || '',
            })));
        } catch {
            setAttachmentsError('LOAD_ERROR');
        } finally {
            setAttachmentsLoading(false);
        }
    }, [admission.id]);

    useEffect(() => {
        if (tab === 'DOCUMENTOS' && fetchedAttachments === null && !attachmentsLoading) {
            fetchAttachments();
        }
    }, [tab, fetchedAttachments, attachmentsLoading, fetchAttachments]);

    // Merge pre-loaded attachments (from caller) with self-fetched ones; prefer fetched (has fileData)
    const resolvedAttachments: AdmissionAttachment[] =
        fetchedAttachments !== null
            ? fetchedAttachments
            : (admission.attachments || []);

    // Lazy-load legal scan data when AUDITORIA tab is opened
    const [fetchedLegalScan, setFetchedLegalScan] = useState<LegalScanData | null | 'NOT_FOUND' | 'PERMISSION_DENIED' | 'LOAD_ERROR'>(
        admission.legalScan ? admission.legalScan : null
    );
    const [legalScanLoading, setLegalScanLoading] = useState(false);

    const fetchLegalScan = useCallback(async () => {
        if (!admission.id) return;
        setLegalScanLoading(true);
        try {
            const res = await fetch(`/api/admissions/${admission.id}/legal-scan`, { credentials: 'include' });
            if (res.status === 403) { setFetchedLegalScan('PERMISSION_DENIED'); return; }
            if (!res.ok) throw new Error(`HTTP ${res.status}`);
            const json: { data: LegalScanData | null } = await res.json();
            setFetchedLegalScan(json.data ?? 'NOT_FOUND');
        } catch {
            setFetchedLegalScan('LOAD_ERROR');
        } finally {
            setLegalScanLoading(false);
        }
    }, [admission.id]);

    useEffect(() => {
        if (tab === 'AUDITORIA' && fetchedLegalScan === null && !legalScanLoading) {
            fetchLegalScan();
        }
    }, [tab, fetchedLegalScan, legalScanLoading, fetchLegalScan]);

    const resolvedLegalScan: LegalScanData | null =
        fetchedLegalScan !== null && typeof fetchedLegalScan === 'object' ? fetchedLegalScan : null;

    const hasAttachments = resolvedAttachments.length > 0;
    const hasLegalScan = !!resolvedLegalScan;
    const hasAuditRounds = (admission.auditHistory || []).length > 0;

    const handleDownload = (att: AdmissionAttachment) => {
        const link = document.createElement('a');
        link.href = att.fileData;
        link.download = att.fileName || att.title || 'documento';
        link.click();
    };

    const handleViewAttachment = (att: AdmissionAttachment) => {
        const win = window.open();
        if (win) {
            win.document.write(
                `<html><head><title>${att.title || att.fileName}</title></head>` +
                `<body style="margin:0;padding:0;background:#111;">` +
                `<iframe src="${att.fileData}" frameborder="0" style="border:0;top:0;left:0;bottom:0;right:0;width:100vw;height:100vh;" allowfullscreen></iframe>` +
                `</body></html>`
            );
        }
    };

    const fmtDate = (d?: string | null) => {
        if (!d) return '—';
        try { return new Date(d + (d.length === 10 ? 'T12:00:00' : '')).toLocaleDateString('pt-BR'); } catch { return d; }
    };

    return (
        <div className="fixed inset-0 z-[10010] flex items-start justify-center bg-black/70 backdrop-blur-sm p-2 sm:p-4 overflow-y-auto">
            <div role="dialog" aria-modal="true" className="responsive-modal-surface bg-white rounded-2xl shadow-2xl w-full max-w-4xl sm:my-4 overflow-hidden flex flex-col">
                {/* Header */}
                <div className="bg-moss-800 px-6 py-4 flex items-center justify-between">
                    <div>
                        <h2 className="text-white font-black text-base uppercase tracking-wider">Ficha de Admissão</h2>
                        <p className="text-moss-200 text-xs mt-0.5">{clientName} · Contrato #{fmt(admission.contractNumber)} · <span className="font-bold">{fmt(admission.status)}</span></p>
                    </div>
                    <button onClick={onClose} className="text-moss-300 hover:text-white transition-colors p-1 rounded-lg hover:bg-moss-700">
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg>
                    </button>
                </div>

                {/* Tabs */}
                <div className="flex border-b border-gray-200 bg-gray-50 overflow-x-auto">
                    {(['FICHA', 'FINANCEIRO', 'DOCUMENTOS', 'AUDITORIA'] as const).map(t => (
                        <button
                            key={t}
                            onClick={() => setTab(t)}
                            className={`px-5 py-3 text-xs font-bold uppercase tracking-wider transition-colors border-b-2 -mb-px whitespace-nowrap ${tab === t ? 'border-moss-600 text-moss-700 bg-white' : 'border-transparent text-gray-500 hover:text-gray-700'}`}
                        >
                            {t === 'FICHA' ? 'Identificação' : t === 'FINANCEIRO' ? 'Contrato / Financeiro' : t === 'DOCUMENTOS' ? `Documentos (${resolvedAttachments.length + bucketCount})` : 'Auditoria'}
                        </button>
                    ))}
                </div>

                <div className="p-4 sm:p-6 flex-1 min-h-0 overflow-y-auto">
                    {/* === TAB: FICHA === */}
                    {tab === 'FICHA' && (
                        <div className="space-y-5">
                            {/* Identificação Principal */}
                            <section>
                                <h3 className="text-[10px] font-black uppercase tracking-widest text-moss-700 mb-3 flex items-center gap-2">
                                    <div className="w-1.5 h-4 rounded-full bg-moss-500"></div>
                                    Identificação do Processo
                                </h3>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                                    <div className="bg-gray-50 rounded-lg p-3 col-span-2">
                                        <p className="text-[10px] text-gray-400 font-bold uppercase mb-0.5">Cliente (Responsável)</p>
                                        <p className="font-semibold text-gray-800">{clientName}</p>
                                    </div>
                                    <div className="bg-gray-50 rounded-lg p-3">
                                        <p className="text-[10px] text-gray-400 font-bold uppercase mb-0.5">Contrato</p>
                                        <p className="font-mono font-bold text-moss-700">#{fmt(admission.contractNumber)}</p>
                                    </div>
                                    <div className="bg-gray-50 rounded-lg p-3">
                                        <p className="text-[10px] text-gray-400 font-bold uppercase mb-0.5">Data Admissão</p>
                                        <p className="font-semibold text-gray-800">{fmtDate(admission.date)}</p>
                                    </div>
                                    <div className="bg-gray-50 rounded-lg p-3">
                                        <p className="text-[10px] text-gray-400 font-bold uppercase mb-0.5">Status</p>
                                        <p className="font-bold text-gray-800">{fmt(admission.status)}</p>
                                    </div>
                                    <div className="bg-gray-50 rounded-lg p-3">
                                        <p className="text-[10px] text-gray-400 font-bold uppercase mb-0.5">Tipo Cliente</p>
                                        <p className="font-semibold text-gray-800">{fmt(admission.tipoCliente)}</p>
                                    </div>
                                    <div className="bg-gray-50 rounded-lg p-3">
                                        <p className="text-[10px] text-gray-400 font-bold uppercase mb-0.5">Série</p>
                                        <p className="font-semibold text-gray-800">{fmt(seriesSigla)}</p>
                                    </div>
                                    <div className="bg-gray-50 rounded-lg p-3">
                                        <p className="text-[10px] text-gray-400 font-bold uppercase mb-0.5">Colaborador</p>
                                        <p className="font-semibold text-gray-800">{fmt(collaboratorName)}</p>
                                    </div>
                                    <div className="bg-gray-50 rounded-lg p-3">
                                        <p className="text-[10px] text-gray-400 font-bold uppercase mb-0.5">Indicação</p>
                                        <p className="font-semibold text-gray-800">{fmt(admission.indicationType)}</p>
                                    </div>
                                    <div className="bg-gray-50 rounded-lg p-3">
                                        <p className="text-[10px] text-gray-400 font-bold uppercase mb-0.5">Origem</p>
                                        <p className="font-semibold text-gray-800">{fmt(admission.originType)}</p>
                                    </div>
                                    {unitName && (
                                        <div className="bg-emerald-50 rounded-lg p-3 col-span-2">
                                            <p className="text-[10px] text-emerald-500 font-bold uppercase mb-0.5">Unidade</p>
                                            <p className="font-bold text-emerald-800">{unitName}</p>
                                        </div>
                                    )}
                                </div>
                            </section>

                            {/* Dados do Responsável */}
                            {client && (
                                <section>
                                    <h3 className="text-[10px] font-black uppercase tracking-widest text-blue-700 mb-3 flex items-center gap-2">
                                        <div className="w-1.5 h-4 rounded-full bg-blue-500"></div>
                                        Dados do Responsável
                                    </h3>
                                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                                        <div className="bg-blue-50 rounded-lg p-3">
                                            <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">CPF/CNPJ</p>
                                            <p className="font-mono font-semibold text-blue-900">{fmt((client as any).document)}</p>
                                        </div>
                                        <div className="bg-blue-50 rounded-lg p-3">
                                            <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">RG</p>
                                            <p className="font-semibold text-blue-900">{fmt((client as any).rg)}</p>
                                        </div>
                                        <div className="bg-blue-50 rounded-lg p-3">
                                            <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Data de Nascimento</p>
                                            <p className="font-semibold text-blue-900">{fmtDate((client as any).birthDate)}</p>
                                        </div>
                                        <div className="bg-blue-50 rounded-lg p-3">
                                            <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Estado Civil</p>
                                            <p className="font-semibold text-blue-900">{fmt((client as any).maritalStatus)}</p>
                                        </div>
                                        <div className="bg-blue-50 rounded-lg p-3">
                                            <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Profissão</p>
                                            <p className="font-semibold text-blue-900">{fmt((client as any).profession)}</p>
                                        </div>
                                        <div className="bg-blue-50 rounded-lg p-3">
                                            <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Tipo</p>
                                            <p className="font-semibold text-blue-900">{fmt((client as any).type)}</p>
                                        </div>
                                        <div className="bg-blue-50 rounded-lg p-3">
                                            <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Telefone</p>
                                            <p className="font-semibold text-blue-900">{fmt((client as any).phone)}</p>
                                        </div>
                                        <div className="bg-blue-50 rounded-lg p-3">
                                            <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Telefone 2</p>
                                            <p className="font-semibold text-blue-900">{fmt((client as any).phone2)}</p>
                                        </div>
                                        <div className="bg-blue-50 rounded-lg p-3">
                                            <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">E-mail</p>
                                            <p className={`font-semibold ${(client as any).email ? 'text-blue-900' : 'text-red-500'}`}>{fmt((client as any).email)}</p>
                                        </div>
                                        {((client as any).address || (client as any).city) && (
                                            <div className="bg-blue-50 rounded-lg p-3 col-span-2 md:col-span-3">
                                                <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Endereço</p>
                                                <p className="font-semibold text-blue-900">
                                                    {[(client as any).address, (client as any).number ? `Nº ${(client as any).number}` : null, (client as any).complement, (client as any).district].filter(Boolean).join(', ')}
                                                </p>
                                                <p className="text-xs text-blue-700 mt-0.5">
                                                    {[(client as any).city, (client as any).state].filter(Boolean).join(' - ')}{(client as any).cep ? ` | CEP: ${(client as any).cep}` : ''}
                                                </p>
                                            </div>
                                        )}
                                        {(client as any).notes && (
                                            <div className="bg-blue-50 rounded-lg p-3 col-span-2 md:col-span-3">
                                                <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Anotações</p>
                                                <p className="text-sm text-blue-800 whitespace-pre-wrap">{(client as any).notes}</p>
                                            </div>
                                        )}
                                    </div>
                                </section>
                            )}

                            {/* Dados do Titular */}
                            {titular && (
                                <section>
                                    <h3 className="text-[10px] font-black uppercase tracking-widest text-cyan-700 mb-3 flex items-center gap-2">
                                        <div className="w-1.5 h-4 rounded-full bg-cyan-500"></div>
                                        Dados do Titular
                                    </h3>
                                    <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                                        <div className="bg-cyan-50 rounded-lg p-3 col-span-2">
                                            <p className="text-[10px] text-cyan-400 font-bold uppercase mb-0.5">Nome</p>
                                            <p className="font-bold text-cyan-900">{fmt((titular as any).name)}</p>
                                        </div>
                                        <div className="bg-cyan-50 rounded-lg p-3">
                                            <p className="text-[10px] text-cyan-400 font-bold uppercase mb-0.5">CPF/CNPJ</p>
                                            <p className="font-mono font-semibold text-cyan-900">{fmt((titular as any).document)}</p>
                                        </div>
                                        <div className="bg-cyan-50 rounded-lg p-3">
                                            <p className="text-[10px] text-cyan-400 font-bold uppercase mb-0.5">RG</p>
                                            <p className="font-semibold text-cyan-900">{fmt((titular as any).rg)}</p>
                                        </div>
                                        <div className="bg-cyan-50 rounded-lg p-3">
                                            <p className="text-[10px] text-cyan-400 font-bold uppercase mb-0.5">Telefone</p>
                                            <p className="font-semibold text-cyan-900">{fmt((titular as any).phone)}</p>
                                        </div>
                                        <div className="bg-cyan-50 rounded-lg p-3">
                                            <p className="text-[10px] text-cyan-400 font-bold uppercase mb-0.5">E-mail</p>
                                            <p className="font-semibold text-cyan-900">{fmt((titular as any).email)}</p>
                                        </div>
                                    </div>
                                </section>
                            )}

                            {/* Veículo */}
                            {admission.vehicleBrand && (
                                <section>
                                    <h3 className="text-[10px] font-black uppercase tracking-widest text-purple-700 mb-3 flex items-center gap-2">
                                        <div className="w-1.5 h-4 rounded-full bg-purple-500"></div>
                                        Dados do Veículo
                                        {admission.isElectricVehicle && <span className="text-[8px] bg-green-600 text-white px-1.5 py-0.5 rounded font-black ml-1">ELÉTRICO</span>}
                                    </h3>
                                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                                        {[
                                            ['Marca', admission.vehicleBrand], ['Modelo', admission.vehicleModel],
                                            ['Ano', admission.vehicleYear], ['Placa', admission.vehiclePlate],
                                            ['Cor', admission.vehicleColor], ['Chassi', admission.vehicleChassis],
                                            ['Renavam', admission.vehicleRenavam],
                                        ].map(([label, value]) => value ? (
                                            <div key={label} className="bg-purple-50 rounded-lg p-3">
                                                <p className="text-[10px] text-purple-400 font-bold uppercase mb-0.5">{label}</p>
                                                <p className="font-semibold text-purple-900">{value}</p>
                                            </div>
                                        ) : null)}
                                    </div>
                                </section>
                            )}

                            {/* Informações Adicionais */}
                            {(admission.otherInfo1 || admission.otherInfo2) && (
                                <section>
                                    <h3 className="text-[10px] font-black uppercase tracking-widest text-amber-700 mb-3 flex items-center gap-2">
                                        <div className="w-1.5 h-4 rounded-full bg-amber-500"></div>
                                        Informações Adicionais
                                    </h3>
                                    <div className="grid grid-cols-2 gap-3">
                                        {admission.otherInfo1 && <div className="bg-amber-50 rounded-lg p-3 border border-amber-100 text-sm text-gray-700"><span className="text-xs font-bold text-amber-600 block mb-1">Taxa Administração (R$)</span>{admission.otherInfo1}</div>}
                                        {admission.otherInfo2 && <div className="bg-amber-50 rounded-lg p-3 border border-amber-100 text-sm text-gray-700"><span className="text-xs font-bold text-amber-600 block mb-1">Primeira Parcela (R$)</span>{admission.otherInfo2}</div>}
                                    </div>
                                </section>
                            )}
                        </div>
                    )}

                    {/* === TAB: FINANCEIRO === */}
                    {tab === 'FINANCEIRO' && (
                        <div className="space-y-5">
                            {/* Banco e Modalidade */}
                            <section>
                                <h3 className="text-[10px] font-black uppercase tracking-widest text-indigo-700 mb-3 flex items-center gap-2">
                                    <div className="w-1.5 h-4 rounded-full bg-indigo-500"></div>
                                    Banco e Modalidade
                                </h3>
                                <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                                    <div className="bg-indigo-50 rounded-lg p-3 col-span-2">
                                        <p className="text-[10px] text-indigo-400 font-bold uppercase mb-0.5">Banco</p>
                                        <p className="font-bold text-indigo-900">{bank?.name || '—'}</p>
                                    </div>
                                    <div className="bg-indigo-50 rounded-lg p-3">
                                        <p className="text-[10px] text-indigo-400 font-bold uppercase mb-0.5">Modalidade</p>
                                        <p className="font-semibold text-indigo-900">{modality?.description || modality?.type || '—'}</p>
                                    </div>
                                    {admission.hasBankFeeIncluded && <div className="bg-blue-50 rounded-lg p-3"><p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Tarifa Bancária</p><p className="font-bold text-blue-700">Inclusa</p></div>}
                                    {admission.isThirdPartyContract && <div className="bg-orange-50 rounded-lg p-3"><p className="text-[10px] text-orange-400 font-bold uppercase mb-0.5">Contrato</p><p className="font-bold text-orange-700">De Terceiro</p></div>}
                                </div>

                                {/* Bank Services */}
                                {bank && bank.services && bank.services.length > 0 && (
                                    <div className="mt-3">
                                        <p className="text-[10px] font-black text-indigo-600 uppercase tracking-wider mb-2">Serviços / Percentuais de Negociação</p>
                                        <div className="border border-indigo-100 rounded-lg overflow-hidden">
                                            <table className="w-full text-xs">
                                                <thead className="bg-indigo-50 text-indigo-600 font-bold uppercase text-[9px]">
                                                    <tr>
                                                        <th className="px-3 py-2 text-left">Serviço</th>
                                                        <th className="px-3 py-2 text-right">% Negociação</th>
                                                        <th className="px-3 py-2 text-right">Sobre Valor Financiado</th>
                                                    </tr>
                                                </thead>
                                                <tbody className="divide-y divide-indigo-50 bg-white">
                                                    {bank.services.map(svc => {
                                                        const parsedFinanced = parseFloat((admission.financedAmount || '0').replace(/\./g, '').replace(',', '.')) || 0;
                                                        const calc = parsedFinanced * (svc.negotiationPercentage / 100);
                                                        return (
                                                            <tr key={svc.id}>
                                                                <td className="px-3 py-2 font-semibold text-gray-800">{svc.name}</td>
                                                                <td className="px-3 py-2 text-right font-bold text-indigo-700">{svc.negotiationPercentage}%</td>
                                                                <td className="px-3 py-2 text-right text-gray-700">
                                                                    {calc > 0 ? `R$ ${calc.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}` : '—'}
                                                                </td>
                                                            </tr>
                                                        );
                                                    })}
                                                </tbody>
                                            </table>
                                        </div>
                                        <p className="text-[9px] text-gray-400 italic mt-1">* Base: valor financiado de R$ {fmt(admission.financedAmount)}</p>
                                    </div>
                                )}
                            </section>

                            {/* Dados Financeiros do Contrato */}
                            <section>
                                <h3 className="text-[10px] font-black uppercase tracking-widest text-blue-700 mb-3 flex items-center gap-2">
                                    <div className="w-1.5 h-4 rounded-full bg-blue-500"></div>
                                    Dados Financeiros do Contrato
                                </h3>
                                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                                    <div className="bg-blue-50 rounded-lg p-3">
                                        <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Valor Financiado</p>
                                        <p className="font-bold text-blue-800">R$ {fmt(admission.financedAmount)}</p>
                                    </div>
                                    <div className="bg-blue-50 rounded-lg p-3">
                                        <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Valor Parcela Atual</p>
                                        <p className="font-bold text-blue-800">R$ {fmt(admission.installmentValue)}</p>
                                    </div>
                                    <div className="bg-blue-50 rounded-lg p-3">
                                        <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Total Parcelas</p>
                                        <p className="font-bold text-blue-800">{fmt(String(admission.totalInstallments || ''))}</p>
                                    </div>
                                    <div className="bg-blue-50 rounded-lg p-3">
                                        <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Pagas / Em Atraso</p>
                                        <p className="font-bold text-blue-800">{admission.paidInstallments || 0} / <span className="text-red-600">{admission.overdueInstallments || 0}</span></p>
                                    </div>
                                    <div className="bg-blue-50 rounded-lg p-3">
                                        <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Dia Vencimento</p>
                                        <p className="font-bold text-blue-800">Dia {fmt(String(admission.dueDay || ''))}</p>
                                    </div>
                                    <div className="bg-blue-50 rounded-lg p-3">
                                        <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Tipo Pagamento</p>
                                        <p className="font-bold text-blue-800">{fmt(admission.paymentType)}</p>
                                    </div>
                                    {admission.firstInstallmentDueDate && (
                                        <div className="bg-blue-50 rounded-lg p-3">
                                            <p className="text-[10px] text-blue-400 font-bold uppercase mb-0.5">Venc. 1ª Parcela</p>
                                            <p className="font-bold text-blue-800">{fmtDate(admission.firstInstallmentDueDate)}</p>
                                        </div>
                                    )}
                                    {admission.parcela1 && (
                                        <div className="bg-emerald-50 rounded-lg p-3">
                                            <p className="text-[10px] text-emerald-500 font-bold uppercase mb-0.5">Taxa Administrativa</p>
                                            <p className="font-bold text-emerald-800">R$ {admission.parcela1}</p>
                                        </div>
                                    )}
                                    {admission.parcela2 && (
                                        <div className="bg-emerald-50 rounded-lg p-3">
                                            <p className="text-[10px] text-emerald-500 font-bold uppercase mb-0.5">1ª Parcela Real</p>
                                            <p className="font-bold text-emerald-800">R$ {admission.parcela2}</p>
                                        </div>
                                    )}
                                    {admission.taxaCobranca && (
                                        <div className="bg-teal-50 rounded-lg p-3">
                                            <p className="text-[10px] text-teal-500 font-bold uppercase mb-0.5">Taxa de Cobrança</p>
                                            <p className="font-bold text-teal-800">R$ {admission.taxaCobranca}</p>
                                        </div>
                                    )}
                                    {(admission as any).desconto && (
                                        <div className="bg-green-50 rounded-lg p-3">
                                            <p className="text-[10px] text-green-500 font-bold uppercase mb-0.5">Desconto</p>
                                            <p className="font-bold text-green-800">R$ {(admission as any).desconto}</p>
                                        </div>
                                    )}
                                </div>
                            </section>

                            {/* Cenários de Recálculo */}
                            {(admission.recalcScenarios || []).length > 0 && (
                                <section>
                                    <h3 className="text-[10px] font-black uppercase tracking-widest text-purple-700 mb-3 flex items-center gap-2">
                                        <div className="w-1.5 h-4 rounded-full bg-purple-500"></div>
                                        Cenários de Recálculo
                                    </h3>
                                    <div className="overflow-x-auto border border-purple-100 rounded-lg">
                                        <table className="w-full text-xs">
                                            <thead className="bg-purple-50 text-purple-600 font-bold uppercase text-[9px]">
                                                <tr>
                                                    <th className="px-3 py-2 text-left">Cenário</th>
                                                    <th className="px-3 py-2 text-right">Dívida Orig.</th>
                                                    <th className="px-3 py-2 text-right">Nova Dívida</th>
                                                    <th className="px-3 py-2 text-right">Economia</th>
                                                    <th className="px-3 py-2 text-right">Parcelas</th>
                                                    <th className="px-3 py-2 text-right">Vl. Parcela</th>
                                                    <th className="px-3 py-2 text-right">Dia Venc.</th>
                                                </tr>
                                            </thead>
                                            <tbody className="divide-y divide-purple-50 bg-white">
                                                {(admission.recalcScenarios || []).map(sc => (
                                                    <tr key={sc.id}>
                                                        <td className="px-3 py-2 font-bold text-gray-700">{sc.label}</td>
                                                        <td className="px-3 py-2 text-right text-gray-500">{sc.originalDebt}</td>
                                                        <td className="px-3 py-2 text-right text-gray-700 font-bold">{sc.newDebt}</td>
                                                        <td className="px-3 py-2 text-right font-bold text-green-600">{sc.savings}</td>
                                                        <td className="px-3 py-2 text-right text-gray-600">{sc.installmentsToPay || '—'}</td>
                                                        <td className="px-3 py-2 text-right text-gray-600">{sc.installmentValue || '—'}</td>
                                                        <td className="px-3 py-2 text-right text-gray-600">{sc.dueDay || '—'}</td>
                                                    </tr>
                                                ))}
                                            </tbody>
                                        </table>
                                    </div>
                                </section>
                            )}
                        </div>
                    )}

                    {/* === TAB: DOCUMENTOS === */}
                    {tab === 'DOCUMENTOS' && (
                        <div className="space-y-4">
                            {admission.clientId && <ClientAttachmentsPanel
                                clientId={admission.clientId} module="ADMISSION"
                                targetType="ADMISSION" targetId={admission.id}
                                readOnly compact onCountChange={setBucketCount}
                            />}
                            {attachmentsLoading && (
                                <div className="text-center py-12 text-gray-400">
                                    <svg className="w-10 h-10 mx-auto mb-3 animate-spin opacity-40" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>
                                    <p className="text-sm">Carregando documentos...</p>
                                </div>
                            )}
                            {!attachmentsLoading && attachmentsError === 'PERMISSION_DENIED' && (
                                <div className="text-center py-12">
                                    <div className="bg-red-50 border border-red-200 rounded-xl p-6 max-w-sm mx-auto">
                                        <svg className="w-12 h-12 mx-auto mb-3 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /></svg>
                                        <p className="text-sm font-bold text-red-700">Sem permissão de acesso</p>
                                        <p className="text-xs text-red-500 mt-1">Você não tem permissão para visualizar os documentos desta admissão. Solicite acesso ao administrador do sistema.</p>
                                    </div>
                                </div>
                            )}
                            {!attachmentsLoading && attachmentsError === 'LOAD_ERROR' && (
                                <div className="text-center py-12">
                                    <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6 max-w-sm mx-auto">
                                        <svg className="w-12 h-12 mx-auto mb-3 text-yellow-400" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
                                        <p className="text-sm font-bold text-yellow-700">Erro ao carregar documentos</p>
                                        <button onClick={fetchAttachments} className="mt-2 text-xs text-yellow-600 underline hover:text-yellow-800">Tentar novamente</button>
                                    </div>
                                </div>
                            )}
                            {!attachmentsLoading && !attachmentsError && !hasAttachments && (
                                <div className="text-center py-12 text-gray-400">
                                    <svg className="w-14 h-14 mx-auto mb-3 opacity-25" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"/></svg>
                                    <p className="font-semibold text-sm">Nenhum documento anexado a esta admissão.</p>
                                    <p className="text-xs mt-1">Os documentos podem ser adicionados na tela de admissão.</p>
                                </div>
                            )}
                            {!attachmentsLoading && !attachmentsError && hasAttachments && (
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    {resolvedAttachments.map((att: AdmissionAttachment) => {
                                        const isImage = att.fileData?.startsWith('data:image');
                                        const isPdf = att.fileData?.startsWith('data:application/pdf') || att.fileName?.toLowerCase().endsWith('.pdf');
                                        return (
                                            <div key={att.id} className="bg-gray-50 rounded-xl border border-gray-200 p-4 flex flex-col gap-3">
                                                <div className="flex items-start gap-3">
                                                    <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${isImage ? 'bg-blue-100' : isPdf ? 'bg-red-100' : 'bg-gray-200'}`}>
                                                        {isImage ? (
                                                            <svg className="w-5 h-5 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                                                        ) : isPdf ? (
                                                            <svg className="w-5 h-5 text-red-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 21h10a2 2 0 002-2V9.414a1 1 0 00-.293-.707l-5.414-5.414A1 1 0 0012.586 3H7a2 2 0 00-2 2v14a2 2 0 002 2z"/></svg>
                                                        ) : (
                                                            <svg className="w-5 h-5 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13"/></svg>
                                                        )}
                                                    </div>
                                                    <div className="flex-1 min-w-0">
                                                        <p className="font-semibold text-sm text-gray-800 truncate">{att.title || att.fileName}</p>
                                                        <p className="text-xs text-gray-400 truncate">{att.fileName}</p>
                                                    </div>
                                                    <div className="flex gap-1.5 flex-shrink-0">
                                                        <button
                                                            onClick={() => handleViewAttachment(att)}
                                                            className="p-2 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded-lg transition-colors"
                                                            title="Visualizar"
                                                        >
                                                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z"/></svg>
                                                        </button>
                                                        <button
                                                            onClick={() => handleDownload(att)}
                                                            className="p-2 text-moss-600 hover:text-moss-800 hover:bg-moss-50 rounded-lg transition-colors"
                                                            title="Baixar documento"
                                                        >
                                                            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4"/></svg>
                                                        </button>
                                                    </div>
                                                </div>
                                                {isImage && (
                                                    <img
                                                        src={att.fileData}
                                                        alt={att.title}
                                                        className="rounded-lg max-h-48 object-contain border border-gray-200 w-full bg-gray-100 cursor-pointer"
                                                        onClick={() => handleViewAttachment(att)}
                                                        title="Clique para ampliar"
                                                    />
                                                )}
                                            </div>
                                        );
                                    })}
                                </div>
                            )}
                        </div>
                    )}

                    {/* === TAB: AUDITORIA === */}
                    {tab === 'AUDITORIA' && (
                        <div className="space-y-5">
                            {/* Legal Scan */}
                            <section>
                                <h3 className="text-[10px] font-black uppercase tracking-widest text-red-700 mb-3 flex items-center gap-2">
                                    <div className="w-1.5 h-4 rounded-full bg-red-500"></div>
                                    Consulta jurídica registrada
                                </h3>
                                {legalScanLoading ? (
                                    <div className="bg-gray-50 rounded-xl border border-gray-200 p-4 text-center text-gray-400 text-sm animate-pulse">
                                        Carregando consulta jurídica...
                                    </div>
                                ) : fetchedLegalScan === 'PERMISSION_DENIED' ? (
                                    <div className="bg-red-50 rounded-xl border border-red-200 p-4 text-center text-red-600 text-sm">
                                        Sem permissão para visualizar a consulta jurídica.
                                    </div>
                                ) : fetchedLegalScan === 'LOAD_ERROR' ? (
                                    <div className="bg-yellow-50 rounded-xl border border-yellow-200 p-4 text-center text-yellow-700 text-sm">
                                        Erro ao carregar consulta jurídica.
                                    </div>
                                ) : hasLegalScan ? (
                                    <HistoricalLegalScan scan={resolvedLegalScan!} />
                                ) : (
                                    <div className="bg-gray-50 rounded-xl border border-gray-200 p-4 text-center text-gray-400 text-sm">
                                        Consulta jurídica não realizada para esta admissão.
                                    </div>
                                )}
                            </section>

                            {/* Rounds de Auditoria */}
                            <section>
                                <h3 className="text-[10px] font-black uppercase tracking-widest text-amber-700 mb-3 flex items-center gap-2">
                                    <div className="w-1.5 h-4 rounded-full bg-amber-500"></div>
                                    Rounds de Auditoria ({(admission.auditHistory || []).length})
                                </h3>
                                {!hasAuditRounds ? (
                                    <div className="bg-gray-50 rounded-xl border border-gray-200 p-4 text-center text-gray-400 text-sm">
                                        Nenhum round de auditoria registrado.
                                    </div>
                                ) : (
                                    <div className="space-y-3">
                                        {(admission.auditHistory || []).map((round, i) => (
                                            <div key={round.id || i} className="bg-amber-50 rounded-xl border border-amber-200 overflow-hidden">
                                                <div className="bg-amber-100 px-4 py-2 flex justify-between items-center">
                                                    <span className="text-xs font-bold text-amber-800 uppercase">Round #{round.roundNumber}</span>
                                                    <span className="text-[10px] text-amber-600">{round.critiqueDate ? new Date(round.critiqueDate).toLocaleDateString('pt-BR') : ''}</span>
                                                </div>
                                                <div className="p-4 space-y-3">
                                                    <div>
                                                        <p className="text-[10px] font-bold text-amber-600 uppercase mb-1">Crítica{round.critiquedBy ? ` — ${round.critiquedBy}` : ''}</p>
                                                        <p className="text-sm text-gray-700 whitespace-pre-wrap">{round.critique}</p>
                                                    </div>
                                                    {round.response && (
                                                        <div className="bg-white rounded-lg p-3 border border-amber-100">
                                                            <p className="text-[10px] font-bold text-moss-600 uppercase mb-1">Resposta{round.respondedBy ? ` — ${round.respondedBy}` : ''}{round.responseDate ? ` (${new Date(round.responseDate).toLocaleDateString('pt-BR')})` : ''}</p>
                                                            <p className="text-sm text-gray-700 whitespace-pre-wrap">{round.response}</p>
                                                        </div>
                                                    )}
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                )}
                            </section>
                        </div>
                    )}
                </div>

                {/* Footer */}
                <div className="px-6 py-4 bg-gray-50 border-t border-gray-200 flex items-center justify-between">
                    <span className="text-[10px] text-gray-400 font-medium uppercase tracking-wider flex items-center gap-1.5">
                        <svg className="w-3.5 h-3.5 text-gray-300" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"/></svg>
                        Somente visualização
                    </span>
                    <button onClick={onClose} className="px-5 py-2 text-sm font-semibold text-gray-600 hover:text-gray-800 bg-white border border-gray-300 rounded-lg hover:border-gray-400 transition-colors">
                        Fechar
                    </button>
                </div>
            </div>
        </div>
    );
};

export default AdmissionViewerModal;

/**
 * TÍTULO: COMPONENTE DE CAPTURA DE CÂMERA AVANÇADO
 * 
 * Funcionalidades:
 * - Visualização em tempo real (Stream).
 * - Seleção de dispositivo de vídeo (Frontal/Traseira).
 * - Toggle de Espelhamento (Mirror).
 * - Captura em alta resolução (tenta HD/FullHD).
 * - Tratamento de erros de permissão.
 */

import React, { useRef, useState, useEffect, useCallback } from 'react';
import Button from './Button';

interface CameraCaptureProps {
  onCapture: (base64Image: string) => void;
  onClose: () => void;
}

interface VideoDevice {
  deviceId: string;
  label: string;
}

const CameraCapture: React.FC<CameraCaptureProps> = ({ onCapture, onClose }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [devices, setDevices] = useState<VideoDevice[]>([]);
  const [selectedDeviceId, setSelectedDeviceId] = useState<string>('');
  const [isMirrored, setIsMirrored] = useState(true);
  const [isLoading, setIsLoading] = useState(true);

  // 1. Listar dispositivos disponíveis
  useEffect(() => {
    const getDevices = async () => {
      try {
        // Solicita permissão inicial para conseguir listar labels
        await navigator.mediaDevices.getUserMedia({ video: true });
        
        const allDevices = await navigator.mediaDevices.enumerateDevices();
        const videoDevices = allDevices
          .filter(device => device.kind === 'videoinput')
          .map(device => ({
            deviceId: device.deviceId,
            label: device.label || `Câmera ${device.deviceId.slice(0, 5)}...`
          }));
        
        setDevices(videoDevices);
        if (videoDevices.length > 0) {
          setSelectedDeviceId(videoDevices[0].deviceId);
        }
      } catch (err) {
        console.error("Erro ao listar dispositivos:", err);
        setError("Permissão de câmera negada ou dispositivo não encontrado.");
        setIsLoading(false);
      }
    };

    getDevices();
  }, []);

  // 2. Iniciar Stream quando o dispositivo selecionado mudar
  useEffect(() => {
    if (!selectedDeviceId) return;
    startCamera(selectedDeviceId);
    
    // Cleanup ao desmontar ou mudar câmera
    return () => {
      stopCamera();
    };
  }, [selectedDeviceId]);

  const startCamera = async (deviceId: string) => {
    stopCamera(); // Garante que o anterior foi fechado
    setIsLoading(true);
    setError(null);

    try {
      const mediaStream = await navigator.mediaDevices.getUserMedia({ 
        video: { 
          deviceId: { exact: deviceId },
          width: { ideal: 1280 }, // Tenta HD
          height: { ideal: 720 }
        } 
      });
      
      setStream(mediaStream);
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      console.error("Erro ao acessar câmera:", err);
      setError("Não foi possível acessar a câmera selecionada.");
    } finally {
      setIsLoading(false);
    }
  };

  const stopCamera = () => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
  };

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const context = canvasRef.current.getContext('2d');
      if (context) {
        const video = videoRef.current;
        const width = video.videoWidth;
        const height = video.videoHeight;
        
        canvasRef.current.width = width;
        canvasRef.current.height = height;
        
        // Aplica espelhamento se necessário
        if (isMirrored) {
          context.translate(width, 0);
          context.scale(-1, 1);
        }

        context.drawImage(video, 0, 0, width, height);
        
        // Exporta como JPEG qualidade 0.85
        const dataUrl = canvasRef.current.toDataURL('image/jpeg', 0.85);
        
        // Som de obturador simulado (opcional, visual)
        video.pause(); 
        setTimeout(() => {
            onCapture(dataUrl);
            stopCamera();
        }, 300);
      }
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black bg-opacity-80 p-4 animate-fade-in backdrop-blur-sm">
      <div className="bg-white rounded-xl shadow-2xl p-5 w-full max-w-lg flex flex-col items-center relative overflow-hidden">
        
        <div className="flex justify-between w-full items-center mb-4">
            <h3 className="text-xl font-bold text-gray-800">Capturar Foto</h3>
            <button onClick={onClose} className="text-gray-400 hover:text-gray-600 font-bold text-xl">&times;</button>
        </div>
        
        {/* Error State */}
        {error ? (
          <div className="text-red-600 mb-6 text-center text-sm p-6 bg-red-50 rounded w-full border border-red-100">
            <div className="mb-2 font-bold text-lg">⚠️ Ops!</div>
            {error}
            <div className="mt-4">
                <Button variant="outline" onClick={onClose}>Fechar</Button>
            </div>
          </div>
        ) : (
          /* Camera View */
          <div className="relative bg-black rounded-lg overflow-hidden mb-4 w-full aspect-video shadow-inner group">
            {isLoading && (
                <div className="absolute inset-0 flex items-center justify-center text-white/50 z-10">
                    <svg className="animate-spin h-8 w-8 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                </div>
            )}
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              className={`w-full h-full object-cover transition-transform duration-200 ${isMirrored ? 'scale-x-[-1]' : ''}`} 
            />
            
            {/* Overlay Controls (Mirror) */}
            <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button 
                    onClick={() => setIsMirrored(!isMirrored)}
                    className="bg-black/50 text-white p-2 rounded-full hover:bg-black/70 text-xs flex items-center gap-1 backdrop-blur-sm"
                    title="Espelhar"
                >
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7h12m0 0l-4-4m4 4l-4 4m0 6H4m0 0l4 4m-4-4l4-4" /></svg>
                </button>
            </div>
          </div>
        )}

        {/* Hidden Canvas */}
        <canvas ref={canvasRef} className="hidden" />

        {/* Controls */}
        {!error && (
            <div className="w-full space-y-4">
                {/* Device Selector (if multiple) */}
                {devices.length > 1 && (
                    <div className="flex items-center gap-2 bg-gray-100 p-2 rounded-lg">
                        <svg className="w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /></svg>
                        <select 
                            className="bg-transparent text-sm w-full outline-none text-gray-700 font-medium"
                            value={selectedDeviceId}
                            onChange={(e) => setSelectedDeviceId(e.target.value)}
                        >
                            {devices.map(device => (
                                <option key={device.deviceId} value={device.deviceId}>
                                    {device.label}
                                </option>
                            ))}
                        </select>
                    </div>
                )}

                <div className="flex gap-3 w-full pt-2">
                    <Button variant="outline" onClick={onClose} type="button" className="flex-1">Cancelar</Button>
                    <Button 
                        variant="primary" 
                        onClick={handleCapture} 
                        type="button" 
                        className="flex-[2] bg-emerald-600 hover:bg-emerald-700 border-emerald-600"
                        disabled={isLoading}
                    >
                        {isLoading ? 'Iniciando...' : '📸 Capturar Foto'}
                    </Button>
                </div>
            </div>
        )}
      </div>
    </div>
  );
};

export default CameraCapture;
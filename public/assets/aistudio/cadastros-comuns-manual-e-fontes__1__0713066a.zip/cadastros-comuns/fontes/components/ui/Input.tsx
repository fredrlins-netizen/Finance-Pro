/**
 * TÍTULO: COMPONENTE DE INPUT REUTILIZÁVEL (UI)
 * 
 * Componente genérico para campos de entrada de texto.
 * 
 * Funcionalidades:
 * - Renderização de rótulo (label).
 * - Exibição de mensagens de erro.
 * - Suporte a ícones à esquerda do campo.
 * - Repasse de referências (refs) para foco e navegação.
 * - Estilização consistente com o design system.
 */

import React, { forwardRef } from 'react';

interface InputProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
  icon?: React.ReactNode;
  containerClassName?: string;
  mask?: 'currency';
}

const Input = forwardRef<HTMLInputElement, InputProps>(({ label, error, icon, className = '', containerClassName = '', mask, onChange, ...props }, ref) => {
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (mask === 'currency') {
      const { value } = e.target;
      const digits = value.replace(/\D/g, '');
      const numberValue = parseInt(digits) / 100;
      const formatted = new Intl.NumberFormat('pt-BR', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      }).format(isNaN(numberValue) ? 0 : numberValue);
      
      e.target.value = formatted;
    }
    if (onChange) onChange(e);
  };

  return (
      <div className={`mb-4 ${containerClassName}`}>
      {label && (
        <label className="block text-xs font-bold tracking-wide text-gray-700 mb-1.5">
            {label}
        </label>
      )}
      <div className="relative">
        <input
          ref={ref}
          onChange={handleInputChange}
          className={`
            w-full min-w-0 px-3 sm:px-4 py-3 rounded-lg border text-base
            focus:ring-2 focus:ring-moss-500/25 focus:border-moss-500 outline-none transition-[border-color,box-shadow,background-color] duration-200
            disabled:bg-gray-100 disabled:text-gray-500
            ${error ? 'border-red-500 bg-red-50' : 'border-gray-300 bg-white'}
            ${icon ? 'pl-11' : ''}
            ${mask === 'currency' ? 'text-right' : ''}
            ${className}
          `}
          {...props}
        />
        {icon && (
          <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400">
            {icon}
          </div>
        )}
      </div>
      {error && (
        <p className="mt-1 text-xs text-red-500">{error}</p>
      )}
    </div>
  );
});

Input.displayName = 'Input';
export default Input;
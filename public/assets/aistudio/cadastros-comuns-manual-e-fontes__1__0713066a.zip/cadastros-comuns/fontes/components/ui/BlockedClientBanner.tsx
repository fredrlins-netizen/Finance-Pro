import React, { useEffect, useRef } from 'react';
import { Client } from '../../types';

interface BlockedClientBannerProps {
    client: Client;
    compact?: boolean;
}

const playBlockAlert = () => {
    try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.connect(gain);
        gain.connect(ctx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        osc.frequency.linearRampToValueAtTime(440, ctx.currentTime + 0.4);
        gain.gain.setValueAtTime(0.4, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.45);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.45);
    } catch (_) {}
};

const BlockedClientBanner: React.FC<BlockedClientBannerProps> = ({ client, compact = false }) => {
    const [expanded, setExpanded] = React.useState(false);
    const playedRef = useRef(false);

    useEffect(() => {
        if (!playedRef.current && client?.blocked) {
            playedRef.current = true;
            playBlockAlert();
        }
    }, [client?.id]);

    if (!client?.blocked) return null;

    const isBloqueado = client.blockStatus === 'BLOQUEADO';
    const colorBg = isBloqueado ? 'bg-red-50 border-red-300' : 'bg-amber-50 border-amber-300';
    const colorText = isBloqueado ? 'text-red-800' : 'text-amber-800';
    const colorBadge = isBloqueado ? 'bg-red-600' : 'bg-amber-500';
    const colorIcon = isBloqueado ? 'text-red-500' : 'text-amber-500';
    const colorBtn = isBloqueado ? 'text-red-600 hover:text-red-800' : 'text-amber-600 hover:text-amber-800';
    const pulseClass = isBloqueado ? 'animate-pulse' : '';

    if (compact) {
        return (
            <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black uppercase ${colorBadge} text-white ${pulseClass}`}>
                <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                </svg>
                {client.blockStatus}
            </span>
        );
    }

    return (
        <div className={`rounded-xl border-2 ${colorBg} p-4 mb-4 ${pulseClass}`}>
            <div className="flex items-start gap-3">
                <div className={`flex-shrink-0 w-9 h-9 rounded-full ${colorBadge} flex items-center justify-center`}>
                    <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                    </svg>
                </div>
                <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                        <span className={`text-sm font-black uppercase ${colorText}`}>
                            Cliente {client.blockStatus}
                        </span>
                        <span className="text-xs text-gray-500">
                            — Operações bloqueadas para {client.name}
                        </span>
                    </div>
                    <div className="flex items-center gap-4 mt-1 flex-wrap">
                        {client.blockedAt && (
                            <span className={`text-xs ${colorText} opacity-70`}>
                                Em: {new Date(client.blockedAt).toLocaleString('pt-BR')}
                            </span>
                        )}
                        {client.blockedBy && (
                            <span className={`text-xs ${colorText} opacity-70`}>
                                Por: {client.blockedBy}
                            </span>
                        )}
                    </div>
                    {expanded && client.blockReason && (
                        <div className={`mt-2 text-sm ${colorText} bg-white/60 rounded-lg px-3 py-2 border ${isBloqueado ? 'border-red-200' : 'border-amber-200'}`}>
                            <span className="font-semibold">Motivo: </span>{client.blockReason}
                        </div>
                    )}
                </div>
                <button
                    onClick={() => setExpanded(e => !e)}
                    className={`text-xs font-semibold ${colorBtn} flex-shrink-0 underline`}
                >
                    {expanded ? 'Ocultar motivo' : 'Ver motivo'}
                </button>
            </div>
        </div>
    );
};

export { playBlockAlert };
export default BlockedClientBanner;

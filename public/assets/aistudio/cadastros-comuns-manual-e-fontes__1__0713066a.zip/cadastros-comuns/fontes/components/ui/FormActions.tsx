import React, { useEffect } from 'react';
import Button from './Button';
import { useKeyboardShortcut } from '../../contexts/KeyboardShortcutContext';

interface FormActionsProps {
  onSave?: () => void;
  onCancel?: () => void;
  onClose?: () => void;
  isSaving?: boolean;
}

const FormActions: React.FC<FormActionsProps> = ({ onSave, onCancel, onClose, isSaving }) => {
  const { registerFormActions, unregisterFormActions } = useKeyboardShortcut();

  useEffect(() => {
    registerFormActions(onSave, onCancel);
    return () => unregisterFormActions();
  }, [onSave, onCancel, registerFormActions, unregisterFormActions]);

  return (
    <div className="flex flex-col-reverse sm:flex-row sm:items-center sm:justify-end gap-2 sm:gap-3 mt-8 pt-6 border-t border-gray-200">
      {onClose && (
        <Button
            variant="ghost"
            onClick={onClose}
            type="button"
            className="!w-full sm:!w-auto text-gray-500 hover:text-gray-700"
        >
            Fechar
        </Button>
      )}
      {onCancel && (
        <Button
            variant="outline"
            onClick={onCancel}
            type="button"
            className="!w-full sm:!w-auto border-red-200 text-red-600 hover:bg-red-50 hover:border-red-300"
        >
            Cancelar
        </Button>
      )}
      {onSave && (
        <Button
            variant="primary"
            onClick={onSave}
            isLoading={isSaving}
            type="button"
            title="Salvar Alterações (Ctrl+Enter)"
            className="!w-full sm:!w-auto px-8"
        >
            Salvar Alterações <span className="ml-1 text-[10px] opacity-60 font-mono">Ctrl+↵</span>
        </Button>
      )}
    </div>
  );
};

export default FormActions;

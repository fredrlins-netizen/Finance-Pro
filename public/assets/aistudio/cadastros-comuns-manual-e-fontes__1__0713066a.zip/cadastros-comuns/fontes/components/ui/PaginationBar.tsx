import React from 'react';

interface PaginationBarProps {
  currentPage: number;
  totalPages: number;
  total: number;
  pageSize: number;
  onPageChange: (page: number) => void;
  loading?: boolean;
}

const PaginationBar: React.FC<PaginationBarProps> = ({
  currentPage,
  totalPages,
  total,
  pageSize,
  onPageChange,
  loading = false,
}) => {
  if (totalPages <= 1 && total <= pageSize) return null;

  const from = Math.min((currentPage - 1) * pageSize + 1, total);
  const to = Math.min(currentPage * pageSize, total);

  const pages: (number | '...')[] = [];
  if (totalPages <= 7) {
    for (let i = 1; i <= totalPages; i++) pages.push(i);
  } else {
    pages.push(1);
    if (currentPage > 3) pages.push('...');
    for (let i = Math.max(2, currentPage - 1); i <= Math.min(totalPages - 1, currentPage + 1); i++) {
      pages.push(i);
    }
    if (currentPage < totalPages - 2) pages.push('...');
    pages.push(totalPages);
  }

  return (
    <div data-pagination="compact" className="flex items-center justify-between px-4 py-2 border-t border-gray-200 bg-gray-50 text-sm text-gray-600 select-none">
      <span data-pagination-summary className="text-xs text-gray-500">
        {total > 0 ? `${from}–${to} de ${total} registros` : 'Nenhum registro'}
      </span>
      <div data-pagination-controls className="flex items-center gap-1">
        <button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={currentPage <= 1 || loading}
          className="px-2 py-1 rounded text-xs font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-200 transition-colors"
        >
          ‹ Anterior
        </button>
        {pages.map((p, i) =>
          p === '...' ? (
            <span key={`ellipsis-${i}`} className="px-1 text-gray-400">…</span>
          ) : (
            <button
              key={p}
              onClick={() => onPageChange(p as number)}
              disabled={loading}
              className={`min-w-[28px] px-2 py-1 rounded text-xs font-medium transition-colors disabled:cursor-not-allowed ${
                p === currentPage
                  ? 'bg-moss-700 text-white'
                  : 'hover:bg-gray-200 text-gray-700'
              }`}
            >
              {p}
            </button>
          )
        )}
        <button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={currentPage >= totalPages || loading}
          className="px-2 py-1 rounded text-xs font-medium disabled:opacity-40 disabled:cursor-not-allowed hover:bg-gray-200 transition-colors"
        >
          Próxima ›
        </button>
      </div>
    </div>
  );
};

export default PaginationBar;

/**
 * TÍTULO: PAINEL DE GESTÃO DE BANCOS
 * 
 * Funcionalidades:
 * - Listagem de bancos cadastrados.
 * - Formulário de cadastro de bancos (Código, Descrição, Status, Código Febraban).
 * - Sub-grid para gerenciamento de Serviços Bancários e Percentuais de Negociação.
 * - Sub-grid para gerenciamento de Contatos do banco.
 * - Suporte a criação/edição automática e retorno de ID (Fluxo Admissão).
 */

import React, { useState, useMemo, useEffect } from 'react';
import { PortalConfig, Bank, BankService, BankContact, Modality } from '../../types';
import Button from '../ui/Button';
import GotalkPhoneLink from '../gotalk/GotalkPhoneLink';
import Input from '../ui/Input';
import FormActions from '../ui/FormActions';
import Pagination from '../ui/Pagination';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { checkDependencies, formatDependencyMessage } from '../../utils/dependencyCheck';
import AuditLogButton from '../ui/AuditLogButton';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';
import { api } from '../../services/apiService';

interface BanksPanelProps {
  config: PortalConfig;
  autoStartCreate?: boolean;
  externalEditId?: string;
  onBankSelect?: (newBankId: string) => void;
  onCancelSubFlow?: () => void;
}

type SortDirection = 'asc' | 'desc' | null;
interface SortConfig {
    key: keyof Bank | null;
    direction: SortDirection;
}

const BanksPanel: React.FC<BanksPanelProps> = ({ 
    config, 
    autoStartCreate = false,
    externalEditId,
    onBankSelect,
    onCancelSubFlow
}) => {
  const { validarPermissao, temPermissao, addToast } = useSecurity();
  const canIncluir = temPermissao('cad_bancos:INCLUIR');
  const canAlterar = temPermissao('cad_bancos:ALTERAR');
  const canExcluir = temPermissao('cad_bancos:EXCLUIR');
  const { logTransaction } = useAudit();

  const { data: banks, loading: apiLoading, error: apiError, create: apiCreate, update: apiUpdate, remove: apiRemove, refresh: apiRefresh, clearError: apiClearError } = useEntityCRUD<Bank>('banks', { pageSize: 1000 });

  const [isEditing, setIsEditing] = useState(false);
  const [currentBank, setCurrentBank] = useState<Bank | null>(null);
  const [originalBank, setOriginalBank] = useState<Bank | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  
  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string>('');
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: null, direction: null });

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  // ── Tabela de referência FEBRABAN (BrasilAPI) ────────────────────────────────
  // Lista carregada do backend; alimenta o dropdown read-only de Cód. Febraban,
  // que preenche automaticamente o código e a descrição (nome) do banco.
  const [febrabanBanks, setFebrabanBanks] = useState<{ code: string; name: string; fullName?: string }[]>([]);
  const [febrabanSearch, setFebrabanSearch] = useState('');
  const [febrabanOpen, setFebrabanOpen] = useState(false);
  const febrabanBoxRef = React.useRef<HTMLDivElement>(null);

  useEffect(() => {
    let cancelled = false;
    api.get<{ banks: { code: string; name: string; fullName?: string }[] }>('/api/febraban-banks')
      .then(d => { if (!cancelled) setFebrabanBanks(d.banks || []); })
      .catch(() => { /* lista de referência indisponível — campo continua usável */ });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    const onClickOutside = (e: MouseEvent) => {
      if (febrabanBoxRef.current && !febrabanBoxRef.current.contains(e.target as Node)) {
        setFebrabanOpen(false);
      }
    };
    document.addEventListener('mousedown', onClickOutside);
    return () => document.removeEventListener('mousedown', onClickOutside);
  }, []);

  const filteredFebraban = useMemo(() => {
    const q = febrabanSearch.trim().toLowerCase();
    if (!q) return febrabanBanks.slice(0, 100);
    return febrabanBanks.filter(b =>
      b.code.toLowerCase().includes(q) ||
      b.name.toLowerCase().includes(q) ||
      (b.fullName || '').toLowerCase().includes(q)
    ).slice(0, 100);
  }, [febrabanBanks, febrabanSearch]);

  // ── Serviços ────────────────────────────────────────────────────────────────
  const [newServiceName, setNewServiceName] = useState('');
  const [newServicePercent, setNewServicePercent] = useState('');
  const [newServiceModalityId, setNewServiceModalityId] = useState('');
  const [isLoadingServices, setIsLoadingServices] = useState(false);
  const [modalities, setModalities] = useState<Modality[]>([]);

  const [editingServiceId, setEditingServiceId] = useState<string | null>(null);
  const [editServiceName, setEditServiceName] = useState('');
  const [editServicePercent, setEditServicePercent] = useState('');
  const [editServiceModalityId, setEditServiceModalityId] = useState('');

  // ── Contatos ────────────────────────────────────────────────────────────────
  const [newContactName, setNewContactName] = useState('');
  const [newContactSector, setNewContactSector] = useState('');
  const [newContactPhone, setNewContactPhone] = useState('');
  const [newContactMobile, setNewContactMobile] = useState('');
  const [newContactIsWhatsapp, setNewContactIsWhatsapp] = useState(false);
  const [newContactEmail, setNewContactEmail] = useState('');
  const [isLoadingContacts, setIsLoadingContacts] = useState(false);

  const [editingContactId, setEditingContactId] = useState<string | null>(null);
  const [editContactName, setEditContactName] = useState('');
  const [editContactSector, setEditContactSector] = useState('');
  const [editContactPhone, setEditContactPhone] = useState('');
  const [editContactMobile, setEditContactMobile] = useState('');
  const [editContactIsWhatsapp, setEditContactIsWhatsapp] = useState(false);
  const [editContactEmail, setEditContactEmail] = useState('');

  useEffect(() => {
      if (apiError) {
          addToast('error', 'Erro', apiError);
          apiClearError();
      }
  }, [apiError]);

  useEffect(() => {
      api.get<{ data: Modality[] }>('/api/modalities?limit=1000')
          .then(res => { if (res.data) setModalities(res.data); })
          .catch(() => {});
  }, []);

  useEffect(() => {
      if (autoStartCreate && !isEditing) {
          handleNewBank();
      } else if (externalEditId && !isEditing) {
          const bank = banks.find(b => b.id === externalEditId);
          if (bank) handleEditBank(bank);
      }
  }, [autoStartCreate, externalEditId, banks]);

  const handleEnterPress = (e: React.KeyboardEvent<HTMLElement>) => {
    if (e.key === 'Enter') {
        e.preventDefault(); 
        const form = e.currentTarget.closest('div[data-form-container="true"]');
        if (!form) return;
        const focusableElements = form.querySelectorAll<HTMLElement>('input:not([disabled]):not([type="hidden"]):not([readonly]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]):not([type="submit"])');
        const focusableArray = Array.from(focusableElements) as HTMLElement[];
        const index = focusableArray.indexOf(e.currentTarget as HTMLElement);
        if (index > -1 && index < focusableArray.length - 1) focusableArray[index + 1].focus();
    }
  };

  const handleNewBank = () => {
    if (!validarPermissao('cad_bancos:INCLUIR')) return;
    const maxId = banks.reduce((max, b) => Math.max(max, parseInt(b.id) || 0), 3000);
    const newBankObj: Bank = {
        id: (maxId + 1).toString(), name: '', status: 'ATIVO', febrabanCode: '', services: [], contacts: [], notes: ''
    };
    setCurrentBank(newBankObj);
    setOriginalBank(null);
    setIsEditing(true);
  };

  const loadServicesAndContacts = async (bankId: string): Promise<{ services: BankService[]; contacts: BankContact[] }> => {
    const [svcRes, ctcRes] = await Promise.allSettled([
      api.get<{ data: any[] }>(`/api/banks/${bankId}/services`),
      api.get<{ data: any[] }>(`/api/banks/${bankId}/contacts`),
    ]);

    const services = svcRes.status === 'fulfilled'
      ? (svcRes.value.data || []).map((s: any) => ({
          id: s.id,
          name: s.name,
          negotiationPercentage: parseFloat(s.negotiationPercentage ?? s.negotiation_percentage ?? 0),
          modalityId: s.modality_id ?? s.modalityId ?? '',
          modalityDescription: s.modality_description ?? s.modalityDescription ?? '',
        }))
      : [];

    const contacts = ctcRes.status === 'fulfilled'
      ? (ctcRes.value.data || []).map((c: any) => ({
          id: c.id,
          bankId: c.bank_id,
          name: c.name,
          sector: c.sector ?? '',
          phone: c.phone ?? '',
          mobile: c.mobile ?? '',
          isWhatsapp: c.is_whatsapp ?? false,
          email: c.email ?? '',
        }))
      : [];

    return { services, contacts };
  };

  const handleEditBank = async (bank: Bank) => {
    if (!validarPermissao('cad_bancos:ALTERAR')) return;
    setCurrentBank({ ...bank, services: [], contacts: [] });
    setOriginalBank({ ...bank });
    setIsEditing(true);
    setIsLoadingServices(true);
    setIsLoadingContacts(true);
    try {
        const { services, contacts } = await loadServicesAndContacts(bank.id);
        setCurrentBank(prev => prev ? { ...prev, services, contacts } : null);
    } catch {
        // não bloqueia a edição se sub-grids falharem ao carregar
    } finally {
        setIsLoadingServices(false);
        setIsLoadingContacts(false);
    }
  };

  const handleDuplicateBank = async (bank: Bank) => {
    if (!validarPermissao('cad_bancos:INCLUIR')) return;
    const maxId = banks.reduce((max, b) => Math.max(max, parseInt(b.id) || 0), 3000);
    const dupBank: Bank = { ...bank, id: (maxId + 1).toString(), name: 'Cópia de ' + bank.name, services: [], contacts: [] };
    setCurrentBank(dupBank);
    setOriginalBank(null);
    setIsEditing(true);
    setIsLoadingServices(true);
    setIsLoadingContacts(true);
    try {
      const { services, contacts } = await loadServicesAndContacts(bank.id);
      setCurrentBank(prev => prev ? {
        ...prev,
        services: services.map(s => ({ ...s, id: 'srv-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5) })),
        contacts: contacts.map(c => ({ ...c, id: 'ctc-' + Date.now() + '-' + Math.random().toString(36).substr(2, 5) })),
      } : null);
    } catch {
      // não bloqueia a duplicação
    } finally {
      setIsLoadingServices(false);
      setIsLoadingContacts(false);
    }
  };

  const handleDeleteBank = async (id: string) => {
    if (!validarPermissao('cad_bancos:EXCLUIR')) return;
    const result = checkDependencies('bank', id, config);
    if (!result.canDelete) {
        const bankName = banks.find(b => b.id === id)?.name || id;
        addToast('warning', 'Exclusão Bloqueada', formatDependencyMessage(`o banco "${bankName}"`, result.dependencies));
        return;
    }
    if (window.confirm('Tem certeza que deseja excluir este banco?')) {
        const bankToDelete = banks.find(b => b.id === id);
        try {
            await apiRemove(id);
            logTransaction('BANCO', id, bankToDelete, null);
            addToast('success', 'Sucesso', 'Banco excluído.');
        } catch {
            addToast('error', 'Erro', 'Erro ao excluir banco.');
        }
    }
  };

  const handleSave = async () => {
      if (!currentBank?.name) {
          addToast('warning', 'Validação', 'Descrição do banco é obrigatória.');
          return;
      }
      
      setIsSaving(true);
      try {
          const isNew = !originalBank;
          let savedBank: Bank;

          if (isNew) {
              savedBank = await apiCreate(currentBank);
          } else {
              savedBank = await apiUpdate(currentBank.id, currentBank);
          }

          await Promise.allSettled([
            api.put(`/api/banks/${savedBank.id}/services`, { services: currentBank.services || [] }),
            api.put(`/api/banks/${savedBank.id}/contacts`, { contacts: currentBank.contacts || [] }),
          ]);

          logTransaction('BANCO', savedBank.id, originalBank, savedBank);
          setIsEditing(false);

          if (onBankSelect) {
              onBankSelect(savedBank.id);
              return;
          }

          setCurrentBank(null);
          setOriginalBank(null);
          addToast('success', 'Sucesso', 'Banco salvo com sucesso.');
      } catch {
          addToast('error', 'Erro', 'Erro ao salvar banco.');
      } finally {
          setIsSaving(false);
      }
  };

  const handleCancel = () => {
      setIsEditing(false);
      setCurrentBank(null);
      setOriginalBank(null);
      if (onCancelSubFlow) onCancelSubFlow();
  };

  // ── Handlers — Serviços ────────────────────────────────────────────────────

  const handleAddService = () => {
      if (!newServiceName || !newServicePercent) {
          addToast('warning', 'Atenção', 'Informe o nome e o percentual do serviço.');
          return;
      }
      if (currentBank) {
          const selectedModality = modalities.find(m => m.id === newServiceModalityId);
          const newService: BankService = {
              id: 'srv-' + Date.now(),
              name: newServiceName,
              negotiationPercentage: parseFloat(newServicePercent.replace(',', '.')) || 0,
              modalityId: newServiceModalityId || undefined,
              modalityDescription: selectedModality ? selectedModality.description : undefined,
          };
          setCurrentBank({...currentBank, services: [...currentBank.services, newService]});
          setNewServiceName('');
          setNewServicePercent('');
          setNewServiceModalityId('');
      }
  };

  const handleRemoveService = (serviceId: string) => {
      if (currentBank) setCurrentBank({...currentBank, services: currentBank.services.filter(s => s.id !== serviceId)});
      if (editingServiceId === serviceId) setEditingServiceId(null);
  };

  const handleStartEditService = (srv: BankService) => {
      setEditingServiceId(srv.id);
      setEditServiceName(srv.name);
      setEditServicePercent(srv.negotiationPercentage?.toString() ?? '');
      setEditServiceModalityId(srv.modalityId ?? '');
  };

  const handleSaveEditService = () => {
      if (!editServiceName.trim() || !editServicePercent) {
          addToast('warning', 'Atenção', 'Informe o nome e o percentual do serviço.');
          return;
      }
      if (!currentBank) return;
      const selectedModality = modalities.find(m => m.id === editServiceModalityId);
      setCurrentBank({
          ...currentBank,
          services: currentBank.services.map(s =>
              s.id === editingServiceId
                  ? { ...s, name: editServiceName.trim(), negotiationPercentage: parseFloat(editServicePercent.replace(',', '.')) || 0, modalityId: editServiceModalityId || undefined, modalityDescription: selectedModality?.description }
                  : s
          ),
      });
      setEditingServiceId(null);
  };

  const handleCancelEditService = () => setEditingServiceId(null);

  // ── Handlers — Contatos ────────────────────────────────────────────────────

  const applyPhoneMask = (value: string, type: 'telefone' | 'celular'): string => {
      let d = value.replace(/\D/g, '');
      if (type === 'celular') {
          if (d.length > 11) d = d.slice(0, 11);
          if (d.length > 7) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
          if (d.length > 2) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
          if (d.length > 0) return `(${d}`;
          return d;
      } else {
          if (d.length > 10) d = d.slice(0, 10);
          if (d.length > 6) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
          if (d.length > 2) return `(${d.slice(0, 2)}) ${d.slice(2)}`;
          if (d.length > 0) return `(${d}`;
          return d;
      }
  };

  const handleAddContact = () => {
      if (!newContactName.trim()) {
          addToast('warning', 'Atenção', 'Informe o nome do contato.');
          return;
      }
      if (currentBank) {
          const newContact: BankContact = {
              id: 'ctc-' + Date.now(),
              name: newContactName.trim(),
              sector: newContactSector.trim(),
              phone: newContactPhone.replace(/\D/g, ''),
              mobile: newContactMobile.replace(/\D/g, ''),
              isWhatsapp: newContactIsWhatsapp,
              email: newContactEmail.trim(),
          };
          setCurrentBank({ ...currentBank, contacts: [...(currentBank.contacts || []), newContact] });
          setNewContactName('');
          setNewContactSector('');
          setNewContactPhone('');
          setNewContactMobile('');
          setNewContactIsWhatsapp(false);
          setNewContactEmail('');
      }
  };

  const handleRemoveContact = (contactId: string) => {
      if (currentBank) setCurrentBank({ ...currentBank, contacts: (currentBank.contacts || []).filter(c => c.id !== contactId) });
      if (editingContactId === contactId) setEditingContactId(null);
  };

  const handleStartEditContact = (c: BankContact) => {
      setEditingContactId(c.id);
      setEditContactName(c.name);
      setEditContactSector(c.sector || '');
      setEditContactPhone(c.phone ? applyPhoneMask(c.phone, 'telefone') : '');
      setEditContactMobile(c.mobile ? applyPhoneMask(c.mobile, 'celular') : '');
      setEditContactIsWhatsapp(c.isWhatsapp || false);
      setEditContactEmail(c.email || '');
  };

  const handleSaveEditContact = () => {
      if (!editContactName.trim()) {
          addToast('warning', 'Atenção', 'Informe o nome do contato.');
          return;
      }
      if (!currentBank) return;
      setCurrentBank({
          ...currentBank,
          contacts: (currentBank.contacts || []).map(c =>
              c.id === editingContactId
                  ? { ...c, name: editContactName.trim(), sector: editContactSector.trim(), phone: editContactPhone.replace(/\D/g, ''), mobile: editContactMobile.replace(/\D/g, ''), isWhatsapp: editContactIsWhatsapp, email: editContactEmail.trim() }
                  : c
          ),
      });
      setEditingContactId(null);
  };

  const handleCancelEditContact = () => setEditingContactId(null);

  // ── Sorting / Filtering ────────────────────────────────────────────────────

  const handleSort = (key: keyof Bank) => {
      let direction: SortDirection = 'asc';
      if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
      else if (sortConfig.key === key && sortConfig.direction === 'desc') direction = null;
      setSortConfig({ key: direction ? key : null, direction });
  };

  useEffect(() => { setCurrentPage(1); }, [searchTerm, filterStatus]);

  const sortedAndFilteredBanks = useMemo(() => {
      let data = banks || [];
      data = data.filter(b => {
          const matchesSearch = b.name?.toLowerCase().includes(searchTerm.toLowerCase()) || b.id?.includes(searchTerm) || b.febrabanCode?.includes(searchTerm);
          const matchesStatus = filterStatus ? b.status === filterStatus : true;
          return matchesSearch && matchesStatus;
      });
      if (sortConfig.key && sortConfig.direction) {
          data = [...data].sort((a, b) => {
              if (sortConfig.key === 'services' || sortConfig.key === 'contacts') return 0;
              const valA = a[sortConfig.key!]?.toString().toLowerCase() || '';
              const valB = b[sortConfig.key!]?.toString().toLowerCase() || '';
              if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
              if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
              return 0;
          });
      }
      return data;
  }, [banks, searchTerm, filterStatus, sortConfig]);

  const paginatedBanks = useMemo(() => {
      const firstIndex = (currentPage - 1) * itemsPerPage;
      return sortedAndFilteredBanks.slice(firstIndex, firstIndex + itemsPerPage);
  }, [sortedAndFilteredBanks, currentPage, itemsPerPage]);

  const renderSortIcon = (key: keyof Bank) => {
      if (sortConfig.key !== key) return <span className="text-gray-300 ml-1">⇅</span>;
      if (sortConfig.direction === 'asc') return <span className="text-moss-600 ml-1">↑</span>;
      return <span className="text-moss-600 ml-1">↓</span>;
  };

  const TableHeader = ({ label, sortKey, align = 'left' }: { label: string, sortKey: keyof Bank, align?: string }) => (
      <th className={`px-6 py-3 text-${align} text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 transition-colors select-none`} onClick={() => handleSort(sortKey)}><div className={`flex items-center ${align === 'right' ? 'justify-end' : 'justify-start'}`}>{label}{renderSortIcon(sortKey)}</div></th>
  );

  if (isEditing && currentBank) {
      return (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 animate-fade-in" data-form-container="true">
             <div className="flex justify-between items-center mb-6 pb-4 border-b">
                <h3 className="text-xl font-bold text-gray-800">{originalBank ? 'Editando Banco' : 'Novo Banco'}</h3>
                {onBankSelect && <span className="text-sm font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">Modo de Admissão</span>}
             </div>
             <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="md:col-span-1"><Input label="01. Código" value={currentBank.id} disabled className="bg-gray-100" onKeyDown={handleEnterPress}/></div>
                <div className="md:col-span-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">04. Cód. Febraban</label>
                  <div className="relative" ref={febrabanBoxRef}>
                    <button
                      type="button"
                      onClick={() => { setFebrabanOpen(o => !o); setFebrabanSearch(''); }}
                      className="w-full px-3 py-3 rounded-lg border border-gray-300 text-sm text-left bg-white focus:ring-2 focus:ring-moss-500 outline-none h-[50px] flex items-center justify-between gap-2"
                      title="Selecione o banco pela lista FEBRABAN"
                    >
                      <span className={currentBank.febrabanCode ? 'text-gray-800' : 'text-gray-400'}>
                        {currentBank.febrabanCode
                          ? `${currentBank.febrabanCode}${currentBank.name ? ` — ${currentBank.name}` : ''}`
                          : 'Selecione o banco…'}
                      </span>
                      <svg className="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                    </button>
                    {febrabanOpen && (
                      <div className="absolute z-50 mt-1 w-full min-w-[280px] bg-white border border-gray-200 rounded-lg shadow-lg">
                        <div className="p-2 border-b border-gray-100">
                          <input
                            autoFocus
                            value={febrabanSearch}
                            onChange={e => setFebrabanSearch(e.target.value)}
                            placeholder="Buscar por código ou nome…"
                            className="w-full px-3 py-2 rounded-md border border-gray-300 text-sm focus:ring-2 focus:ring-moss-500 outline-none"
                          />
                        </div>
                        <div className="max-h-60 overflow-y-auto">
                          {febrabanBanks.length === 0 ? (
                            <div className="px-3 py-3 text-sm text-gray-400">Lista FEBRABAN indisponível.</div>
                          ) : filteredFebraban.length === 0 ? (
                            <div className="px-3 py-3 text-sm text-gray-400">Nenhum banco encontrado.</div>
                          ) : (
                            filteredFebraban.map(b => (
                              <button
                                type="button"
                                key={b.code}
                                onClick={() => {
                                  setCurrentBank({ ...currentBank, febrabanCode: b.code, name: b.fullName || b.name });
                                  setFebrabanOpen(false);
                                }}
                                className="w-full text-left px-3 py-2 text-sm hover:bg-moss-50 flex items-start gap-2"
                              >
                                <span className="font-mono font-semibold text-moss-700 w-10 flex-shrink-0">{b.code}</span>
                                <span className="text-gray-700">{b.fullName || b.name}</span>
                              </button>
                            ))
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
                <div className="md:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">03. Status</label><div className="flex gap-4 items-center h-[50px]"><label className="flex items-center space-x-2 cursor-pointer"><input type="radio" name="status" checked={currentBank.status === 'ATIVO'} onChange={() => setCurrentBank({...currentBank, status: 'ATIVO'})} className="h-4 w-4 text-green-600 focus:ring-green-500"/><span className="text-sm font-medium text-gray-700">Ativo</span></label><label className="flex items-center space-x-2 cursor-pointer"><input type="radio" name="status" checked={currentBank.status === 'INATIVO'} onChange={() => setCurrentBank({...currentBank, status: 'INATIVO'})} className="h-4 w-4 text-red-600 focus:ring-red-500"/><span className="text-sm font-medium text-gray-700">Inativo</span></label></div></div>
                <div className="md:col-span-4"><Input label="02. Descrição (Nome do Banco)" value={currentBank.name} onChange={e => setCurrentBank({...currentBank, name: e.target.value})} onKeyDown={handleEnterPress} className="text-left" /></div>

                {/* ── Sub-grid: Serviços Bancários ──────────────────────────── */}
                <div className="md:col-span-4 mt-2 mb-2">
                  <h4 className="text-sm font-bold text-gray-500 uppercase border-b border-gray-100 pb-2 mb-4">05. Serviços Bancários & Percentuais de Negociação</h4>
                  <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <div className="flex flex-col md:flex-row gap-3 mb-4 items-end">
                      <div className="flex-1"><Input label="Serviço / Produto" placeholder="Ex: Empréstimo Pessoal" value={newServiceName} onChange={e => setNewServiceName(e.target.value)} containerClassName="!mb-0"/></div>
                      <div className="w-48"><label className="block text-sm font-medium text-gray-700 mb-1">Modalidade</label><select className="w-full px-3 py-3 rounded-lg border border-gray-300 text-sm focus:ring-2 focus:ring-moss-500 outline-none h-[50px]" value={newServiceModalityId} onChange={e => setNewServiceModalityId(e.target.value)}><option value="">— Nenhuma —</option>{modalities.map(m => (<option key={m.id} value={m.id}>{m.description}</option>))}</select></div>
                      <div className="w-40"><Input label="% Negociação" type="number" placeholder="0.00" value={newServicePercent} onChange={e => setNewServicePercent(e.target.value)} containerClassName="!mb-0"/></div>
                      <Button variant="secondary" className="!w-auto !mb-[1px] h-[50px]" onClick={handleAddService}>+ Adicionar</Button>
                    </div>
                    <div className="bg-white rounded border overflow-hidden">
                      <table className="min-w-full divide-y divide-gray-200 operational-grid">
                        <thead className="bg-gray-100">
                          <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Serviço</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Modalidade</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Percentual (%)</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Ação</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {isLoadingServices && (<tr><td colSpan={4} className="px-4 py-4 text-center text-sm text-gray-400">Carregando serviços...</td></tr>)}
                          {!isLoadingServices && currentBank.services.length === 0 && (<tr><td colSpan={4} className="px-4 py-4 text-center text-sm text-gray-400">Nenhum serviço cadastrado.</td></tr>)}
                          {currentBank.services.map(srv => (
                            <tr key={srv.id} className={editingServiceId === srv.id ? 'bg-blue-50' : 'hover:bg-gray-50'}>
                              {editingServiceId === srv.id ? (
                                <>
                                  <td className="px-2 py-1"><input className="w-full px-2 py-1 border border-blue-300 rounded text-sm" value={editServiceName} onChange={e => setEditServiceName(e.target.value)} placeholder="Nome do serviço" autoFocus /></td>
                                  <td className="px-2 py-1"><select className="w-full px-2 py-1 border border-blue-300 rounded text-sm" value={editServiceModalityId} onChange={e => setEditServiceModalityId(e.target.value)}><option value="">— Nenhuma —</option>{modalities.map(m => (<option key={m.id} value={m.id}>{m.description}</option>))}</select></td>
                                  <td className="px-2 py-1"><input className="w-24 px-2 py-1 border border-blue-300 rounded text-sm" type="number" value={editServicePercent} onChange={e => setEditServicePercent(e.target.value)} placeholder="0.00" /></td>
                                  <td className="px-2 py-1 text-right whitespace-nowrap">
                                    <button onClick={handleSaveEditService} className="text-green-600 hover:text-green-800 text-xs font-medium mr-2">Salvar</button>
                                    <button onClick={handleCancelEditService} className="text-gray-400 hover:text-gray-600 text-xs font-medium">Cancelar</button>
                                  </td>
                                </>
                              ) : (
                                <>
                                  <td className="px-4 py-2 text-sm text-gray-800">{srv.name}</td>
                                  <td className="px-4 py-2 text-sm text-gray-600">{srv.modalityDescription || '—'}</td>
                                  <td className="px-4 py-2 text-sm text-gray-800">{srv.negotiationPercentage?.toFixed(2)}%</td>
                                  <td className="px-4 py-2 text-right whitespace-nowrap">
                                    <button onClick={() => handleStartEditService(srv)} className="text-indigo-500 hover:text-indigo-700 text-xs font-medium mr-2">Editar</button>
                                    <button onClick={() => handleRemoveService(srv.id)} className="text-red-500 hover:text-red-700 text-xs font-medium">Remover</button>
                                  </td>
                                </>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                {/* ── Sub-grid: Contatos ────────────────────────────────────── */}
                <div className="md:col-span-4 mt-2 mb-2">
                  <h4 className="text-sm font-bold text-gray-500 uppercase border-b border-gray-100 pb-2 mb-4">06. Contatos</h4>
                  <div className="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    {/* Linha de adição — Linha 1: Nome, Setor, Telefone, Celular, Zap, Botão */}
                    <div className="grid grid-cols-12 gap-2 mb-2 items-end">
                      <div className="col-span-12 md:col-span-3">
                        <Input label="Nome *" placeholder="Nome do contato" value={newContactName} onChange={e => setNewContactName(e.target.value)} containerClassName="!mb-0"/>
                      </div>
                      <div className="col-span-12 md:col-span-2">
                        <Input label="Setor" placeholder="Ex: Crédito" value={newContactSector} onChange={e => setNewContactSector(e.target.value)} containerClassName="!mb-0"/>
                      </div>
                      <div className="col-span-6 md:col-span-2">
                        <Input label="Telefone" placeholder="(00) 0000-0000" value={newContactPhone} onChange={e => setNewContactPhone(applyPhoneMask(e.target.value, 'telefone'))} containerClassName="!mb-0"/>
                      </div>
                      <div className="col-span-6 md:col-span-2">
                        <Input label="Celular" placeholder="(00) 00000-0000" value={newContactMobile} onChange={e => setNewContactMobile(applyPhoneMask(e.target.value, 'celular'))} containerClassName="!mb-0"/>
                      </div>
                      <div className="col-span-4 md:col-span-1 flex flex-col items-center justify-end pb-[6px]">
                        <label className="block text-xs font-medium text-gray-700 mb-1 text-center">Zap</label>
                        <input
                          type="checkbox"
                          checked={newContactIsWhatsapp}
                          onChange={e => setNewContactIsWhatsapp(e.target.checked)}
                          className="h-5 w-5 rounded border-gray-300 text-green-600 focus:ring-green-500 cursor-pointer"
                        />
                      </div>
                      <div className="col-span-8 md:col-span-2 flex items-end">
                        <Button variant="secondary" className="!w-full h-[50px] !mb-[1px]" onClick={handleAddContact}>+ Adicionar</Button>
                      </div>
                    </div>
                    {/* Linha 2: E-mail (largura total) */}
                    <div className="mb-4">
                      <Input label="E-mail" placeholder="email@banco.com" value={newContactEmail} onChange={e => setNewContactEmail(e.target.value)} containerClassName="!mb-0"/>
                    </div>

                    {/* Tabela de contatos */}
                    <div className="bg-white rounded border overflow-x-auto">
                       <table className="min-w-full divide-y divide-gray-200 operational-grid">
                        <thead className="bg-gray-100">
                          <tr>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Nome</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Setor</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Telefone</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Celular</th>
                            <th className="px-4 py-2 text-center text-xs font-medium text-gray-500 uppercase">Zap</th>
                            <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">E-mail</th>
                            <th className="px-4 py-2 text-right text-xs font-medium text-gray-500 uppercase">Ação</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-gray-200">
                          {isLoadingContacts && (<tr><td colSpan={7} className="px-4 py-4 text-center text-sm text-gray-400">Carregando contatos...</td></tr>)}
                          {!isLoadingContacts && (currentBank.contacts || []).length === 0 && (<tr><td colSpan={7} className="px-4 py-4 text-center text-sm text-gray-400">Nenhum contato cadastrado.</td></tr>)}
                          {(currentBank.contacts || []).map(c => (
                            <tr key={c.id} className={editingContactId === c.id ? 'bg-blue-50' : 'hover:bg-gray-50'}>
                              {editingContactId === c.id ? (
                                <>
                                  <td className="px-2 py-1"><input className="w-full px-2 py-1 border border-blue-300 rounded text-sm" value={editContactName} onChange={e => setEditContactName(e.target.value)} placeholder="Nome *" autoFocus /></td>
                                  <td className="px-2 py-1"><input className="w-full px-2 py-1 border border-blue-300 rounded text-sm" value={editContactSector} onChange={e => setEditContactSector(e.target.value)} placeholder="Setor" /></td>
                                  <td className="px-2 py-1"><input className="w-full px-2 py-1 border border-blue-300 rounded text-sm" value={editContactPhone} onChange={e => setEditContactPhone(applyPhoneMask(e.target.value, 'telefone'))} placeholder="(00) 0000-0000" /></td>
                                  <td className="px-2 py-1"><input className="w-full px-2 py-1 border border-blue-300 rounded text-sm" value={editContactMobile} onChange={e => setEditContactMobile(applyPhoneMask(e.target.value, 'celular'))} placeholder="(00) 00000-0000" /></td>
                                  <td className="px-2 py-1 text-center"><input type="checkbox" checked={editContactIsWhatsapp} onChange={e => setEditContactIsWhatsapp(e.target.checked)} className="h-4 w-4 rounded border-gray-300 text-green-600 cursor-pointer" /></td>
                                  <td className="px-2 py-1"><input className="w-full px-2 py-1 border border-blue-300 rounded text-sm" value={editContactEmail} onChange={e => setEditContactEmail(e.target.value)} placeholder="email@banco.com" /></td>
                                  <td className="px-2 py-1 text-right whitespace-nowrap">
                                    <button onClick={handleSaveEditContact} className="text-green-600 hover:text-green-800 text-xs font-medium mr-2">Salvar</button>
                                    <button onClick={handleCancelEditContact} className="text-gray-400 hover:text-gray-600 text-xs font-medium">Cancelar</button>
                                  </td>
                                </>
                              ) : (
                                <>
                                  <td className="px-4 py-2 text-sm font-medium text-gray-800">{c.name}</td>
                                  <td className="px-4 py-2 text-sm text-gray-600">{c.sector || '—'}</td>
                                  <td className="px-4 py-2 text-sm text-gray-600"><GotalkPhoneLink phone={c.phone} name={c.name} /></td>
                                  <td className="px-4 py-2 text-sm text-gray-600"><GotalkPhoneLink phone={c.mobile} name={c.name} /></td>
                                  <td className="px-4 py-2 text-center">
                                    {c.isWhatsapp
                                      ? <span title="WhatsApp" className="text-green-600 text-base">✓</span>
                                      : <span className="text-gray-300">—</span>}
                                  </td>
                                  <td className="px-4 py-2 text-sm text-gray-600 min-w-[180px] break-all">{c.email ? <a href={`mailto:${c.email}`} className="text-blue-600 hover:underline">{c.email}</a> : '—'}</td>
                                  <td className="px-4 py-2 text-right whitespace-nowrap">
                                    <button onClick={() => handleStartEditContact(c)} className="text-indigo-500 hover:text-indigo-700 text-xs font-medium mr-2">Editar</button>
                                    <button onClick={() => handleRemoveContact(c.id)} className="text-red-500 hover:text-red-700 text-xs font-medium">Remover</button>
                                  </td>
                                </>
                              )}
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>

                <div className="md:col-span-4"><label className="block text-sm font-medium text-gray-700 mb-1">07. Anotações</label><textarea className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-moss-500 outline-none" rows={3} value={currentBank.notes || ''} onChange={(e) => setCurrentBank({...currentBank, notes: e.target.value})} /></div>
             </div>
             <FormActions onSave={handleSave} onCancel={handleCancel} />
        </div>
      );
  }

  return (
     <div className="flex flex-col h-full animate-fade-in" data-grid-density="compact">
        <div className="flex justify-between items-center mb-6"><h2 className="text-2xl font-bold text-gray-800">Cadastro de Bancos</h2>{canIncluir && <Button variant="new" className="!w-auto" onClick={handleNewBank}>Novo Banco</Button>}</div>
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-4 flex flex-col gap-4"><div className="flex gap-4"><div className="flex-1"><Input label="" placeholder="Pesquisar por Nome, Código ou Febraban..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} containerClassName="!mb-0" icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>}/></div><Button variant="ghost" className={`!w-auto ${showFilters ? 'bg-gray-100 text-moss-800' : ''}`} onClick={() => setShowFilters(!showFilters)}><svg className="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" /></svg>Filtros {showFilters ? 'Avançados' : ''}</Button></div>{showFilters && (<div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-4 border-t animate-fade-in-down"><div><label className="block text-xs font-bold text-gray-500 mb-1 uppercase">Status</label><select className="w-full px-3 py-2 rounded border border-gray-300 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)}><option value="">Todos</option><option value="ATIVO">Ativo</option><option value="INATIVO">Inativo</option></select></div><div className="flex items-end"><Button variant="outline" className="!py-2 !text-xs !w-full" onClick={() => { setFilterStatus(''); setSearchTerm(''); setSortConfig({ key: null, direction: null }); }}>Limpar Filtros</Button></div></div>)}</div>
         <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex-1 flex flex-col"><div className="overflow-x-auto flex-1 min-h-0 grid-body-scroll"><table className="min-w-full divide-y divide-gray-200 operational-grid"><thead className="bg-gray-50"><tr><TableHeader label="Descrição (Nome)" sortKey="name" /><TableHeader label="Status" sortKey="status" /><th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th></tr></thead><tbody className="bg-white divide-y divide-gray-200">{apiLoading && paginatedBanks.length === 0 && (<tr><td colSpan={3} className="px-6 py-10 text-center text-gray-500">Carregando bancos...</td></tr>)}{!apiLoading && paginatedBanks.length === 0 && (<tr><td colSpan={3} className="px-6 py-10 text-center text-gray-500">Nenhum banco encontrado com os filtros atuais.</td></tr>)}{paginatedBanks.map(bank => (<tr key={bank.id} className="operational-grid-row hover:bg-gray-50 transition-colors"><td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{bank.name}</td><td className="px-6 py-4 whitespace-nowrap"><span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${bank.status === 'ATIVO' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{bank.status}</span></td><td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium"><div className="flex justify-end items-center gap-3"><AuditLogButton entityId={bank.id} entityName={bank.name} logs={config.auditLogs || []} />{canAlterar && <button onClick={() => handleEditBank(bank)} className="text-indigo-600 hover:text-indigo-900">Editar</button>}{canIncluir && <button onClick={() => handleDuplicateBank(bank)} className="text-amber-600 hover:text-amber-900">Duplicar</button>}{canExcluir && <button onClick={() => handleDeleteBank(bank.id)} className="text-red-600 hover:text-red-900">Excluir</button>}</div></td></tr>))}</tbody></table></div>
        <Pagination currentPage={currentPage} totalItems={sortedAndFilteredBanks.length} itemsPerPage={itemsPerPage} onPageChange={setCurrentPage} onItemsPerPageChange={(n) => { setItemsPerPage(n); setCurrentPage(1); }} /></div>
    </div>
  );
};

export default BanksPanel;

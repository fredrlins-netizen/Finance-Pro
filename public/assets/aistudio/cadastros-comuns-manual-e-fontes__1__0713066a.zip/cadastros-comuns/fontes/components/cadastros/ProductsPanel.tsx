import React, { useState, useMemo, useEffect } from 'react';
import { PortalConfig, Product, MeasurementUnit, ProductType } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';
import FormActions from '../ui/FormActions';
import Pagination from '../ui/Pagination';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import AuditLogButton from '../ui/AuditLogButton';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';
import { api, ApiItemResponse } from '../../services/apiService';

interface ProductsPanelProps {
  config: PortalConfig;
}

type SortDirection = 'asc' | 'desc' | null;
interface SortConfig {
    key: keyof Product | null;
    direction: SortDirection;
}

interface ApiProduct {
  id: string;
  type: string;
  description: string;
  unit_id?: string;
  unitId?: string;
}

function apiToProduct(p: ApiProduct): Product {
  return { id: p.id, type: p.type as ProductType, description: p.description, unitId: p.unitId ?? p.unit_id ?? '' };
}

function productToApi(p: Partial<Product>): Record<string, any> {
  const result: Record<string, any> = {};
  if (p.type !== undefined) result.type = p.type;
  if (p.description !== undefined) result.description = p.description;
  if (p.unitId !== undefined) result.unit_id = p.unitId;
  return result;
}

interface ApiMeasurementUnit {
  id: string;
  name: string;
  conversion_factor?: number;
  conversionFactor?: number;
}

function apiToMU(u: ApiMeasurementUnit): MeasurementUnit {
  return { id: u.id, name: u.name, conversionFactor: u.conversionFactor ?? u.conversion_factor ?? 1 };
}

const ProductsPanel: React.FC<ProductsPanelProps> = ({ config }) => {
  const { validarPermissao, temPermissao, addToast } = useSecurity();
  const canIncluir = temPermissao('cad_produtos:INCLUIR');
  const canAlterar = temPermissao('cad_produtos:ALTERAR');
  const canExcluir = temPermissao('cad_produtos:EXCLUIR');
  const { logTransaction } = useAudit();

  const { data: rawProducts, loading, error, create: apiCreate, update: apiUpdate, remove: apiRemove, refresh } = useEntityCRUD<ApiProduct>('products');
  const products = useMemo(() => rawProducts.map(apiToProduct), [rawProducts]);

  const [measurementUnits, setMeasurementUnits] = useState<MeasurementUnit[]>(config.measurementUnits || []);

  useEffect(() => {
    api.get<{ data: ApiMeasurementUnit[] }>('/api/lookups/measurement-units')
      .then(res => {
        if (res.data && res.data.length > 0) {
          setMeasurementUnits(res.data.map(apiToMU));
        }
      })
      .catch(() => {});
  }, []);

  const [isEditing, setIsEditing] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Product | null>(null);
  const [originalProduct, setOriginalProduct] = useState<Product | null>(null);

  const [showUnitModal, setShowUnitModal] = useState(false);
  const [tempUnit, setTempUnit] = useState<Partial<MeasurementUnit>>({ id: '', name: '', conversionFactor: 1 });

  const [searchTerm, setSearchTerm] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filterType, setFilterType] = useState<string>('');
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: null, direction: null });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleEnterPress = (e: React.KeyboardEvent<HTMLElement>) => {
    if (e.key === 'Enter') {
        e.preventDefault(); 
        const form = e.currentTarget.closest('div[data-form-container="true"]');
        if (!form) return;
        const focusableElements = form.querySelectorAll<HTMLElement>(
            'input:not([disabled]):not([type="hidden"]):not([readonly]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]):not([type="submit"])'
        );
        const focusableArray = Array.from(focusableElements) as HTMLElement[];
        const index = focusableArray.indexOf(e.currentTarget as HTMLElement);
        if (index > -1 && index < focusableArray.length - 1) {
            focusableArray[index + 1].focus();
        }
    }
  };

  const handleNewProduct = () => {
    if (!validarPermissao('cad_produtos:INCLUIR')) return;
    const defaultUnitId = measurementUnits.length > 0 ? measurementUnits[0].id : '';
    const newProduct: Product = { id: '', type: 'SERVICO', description: '', unitId: defaultUnitId };
    setCurrentProduct(newProduct);
    setOriginalProduct(null);
    setIsEditing(true);
  };

  const handleEditProduct = (prod: Product) => {
    if (!validarPermissao('cad_produtos:ALTERAR')) return;
    setCurrentProduct({ ...prod });
    setOriginalProduct({ ...prod });
    setIsEditing(true);
  };

  const handleDuplicateProduct = (prod: Product) => {
    if (!validarPermissao('cad_produtos:INCLUIR')) return;
    setCurrentProduct({ ...prod, id: '', description: 'Cópia de ' + prod.description });
    setOriginalProduct(null);
    setIsEditing(true);
  };

  const handleDeleteProduct = async (id: string) => {
    if (!validarPermissao('cad_produtos:EXCLUIR')) return;
    if (window.confirm('Excluir este produto?')) {
        try {
            const toDelete = products.find(p => p.id === id);
            await apiRemove(id);
            logTransaction('PRODUTO', id, toDelete, null);
            addToast('success', 'Sucesso', 'Produto excluído.');
        } catch (err: any) {
            addToast('warning', 'Exclusão Bloqueada', err?.message || 'Não foi possível excluir o produto.');
        }
    }
  };

  const handleSaveProduct = async () => {
      if (!currentProduct?.description) {
          addToast('warning', 'Validação', 'A Descrição é obrigatória.');
          return;
      }
      if (!currentProduct?.unitId) {
          addToast('warning', 'Validação', 'A Unidade é obrigatória.');
          return;
      }

      try {
          const payload = productToApi(currentProduct);
          let saved: any;
          if (currentProduct.id) {
              saved = await apiUpdate(currentProduct.id, payload as any);
          } else {
              saved = await apiCreate(payload as any);
          }
          logTransaction('PRODUTO', saved.id || currentProduct.id, originalProduct, currentProduct);
          setIsEditing(false);
          setCurrentProduct(null);
          setOriginalProduct(null);
          addToast('success', 'Sucesso', 'Produto salvo.');
          refresh();
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Erro ao salvar produto.');
      }
  };

  const handleOpenNewUnit = () => {
      setTempUnit({ id: '', name: '', conversionFactor: 1 });
      setShowUnitModal(true);
  };

  const handleOpenEditUnit = () => {
      if (!currentProduct?.unitId) return;
      const unit = measurementUnits.find(u => u.id === currentProduct.unitId);
      if (unit) {
          setTempUnit({ ...unit });
          setShowUnitModal(true);
      }
  };

  const handleSaveUnit = async () => {
      if (!tempUnit.name || !tempUnit.conversionFactor) {
          addToast('warning', 'Validação', 'Nome e Fator de Conversão são obrigatórios.');
          return;
      }

      try {
          const payload = { name: tempUnit.name!.toUpperCase(), conversion_factor: Number(tempUnit.conversionFactor) };
          if (tempUnit.id) {
              const res = await api.put<ApiItemResponse<ApiMeasurementUnit>>(`/api/lookups/measurement-units/${tempUnit.id}`, payload);
              const updated = apiToMU(res.data);
              setMeasurementUnits(prev => prev.map(u => u.id === updated.id ? updated : u));
              logTransaction('UNIDADE_MEDIDA', updated.id, tempUnit, updated);
          } else {
              const res = await api.post<ApiItemResponse<ApiMeasurementUnit>>('/api/lookups/measurement-units', payload);
              const created = apiToMU(res.data);
              setMeasurementUnits(prev => [...prev, created]);
              logTransaction('UNIDADE_MEDIDA', created.id, null, created);
              if (currentProduct) {
                  setCurrentProduct({ ...currentProduct, unitId: created.id });
              }
          }
          setShowUnitModal(false);
          setTempUnit({ id: '', name: '', conversionFactor: 1 });
          addToast('success', 'Sucesso', tempUnit.id ? 'Unidade atualizada.' : 'Unidade criada.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Erro ao salvar unidade.');
      }
  };

  const handleSort = (key: keyof Product) => {
      let direction: SortDirection = 'asc';
      if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
      else if (sortConfig.key === key && sortConfig.direction === 'desc') direction = null;
      setSortConfig({ key: direction ? key : null, direction });
  };

  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm, filterType]);

  const sortedAndFiltered = useMemo(() => {
      let data = products || [];
      if (searchTerm) {
          const lower = searchTerm.toLowerCase();
          data = data.filter(p => p.description.toLowerCase().includes(lower) || p.type.toLowerCase().includes(lower));
      }
      if (filterType) {
          data = data.filter(p => p.type === filterType);
      }
      if (sortConfig.key && sortConfig.direction) {
          data = [...data].sort((a, b) => {
              const valA = a[sortConfig.key!]?.toString().toLowerCase() || '';
              const valB = b[sortConfig.key!]?.toString().toLowerCase() || '';
              if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
              if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
              return 0;
          });
      }
      return data;
  }, [products, searchTerm, filterType, sortConfig]);

  const paginated = useMemo(() => {
      const start = (currentPage - 1) * itemsPerPage;
      return sortedAndFiltered.slice(start, start + itemsPerPage);
  }, [sortedAndFiltered, currentPage, itemsPerPage]);

  const renderSortIcon = (key: keyof Product) => {
      if (sortConfig.key !== key) return <span className="text-gray-300 ml-1">⇅</span>;
      return sortConfig.direction === 'asc' ? <span className="text-moss-600 ml-1">↑</span> : <span className="text-moss-600 ml-1">↓</span>;
  };

  const TableHeader = ({ label, sortKey }: { label: string, sortKey: keyof Product }) => (
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onClick={() => handleSort(sortKey)}>
          <div className="flex items-center">{label} {renderSortIcon(sortKey)}</div>
      </th>
  );

  const getUnitName = (id: string) => {
      const u = measurementUnits.find(unit => unit.id === id);
      return u ? u.name : '-';
  };

  if (isEditing && currentProduct) {
      return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 animate-fade-in" data-form-container="true">
              <div className="flex justify-between items-center mb-6 pb-4 border-b">
                  <h3 className="text-xl font-bold text-gray-800">{currentProduct.id ? 'Editar Produto' : 'Novo Produto'}</h3>
              </div>
              
              <div className="flex flex-col md:flex-row gap-4 items-end">
                  <div className="w-full md:w-1/6 min-w-[150px]">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Tipo</label>
                      <select 
                          className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moss-500 outline-none bg-white"
                          value={currentProduct.type}
                          onChange={(e) => setCurrentProduct({...currentProduct, type: e.target.value as ProductType})}
                          onKeyDown={handleEnterPress}
                      >
                          <option value="SERVICO">SERVIÇO</option>
                          <option value="MATERIAL">MATERIAL</option>
                      </select>
                  </div>

                  <div className="flex-1 w-full">
                      <Input 
                        label="Descrição" 
                        value={currentProduct.description} 
                        onChange={e => setCurrentProduct({...currentProduct, description: e.target.value})} 
                        onKeyDown={handleEnterPress}
                        placeholder="Ex: Consultoria Financeira"
                        containerClassName="!mb-0"
                      />
                  </div>

                  <div className="w-full md:w-1/4 min-w-[200px]">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Unidade</label>
                      <div className="flex gap-2">
                          <select 
                              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moss-500 outline-none bg-white"
                              value={currentProduct.unitId}
                              onChange={(e) => setCurrentProduct({...currentProduct, unitId: e.target.value})}
                              onKeyDown={handleEnterPress}
                          >
                              {measurementUnits.map(u => (
                                  <option key={u.id} value={u.id}>{u.name} (FC: {u.conversionFactor})</option>
                              ))}
                          </select>
                          
                          <Button 
                            variant="outline" 
                            className="!w-12 !px-0 border-gray-300 text-gray-600 hover:text-blue-600 hover:border-blue-300" 
                            title="Editar Unidade Selecionada"
                            onClick={handleOpenEditUnit}
                            disabled={!currentProduct.unitId}
                          >
                              ✎
                          </Button>

                          <Button 
                            variant="secondary" 
                            className="!w-12 !px-0" 
                            title="Nova Unidade"
                            onClick={handleOpenNewUnit}
                          >
                              +
                          </Button>
                      </div>
                  </div>
              </div>

              <FormActions onSave={handleSaveProduct} onCancel={() => setIsEditing(false)} />

              {showUnitModal && (
                  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 animate-fade-in p-4">
                      <div className="bg-white rounded-lg shadow-xl w-full max-w-sm overflow-hidden">
                          <div className="bg-gray-100 p-4 border-b flex justify-between items-center">
                              <h3 className="font-bold text-gray-800">{tempUnit.id ? 'Editar Unidade' : 'Nova Unidade'}</h3>
                              <button onClick={() => setShowUnitModal(false)} className="text-gray-500 hover:text-gray-800">✕</button>
                          </div>
                          <div className="p-6 space-y-4">
                              <Input 
                                  label="Sigla / Nome (Ex: CX, KG)" 
                                  value={tempUnit.name || ''} 
                                  onChange={e => setTempUnit({...tempUnit, name: e.target.value.toUpperCase()})}
                                  autoFocus
                                  maxLength={5}
                              />
                              <Input 
                                  label="Fator de Conversão (Padrão 1)" 
                                  type="number" 
                                  value={tempUnit.conversionFactor} 
                                  onChange={e => setTempUnit({...tempUnit, conversionFactor: parseFloat(e.target.value) || 0})}
                                  placeholder="1.0"
                              />
                              <p className="text-xs text-gray-500">O fator de conversão é utilizado para cálculos de estoque e venda fracionada.</p>
                          </div>
                          <div className="p-4 border-t flex justify-end gap-2 bg-gray-50">
                              <Button variant="outline" className="!w-auto" onClick={() => setShowUnitModal(false)}>Cancelar</Button>
                              <Button variant="primary" className="!w-auto" onClick={handleSaveUnit}>
                                  {tempUnit.id ? 'Salvar Alterações' : 'Criar Unidade'}
                              </Button>
                          </div>
                      </div>
                  </div>
              )}
          </div>
      );
  }

  return (
       <div className="flex flex-col h-full animate-fade-in" data-grid-density="compact">
          <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Produtos e Serviços</h2>
              {canIncluir && <Button variant="new" className="!w-auto" onClick={handleNewProduct}>Novo Produto</Button>}
          </div>

          {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex justify-between items-center">
                  <span>{error}</span>
                  <button onClick={refresh} className="text-red-800 underline text-sm">Tentar novamente</button>
              </div>
          )}

          {loading && products.length === 0 && (
              <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-moss-600"></div>
                  <span className="ml-3 text-gray-500">Carregando produtos...</span>
              </div>
          )}

           <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-4 flex flex-col gap-4 grid-search">
              <div className="flex gap-4">
                  <div className="flex-1">
                      <Input 
                        label="" 
                        placeholder="Pesquisar por Descrição ou Tipo..." 
                        value={searchTerm} 
                        onChange={e => setSearchTerm(e.target.value)} 
                        containerClassName="!mb-0" 
                        icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} 
                      />
                  </div>
                  <Button variant="ghost" className={`!w-auto ${showFilters ? 'bg-gray-100 text-moss-800' : ''}`} onClick={() => setShowFilters(!showFilters)}>
                      <svg className="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" /></svg>
                      Filtros {showFilters ? 'Avançados' : ''}
                  </Button>
              </div>

              {showFilters && (
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-4 border-t animate-fade-in-down">
                      <div>
                          <label className="block text-xs font-bold text-gray-500 mb-1 uppercase">Tipo</label>
                          <select 
                              className="w-full px-3 py-2 rounded border border-gray-300 text-sm focus:ring-2 focus:ring-moss-500 outline-none"
                              value={filterType}
                              onChange={(e) => setFilterType(e.target.value)}
                          >
                              <option value="">Todos</option>
                              <option value="SERVICO">Serviço</option>
                              <option value="MATERIAL">Material</option>
                          </select>
                      </div>
                      <div className="flex items-end">
                          <Button 
                              variant="outline" 
                              className="!py-2 !text-xs !w-full"
                              onClick={() => {
                                  setFilterType('');
                                  setSearchTerm('');
                                  setSortConfig({ key: null, direction: null });
                              }}
                          >
                              Limpar Filtros
                          </Button>
                      </div>
                  </div>
              )}
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex-1 flex flex-col">
               <div className="overflow-x-auto grid-body-scroll">
                  <table className="min-w-full divide-y divide-gray-200 operational-grid">
                      <thead className="bg-gray-50">
                          <tr>
                              <TableHeader label="Tipo" sortKey="type" />
                              <TableHeader label="Descrição" sortKey="description" />
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Unidade</th>
                              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
                          </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                          {paginated.length === 0 && <tr><td colSpan={4} className="px-6 py-10 text-center text-gray-500">{loading ? 'Carregando...' : 'Nenhum registro encontrado.'}</td></tr>}
                          {paginated.map(p => (
                              <tr key={p.id} className="hover:bg-gray-50">
                                  <td className="px-6 py-4 whitespace-nowrap">
                                      <span className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${p.type === 'SERVICO' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'} uppercase`}>
                                          {p.type}
                                      </span>
                                  </td>
                                  <td className="px-6 py-4 text-sm text-gray-600">{p.description}</td>
                                  <td className="px-6 py-4 text-sm text-gray-600 font-mono font-bold">{getUnitName(p.unitId)}</td>
                                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                      <div className="flex justify-end items-center gap-3">
                                          <AuditLogButton entityId={p.id} entityName={(p as any).name || p.description} logs={config.auditLogs || []} />
                                          {canAlterar && <button onClick={() => handleEditProduct(p)} className="text-indigo-600 hover:text-indigo-900">Editar</button>}
                                          {canIncluir && <button onClick={() => handleDuplicateProduct(p)} className="text-amber-600 hover:text-amber-800">Duplicar</button>}
                                          {canExcluir && <button onClick={() => handleDeleteProduct(p.id)} className="text-red-600 hover:text-red-900">Excluir</button>}
                                      </div>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
              <Pagination totalItems={sortedAndFiltered.length} itemsPerPage={itemsPerPage} currentPage={currentPage} onPageChange={setCurrentPage} onItemsPerPageChange={setItemsPerPage} />
          </div>
      </div>
  );
};

export default ProductsPanel;

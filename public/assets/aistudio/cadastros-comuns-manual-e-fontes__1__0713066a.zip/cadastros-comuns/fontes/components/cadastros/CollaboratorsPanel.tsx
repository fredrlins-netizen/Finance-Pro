/**
 * TÍTULO: PAINEL DE GESTÃO DE COLABORADORES
 * 
 * Funcionalidades:
 * - Listagem de colaboradores.
 * - Formulário de cadastro/edição (Dados pessoais, contato, endereço, foto).
 * - Integração com Câmera para foto de perfil.
 * - Auditoria e Segurança.
 * - Filtros e Paginação.
 * - Suporte a criação/edição automática e retorno de ID (Fluxo Admissão).
 */

import React, { useState, useMemo, useRef, useEffect } from 'react';
import { PortalConfig, Collaborator } from '../../types';
import Button from '../ui/Button';
import GotalkPhoneLink from '../gotalk/GotalkPhoneLink';
import Input from '../ui/Input';
import FormActions from '../ui/FormActions';
import CameraCapture from '../ui/CameraCapture';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { checkDependencies, formatDependencyMessage } from '../../utils/dependencyCheck';
import AuditLogButton from '../ui/AuditLogButton';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';

interface CollaboratorsPanelProps {
  config: PortalConfig;
  autoStartCreate?: boolean;
  externalEditId?: string;
  onCollaboratorSelect?: (newCollabId: string) => void;
  onCancelSubFlow?: () => void;
}

type SortDirection = 'asc' | 'desc' | null;
interface SortConfig {
    key: keyof Collaborator | null;
    direction: SortDirection;
}

const CollaboratorsPanel: React.FC<CollaboratorsPanelProps> = ({ 
    config, 
    autoStartCreate = false,
    externalEditId,
    onCollaboratorSelect,
    onCancelSubFlow
}) => {
  const { validarPermissao, temPermissao, addToast } = useSecurity();
  const canIncluir = temPermissao('cad_colaboradores:INCLUIR');
  const canAlterar = temPermissao('cad_colaboradores:ALTERAR');
  const canExcluir = temPermissao('cad_colaboradores:EXCLUIR');
  const { logTransaction } = useAudit();

  const { data: collaborators, loading: apiLoading, error: apiError, create: apiCreate, update: apiUpdate, remove: apiRemove, refresh: apiRefresh, clearError: apiClearError } = useEntityCRUD<Collaborator>('collaborators', { pageSize: 1000 });

  const { data: dbDepartments } = useEntityCRUD<{ id: string; code: string; name: string; managerName: string; status: string }>('lookups/departments', { pageSize: 500 });
  const { data: dbUnits } = useEntityCRUD<{ id: string; razaoSocial: string; nomeFantasia: string; cnpj: string; telefone: string; email: string }>('units', { pageSize: 500 });
  const { data: dbRolesRaw } = useEntityCRUD<{ id: string; value: string }>('roles', { pageSize: 500 });

  const dbJobTitles = useMemo(() => {
    return dbRolesRaw.map(r => {
      let name = r.value;
      try {
        const parsed = JSON.parse(r.value);
        if (typeof parsed === 'object' && parsed.name) name = parsed.name;
      } catch {}
      return { id: r.id, name };
    });
  }, [dbRolesRaw]);

  const [isEditing, setIsEditing] = useState(false);
  const [currentCollaborator, setCurrentCollaborator] = useState<Collaborator | null>(null);
  const [originalCollaborator, setOriginalCollaborator] = useState<Collaborator | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const [showCamera, setShowCamera] = useState(false);
  const photoInputRef = useRef<HTMLInputElement>(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: null, direction: null });
  const [expandedUnits, setExpandedUnits] = useState<Set<string>>(new Set());
  const [expandedRoles, setExpandedRoles] = useState<Set<string>>(new Set());

  const [isLoadingCep, setIsLoadingCep] = useState(false);
  const [fieldErrors, setFieldErrors] = useState<{ unitId?: boolean; jobTitle?: boolean; departmentId?: boolean }>({});
  const numeroRef = useRef<HTMLInputElement>(null);
  const enderecoRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
      if (apiError) {
          addToast('error', 'Erro', apiError);
          apiClearError();
      }
  }, [apiError]);

  useEffect(() => {
      if (autoStartCreate && !isEditing) {
          handleNewCollaborator();
      } else if (externalEditId && !isEditing) {
          const colab = collaborators.find(c => c.id === externalEditId);
          if (colab) handleEditCollaborator(colab);
      }
  }, [autoStartCreate, externalEditId, collaborators]);

  // --- UTILS ---
  const formatPhone = (value: string) => {
    let r = value.replace(/\D/g, "");
    r = r.substring(0, 11);
    if (r.length > 10) {
      r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
    } else if (r.length > 5) {
      r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, "($1) $2-$3");
    } else if (r.length > 2) {
      r = r.replace(/^(\d\d)(\d{0,5})/, "($1) $2");
    } else {
      r = r.replace(/^(\d*)/, "($1");
    }
    return r;
  };

  const formatCEP = (value: string) => {
    let r = value.replace(/\D/g, "");
    r = r.substring(0, 8);
    if (r.length > 5) {
        r = r.replace(/^(\d{5})(\d{1,3}).*/, "$1-$2");
    }
    return r;
  };

  const formatDateMask = (value: string): string => {
      let d = value.replace(/\D/g, '').substring(0, 8);
      if (d.length > 4) d = d.replace(/^(\d{2})(\d{2})(\d{0,4})/, '$1/$2/$3');
      else if (d.length > 2) d = d.replace(/^(\d{2})(\d{0,2})/, '$1/$2');
      return d;
  };

  const isoToBR = (iso: string): string => {
      if (!iso) return '';
      const dateOnly = iso.split('T')[0];
      const parts = dateOnly.split('-');
      if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
      return iso;
  };

  const brToISO = (br: string): string => {
      if (!br) return '';
      const parts = br.split('/');
      if (parts.length === 3 && parts[2].length === 4) return `${parts[2]}-${parts[1]}-${parts[0]}`;
      return '';
  };

  const handleEnterPress = (e: React.KeyboardEvent<HTMLElement>) => {
    if (e.key === 'Enter') {
        e.preventDefault(); 
        const form = e.currentTarget.closest('div[data-form-container="true"]');
        if (!form) return;
        const focusableElements = form.querySelectorAll<HTMLElement>('input:not([disabled]):not([type="hidden"]):not([readonly]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]):not([type="submit"])');
        const focusableArray = Array.from(focusableElements) as HTMLElement[];
        const index = focusableArray.indexOf(e.currentTarget as HTMLElement);
        if (index > -1 && index < focusableArray.length - 1) focusableArray[index + 1].focus();
    }
  };

  // --- ACTIONS ---

  const handleNewCollaborator = () => {
    if (!validarPermissao('cad_colaboradores:INCLUIR')) return;
    const maxId = collaborators.reduce((max, c) => Math.max(max, parseInt(c.id) || 0), 2000);
    const newColab: Collaborator = {
        id: (maxId + 1).toString(), name: '', active: true, unitId: '', departmentId: '', photoUrl: '', jobTitle: '', phone: '', email: '', cep: '', address: '', number: '', complement: '', district: '', city: '', state: ''
    };
    setCurrentCollaborator(newColab);
    setOriginalCollaborator(null);
    setIsEditing(true);
  };

  const handleEditCollaborator = (colab: Collaborator) => {
    if (!validarPermissao('cad_colaboradores:ALTERAR')) return;
    setCurrentCollaborator({ ...colab, birthDate: isoToBR(colab.birthDate || '') });
    setOriginalCollaborator({ ...colab });
    setIsEditing(true);
  };

  const handleDuplicateCollaborator = (colab: Collaborator) => {
    if (!validarPermissao('cad_colaboradores:INCLUIR')) return;
    const maxId = collaborators.reduce((max, c) => Math.max(max, parseInt(c.id) || 0), 2000);
    setCurrentCollaborator({ ...colab, id: (maxId + 1).toString(), name: 'Cópia de ' + colab.name, photoUrl: '', birthDate: isoToBR(colab.birthDate || '') });
    setOriginalCollaborator(null);
    setIsEditing(true);
  };

  const handleDeleteCollaborator = async (id: string) => {
    if (!validarPermissao('cad_colaboradores:EXCLUIR')) return;
    const result = checkDependencies('collaborator', id, config);
    if (!result.canDelete) {
        const collabName = collaborators.find(c => c.id === id)?.name || id;
        addToast('warning', 'Exclusão Bloqueada', formatDependencyMessage(`o colaborador "${collabName}"`, result.dependencies));
        return;
    }
    if (window.confirm('Excluir este colaborador?')) {
        const toDelete = collaborators.find(c => c.id === id);
        try {
            await apiRemove(id);
            logTransaction('COLABORADOR', id, toDelete, null);
            addToast('success', 'Sucesso', 'Colaborador excluído.');
        } catch {
            addToast('error', 'Erro', 'Erro ao excluir colaborador.');
        }
    }
  };

  const handleSave = async () => {
      if (!currentCollaborator?.name) {
          addToast('warning', 'Validação', 'Nome é obrigatório.');
          return;
      }

      const errors: { unitId?: boolean; jobTitle?: boolean; departmentId?: boolean } = {};
      if (!currentCollaborator.unitId) errors.unitId = true;
      if (!currentCollaborator.jobTitle) errors.jobTitle = true;
      if (!currentCollaborator.departmentId) errors.departmentId = true;
      if (Object.keys(errors).length > 0) {
          setFieldErrors(errors);
          addToast('warning', 'Validação', 'Preencha os campos obrigatórios: Unidade, Cargo/Função e Setor.');
          return;
      }
      setFieldErrors({});

      setIsSaving(true);
      try {
          const isNew = !originalCollaborator;
          let savedCollab: Collaborator;

          const sanitized = {
              ...currentCollaborator,
              birthDate: brToISO(currentCollaborator.birthDate || '') || null,
              unitId: currentCollaborator.unitId || null,
              departmentId: currentCollaborator.departmentId || null,
          };

          if (isNew) {
              savedCollab = await apiCreate(sanitized);
          } else {
              savedCollab = await apiUpdate(sanitized.id, sanitized);
          }

          logTransaction('COLABORADOR', savedCollab.id, originalCollaborator, savedCollab);
          setIsEditing(false);

          if (onCollaboratorSelect) {
              onCollaboratorSelect(savedCollab.id);
              return;
          }

          setCurrentCollaborator(null);
          setOriginalCollaborator(null);
          addToast('success', 'Sucesso', 'Colaborador salvo.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Erro ao salvar colaborador.');
      } finally {
          setIsSaving(false);
      }
  };

  const handleCancel = () => {
      setIsEditing(false);
      setCurrentCollaborator(null);
      setOriginalCollaborator(null);
      setFieldErrors({});
      
      // Se estiver em modo de sub-fluxo (Admissão), dispara o cancelamento para fechar a tela
      if (onCancelSubFlow) {
          onCancelSubFlow();
      }
  };

  const handleCepSearch = async () => {
    if (!currentCollaborator?.cep) return;
    const cep = currentCollaborator.cep.replace(/\D/g, '');
    if (cep.length === 8) {
        setIsLoadingCep(true);
        try {
            const r = await fetch(`/api/cep/${cep}`);
            const d = await r.json();
            if (!d.erro) {
                const n = { address: d.logradouro || '', district: d.bairro || '', city: d.localidade || '', state: d.uf || '', complement: currentCollaborator.complement || d.complemento || '' };
                setCurrentCollaborator(prev => prev ? ({...prev, ...n}) : null);
                setTimeout(() => { if (d.logradouro) numeroRef.current?.focus(); else enderecoRef.current?.focus(); }, 100);
            } else addToast('warning', 'Atenção', 'CEP não encontrado.');
        } catch { addToast('error', 'Erro', 'Erro ao buscar CEP.'); } finally { setIsLoadingCep(false); }
    }
  };

  const handlePhotoFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onloadend = () => { 
            const base64String = reader.result as string;
            setCurrentCollaborator(prev => prev ? ({ ...prev, photoUrl: base64String }) : null);
            addToast('success', 'Upload', 'Foto carregada com sucesso.');
        };
        reader.readAsDataURL(file);
    }
    if (e.target) e.target.value = ''; 
  };

  const handleCameraCapture = (base64: string) => {
      setCurrentCollaborator(prev => prev ? ({ ...prev, photoUrl: base64 }) : null);
      setShowCamera(false);
      addToast('success', 'Câmera', 'Foto capturada com sucesso.');
  };

  const handleRemovePhoto = () => {
      if(window.confirm('Remover foto atual?')) {
          setCurrentCollaborator(prev => prev ? ({ ...prev, photoUrl: '' }) : null);
      }
  };

  const getUnitName = (unitId?: string) => {
      if (!unitId) return 'Sem Unidade';
      const found = dbUnits.find(u => u.id === unitId);
      return found?.nomeFantasia || found?.razaoSocial || 'Sem Unidade';
  };
  const getRoleName = (jobTitle?: string) => {
      if (!jobTitle) return 'Sem Cargo';
      return jobTitle;
  };
  const getDeptName = (deptId?: string) => {
      if (!deptId) return '';
      return dbDepartments.find(d => d.id === deptId)?.name || '';
  };

  const toggleUnit = (key: string) => {
      setExpandedUnits(prev => {
          const next = new Set(prev);
          if (next.has(key)) next.delete(key); else next.add(key);
          return next;
      });
  };
  const toggleRole = (key: string) => {
      setExpandedRoles(prev => {
          const next = new Set(prev);
          if (next.has(key)) next.delete(key); else next.add(key);
          return next;
      });
  };

  const sortedAndFiltered = useMemo(() => {
      let data = collaborators || [];
      if (searchTerm) {
          const lower = searchTerm.toLowerCase();
          data = data.filter(c => 
              c.name?.toLowerCase().includes(lower) || 
              c.email?.toLowerCase().includes(lower) || 
              getRoleName(c.jobTitle).toLowerCase().includes(lower) ||
              getUnitName(c.unitId).toLowerCase().includes(lower) ||
              getDeptName(c.departmentId).toLowerCase().includes(lower)
          );
      }
      if (sortConfig.key && sortConfig.direction) {
          data = [...data].sort((a, b) => {
              const valA = a[sortConfig.key!]?.toString().toLowerCase() || '';
              const valB = b[sortConfig.key!]?.toString().toLowerCase() || '';
              if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
              if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
              return 0;
          });
      }
      return data;
  }, [collaborators, searchTerm, sortConfig, dbUnits, dbJobTitles, dbDepartments]);

  const treeData = useMemo(() => {
      const grouped: Record<string, Record<string, Collaborator[]>> = {};
      sortedAndFiltered.forEach(c => {
          const unitKey = c.unitId || '__none__';
          const roleKey = c.jobTitle || '__none__';
          if (!grouped[unitKey]) grouped[unitKey] = {};
          if (!grouped[unitKey][roleKey]) grouped[unitKey][roleKey] = [];
          grouped[unitKey][roleKey].push(c);
      });
      const unitKeys = Object.keys(grouped).sort((a, b) => {
          if (a === '__none__') return 1;
          if (b === '__none__') return -1;
          return getUnitName(a).localeCompare(getUnitName(b));
      });
      return { grouped, unitKeys };
  }, [sortedAndFiltered, dbUnits, dbJobTitles]);

  useEffect(() => {
      if (treeData.unitKeys.length > 0) {
          setExpandedUnits(new Set(treeData.unitKeys));
          const allRoleKeys = new Set<string>();
          treeData.unitKeys.forEach(unitKey => {
              Object.keys(treeData.grouped[unitKey]).forEach(roleKey => {
                  allRoleKeys.add(`${unitKey}::${roleKey}`);
              });
          });
          setExpandedRoles(allRoleKeys);
      }
  }, [treeData]);

  const expandAll = () => {
      const allUnitKeys = new Set(treeData.unitKeys);
      setExpandedUnits(allUnitKeys);
      const allRoleKeys = new Set<string>();
      treeData.unitKeys.forEach(uk => {
          Object.keys(treeData.grouped[uk]).forEach(rk => allRoleKeys.add(`${uk}::${rk}`));
      });
      setExpandedRoles(allRoleKeys);
  };
  const collapseAll = () => {
      setExpandedUnits(new Set());
      setExpandedRoles(new Set());
  };

  useEffect(() => {
      if (searchTerm) expandAll();
  }, [searchTerm]);

  if (isEditing && currentCollaborator) {
      return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 animate-fade-in" data-form-container="true">
              <div className="flex justify-between items-center mb-6 pb-4 border-b">
                  <h3 className="text-xl font-bold text-gray-800">
                    {originalCollaborator ? 'Editando Colaborador' : 'Novo Colaborador'}
                  </h3>
                  {onCollaboratorSelect && <span className="text-sm font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">Modo de Admissão</span>}
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                  <div className="md:col-span-1 flex flex-col items-center space-y-3">
                      <div className="h-36 w-36 rounded-full bg-gray-200 overflow-hidden border-4 border-white shadow-md relative group">
                          {currentCollaborator.photoUrl ? (
                              <img src={currentCollaborator.photoUrl} alt="Foto" className="w-full h-full object-cover" />
                          ) : (
                              <div className="w-full h-full flex items-center justify-center text-gray-400 font-bold text-3xl">
                                  {currentCollaborator.name ? currentCollaborator.name.charAt(0) : '?'}
                              </div>
                          )}
                          <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                                <button onClick={() => setShowCamera(true)} className="p-2 bg-white/20 hover:bg-white/40 rounded-full text-white" title="Câmera">
                                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                                </button>
                                <button onClick={() => photoInputRef.current?.click()} className="p-2 bg-white/20 hover:bg-white/40 rounded-full text-white" title="Arquivo">
                                    <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" /></svg>
                                </button>
                          </div>
                      </div>
                      <input type="file" ref={photoInputRef} className="hidden" accept="image/*" onChange={handlePhotoFile} />
                      <div className="flex flex-col w-full gap-2">
                          <div className="flex gap-2 w-full">
                              <Button variant="secondary" className="!text-xs flex-1 !py-1" onClick={() => setShowCamera(true)}>📷 Câmera</Button>
                              <Button variant="outline" className="!text-xs flex-1 !py-1" onClick={() => photoInputRef.current?.click()}>📁 Arquivo</Button>
                          </div>
                          {currentCollaborator.photoUrl && <button onClick={handleRemovePhoto} className="text-xs text-red-500 hover:text-red-700 underline text-center w-full">Remover Foto</button>}
                      </div>
                  </div>

                  <div className="md:col-span-3 grid grid-cols-1 md:grid-cols-2 gap-4">
                      <Input label="Código" value={currentCollaborator.id} disabled className="bg-gray-100" />
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                          <select className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white" value={currentCollaborator.active === false ? 'false' : 'true'} onChange={e => setCurrentCollaborator({...currentCollaborator, active: e.target.value === 'true'})}>
                              <option value="true">Ativo</option>
                              <option value="false">Inativo</option>
                          </select>
                      </div>
                      <div>
                          <label className="block text-sm font-medium text-gray-700 mb-1">Unidade <span className="text-red-500">*</span></label>
                          <select className={`w-full px-4 py-3 rounded-lg border bg-white ${fieldErrors.unitId ? 'border-red-500 ring-1 ring-red-500' : 'border-gray-300'}`} value={currentCollaborator.unitId || ''} onChange={e => { setCurrentCollaborator({...currentCollaborator, unitId: e.target.value}); if (e.target.value) setFieldErrors(prev => ({ ...prev, unitId: false })); }} onKeyDown={handleEnterPress}>
                              <option value="">Selecione...</option>
                              {dbUnits.map(u => <option key={u.id} value={u.id}>{u.nomeFantasia || u.razaoSocial || u.id}</option>)}
                          </select>
                          {fieldErrors.unitId && <p className="text-red-500 text-xs mt-1">Campo obrigatório.</p>}
                      </div>
                      <div className="md:col-span-2 grid grid-cols-2 gap-4">
                          <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Cargo / Função <span className="text-red-500">*</span></label>
                              <select className={`w-full px-4 py-3 rounded-lg border bg-white ${fieldErrors.jobTitle ? 'border-red-500 ring-1 ring-red-500' : 'border-gray-300'}`} value={currentCollaborator.jobTitle || ''} onChange={e => { setCurrentCollaborator({...currentCollaborator, jobTitle: e.target.value}); if (e.target.value) setFieldErrors(prev => ({ ...prev, jobTitle: false })); }} onKeyDown={handleEnterPress}>
                                  <option value="">Selecione...</option>
                                  {dbJobTitles.map(jt => <option key={jt.id} value={jt.name}>{jt.name}</option>)}
                              </select>
                              {fieldErrors.jobTitle && <p className="text-red-500 text-xs mt-1">Campo obrigatório.</p>}
                          </div>
                          <div>
                              <label className="block text-sm font-medium text-gray-700 mb-1">Setor <span className="text-red-500">*</span></label>
                              <select className={`w-full px-4 py-3 rounded-lg border bg-white ${fieldErrors.departmentId ? 'border-red-500 ring-1 ring-red-500' : 'border-gray-300'}`} value={currentCollaborator.departmentId || ''} onChange={e => { setCurrentCollaborator({...currentCollaborator, departmentId: e.target.value}); if (e.target.value) setFieldErrors(prev => ({ ...prev, departmentId: false })); }} onKeyDown={handleEnterPress}>
                                  <option value="">Selecione...</option>
                                  {dbDepartments.filter(d => d.status === 'ATIVO' || d.id === currentCollaborator.departmentId).map(d => <option key={d.id} value={d.id}>{d.name}{d.status !== 'ATIVO' ? ' (inativo)' : ''}</option>)}
                              </select>
                              {fieldErrors.departmentId && <p className="text-red-500 text-xs mt-1">Campo obrigatório.</p>}
                          </div>
                      </div>
                      <div className="md:col-span-2"><Input label="Nome Completo" value={currentCollaborator.name} onChange={e => setCurrentCollaborator({...currentCollaborator, name: e.target.value})} onKeyDown={handleEnterPress} /></div>
                      <Input label="E-mail" type="email" containerClassName="!mb-0" value={currentCollaborator.email || ''} onChange={e => setCurrentCollaborator({...currentCollaborator, email: e.target.value})} onKeyDown={handleEnterPress} />
                      <div className="flex items-end gap-2">
                        <Input label="Telefone" containerClassName="flex-1 !mb-0" value={currentCollaborator.phone} onChange={e => setCurrentCollaborator({...currentCollaborator, phone: formatPhone(e.target.value)})} onKeyDown={handleEnterPress} maxLength={15} />
                        <label className="flex items-center justify-center border border-gray-300 rounded-lg h-[50px] px-3 cursor-pointer bg-white" title="Whatsapp"><input type="checkbox" className="h-4 w-4 text-green-600 focus:ring-green-500 mr-2" checked={currentCollaborator.isWhatsapp || false} onChange={e => setCurrentCollaborator({...currentCollaborator, isWhatsapp: e.target.checked})} /><span className="text-green-600 font-bold">Zap</span></label>
                      </div>
                      <Input label="Data Nascimento" type="text" placeholder="DD/MM/AAAA" maxLength={10} value={currentCollaborator.birthDate || ''} onChange={e => setCurrentCollaborator({...currentCollaborator, birthDate: formatDateMask(e.target.value)})} onKeyDown={handleEnterPress} />
                      <div className="md:col-span-1">
                          <label className="block text-sm font-medium text-gray-700 mb-1">Estado Civil</label>
                          <select className="w-full px-4 py-3 rounded-lg border border-gray-300 bg-white" value={currentCollaborator.maritalStatus || ''} onChange={e => setCurrentCollaborator({...currentCollaborator, maritalStatus: e.target.value})} onKeyDown={handleEnterPress}>
                              <option value="">Selecione...</option>
                              {(config.maritalStatusOptions || []).map(o => <option key={o} value={o}>{o}</option>)}
                          </select>
                      </div>
                  </div>

                  <div className="md:col-span-4 border-t pt-4">
                      <h4 className="text-sm font-bold text-gray-500 uppercase mb-4">Endereço</h4>
                      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                          <div className="flex items-end gap-2 md:col-span-1"><Input label="CEP" containerClassName="flex-1 !mb-0" value={currentCollaborator.cep} onChange={e => setCurrentCollaborator({...currentCollaborator, cep: formatCEP(e.target.value)})} onKeyDown={handleEnterPress} maxLength={9} /><Button className="!w-12 !h-[50px] !mb-[1px]" onClick={handleCepSearch} isLoading={isLoadingCep}>🔎</Button></div>
                          <div className="md:col-span-3"><Input label="Endereço" containerClassName="!mb-0" value={currentCollaborator.address} ref={enderecoRef} onChange={e => setCurrentCollaborator({...currentCollaborator, address: e.target.value})} onKeyDown={handleEnterPress} /></div>
                          <Input label="Número" value={currentCollaborator.number} ref={numeroRef} onChange={e => setCurrentCollaborator({...currentCollaborator, number: e.target.value})} onKeyDown={handleEnterPress} /><Input label="Complemento" value={currentCollaborator.complement} onChange={e => setCurrentCollaborator({...currentCollaborator, complement: e.target.value})} onKeyDown={handleEnterPress} /><Input label="Bairro" value={currentCollaborator.district} onChange={e => setCurrentCollaborator({...currentCollaborator, district: e.target.value})} onKeyDown={handleEnterPress} /><Input label="Cidade" value={currentCollaborator.city} onChange={e => setCurrentCollaborator({...currentCollaborator, city: e.target.value})} onKeyDown={handleEnterPress} /><Input label="UF" value={currentCollaborator.state} onChange={e => setCurrentCollaborator({...currentCollaborator, state: e.target.value})} onKeyDown={handleEnterPress} maxLength={2} />
                      </div>
                  </div>
                  <div className="md:col-span-4"><label className="block text-sm font-medium text-gray-700 mb-1">Anotações</label><textarea className="w-full border border-gray-300 rounded-lg p-3 outline-none" rows={3} value={currentCollaborator.notes || ''} onChange={e => setCurrentCollaborator({...currentCollaborator, notes: e.target.value})} /></div>
              </div>

              <FormActions onSave={handleSave} onCancel={handleCancel} />
              {showCamera && <CameraCapture onCapture={handleCameraCapture} onClose={() => setShowCamera(false)} />}
          </div>
      );
  }

  return (
      <div className="flex flex-col h-full animate-fade-in">
          <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Colaboradores</h2>
              {canIncluir && <Button variant="new" className="!w-auto" onClick={handleNewCollaborator}>Novo Colaborador</Button>}
          </div>
          <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-4 flex items-center gap-4">
              <div className="flex-1"><Input label="" placeholder="Pesquisar..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} containerClassName="!mb-0" icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} /></div>
              <div className="flex gap-1 flex-shrink-0">
                  <button onClick={expandAll} className="px-3 py-2 text-[10px] font-bold text-gray-600 hover:bg-gray-100 rounded border border-gray-200 transition-colors" title="Expandir Tudo">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4" /></svg>
                  </button>
                  <button onClick={collapseAll} className="px-3 py-2 text-[10px] font-bold text-gray-600 hover:bg-gray-100 rounded border border-gray-200 transition-colors" title="Recolher Tudo">
                      <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 9V4.5M9 9H4.5M9 9L3.5 3.5M9 15v4.5M9 15H4.5M9 15l-5.5 5.5M15 9h4.5M15 9V4.5M15 9l5.5-5.5M15 15h4.5M15 15v4.5m0-4.5l5.5 5.5" /></svg>
                  </button>
              </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex-1 flex flex-col">
              <div className="overflow-y-auto flex-1">
                  {sortedAndFiltered.length === 0 ? (
                      <div className="px-6 py-16 text-center text-gray-400">
                          <svg className="w-12 h-12 mx-auto mb-3 opacity-50" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                          <p className="font-bold text-sm">{apiLoading ? 'Carregando colaboradores...' : 'Nenhum colaborador encontrado.'}</p>
                      </div>
                  ) : (
                       <div className="divide-y divide-gray-100 collaborator-grid-content">
                          {treeData.unitKeys.map(unitKey => {
                              const unitName = unitKey === '__none__' ? 'Sem Unidade' : getUnitName(unitKey);
                              const unitExpanded = expandedUnits.has(unitKey);
                              const roleGroups = treeData.grouped[unitKey];
                              const roleKeys = Object.keys(roleGroups).sort((a, b) => {
                                  if (a === '__none__') return 1;
                                  if (b === '__none__') return -1;
                                  return getRoleName(a).localeCompare(getRoleName(b));
                              });
                              const totalInUnit = Object.values(roleGroups).reduce((s, arr) => s + arr.length, 0);

                              return (
                                  <div key={unitKey}>
                                      <div 
                                          onClick={() => toggleUnit(unitKey)}
                                          className="flex items-center gap-3 px-5 py-3 bg-moss-800 hover:bg-moss-700 cursor-pointer transition-colors select-none"
                                      >
                                          <svg className={`w-4 h-4 text-white/70 transition-transform flex-shrink-0 ${unitExpanded ? 'rotate-90' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                                          <svg className="w-5 h-5 text-white/60 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                                          <span className="font-bold text-xs text-white uppercase tracking-wide flex-1">{unitName}</span>
                                          <span className="text-[10px] font-bold text-white/50 bg-white/10 px-2 py-0.5 rounded-full">{totalInUnit}</span>
                                      </div>
                                      {unitExpanded && roleKeys.map(roleKey => {
                                          const compositeKey = `${unitKey}::${roleKey}`;
                                          const roleName = roleKey === '__none__' ? 'Sem Cargo' : getRoleName(roleKey);
                                          const roleExpanded = expandedRoles.has(compositeKey);
                                          const collabs = roleGroups[roleKey].sort((a, b) => a.name.localeCompare(b.name));

                                          return (
                                              <div key={compositeKey}>
                                                  <div 
                                                      onClick={() => toggleRole(compositeKey)}
                                                      className="flex items-center gap-3 px-5 py-2.5 pl-10 bg-gray-100 hover:bg-gray-200 cursor-pointer transition-colors select-none border-b border-gray-200"
                                                  >
                                                      <svg className={`w-3.5 h-3.5 text-gray-500 transition-transform flex-shrink-0 ${roleExpanded ? 'rotate-90' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" /></svg>
                                                      <svg className="w-4 h-4 text-purple-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 13.255A23.931 23.931 0 0112 15c-3.183 0-6.22-.62-9-1.745M16 6V4a2 2 0 00-2-2h-4a2 2 0 00-2 2v2m4 6h.01M5 20h14a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                                                      <span className="font-bold text-xs text-gray-700 uppercase tracking-wide flex-1">{roleName}</span>
                                                      <span className="text-[10px] font-bold text-gray-400 bg-gray-200 px-2 py-0.5 rounded-full">{collabs.length}</span>
                                                  </div>
                                                  {roleExpanded && collabs.map(c => {
                                                      const deptName = getDeptName(c.departmentId);
                                                      return (
                                                          <div key={c.id} className="flex items-center gap-3 px-5 py-2.5 pl-16 hover:bg-blue-50/50 transition-colors border-b border-gray-50 group">
                                                              <div className="h-8 w-8 rounded-full bg-gray-200 overflow-hidden flex-shrink-0">
                                                                  {c.photoUrl ? <img src={c.photoUrl} alt="" className="h-full w-full object-cover" /> : <div className="h-full w-full flex items-center justify-center font-bold text-gray-500 text-[10px]">{c.name.charAt(0)}</div>}
                                                              </div>
                                                              <div className="flex-1 min-w-0">
                                                                  <div className="flex items-center gap-2">
                                                                      <span className="text-xs font-medium text-gray-900 truncate">{c.name}</span>
                                                                      {c.active === false 
                                                                          ? <span className="px-1.5 py-0.5 text-[8px] font-black rounded-full uppercase bg-red-100 text-red-700 border border-red-200 flex-shrink-0">Inativo</span> 
                                                                          : <span className="px-1.5 py-0.5 text-[8px] font-black rounded-full uppercase bg-green-100 text-green-700 border border-green-200 flex-shrink-0">Ativo</span>
                                                                      }
                                                                  </div>
                                                                  <div className="flex items-center gap-3 text-xs text-gray-500">
                                                                      {deptName && <span className="flex items-center gap-1"><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5" /></svg>{deptName}</span>}
                                                                      {c.phone && <GotalkPhoneLink phone={c.phone} name={c.name} />}
                                                                      {c.email && <span>{c.email}</span>}
                                                                  </div>
                                                              </div>
                                                              <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0">
                                                                  <AuditLogButton entityId={c.id} entityName={c.name} logs={config.auditLogs || []} />
                                                                  {canAlterar && <button onClick={() => handleEditCollaborator(c)} className="text-indigo-600 hover:text-indigo-900 text-xs font-medium">Editar</button>}
                                                                  {canIncluir && <button onClick={() => handleDuplicateCollaborator(c)} className="text-amber-600 hover:text-amber-800 text-xs font-medium">Duplicar</button>}
                                                                  {canExcluir && <button onClick={() => handleDeleteCollaborator(c.id)} className="text-red-600 hover:text-red-900 text-xs font-medium">Excluir</button>}
                                                              </div>
                                                          </div>
                                                      );
                                                  })}
                                              </div>
                                          );
                                      })}
                                  </div>
                              );
                          })}
                      </div>
                  )}
              </div>
              <div className="px-4 py-2 bg-gray-50 border-t text-xs text-gray-500 font-medium flex-shrink-0">
                  Total: {sortedAndFiltered.length} colaborador{sortedAndFiltered.length !== 1 ? 'es' : ''}
              </div>
          </div>
      </div>
  );
};

export default CollaboratorsPanel;

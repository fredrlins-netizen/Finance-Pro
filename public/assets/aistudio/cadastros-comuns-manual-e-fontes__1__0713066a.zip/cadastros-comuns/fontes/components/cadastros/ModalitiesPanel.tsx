import React, { useState, useMemo, useRef, useEffect, useCallback } from 'react';
import { PortalConfig, Modality } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';
import FormActions from '../ui/FormActions';
import Pagination from '../ui/Pagination';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import AuditLogButton from '../ui/AuditLogButton';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';
import { api } from '../../services/apiService';

interface ModalitiesPanelProps {
  config: PortalConfig;
}

type SortDirection = 'asc' | 'desc' | null;
interface SortConfig {
    key: keyof Modality | null;
    direction: SortDirection;
}

const ModalitiesPanel: React.FC<ModalitiesPanelProps> = ({ config }) => {
  const { validarPermissao, temPermissao, addToast } = useSecurity();
  const canIncluir = temPermissao('cad_modalidades:INCLUIR');
  const canAlterar = temPermissao('cad_modalidades:ALTERAR');
  const canExcluir = temPermissao('cad_modalidades:EXCLUIR');
  const { logTransaction } = useAudit();

  const { data: apiModalities, loading, error, create, update, remove, refresh } = useEntityCRUD<Modality>('modalities');

  const [modalityTypes, setModalityTypes] = useState<string[]>(config.modalityTypes || []);

  useEffect(() => {
    api.get<{ data: Array<{ id: string; value: string }> }>('/api/config-options/modalityType')
      .then(res => {
        if (res.data && res.data.length > 0) {
          setModalityTypes(res.data.map((item: any) => item.value));
        }
      })
      .catch(() => {});
  }, []);

  const modalities = useMemo(() => apiModalities, [apiModalities]);

  const [isEditing, setIsEditing] = useState(false);
  const [currentModality, setCurrentModality] = useState<Modality | null>(null);
  const [originalModality, setOriginalModality] = useState<Modality | null>(null);

  const [typeInputValue, setTypeInputValue] = useState('');
  const [showTypeDropdown, setShowTypeDropdown] = useState(false);
  const typeInputRef = useRef<HTMLInputElement>(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: null, direction: null });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleEnterPress = (e: React.KeyboardEvent<HTMLElement>) => {
    if (e.key === 'Enter') {
        e.preventDefault(); 
        const form = e.currentTarget.closest('div[data-form-container="true"]');
        if (!form) return;

        const focusableElements = form.querySelectorAll<HTMLElement>(
            'input:not([disabled]):not([type="hidden"]):not([readonly]), textarea:not([disabled]), button:not([disabled]):not([type="submit"])'
        );
        
        const focusableArray = Array.from(focusableElements) as HTMLElement[];
        const index = focusableArray.indexOf(e.currentTarget as HTMLElement);
        
        if (index > -1 && index < focusableArray.length - 1) {
            focusableArray[index + 1].focus();
        }
    }
  };

  const handleNewModality = () => {
    if (!validarPermissao('cad_modalidades:INCLUIR')) return;
    const newModality: Modality = {
        id: '',
        type: '',
        description: ''
    };
    setCurrentModality(newModality);
    setOriginalModality(null);
    setTypeInputValue('');
    setIsEditing(true);
  };

  const handleEditModality = (modality: Modality) => {
    if (!validarPermissao('cad_modalidades:ALTERAR')) return;
    setCurrentModality({ ...modality });
    setOriginalModality({ ...modality });
    setTypeInputValue(modality.type);
    setIsEditing(true);
  };

  const handleDuplicateModality = (modality: Modality) => {
    if (!validarPermissao('cad_modalidades:INCLUIR')) return;
    const copy = { ...modality, id: '', description: 'Cópia de ' + modality.description };
    setCurrentModality(copy);
    setOriginalModality(null);
    setTypeInputValue(copy.type);
    setIsEditing(true);
  };

  const handleDeleteModality = async (id: string) => {
    if (!validarPermissao('cad_modalidades:EXCLUIR')) return;
    if (window.confirm('Excluir esta modalidade?')) {
        try {
            const toDelete = modalities.find(m => m.id === id);
            await remove(id);
            logTransaction('MODALIDADE', id, toDelete, null);
            addToast('success', 'Sucesso', 'Modalidade excluída.');
        } catch (err: any) {
            addToast('warning', 'Exclusão Bloqueada', err?.message || 'Não foi possível excluir a modalidade.');
        }
    }
  };

  const handleSave = async () => {
      if (!typeInputValue.trim()) {
          addToast('warning', 'Validação', 'O Tipo é obrigatório.');
          return;
      }

      if (!currentModality) return;

      const modalityToSave = { ...currentModality, type: typeInputValue.toUpperCase() };
      
      try {
          let saved: Modality;
          if (modalityToSave.id) {
              saved = await update(modalityToSave.id, { type: modalityToSave.type, description: modalityToSave.description });
          } else {
              saved = await create({ type: modalityToSave.type, description: modalityToSave.description });
          }

          if (!modalityTypes.includes(modalityToSave.type)) {
              try {
                  await api.post('/api/config-options/modalityType', { value: modalityToSave.type });
                  setModalityTypes(prev => [...prev, modalityToSave.type]);
              } catch {}
          }
          
          logTransaction('MODALIDADE', saved.id, originalModality, saved);
          
          setIsEditing(false);
          setCurrentModality(null);
          setOriginalModality(null);
          addToast('success', 'Sucesso', 'Modalidade salva.');
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Erro ao salvar modalidade.');
      }
  };

  const filteredTypes = useMemo(() => {
      const types = modalityTypes || [];
      if (!typeInputValue) return types;
      return types.filter(t => t.toLowerCase().includes(typeInputValue.toLowerCase()));
  }, [modalityTypes, typeInputValue]);

  const handleSelectType = (type: string) => {
      setTypeInputValue(type);
      if (currentModality) setCurrentModality({...currentModality, type: type});
      setShowTypeDropdown(false);
  };

  const handleSort = (key: keyof Modality) => {
      let direction: SortDirection = 'asc';
      if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
      else if (sortConfig.key === key && sortConfig.direction === 'desc') direction = null;
      setSortConfig({ key: direction ? key : null, direction });
  };

  const sortedAndFiltered = useMemo(() => {
      let data = modalities || [];
      if (searchTerm) {
          const lower = searchTerm.toLowerCase();
          data = data.filter(m => m.type.toLowerCase().includes(lower) || m.description.toLowerCase().includes(lower));
      }
      if (sortConfig.key && sortConfig.direction) {
          data = [...data].sort((a, b) => {
              const valA = a[sortConfig.key!]?.toString().toLowerCase() || '';
              const valB = b[sortConfig.key!]?.toString().toLowerCase() || '';
              if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
              if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
              return 0;
          });
      }
      return data;
  }, [modalities, searchTerm, sortConfig]);

  const paginated = useMemo(() => {
      const start = (currentPage - 1) * itemsPerPage;
      return sortedAndFiltered.slice(start, start + itemsPerPage);
  }, [sortedAndFiltered, currentPage, itemsPerPage]);

  const renderSortIcon = (key: keyof Modality) => {
      if (sortConfig.key !== key) return <span className="text-gray-300 ml-1">⇅</span>;
      return sortConfig.direction === 'asc' ? <span className="text-moss-600 ml-1">↑</span> : <span className="text-moss-600 ml-1">↓</span>;
  };

  const TableHeader = ({ label, sortKey }: { label: string, sortKey: keyof Modality }) => (
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onClick={() => handleSort(sortKey)}>
          <div className="flex items-center">{label} {renderSortIcon(sortKey)}</div>
      </th>
  );

  if (isEditing && currentModality) {
      return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 animate-fade-in" data-form-container="true">
              <div className="flex justify-between items-center mb-6 pb-4 border-b">
                  <h3 className="text-xl font-bold text-gray-800">
                      {currentModality.id ? 'Editar Modalidade' : 'Incluir Modalidade'}
                  </h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="relative">
                      <label className="block text-sm font-medium text-gray-700 mb-1">Tipo</label>
                      <div className="relative">
                          <input 
                              ref={typeInputRef}
                              type="text"
                              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moss-500 outline-none uppercase"
                              placeholder="SELECIONE OU DIGITE..."
                              value={typeInputValue}
                              onChange={(e) => {
                                  setTypeInputValue(e.target.value);
                                  setShowTypeDropdown(true);
                              }}
                              onFocus={() => setShowTypeDropdown(true)}
                              onBlur={() => setTimeout(() => setShowTypeDropdown(false), 200)}
                              onKeyDown={handleEnterPress}
                          />
                          <div className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 pointer-events-none">
                              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" /></svg>
                          </div>
                      </div>
                      
                      {showTypeDropdown && (
                          <div className="absolute z-10 w-full bg-white border border-gray-200 rounded-lg shadow-lg max-h-48 overflow-y-auto mt-1">
                              {filteredTypes.map(type => (
                                  <div 
                                      key={type}
                                      className="px-4 py-2 hover:bg-moss-50 cursor-pointer border-b last:border-0 border-gray-50 text-sm font-medium text-gray-700 uppercase"
                                      onMouseDown={() => handleSelectType(type)}
                                  >
                                      {type}
                                  </div>
                              ))}
                              {typeInputValue && !filteredTypes.includes(typeInputValue.toUpperCase()) && (
                                  <div 
                                      className="px-4 py-2 hover:bg-green-50 cursor-pointer border-t border-gray-100 text-sm font-bold text-green-700 flex items-center gap-2 uppercase"
                                      onMouseDown={() => handleSelectType(typeInputValue.toUpperCase())}
                                  >
                                      <span>+ CRIAR NOVO TIPO:</span>
                                      <span className="bg-green-100 px-2 py-0.5 rounded">{typeInputValue.toUpperCase()}</span>
                                  </div>
                              )}
                              {filteredTypes.length === 0 && !typeInputValue && (
                                  <div className="p-3 text-center text-gray-400 text-sm">Digite para criar um novo...</div>
                              )}
                          </div>
                      )}
                  </div>

                  <div>
                      <Input 
                        label="Descrição" 
                        value={currentModality.description} 
                        onChange={e => setCurrentModality({...currentModality!, description: e.target.value})} 
                        onKeyDown={handleEnterPress}
                        placeholder="Ex: Negociação de dívidas bancárias"
                        containerClassName="!mb-0"
                      />
                  </div>
              </div>

              <FormActions onSave={handleSave} onCancel={() => setIsEditing(false)} />
          </div>
      );
  }

  return (
       <div className="flex flex-col h-full animate-fade-in" data-grid-density="compact">
          <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Modalidades de Negócio</h2>
              {canIncluir && <Button variant="new" className="!w-auto" onClick={handleNewModality}>Nova Modalidade</Button>}
          </div>

          {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex justify-between items-center">
                  <span>{error}</span>
                  <button onClick={refresh} className="text-red-800 underline text-sm">Tentar novamente</button>
              </div>
          )}

          {loading && modalities.length === 0 && (
              <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-moss-600"></div>
                  <span className="ml-3 text-gray-500">Carregando modalidades...</span>
              </div>
          )}

           <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-4 grid-search">
              <Input label="" placeholder="Pesquisar..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} containerClassName="!mb-0" icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} />
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex-1 flex flex-col">
               <div className="overflow-x-auto grid-body-scroll">
                  <table className="min-w-full divide-y divide-gray-200 operational-grid">
                      <thead className="bg-gray-50">
                          <tr>
                              <TableHeader label="Tipo" sortKey="type" />
                              <TableHeader label="Descrição" sortKey="description" />
                              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">Ações</th>
                          </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                          {paginated.length === 0 && <tr><td colSpan={3} className="px-6 py-10 text-center text-gray-500">{loading ? 'Carregando...' : 'Nenhum registro encontrado.'}</td></tr>}
                          {paginated.map(m => (
                              <tr key={m.id} className="hover:bg-gray-50">
                                  <td className="px-6 py-4 whitespace-nowrap">
                                      <span className="px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800 uppercase">
                                          {m.type}
                                      </span>
                                  </td>
                                  <td className="px-6 py-4 text-sm text-gray-600">{m.description}</td>
                                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                      <div className="flex justify-end items-center gap-3">
                                          <AuditLogButton entityId={m.id} entityName={(m as any).name || m.description} logs={config.auditLogs || []} />
                                          {canAlterar && <button onClick={() => handleEditModality(m)} className="text-indigo-600 hover:text-indigo-900">Editar</button>}
                                          {canIncluir && <button onClick={() => handleDuplicateModality(m)} className="text-amber-600 hover:text-amber-800">Duplicar</button>}
                                          {canExcluir && <button onClick={() => handleDeleteModality(m.id)} className="text-red-600 hover:text-red-900">Excluir</button>}
                                      </div>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
              <Pagination totalItems={sortedAndFiltered.length} itemsPerPage={itemsPerPage} currentPage={currentPage} onPageChange={setCurrentPage} onItemsPerPageChange={setItemsPerPage} />
          </div>
      </div>
  );
};

export default ModalitiesPanel;

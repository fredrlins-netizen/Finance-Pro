import React, { useState, useMemo, useEffect } from 'react';
import { Department, PortalConfig } from '../../types';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { useKeyboardShortcut } from '../../contexts/KeyboardShortcutContext';
import { checkDependencies, formatDependencyMessage } from '../../utils/dependencyCheck';
import Button from '../ui/Button';
import Input from '../ui/Input';
import AuditLogButton from '../ui/AuditLogButton';

const DepartmentManager: React.FC<{
    departments: Department[];
    onUpdate: (depts: Department[]) => void;
    config: PortalConfig;
}> = ({ departments, onUpdate, config }) => {
    const { addToast, validarPermissao } = useSecurity();
    const { logTransaction } = useAudit();
    const { registerFormActions, unregisterFormActions } = useKeyboardShortcut();

    const [isEditing, setIsEditing] = useState(false);
    const [currentDept, setCurrentDept] = useState<Department | null>(null);
    const [originalDept, setOriginalDept] = useState<Department | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    const handleNew = () => {
        if (!validarPermissao('fin_departamentos:INCLUIR')) return;
        setCurrentDept({
            id: '', code: '', name: '', managerName: '', status: 'ATIVO'
        });
        setOriginalDept(null);
        setIsEditing(true);
    };

    const handleEdit = (dept: Department) => {
        if (!validarPermissao('fin_departamentos:ALTERAR')) return;
        setCurrentDept({ ...dept });
        setOriginalDept({ ...dept });
        setIsEditing(true);
    };

    const handleDelete = (id: string) => {
        if (!validarPermissao('fin_departamentos:EXCLUIR')) return;
        const result = checkDependencies('department', id, config);
        if (!result.canDelete) {
            const deptName = departments.find(d => d.id === id)?.name || id;
            addToast('warning', 'Exclusão Bloqueada', formatDependencyMessage(`o departamento "${deptName}"`, result.dependencies));
            return;
        }
        if (window.confirm('Excluir este departamento?')) {
            const updated = departments.filter(d => d.id !== id);
            onUpdate(updated);
            const deleted = departments.find(d => d.id === id);
            logTransaction('DEPARTAMENTO' as any, id, deleted, null);
            addToast('success', 'Sucesso', 'Departamento excluído.');
        }
    };

    const handleSave = () => {
        if (!currentDept?.name) {
            addToast('warning', 'Validação', 'Nome é obrigatório.');
            return;
        }
        const list = [...departments];
        let itemToSave = { ...currentDept };

        if (itemToSave.id) {
            const idx = list.findIndex(d => d.id === itemToSave.id);
            if (idx !== -1) list[idx] = itemToSave;
        } else {
            itemToSave.id = 'dep-' + Date.now();
            list.push(itemToSave);
        }

        onUpdate(list);
        logTransaction('DEPARTAMENTO' as any, itemToSave.id, originalDept, itemToSave);
        
        setIsEditing(false);
        setCurrentDept(null);
        addToast('success', 'Sucesso', 'Departamento salvo.');
    };

    useEffect(() => {
        if (isEditing) {
            registerFormActions(handleSave, () => setIsEditing(false));
        } else {
            unregisterFormActions();
        }
        return () => unregisterFormActions();
    }, [isEditing]);

    const filteredList = useMemo(() => {
        const lower = searchTerm.toLowerCase();
        return departments.filter(d => d.name.toLowerCase().includes(lower) || d.code.includes(lower));
    }, [departments, searchTerm]);

    if (isEditing && currentDept) {
        return (
            <div className="rounded-2xl shadow-2xl border border-gray-200 animate-fade-in max-w-2xl mx-auto flex flex-col bg-white overflow-hidden">
                <div className="bg-moss-800 px-6 py-4 flex items-center justify-between flex-shrink-0">
                    <div className="flex items-center gap-3">
                        <svg className="w-7 h-7 text-white/80" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" /></svg>
                        <div>
                            <h3 className="text-lg font-bold text-white tracking-wide">Departamentos</h3>
                            <p className="text-xs text-white/60">{currentDept.id ? 'Editando departamento existente' : 'Novo departamento'}</p>
                        </div>
                    </div>
                    <button onClick={() => setIsEditing(false)} className="w-8 h-8 rounded-full flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10 transition-colors">
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                    </button>
                </div>
                <div className="overflow-y-auto bg-gray-50 p-6 space-y-6">
                    <div className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden">
                        <div className="flex items-center gap-3 px-5 py-3 border-b border-gray-100">
                            <div className="w-2 h-6 rounded-full bg-moss-500"></div>
                            <span className="text-[11px] font-black uppercase tracking-widest text-gray-500">Dados do Departamento</span>
                        </div>
                        <div className="p-5 space-y-4">
                            <div className="grid grid-cols-4 gap-4">
                                <div className="col-span-1">
                                    <Input label="Código" value={currentDept.code} onChange={e => setCurrentDept({...currentDept, code: e.target.value})} placeholder="Ex: 01" />
                                </div>
                                <div className="col-span-3">
                                    <Input label="Nome do Departamento" value={currentDept.name} onChange={e => setCurrentDept({...currentDept, name: e.target.value.toUpperCase()})} placeholder="Ex: FINANCEIRO" />
                                </div>
                            </div>
                            <Input label="Responsável / Gerente" value={currentDept.managerName || ''} onChange={e => setCurrentDept({...currentDept, managerName: e.target.value})} placeholder="Ex: João da Silva" />
                            <div>
                                <label className="block text-sm font-medium text-gray-700 mb-1">Status</label>
                                <select className="w-full rounded-lg border border-gray-300 bg-white px-4 py-3 text-sm focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none transition-colors" value={currentDept.status} onChange={e => setCurrentDept({...currentDept, status: e.target.value as any})}>
                                    <option value="ATIVO">Ativo</option>
                                    <option value="INATIVO">Inativo</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div className="bg-gray-100 px-6 py-4 flex justify-end gap-3 border-t border-gray-200 flex-shrink-0">
                    <button onClick={() => setIsEditing(false)} className="px-5 py-2.5 rounded-lg border border-gray-300 text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors">Cancelar</button>
                    <button onClick={handleSave} className="px-6 py-2.5 rounded-lg bg-moss-700 text-white text-sm font-bold hover:bg-moss-800 transition-colors shadow-sm">Salvar</button>
                </div>
            </div>
        );
    }

    return (
        <div className="flex flex-col h-full animate-fade-in space-y-4" data-grid-density="compact">
            <div className="flex justify-between items-center mb-2">
                <h2 className="text-2xl font-bold text-gray-800">Departamentos</h2>
                <Button variant="new" className="!w-auto" onClick={handleNew}>Novo Departamento</Button>
            </div>
            <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 grid-search">
                <Input label="" placeholder="Pesquisar..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} containerClassName="!mb-0" icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} />
            </div>
            <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex-1 flex flex-col">
                 <div className="overflow-x-auto grid-body-scroll">
                     <table className="min-w-full divide-y divide-gray-200 operational-grid">
                        <thead className="bg-gray-50">
                            <tr>
                                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Descrição</th>
                                <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Responsável</th>
                                <th className="px-6 py-3 text-center text-xs font-bold text-gray-500 uppercase">Status</th>
                                <th className="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Ações</th>
                            </tr>
                        </thead>
                        <tbody className="bg-white divide-y divide-gray-200">
                            {filteredList.map(dept => (
                                 <tr key={dept.id} className="operational-grid-row hover:bg-gray-50 transition-colors">
                                    <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{dept.name}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{dept.managerName || '-'}</td>
                                    <td className="px-6 py-4 whitespace-nowrap text-center">
                                        <span className={`px-2 py-1 inline-flex text-[10px] font-black rounded-full uppercase ${dept.status === 'ATIVO' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>{dept.status}</span>
                                    </td>
                                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                        <div className="flex justify-end items-center gap-3">
                                            <AuditLogButton entityId={dept.id} entityName={dept.name} logs={config.auditLogs || []} />
                                            <button onClick={() => handleEdit(dept)} className="text-indigo-600 hover:text-indigo-900">Editar</button>
                                            <button onClick={() => handleDelete(dept.id)} className="text-red-600 hover:text-red-900">Excluir</button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

interface DepartamentosPanelProps {
    config: PortalConfig;
    onUpdate: (depts: Department[]) => void;
}

const DepartamentosPanel: React.FC<DepartamentosPanelProps> = ({ config, onUpdate }) => {
    return (
        <DepartmentManager
            departments={config.departments || []}
            onUpdate={onUpdate}
            config={config}
        />
    );
};

export default DepartamentosPanel;

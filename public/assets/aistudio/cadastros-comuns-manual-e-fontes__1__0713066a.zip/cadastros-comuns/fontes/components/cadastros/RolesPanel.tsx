import React, { useState, useMemo } from 'react';
import { PortalConfig, Role } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';
import FormActions from '../ui/FormActions';
import Pagination from '../ui/Pagination';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAuditedCRUD } from '../../hooks/useAuditedCRUD';
import AuditLogButton from '../ui/AuditLogButton';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';

interface RolesPanelProps {
  config: PortalConfig;
}

type SortDirection = 'asc' | 'desc' | null;
interface SortConfig {
    key: keyof Role | null;
    direction: SortDirection;
}

interface ApiRole {
  id: string;
  option_type: string;
  value: string;
  sort_order: number;
}

function apiToRole(r: ApiRole): Role {
  try {
    const parsed = JSON.parse(r.value);
    if (typeof parsed === 'object' && parsed.name) {
      return { id: r.id, name: parsed.name, participatesInScheduling: !!parsed.participatesInScheduling };
    }
  } catch {}
  return { id: r.id, name: r.value, participatesInScheduling: false };
}

function roleToApiValue(role: Partial<Role>): string {
  return JSON.stringify({ name: role.name, participatesInScheduling: !!role.participatesInScheduling });
}

const RolesPanel: React.FC<RolesPanelProps> = ({ config }) => {
  const { validarPermissao, temPermissao, addToast } = useSecurity();
  const canIncluir = temPermissao('cad_cargos:INCLUIR');
  const canAlterar = temPermissao('cad_cargos:ALTERAR');
  const canExcluir = temPermissao('cad_cargos:EXCLUIR');
  const { auditSave, auditDelete } = useAuditedCRUD<Role>('CARGO');

  const { data: rawRoles, loading, error, create: apiCreate, update: apiUpdate, remove: apiRemove, refresh } = useEntityCRUD<ApiRole>('roles');
  const roles = useMemo(() => rawRoles.map(apiToRole), [rawRoles]);

  const [isEditing, setIsEditing] = useState(false);
  const [currentRole, setCurrentRole] = useState<Role | null>(null);
  const [originalRole, setOriginalRole] = useState<Role | null>(null);

  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: null, direction: null });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleNewRole = () => {
      if (!validarPermissao('cad_cargos:INCLUIR')) return;
      setCurrentRole({ id: '', name: '', participatesInScheduling: false });
      setOriginalRole(null);
      setIsEditing(true);
  };

  const handleEditRole = (role: Role) => {
      if (!validarPermissao('cad_cargos:ALTERAR')) return;
      setCurrentRole({ ...role });
      setOriginalRole({ ...role });
      setIsEditing(true);
  };

  const handleDuplicateRole = (role: Role) => {
      if (!validarPermissao('cad_cargos:INCLUIR')) return;
      setCurrentRole({ ...role, id: '', name: 'Cópia de ' + role.name });
      setOriginalRole(null);
      setIsEditing(true);
  };

  const handleSave = async () => {
      if (!currentRole || !currentRole.name.trim()) {
          addToast('warning', 'Validação', 'O nome do cargo é obrigatório.');
          return;
      }
      try {
          const payload = { value: roleToApiValue(currentRole), sort_order: 0 } as any;
          if (currentRole.id) {
              await apiUpdate(currentRole.id, payload);
          } else {
              await apiCreate(payload);
          }
          auditSave(currentRole, originalRole);
          addToast('success', 'Sucesso', `Cargo "${currentRole.name}" salvo com sucesso.`);
          setIsEditing(false);
          setCurrentRole(null);
          setOriginalRole(null);
          refresh();
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Erro ao salvar cargo.');
      }
  };

  const handleDelete = async (role: Role) => {
      if (!validarPermissao('cad_cargos:EXCLUIR')) return;
      if (!window.confirm(`Excluir o cargo "${role.name}"?`)) return;
      try {
          await apiRemove(role.id);
          auditDelete(role);
          addToast('success', 'Sucesso', 'Cargo excluído.');
      } catch (err: any) {
          addToast('warning', 'Exclusão Bloqueada', err?.message || 'Não foi possível excluir o cargo.');
      }
  };

  const handleCancel = () => {
      setIsEditing(false);
      setCurrentRole(null);
      setOriginalRole(null);
  };

  const handleSort = (key: keyof Role) => {
      setSortConfig(prev => ({
          key,
          direction: prev.key === key ? (prev.direction === 'asc' ? 'desc' : prev.direction === 'desc' ? null : 'asc') : 'asc'
      }));
  };

  const handleEnterPress = (e: React.KeyboardEvent) => {
      if (e.key === 'Enter') {
          e.preventDefault();
          const form = (e.target as HTMLElement).closest('form');
          if (form) {
              const inputs = Array.from(form.querySelectorAll('input, select, textarea'));
              const idx = inputs.indexOf(e.target as HTMLElement);
              if (idx < inputs.length - 1) (inputs[idx + 1] as HTMLElement).focus();
          }
      }
  };

  const sortedRoles = useMemo(() => {
      let data = [...roles];
      if (searchTerm) {
          const lower = searchTerm.toLowerCase();
          data = data.filter(r => r.name.toLowerCase().includes(lower));
      }
      if (sortConfig.key && sortConfig.direction) {
          data.sort((a, b) => {
              const valA = String(a[sortConfig.key!] ?? '').toLowerCase();
              const valB = String(b[sortConfig.key!] ?? '').toLowerCase();
              return sortConfig.direction === 'asc' ? valA.localeCompare(valB) : valB.localeCompare(valA);
          });
      }
      return data;
  }, [roles, searchTerm, sortConfig]);

  const paginatedRoles = useMemo(() => {
      const start = (currentPage - 1) * itemsPerPage;
      return sortedRoles.slice(start, start + itemsPerPage);
  }, [sortedRoles, currentPage, itemsPerPage]);

  const TableHeader = ({ label, sortKey }: { label: string; sortKey: keyof Role }) => (
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onClick={() => handleSort(sortKey)}>
          {label} {sortConfig.key === sortKey ? (sortConfig.direction === 'asc' ? '↑' : sortConfig.direction === 'desc' ? '↓' : '⇅') : '⇅'}
      </th>
  );

  if (isEditing && currentRole) {
      return (
          <div className="flex flex-col h-full animate-fade-in w-full p-4 md:p-8 overflow-y-auto">
              <div className="flex justify-between items-center mb-6">
                  <div>
                      <h2 className="text-3xl font-black text-gray-900 tracking-tighter uppercase italic">{originalRole ? 'Editar Cargo' : 'Novo Cargo'}</h2>
                      <p className="text-gray-500 text-sm font-medium">Preencha os dados do cargo.</p>
                  </div>
              </div>
              <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 max-w-2xl">
                  <form onSubmit={e => { e.preventDefault(); handleSave(); }}>
                      <div className="space-y-6">
                          <Input label="Nome do Cargo *" value={currentRole.name} onChange={e => setCurrentRole({ ...currentRole, name: e.target.value })} onKeyDown={handleEnterPress} autoFocus />
                          <div className="flex items-center gap-3 bg-gray-50 p-4 rounded-lg border border-gray-200">
                              <input
                                  type="checkbox"
                                  id="scheduling"
                                  checked={currentRole.participatesInScheduling}
                                  onChange={e => setCurrentRole({ ...currentRole, participatesInScheduling: e.target.checked })}
                                  className="w-5 h-5 text-moss-600 border-gray-300 rounded focus:ring-moss-500 cursor-pointer"
                              />
                              <label htmlFor="scheduling" className="text-sm font-bold text-gray-700 cursor-pointer select-none">
                                  Participa da Fila de Agendamento
                              </label>
                          </div>
                      </div>
                      <FormActions onSave={handleSave} onCancel={handleCancel} />
                  </form>
              </div>
          </div>
      );
  }

  return (
       <div className="flex flex-col h-full min-h-0 animate-fade-in w-full" data-grid-density="compact">
          <div className="flex justify-between items-center mb-8">
              <div>
                  <h2 className="text-3xl font-black text-gray-900 tracking-tighter uppercase italic">Cargos</h2>
                  <p className="text-gray-500 text-sm font-medium">Gerencie os cargos disponíveis para os colaboradores.</p>
              </div>
              {canIncluir && <Button variant="new" className="!w-auto px-6 py-3 shadow-lg transform hover:scale-105 transition-all" onClick={handleNewRole}>Novo Cargo</Button>}
          </div>

          {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex justify-between items-center">
                  <span>{error}</span>
                  <button onClick={refresh} className="text-red-800 underline text-sm">Tentar novamente</button>
              </div>
          )}

          {loading && roles.length === 0 && (
              <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-moss-600"></div>
                  <span className="ml-3 text-gray-500">Carregando cargos...</span>
              </div>
          )}

           <div className="mb-4 grid-search">
              <Input label="Buscar" placeholder="Buscar por nome..." value={searchTerm} onChange={e => { setSearchTerm(e.target.value); setCurrentPage(1); }} />
          </div>
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden flex-1 flex flex-col">
               <div className="overflow-x-auto grid-body-scroll">
                  <table className="operational-grid visual-dimension-grid min-w-full divide-y divide-gray-200">
                      <thead className="bg-gray-50">
                          <tr>
                              <TableHeader label="Nome" sortKey="name" />
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Fila de Agendamento</th>
                              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                          </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                          {paginatedRoles.length === 0 ? (
                              <tr><td colSpan={3} className="px-6 py-10 text-center text-gray-400">{loading ? 'Carregando...' : 'Nenhum cargo cadastrado.'}</td></tr>
                          ) : (
                              paginatedRoles.map(role => (
                                  <tr key={role.id} className="hover:bg-gray-50 transition-colors">
                                      <td className="px-6 py-4 whitespace-nowrap text-sm font-bold text-gray-900">{role.name}</td>
                                      <td className="px-6 py-4 whitespace-nowrap">
                                          {role.participatesInScheduling ? (
                                              <span className="px-2.5 py-1 inline-flex text-[10px] font-black rounded-full uppercase bg-green-100 text-green-700 border border-green-200">Sim</span>
                                          ) : (
                                              <span className="px-2.5 py-1 inline-flex text-[10px] font-black rounded-full uppercase bg-gray-100 text-gray-500 border border-gray-200">Não</span>
                                          )}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                          <div className="flex justify-end items-center gap-3">
                                              <AuditLogButton entityId={role.id} entityName={role.name} logs={config.auditLogs || []} />
                                              {canAlterar && <button onClick={() => handleEditRole(role)} className="text-blue-600 hover:text-blue-900">Editar</button>}
                                              {canIncluir && <button onClick={() => handleDuplicateRole(role)} className="text-amber-600 hover:text-amber-800">Duplicar</button>}
                                              {canExcluir && <button onClick={() => handleDelete(role)} className="text-red-400 hover:text-red-600">Excluir</button>}
                                          </div>
                                      </td>
                                  </tr>
                              ))
                          )}
                      </tbody>
                  </table>
              </div>
              <Pagination totalItems={sortedRoles.length} itemsPerPage={itemsPerPage} currentPage={currentPage} onPageChange={setCurrentPage} onItemsPerPageChange={setItemsPerPage} />
          </div>
      </div>
  );
};

export default RolesPanel;

import React, { useState, useMemo, useEffect } from 'react';
import { PortalConfig, Series, UnitNumbering, CompanyInfo } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';
import FormActions from '../ui/FormActions';
import Pagination from '../ui/Pagination';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import AuditLogButton from '../ui/AuditLogButton';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';
import { api, ApiItemResponse, ApiListResponse } from '../../services/apiService';

interface SeriesPanelProps {
  config: PortalConfig;
}

type SortDirection = 'asc' | 'desc' | null;
interface SortConfig {
    key: keyof Series | null;
    direction: SortDirection;
}

interface ApiSeries {
  id: string;
  sigla: string;
  description: string;
  general_number?: number;
  generalNumber?: number;
}

function apiToSeries(s: ApiSeries, unitNumbering: UnitNumbering[] = []): Series {
  return { id: s.id, sigla: s.sigla, description: s.description, generalNumber: s.generalNumber ?? s.general_number ?? 0, unitNumbering };
}

function seriesToApi(s: Partial<Series>): Record<string, any> {
  const result: Record<string, any> = {};
  if (s.sigla !== undefined) result.sigla = s.sigla;
  if (s.description !== undefined) result.description = s.description;
  if (s.generalNumber !== undefined) result.general_number = s.generalNumber;
  return result;
}

const SeriesPanel: React.FC<SeriesPanelProps> = ({ config }) => {
  const { validarPermissao, temPermissao, addToast } = useSecurity();
  const canIncluir = temPermissao('cad_series:INCLUIR');
  const canAlterar = temPermissao('cad_series:ALTERAR');
  const canExcluir = temPermissao('cad_series:EXCLUIR');
  const { logTransaction } = useAudit();

  const { data: rawSeries, loading, error, create: apiCreate, update: apiUpdate, remove: apiRemove, refresh } = useEntityCRUD<ApiSeries>('series');
  
  const [unitNumberingMap, setUnitNumberingMap] = useState<Record<string, UnitNumbering[]>>({});

  const series = useMemo(() => rawSeries.map(s => apiToSeries(s, unitNumberingMap[s.id] || [])), [rawSeries, unitNumberingMap]);

  const units = config.units || [];

  const [isEditing, setIsEditing] = useState(false);
  const [currentSeries, setCurrentSeries] = useState<Series | null>(null);
  const [originalSeries, setOriginalSeries] = useState<Series | null>(null);
  const [selectedUnitToAdd, setSelectedUnitToAdd] = useState<string>('');

  const [searchTerm, setSearchTerm] = useState('');
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: null, direction: null });
  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(10);

  const handleEnterPress = (e: React.KeyboardEvent<HTMLElement>) => {
    if (e.key === 'Enter') {
        e.preventDefault(); 
        const form = e.currentTarget.closest('div[data-form-container="true"]');
        if (!form) return;
        const focusableElements = form.querySelectorAll<HTMLElement>(
            'input:not([disabled]):not([type="hidden"]):not([readonly]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]):not([type="submit"])'
        );
        const focusableArray = Array.from(focusableElements) as HTMLElement[];
        const index = focusableArray.indexOf(e.currentTarget as HTMLElement);
        if (index > -1 && index < focusableArray.length - 1) {
            focusableArray[index + 1].focus();
        }
    }
  };

  const handleNewSeries = () => {
    if (!validarPermissao('cad_series:INCLUIR')) return;
    const newSeries: Series = { id: '', sigla: '', description: '', generalNumber: 0, unitNumbering: [] };
    setCurrentSeries(newSeries);
    setOriginalSeries(null);
    setSelectedUnitToAdd('');
    setIsEditing(true);
  };

  const handleEditSeries = (s: Series) => {
    if (!validarPermissao('cad_series:ALTERAR')) return;
    setCurrentSeries({ ...s, unitNumbering: s.unitNumbering || [] });
    setOriginalSeries({ ...s });
    setSelectedUnitToAdd('');
    setIsEditing(true);
  };

  const handleDuplicateSeries = (s: Series) => {
    if (!validarPermissao('cad_series:INCLUIR')) return;
    setCurrentSeries({
      ...s,
      id: '',
      sigla: 'C-' + s.sigla,
      description: 'Cópia de ' + s.description,
      generalNumber: 0,
      unitNumbering: [],
    });
    setOriginalSeries(null);
    setSelectedUnitToAdd('');
    setIsEditing(true);
  };

  const handleDeleteSeries = async (id: string) => {
    if (!validarPermissao('cad_series:EXCLUIR')) return;
    if (window.confirm('Excluir esta série de numeração?')) {
        try {
            const toDelete = series.find(s => s.id === id);
            await apiRemove(id);
            logTransaction('SERIE', id, toDelete, null);
            addToast('success', 'Sucesso', 'Série excluída.');
        } catch (err: any) {
            addToast('warning', 'Exclusão Bloqueada', err?.message || 'Não foi possível excluir a série.');
        }
    }
  };

  const handleSave = async () => {
      if (!currentSeries?.sigla || !currentSeries?.description) {
          addToast('warning', 'Validação', 'Sigla e Descrição são obrigatórios.');
          return;
      }

      try {
          const payload = seriesToApi(currentSeries);
          let saved: any;
          if (currentSeries.id) {
              saved = await apiUpdate(currentSeries.id, payload as any);
          } else {
              saved = await apiCreate(payload as any);
          }
          
          logTransaction('SERIE', saved.id || currentSeries.id, originalSeries, currentSeries);
          
          setIsEditing(false);
          setCurrentSeries(null);
          setOriginalSeries(null);
          addToast('success', 'Sucesso', 'Série salva.');
          refresh();
      } catch (err: any) {
          addToast('error', 'Erro', err?.message || 'Erro ao salvar série.');
      }
  };

  const availableUnitsForSelect = useMemo(() => {
    if (!currentSeries) return [];
    return units.filter(u => !currentSeries.unitNumbering.some(un => un.unitId === u.id));
  }, [units, currentSeries?.unitNumbering]);

  const handleAddUnitToGrid = () => {
      if (!selectedUnitToAdd || !currentSeries) return;
      const newEntry: UnitNumbering = { unitId: selectedUnitToAdd, currentNumber: 0 };
      setCurrentSeries({
          ...currentSeries,
          unitNumbering: [...currentSeries.unitNumbering, newEntry]
      });
      setSelectedUnitToAdd('');
  };

  const handleRemoveUnitFromGrid = (unitId: string) => {
      if (!currentSeries) return;
      setCurrentSeries({
          ...currentSeries,
          unitNumbering: currentSeries.unitNumbering.filter(un => un.unitId !== unitId)
      });
  };

  const updateUnitNumber = (unitId: string, value: string) => {
      if (!currentSeries) return;
      const val = parseInt(value) || 0;
      const updatedNumbering = currentSeries.unitNumbering.map(un => 
          un.unitId === unitId ? { ...un, currentNumber: val } : un
      );
      setCurrentSeries({ ...currentSeries, unitNumbering: updatedNumbering });
  };

  const handleSort = (key: keyof Series) => {
      let direction: SortDirection = 'asc';
      if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
      else if (sortConfig.key === key && sortConfig.direction === 'desc') direction = null;
      setSortConfig({ key: direction ? key : null, direction });
  };

  const sortedAndFiltered = useMemo(() => {
      let data = series || [];
      if (searchTerm) {
          const lower = searchTerm.toLowerCase();
          data = data.filter(s => s.sigla.toLowerCase().includes(lower) || s.description.toLowerCase().includes(lower));
      }
      if (sortConfig.key && sortConfig.direction) {
          data = [...data].sort((a, b) => {
              const valA = a[sortConfig.key!]?.toString().toLowerCase() || '';
              const valB = b[sortConfig.key!]?.toString().toLowerCase() || '';
              if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
              if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
              return 0;
          });
      }
      return data;
  }, [series, searchTerm, sortConfig]);

  const paginated = useMemo(() => {
      const start = (currentPage - 1) * itemsPerPage;
      return sortedAndFiltered.slice(start, start + itemsPerPage);
  }, [sortedAndFiltered, currentPage, itemsPerPage]);

  const renderSortIcon = (key: keyof Series) => {
      if (sortConfig.key !== key) return <span className="text-gray-300 ml-1">⇅</span>;
      return sortConfig.direction === 'asc' ? <span className="text-moss-600 ml-1">↑</span> : <span className="text-moss-600 ml-1">↓</span>;
  };

  const TableHeader = ({ label, sortKey }: { label: string, sortKey: keyof Series }) => (
      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100" onClick={() => handleSort(sortKey)}>
          <div className="flex items-center">{label} {renderSortIcon(sortKey)}</div>
      </th>
  );

  if (isEditing && currentSeries) {
      return (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 animate-fade-in" data-form-container="true">
              <div className="flex justify-between items-center mb-6 pb-4 border-b">
                  <h3 className="text-xl font-bold text-gray-800">{currentSeries.id ? 'Editar Série' : 'Nova Série'}</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 mb-8 items-end">
                  <div className="md:col-span-2">
                    <Input 
                        label="Sigla" 
                        value={currentSeries.sigla} 
                        onChange={e => setCurrentSeries({...currentSeries, sigla: e.target.value.toUpperCase()})} 
                        onKeyDown={handleEnterPress}
                        placeholder="Ex: CONTR"
                        containerClassName="!mb-0"
                    />
                  </div>
                  <div className="md:col-span-8">
                    <Input 
                        label="Descrição" 
                        value={currentSeries.description} 
                        onChange={e => setCurrentSeries({...currentSeries, description: e.target.value})} 
                        onKeyDown={handleEnterPress}
                        placeholder="Ex: Série de Contratos Internos"
                        containerClassName="!mb-0"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Input 
                        label="Nº Geral" 
                        type="number"
                        value={currentSeries.generalNumber} 
                        onChange={e => setCurrentSeries({...currentSeries, generalNumber: parseInt(e.target.value) || 0})} 
                        onKeyDown={handleEnterPress}
                        containerClassName="!mb-0"
                    />
                  </div>
              </div>

              <div className="border rounded-lg overflow-hidden bg-gray-50">
                  <div className="bg-white px-4 py-4 border-b flex flex-col md:flex-row justify-between items-center gap-4">
                      <div>
                        <h4 className="font-bold text-gray-700 text-sm uppercase">Numeração por Unidade</h4>
                        <p className="text-xs text-gray-500">Adicione unidades para definir numerações específicas.</p>
                      </div>
                      
                      <div className="flex items-center gap-2 w-full md:w-auto">
                          <select 
                            className="flex-1 md:w-64 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-moss-500 outline-none bg-white"
                            value={selectedUnitToAdd}
                            onChange={(e) => setSelectedUnitToAdd(e.target.value)}
                          >
                              <option value="">Selecione a Unidade...</option>
                              {availableUnitsForSelect.map(u => (
                                  <option key={u.id} value={u.id}>{u.nomeFantasia || u.razaoSocial}</option>
                              ))}
                          </select>
                          <Button 
                            variant="secondary" 
                            className="!w-auto !py-2 !px-4 !text-sm" 
                            onClick={handleAddUnitToGrid}
                            disabled={!selectedUnitToAdd}
                          >
                              Adicionar Unidade
                          </Button>
                      </div>
                  </div>

                  <table className="min-w-full divide-y divide-gray-200 operational-grid">
                      <thead className="bg-gray-100">
                          <tr>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Unidade</th>
                              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Numeração Atual</th>
                              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ação</th>
                          </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                          {currentSeries.unitNumbering.length === 0 && (
                              <tr>
                                  <td colSpan={3} className="px-6 py-8 text-center text-gray-400 text-sm italic">
                                      Nenhuma unidade selecionada para esta série. Use o campo acima para adicionar.
                                  </td>
                              </tr>
                          )}
                          {currentSeries.unitNumbering.map(numbering => {
                              const unit = units.find(u => u.id === numbering.unitId);
                              return (
                                  <tr key={numbering.unitId} className="hover:bg-gray-50">
                                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-800">
                                          {unit?.nomeFantasia || unit?.razaoSocial || `Unidade #${numbering.unitId}`}
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap">
                                          <input 
                                              type="number"
                                              className="w-32 px-3 py-1 border border-gray-300 rounded focus:ring-2 focus:ring-moss-500 outline-none"
                                              value={numbering.currentNumber}
                                              onChange={(e) => updateUnitNumber(numbering.unitId, e.target.value)}
                                              onKeyDown={handleEnterPress}
                                          />
                                      </td>
                                      <td className="px-6 py-4 whitespace-nowrap text-right text-sm">
                                          <button 
                                            onClick={() => handleRemoveUnitFromGrid(numbering.unitId)}
                                            className="text-red-500 hover:text-red-700 font-medium"
                                          >
                                              Remover
                                          </button>
                                      </td>
                                  </tr>
                              );
                          })}
                      </tbody>
                  </table>
              </div>

              <FormActions onSave={handleSave} onCancel={() => setIsEditing(false)} />
          </div>
      );
  }

  return (
       <div className="flex flex-col h-full animate-fade-in" data-grid-density="compact">
          <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-gray-800">Séries e Numerações</h2>
              {canIncluir && <Button variant="new" className="!w-auto" onClick={handleNewSeries}>Nova Série</Button>}
          </div>

          {error && (
              <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4 flex justify-between items-center">
                  <span>{error}</span>
                  <button onClick={refresh} className="text-red-800 underline text-sm">Tentar novamente</button>
              </div>
          )}

          {loading && series.length === 0 && (
              <div className="flex items-center justify-center py-12">
                  <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-moss-600"></div>
                  <span className="ml-3 text-gray-500">Carregando séries...</span>
              </div>
          )}

           <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-4 grid-search">
              <Input label="" placeholder="Pesquisar por Sigla ou Descrição..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} containerClassName="!mb-0" icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>} />
          </div>

          <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex-1 flex flex-col">
               <div className="overflow-x-auto grid-body-scroll">
                  <table className="min-w-full divide-y divide-gray-200 data-grid-typography">
                      <thead className="bg-gray-50">
                          <tr>
                              <TableHeader label="Sigla" sortKey="sigla" />
                              <TableHeader label="Descrição" sortKey="description" />
                              <TableHeader label="Nº Geral" sortKey="generalNumber" />
                              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th>
                          </tr>
                      </thead>
                      <tbody className="bg-white divide-y divide-gray-200">
                          {paginated.length === 0 && <tr><td colSpan={4} className="px-6 py-10 text-center text-gray-500">{loading ? 'Carregando...' : 'Nenhum registro encontrado.'}</td></tr>}
                          {paginated.map(s => (
                              <tr key={s.id} className="hover:bg-gray-50">
                                  <td className="px-6 py-4 whitespace-nowrap">
                                      <span className="font-bold text-moss-700">{s.sigla}</span>
                                  </td>
                                  <td className="px-6 py-4 text-sm text-gray-600">{s.description}</td>
                                  <td className="px-6 py-4 text-sm text-gray-600 font-mono font-bold">{s.generalNumber}</td>
                                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                      <div className="flex justify-end items-center gap-3">
                                          <AuditLogButton entityId={s.id} entityName={(s as any).name || s.sigla} logs={config.auditLogs || []} />
                                          {canAlterar && <button onClick={() => handleEditSeries(s)} className="text-indigo-600 hover:text-indigo-900">Editar</button>}
                                          {canIncluir && <button onClick={() => handleDuplicateSeries(s)} className="text-amber-600 hover:text-amber-800">Duplicar</button>}
                                          {canExcluir && <button onClick={() => handleDeleteSeries(s.id)} className="text-red-600 hover:text-red-900">Excluir</button>}
                                      </div>
                                  </td>
                              </tr>
                          ))}
                      </tbody>
                  </table>
              </div>
              <Pagination totalItems={sortedAndFiltered.length} itemsPerPage={itemsPerPage} currentPage={currentPage} onPageChange={setCurrentPage} onItemsPerPageChange={setItemsPerPage} />
          </div>
      </div>
  );
};

export default SeriesPanel;

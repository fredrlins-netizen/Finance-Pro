/**
 * TÍTULO: PAINEL DE GESTÃO DE CLIENTES
 * 
 * Funcionalidades:
 * - Listagem de clientes cadastrados.
 * - Formulário completo com 18 campos.
 * - Busca de endereço por CEP.
 * - Validação de Dígito Verificador (CPF/CNPJ).
 * - Controle de permissões (SecurityContext).
 * - Filtros Avançados e Paginação.
 * - Suporte a criação/edição automática e retorno de ID (Fluxo Admissão).
 */

import React, { useState, useRef, useMemo, useEffect, useCallback, lazy, Suspense } from 'react';
import { PortalConfig, Client, Admission } from '../../types';
import Button from '../ui/Button';
import Input from '../ui/Input';
import FormActions from '../ui/FormActions';
import PaginationBar from '../ui/PaginationBar';
import { useSecurity } from '../../contexts/SecurityContext';
import { useAudit } from '../../contexts/AuditContext';
import { checkDependencies, formatDependencyMessage } from '../../utils/dependencyCheck';
import AuditLogButton from '../ui/AuditLogButton';
import BlockClientModal from '../ui/BlockClientModal';
import BlockedClientBanner from '../ui/BlockedClientBanner';
import { useEntityCRUD } from '../../hooks/useEntityCRUD';
import { api } from '../../services/apiService';
import GotalkConversationsTab from '../gotalk/GotalkConversationsTab';
import GotalkPhoneLink from '../gotalk/GotalkPhoneLink';
import AdmissionViewerModal from '../ui/AdmissionViewerModal';
import ClientAttachmentsPanel from '../attachments/ClientAttachmentsPanel';

const ConversasPanel = lazy(() => import('../conversas/ConversasPanel'));

interface ClientsPanelProps {
  config: PortalConfig;
  autoStartCreate?: boolean;
  externalEditId?: string;
  onClientSelect?: (newClientId: string) => void;
  onCancelSubFlow?: () => void;
}

type SortDirection = 'asc' | 'desc' | null;
interface SortConfig {
    key: keyof Client | null;
    direction: SortDirection;
}

const ClientRow = React.memo<{
  client: Client;
  auditLogs: any[];
  onEdit: (client: Client) => void;
  onDuplicate: (client: Client) => void;
  onDelete: (id: string) => void;
  canEdit: boolean;
  canDelete: boolean;
}>(({ client, auditLogs, onEdit, onDuplicate, onDelete, canEdit, canDelete }) => (
  <tr className="operational-grid-row hover:bg-gray-50 transition-colors">
    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
      <div className="flex items-center gap-2">
        {client.name}
        {client.blocked && <BlockedClientBanner client={client} compact />}
      </div>
    </td>
    <td className="px-6 py-4 whitespace-nowrap text-center text-xs font-semibold">
      <span className="px-2 py-1 rounded-full bg-blue-50 text-blue-700">{client.natureza ?? 'C'}</span>
    </td>
    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{client.document}</td>
    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><GotalkPhoneLink phone={client.phone} name={client.name} /></td>
    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{client.city}/{client.state}</td>
    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
      <div className="flex justify-end items-center gap-3">
        <AuditLogButton entityId={client.id} entityName={client.name || (client as any).razaoSocial || client.id} logs={auditLogs} />
        {canEdit && <button onClick={() => onEdit(client)} className="text-indigo-600 hover:text-indigo-900">Editar</button>}
        {canEdit && <button onClick={() => onDuplicate(client)} className="text-amber-600 hover:text-amber-800">Duplicar</button>}
        {canDelete && <button onClick={() => onDelete(client.id)} className="text-red-600 hover:text-red-900">Excluir</button>}
      </div>
    </td>
  </tr>
));

interface OtherClient {
  clientId: string;
  clientName: string;
  role: string;
}

interface AdmissionLink {
  id: string;
  contract_number: string;
  date: string;
  status: string;
  role: string;
  other_client: OtherClient | null;
}

const STATUS_COLORS: Record<string, string> = {
  'PENDENTE': 'bg-yellow-100 text-yellow-800',
  'NEGOCIAÇÃO': 'bg-blue-100 text-blue-800',
  'APROVADA': 'bg-green-100 text-green-800',
  'ANÁLISE CLIENTE': 'bg-purple-100 text-purple-800',
  'REPROVADA': 'bg-red-100 text-red-800',
  'AUDITADA': 'bg-indigo-100 text-indigo-800',
  'FINALIZADA': 'bg-gray-100 text-gray-800',
  'CONCLUIDO': 'bg-emerald-100 text-emerald-800',
  'RETORNO AUDITORIA': 'bg-orange-100 text-orange-800',
};

const AdmissionLinksSection: React.FC<{ clientId: string }> = ({ clientId }) => {
  const [links, setLinks] = useState<AdmissionLink[]>([]);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(true);
  const [fetched, setFetched] = useState(false);
  const [fetchError, setFetchError] = useState(false);
  const [viewingAdmission, setViewingAdmission] = useState<Admission | null>(null);
  const [viewingLoading, setViewingLoading] = useState<string | null>(null);
  const [viewingError, setViewingError] = useState<string | null>(null);

  const handleViewAdmission = async (admissionId: string) => {
    if (!admissionId || viewingLoading) return;
    setViewingLoading(admissionId);
    setViewingError(null);
    try {
      const res = await fetch(`/api/admissions/${admissionId}`, { credentials: 'include' });
      if (res.status === 403) {
        setViewingError('Sem permissão de acesso para visualizar esta Ficha de Admissão.');
        return;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const json = await res.json();
      const data = json.data || json;
      setViewingAdmission(data as Admission);
    } catch {
      setViewingError('Não foi possível carregar a Ficha de Admissão. Tente novamente.');
    } finally {
      setViewingLoading(null);
    }
  };

  useEffect(() => {
    if (!clientId) return;
    setLoading(true);
    setFetched(false);
    setFetchError(false);
    api.get<{ data: AdmissionLink[] }>(`/api/clients/${clientId}/admission-links`)
      .then(json => {
        setLinks(json.data || []);
        setFetched(true);
      })
      .catch(() => {
        setLinks([]);
        setFetchError(true);
        setFetched(true);
      })
      .finally(() => setLoading(false));
  }, [clientId]);

  const formatDate = (iso: string) => {
    if (!iso) return '—';
    const d = iso.split('T')[0];
    const parts = d.split('-');
    if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
    return iso;
  };

  const roleLabel = (tipo: string | null) => {
    if (!tipo) return '—';
    if (tipo === 'RESPONSÁVEL') return 'Responsável';
    if (tipo === 'TITULAR') return 'Titular';
    return tipo;
  };

  return (
    <div className="mt-6 border border-gray-200 rounded-lg overflow-hidden">
      <button
        type="button"
        className="w-full flex items-center justify-between px-4 py-3 bg-gray-50 hover:bg-gray-100 transition-colors text-left"
        onClick={() => setExpanded(!expanded)}
      >
        <span className="text-sm font-bold text-gray-700 uppercase tracking-wide flex items-center gap-2">
          <svg className="w-4 h-4 text-gray-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
          </svg>
          Vínculos de Admissão
          {fetched && <span className="text-xs font-normal text-gray-400 ml-1">({links.length})</span>}
        </span>
        <svg className={`w-5 h-5 text-gray-400 transform transition-transform ${expanded ? 'rotate-180' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {expanded && (
        <div className="px-4 py-3 bg-white">
          {loading && (
            <p className="text-sm text-gray-400 py-2 text-center">Carregando vínculos...</p>
          )}
          {!loading && fetchError && (
            <p className="text-sm text-red-500 py-2 text-center">Erro ao carregar vínculos de admissão.</p>
          )}
          {!loading && !fetchError && fetched && links.length === 0 && (
            <p className="text-sm text-gray-400 py-2 text-center">Nenhuma admissão vinculada.</p>
          )}
          {viewingError && (
            <div className="mb-2 bg-red-50 border border-red-200 rounded-lg px-3 py-2 flex items-center gap-2 text-xs text-red-700">
              <svg className="w-4 h-4 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"/></svg>
              {viewingError}
              <button onClick={() => setViewingError(null)} className="ml-auto text-red-400 hover:text-red-600">✕</button>
            </div>
          )}
          {!loading && links.length > 0 && (
            <div className="overflow-x-auto">
              <table className="min-w-full text-sm operational-grid">
                <thead>
                  <tr className="border-b border-gray-100">
                    <th className="text-left py-2 px-2 text-xs font-medium text-gray-500 uppercase">Contrato</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-gray-500 uppercase">Data</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-gray-500 uppercase">Papel</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-gray-500 uppercase">Outro Vínculo</th>
                    <th className="text-left py-2 px-2 text-xs font-medium text-gray-500 uppercase">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-50">
                  {links.map(link => (
                    <tr key={link.id} className="hover:bg-gray-50 transition-colors">
                      <td className="py-2 px-2 font-mono text-gray-700">{link.contract_number || '—'}</td>
                      <td className="py-2 px-2 text-gray-600">{formatDate(link.date)}</td>
                      <td className="py-2 px-2">
                        <span className={`inline-block px-2 py-0.5 rounded text-xs font-bold ${link.role === 'TITULAR' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'}`}>
                          {roleLabel(link.role)}
                        </span>
                      </td>
                      <td className="py-2 px-2">
                        <span className={`inline-block px-2 py-0.5 rounded text-xs font-semibold ${STATUS_COLORS[link.status] || 'bg-gray-100 text-gray-700'}`}>
                          {link.status}
                        </span>
                      </td>
                      <td className="py-2 px-2 text-gray-600">
                        {link.other_client ? (
                          <span>
                            <span className="font-medium">{link.other_client.clientName}</span>
                            <span className="text-gray-400 text-xs ml-1">({roleLabel(link.other_client.role)})</span>
                          </span>
                        ) : (
                          <span className="text-gray-400">—</span>
                        )}
                      </td>
                      <td className="py-2 px-2">
                        <button
                          onClick={() => handleViewAdmission(link.id)}
                          disabled={viewingLoading === link.id}
                          className="inline-flex items-center gap-1 px-2.5 py-1 bg-moss-600 hover:bg-moss-700 disabled:bg-moss-300 text-white text-[10px] font-bold rounded-lg uppercase tracking-wider transition-colors"
                          title="Ver Ficha de Admissão completa"
                        >
                          {viewingLoading === link.id ? (
                            <><svg className="w-3 h-3 animate-spin" fill="none" viewBox="0 0 24 24"><circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/><path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z"/></svg>Abrindo...</>
                          ) : (
                            <><svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>Ver Ficha</>
                          )}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
          {viewingAdmission && (
            <AdmissionViewerModal
              admission={viewingAdmission}
              clientName={viewingAdmission.clientName || clientId}
              onClose={() => setViewingAdmission(null)}
            />
          )}
        </div>
      )}
    </div>
  );
};

const ClientsPanel: React.FC<ClientsPanelProps> = ({ 
    config, 
    autoStartCreate = false,
    externalEditId,
    onClientSelect,
    onCancelSubFlow
}) => {
  const { validarPermissao, temPermissao, addToast, currentUser, isLoggedAdmin } = useSecurity();
  const canIncluir = temPermissao('cad_clientes:INCLUIR');
  const canAlterar = temPermissao('cad_clientes:ALTERAR');
  const canExcluir = temPermissao('cad_clientes:EXCLUIR');
  const { logTransaction } = useAudit();

  const { data: clients, loading: apiLoading, error: apiError, create: apiCreate, update: apiUpdate, remove: apiRemove, refresh: apiRefresh, clearError: apiClearError, search: serverSearch, setFilters: serverSetFilters, currentPage: serverPage, totalPages: serverTotalPages, total: serverTotal, goToPage: serverGoToPage } = useEntityCRUD<Client>('clients', { pageSize: 50 });
  
  const [isEditing, setIsEditing] = useState(false);
  const [currentClient, setCurrentClient] = useState<Client | null>(null);
  const [originalClient, setOriginalClient] = useState<Client | null>(null);
  const [showBlockModal, setShowBlockModal] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  
  const [searchTerm, setSearchTerm] = useState('');
  const searchDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current);
    searchDebounceRef.current = setTimeout(() => { serverSearch(searchTerm); }, 300);
    return () => { if (searchDebounceRef.current) clearTimeout(searchDebounceRef.current); };
  }, [searchTerm]);
  const [showFilters, setShowFilters] = useState(false);
  const [filterType, setFilterType] = useState<string>('');
  const [filterDocument, setFilterDocument] = useState('');
  const [filterCity, setFilterCity] = useState('');
  const [filterState, setFilterState] = useState('');
  const colFilterDebounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (colFilterDebounceRef.current) clearTimeout(colFilterDebounceRef.current);
    colFilterDebounceRef.current = setTimeout(() => {
      const filters: Record<string, string | number> = {};
      if (filterType) filters.filter_type = filterType;
      if (filterState) filters.filter_state = filterState;
      if (filterCity) filters.filter_city_ilike = filterCity;
      serverSetFilters(filters);
    }, 300);
    return () => { if (colFilterDebounceRef.current) clearTimeout(colFilterDebounceRef.current); };
  }, [filterType, filterState, filterCity]);
  const [sortConfig, setSortConfig] = useState<SortConfig>({ key: null, direction: null });
  
  const [isLoadingCep, setIsLoadingCep] = useState(false);
  const [validationErrors, setValidationErrors] = useState<{ document?: string; email?: string }>({});

  const numeroRef = useRef<HTMLInputElement>(null);
  const enderecoRef = useRef<HTMLInputElement>(null);
  const [showMaritalModal, setShowMaritalModal] = useState(false);
  const [newMaritalOption, setNewMaritalOption] = useState('');
  const [activeTab, setActiveTab] = useState<'dados' | 'conversas' | 'documentos'>('dados');
  const [clientPendingDelete, setClientPendingDelete] = useState<Client | null>(null);
  const [deleteDocumentCount, setDeleteDocumentCount] = useState<number | null>(null);
  const [deleteTab, setDeleteTab] = useState<'dados' | 'documentos'>('documentos');
  const [whatsappLinked, setWhatsappLinked] = useState(false);
  const [conversationsRefreshKey, setConversationsRefreshKey] = useState(0);
  const [showConversasModal, setShowConversasModal] = useState(false);

  useEffect(() => {
      if (apiError) {
          addToast('error', 'Erro', apiError);
          apiClearError();
      }
  }, [apiError]);

  useEffect(() => {
      let active = true;
      if (autoStartCreate && !isEditing) {
          handleNewClient();
      } else if (externalEditId && !isEditing) {
          const client = clients.find(c => c.id === externalEditId);
          if (client) handleEditClient(client);
          else api.get<{ data: Client }>(`/api/clients/${externalEditId}`).then(result => {
              if (active) handleEditClient(result.data);
          }).catch(error => {
              if (active) addToast('error', 'Cliente', error.message || 'Não foi possível carregar o cadastro');
          });
      }
      return () => { active = false; };
  }, [autoStartCreate, externalEditId, clients, isEditing]);

  useEffect(() => {
      if (isEditing && originalClient?.id) {
          fetch(`/api/gotalk/client/${originalClient.id}`)
              .then(r => r.ok ? r.json() : null)
              .then(d => setWhatsappLinked(!!(d?.linked)))
              .catch(() => setWhatsappLinked(false));
      } else {
          setWhatsappLinked(false);
      }
  }, [isEditing, originalClient?.id]);

  // --- UTILS ---
  const validateCPF = (cpf: string): boolean => {
    cpf = cpf.replace(/[^\d]+/g, '');
    if (cpf === '' || cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;
    let add = 0;
    for (let i = 0; i < 9; i++) add += parseInt(cpf.charAt(i)) * (10 - i);
    let rev = 11 - (add % 11);
    if (rev === 10 || rev === 11) rev = 0;
    if (rev !== parseInt(cpf.charAt(9))) return false;
    add = 0;
    for (let i = 0; i < 10; i++) add += parseInt(cpf.charAt(i)) * (11 - i);
    rev = 11 - (add % 11);
    if (rev === 10 || rev === 11) rev = 0;
    if (rev !== parseInt(cpf.charAt(10))) return false;
    return true;
  };

  const validateCNPJ = (cnpj: string): boolean => {
    cnpj = cnpj.replace(/[^\d]+/g, '');
    if (cnpj === '' || cnpj.length !== 14 || /^(\d)\1+$/.test(cnpj)) return false;
    let size = cnpj.length - 2;
    let numbers = cnpj.substring(0, size);
    const digits = cnpj.substring(size);
    let sum = 0;
    let pos = size - 7;
    for (let i = size; i >= 1; i--) {
      sum += parseInt(numbers.charAt(size - i)) * pos--;
      if (pos < 2) pos = 9;
    }
    let result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
    if (result !== parseInt(digits.charAt(0))) return false;
    size = size + 1;
    numbers = cnpj.substring(0, size);
    sum = 0;
    pos = size - 7;
    for (let i = size; i >= 1; i--) {
      sum += parseInt(numbers.charAt(size - i)) * pos--;
      if (pos < 2) pos = 9;
    }
    result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
    if (result !== parseInt(digits.charAt(1))) return false;
    return true;
  };

  const validateEmailFormat = (email: string): boolean => {
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return re.test(email);
  };

  const formatPhone = (value: string) => {
      let r = value.replace(/\D/g, "");
      r = r.substring(0, 11);
      if (r.length > 10) r = r.replace(/^(\d\d)(\d{5})(\d{4}).*/, "($1) $2-$3");
      else if (r.length > 5) r = r.replace(/^(\d\d)(\d{4})(\d{0,4}).*/, "($1) $2-$3");
      else if (r.length > 2) r = r.replace(/^(\d\d)(\d{0,5})/, "($1) $2");
      else r = r.replace(/^(\d*)/, "($1");
      return r;
  };

  const formatCEP = (value: string) => {
      let r = value.replace(/\D/g, "");
      r = r.substring(0, 8);
      if (r.length > 5) r = r.replace(/^(\d{5})(\d{1,3}).*/, "$1-$2");
      return r;
  };

  const formatDateMask = (value: string): string => {
      let d = value.replace(/\D/g, '').substring(0, 8);
      if (d.length > 4) d = d.replace(/^(\d{2})(\d{2})(\d{0,4})/, '$1/$2/$3');
      else if (d.length > 2) d = d.replace(/^(\d{2})(\d{0,2})/, '$1/$2');
      return d;
  };

  const isoToBR = (iso: string): string => {
      if (!iso) return '';
      const dateOnly = iso.split('T')[0];
      const parts = dateOnly.split('-');
      if (parts.length === 3) return `${parts[2]}/${parts[1]}/${parts[0]}`;
      return iso;
  };

  const brToISO = (br: string): string => {
      if (!br) return '';
      const parts = br.split('/');
      if (parts.length === 3 && parts[2].length === 4) return `${parts[2]}-${parts[1]}-${parts[0]}`;
      return '';
  };

  const formatDocument = (value: string, type: 'FISICA' | 'JURIDICA') => {
      let r = value.replace(/\D/g, "");
      if (type === 'FISICA') {
          r = r.substring(0, 11);
          r = r.replace(/(\d{3})(\d)/, "$1.$2");
          r = r.replace(/(\d{3})(\d)/, "$1.$2");
          r = r.replace(/(\d{3})(\d{1,2})$/, "$1-$2");
      } else {
          r = r.substring(0, 14);
          r = r.replace(/^(\d{2})(\d)/, "$1.$2");
          r = r.replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3");
          r = r.replace(/\.(\d{3})(\d)/, ".$1/$2");
          r = r.replace(/(\d{4})(\d)/, "$1-$2");
      }
      return r;
  };

  const handleDocumentChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (!currentClient) return;
      const rawValue = e.target.value;
      const formattedValue = formatDocument(rawValue, currentClient.type);
      setCurrentClient({ ...currentClient, document: formattedValue });
      const cleanValue = formattedValue.replace(/\D/g, '');
      const isComplete = currentClient.type === 'FISICA' ? cleanValue.length === 11 : cleanValue.length === 14;
      if (isComplete) {
          const isValid = currentClient.type === 'FISICA' ? validateCPF(cleanValue) : validateCNPJ(cleanValue);
          setValidationErrors(prev => ({ ...prev, document: isValid ? undefined : `${currentClient.type === 'FISICA' ? 'CPF' : 'CNPJ'} inválido.` }));
      } else {
          setValidationErrors(prev => ({ ...prev, document: undefined }));
      }
  };

  const handleEmailChange = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (!currentClient) return;
      const value = e.target.value.toLowerCase().replace(/\s/g, '');
      setCurrentClient({ ...currentClient, email: value });
      if (value && !validateEmailFormat(value)) setValidationErrors(prev => ({ ...prev, email: 'Formato de e-mail inválido.' }));
      else setValidationErrors(prev => ({ ...prev, email: undefined }));
  };

  const handleEnterPress = (e: React.KeyboardEvent<HTMLElement>) => {
    if (e.key === 'Enter') {
        e.preventDefault(); 
        const form = e.currentTarget.closest('div[data-form-container="true"]');
        if (!form) return;
        const focusableElements = form.querySelectorAll<HTMLElement>('input:not([disabled]):not([type="hidden"]):not([readonly]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]):not([type="submit"])');
        const focusableArray = Array.from(focusableElements) as HTMLElement[];
        const index = focusableArray.indexOf(e.currentTarget as HTMLElement);
        if (index > -1 && index < focusableArray.length - 1) focusableArray[index + 1].focus();
    }
  };

  const handleCepSearch = async () => {
    if (!currentClient?.cep) return;
    const cep = currentClient.cep.replace(/\D/g, '');
    if (cep.length === 8) {
        setIsLoadingCep(true);
        try {
            const r = await fetch(`/api/cep/${cep}`);
            const d = await r.json();
            if (!d.erro) {
                const n = { address: d.logradouro || '', district: d.bairro || '', city: d.localidade || '', state: d.uf || '', complement: currentClient.complement || d.complemento || '' };
                setCurrentClient(prev => prev ? ({...prev, ...n}) : null);
                setTimeout(() => { if (d.logradouro) numeroRef.current?.focus(); else enderecoRef.current?.focus(); }, 100);
            } else addToast('warning', 'Atenção', 'CEP não encontrado.');
        } catch { addToast('error', 'Erro', 'Erro de conexão ao buscar CEP.'); } finally { setIsLoadingCep(false); }
    } else addToast('warning', 'Atenção', 'CEP inválido.');
  };

  // --- CRUD ACTIONS ---

  const handleNewClient = () => {
    if (!validarPermissao('cad_clientes:INCLUIR')) return;
    const maxId = clients.reduce((max, c) => Math.max(max, parseInt(c.id) || 0), 1000);
    const newClientObj = {
        id: (maxId + 1).toString(), name: '', type: 'FISICA' as const, document: '', rg: '', phone: '', phone2: '', isWhatsapp: false, email: '', profession: '', maritalStatus: '', birthDate: '', cep: '', address: '', number: '', complement: '', district: '', city: '', state: '', notes: '', natureza: 'C' as const
    };
    setCurrentClient(newClientObj);
    setOriginalClient(null); 
    setValidationErrors({});
    setActiveTab('dados');
    setIsEditing(true);
  };

  const handleEditClient = (client: Client) => {
    if (!validarPermissao('cad_clientes:ALTERAR')) return;
    setCurrentClient({ ...client, birthDate: isoToBR(client.birthDate || ''), phone: formatPhone(client.phone || ''), phone2: formatPhone(client.phone2 || '') });
    setOriginalClient({ ...client });
    setValidationErrors({});
    setActiveTab('dados');
    setConversationsRefreshKey(0);
    setIsEditing(true);
  };

  const handleDuplicateClient = (client: Client) => {
    if (!validarPermissao('cad_clientes:INCLUIR')) return;
    const maxId = clients.reduce((max, c) => Math.max(max, parseInt(c.id) || 0), 1000);
    setCurrentClient({ ...client, id: (maxId + 1).toString(), name: 'Cópia de ' + client.name, document: '', birthDate: isoToBR(client.birthDate || ''), phone: formatPhone(client.phone || ''), phone2: formatPhone(client.phone2 || ''), natureza: 'C' });
    setOriginalClient(null);
    setValidationErrors({});
    setActiveTab('dados');
    setIsEditing(true);
  };

  const handleDeleteClient = async (id: string) => {
    if (!validarPermissao('cad_clientes:EXCLUIR')) return;
    const result = checkDependencies('client', id, config);
    if (!result.canDelete) {
        const clientName = clients.find(c => c.id === id)?.name || id;
        addToast('warning', 'Exclusão Bloqueada', formatDependencyMessage(`o cliente "${clientName}"`, result.dependencies));
        return;
    }
    const clientToDelete = clients.find(c => c.id === id);
    if (clientToDelete) {
      setDeleteDocumentCount(null);
      setClientPendingDelete(clientToDelete);
      setDeleteTab('documentos');
    }
  };

  const confirmDeleteClient = async () => {
    if (!clientPendingDelete || deleteDocumentCount !== 0) return;
    try {
      await apiRemove(clientPendingDelete.id);
      logTransaction('CLIENTE', clientPendingDelete.id, clientPendingDelete, null);
      addToast('success', 'Sucesso', 'Cliente excluído.');
      setClientPendingDelete(null);
    } catch (error) {
      addToast('error', 'Exclusão bloqueada', (error as Error)?.message || 'Não foi possível excluir o cliente.');
    }
  };

  const handleSave = async (keepOpen = false) => {
      if (validationErrors.document || validationErrors.email) {
          addToast('error', 'Validação', 'Corrija os campos inválidos antes de salvar.');
          return;
      }
      const strippedPhone = (currentClient?.phone || '').replace(/\D/g, '');
      if (!currentClient?.name || strippedPhone.length < 10) {
          addToast('warning', 'Validação', 'Nome e Telefone são obrigatórios.');
          return;
      }
      
      setIsSaving(true);
      try {
          const isNew = !originalClient;
          let savedClient: Client;

          const stripPhone = (v: string | undefined) => v ? v.replace(/\D/g, '') : '';
          const originalPhone = stripPhone(originalClient?.phone || '');
          const newPhone = strippedPhone;

          const payload = {
              ...currentClient,
              phone: newPhone,
              phone2: stripPhone(currentClient.phone2 || ''),
              birthDate: brToISO(currentClient.birthDate || '') || null,
          };

          if (isNew) {
              savedClient = await apiCreate(payload);
          } else {
              savedClient = await apiUpdate(payload.id, payload);
          }

          logTransaction('CLIENTE', savedClient.id, originalClient, savedClient);
          setIsEditing(keepOpen);

          // When phone was set or changed, auto-sync GoTalk conversations in background
          const phoneChanged = newPhone && (isNew || newPhone !== originalPhone);
          if (phoneChanged && savedClient.id) {
              addToast('info', 'WhatsApp', 'Sincronizando conversas do número informado...');
              fetch('/api/gotalk/sync-by-phone', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify({ phone: newPhone, clientId: savedClient.id }),
              })
                  .then(r => r.json())
                  .then(d => {
                      if (d.saved > 0) {
                          addToast('success', 'WhatsApp', `${d.saved} mensagem(ns) importada(s) para este cliente.`);
                      }
                      setConversationsRefreshKey(k => k + 1);
                  })
                  .catch(() => {});
          }
      
          if (onClientSelect && !keepOpen) {
              onClientSelect(savedClient.id);
              return;
          }

          if (keepOpen) {
            setCurrentClient({ ...savedClient, birthDate: isoToBR(savedClient.birthDate || ''), phone: formatPhone(savedClient.phone || ''), phone2: formatPhone(savedClient.phone2 || '') });
            setOriginalClient({ ...savedClient });
            setActiveTab('documentos');
          } else {
            setCurrentClient(null);
            setOriginalClient(null);
          }
          addToast('success', 'Sucesso', 'Cliente salvo com sucesso.');
      } catch {
          addToast('error', 'Erro', 'Erro ao salvar cliente.');
      } finally {
          setIsSaving(false);
      }
  };

  const handleCancel = () => {
      setIsEditing(false);
      setCurrentClient(null);
      setOriginalClient(null);
      
      // Se estiver em modo de sub-fluxo (Admissão), dispara o cancelamento para fechar a tela
      if (onCancelSubFlow) {
          onCancelSubFlow();
      }
  };

  const handleApplyBlock = async (status: 'BLOQUEADO' | 'SUSPENSO', reason: string) => {
      if (!currentClient) return;
      const blockedClient: Client = {
          ...currentClient,
          blocked: true,
          blockStatus: status,
          blockReason: reason,
          blockedAt: new Date().toISOString(),
          blockedBy: currentUser?.name || currentUser?.email || 'Usuário',
      };
      try {
          await apiUpdate(blockedClient.id, blockedClient);
          logTransaction('CLIENTE_BLOQUEIO', blockedClient.id, currentClient, blockedClient);
          setCurrentClient(blockedClient);
          setShowBlockModal(false);
          addToast('warning', 'Restrição Aplicada', `Cliente ${blockedClient.name} foi ${status === 'BLOQUEADO' ? 'bloqueado' : 'suspenso'}.`);
      } catch {
          addToast('error', 'Erro', 'Erro ao aplicar restrição.');
      }
  };

  const handleRemoveBlock = async () => {
      if (!currentClient) return;
      const unblocked: Client = {
          ...currentClient,
          blocked: false,
          blockStatus: undefined,
          blockReason: undefined,
          blockedAt: undefined,
          blockedBy: undefined,
      };
      try {
          await apiUpdate(unblocked.id, unblocked);
          logTransaction('CLIENTE_DESBLOQUEIO', unblocked.id, currentClient, unblocked);
          setCurrentClient(unblocked);
          setShowBlockModal(false);
          addToast('success', 'Restrição Removida', `Cliente ${unblocked.name} foi desbloqueado.`);
      } catch {
          addToast('error', 'Erro', 'Erro ao remover restrição.');
      }
  };

  const handleSort = (key: keyof Client) => {
      let direction: SortDirection = 'asc';
      if (sortConfig.key === key && sortConfig.direction === 'asc') direction = 'desc';
      else if (sortConfig.key === key && sortConfig.direction === 'desc') direction = null;
      setSortConfig({ key: direction ? key : null, direction });
  };


  const sortedAndFilteredClients = useMemo(() => {
      let data = clients || [];
      data = data.filter(c => c.natureza === 'C' || !c.natureza);
      data = data.filter(c => {
          const matchesDocument = filterDocument ? c.document?.includes(filterDocument) : true;
          return matchesDocument;
      });
      if (sortConfig.key && sortConfig.direction) {
          data = [...data].sort((a, b) => {
              const valA = a[sortConfig.key!]?.toString().toLowerCase() || '';
              const valB = b[sortConfig.key!]?.toString().toLowerCase() || '';
              if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
              if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
              return 0;
          });
      }
      return data;
  }, [clients, filterDocument, sortConfig]);

  const paginatedClients = sortedAndFilteredClients;

  const renderSortIcon = (key: keyof Client) => {
      if (sortConfig.key !== key) return <span className="text-gray-300 ml-1">⇅</span>;
      return sortConfig.direction === 'asc' ? <span className="text-moss-600 ml-1">↑</span> : <span className="text-moss-600 ml-1">↓</span>;
  };

  const TableHeader = ({ label, sortKey, align = 'left' }: { label: string, sortKey: keyof Client, align?: string }) => (
      <th className={`px-6 py-3 text-${align} text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer hover:bg-gray-100 select-none`} onClick={() => handleSort(sortKey)}>
          <div className={`flex items-center ${align === 'right' ? 'justify-end' : 'justify-start'}`}>{label}{renderSortIcon(sortKey)}</div>
      </th>
  );

  const handleAddMaritalOption = () => { if (!newMaritalOption.trim()) return; const options = config.maritalStatusOptions || []; if (!options.includes(newMaritalOption)) { const updated = [...options, newMaritalOption]; fetch('/api/settings/section', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: 'maritalStatusOptions', value: updated }) }).catch(() => {}); setNewMaritalOption(''); } };
  const handleRemoveMaritalOption = (option: string) => { const options = (config.maritalStatusOptions || []).filter(o => o !== option); fetch('/api/settings/section', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key: 'maritalStatusOptions', value: options }) }).catch(() => {}); };

  const handleEditClientCb = useCallback((client: Client) => { handleEditClient(client); }, [clients]);
  const handleDuplicateClientCb = useCallback((client: Client) => { handleDuplicateClient(client); }, [clients]);
  const handleDeleteClientCb = useCallback((id: string) => { handleDeleteClient(id); }, [clients]);

  if (isEditing && currentClient) {
      return (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 animate-fade-in" data-form-container="true">
             <div className="flex justify-between items-center mb-4 pb-4 border-b">
                <div className="flex items-center gap-3">
                    <button
                        type="button"
                        onClick={handleCancel}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium text-gray-600 border border-gray-300 bg-white hover:bg-gray-50 transition-colors"
                    >
                        <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                        </svg>
                        Voltar
                    </button>
                    <h3 className="text-xl font-bold text-gray-800 flex items-center gap-2">
                        {originalClient ? 'Editando Cliente' : 'Novo Cliente'}
                        {currentClient.blocked && <BlockedClientBanner client={currentClient} compact />}
                    </h3>
                    {originalClient && whatsappLinked && (
                        <span className="flex items-center gap-1.5 text-xs font-semibold text-green-700 bg-green-50 border border-green-200 px-2.5 py-1 rounded-full">
                            <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                                <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                            </svg>
                            WhatsApp Vinculado
                        </span>
                    )}
                </div>
                <div className="flex items-center gap-2">
                    {onClientSelect && <span className="text-sm font-bold text-blue-600 bg-blue-50 px-2 py-1 rounded">Modo de Admissão</span>}
                    {originalClient && (
                        <button
                            onClick={() => setShowBlockModal(true)}
                            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold border transition-colors ${
                                currentClient.blocked
                                    ? 'border-red-300 text-red-700 bg-red-50 hover:bg-red-100'
                                    : 'border-gray-300 text-gray-600 bg-white hover:bg-gray-50'
                            }`}
                        >
                            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                            </svg>
                            {currentClient.blocked ? 'Gerenciar Restrição' : 'Bloquear / Suspender'}
                        </button>
                    )}
                </div>
             </div>

             {isEditing && (
               <div className="flex border-b border-gray-200 mb-5 -mt-1">
                 <button
                   type="button"
                   onClick={() => setActiveTab('dados')}
                   className={`px-5 py-2.5 text-sm font-semibold border-b-2 transition-colors focus:outline-none ${
                     activeTab === 'dados'
                       ? 'border-indigo-600 text-indigo-600'
                       : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                   }`}
                 >
                   Dados do Cliente
                 </button>
                  {originalClient && <button
                    type="button"
                    onClick={() => setActiveTab('conversas')}
                    className={`flex items-center gap-1.5 px-5 py-2.5 text-sm font-semibold border-b-2 transition-colors focus:outline-none ${
                      activeTab === 'conversas'
                        ? 'border-green-600 text-green-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                    </svg>
                    Conversas WhatsApp
                  </button>}
                  <button
                    type="button"
                    onClick={() => setActiveTab('documentos')}
                    className={`px-5 py-2.5 text-sm font-semibold border-b-2 transition-colors focus:outline-none ${
                      activeTab === 'documentos'
                        ? 'border-emerald-600 text-emerald-700'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    Documentos
                  </button>
               </div>
             )}

             {currentClient.blocked && <BlockedClientBanner client={currentClient} />}

             {activeTab === 'dados' && (
               <>
                 <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="md:col-span-1"><Input label="Cód." value={currentClient.id} disabled className="bg-gray-100 text-center font-bold" onKeyDown={handleEnterPress}/></div>
                    <div className="md:col-span-3 flex flex-col justify-end pb-5">
                        <span className="text-sm font-medium text-gray-700 mb-2 block">01. Natureza</span>
                        <div className="flex gap-4">
                            <label className="flex items-center space-x-2 cursor-pointer"><input type="radio" name="type" checked={currentClient.type === 'FISICA'} onChange={() => { setCurrentClient({...currentClient, type: 'FISICA', document: ''}); setValidationErrors(prev => ({...prev, document: undefined})); }} onKeyDown={handleEnterPress} className="h-4 w-4 text-moss-600 focus:ring-moss-500"/><span>Física (CPF)</span></label>
                            <label className="flex items-center space-x-2 cursor-pointer"><input type="radio" name="type" checked={currentClient.type === 'JURIDICA'} onChange={() => { setCurrentClient({...currentClient, type: 'JURIDICA', document: '', rg: '', birthDate: ''}); setValidationErrors(prev => ({...prev, document: undefined})); }} onKeyDown={handleEnterPress} className="h-4 w-4 text-moss-600 focus:ring-moss-500"/><span>Jurídica (CNPJ)</span></label>
                        </div>
                    </div>
                    <div className="md:col-span-4"><Input label="02. Descrição (Nome / Razão Social)" value={currentClient.name} onChange={e => setCurrentClient({...currentClient, name: e.target.value})} onKeyDown={handleEnterPress} className="text-left" /></div>
                    <div className="md:col-span-2"><Input label={`03. ${currentClient.type === 'FISICA' ? 'CPF' : 'CNPJ'}`} value={currentClient.document} onChange={handleDocumentChange} onKeyDown={handleEnterPress} placeholder={currentClient.type === 'FISICA' ? '000.000.000-00' : '000.000.000/0000-00'} error={validationErrors.document} maxLength={currentClient.type === 'FISICA' ? 14 : 18}/></div>
                    <div className="md:col-span-2"><Input label="04. RG" value={currentClient.rg || ''} onChange={e => setCurrentClient({...currentClient, rg: e.target.value})} onKeyDown={handleEnterPress} disabled={currentClient.type === 'JURIDICA'} className={currentClient.type === 'JURIDICA' ? 'bg-gray-100' : ''}/></div>
                    <div className="md:col-span-2"><div className="flex gap-2 items-end"><div className="flex-1"><Input label="05. Telefone *" value={currentClient.phone} onChange={e => setCurrentClient({...currentClient, phone: formatPhone(e.target.value)})} onKeyDown={handleEnterPress} placeholder="(00) 00000-0000" maxLength={15} containerClassName="!mb-0"/></div><label className="flex items-center justify-center border border-gray-300 rounded-lg h-[50px] px-3 mb-[1px] cursor-pointer bg-white hover:bg-gray-50 transition-colors" title="06. Whatsapp"><input type="checkbox" className="h-4 w-4 text-green-600 focus:ring-green-500 rounded mr-2" checked={currentClient.isWhatsapp || false} onChange={e => setCurrentClient({...currentClient, isWhatsapp: e.target.checked})} onKeyDown={handleEnterPress}/><span className="text-xs font-bold text-green-700">06. Zap</span></label></div></div>
                    <div className="md:col-span-2"><Input label="07. Telefone 02" value={currentClient.phone2 || ''} onChange={e => setCurrentClient({...currentClient, phone2: formatPhone(e.target.value)})} onKeyDown={handleEnterPress} placeholder="(00) 00000-0000" maxLength={15}/></div>
                    <div className="md:col-span-2"><label className="block text-sm font-medium text-gray-700 mb-1">08. Estado Civil</label><div className="flex gap-2"><select className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-moss-500 focus:border-moss-500 outline-none bg-white h-[50px]" value={currentClient.maritalStatus || ''} onChange={e => setCurrentClient({...currentClient, maritalStatus: e.target.value})} onKeyDown={handleEnterPress}><option value="">Selecione...</option>{(config.maritalStatusOptions || []).map(opt => (<option key={opt} value={opt}>{opt}</option>))}</select><Button variant="secondary" className="!w-12 !h-[50px] !mb-0 !px-0" title="Gerenciar Opções" onClick={() => setShowMaritalModal(true)}>⚙️</Button></div></div>
                    <div className="md:col-span-2"><Input label="09. Data de Nascimento" type="text" placeholder="DD/MM/AAAA" maxLength={10} value={currentClient.birthDate || ''} onChange={e => setCurrentClient({...currentClient, birthDate: formatDateMask(e.target.value)})} onKeyDown={handleEnterPress}/></div>
                    <div className="md:col-span-2"><Input label="E-mail" type="email" value={currentClient.email || ''} onChange={handleEmailChange} onKeyDown={handleEnterPress} placeholder="email@exemplo.com" error={validationErrors.email}/></div>
                    <div className="md:col-span-2"><Input label="Profissão" value={currentClient.profession || ''} onChange={e => setCurrentClient({...currentClient, profession: e.target.value})} onKeyDown={handleEnterPress}/></div>
                    <div className="md:col-span-4 mt-2 mb-2 border-b border-gray-100 pb-2"><h4 className="text-sm font-bold text-gray-500 uppercase">Endereço & Localização</h4></div>
                    <div className="md:col-span-2"><div className="flex items-end gap-2"><Input label="10. CEP" containerClassName="flex-1 !mb-0" value={currentClient.cep} onChange={e => setCurrentClient({...currentClient, cep: formatCEP(e.target.value)})} onKeyDown={handleEnterPress} maxLength={9} placeholder="00000-000"/><Button className="!w-12 !h-[50px] !mb-[1px]" onClick={handleCepSearch} isLoading={isLoadingCep} title="Buscar CEP">🔎</Button></div></div>
                    <div className="md:col-span-2"><Input label="11. Endereço" value={currentClient.address} ref={enderecoRef} onChange={e => setCurrentClient({...currentClient, address: e.target.value})} onKeyDown={handleEnterPress}/></div>
                    <div className="md:col-span-1"><Input label="12. Número" value={currentClient.number} ref={numeroRef} onChange={e => setCurrentClient({...currentClient, number: e.target.value})} onKeyDown={handleEnterPress}/></div>
                    <div className="md:col-span-1"><Input label="13. Complemento" value={currentClient.complement} onChange={e => setCurrentClient({...currentClient, complement: e.target.value})} onKeyDown={handleEnterPress}/></div>
                    <div className="md:col-span-2"><Input label="14. Bairro" value={currentClient.district} onChange={e => setCurrentClient({...currentClient, district: e.target.value})} onKeyDown={handleEnterPress}/></div>
                    <div className="md:col-span-3"><Input label="15. Cidade" value={currentClient.city} onChange={e => setCurrentClient({...currentClient, city: e.target.value})} onKeyDown={handleEnterPress}/></div>
                    <div className="md:col-span-1"><Input label="16. Estado" value={currentClient.state} onChange={e => setCurrentClient({...currentClient, state: e.target.value})} onKeyDown={handleEnterPress} maxLength={2}/></div>
                    <div className="md:col-span-4"><label className="block text-sm font-medium text-gray-700 mb-1">17. Anotações</label><textarea className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-moss-500 outline-none" rows={3} value={currentClient.notes || ''} onChange={(e) => setCurrentClient({...currentClient, notes: e.target.value})} /></div>
                 </div>

                 {originalClient && <AdmissionLinksSection clientId={currentClient.id} />}

                 <FormActions
                    onSave={() => handleSave()}
                    onCancel={handleCancel}
                 />
               </>
             )}

             {activeTab === 'conversas' && originalClient && (
               <>
                 {currentClient.phone && (
                   <div className="mb-3 flex justify-end">
                     <button
                       type="button"
                       onClick={() => setShowConversasModal(true)}
                       className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-teal-700 bg-teal-50 border border-teal-200 rounded-lg hover:bg-teal-100 transition-colors"
                     >
                       <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
                       Ver painel unificado (GoTalk + uazapi)
                     </button>
                   </div>
                 )}

                 <GotalkConversationsTab key={conversationsRefreshKey} clientId={currentClient.id} />
                 <div className="mt-4 flex justify-end">
                   <button
                     type="button"
                     onClick={handleCancel}
                     className="px-4 py-2 text-sm font-medium text-gray-600 border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                   >
                     Fechar
                   </button>
                 </div>
               </>
             )}

             {activeTab === 'documentos' && originalClient && (
               <div className="mb-5">
                 <ClientAttachmentsPanel clientId={currentClient.id} compact allowUpload={temPermissao('cad_clientes:ALTERAR')} />
               </div>
             )}
             {!originalClient && activeTab === 'documentos' && (
               <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-900">
                 Salve o cadastro do cliente primeiro para criar a pasta e liberar o vínculo dos documentos.
                 <div className="mt-3">
                   <button type="button" disabled={isSaving} onClick={() => handleSave(true)} className="rounded-lg bg-emerald-700 px-4 py-2 font-semibold text-white disabled:opacity-50">
                     {isSaving ? 'Salvando…' : 'Salvar cliente e continuar'}
                   </button>
                 </div>
               </div>
             )}
             {showConversasModal && (
               <div className="fixed inset-0 z-50 bg-white flex flex-col">
                 <div className="flex items-center justify-between px-4 py-3 border-b border-gray-200 bg-white shadow-sm flex-shrink-0">
                   <div>
                     <h2 className="text-base font-semibold text-gray-800">Conversas WhatsApp</h2>
                     <p className="text-xs text-gray-500">{currentClient.name} — {currentClient.phone}</p>
                   </div>
                   <button
                     type="button"
                     onClick={() => setShowConversasModal(false)}
                     className="p-2 text-gray-400 hover:text-gray-600 hover:bg-gray-100 rounded-lg transition-colors"
                     title="Fechar"
                   >
                     <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                   </button>
                 </div>
                 <div className="flex-1 overflow-hidden">
                   <Suspense fallback={<div className="flex items-center justify-center h-full text-gray-400 text-sm">Carregando...</div>}>
                     <ConversasPanel
                       defaultPhone={currentClient.phone.replace(/\D/g, '')}
                       defaultClientId={currentClient.id}
                     />
                   </Suspense>
                 </div>
               </div>
             )}

             {showMaritalModal && (
                 <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 animate-fade-in">
                     <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-md">
                         <h3 className="text-lg font-bold text-gray-800 mb-4">Gerenciar Estados Civis</h3>
                         <div className="flex gap-2 mb-4"><Input label="" placeholder="Novo Estado Civil" value={newMaritalOption} onChange={e => setNewMaritalOption(e.target.value)} containerClassName="flex-1 !mb-0"/><Button className="!w-auto" onClick={handleAddMaritalOption}>Adicionar</Button></div>
                         <div className="max-h-60 overflow-y-auto border rounded-lg divide-y">{(config.maritalStatusOptions || []).map(opt => (<div key={opt} className="p-3 flex justify-between items-center hover:bg-gray-50"><span>{opt}</span><button onClick={() => handleRemoveMaritalOption(opt)} className="text-red-500 hover:text-red-700"><svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg></button></div>))}</div>
                         <div className="flex justify-end mt-4"><Button variant="outline" onClick={() => setShowMaritalModal(false)}>Fechar</Button></div>
                     </div>
                 </div>
             )}

             <BlockClientModal
                 client={currentClient}
                 isOpen={showBlockModal}
                 onClose={() => setShowBlockModal(false)}
                 onConfirm={handleApplyBlock}
                 onUnblock={handleRemoveBlock}
                 currentUserName={currentUser?.name || currentUser?.email || 'Usuário'}
                 canUnblock={isLoggedAdmin}
             />
        </div>
      );
  }

  return (
    <div className="flex flex-col h-full animate-fade-in" data-grid-density="compact">
        {clientPendingDelete && (
          <div className="fixed inset-0 z-[1000] flex items-center justify-center bg-black/50 p-4" role="presentation" onMouseDown={event => {
            if (event.target === event.currentTarget) {
              setClientPendingDelete(null);
              setDeleteDocumentCount(null);
            }
          }}>
            <section role="dialog" aria-modal="true" aria-labelledby="client-delete-title" className="w-full max-w-3xl max-h-[90vh] overflow-y-auto rounded-xl bg-white p-5 shadow-2xl">
              <h3 id="client-delete-title" className="text-lg font-bold text-slate-900">Excluir cliente</h3>
              <p className="mt-1 text-sm text-slate-600">
                Confira os documentos de <strong>{clientPendingDelete.name}</strong>. A exclusão ficará bloqueada enquanto houver arquivos vinculados; os documentos não serão removidos automaticamente.
              </p>
              <div role="tablist" aria-label="Consulta antes da exclusão" className="mt-4 flex gap-4 border-b">
                <button type="button" role="tab" aria-selected={deleteTab === 'dados'} onClick={() => setDeleteTab('dados')} className="px-2 py-2 font-semibold">Dados do Cliente</button>
                <button type="button" role="tab" aria-selected={deleteTab === 'documentos'} onClick={() => setDeleteTab('documentos')} className="px-2 py-2 font-semibold">Documentos</button>
              </div>
              {deleteTab === 'dados' && (
                <dl className="mt-4 grid grid-cols-1 gap-3 text-sm sm:grid-cols-2">
                  <div><dt className="font-semibold">Nome</dt><dd>{clientPendingDelete.name}</dd></div>
                  <div><dt className="font-semibold">CPF / CNPJ</dt><dd>{clientPendingDelete.document || 'Não informado'}</dd></div>
                  <div><dt className="font-semibold">Telefone</dt><dd>{clientPendingDelete.phone || 'Não informado'}</dd></div>
                  <div><dt className="font-semibold">E-mail</dt><dd>{clientPendingDelete.email || 'Não informado'}</dd></div>
                </dl>
              )}
              <div className="mt-4" hidden={deleteTab !== 'documentos'}>
                <ClientAttachmentsPanel
                  clientId={clientPendingDelete.id}
                  compact
                  readOnly
                  onCountChange={setDeleteDocumentCount}
                />
              </div>
              {deleteDocumentCount === null && (
                <p className="mt-3 text-sm text-slate-500">Aguardando a verificação dos documentos e das permissões…</p>
              )}
              {deleteDocumentCount !== null && deleteDocumentCount > 0 && (
                <p className="mt-3 rounded-lg border border-amber-200 bg-amber-50 p-3 text-sm text-amber-900">
                  Exclusão bloqueada: resolva os {deleteDocumentCount} documento(s) vinculado(s) antes de excluir o cadastro.
                </p>
              )}
              <div className="mt-5 flex justify-end gap-2">
                <button type="button" onClick={() => { setClientPendingDelete(null); setDeleteDocumentCount(null); }} className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-semibold text-slate-700 hover:bg-slate-50">Cancelar</button>
                <button type="button" disabled={deleteDocumentCount !== 0} onClick={confirmDeleteClient} className="rounded-lg bg-red-700 px-4 py-2 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-40">Excluir cliente</button>
              </div>
            </section>
          </div>
        )}
        <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-800">Cadastro de Clientes</h2>
            {canIncluir && <Button variant="new" className="!w-auto" onClick={handleNewClient}>Novo Cliente</Button>}
        </div>
        <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-4 flex flex-col gap-4 grid-search">
            <div className="flex gap-4"><div className="flex-1"><Input label="" placeholder="Pesquisar por Nome, Código ou CPF/CNPJ..." value={searchTerm} onChange={e => setSearchTerm(e.target.value)} containerClassName="!mb-0" icon={<svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>}/></div><Button variant="ghost" className={`!w-auto ${showFilters ? 'bg-gray-100 text-moss-800' : ''}`} onClick={() => setShowFilters(!showFilters)}><svg className="w-5 h-5 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" /></svg>Filtros {showFilters ? 'Avançados' : ''}</Button></div>
            {showFilters && (
                <div className="grid grid-cols-1 md:grid-cols-5 gap-4 pt-4 border-t animate-fade-in-down">
                    <div><label className="block text-xs font-bold text-gray-500 mb-1 uppercase">Tipo</label><select className="w-full px-3 py-2 rounded border border-gray-300 text-sm focus:ring-2 focus:ring-moss-500 outline-none" value={filterType} onChange={(e) => setFilterType(e.target.value)}><option value="">Todos</option><option value="FISICA">Física</option><option value="JURIDICA">Jurídica</option></select></div>
                    <div><Input label="CPF / CNPJ" value={filterDocument} onChange={(e) => setFilterDocument(e.target.value)} placeholder="Digite os números..." className="!py-2 !text-sm" containerClassName="!mb-0"/></div>
                    <div><Input label="Cidade" value={filterCity} onChange={(e) => setFilterCity(e.target.value)} placeholder="Filtrar cidade..." className="!py-2 !text-sm" containerClassName="!mb-0"/></div>
                    <div><Input label="Estado (UF)" value={filterState} onChange={(e) => setFilterState(e.target.value)} placeholder="Ex: SP" maxLength={2} className="!py-2 !text-sm" containerClassName="!mb-0"/></div>
                    <div className="flex items-end"><Button variant="outline" className="!py-2 !text-xs !w-full" onClick={() => { setFilterType(''); setFilterDocument(''); setFilterCity(''); setFilterState(''); setSearchTerm(''); setSortConfig({ key: null, direction: null }); }}>Limpar Filtros</Button></div>
                </div>
            )}
        </div>
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden flex-1 flex flex-col">
            <div className="overflow-x-auto grid-body-scroll">
                <table className="min-w-full divide-y divide-gray-200 operational-grid">
                    <thead className="bg-gray-50"><tr><TableHeader label="Descrição (Nome)" sortKey="name" /><th className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Natureza</th><TableHeader label="CPF/CNPJ" sortKey="document" /><TableHeader label="Telefone" sortKey="phone" /><TableHeader label="Cidade/UF" sortKey="city" /><th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Ações</th></tr></thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                        {apiLoading && paginatedClients.length === 0 && (<tr><td colSpan={6} className="px-6 py-10 text-center text-gray-500">Carregando clientes...</td></tr>)}
                        {!apiLoading && paginatedClients.length === 0 && (<tr><td colSpan={6} className="px-6 py-10 text-center text-gray-500">Nenhum cliente encontrado com os filtros atuais.</td></tr>)}
                        {paginatedClients.map(client => (
                            <ClientRow
                                key={client.id}
                                client={client}
                                auditLogs={config.auditLogs || []}
                                onEdit={handleEditClientCb}
                                onDuplicate={handleDuplicateClientCb}
                                onDelete={handleDeleteClientCb}
                            canEdit={canAlterar} canDelete={canExcluir} />
                        ))}
                    </tbody>
                </table>
            </div>
            <PaginationBar currentPage={serverPage} totalPages={serverTotalPages} total={serverTotal} pageSize={50} onPageChange={serverGoToPage} loading={apiLoading} />
        </div>
    </div>
  );
};

export default ClientsPanel;

import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { PortalConfig } from '../../types';
import GoTalkMediaRenderer from '../gotalk/GoTalkMediaRenderer';
import { useMessaging } from '../../contexts/MessagingContext';
import { useSecurity } from '../../contexts/SecurityContext';
import { useSocket } from '../../contexts/SocketContext';
import {
  ConversationBubble,
  ConversationComposerSurface,
  ConversationDateSeparator,
  ConversationSurface,
  ConversationTimeline,
} from '../conversations/ConversationPrimitives';

interface Msg {
  id: string;
  phone_number: string;
  direction: 'IN' | 'OUT';
  body: string | null;
  message_type: string;
  attachment_url?: string | null;
  attachment_name?: string | null;
  attachment_mime_type?: string | null;
  ack_status?: number | null;
  operator_name?: string | null;
  department?: string | null;
  sent_at: string;
  source: string;
  unit_id?: string | null;
  client_id?: string | null;
  gotalk_contact_id?: string | null;
  client_name?: string | null;
  unit_name?: string | null;
}

interface TimelineMsg {
  message_id?: string;
  body: string | null;
  audio_transcript?: string | null;
  direction: 'IN' | 'OUT';
  message_type: string;
  sent_at?: string | null;
  attachment_url?: string | null;
  attachment_name?: string | null;
  attachment_mime_type?: string | null;
  operator_name?: string | null;
  source?: string;
  ack_status?: number | null;
  uazapi_instance_id?: string | null;
}

interface Unit {
  id: string;
  razaoSocial?: string;
  nomeFantasia?: string;
}

interface Props {
  config?: PortalConfig;
  defaultPhone?: string;
  defaultClientId?: string;
}

const PAGE_LIMIT = 50;

const ConversasPanel: React.FC<Props> = ({ defaultPhone, defaultClientId }) => {
  const { markGotalkConversationRead } = useMessaging();
  const { addToast } = useSecurity();
  const { socket } = useSocket();

  const [messages, setMessages] = useState<Msg[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [pages, setPages] = useState(1);
  const [loading, setLoading] = useState(false);

  const [units, setUnits] = useState<Unit[]>([]);

  const [fPhone, setFPhone] = useState(defaultPhone || '');
  const [fUnitId, setFUnitId] = useState(() => {
    try { return localStorage.getItem('conversas:fUnitId') || ''; } catch { return ''; }
  });
  const [fSource, setFSource] = useState('');
  const [fDirection, setFDirection] = useState('');
  const [fType, setFType] = useState('');
  const [fOperator, setFOperator] = useState('');
  const [fDateFrom, setFDateFrom] = useState('');
  const [fDateTo, setFDateTo] = useState('');
  const [fQ, setFQ] = useState('');

  const [drawerPhone, setDrawerPhone] = useState<string | null>(null);
  const [drawerClientName, setDrawerClientName] = useState<string | null>(null);
  const [drawerMsgs, setDrawerMsgs] = useState<TimelineMsg[]>([]);
  const [drawerLoading, setDrawerLoading] = useState(false);
  const [drawerUnitId, setDrawerUnitId] = useState<string | null>(null);
  const [drawerSource, setDrawerSource] = useState<string | null>(null);
  const [drawerHasToken, setDrawerHasToken] = useState(false);
  const [drawerInstancePhone, setDrawerInstancePhone] = useState<string | null>(null);
  const [drawerInstancePhones, setDrawerInstancePhones] = useState<Map<string, string>>(new Map());
  const drawerReqRef = useRef(0);

  const [sendText, setSendText] = useState('');
  const [sendLoading, setSendLoading] = useState(false);

  // Modal nova mensagem uazapi
  interface CapableUnit { unit_id: string; unit_name: string; }
  const [showNewMsg, setShowNewMsg] = useState(false);
  const [newMsgUnits, setNewMsgUnits] = useState<CapableUnit[]>([]);
  const [newMsgUnitId, setNewMsgUnitId] = useState('');
  const [newMsgPhone, setNewMsgPhone] = useState('');
  const [newMsgText, setNewMsgText] = useState('');
  const [newMsgLoading, setNewMsgLoading] = useState(false);

  const drawerEndRef = useRef<HTMLDivElement>(null);
  const tableContainerRef = useRef<HTMLDivElement>(null);
  const searchTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const buildQs = useCallback((p: number) => {
    const qs = new URLSearchParams();
    qs.set('page', String(p));
    qs.set('limit', String(PAGE_LIMIT));
    if (fPhone.trim()) qs.set('phone', fPhone.trim());
    if (fUnitId) qs.set('unit_id', fUnitId);
    if (fSource) qs.set('source', fSource);
    if (fDirection) qs.set('direction', fDirection);
    if (fType) qs.set('type', fType);
    if (fOperator.trim()) qs.set('operator', fOperator.trim());
    if (fDateFrom) qs.set('date_from', fDateFrom);
    if (fDateTo) qs.set('date_to', fDateTo);
    if (fQ.trim()) qs.set('q', fQ.trim());
    if (defaultClientId) qs.set('client_id', defaultClientId);
    return qs.toString();
  }, [fPhone, fUnitId, fSource, fDirection, fType, fOperator, fDateFrom, fDateTo, fQ, defaultClientId]);

  const fetchMessages = useCallback(async (p: number) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/whatsapp/messages?${buildQs(p)}`);
      if (!res.ok) return;
      const data = await res.json();
      setMessages(data.messages || []);
      setTotal(data.total || 0);
      setPage(data.page || p);
      setPages(data.pages || 1);
    } catch {}
    finally { setLoading(false); }
  }, [buildQs]);

  const fetchUnits = async () => {
    try {
      const res = await fetch('/api/units?limit=200');
      if (!res.ok) return;
      const data = await res.json();
      setUnits((data.data || []).filter((u: Unit) => u.id && (u.razaoSocial || u.nomeFantasia)));
    } catch {}
  };

  const unitLabel = (u: Unit) => u.nomeFantasia || u.razaoSocial || u.id;

  const fetchCapableUnits = async () => {
    try {
      const r = await fetch('/api/uazapi/capable-units');
      if (r.ok) {
        const d = await r.json();
        const list = d.units || [];
        setNewMsgUnits(list);
        if (list.length === 1) setNewMsgUnitId(list[0].unit_id);
      }
    } catch {}
  };

  useEffect(() => {
    fetchUnits();
    fetchCapableUnits();
  }, []);

  useEffect(() => {
    if (searchTimerRef.current) clearTimeout(searchTimerRef.current);
    searchTimerRef.current = setTimeout(() => {
      fetchMessages(1);
    }, 400);
    return () => { if (searchTimerRef.current) clearTimeout(searchTimerRef.current); };
  }, [fPhone, fUnitId, fSource, fDirection, fType, fOperator, fDateFrom, fDateTo, fQ]);

  // Auto-refresh: Socket.io para GoTalk + polling periódico para uazapi
  const refreshTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (!socket) return;
    const handleNewMsg = () => {
      // Debounce para evitar múltiplos reloads consecutivos
      if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
      refreshTimerRef.current = setTimeout(() => {
        fetchMessages(1);
      }, 800);
    };
    socket.on('gotalk:new_message', handleNewMsg);
    return () => {
      socket.off('gotalk:new_message', handleNewMsg);
      if (refreshTimerRef.current) clearTimeout(refreshTimerRef.current);
    };
  }, [socket, fetchMessages]);

  // Polling periódico a cada 30s para capturar mensagens uazapi e GoTalk
  useEffect(() => {
    const interval = setInterval(() => fetchMessages(1), 30_000);
    return () => clearInterval(interval);
  }, [fetchMessages]);

  const handlePageChange = (p: number) => {
    if (p < 1 || p > pages) return;
    fetchMessages(p);
  };

  const openNewMsg = () => {
    setNewMsgPhone(''); setNewMsgText('');
    if (newMsgUnits.length === 1) setNewMsgUnitId(newMsgUnits[0].unit_id);
    else setNewMsgUnitId('');
    setShowNewMsg(true);
  };

  const handleNewMsgSend = async () => {
    const phone = newMsgPhone.replace(/\D/g, '');
    if (!newMsgUnitId) { addToast('error', 'Atenção', 'Selecione a unidade.'); return; }
    if (phone.length < 8) { addToast('error', 'Atenção', 'Informe um número de telefone válido.'); return; }
    if (!newMsgText.trim()) { addToast('error', 'Atenção', 'Digite uma mensagem.'); return; }
    setNewMsgLoading(true);
    try {
      const res = await fetch('/api/uazapi/send-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ unitId: newMsgUnitId, phone, text: newMsgText.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        addToast('error', 'Erro ao enviar', data.error || 'Não foi possível enviar a mensagem.');
      } else {
        addToast('success', 'Mensagem enviada', 'Mensagem enviada com sucesso via uazapi.');
        setShowNewMsg(false);
        fetchMessages(1);
      }
    } catch {
      addToast('error', 'Erro ao enviar', 'Erro de conexão.');
    } finally {
      setNewMsgLoading(false);
    }
  };

  const openDrawer = async (phone: string, clientName: string | null, unitId?: string | null, source?: string | null, contactId?: string | null) => {
    setDrawerPhone(phone);
    setDrawerClientName(clientName);
    setDrawerUnitId(unitId || null);
    setDrawerSource(source || null);
    setDrawerHasToken(false);
    setDrawerInstancePhone(null);
    setDrawerInstancePhones(new Map());
    setDrawerMsgs([]);
    setDrawerLoading(true);
    setSendText('');
    const reqId = ++drawerReqRef.current;

    markGotalkConversationRead(phone, contactId);

    // Fetch messages and (for uazapi) credentials in parallel
    const timeline = fetch(`/api/gotalk/client-timeline?phone=${encodeURIComponent(phone)}&limit=500`)
      .then(r => r.ok ? r.json() : null).catch(() => null);

    if (source === 'uazapi' && unitId) {
      try {
        const capRes = await fetch(`/api/units/${encodeURIComponent(unitId)}/uazapi-send-capability`);
        if (reqId === drawerReqRef.current) {
          if (capRes.ok) {
            const cap = await capRes.json();
            if (reqId === drawerReqRef.current) setDrawerHasToken(Boolean(cap?.hasToken));
          } else if (capRes.status === 403) {
            addToast('error', 'Acesso negado', 'Você não tem permissão para enviar mensagens por esta unidade.');
          }
        }
      } catch {
        // silent — composer will remain hidden
      }
      // Task #312: resolver os números reais das instâncias desta unidade (cache 5 min no servidor).
      // Monta um mapa instanceId→número para exibir, por mensagem, a instância realmente usada;
      // o chip do cabeçalho usa o número conectado (ou o primeiro) como referência da unidade.
      fetch(`/api/units/${encodeURIComponent(unitId)}/uazapi-instances`)
        .then(r => r.ok ? r.json() : null)
        .then(d => {
          if (reqId !== drawerReqRef.current) return; // descarta resposta de drawer anterior
          const list: Array<{ instanceId?: string; phoneNumber?: string | null; isConnected?: boolean | null }> = d?.instances || [];
          const map = new Map<string, string>();
          for (const i of list) {
            if (i.instanceId && i.phoneNumber) map.set(i.instanceId, i.phoneNumber);
          }
          setDrawerInstancePhones(map);
          const connected = list.find(i => i.isConnected && i.phoneNumber);
          const anyPhone = connected?.phoneNumber || list.find(i => i.phoneNumber)?.phoneNumber || null;
          setDrawerInstancePhone(anyPhone || null);
        })
        .catch(() => {});
    }

    try {
      const data = await timeline;
      if (reqId === drawerReqRef.current && data) setDrawerMsgs(data.messages || []);
    } catch {}
    finally { if (reqId === drawerReqRef.current) setDrawerLoading(false); }
  };

  const handleSendText = async () => {
    if (!sendText.trim() || !drawerPhone || !drawerUnitId || sendLoading) return;
    setSendLoading(true);
    try {
      const res = await fetch('/api/uazapi/send-text', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ unitId: drawerUnitId, phone: drawerPhone, text: sendText.trim() }),
      });
      const data = await res.json();
      if (!res.ok) {
        addToast('error', 'Erro ao enviar', data.error || 'Não foi possível enviar a mensagem.');
      } else {
        setSendText('');
        if (data.message) {
          setDrawerMsgs(prev => [...prev, data.message]);
          setTimeout(() => drawerEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 50);
        }
      }
    } catch {
      addToast('error', 'Erro ao enviar', 'Erro de conexão ao tentar enviar mensagem.');
    } finally {
      setSendLoading(false);
    }
  };

  useEffect(() => {
    if (!drawerLoading) {
      drawerEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [drawerMsgs, drawerLoading]);

  // Group messages by date (DESC order from backend), sort each group ASC by time
  const sortedMessages = useMemo(() => {
    const groups = new Map<string, Msg[]>();
    for (const m of messages) {
      const key = m.sent_at ? new Date(m.sent_at).toDateString() : '_none';
      if (!groups.has(key)) groups.set(key, []);
      groups.get(key)!.push(m);
    }
    const result: Msg[] = [];
    for (const [, group] of groups) {
      group.sort((a, b) => new Date(a.sent_at).getTime() - new Date(b.sent_at).getTime());
      result.push(...group);
    }
    return result;
  }, [messages]);

  // Scroll table to top whenever messages load or page changes
  useEffect(() => {
    if (!loading && sortedMessages.length > 0) {
      tableContainerRef.current?.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }, [sortedMessages, loading]);

  const formatDt = (iso: string) => {
    if (!iso) return '';
    const d = new Date(iso);
    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' })
      + ' ' + d.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  const formatTime = (iso?: string | null) => {
    if (!iso) return '';
    return new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDay = (iso?: string | null) => {
    if (!iso) return '';
    return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' });
  };

  const formatDayLabel = (iso?: string | null): string => {
    if (!iso) return '';
    const d = new Date(iso);
    const today = new Date();
    const yesterday = new Date();
    yesterday.setDate(yesterday.getDate() - 1);
    const sameDay = (a: Date, b: Date) =>
      a.getFullYear() === b.getFullYear() &&
      a.getMonth() === b.getMonth() &&
      a.getDate() === b.getDate();
    if (sameDay(d, today)) return 'Hoje';
    if (sameDay(d, yesterday)) return 'Ontem';
    return d.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long', year: 'numeric' });
  };

  const formatPhone = (p: string) => {
    const d = p.replace(/\D/g, '');
    if (d.length === 13) return `+${d.slice(0, 2)} (${d.slice(2, 4)}) ${d.slice(4, 9)}-${d.slice(9)}`;
    if (d.length === 12) return `+${d.slice(0, 2)} (${d.slice(2, 4)}) ${d.slice(4, 8)}-${d.slice(8)}`;
    if (d.length === 11) return `(${d.slice(0, 2)}) ${d.slice(2, 7)}-${d.slice(7)}`;
    if (d.length === 10) return `(${d.slice(0, 2)}) ${d.slice(2, 6)}-${d.slice(6)}`;
    return p;
  };

  const sourceLabel = (s: string) => s === 'uazapi' ? 'uazapi' : 'GoTalk';
  const sourceBadge = (s: string) => s === 'uazapi'
    ? 'bg-teal-100 text-teal-800'
    : 'bg-green-100 text-green-800';

  const typeLabel: Record<string, string> = {
    TEXT: 'Texto', AUDIO: 'Áudio', IMAGE: 'Imagem', VIDEO: 'Vídeo',
    DOCUMENT: 'Documento', TEMPLATE: 'Template', STICKER: 'Sticker',
    LOCATION: 'Localização', CONTACT: 'Contato',
  };

  const renderAck = (ack?: number | null) => {
    if (ack == null) return <span className="text-gray-600 text-xs" title="Aguardando">⏱</span>;
    if (ack >= 3) return <span className="text-blue-700 text-xs font-bold" title="Lida">✓✓</span>;
    if (ack === 2) return <span className="text-gray-500 text-xs font-bold" title="Entregue">✓✓</span>;
    return <span className="text-gray-600 text-xs" title="Enviada">✓</span>;
  };

  const clearFilters = () => {
    setFPhone(defaultPhone || '');
    setFUnitId(''); setFSource(''); setFDirection('');
    setFType(''); setFOperator(''); setFDateFrom(''); setFDateTo(''); setFQ('');
  };

  const [syncing, setSyncing] = useState(false);

  const handleSyncHistory = async () => {
    if (syncing) return;
    setSyncing(true);
    try {
      // Determinar quais unidades sincronizar
      const unitIds: string[] = fUnitId
        ? [fUnitId]
        : newMsgUnits.map((u: CapableUnit) => u.unit_id);

      if (unitIds.length === 0) {
        addToast('error', 'Sem unidades', 'Nenhuma unidade com WhatsApp (uazapi) configurado.');
        setSyncing(false);
        return;
      }

      let ok = 0;
      for (const uid of unitIds) {
        try {
          const res = await fetch('/api/uazapi/sync-history', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ unitId: uid }),
          });
          if (res.ok) ok++;
        } catch { /* continuar próxima unidade */ }
      }

      if (ok === 0) {
        addToast('error', 'Erro na sincronização', 'Nenhuma unidade pôde ser sincronizada.');
        setSyncing(false);
        return;
      }

      addToast('success', 'Sincronizando conversas', `Buscando mensagens de ${ok} unidade${ok > 1 ? 's' : ''} em background. A lista será atualizada em instantes.`);
      setTimeout(() => {
        fetchMessages(1);
        setSyncing(false);
      }, 6000);
    } catch {
      addToast('error', 'Erro de conexão', 'Não foi possível iniciar a sincronização.');
      setSyncing(false);
    }
  };

  const [exporting, setExporting] = useState(false);

  const handleExport = async () => {
    setExporting(true);
    try {
      const qs = new URLSearchParams();
      qs.set('format', 'csv');
      if (fPhone.trim()) qs.set('phone', fPhone.trim());
      if (fUnitId) qs.set('unit_id', fUnitId);
      if (fSource) qs.set('source', fSource);
      if (fDirection) qs.set('direction', fDirection);
      if (fType) qs.set('type', fType);
      if (fOperator.trim()) qs.set('operator', fOperator.trim());
      if (fDateFrom) qs.set('date_from', fDateFrom);
      if (fDateTo) qs.set('date_to', fDateTo);
      if (fQ.trim()) qs.set('q', fQ.trim());
      if (defaultClientId) qs.set('client_id', defaultClientId);

      const res = await fetch(`/api/whatsapp/messages?${qs.toString()}`);
      if (!res.ok) return;
      const blob = await res.blob();
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'conversas-whatsapp.csv';
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(url);
    } catch {}
    finally { setExporting(false); }
  };

  let lastDay = '';
  let tableDay = '';

  return (
    <>
    <ConversationSurface data-testid="conversas-panel" data-visual-panel="conversas" className="flex h-full min-w-0 overflow-hidden bg-gray-50">
      {/* Main panel */}
        <div className="flex-1 min-w-0 flex flex-col overflow-hidden">
        {/* Header */}
        <div data-testid="conversas-filters" className="bg-white border-b border-gray-200 px-3 min-[1400px]:px-6 py-2.5 min-[1400px]:py-4 flex-shrink-0">
          <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-lg bg-green-600 flex items-center justify-center">
                <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
                </svg>
              </div>
              <div>
                <h1 className="text-lg font-bold text-gray-900">Conversas WhatsApp</h1>
                <p className="text-xs text-gray-500">GoTalk + uazapi — todas as unidades</p>
              </div>
            </div>
            <div className="flex flex-wrap items-center gap-2 text-sm text-gray-500">
              <span className="font-semibold text-gray-800">{total.toLocaleString('pt-BR')}</span>
              <span>mensagem{total !== 1 ? 's' : ''}</span>
              {(() => {
                const uazapiAvailable = newMsgUnits.length > 0;
                const notGotalk = fSource !== 'gotalk';
                const enabled = uazapiAvailable && notGotalk;
                const tooltip = !uazapiAvailable
                  ? 'Nenhuma unidade com uazapi configurado'
                  : !notGotalk
                  ? 'Disponível apenas para o provedor uazapi'
                  : 'Enviar nova mensagem via uazapi';
                return (
                  <button
                    onClick={enabled ? openNewMsg : undefined}
                    disabled={!enabled}
                    className={`ml-2 flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${enabled ? 'bg-teal-700 hover:bg-teal-800 text-white cursor-pointer' : 'bg-gray-200 text-gray-400 cursor-not-allowed'}`}
                    title={tooltip}
                  >
                    <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                    Nova mensagem
                  </button>
                );
              })()}
              <button
                onClick={handleSyncHistory}
                disabled={syncing}
                className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg transition-colors ${syncing ? 'bg-green-100 text-green-500 cursor-wait' : 'bg-green-50 hover:bg-green-100 text-green-700 cursor-pointer'}`}
                title={fUnitId ? 'Importar conversas desta unidade do uazapi para o banco' : 'Importar conversas de todas as unidades do uazapi para o banco'}
              >
                <svg className={`w-3.5 h-3.5 ${syncing ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                {syncing ? 'Sincronizando...' : 'Atualizar do WhatsApp'}
              </button>
              <button
                onClick={() => fetchMessages(page)}
                className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-600 hover:text-gray-800"
                title="Atualizar lista local"
              >
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
              </button>
            </div>
          </div>

          {/* Filters */}
          <div className="grid grid-cols-1 min-[420px]:grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-1.5 min-[1400px]:gap-2">
            <input
              type="text"
              placeholder="Buscar no texto..."
              value={fQ}
              onChange={e => setFQ(e.target.value)}
              className="col-span-2 md:col-span-1 border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <input
              type="text"
              placeholder="Telefone"
              value={fPhone}
              onChange={e => setFPhone(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <select
              value={fUnitId}
              onChange={e => {
                const v = e.target.value;
                setFUnitId(v);
                try { v ? localStorage.setItem('conversas:fUnitId', v) : localStorage.removeItem('conversas:fUnitId'); } catch {}
              }}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 bg-white"
            >
              <option value="">Todas as unidades</option>
              {units.map(u => (
                <option key={u.id} value={u.id}>{unitLabel(u)}</option>
              ))}
            </select>
            <select
              value={fSource}
              onChange={e => setFSource(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 bg-white"
            >
              <option value="">Todos os provedores</option>
              <option value="gotalk">GoTalk</option>
              <option value="uazapi">uazapi</option>
            </select>
            <div className="flex gap-2 col-span-2 md:col-span-1">
              <input
                type="date"
                value={fDateFrom}
                onChange={e => setFDateFrom(e.target.value)}
                className="flex-1 border border-gray-300 rounded-lg px-2 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                title="Data inicial"
              />
              <input
                type="date"
                value={fDateTo}
                onChange={e => setFDateTo(e.target.value)}
                className="flex-1 border border-gray-300 rounded-lg px-2 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
                title="Data final"
              />
            </div>
            <select
              value={fDirection}
              onChange={e => setFDirection(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 bg-white"
            >
              <option value="">Todas as direções</option>
              <option value="IN">Recebidas</option>
              <option value="OUT">Enviadas</option>
            </select>
            <select
              value={fType}
              onChange={e => setFType(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500 bg-white"
            >
              <option value="">Todos os tipos</option>
              <option value="TEXT">Texto</option>
              <option value="AUDIO">Áudio</option>
              <option value="IMAGE">Imagem</option>
              <option value="VIDEO">Vídeo</option>
              <option value="DOCUMENT">Documento</option>
              <option value="TEMPLATE">Template</option>
            </select>
            <input
              type="text"
              placeholder="Operador"
              value={fOperator}
              onChange={e => setFOperator(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-500"
            />
            <button
              onClick={clearFilters}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm text-gray-500 hover:bg-gray-100 transition-colors"
              title="Limpar filtros"
            >
              Limpar
            </button>
            <button
              onClick={handleExport}
              disabled={exporting}
              className="flex items-center gap-1.5 border border-green-600 rounded-lg px-3 py-2 text-sm text-green-700 hover:bg-green-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
              title="Exportar filtros atuais para CSV"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
              </svg>
              {exporting ? 'Exportando...' : 'Exportar'}
            </button>
          </div>
        </div>

        {/* Table */}
        <div data-testid="conversas-table-scroll" ref={tableContainerRef} className="flex-1 min-h-0 min-w-0 overflow-auto">
          {loading ? (
            <div className="flex items-center justify-center h-40 text-gray-400 text-sm">
              Carregando...
            </div>
          ) : messages.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-40 text-gray-400 gap-2">
              <svg className="w-10 h-10 opacity-30" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
              <p className="text-sm">Nenhuma mensagem encontrada</p>
            </div>
          ) : (
            <table data-testid="conversas-table" aria-label="Mensagens WhatsApp" className="w-full min-w-[940px] text-sm operational-grid">
              <thead className="bg-gray-100 sticky top-0 z-10">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider whitespace-nowrap">Data/Hora</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Número</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Cliente</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Unidade</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Provedor</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Dir.</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Tipo</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Prévia</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Operador</th>
                  <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">ACK</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 bg-white">
                {(() => {
                  tableDay = '';
                  return sortedMessages.map(m => {
                    const day = m.sent_at ? formatDay(m.sent_at) : '';
                    const showDay = day !== tableDay;
                    if (showDay) tableDay = day;
                    return (
                      <React.Fragment key={m.id}>
                        {showDay && (
                          <tr className="bg-gray-50">
                            <td colSpan={10} className="px-4 py-2">
                              <div className="flex items-center gap-3">
                                <div className="flex-1 border-t border-gray-200" />
                                <span className="text-[10px] font-bold text-gray-600 uppercase tracking-widest whitespace-nowrap select-none">
                                  {formatDayLabel(m.sent_at)}
                                </span>
                                <div className="flex-1 border-t border-gray-200" />
                              </div>
                            </td>
                          </tr>
                        )}
                        <tr
                          onClick={() => openDrawer(m.phone_number, m.client_name, m.unit_id, m.source, m.gotalk_contact_id)}
                          className="hover:bg-green-50 cursor-pointer transition-colors"
                        >
                          <td className="px-4 py-2.5 whitespace-nowrap text-xs text-gray-500">{formatDt(m.sent_at)}</td>
                          <td className="px-4 py-2.5 whitespace-nowrap font-mono text-xs text-gray-700">{formatPhone(m.phone_number)}</td>
                          <td className="px-4 py-2.5 max-w-[140px] truncate text-xs">
                            {m.client_name
                              ? <span className="text-indigo-700 font-medium">{m.client_name}</span>
                              : <span className="text-gray-600 italic">—</span>
                            }
                          </td>
                          <td className="px-4 py-2.5 max-w-[120px] truncate text-xs text-gray-600">{m.unit_name || '—'}</td>
                          <td className="px-4 py-2.5 whitespace-nowrap">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-semibold ${sourceBadge(m.source)}`}>
                              {sourceLabel(m.source)}
                            </span>
                          </td>
                          <td className="px-4 py-2.5 whitespace-nowrap">
                            {m.direction === 'IN'
                              ? <span className="text-blue-600" title="Recebida">↓</span>
                              : <span className="text-green-700" title="Enviada">↑</span>
                            }
                          </td>
                          <td className="px-4 py-2.5 whitespace-nowrap text-xs text-gray-500">
                            {typeLabel[m.message_type] || m.message_type}
                          </td>
                          <td className="px-4 py-2.5 max-w-[220px] truncate text-xs text-gray-700">
                            {m.body || (m.attachment_name ? `📎 ${m.attachment_name}` : '—')}
                          </td>
                          <td className="px-4 py-2.5 max-w-[120px] truncate text-xs text-gray-600">{m.operator_name || '—'}</td>
                          <td className="px-4 py-2.5 text-center whitespace-nowrap">
                            {m.direction === 'OUT' ? renderAck(m.ack_status) : <span className="text-gray-600 text-xs">—</span>}
                          </td>
                        </tr>
                      </React.Fragment>
                    );
                  });
                })()}
              </tbody>
            </table>
          )}
        </div>

        {/* Pagination */}
        {pages > 1 && (
          <div data-testid="conversas-pagination" aria-label="Paginação de conversas" className="bg-white border-t border-gray-200 px-3 min-[1400px]:px-4 py-2 min-[1400px]:py-3 flex items-center justify-between gap-2 flex-shrink-0">
            <span className="text-xs text-gray-500">
              Página {page} de {pages} · {total.toLocaleString('pt-BR')} registros
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => handlePageChange(1)}
                disabled={page === 1}
                className="px-2 py-1 rounded text-xs border border-gray-300 disabled:opacity-40 hover:bg-gray-50 transition-colors"
              >«</button>
              <button
                onClick={() => handlePageChange(page - 1)}
                disabled={page === 1}
                className="px-2 py-1 rounded text-xs border border-gray-300 disabled:opacity-40 hover:bg-gray-50 transition-colors"
              >‹</button>
              {Array.from({ length: Math.min(5, pages) }, (_, i) => {
                let p: number;
                if (pages <= 5) p = i + 1;
                else if (page <= 3) p = i + 1;
                else if (page >= pages - 2) p = pages - 4 + i;
                else p = page - 2 + i;
                return (
                  <button
                    key={p}
                    onClick={() => handlePageChange(p)}
                    className={`px-2.5 py-1 rounded text-xs border transition-colors ${
                      p === page
                        ? 'bg-green-700 text-white border-green-700'
                        : 'border-gray-300 hover:bg-gray-50'
                    }`}
                  >{p}</button>
                );
              })}
              <button
                onClick={() => handlePageChange(page + 1)}
                disabled={page === pages}
                className="px-2 py-1 rounded text-xs border border-gray-300 disabled:opacity-40 hover:bg-gray-50 transition-colors"
              >›</button>
              <button
                onClick={() => handlePageChange(pages)}
                disabled={page === pages}
                className="px-2 py-1 rounded text-xs border border-gray-300 disabled:opacity-40 hover:bg-gray-50 transition-colors"
              >»</button>
            </div>
          </div>
        )}
      </div>

      {/* Conversation Drawer */}
      {drawerPhone && (
        <div className="w-[380px] max-[767px]:absolute max-[767px]:inset-0 max-[767px]:z-20 max-[767px]:w-full flex-shrink-0 bg-white border-l border-gray-200 flex flex-col overflow-hidden shadow-lg">
          {/* Drawer header */}
          <div className="bg-green-800 text-white px-4 py-3 flex items-center gap-3 flex-shrink-0">
            <div className="w-8 h-8 rounded-full bg-green-700 flex items-center justify-center font-bold text-sm">
              {(drawerClientName || drawerPhone)[0].toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-semibold text-sm truncate">{drawerClientName || formatPhone(drawerPhone)}</p>
              <p className="text-xs text-green-100 truncate">{formatPhone(drawerPhone)}</p>
              {drawerSource === 'uazapi' && (() => {
                const u = units.find(x => x.id === drawerUnitId);
                const unitName = u ? unitLabel(u) : null;
                if (!unitName && !drawerInstancePhone) return null;
                return (
                  <span className="inline-flex items-center gap-1 mt-1 px-1.5 py-0.5 rounded-full bg-green-950/80 text-[10px] text-white max-w-full truncate" title="Unidade e número WhatsApp desta conversa">
                    <svg className="w-2.5 h-2.5 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0H5m14 0h2M5 21H3m4-14h2m-2 4h2m-2 4h2m4-8h2m-2 4h2m-2 4h2" /></svg>
                    <span className="truncate">{unitName || 'Unidade'}{drawerInstancePhone ? ` · ${formatPhone(drawerInstancePhone)}` : ''}</span>
                  </span>
                );
              })()}
            </div>
            <button
              onClick={() => { setDrawerPhone(null); setDrawerUnitId(null); setDrawerSource(null); setDrawerHasToken(false); setDrawerInstancePhone(null); setSendText(''); }}
              className="p-1 rounded hover:bg-green-700 transition-colors flex-shrink-0"
              title="Fechar"
            >
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Drawer messages */}
          <ConversationTimeline className="flex-1 overflow-y-auto p-3 space-y-1">
            {drawerLoading ? (
              <div className="flex items-center justify-center h-full text-gray-400 text-sm">
                Carregando conversa...
              </div>
            ) : drawerMsgs.length === 0 ? (
              <div className="flex items-center justify-center h-full text-gray-400 text-sm">
                Nenhuma mensagem no histórico
              </div>
            ) : (
              <>
                {(() => {
                  lastDay = '';
                  return drawerMsgs.map((msg, i) => {
                    const day = msg.sent_at ? formatDay(msg.sent_at) : '';
                    const showDay = day !== lastDay;
                    if (showDay) lastDay = day;
                    const isOut = msg.direction === 'OUT';

                    return (
                      <React.Fragment key={msg.message_id || i}>
                        {showDay && (
                          <ConversationDateSeparator className="bg-white text-gray-500 text-[10px] font-semibold px-3 py-1 rounded-full shadow-sm border border-gray-200">
                            {day}
                          </ConversationDateSeparator>
                        )}
                        <div className={`flex ${isOut ? 'justify-end' : 'justify-start'}`}>
                          <ConversationBubble outgoing={isOut} className={`max-w-[85%] rounded-xl px-3 py-2 shadow-sm text-sm ${
                            isOut
                              ? 'bg-green-100 text-gray-800 rounded-br-none'
                              : 'bg-white text-gray-800 rounded-bl-none border border-gray-100'
                          }`}>
                            <GoTalkMediaRenderer
                              messageId={msg.message_id}
                              messageType={msg.message_type}
                              caption={msg.body}
                              audioTranscript={msg.audio_transcript}
                              attachmentUrl={msg.attachment_url}
                              attachmentName={msg.attachment_name}
                              attachmentMime={msg.attachment_mime_type}
                            />
                            <div className="flex items-center justify-end gap-1 mt-0.5">
                              {msg.operator_name && isOut && (
                                <span className="text-[9px] text-green-800">{msg.operator_name}</span>
                              )}
                              <span className="text-[10px] text-gray-600">{formatTime(msg.sent_at)}</span>
                              {msg.source === 'uazapi' && (() => {
                                const num = (msg.uazapi_instance_id && drawerInstancePhones.get(msg.uazapi_instance_id)) || drawerInstancePhone;
                                return num ? (
                                  <span className="conversation-instance-label text-[9px] text-teal-800 font-mono" title="Número WhatsApp (instância) usado nesta mensagem">
                                    via {formatPhone(num)}
                                  </span>
                                ) : null;
                              })()}
                              {msg.source && (
                                <span className={`conversation-source-marker text-[9px] px-1 rounded ${msg.source === 'uazapi' ? 'text-teal-800' : 'text-green-800'}`}>
                                  {msg.source === 'uazapi' ? '●' : '○'}
                                </span>
                              )}
                            </div>
                          </ConversationBubble>
                        </div>
                      </React.Fragment>
                    );
                  });
                })()}
                <div ref={drawerEndRef} />
              </>
            )}
          </ConversationTimeline>

          {/* Send area — only for uazapi conversations with a configured token */}
          {drawerSource === 'uazapi' && drawerUnitId && drawerHasToken && (
            <ConversationComposerSurface className="border-t border-gray-200 bg-white px-3 py-2 flex-shrink-0">
              <div className="flex gap-2 items-end">
                <textarea
                  className="flex-1 border border-gray-300 rounded-lg px-3 py-2 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-green-400 focus:border-transparent"
                  rows={2}
                  placeholder="Digite uma mensagem..."
                  value={sendText}
                  onChange={e => setSendText(e.target.value)}
                  onKeyDown={e => {
                    if (e.key === 'Enter' && !e.shiftKey) {
                      e.preventDefault();
                      handleSendText();
                    }
                  }}
                  disabled={sendLoading}
                />
                <button
                  onClick={handleSendText}
                  disabled={sendLoading || !sendText.trim()}
                  className="bg-green-600 hover:bg-green-700 disabled:opacity-40 text-white rounded-full w-9 h-9 flex items-center justify-center flex-shrink-0 transition-colors"
                  title="Enviar mensagem"
                >
                  {sendLoading ? (
                    <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                    </svg>
                  ) : (
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                  )}
                </button>
              </div>
            </ConversationComposerSurface>
          )}
        </div>
      )}
    </ConversationSurface>

    {/* ── Modal Nova Mensagem uazapi ────────────────────────────────────────── */}
    {showNewMsg && (
      <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/40 backdrop-blur-sm p-2 sm:p-4">
        <div role="dialog" aria-modal="true" className="whatsapp-theme responsive-modal-surface bg-white rounded-t-2xl sm:rounded-2xl shadow-2xl w-full max-w-md overflow-hidden flex flex-col">
          <div className="bg-teal-700 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
              </svg>
              <span className="text-white font-semibold">Nova mensagem via uazapi</span>
            </div>
            <button onClick={() => setShowNewMsg(false)} className="text-white hover:text-white transition-colors">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <div className="px-4 sm:px-6 py-5 space-y-4 overflow-y-auto">
            {newMsgUnits.length === 0 ? (
              <p className="text-sm text-amber-700 bg-amber-50 border border-amber-200 rounded-lg px-4 py-3">
                Nenhuma unidade com uazapi configurado foi encontrada ou você não tem permissão de acesso.
              </p>
            ) : newMsgUnits.length > 1 ? (
              <div>
                <label className="block text-xs font-semibold text-gray-600 mb-1">Unidade</label>
                <select
                  value={newMsgUnitId}
                  onChange={e => setNewMsgUnitId(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 bg-white"
                >
                  <option value="">Selecione a unidade...</option>
                  {newMsgUnits.map(u => (
                    <option key={u.unit_id} value={u.unit_id}>{u.unit_name}</option>
                  ))}
                </select>
              </div>
            ) : (
              <p className="text-xs text-teal-700 bg-teal-50 rounded-lg px-3 py-2">
                Instância: <strong>{newMsgUnits[0].unit_name}</strong>
              </p>
            )}
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Número do WhatsApp</label>
              <input
                type="text"
                placeholder="Ex: 5511999990000"
                value={newMsgPhone}
                onChange={e => setNewMsgPhone(e.target.value)}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
              <p className="text-xs text-gray-600 mt-1">Com DDI e DDD, apenas números. Ex: 5581999990000</p>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-600 mb-1">Mensagem</label>
              <textarea
                rows={4}
                placeholder="Digite a mensagem..."
                value={newMsgText}
                onChange={e => setNewMsgText(e.target.value)}
                onKeyDown={e => { if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) handleNewMsgSend(); }}
                className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-teal-500 resize-none"
              />
              <p className="text-xs text-gray-600 mt-1">Ctrl+Enter para enviar</p>
            </div>
          </div>
          <div className="px-6 pb-5 flex justify-end gap-3">
            <button
              onClick={() => setShowNewMsg(false)}
              className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 rounded-lg hover:bg-gray-100 transition-colors"
              disabled={newMsgLoading}
            >
              Cancelar
            </button>
            <button
              onClick={handleNewMsgSend}
              disabled={newMsgLoading || newMsgUnits.length === 0}
              className="flex items-center gap-2 px-5 py-2 bg-teal-700 hover:bg-teal-800 disabled:opacity-40 text-white text-sm font-semibold rounded-lg transition-colors"
            >
              {newMsgLoading ? (
                <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
                </svg>
              ) : (
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                </svg>
              )}
              Enviar
            </button>
          </div>
        </div>
      </div>
    )}
    </>
  );
};

export default ConversasPanel;

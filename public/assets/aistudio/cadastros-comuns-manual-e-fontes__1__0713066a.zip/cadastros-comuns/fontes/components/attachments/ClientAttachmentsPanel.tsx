import React, { useCallback, useEffect, useRef, useState } from 'react';
import { api, apiRequest } from '../../services/apiService';
import { ClientAttachmentMetadata, AttachmentModule } from './attachmentTypes';
import AclRecipientPicker from './AclRecipientPicker';

interface Props {
  clientId?: string;
  module?: AttachmentModule;
  targetType?: string;
  targetId?: string;
  compact?: boolean;
  allowUpload?: boolean;
  readOnly?: boolean;
  onCountChange?: (count: number) => void;
}

interface AttachmentPage {
  data: ClientAttachmentMetadata[];
  total?: number;
  nextCursor?: string | null;
  hasMore?: boolean;
  pagination?: { total?: number; nextCursor?: string | null; hasMore?: boolean };
}

interface AccessDraft {
  groupIds: string[];
  userIds: string[];
  configured?: boolean;
  overrideEnabled?: boolean;
}

interface LegacyAclImpact {
  clientId: string;
  legacyCount: number;
  folderConfigured: boolean;
  folderGroupGrantCount: number;
  folderUserGrantCount: number;
}

interface LegacyProtection {
  id: string;
  originalFilename: string;
  module: AttachmentModule;
  category: string;
  adoptedByName: string;
  adoptedAt: string;
}

const moduleLabels: Record<AttachmentModule, string> = {
  GENERAL: 'Geral', ADMISSION: 'Admissões', LEGAL: 'Jurídico',
  COLLECTION_PROSPECTION: 'Cobrança / Prospecção',
};
const PAGE_SIZE = 25;
const formatBytes = (value?: number) => !value ? '—' : value < 1024 * 1024
  ? `${Math.ceil(value / 1024)} KB` : `${(value / 1024 / 1024).toFixed(1)} MB`;
const formatDateTime = (value: string) => new Intl.DateTimeFormat('pt-BR', {
  dateStyle: 'short', timeStyle: 'short',
}).format(new Date(value));

export default function ClientAttachmentsPanel({
  clientId, module, targetType, targetId, compact = false,
  allowUpload = false, readOnly = false, onCountChange,
}: Props) {
  const [items, setItems] = useState<ClientAttachmentMetadata[]>([]);
  const [filter, setFilter] = useState('');
  const [query, setQuery] = useState('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const [nextCursor, setNextCursor] = useState<string | null>(null);
  const [hasMore, setHasMore] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [busy, setBusy] = useState<string | null>(null);
  // Selection is deliberately independent of the current page.
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [selectedItems, setSelectedItems] = useState<Map<string, ClientAttachmentMetadata>>(new Map());
  const [pendingDelete, setPendingDelete] = useState<ClientAttachmentMetadata[]>([]);
  const [deleting, setDeleting] = useState(false);
  const [accessOptionsLoaded, setAccessOptionsLoaded] = useState(false);
  const [accessModal, setAccessModal] = useState<{ kind: 'folder' | 'file'; attachment?: ClientAttachmentMetadata } | null>(null);
  const [accessDraft, setAccessDraft] = useState<AccessDraft>({ groupIds: [], userIds: [] });
  const [accessLoading, setAccessLoading] = useState(false);
  const [accessReady, setAccessReady] = useState(false);
  const [accessSaving, setAccessSaving] = useState(false);
  const [accessError, setAccessError] = useState('');
  const [legacyImpact, setLegacyImpact] = useState<LegacyAclImpact | null>(null);
  const [legacyImpactLoading, setLegacyImpactLoading] = useState(false);
  const [legacyOptInModal, setLegacyOptInModal] = useState(false);
  const [pendingLegacyOptIn, setPendingLegacyOptIn] = useState<ClientAttachmentMetadata[]>([]);
  const [legacyOptInSaving, setLegacyOptInSaving] = useState(false);
  const [legacyOptInError, setLegacyOptInError] = useState('');
  const [legacyHistoryOpen, setLegacyHistoryOpen] = useState(false);
  const [legacyHistoryLoading, setLegacyHistoryLoading] = useState(false);
  const [legacyHistoryError, setLegacyHistoryError] = useState('');
  const [legacyProtections, setLegacyProtections] = useState<LegacyProtection[]>([]);
  const [legacyHistoryPage, setLegacyHistoryPage] = useState(1);
  const [legacyHistoryTotal, setLegacyHistoryTotal] = useState(0);
  const [pendingUndo, setPendingUndo] = useState<LegacyProtection | null>(null);
  const [undoSaving, setUndoSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const uploadInput = useRef<HTMLInputElement>(null);
  const accessOptionsRequested = useRef(false);
  const cursors = useRef<Record<number, string | undefined>>({});
  const request = useRef<AbortController | null>(null);

  useEffect(() => {
    const timer = window.setTimeout(() => setQuery(filter.trim()), 300);
    return () => window.clearTimeout(timer);
  }, [filter]);

  const load = useCallback(async (requestedPage = 1, cursor?: string) => {
    if (!clientId) return;
    request.current?.abort();
    const controller = new AbortController();
    request.current = controller;
    setLoading(true); setError('');
    try {
      const result = await api.get<AttachmentPage>('/api/client-attachments/', {
        clientId, module, targetType, targetId, search: query || undefined,
        limit: PAGE_SIZE, cursor,
      }, controller.signal);
      const rows = result.data || [];
      const pagination = result.pagination || {};
      setItems(rows);
      setTotal(typeof result.total === 'number' ? result.total : (pagination.total ?? rows.length));
      onCountChange?.(typeof result.total === 'number' ? result.total : (pagination.total ?? rows.length));
      const returnedCursor = result.nextCursor ?? pagination.nextCursor ?? null;
      setNextCursor(returnedCursor);
      setHasMore(typeof result.hasMore === 'boolean' ? result.hasMore : (pagination.hasMore ?? Boolean(returnedCursor)));
      setPage(requestedPage);
      if (returnedCursor) cursors.current[requestedPage + 1] = returnedCursor;
    } catch (err) {
      if ((err as Error).name !== 'AbortError') setError('Não foi possível carregar os documentos armazenados.');
    } finally {
      if (request.current === controller) setLoading(false);
    }
  }, [clientId, module, targetType, targetId, query, onCountChange]);

  useEffect(() => {
    cursors.current = {};
    setPage(1);
    load(1);
    return () => request.current?.abort();
  }, [load]);

  useEffect(() => {
    if (!clientId || accessOptionsRequested.current) return;
    accessOptionsRequested.current = true;
    api.get('/api/client-attachments/acl/options', { type: 'groups', limit: 1 })
      .then(() => setAccessOptionsLoaded(true))
      .catch(() => { accessOptionsRequested.current = false; });
  }, [clientId]);

  useEffect(() => {
    if (!clientId || !accessOptionsLoaded) return;
    let active = true;
    api.get<{ data: LegacyAclImpact }>(`/api/client-attachments/acl/legacy/${clientId}/impact`)
      .then(result => {
        if (active && result.data.clientId === clientId) setLegacyImpact(result.data);
      })
      .catch(() => undefined);
    return () => { active = false; };
  }, [clientId, accessOptionsLoaded]);

  useEffect(() => {
    setSelected(new Set());
    setSelectedItems(new Map());
    setLegacyImpact(null);
    setLegacyOptInModal(false);
    setPendingLegacyOptIn([]);
    setLegacyHistoryOpen(false);
    setLegacyProtections([]);
    setLegacyHistoryPage(1);
    setLegacyHistoryTotal(0);
    setPendingUndo(null);
  }, [clientId]);

  const editAccess = async (kind: 'folder' | 'file', attachment?: ClientAttachmentMetadata) => {
    if (!clientId || (kind === 'file' && !attachment)) return;
    setAccessModal({ kind, attachment });
    setAccessLoading(true);
    setAccessReady(false);
    setAccessError('');
    try {
      const result = kind === 'folder'
        ? await api.get<{ data: AccessDraft }>(`/api/client-attachments/acl/folders/${clientId}`)
        : await api.get<{ data: AccessDraft }>(`/api/client-attachments/acl/files/${attachment!.id}`);
      setAccessDraft({
        groupIds: result.data.groupIds || [],
        userIds: result.data.userIds || [],
        configured: result.data.configured,
        overrideEnabled: result.data.overrideEnabled,
      });
      setAccessReady(true);
    } catch (err: any) {
      setAccessError(err?.message || 'Não foi possível carregar as permissões.');
    } finally {
      setAccessLoading(false);
    }
  };

  const saveAccess = async () => {
    if (!accessModal || !clientId) return;
    setAccessSaving(true);
    setAccessError('');
    try {
      if (accessModal.kind === 'folder') {
        await api.put(`/api/client-attachments/acl/folders/${clientId}`, {
          groupIds: accessDraft.groupIds,
          userIds: accessDraft.userIds,
        });
      } else if (accessModal.attachment) {
        await api.put(`/api/client-attachments/acl/files/${accessModal.attachment.id}`, {
          overrideEnabled: accessDraft.overrideEnabled === true,
          groupIds: accessDraft.overrideEnabled ? accessDraft.groupIds : [],
          userIds: accessDraft.overrideEnabled ? accessDraft.userIds : [],
        });
      }
      setAccessModal(null);
      setError('');
      load(page, cursors.current[page]);
    } catch (err: any) {
      setAccessError(err?.message || 'Não foi possível salvar as permissões.');
    } finally {
      setAccessSaving(false);
    }
  };

  const changePage = (requestedPage: number) => {
    if (requestedPage < 1 || loading) return;
    if (requestedPage > page && !nextCursor) return;
    load(requestedPage, cursors.current[requestedPage]);
  };
  const toggle = (item: ClientAttachmentMetadata) => {
    setSelected(current => {
      const next = new Set(current);
      if (next.has(item.id)) next.delete(item.id); else next.add(item.id);
      return next;
    });
    setSelectedItems(current => {
      const next = new Map(current);
      if (next.has(item.id)) next.delete(item.id); else next.set(item.id, item);
      return next;
    });
  };
  const selectedLegacyItems = [...selectedItems.values()]
    .filter(item => item.clientId === clientId && item.aclProtected !== true);
  const selectLegacyPage = () => {
    const candidates = items.filter(item => item.aclProtected !== true);
    setSelected(current => new Set([...current, ...candidates.map(item => item.id)]));
    setSelectedItems(current => new Map([...current, ...candidates.map(item => [item.id, item] as const)]));
  };
  const openLegacyOptIn = async () => {
    if (!clientId || !selectedLegacyItems.length) return;
    setPendingLegacyOptIn(selectedLegacyItems);
    setLegacyOptInModal(true);
    setLegacyImpactLoading(true);
    setLegacyOptInError('');
    setSuccess('');
    try {
      const result = await api.get<{ data: LegacyAclImpact }>(`/api/client-attachments/acl/legacy/${clientId}/impact`);
      setLegacyImpact(result.data);
    } catch (err: any) {
      setLegacyOptInError(err?.message || 'Não foi possível calcular o impacto desta adesão.');
    } finally {
      setLegacyImpactLoading(false);
    }
  };
  const confirmLegacyOptIn = async () => {
    if (!clientId || !pendingLegacyOptIn.length || legacyImpact?.folderConfigured !== true) return;
    setLegacyOptInSaving(true);
    setLegacyOptInError('');
    try {
      const ids = pendingLegacyOptIn.map(item => item.id);
      await api.post(`/api/client-attachments/acl/legacy/${clientId}/protect`, { attachmentIds: ids });
      setLegacyOptInModal(false);
      setSelected(current => new Set([...current].filter(id => !ids.includes(id))));
      setSelectedItems(current => {
        const next = new Map(current);
        ids.forEach(id => next.delete(id));
        return next;
      });
      setLegacyImpact(current => current
        ? { ...current, legacyCount: Math.max(0, current.legacyCount - ids.length) }
        : current);
      setSuccess(`${ids.length} anexo(s) legado(s) agora seguem as regras de acesso do cliente.`);
      load(page, cursors.current[page]);
      api.get<{ data: LegacyAclImpact }>(`/api/client-attachments/acl/legacy/${clientId}/impact`)
        .then(result => setLegacyImpact(result.data))
        .catch(() => undefined);
    } catch (err: any) {
      setLegacyOptInError(err?.message || 'Não foi possível proteger os anexos selecionados.');
    } finally {
      setLegacyOptInSaving(false);
    }
  };
  const loadLegacyProtections = async (requestedPage = 1) => {
    if (!clientId) return;
    setLegacyHistoryLoading(true);
    setLegacyHistoryError('');
    try {
      const offset = (requestedPage - 1) * PAGE_SIZE;
      const result = await api.get<{
        data: LegacyProtection[];
        pagination: { total: number };
      }>(`/api/client-attachments/acl/legacy/${clientId}/protected`, { limit: PAGE_SIZE, offset });
      setLegacyProtections((result.data || []).map(item => ({
        id: item.id,
        originalFilename: item.originalFilename,
        module: item.module,
        category: item.category,
        adoptedByName: item.adoptedByName,
        adoptedAt: item.adoptedAt,
      })));
      setLegacyHistoryTotal(result.pagination?.total || 0);
      setLegacyHistoryPage(requestedPage);
    } catch (err: any) {
      setLegacyHistoryError(err?.message || 'Não foi possível carregar o histórico de proteção.');
    } finally {
      setLegacyHistoryLoading(false);
    }
  };
  const openLegacyHistory = () => {
    setLegacyHistoryOpen(true);
    loadLegacyProtections(1);
  };
  const undoLegacyProtection = async () => {
    if (!clientId || !pendingUndo) return;
    setUndoSaving(true);
    setLegacyHistoryError('');
    try {
      await api.delete(`/api/client-attachments/acl/legacy/${clientId}/protect/${pendingUndo.id}`);
      const nextTotal = Math.max(0, legacyHistoryTotal - 1);
      const nextPage = legacyProtections.length === 1 && legacyHistoryPage > 1
        ? legacyHistoryPage - 1 : legacyHistoryPage;
      setPendingUndo(null);
      setLegacyHistoryTotal(nextTotal);
      setSuccess('Proteção revertida. O anexo e o arquivo armazenado foram mantidos.');
      await loadLegacyProtections(nextPage);
      load(page, cursors.current[page]);
      api.get<{ data: LegacyAclImpact }>(`/api/client-attachments/acl/legacy/${clientId}/impact`)
        .then(result => setLegacyImpact(result.data))
        .catch(() => undefined);
    } catch (err: any) {
      setLegacyHistoryError(err?.message || 'Não foi possível reverter a proteção.');
    } finally {
      setUndoSaving(false);
    }
  };
  const openPreview = (item: ClientAttachmentMetadata) => {
    // Let the browser stream the response; do not copy the object into a Blob.
    window.open(`/api/client-attachments/${encodeURIComponent(item.id)}/content?browser=1`, '_blank', 'noopener,noreferrer');
  };
  const download = (item: ClientAttachmentMetadata) => {
    const anchor = document.createElement('a');
    anchor.href = `/api/client-attachments/${encodeURIComponent(item.id)}/download?browser=1`;
    // Let Content-Disposition start the download. The browser target also lets
    // a 504 render its retry page without replacing the attachment list.
    anchor.target = '_blank';
    anchor.rel = 'noopener noreferrer';
    anchor.click();
  };
  const requestDelete = (attachments: ClientAttachmentMetadata[]) => { setError(''); setPendingDelete(attachments); };
  const confirmDelete = async () => {
    setDeleting(true);
    const deleted = new Set<string>(); const failed: string[] = [];
    for (const item of pendingDelete) {
      setBusy(item.id);
      try { await api.delete(`/api/client-attachments/${item.id}`); deleted.add(item.id); }
      catch { failed.push(item.originalFilename); }
    }
    setSelected(current => new Set([...current].filter(id => !deleted.has(id))));
    setSelectedItems(current => { const next = new Map(current); deleted.forEach(id => next.delete(id)); return next; });
    setPendingDelete([]); setBusy(null); setDeleting(false);
    if (failed.length) setError(`${failed.length} anexo(s) não puderam ser excluídos: ${failed.join(', ')}`);
    load(page, cursors.current[page]);
  };
  const allPageSelected = items.length > 0 && items.every(item => selected.has(item.id));
  const togglePage = () => items.forEach(item => {
    if (allPageSelected && selected.has(item.id)) toggle(item);
    else if (!allPageSelected && !selected.has(item.id)) toggle(item);
  });
  const clientName = pendingDelete[0]?.clientName || items[0]?.clientName || 'Cliente selecionado';

  const uploadSelectedFile = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    event.target.value = '';
    if (!file || !clientId || !allowUpload || readOnly) return;
    setUploading(true);
    setError('');
    setSuccess('');
    try {
      if (file.size === 0 || file.size > 20 * 1024 * 1024) {
        throw new Error('Selecione um arquivo não vazio de até 20 MB.');
      }
      const checksum = Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256', await file.arrayBuffer())))
        .map(byte => byte.toString(16).padStart(2, '0')).join('');
      const metadata = {
        clientId,
        module: module || 'GENERAL',
        category: 'OUTRO',
        targetType: targetType || null,
        targetId: targetId || null,
        originalFilename: file.name,
        mimeType: file.type || 'application/octet-stream',
        fileSize: file.size,
        checksum,
      };
      const body = new FormData();
      body.append('metadata', JSON.stringify(metadata));
      body.append('file', file, file.name);
      const result = await apiRequest<{ duplicate?: boolean }>('/api/client-attachments/form-upload-stream', {
        method: 'POST', body, timeout: 120000, retries: 1,
      });
      setSuccess(result.duplicate ? 'Este arquivo já estava armazenado neste cadastro.' : 'Arquivo enviado e vinculado ao cadastro.');
      await load(1);
    } catch (err) {
      setError((err as Error).message || 'Não foi possível enviar o arquivo.');
    } finally {
      setUploading(false);
    }
  };

  if (!clientId) return null;
  return (
    <section className={`border border-slate-200 rounded-xl bg-white overflow-hidden ${compact ? '' : 'shadow-sm'}`}>
      <header className="px-4 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center gap-3">
        <div className="mr-auto"><h3 className="text-sm font-bold text-slate-800">Documentos armazenados</h3><p className="text-[11px] text-slate-500">Anexos classificados por cliente, separados dos anexos legados.</p></div>
        <span className="text-xs font-semibold text-slate-500">{total} documento{total === 1 ? '' : 's'}</span>
        {allowUpload && !readOnly && <>
          <input ref={uploadInput} type="file" className="hidden" onChange={uploadSelectedFile} />
          <button type="button" disabled={uploading} onClick={() => uploadInput.current?.click()} className="px-2.5 py-1.5 text-xs font-bold text-white bg-emerald-700 rounded-lg hover:bg-emerald-800 disabled:opacity-50">{uploading ? 'Enviando…' : 'Anexar arquivo'}</button>
        </>}
        {!readOnly && selected.size > 0 && <button type="button" onClick={() => requestDelete([...selectedItems.values()])} className="px-2.5 py-1.5 text-xs font-bold text-red-700 border border-red-300 rounded-lg hover:bg-red-50">Excluir selecionados ({selected.size})</button>}
        {!readOnly && accessOptionsLoaded && legacyImpact?.legacyCount ? <span className="text-xs font-semibold text-amber-800">{legacyImpact.legacyCount} legado{legacyImpact.legacyCount === 1 ? '' : 's'} sem ACL</span> : null}
        {!readOnly && accessOptionsLoaded && items.some(item => item.aclProtected !== true) && <button type="button" onClick={selectLegacyPage} className="px-2.5 py-1.5 text-xs font-bold text-amber-800 border border-amber-300 rounded-lg hover:bg-amber-50">Selecionar legados exibidos</button>}
        {!readOnly && accessOptionsLoaded && selectedLegacyItems.length > 0 && <button type="button" disabled={selectedLegacyItems.length > 500} onClick={openLegacyOptIn} className="px-2.5 py-1.5 text-xs font-bold text-indigo-700 border border-indigo-200 rounded-lg hover:bg-indigo-50 disabled:opacity-50">{selectedLegacyItems.length > 500 ? 'Selecione até 500 legados' : `Proteger selecionados (${selectedLegacyItems.length})`}</button>}
        {!readOnly && accessOptionsLoaded && <button type="button" onClick={() => editAccess('folder')} className="px-2.5 py-1.5 text-xs font-bold text-indigo-700 border border-indigo-200 rounded-lg hover:bg-indigo-50">Acesso da pasta</button>}
        {!readOnly && accessOptionsLoaded && <button type="button" onClick={openLegacyHistory} className="px-2.5 py-1.5 text-xs font-bold text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-100">Histórico ACL legado</button>}
        <input aria-label="Filtrar documentos" value={filter} onChange={e => setFilter(e.target.value)} placeholder="Filtrar..." className="w-32 px-2.5 py-1.5 text-xs border border-slate-300 rounded-lg" />
        <button type="button" onClick={() => load(page, cursors.current[page])} disabled={loading} className="px-2.5 py-1.5 text-xs font-bold text-emerald-700 border border-emerald-200 rounded-lg hover:bg-emerald-50 disabled:opacity-50">Atualizar</button>
      </header>
      {success && <div role="status" className="px-4 py-2 text-xs text-emerald-800 bg-emerald-50 border-b border-emerald-100">{success}</div>}
      {error && <div className="px-4 py-2 text-xs text-red-700 bg-red-50 border-b border-red-100">{error}</div>}
      {pendingDelete.length > 0 && <div role="alert" className="m-4 rounded-xl border-2 border-red-300 bg-red-50 p-4 text-red-900">
        <p className="text-sm font-black">Confirmar exclusão de anexos</p><p className="mt-1 text-xs"><strong>{clientName}</strong> perderá {pendingDelete.length} anexo{pendingDelete.length === 1 ? '' : 's'} permanentemente.</p>
        <ul className="mt-2 max-h-28 overflow-auto text-xs list-disc pl-5">{pendingDelete.map(item => <li key={item.id}>{item.originalFilename}</li>)}</ul>
        <div className="mt-3 flex gap-2"><button type="button" disabled={deleting} onClick={confirmDelete} className="px-3 py-1.5 rounded-lg bg-red-700 text-white text-xs font-bold disabled:opacity-50">{deleting ? 'Excluindo...' : 'Confirmar exclusão'}</button><button type="button" disabled={deleting} onClick={() => setPendingDelete([])} className="px-3 py-1.5 rounded-lg border border-red-300 text-xs font-bold">Cancelar</button></div>
      </div>}
      {loading ? <div className="p-4 space-y-2"><div className="h-8 rounded bg-slate-100 animate-pulse" /><div className="h-8 rounded bg-slate-100 animate-pulse" /></div> :
        items.length === 0 ? <div className="p-6 text-center text-xs text-slate-400">{query ? 'Nenhum documento encontrado.' : 'Nenhum documento armazenado para este contexto.'}</div> :
        <div>{!readOnly && <div className="px-4 py-2 border-b border-slate-100 bg-slate-50/60"><label className="inline-flex items-center gap-2 text-xs font-semibold text-slate-600"><input type="checkbox" checked={allPageSelected} onChange={togglePage} />Selecionar todos os anexos exibidos</label></div>}<div className="divide-y divide-slate-100">{items.map(item => <div key={item.id} className="px-4 py-3 flex items-center gap-3 hover:bg-slate-50 transition-colors">
          {!readOnly && <input aria-label={`Selecionar ${item.originalFilename}`} type="checkbox" checked={selected.has(item.id)} onChange={() => toggle(item)} />}
           <div className="w-9 h-9 rounded-lg bg-emerald-50 text-emerald-700 flex items-center justify-center text-[10px] font-black">{item.mimeType.includes('pdf') ? 'PDF' : 'DOC'}</div>
            <div className="min-w-0 flex-1"><p className="text-sm font-semibold text-slate-800 truncate">{item.originalFilename}</p><p className="text-[11px] text-slate-500">{item.category || 'Sem categoria'} · {moduleLabels[item.module] || item.module} · {formatBytes(item.fileSize)}{accessOptionsLoaded && item.aclProtected !== true ? ' · Legado sem ACL' : ''}</p></div>
            {(item.mimeType.startsWith('image/') || item.mimeType === 'application/pdf') && <button type="button" onClick={() => openPreview(item)} className="text-xs font-bold text-slate-700 hover:text-slate-900">Ver</button>}
             {!readOnly && accessOptionsLoaded && item.aclProtected && <button type="button" onClick={() => editAccess('file', item)} className="text-xs font-bold text-indigo-700 hover:text-indigo-900">Acesso</button>}
          <button type="button" onClick={() => download(item)} className="text-xs font-bold text-emerald-700 hover:text-emerald-900">Baixar</button>
           {!readOnly && <button type="button" disabled={busy === item.id} onClick={() => requestDelete([item])} className="text-xs font-bold text-red-600 hover:text-red-800 disabled:opacity-40">Excluir</button>}
        </div>)}</div></div>}
      {accessModal && <div className="fixed inset-0 z-[120] flex items-center justify-center bg-black/40 p-4" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget && !accessSaving) setAccessModal(null); }}>
        <section role="dialog" aria-modal="true" aria-labelledby="attachment-access-title" className="w-full max-w-xl rounded-xl bg-white p-5 shadow-xl">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 id="attachment-access-title" className="text-base font-bold text-slate-900">{accessModal.kind === 'folder' ? 'Acesso à pasta do cliente' : `Acesso: ${accessModal.attachment?.originalFilename || 'arquivo'}`}</h3>
              <p className="mt-1 text-xs text-slate-600">{accessModal.kind === 'folder'
                ? 'A regra afeta os anexos protegidos da pasta; módulos e unidades continuam sendo filtros obrigatórios.'
                : 'A exceção substitui os destinatários da pasta, mas não as permissões de módulo e unidade.'}</p>
            </div>
            <button type="button" disabled={accessSaving} onClick={() => setAccessModal(null)} aria-label="Fechar" className="text-slate-500 hover:text-slate-800">✕</button>
          </div>
          {accessLoading ? <p className="py-8 text-center text-sm text-slate-500">Carregando permissões…</p> : <>
            {accessModal.kind === 'file' && <label className="mt-4 flex items-start gap-2 text-sm text-slate-700">
              <input type="checkbox" checked={accessDraft.overrideEnabled === true} onChange={e => setAccessDraft(current => ({ ...current, overrideEnabled: e.target.checked, groupIds: e.target.checked ? current.groupIds : [], userIds: e.target.checked ? current.userIds : [] }))} />
              <span>Ativar exceção para este arquivo e substituir a regra da pasta.</span>
            </label>}
            {(accessModal.kind === 'folder' || accessDraft.overrideEnabled) && <div className="mt-4 grid gap-3 sm:grid-cols-2">
              <AclRecipientPicker kind="groups" selectedIds={accessDraft.groupIds} onChange={groupIds => setAccessDraft(current => ({ ...current, groupIds }))} />
              <AclRecipientPicker kind="users" selectedIds={accessDraft.userIds} onChange={userIds => setAccessDraft(current => ({ ...current, userIds }))} />
            </div>}
            {((accessModal.kind === 'folder' || accessDraft.overrideEnabled)
              && !accessDraft.groupIds.length && !accessDraft.userIds.length)
              && <p className="mt-2 text-xs text-amber-700">Sem grupos ou usuários selecionados: somente administradores terão acesso.</p>}
          </>}
          {accessError && <p role="alert" className="mt-3 text-xs text-red-700">{accessError}</p>}
          <div className="mt-5 flex justify-end gap-2">
            <button type="button" disabled={accessSaving} onClick={() => setAccessModal(null)} className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 disabled:opacity-50">Cancelar</button>
            <button type="button" disabled={accessSaving || accessLoading || !accessReady} onClick={saveAccess} className="rounded-lg bg-indigo-700 px-3 py-2 text-xs font-bold text-white disabled:opacity-50">{accessSaving ? 'Salvando…' : 'Salvar permissões'}</button>
          </div>
        </section>
      </div>}
      {legacyOptInModal && <div className="fixed inset-0 z-[121] flex items-center justify-center bg-black/50 p-4" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget && !legacyOptInSaving) setLegacyOptInModal(false); }}>
        <section role="dialog" aria-modal="true" aria-labelledby="legacy-acl-opt-in-title" className="w-full max-w-xl rounded-xl bg-white p-5 shadow-xl">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 id="legacy-acl-opt-in-title" className="text-base font-bold text-slate-900">Confirmar proteção de anexos legados</h3>
              <p className="mt-1 text-xs text-slate-600">A adesão afeta somente os arquivos listados. Eles também passarão a exigir a regra ACL da pasta, além das permissões atuais de módulo e unidade; a adesão nunca amplia essas permissões.</p>
            </div>
            <button type="button" disabled={legacyOptInSaving} onClick={() => setLegacyOptInModal(false)} aria-label="Fechar" className="text-slate-500 hover:text-slate-800">✕</button>
          </div>
          {legacyImpactLoading ? <p className="py-5 text-center text-sm text-slate-500">Calculando impacto…</p> : <>
            <div className="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-3 text-xs text-slate-700">
              <p><strong>{pendingLegacyOptIn.length}</strong> anexo(s) selecionado(s), de <strong>{legacyImpact?.legacyCount ?? '—'}</strong> legado(s) ainda sem ACL para este cliente.</p>
              {legacyImpact?.folderConfigured
                ? <p className="mt-1">Regra da pasta configurada para {legacyImpact.folderGroupGrantCount} grupo(s) e {legacyImpact.folderUserGrantCount} usuário(s).</p>
                : <p className="mt-1 font-semibold text-red-700">A regra da pasta ainda não está configurada. Configure-a antes de proteger anexos.</p>}
              {legacyImpact?.folderConfigured && !legacyImpact.folderGroupGrantCount && !legacyImpact.folderUserGrantCount
                && <p className="mt-1 font-semibold text-amber-800">Sem destinatários na regra: somente administradores poderão acessar esses arquivos depois da proteção.</p>}
            </div>
            <ul className="mt-3 max-h-48 overflow-auto rounded-lg border border-slate-200 divide-y divide-slate-100 text-xs">
              {pendingLegacyOptIn.map(item => <li key={item.id} className="px-3 py-2">
                <span className="font-semibold text-slate-800">{item.originalFilename}</span>
                <span className="ml-2 text-slate-500">{moduleLabels[item.module] || item.module} · {item.category || 'Sem categoria'}</span>
              </li>)}
            </ul>
          </>}
          {legacyOptInError && <p role="alert" className="mt-3 text-xs text-red-700">{legacyOptInError}</p>}
          <div className="mt-5 flex flex-wrap justify-end gap-2">
            {!legacyImpactLoading && legacyImpact?.folderConfigured !== true && <button type="button" disabled={legacyOptInSaving} onClick={() => { setLegacyOptInModal(false); editAccess('folder'); }} className="rounded-lg border border-indigo-300 px-3 py-2 text-xs font-semibold text-indigo-700 disabled:opacity-50">Configurar regra da pasta</button>}
            <button type="button" disabled={legacyOptInSaving} onClick={() => setLegacyOptInModal(false)} className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700 disabled:opacity-50">Cancelar</button>
            <button type="button" disabled={legacyOptInSaving || legacyImpactLoading || legacyImpact?.folderConfigured !== true || !pendingLegacyOptIn.length} onClick={confirmLegacyOptIn} className="rounded-lg bg-indigo-700 px-3 py-2 text-xs font-bold text-white disabled:opacity-50">{legacyOptInSaving ? 'Protegendo…' : `Confirmar proteção (${pendingLegacyOptIn.length})`}</button>
          </div>
        </section>
      </div>}
      {legacyHistoryOpen && <div className="fixed inset-0 z-[122] flex items-center justify-center bg-black/50 p-4" role="presentation" onMouseDown={event => { if (event.target === event.currentTarget && !undoSaving) { setLegacyHistoryOpen(false); setPendingUndo(null); } }}>
        <section role="dialog" aria-modal="true" aria-labelledby="legacy-acl-history-title" className="w-full max-w-3xl rounded-xl bg-white p-5 shadow-xl">
          <div className="flex items-start justify-between gap-3">
            <div>
              <h3 id="legacy-acl-history-title" className="text-base font-bold text-slate-900">Histórico de proteção dos anexos legados</h3>
              <p className="mt-1 text-xs text-slate-600">Responsável e data da adesão à regra ACL da pasta. Reverter a proteção não apaga o arquivo.</p>
            </div>
            <button type="button" disabled={undoSaving} onClick={() => { setLegacyHistoryOpen(false); setPendingUndo(null); }} aria-label="Fechar histórico" className="text-slate-500 hover:text-slate-800">✕</button>
          </div>
          {legacyHistoryError && <p role="alert" className="mt-3 rounded-lg bg-red-50 p-2 text-xs text-red-700">{legacyHistoryError}</p>}
          {legacyHistoryLoading ? <p className="py-10 text-center text-sm text-slate-500">Carregando histórico…</p>
            : legacyProtections.length === 0 ? <p className="py-10 text-center text-sm text-slate-500">Nenhum anexo legado protegido por adesão explícita.</p>
              : <div className="mt-4 max-h-[55vh] overflow-auto rounded-lg border border-slate-200 divide-y divide-slate-100">
                {legacyProtections.map(item => <div key={item.id} className="flex flex-wrap items-center gap-3 px-3 py-3">
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-semibold text-slate-800">{item.originalFilename}</p>
                    <p className="text-[11px] text-slate-500">{moduleLabels[item.module] || item.module} · {item.category || 'Sem categoria'}</p>
                    <p className="mt-1 text-xs text-slate-700">
                      Protegido por <strong>{item.adoptedByName || 'Usuário removido'}</strong>
                      · {formatDateTime(item.adoptedAt)}
                    </p>
                  </div>
                  <button type="button" disabled={undoSaving} onClick={() => setPendingUndo(item)} className="rounded-lg border border-amber-300 px-3 py-2 text-xs font-semibold text-amber-800 hover:bg-amber-50 disabled:opacity-50">Reverter proteção</button>
                </div>)}
              </div>}
          <div className="mt-4 flex items-center justify-between gap-3 text-xs text-slate-600">
            <span>{legacyHistoryTotal} proteção(ões) · página {legacyHistoryPage}</span>
            <div className="flex gap-2">
              <button type="button" disabled={legacyHistoryPage <= 1 || legacyHistoryLoading} onClick={() => loadLegacyProtections(legacyHistoryPage - 1)} className="rounded-lg border border-slate-300 px-3 py-1.5 disabled:opacity-40">Anterior</button>
              <button type="button" disabled={legacyHistoryPage * PAGE_SIZE >= legacyHistoryTotal || legacyHistoryLoading} onClick={() => loadLegacyProtections(legacyHistoryPage + 1)} className="rounded-lg border border-slate-300 px-3 py-1.5 disabled:opacity-40">Próxima</button>
            </div>
          </div>
        </section>
      </div>}
      {pendingUndo && <div className="fixed inset-0 z-[123] flex items-center justify-center bg-black/60 p-4" role="presentation">
        <section role="alertdialog" aria-modal="true" aria-labelledby="legacy-acl-undo-title" className="w-full max-w-md rounded-xl bg-white p-5 shadow-xl">
          <h3 id="legacy-acl-undo-title" className="text-base font-bold text-slate-900">Reverter a proteção deste anexo?</h3>
          <p className="mt-2 text-sm text-slate-700"><strong>{pendingUndo.originalFilename}</strong> voltará às regras de acesso que tinha antes da adesão ACL.</p>
          <p className="mt-2 text-xs text-slate-600">O arquivo armazenado e o registro permanecerão intactos. A reversão não contorna as permissões de módulo e unidade.</p>
          {legacyHistoryError && <p role="alert" className="mt-3 text-xs text-red-700">{legacyHistoryError}</p>}
          <div className="mt-5 flex justify-end gap-2">
            <button type="button" disabled={undoSaving} onClick={() => setPendingUndo(null)} className="rounded-lg border border-slate-300 px-3 py-2 text-xs font-semibold text-slate-700">Cancelar</button>
            <button type="button" disabled={undoSaving} onClick={undoLegacyProtection} className="rounded-lg bg-amber-700 px-3 py-2 text-xs font-bold text-white disabled:opacity-50">{undoSaving ? 'Revertendo…' : 'Confirmar reversão'}</button>
          </div>
        </section>
      </div>}
      {(page > 1 || hasMore || total > PAGE_SIZE) && <div className="flex items-center justify-between px-4 py-2 border-t border-gray-200 bg-gray-50 text-xs text-gray-600"><span>{total ? `${(page - 1) * PAGE_SIZE + 1}–${Math.min(page * PAGE_SIZE, total)} de ${total} registros` : 'Nenhum registro'}</span><div className="flex gap-2"><button type="button" onClick={() => changePage(page - 1)} disabled={page <= 1 || loading} className="px-2 py-1 disabled:opacity-40">‹ Anterior</button><span className="px-2 py-1">Página {page}</span><button type="button" onClick={() => changePage(page + 1)} disabled={!hasMore || loading} className="px-2 py-1 disabled:opacity-40">Próxima ›</button></div></div>}
    </section>
  );
}
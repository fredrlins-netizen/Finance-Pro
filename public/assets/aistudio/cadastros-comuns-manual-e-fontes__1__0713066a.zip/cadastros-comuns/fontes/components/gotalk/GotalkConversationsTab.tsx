import React, { useState, useEffect, useCallback, useRef } from 'react';
import GoTalkMediaRenderer from './GoTalkMediaRenderer';

interface GotalkMessage {
  id?: string;
  gotalk_message_id?: string;
  body: string | null;
  direction: 'IN' | 'OUT';
  message_type: string;
  sent_at?: string | null;
  attachment_url?: string | null;
  attachment_name?: string | null;
  attachment_mime_type?: string | null;
  attachment_size?: number | null;
  transcription?: string | null;
  operator_name?: string | null;
  department?: string | null;
  area?: string | null;
  ack_status?: number | null;
  template_body?: string | null;
  template_header?: string | null;
  template_footer?: string | null;
  template_category?: string | null;
  template_status?: string | null;
}

interface LinkedContact {
  id: string;
  name: string | null;
  phone_number: string | null;
}

interface Props {
  clientId: string;
}

const GotalkConversationsTab: React.FC<Props> = ({ clientId }) => {
  const [allMessages, setAllMessages] = useState<GotalkMessage[]>([]);
  const [contact, setContact] = useState<LinkedContact | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [linked, setLinked] = useState(false);

  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');
  const [filterOperator, setFilterOperator] = useState('');

  const messagesEndRef = useRef<HTMLDivElement>(null);

  const fetchData = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    else setRefreshing(true);
    try {
      const [contactRes, messagesRes] = await Promise.all([
        fetch(`/api/gotalk/client/${clientId}`),
        fetch(`/api/gotalk/messages/${clientId}?limit=500`),
      ]);
      if (contactRes.ok) {
        const d = await contactRes.json();
        setLinked(!!d.linked);
        if (d.linked && d.contact) setContact(d.contact);
        else setContact(null);
      }
      if (messagesRes.ok) {
        const d = await messagesRes.json();
        setAllMessages(d.data || []);
      }
    } finally {
      if (!silent) setLoading(false);
      else setRefreshing(false);
    }
  }, [clientId]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [allMessages, filterDateFrom, filterDateTo, filterOperator]);

  const operatorOptions = React.useMemo(() => {
    const ops = new Set<string>();
    allMessages.forEach(m => {
      if (m.operator_name) ops.add(m.operator_name);
    });
    return Array.from(ops).sort();
  }, [allMessages]);

  const filteredMessages = React.useMemo(() => {
    return allMessages.filter(msg => {
      if (filterDateFrom && msg.sent_at) {
        const msgDate = msg.sent_at.split('T')[0];
        if (msgDate < filterDateFrom) return false;
      }
      if (filterDateTo && msg.sent_at) {
        const msgDate = msg.sent_at.split('T')[0];
        if (msgDate > filterDateTo) return false;
      }
      if (filterOperator) {
        const op = msg.operator_name || '';
        if (!op.toLowerCase().includes(filterOperator.toLowerCase())) return false;
      }
      return true;
    });
  }, [allMessages, filterDateFrom, filterDateTo, filterOperator]);

  const formatTime = (iso?: string | null) => {
    if (!iso) return '';
    return new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  const formatDay = (iso?: string | null) => {
    if (!iso) return '';
    return new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: 'numeric' });
  };

  const renderAckIcon = (ackStatus: number | null | undefined) => {
    if (ackStatus === null || ackStatus === undefined) return null;
    if (ackStatus === 1) {
      return (
        <svg className="inline w-3.5 h-3 ml-0.5 opacity-60" viewBox="0 0 16 11" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="1,5.5 5.5,10 15,1" />
        </svg>
      );
    }
    if (ackStatus === 2) {
      return (
        <svg className="inline w-4 h-3 ml-0.5 opacity-60" viewBox="0 0 20 11" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="1,5.5 5.5,10 15,1" />
          <polyline points="6,5.5 10.5,10 20,1" />
        </svg>
      );
    }
    if (ackStatus >= 3) {
      return (
        <svg className="inline w-4 h-3 ml-0.5" viewBox="0 0 20 11" fill="none" stroke="#53bdeb" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="1,5.5 5.5,10 15,1" />
          <polyline points="6,5.5 10.5,10 20,1" />
        </svg>
      );
    }
    return null;
  };


  const clearFilters = () => {
    setFilterDateFrom('');
    setFilterDateTo('');
    setFilterOperator('');
  };

  const hasFilters = filterDateFrom || filterDateTo || filterOperator;

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16 text-gray-400 text-sm">
        Carregando conversas...
      </div>
    );
  }

  if (!linked) {
    return (
      <div className="flex flex-col items-center justify-center py-16 gap-3 text-gray-400">
        <svg className="w-12 h-12 text-gray-200" fill="currentColor" viewBox="0 0 24 24">
          <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.890-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z" />
        </svg>
        <p className="text-sm">Nenhum contato WhatsApp vinculado a este cliente.</p>
        <p className="text-xs text-gray-300">Acesse a aba "Dados do Cliente" e use a seção WhatsApp/Gotalk para vincular.</p>
      </div>
    );
  }

  let lastDay = '';

  return (
    <div className="whatsapp-theme flex flex-col gap-4">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-2">
          {contact && (
            <div className="flex items-center gap-2 text-sm text-gray-700">
              <div className="w-7 h-7 rounded-full bg-green-500 flex items-center justify-center text-white font-bold text-xs">
                {((contact.name || '?')[0]).toUpperCase()}
              </div>
              <span className="font-medium">{contact.name || 'Contato'}</span>
              <span className="text-gray-400">{contact.phone_number}</span>
            </div>
          )}
          <span className="text-xs bg-gray-100 text-gray-500 px-2 py-0.5 rounded-full">
            {filteredMessages.length} mensagem{filteredMessages.length !== 1 ? 's' : ''}
            {allMessages.length !== filteredMessages.length && ` de ${allMessages.length}`}
          </span>
        </div>
        <button
          type="button"
          onClick={() => fetchData(true)}
          disabled={refreshing}
          className="flex items-center gap-1.5 text-xs text-gray-500 hover:text-gray-700 border border-gray-200 hover:border-gray-300 px-3 py-1.5 rounded-lg transition-colors disabled:opacity-50"
        >
          <svg className={`w-3.5 h-3.5 ${refreshing ? 'animate-spin' : ''}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
          </svg>
          Atualizar
        </button>
      </div>

      <div className="bg-gray-50 border border-gray-200 rounded-lg p-3 flex flex-wrap gap-3 items-end">
        <div className="flex flex-col gap-1 min-w-[140px]">
          <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Data Inicial</label>
          <input
            type="date"
            value={filterDateFrom}
            onChange={e => setFilterDateFrom(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 outline-none bg-white"
          />
        </div>
        <div className="flex flex-col gap-1 min-w-[140px]">
          <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Data Final</label>
          <input
            type="date"
            value={filterDateTo}
            onChange={e => setFilterDateTo(e.target.value)}
            className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 outline-none bg-white"
          />
        </div>
        <div className="flex flex-col gap-1 flex-1 min-w-[160px]">
          <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">Atendente</label>
          {operatorOptions.length > 0 ? (
            <select
              value={filterOperator}
              onChange={e => setFilterOperator(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 outline-none bg-white"
            >
              <option value="">Todos os atendentes</option>
              {operatorOptions.map(op => (
                <option key={op} value={op}>{op}</option>
              ))}
            </select>
          ) : (
            <input
              type="text"
              value={filterOperator}
              onChange={e => setFilterOperator(e.target.value)}
              placeholder="Filtrar por atendente..."
              className="border border-gray-300 rounded-lg px-3 py-2 text-sm focus:ring-2 focus:ring-indigo-400 focus:border-indigo-400 outline-none bg-white"
            />
          )}
        </div>
        {hasFilters && (
          <button
            type="button"
            onClick={clearFilters}
            className="flex items-center gap-1.5 text-xs text-red-500 hover:text-red-700 border border-red-200 hover:border-red-400 px-3 py-2 rounded-lg transition-colors"
          >
            <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
            Limpar Filtros
          </button>
        )}
      </div>

      <div
        className="whatsapp-timeline rounded-lg overflow-y-auto px-4 py-3 space-y-2 border border-gray-200"
        style={{ background: '#e5ddd5', minHeight: '320px', maxHeight: '500px' }}
      >
        {filteredMessages.length === 0 && (
          <div className="flex items-center justify-center h-40 text-gray-500 text-sm">
            {hasFilters ? 'Nenhuma mensagem encontrada com os filtros aplicados.' : 'Nenhuma mensagem registrada.'}
          </div>
        )}
        {filteredMessages.map((msg, idx) => {
          const day = formatDay(msg.sent_at);
          const showDayLabel = day !== lastDay;
          if (showDayLabel) lastDay = day;
          const isOut = msg.direction === 'OUT';

          return (
            <React.Fragment key={msg.gotalk_message_id || msg.id || idx}>
              {showDayLabel && day && (
                <div className="flex justify-center my-2">
                  <span className="whatsapp-date-pill text-xs bg-white/70 text-gray-600 px-3 py-1 rounded-full shadow-sm">
                    {day}
                  </span>
                </div>
              )}
              <div className={`flex ${isOut ? 'justify-end' : 'justify-start'}`}>
                <div
                  className={`max-w-[70%] px-3 py-2 rounded-lg shadow-sm ${isOut ? 'whatsapp-bubble-out' : 'whatsapp-bubble-in'} ${
                    isOut ? 'bg-[#dcf8c6] text-gray-800' : 'bg-white text-gray-800'
                  }`}
                >
                  <GoTalkMediaRenderer
                    messageId={msg.id}
                    messageType={msg.message_type}
                    attachmentUrl={msg.attachment_url}
                    attachmentName={msg.attachment_name}
                    attachmentMime={msg.attachment_mime_type}
                    attachmentSize={msg.attachment_size}
                    audioTranscript={msg.transcription}
                    caption={msg.body}
                    templateBody={msg.template_body}
                    templateHeader={msg.template_header}
                    templateFooter={msg.template_footer}
                    templateCategory={msg.template_category}
                    templateStatus={msg.template_status}
                  />
                  <div className={`flex items-center gap-0.5 mt-0.5 ${isOut ? 'justify-end' : 'justify-start'}`}>
                    <span className={`text-[10px] ${isOut ? 'text-green-700' : 'text-gray-400'}`}>
                      {formatTime(msg.sent_at)}
                    </span>
                    {isOut && renderAckIcon(msg.ack_status)}
                  </div>
                  {isOut && msg.operator_name && (
                    <p className="text-[10px] text-green-700 opacity-70 mt-0.5 text-right">
                      {[msg.operator_name, msg.department || msg.area].filter(Boolean).join(' · ')}
                    </p>
                  )}
                </div>
              </div>
            </React.Fragment>
          );
        })}
        <div ref={messagesEndRef} />
      </div>
    </div>
  );
};

export default GotalkConversationsTab;

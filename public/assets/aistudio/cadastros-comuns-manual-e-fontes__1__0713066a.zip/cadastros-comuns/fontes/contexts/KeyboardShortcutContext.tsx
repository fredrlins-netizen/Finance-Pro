import React, { createContext, useContext, useEffect, useRef, useCallback } from 'react';

interface FormHandlers {
  onSave?: () => void;
  onCancel?: () => void;
}

interface KeyboardShortcutContextValue {
  registerFormActions: (onSave?: () => void, onCancel?: () => void) => void;
  unregisterFormActions: () => void;
}

const KeyboardShortcutContext = createContext<KeyboardShortcutContextValue | null>(null);

export const KeyboardShortcutProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const handlersRef = useRef<FormHandlers>({});

  const registerFormActions = useCallback((onSave?: () => void, onCancel?: () => void) => {
    handlersRef.current = { onSave, onCancel };
  }, []);

  const unregisterFormActions = useCallback(() => {
    handlersRef.current = {};
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        if (handlersRef.current.onSave) {
          e.preventDefault();
          handlersRef.current.onSave();
        }
        return;
      }

    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <KeyboardShortcutContext.Provider value={{ registerFormActions, unregisterFormActions }}>
      {children}
    </KeyboardShortcutContext.Provider>
  );
};

export const useKeyboardShortcut = (): KeyboardShortcutContextValue => {
  const ctx = useContext(KeyboardShortcutContext);
  if (!ctx) {
    return { registerFormActions: () => {}, unregisterFormActions: () => {} };
  }
  return ctx;
};

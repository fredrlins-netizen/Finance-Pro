/**
 * TÍTULO: CONTEXTO DE SEGURANÇA E PERMISSÕES
 * 
 * Este contexto é o "Guardião" da aplicação.
 * 
 * Responsabilidades:
 * 1. Gerenciar o estado global de notificações (Toasts).
 * 2. Fornecer a função `validarPermissao` que verifica se o usuário logado
 *    possui a permissão necessária baseada em seus grupos.
 * 3. Se a validação falhar, exibe automaticamente uma mensagem visual.
 * 4. Fornecer `temPermissao` (visibilidade no menu) e `temAcesso` (acesso real ao módulo).
 *    - temPermissao(id): true se o grupo tem o checkbox base do módulo marcado → item aparece no menu.
 *    - temAcesso(id): true se o grupo tem ao menos uma ação (V/I/A/E/C/X/P) para o módulo → acesso liberado.
 */

import React, { createContext, useContext, useState, ReactNode, useCallback, useMemo } from 'react';
import { User, UserPermission, PortalConfig } from '../types';
import ToastContainer, { ToastMessage, ToastType } from '../components/ui/Toast';

const ACOES_PERMISSAO = ['VISUALIZAR', 'INCLUIR', 'ALTERAR', 'EXCLUIR', 'CANCELAR', 'INATIVAR', 'IMPRIMIR'];

interface SecurityContextData {
  validarPermissao: (permission: UserPermission) => boolean;
  temPermissao: (permission: UserPermission) => boolean;
  temAcesso: (moduleId: string) => boolean;
  addToast: (type: ToastType, title: string, message: string, onAction?: () => void, actionLabel?: string) => void;
  currentUser: User | null;
  isLoggedAdmin: boolean;
}

interface SecurityProviderProps {
  children: ReactNode;
  currentUser: User | null;
  config: PortalConfig;
}

const SecurityContext = createContext<SecurityContextData>({} as SecurityContextData);

export const SecurityProvider: React.FC<SecurityProviderProps> = ({ children, currentUser, config }) => {
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  const addToast = useCallback((type: ToastType, title: string, message: string, onAction?: () => void, actionLabel?: string) => {
    const id = Math.random().toString(36).substr(2, 9);
    setToasts([{ id, type, title, message, onAction, actionLabel }]);
  }, []);

  const removeToast = useCallback((id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  const checarPermissao = useCallback((permission: UserPermission): boolean => {
    if (!currentUser) return false;
    if (currentUser.role === 'ADMIN') return true;

    const userGroupIds = currentUser.groupIds || [];
    const allGroups = config.userGroups || [];
    const myGroups = allGroups.filter(g => userGroupIds.includes(g.id));

    return myGroups.some(g => {
        if (g.permissions.includes(permission)) return true;
        if (!permission.includes(':')) {
           return g.permissions.some(p => p.endsWith(`:${permission}`) || p === permission);
        }
        const action = permission.split(':').pop();
        if (action && g.permissions.includes(action as UserPermission)) return true;
        return false;
    });
  }, [currentUser, config.userGroups]);

  const temPermissao = useCallback((permission: UserPermission): boolean => {
    return checarPermissao(permission);
  }, [checarPermissao]);

  /**
   * Verifica se o usuário tem acesso REAL a um módulo, ou seja, possui ao menos
   * uma permissão de ação (VISUALIZAR, INCLUIR, ALTERAR, EXCLUIR, CANCELAR,
   * INATIVAR ou IMPRIMIR) para esse módulo.
   *
   * Diferença em relação a `temPermissao`:
   *  - temPermissao(moduleId) → verifica apenas o checkbox base (visibilidade no menu).
   *  - temAcesso(moduleId)    → verifica se alguma ação foi concedida (acesso à tela).
   */
  const temAcesso = useCallback((moduleId: string): boolean => {
    if (!currentUser) return false;
    if (currentUser.role === 'ADMIN') return true;

    const userGroupIds = currentUser.groupIds || [];
    const allGroups = config.userGroups || [];
    const myGroups = allGroups.filter(g => userGroupIds.includes(g.id));

    return myGroups.some(g =>
      ACOES_PERMISSAO.some(acao =>
        g.permissions.includes(`${moduleId}:${acao}` as UserPermission)
      )
    );
  }, [currentUser, config.userGroups]);

  const validarPermissao = useCallback((permission: UserPermission): boolean => {
    if (!currentUser) {
      addToast('error', 'Sessão Expirada', 'Por favor, faça login novamente.');
      return false;
    }

    const hasPermission = checarPermissao(permission);

    if (!hasPermission) {
      addToast(
        'error', 
        'Acesso Negado', 
        `Você não tem permissão para: ${permission}`
      );
      return false;
    }

    return true;
  }, [currentUser, checarPermissao, addToast]);

  const isLoggedAdmin = currentUser?.role === 'ADMIN';

  const contextValue = useMemo(() => ({
    validarPermissao,
    temPermissao,
    temAcesso,
    addToast,
    currentUser,
    isLoggedAdmin,
  }), [validarPermissao, temPermissao, temAcesso, addToast, currentUser, isLoggedAdmin]);

  return (
    <SecurityContext.Provider value={contextValue}>
      {children}
      <ToastContainer toasts={toasts} removeToast={removeToast} />
    </SecurityContext.Provider>
  );
};

export const useSecurity = () => {
  const context = useContext(SecurityContext);
  if (!context) {
    throw new Error('useSecurity deve ser usado dentro de um SecurityProvider');
  }
  return context;
};

/**
 * TÍTULO: CONTEXTO DE AUDITORIA
 *
 * Responsável por centralizar a lógica de gravação de logs de operações.
 * Intercepta as ações de CRUD e salva o histórico no estado global
 * A persistência é feita exclusivamente pelo servidor durante a operação real.
 */

import React, { createContext, useContext, ReactNode, useCallback, useMemo } from 'react';
import { PortalConfig, User, AuditLog, AuditEntity, AuditAction } from '../types';
import { compareObjects, generateAuditDescription } from '../utils/auditUtils';

interface AuditContextData {
  logTransaction: (
    entity: AuditEntity,
    recordId: string,
    oldData: any | null,
    newData: any | null,
    customUnitId?: string,
    customAction?: AuditAction
  ) => void;
}

interface AuditProviderProps {
  children: ReactNode;
  currentUser: User | null;
  config: PortalConfig;
  onAppendAuditLog: (newLog: AuditLog) => void;
}

const AuditContext = createContext<AuditContextData>({} as AuditContextData);

export const AuditProvider: React.FC<AuditProviderProps> = ({
  children,
  currentUser,
  config,
  onAppendAuditLog
}) => {

  const logTransaction = useCallback((
    entity: AuditEntity,
    recordId: string,
    oldData: any | null,
    newData: any | null,
    customUnitId?: string,
    customAction?: AuditAction
  ) => {
    if (!currentUser) return;

    const timestamp = new Date().toISOString();
    const unitId = customUnitId || (currentUser.allowedUnitIds && currentUser.allowedUnitIds.length > 0 ? currentUser.allowedUnitIds[0] : 'GLOBAL');
    let action: AuditAction = 'UPDATE';
    let changes: any[] = [];

    if (customAction) {
      action = customAction;
      if (oldData && newData) {
        changes = compareObjects(oldData, newData, ['updatedAt']);
      }
    } else if (!oldData && newData) {
      action = 'CREATE';
    } else if (oldData && !newData) {
      action = 'DELETE';
    } else if (oldData && newData) {
      action = 'UPDATE';
      changes = compareObjects(oldData, newData, ['updatedAt']);
      if (changes.length === 0) return;
    }

    const description = generateAuditDescription(action, entity, recordId, changes.length);

    const newLog: AuditLog = {
      id: `log-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      timestamp,
      userId: currentUser.id,
      userName: currentUser.name,
      unitId,
      entity,
      entityId: recordId,
      action,
      changes,
      description
    };

    onAppendAuditLog(newLog);

  }, [currentUser, onAppendAuditLog]);

  const contextValue = useMemo(() => ({ logTransaction }), [logTransaction]);

  return (
    <AuditContext.Provider value={contextValue}>
      {children}
    </AuditContext.Provider>
  );
};

export const useAudit = () => {
  const context = useContext(AuditContext);
  if (!context) {
    throw new Error('useAudit deve ser usado dentro de um AuditProvider');
  }
  return context;
};

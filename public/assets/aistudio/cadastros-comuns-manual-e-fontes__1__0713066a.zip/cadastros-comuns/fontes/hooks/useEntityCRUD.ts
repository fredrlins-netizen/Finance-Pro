import { useState, useCallback, useRef, useEffect } from 'react';
import { api, ApiError, ApiItemResponse, ApiListResponse } from '../services/apiService';

interface CacheEntry<T> {
  data: T[];
  total: number;
  totalPages: number;
  timestamp: number;
}

const STALE_TIME = 30_000;
const MAX_CACHE_SIZE = 50;
const entityCache = new Map<string, CacheEntry<any>>();
const inflightRequests = new Map<string, Promise<{ data: any[]; total: number; totalPages: number }>>();

function evictOldestCacheEntry() {
  let oldestKey = '';
  let oldestTime = Infinity;
  for (const [key, entry] of entityCache) {
    if (entry.timestamp < oldestTime) {
      oldestTime = entry.timestamp;
      oldestKey = key;
    }
  }
  if (oldestKey) entityCache.delete(oldestKey);
}

export interface UseEntityCRUDOptions {
  autoLoad?: boolean;
  staleTime?: number;
  pageSize?: number;
  extraParams?: Record<string, string | number>;
}

export interface UseEntityCRUDReturn<T> {
  data: T[];
  total: number;
  currentPage: number;
  totalPages: number;
  loading: boolean;
  error: string | null;
  create: (item: Partial<T>) => Promise<T>;
  update: (id: string, item: Partial<T>) => Promise<T>;
  remove: (id: string) => Promise<void>;
  refresh: () => Promise<void>;
  search: (term: string) => Promise<void>;
  setFilters: (filters: Record<string, string | number>) => Promise<void>;
  getById: (id: string) => Promise<T>;
  clearError: () => void;
  goToPage: (page: number) => Promise<void>;
}

export function useEntityCRUD<T extends { id: string }>(
  entityPath: string,
  options: UseEntityCRUDOptions = {}
): UseEntityCRUDReturn<T> {
  const {
    autoLoad = true,
    staleTime = STALE_TIME,
    pageSize = 50,
    extraParams,
  } = options;

  const [data, setData] = useState<T[]>([]);
  const [total, setTotal] = useState(0);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const mountedRef = useRef(true);
  const currentSearchRef = useRef('');
  const currentPageRef = useRef(1);
  const dynamicFiltersRef = useRef<Record<string, string | number>>({});

  useEffect(() => {
    mountedRef.current = true;
    return () => { mountedRef.current = false; };
  }, []);

  const apiPath = entityPath.startsWith('/') ? entityPath : `/api/${entityPath}`;

  const extraParamsKey = extraParams ? JSON.stringify(extraParams) : '';

  const getCacheKey = useCallback((page: number, searchTerm?: string) => {
    const base = extraParamsKey ? `${apiPath}[${extraParamsKey}]` : apiPath;
    const dynFilters = dynamicFiltersRef.current;
    const dynKey = Object.keys(dynFilters).length > 0 ? `[f:${JSON.stringify(dynFilters)}]` : '';
    const searchPart = searchTerm ? `&search=${encodeURIComponent(searchTerm)}` : '';
    return `${base}${dynKey}?page=${page}${searchPart}`;
  }, [apiPath, extraParamsKey]);

  const invalidateCache = useCallback(() => {
    for (const key of Array.from(entityCache.keys())) {
      if (key.startsWith(apiPath)) {
        entityCache.delete(key);
      }
    }
  }, [apiPath]);

  const loadData = useCallback(async (searchTerm?: string, page?: number) => {
    const targetPage = page ?? currentPageRef.current;
    const cacheKey = getCacheKey(targetPage, searchTerm);

    const cached = entityCache.get(cacheKey);
    const isStale = !cached || (Date.now() - cached.timestamp > staleTime);

    if (cached && !isStale) {
      if (mountedRef.current) {
        setData(cached.data);
        setTotal(cached.total);
        setTotalPages(cached.totalPages);
        setCurrentPage(targetPage);
      }
      return;
    }

    if (mountedRef.current) setLoading(true);

    const inflightKey = cacheKey;

    try {
      let fetchPromise = inflightRequests.get(inflightKey);

      if (!fetchPromise) {
        const params: Record<string, string | number> = {
          limit: pageSize,
          page: targetPage,
        };
        if (searchTerm) {
          params.search = searchTerm;
        }
        if (extraParams) {
          Object.assign(params, extraParams);
        }
        const dynFilters = dynamicFiltersRef.current;
        if (Object.keys(dynFilters).length > 0) {
          Object.assign(params, dynFilters);
        }

        fetchPromise = api.get<ApiListResponse<T>>(apiPath, params).then(result => ({
          data: result.data,
          total: result.total,
          totalPages: result.totalPages ?? (Math.ceil(result.total / pageSize) || 1),
        }));

        inflightRequests.set(inflightKey, fetchPromise);
        fetchPromise.finally(() => {
          inflightRequests.delete(inflightKey);
        });
      }

      const result = await fetchPromise;

      if (mountedRef.current) {
        setData(result.data);
        setTotal(result.total);
        setTotalPages(result.totalPages);
        setCurrentPage(targetPage);
        currentPageRef.current = targetPage;
        setError(null);
      }

      if (entityCache.size >= MAX_CACHE_SIZE) {
        evictOldestCacheEntry();
      }
      entityCache.set(cacheKey, {
        data: result.data,
        total: result.total,
        totalPages: result.totalPages,
        timestamp: Date.now(),
      });
    } catch (err) {
      if (mountedRef.current) {
        setError(err instanceof ApiError ? err.message : 'Erro ao carregar dados');
      }
    } finally {
      if (mountedRef.current) setLoading(false);
    }
  }, [apiPath, pageSize, staleTime, getCacheKey]);

  useEffect(() => {
    if (autoLoad) {
      loadData();
    }
  }, [autoLoad, loadData]);

  const create = useCallback(async (item: Partial<T>): Promise<T> => {
    setError(null);
    const optimisticId = `temp-${Date.now()}`;
    const optimisticItem = { ...item, id: optimisticId } as T;

    setData(prev => [optimisticItem, ...prev]);
    setTotal(prev => prev + 1);

    try {
      const result = await api.post<ApiItemResponse<T>>(apiPath, item);

      setData(prev =>
        prev.map(d => (d.id === optimisticId ? result.data : d))
      );

      invalidateCache();
      return result.data;
    } catch (err) {
      setData(prev => prev.filter(d => d.id !== optimisticId));
      setTotal(prev => prev - 1);

      const message = err instanceof ApiError ? err.message : 'Erro ao criar registro';
      setError(message);
      throw err;
    }
  }, [apiPath, invalidateCache]);

  const update = useCallback(async (id: string, item: Partial<T>): Promise<T> => {
    setError(null);
    const previousData = data;

    setData(prev =>
      prev.map(d => (d.id === id ? { ...d, ...item } : d))
    );

    try {
      const result = await api.put<ApiItemResponse<T>>(`${apiPath}/${id}`, item);

      setData(prev =>
        prev.map(d => (d.id === id ? result.data : d))
      );

      invalidateCache();
      return result.data;
    } catch (err) {
      setData(previousData);

      const message = err instanceof ApiError ? err.message : 'Erro ao atualizar registro';
      setError(message);
      throw err;
    }
  }, [apiPath, data, invalidateCache]);

  const remove = useCallback(async (id: string): Promise<void> => {
    setError(null);
    const previousData = data;
    const previousTotal = total;

    setData(prev => prev.filter(d => d.id !== id));
    setTotal(prev => prev - 1);

    try {
      await api.delete(`${apiPath}/${id}`);
      invalidateCache();
    } catch (err) {
      setData(previousData);
      setTotal(previousTotal);

      const message = err instanceof ApiError ? err.message : 'Erro ao excluir registro';
      setError(message);
      throw err;
    }
  }, [apiPath, data, total, invalidateCache]);

  const refresh = useCallback(async () => {
    invalidateCache();
    await loadData(currentSearchRef.current || undefined, currentPageRef.current);
  }, [invalidateCache, loadData]);

  const search = useCallback(async (term: string) => {
    if (term === currentSearchRef.current) return;
    currentSearchRef.current = term;
    currentPageRef.current = 1;
    setCurrentPage(1);
    await loadData(term || undefined, 1);
  }, [loadData]);

  const getById = useCallback(async (id: string): Promise<T> => {
    try {
      const result = await api.get<ApiItemResponse<T>>(`${apiPath}/${id}`);
      return result.data;
    } catch (err) {
      throw err;
    }
  }, [apiPath]);

  const setFilters = useCallback(async (filters: Record<string, string | number>) => {
    if (JSON.stringify(filters) === JSON.stringify(dynamicFiltersRef.current)) return;
    dynamicFiltersRef.current = filters;
    invalidateCache();
    currentPageRef.current = 1;
    setCurrentPage(1);
    await loadData(currentSearchRef.current || undefined, 1);
  }, [invalidateCache, loadData]);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  const goToPage = useCallback(async (page: number) => {
    if (page < 1 || (totalPages > 0 && page > totalPages)) return;
    currentPageRef.current = page;
    entityCache.delete(getCacheKey(page, currentSearchRef.current || undefined));
    await loadData(currentSearchRef.current || undefined, page);
  }, [loadData, totalPages, getCacheKey]);

  return {
    data,
    total,
    currentPage,
    totalPages,
    loading,
    error,
    create,
    update,
    remove,
    refresh,
    search,
    setFilters,
    getById,
    clearError,
    goToPage,
  };
}

export function invalidateEntityCache(entityPath?: string) {
  if (entityPath) {
    const key = entityPath.startsWith('/') ? entityPath : `/api/${entityPath}`;
    for (const k of Array.from(entityCache.keys())) {
      if (k.startsWith(key)) entityCache.delete(k);
    }
  } else {
    entityCache.clear();
  }
}

import { PortalConfig } from '../types';

export interface DependencyResult {
    canDelete: boolean;
    dependencies: string[];
}

export function checkDependencies(
    entityType: string,
    entityId: string,
    config: PortalConfig
): DependencyResult {
    const deps: string[] = [];

    switch (entityType) {
        case 'client': {
            const admCount = (config.admissions || []).filter(a => a.clientId === entityId).length;
            if (admCount > 0) deps.push(`${admCount} admiss${admCount > 1 ? 'ões' : 'ão'}`);

            const apptCount = (config.appointments || []).filter(a => a.clientId === entityId).length;
            if (apptCount > 0) deps.push(`${apptCount} agendamento${apptCount > 1 ? 's' : ''}`);

            const waitCount = (config.waitlist || []).filter(w => w.clientId === entityId).length;
            if (waitCount > 0) deps.push(`${waitCount} item(ns) na fila de espera`);
            break;
        }

        case 'collaborator': {
            const admCount = (config.admissions || []).filter(a => a.collaboratorId === entityId).length;
            if (admCount > 0) deps.push(`${admCount} admiss${admCount > 1 ? 'ões' : 'ão'}`);

            const apptCount = (config.appointments || []).filter(a => a.collaboratorId === entityId).length;
            if (apptCount > 0) deps.push(`${apptCount} agendamento${apptCount > 1 ? 's' : ''}`);

            const blockCount = (config.scheduleBlocks || []).filter(b => b.collaboratorId === entityId).length;
            if (blockCount > 0) deps.push(`${blockCount} bloqueio${blockCount > 1 ? 's' : ''} de agenda`);

            const waitCount = (config.waitlist || []).filter(w => w.collaboratorId === entityId).length;
            if (waitCount > 0) deps.push(`${waitCount} item(ns) na fila de espera`);

            const queueRefs = (config.schedulingQueue || []).filter(q => q.collaboratorIds.includes(entityId)).length;
            if (queueRefs > 0) deps.push(`${queueRefs} fila(s) de agendamento`);

            const userRefs = (config.users || []).filter(u => u.collaboratorId === entityId).length;
            if (userRefs > 0) deps.push(`${userRefs} usuário${userRefs > 1 ? 's' : ''} vinculado${userRefs > 1 ? 's' : ''}`);
            break;
        }

        case 'bank': {
            const admCount = (config.admissions || []).filter(a => a.bankId === entityId).length;
            if (admCount > 0) deps.push(`${admCount} admiss${admCount > 1 ? 'ões' : 'ão'}`);

            const acctCount = (config.bankAccounts || []).filter(a => a.bankId === entityId).length;
            if (acctCount > 0) deps.push(`${acctCount} conta${acctCount > 1 ? 's' : ''} bancária${acctCount > 1 ? 's' : ''}`);
            break;
        }

        case 'modality': {
            const admCount = (config.admissions || []).filter(a => a.modalityId === entityId).length;
            if (admCount > 0) deps.push(`${admCount} admiss${admCount > 1 ? 'ões' : 'ão'}`);
            break;
        }

        case 'series': {
            const admCount = (config.admissions || []).filter(a => a.seriesId === entityId).length;
            if (admCount > 0) deps.push(`${admCount} admiss${admCount > 1 ? 'ões' : 'ão'}`);
            break;
        }

        case 'product': {
            const admCount = (config.admissions || []).filter(a => (a as any).productId === entityId).length;
            if (admCount > 0) deps.push(`${admCount} admiss${admCount > 1 ? 'ões' : 'ão'}`);
            break;
        }

        case 'role': {
            const collabCount = (config.collaborators || []).filter(c => c.jobTitle === entityId).length;
            if (collabCount > 0) deps.push(`${collabCount} colaborador${collabCount > 1 ? 'es' : ''}`);
            break;
        }

        case 'department': {
            const collabCount = (config.collaborators || []).filter(c => c.departmentId === entityId).length;
            if (collabCount > 0) deps.push(`${collabCount} colaborador${collabCount > 1 ? 'es' : ''}`);
            break;
        }

        case 'unit': {
            const collabCount = (config.collaborators || []).filter(c => c.unitId === entityId).length;
            if (collabCount > 0) deps.push(`${collabCount} colaborador${collabCount > 1 ? 'es' : ''}`);

            const admCount = (config.admissions || []).filter(a => a.unitId === entityId).length;
            if (admCount > 0) deps.push(`${admCount} admiss${admCount > 1 ? 'ões' : 'ão'}`);

            const userCount = (config.users || []).filter(u => (u.allowedUnitIds || []).includes(entityId)).length;
            if (userCount > 0) deps.push(`${userCount} usuário${userCount > 1 ? 's' : ''}`);

            const queueRefs = (config.schedulingQueue || []).filter(q => q.unitId === entityId).length;
            if (queueRefs > 0) deps.push(`${queueRefs} fila(s) de agendamento`);

            const seriesCount = (config.series || []).filter(s =>
                (s.unitNumbering || []).some(un => un.unitId === entityId)
            ).length;
            if (seriesCount > 0) deps.push(`${seriesCount} série${seriesCount > 1 ? 's' : ''} com numeração por unidade`);
            break;
        }

        case 'user': {
            const groupRefs = (config.userGroups || []).filter(g =>
                (config.users || []).find(u => u.id === entityId)?.groupIds?.includes(g.id)
            ).length;
            if (groupRefs > 0) deps.push(`${groupRefs} grupo${groupRefs > 1 ? 's' : ''} de usuário`);

            const admCount = (config.admissions || []).filter(a => (a as any).userId === entityId).length;
            if (admCount > 0) deps.push(`${admCount} admiss${admCount > 1 ? 'ões' : 'ão'}`);
            break;
        }

        case 'userGroup': {
            const memberCount = (config.users || []).filter(u => (u.groupIds || []).includes(entityId)).length;
            if (memberCount > 0) deps.push(`${memberCount} usuário${memberCount > 1 ? 's' : ''} vinculado${memberCount > 1 ? 's' : ''}`);
            break;
        }

        case 'service': {
            const apptCount = (config.appointments || []).filter(a => a.serviceId === entityId).length;
            if (apptCount > 0) deps.push(`${apptCount} agendamento${apptCount > 1 ? 's' : ''}`);

            const waitCount = (config.waitlist || []).filter(w => w.serviceId === entityId).length;
            if (waitCount > 0) deps.push(`${waitCount} item(ns) na fila de espera`);
            break;
        }

        case 'bankAccount': {
            const bearerCount = (config.bearers || []).filter(b => b.associatedBankAccountId === entityId).length;
            if (bearerCount > 0) deps.push(`${bearerCount} portador${bearerCount > 1 ? 'es' : ''}`);
            break;
        }

        case 'admission':
            break;

        case 'documentType':
        case 'bearer':
        case 'chartOfAccounts':
        case 'emailTemplate':
        case 'apiIntegration':
        case 'helpTopic':
            break;
    }

    return {
        canDelete: deps.length === 0,
        dependencies: deps
    };
}

export function formatDependencyMessage(entityLabel: string, deps: string[]): string {
    return `Não é possível excluir ${entityLabel} pois possui vínculos:\n\n• ${deps.join('\n• ')}\n\nRemova os vínculos antes de excluir.`;
}

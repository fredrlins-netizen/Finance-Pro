

export enum UserRole {
    ADMIN = 'ADMIN',
    USER = 'USER'
}

export type UserStatus = 'ATIVO' | 'INATIVO';
export type UserPermission = string;
export type VisualMode = 'LIGHT' | 'DARK';
export type VisualPalette = 'INSTITUTIONAL' | 'OCEAN' | 'VIOLET' | 'AMBER';
export interface VisualPreferences {
    mode: VisualMode;
    palette: VisualPalette;
    widthScale: number;
    heightScale: number;
}
export type ColorCustomizationOverride = 'INHERIT' | 'ALLOW' | 'BLOCK';

export interface AllowedUnit {
    id: string;
    nomeFantasia?: string;
    razaoSocial?: string;
}

export interface User {
    id: string;
    name: string;
    email: string;
    role: UserRole;
    status: UserStatus;
    allowedUnitIds: string[];
    allowedUnits?: AllowedUnit[];
    currentUnitId?: string;
    groupIds: string[];
    photoUrl?: string;
    initialPassword?: string;
    forceChangePassword?: boolean;
    collaboratorId?: string;
    changedPassword?: string;
    failedAttempts?: number;
    lockedAt?: string;
    forceReset?: boolean;
    mfaEnabled?: boolean;
    visualPreferences?: VisualPreferences;
    canCustomizeColors?: boolean;
    customizeColorsOverride?: ColorCustomizationOverride;
}

export interface UserGroup {
    id: string;
    name: string;
    permissions: UserPermission[];
    agendaUnitIds?: string[];
}

export interface CompanyInfo {
    id: string;
    razaoSocial: string;
    nomeFantasia?: string;
    cnpj: string;
    telefone: string;
    email: string;
    cep: string;
    endereco: string;
    numero: string;
    complemento: string;
    bairro: string;
    cidade: string;
    estado: string;
    taxaMinima?: string;
    emailConfig?: EmailConfig;
    googleIntegration?: GoogleIntegrationConfig;
    whatsappNumber?: string;
    uazapiInstanceId?: string;
    uazapiHasToken?: boolean;
    uazapiServerUrl?: string;
}

export interface UnitNumbering {
    unitId: string;
    currentNumber: number;
}

export interface Series {
    id: string;
    sigla: string;
    description: string;
    generalNumber: number;
    unitNumbering: UnitNumbering[];
}

export interface EmailConfig {
    senderName: string;
    host: string;
    port: string;
    user: string;
    password?: string;
    security: 'TLS' | 'NONE';
}

export interface GoogleIntegrationConfig {
    isConnected: boolean;
    accountEmail?: string;
    lastSync?: string;
    accessToken?: string;
}

export interface EmailTemplate {
    id: string;
    title: string;
    subject: string;
    body: string;
}

export type ApiMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';
export type ApiAuthType = 'NONE' | 'BEARER' | 'BASIC' | 'HEADER_KEY';

export interface ApiHeader {
    key: string;
    value: string;
}

export interface ApiIntegration {
    id: string;
    name: string;
    description?: string;
    baseUrl: string;
    method: ApiMethod;
    authType: ApiAuthType;
    authToken?: string;
    authUsername?: string;
    authPassword?: string;
    authHeaderKey?: string;
    headers: ApiHeader[];
    bodyTemplate?: string;
}

export interface MenuItem {
    id: string;
    label: string;
    subItems?: MenuItem[];
    hidden?: boolean;
}

export interface Client {
    id: string;
    name: string;
    type: 'FISICA' | 'JURIDICA';
    document: string;
    rg?: string;
    phone?: string;
    phone2?: string;
    isWhatsapp?: boolean;
    email?: string;
    profession?: string;
    maritalStatus?: string;
    birthDate?: string;
    cep?: string;
    address?: string;
    number?: string;
    complement?: string;
    district?: string;
    city?: string;
    state?: string;
    notes?: string;
    blocked?: boolean;
    blockStatus?: 'BLOQUEADO' | 'SUSPENSO';
    blockReason?: string;
    blockedAt?: string;
    blockedBy?: string;
    natureza?: 'C' | 'F';
}

export type ClientAttachmentModule = 'GENERAL' | 'ADMISSION' | 'LEGAL' | 'COLLECTION_PROSPECTION';
export type ClientAttachmentTargetType = 'ADMISSION' | 'LEGAL_PROCESS' | 'FINANCIAL_TITLE' | 'NEGOTIATION' | 'PROSPECTION_CONTACT';
export type ClientAttachmentCategory = 'CONTRATO' | 'PROCURACAO' | 'CNH' | 'CPF' | 'RG' | 'DOCUMENTO_VEICULO' | 'CARTAO_CREDITO' | 'EMPRESTIMO' | 'CHEQUE_ESPECIAL' | 'OUTRO';
export interface ClientAttachmentMetadata {
    id: string;
    clientId: string;
    clientName?: string;
    module: ClientAttachmentModule;
    category: ClientAttachmentCategory;
    targetType?: ClientAttachmentTargetType;
    targetId?: string;
    originalFilename: string;
    mimeType: string;
    fileSize?: number;
    checksumSha256?: string;
    aclProtected?: boolean;
    createdAt?: string;
}

export interface Collaborator {
    id: string;
    name: string;
    active?: boolean;
    unitId?: string;
    departmentId?: string;
    photoUrl?: string;
    jobTitle?: string;
    phone?: string;
    isWhatsapp?: boolean;
    email?: string;
    maritalStatus?: string;
    birthDate?: string;
    cep?: string;
    address?: string;
    number?: string;
    complement?: string;
    district?: string;
    city?: string;
    state?: string;
    notes?: string;
}

export interface BankService {
    id: string;
    name: string;
    negotiationPercentage: number;
    modalityId?: string;
    modalityDescription?: string;
}

export interface BankContact {
    id: string;
    bankId?: string;
    name: string;
    sector?: string;
    phone?: string;
    mobile?: string;
    isWhatsapp?: boolean;
    email?: string;
}

export interface Bank {
    id: string;
    name: string;
    status: 'ATIVO' | 'INATIVO';
    febrabanCode: string;
    services: BankService[];
    contacts: BankContact[];
    notes?: string;
}

export type AccountType = 'CORRENTE' | 'POUPANCA' | 'INVESTIMENTO' | 'CAIXA';
export type AccountNature = 'FISICA' | 'JURIDICA';

export interface BankAccount {
    id: string;
    description: string;
    accountType: AccountType;
    bankId?: string; // ID do banco cadastrado em 'cad_bancos'
    bankName?: string; // Nome do banco para facilitar exibição
    agency?: string;
    accountNumber?: string;
    accountNature?: AccountNature;
    agencyName?: string;
    assignorNumber?: string; // Carteira/Convênio
    initialBalance: number;
    initialBalanceDate: string;
    isDefault: boolean;
    status: 'ATIVA' | 'INATIVA';
    currentBalance: number; 
}

export interface Modality {
    id: string;
    type: string;
    description: string;
}

export interface MeasurementUnit {
    id: string;
    name: string;
    conversionFactor: number;
}

export type ProductType = 'SERVICO' | 'MATERIAL';

export interface Product {
    id: string;
    type: ProductType;
    description: string;
    unitId: string;
}

export interface ServiceItem {
    id: string;
    name: string;
    durationMinutes: number;
    price: number;
    color: string;
}

export type AppointmentStatus = 'AGUARDANDO' | 'AGENDADO' | 'CONFIRMADO' | 'CANCELADO_CLIENTE' | 'CANCELADO_CONSULTOR' | 'NAO_COMPARECEU';

export type AppointmentModalidade = 'PRESENCIAL' | 'ONLINE';

export interface Appointment {
    id: string;
    clientId: string;
    clientName: string;
    collaboratorId: string;
    serviceId: string;
    date: string;
    startTime: string;
    endTime: string;
    status: AppointmentStatus;
    notes?: string;
    unitId?: string;
    groupId?: string;
    modalidade?: AppointmentModalidade;
    createdBy?: { id: string; name: string; at: string };
    updatedBy?: { id: string; name: string; at: string };
}

export interface ScheduleBlock {
    id: string;
    collaboratorId: string;
    isWholeDay: boolean;
    startDate: string;
    endDate: string;
    startTime?: string;
    endTime?: string;
    repeatDays: number[];
    reason: string;
}

export interface WaitlistItem {
    id: string;
    clientId: string;
    clientName: string;
    serviceId: string;
    serviceName: string;
    collaboratorId: string;
    collaboratorName: string;
    date: string;
    time: string;
    notes: string;
}

export interface AgendaConfig {
    startHour: string;
    endHour: string;
    slotInterval: number;
}

export type AuditEntity = 'CLIENTE' | 'COLABORADOR' | 'BANCO' | 'PRODUTO' | 'SERVICO' | 'MODALIDADE' | 'SERIE' | 'AGENDA' | 'ADMISSAO' | 'AUDITORIA' | 'JURIDICO' | 'CONFIG' | 'USUARIO' | 'UNIDADE_MEDIDA' | 'CONTA_BANCARIA' | 'TIPO_DOCUMENTO' | 'PORTADOR' | 'PLANO_CONTAS' | 'DEPARTAMENTO' | 'CARGO' | 'AUDIT_CHECK_ITEM' | 'CONTA_PAGAR' | 'CONTA_RECEBER' | 'NEGOCIACAO' | 'CLIENTE_BLOQUEIO' | 'CLIENTE_DESBLOQUEIO' | 'MOVIMENTO_BANCARIO' | 'CONCILIACAO_BANCARIA' | 'ESCALA_TRABALHO' | 'FORMULARIO' | 'ACOMP_JURIDICO' | 'FORNECEDOR' | 'NOTA_COBRANCA';
export type AuditAction = 'CREATE' | 'UPDATE' | 'DELETE' | 'BAIXA' | 'BAIXA_PARCIAL' | 'CANCELAR_BAIXA' | 'CANCELAR' | 'INVOICE' | 'RECORRENCIA' | 'LINK' | 'DEDUCAO' | 'REABRIR_TITULO';

export interface AuditChange {
    field: string;
    oldValue: any;
    newValue: any;
}

export interface AuditLog {
    id: string;
    timestamp: string;
    userId: string;
    userName: string;
    unitId: string;
    entity: AuditEntity;
    entityId: string;
    action: AuditAction;
    changes: AuditChange[];
    description: string;
}

export type AdmissionStatus = 'PENDENTE' | 'NEGOCIAÇÃO' | 'APROVADA' | 'ANÁLISE CLIENTE' | 'REPROVADA' | 'AUDITADA' | 'FINALIZADA' | 'CONCLUIDO' | 'RETORNO AUDITORIA';

export interface RecalcScenario {
    id: string;
    label: string;
    installmentsToPay: string;
    originalDebt: string;
    installmentValue: string;
    newDebt: string;
    savings: string;
    dueDay: string;
}

export interface AdmissionAttachment {
    id: string;
    title: string;
    fileName: string;
    fileData: string; // Base64
}

export interface HistoricalLegalProcess {
    numeroProcesso: string;
    tribunal: string;
    classe?: string;
    assunto?: string;
    dataAjuizamento?: string;
    ultimaMovimentacao?: string;
    parteAutora?: string;
}

export interface LegalScanData {
    found: boolean;
    processNumber?: string;
    court?: string;
    lastMovement?: string;
    lastUpdate?: string;
    plaintiff?: string;
    allProcesses?: HistoricalLegalProcess[];
}

export type MovementStatus = 'MOVIMENTADO' | 'SEM_MOVIMENTO' | 'ARQUIVADO' | 'ALERTA';
export type ProcessMovementType = 'DESPACHO' | 'DECISAO' | 'PETICAO' | 'CERTIDAO' | 'SENTENCA' | 'AUDIENCIA';

export interface ProcessMovement {
    date: string;
    description: string;
    type: ProcessMovementType;
    source?: string;
}

export interface LegalProcess {
    id: string;
    clientId: string;
    clientName: string;
    admissionId?: string;
    contractNumber?: string;
    processNumber: string;
    court: string;
    type: string;
    status: MovementStatus;
    lastUpdate: string;
    movements: ProcessMovement[];
    tags?: string[];
    notes?: string;
    // Extended fields from DB (populated by toFrontend mapper)
    role?: string;
    subject?: string;
    opposingParty?: string;
    opposingPartyDocument?: string;
    opposingPartyLawyer?: string;
    responsibleLawyer?: string;
    causeValue?: number;
    provisionValue?: number;
    riskLevel?: string;
    distributionDate?: string;
    lastMovementDate?: string;
    deadlines?: unknown[];
    hearings?: unknown[];
    attachments?: unknown[];
    createdAt?: string;
}

export interface AuditRound {
    id: string;
    roundNumber: number;
    critiqueDate: string;
    critique: string;
    critiquedBy?: string;
    responseDate?: string;
    response?: string;
    respondedBy?: string;
}

export type CompanyProcessType = 'TRABALHISTA' | 'CÍVEL' | 'TRIBUTÁRIO' | 'CONSUMIDOR' | 'CRIMINAL' | 'ADMINISTRATIVO' | 'OUTRO';
export type CompanyProcessStatus = 'ATIVO' | 'SUSPENSO' | 'ARQUIVADO' | 'ENCERRADO_PROCEDENTE' | 'ENCERRADO_IMPROCEDENTE' | 'ACORDO';
export type ProcessRiskLevel = 'BAIXO' | 'MEDIO' | 'ALTO' | 'CRITICO';
export type CompanyProcessRole = 'AUTOR' | 'RÉU' | 'TERCEIRO';
export type DeadlineType = 'CONTESTAÇÃO' | 'RECURSO' | 'MANIFESTAÇÃO' | 'CUMPRIMENTO' | 'AUDIÊNCIA' | 'OUTRO';
export type DeadlineStatus = 'PENDENTE' | 'CUMPRIDO' | 'VENCIDO';
export type HearingType = 'INICIAL' | 'INSTRUÇÃO' | 'JULGAMENTO' | 'CONCILIAÇÃO' | 'OUTRO';
export type HearingStatus = 'AGENDADA' | 'REALIZADA' | 'ADIADA' | 'CANCELADA';

export interface CompanyProcessMovement {
    id: string;
    date: string;
    type: ProcessMovementType;
    description: string;
    source?: string;
}

export interface ProcessDeadline {
    id: string;
    processId: string;
    description: string;
    dueDate: string;
    type: DeadlineType;
    status: DeadlineStatus;
    responsibleId?: string;
    notes?: string;
}

export interface ProcessHearing {
    id: string;
    processId: string;
    date: string;
    time: string;
    type: HearingType;
    location?: string;
    notes?: string;
    status: HearingStatus;
}

export interface CompanyLegalProcess {
    id: string;
    unitId: string;
    processNumber: string;
    court: string;
    jurisdiction: string;
    type: CompanyProcessType;
    role: CompanyProcessRole;
    opposingParty: string;
    opposingPartyDocument?: string;
    opposingPartyLawyer?: string;
    opposingPartyLawyerOAB?: string;
    partnerId?: string;
    responsibleLawyer: string;
    responsibleLawyerOAB?: string;
    status: CompanyProcessStatus;
    subject: string;
    causeValue?: string;
    provisionValue?: string;
    riskLevel: ProcessRiskLevel;
    distributionDate: string;
    lastMovementDate?: string;
    movements: CompanyProcessMovement[];
    deadlines: ProcessDeadline[];
    hearings: ProcessHearing[];
    notes?: string;
    notesHeader?: string;
    notesFooter?: string;
    attachments?: { id: string; title: string; fileName: string; fileData: string }[];
    tags?: string[];
    createdAt: string;
    updatedAt: string;
}

export interface FichaAddendum {
    id: string;
    date: string;
    description: string | null;
    createdAt: string;
}

export interface FichaParcela {
    id: string;
    admissionId: string;
    documentNumber: string;
    description: string;
    dueDate: string;
    originalValue: number;
    currentBalance: number;
    status: TitleStatus;
    type: TitleType;
    clientId: string;
    collectionStatus?: 'EM_DIA' | 'COBRAR' | 'NAO_COBRAR';
}

export interface ClientFicha {
    id: string;
    clientId: string;
    contractNumber?: string | null;
    status: string;
    createdAt: string;
    hasAddendum: boolean;
    latestAddendumDate: string | null;
    addendums: FichaAddendum[];
    parcelas: FichaParcela[];
}

export interface Admission {
    id: string;
    date: string;
    clientId: string;
    clientName: string;
    bankId: string;
    collaboratorId: string;
    seriesId: string;
    modalityId: string;
    contractNumber: string;
    totalInstallments: string;
    paidInstallments: string;
    overdueInstallments: string;
    financedAmount: string;
    installmentValue: string;
    dueDay: string;
    paymentType: string;
    indicationType: string;
    originType?: string;
    unitId?: string;
    tipoCliente?: 'RESPONSÁVEL' | 'TITULAR';
    titularClientId?: string;
    status: AdmissionStatus;
    vehicleBrand?: string;
    vehicleModel?: string;
    vehicleColor?: string;
    vehicleYear?: string;
    vehiclePlate?: string;
    vehicleChassis?: string;
    vehicleRenavam?: string;
    isElectricVehicle?: boolean;
    firstInstallmentDueDate?: string;
    hasBankFeeIncluded?: boolean;
    isThirdPartyContract?: boolean;
    recalcScenarios: RecalcScenario[];
    attachments?: AdmissionAttachment[];
    legalScan?: LegalScanData;
    auditCritique?: string;
    auditResponse?: string;
    auditHistory?: AuditRound[];
    parcela1?: string;
    parcela2?: string;
    taxaCobranca?: string;
    desconto?: string;
    acrescimo?: string;
    otherInfo1: string;
    otherInfo2: string;
}

export type NegotiationContactChannel = 'TELEFONE' | 'WHATSAPP' | 'EMAIL' | 'SMS' | 'PRESENCIAL' | 'CARTA';
export type NegotiationContactResponse = 'ATENDEU' | 'NAO_ATENDEU' | 'RECADO' | 'CAIXA_POSTAL' | 'RECUSOU' | 'INTERESSADO' | 'SEM_RESPOSTA';
export type NegotiationProposalStatus = 'ENVIADA' | 'EM_ANALISE' | 'ACEITA' | 'RECUSADA' | 'CONTRA_PROPOSTA' | 'EXPIRADA' | 'CANCELADA';
export type NegotiationStatus = 'ABERTA' | 'EM_ANDAMENTO' | 'ACORDO_FECHADO' | 'ACORDO_QUEBRADO' | 'CANCELADA' | 'ENCERRADA';

export interface NegotiationContact {
    id: string;
    date: string;
    time: string;
    channel: NegotiationContactChannel;
    response: NegotiationContactResponse;
    description: string;
    nextActionDate?: string;
    nextActionDescription?: string;
    collaboratorId: string;
    collaboratorName: string;
}

export interface NegotiationProposal {
    id: string;
    date: string;
    originalValue: string;
    discountPercentage: number;
    discountedValue: string;
    installments: number;
    installmentValue: string;
    entryValue?: string;
    status: NegotiationProposalStatus;
    notes?: string;
    collaboratorId: string;
    collaboratorName: string;
    responseDate?: string;
}

export interface NegotiationGoal {
    id: string;
    month: string;
    year: string;
    collaboratorId: string;
    targetValue: string;
    achievedValue: string;
    targetCount: string;
    achievedCount: string;
}

export interface NegotiationRecord {
    id: string;
    date: string;
    clientId: string;
    clientName: string;
    admissionId?: string;
    bankId?: string;
    collaboratorId: string;
    collaboratorName: string;
    status: NegotiationStatus;
    debtValue: string;
    contacts: NegotiationContact[];
    proposals: NegotiationProposal[];
    nextContactDate?: string;
    nextContactDescription?: string;
    notes?: string;
    closedDate?: string;
    closedValue?: string;
    closedInstallments?: number;
    titleId?: string;
}

export type DocCategory = 'PAGAR' | 'RECEBER' | 'AMBOS';

export interface DocumentType {
    id: string;
    description: string; 
    category: DocCategory; 
    isFiscal: boolean; 
    status: 'ATIVO' | 'INATIVO';
    requiresDocNumber: boolean; 
}

export type BearerType = 'CARTEIRA' | 'BANCO' | 'CARTORIO' | 'JURIDICO' | 'TERCEIROS';

export interface Bearer {
    id: string;
    code: string; 
    name: string; 
    type: BearerType;
    associatedBankAccountId?: string; 
    status: 'ATIVO' | 'INATIVO';
    agencyCode?: string; 
    contractCode?: string; 
}

export type ChartAccountType = 'RECEITA' | 'DESPESA';

export interface FinancialAccount {
    id: string;
    code: string; 
    name: string;
    type: ChartAccountType;
    parentId?: string; 
    isAnalytical: boolean; 
    isSystem?: boolean; 
}

export interface Department {
    id: string;
    code: string;
    name: string;
    managerName?: string;
    status: 'ATIVO' | 'INATIVO';
}

export interface HelpTopic {
    id: string;
    menuPath: string;
    title: string;
    summary: string;
    content: string;
    keywords: string[];
}

export interface Role {
    id: string;
    name: string;
    participatesInScheduling: boolean;
}

export interface SchedulingQueueEntry {
    unitId: string;
    collaboratorIds: string[];
}

export interface AuditCheckItem {
    id: string;
    order: number;
    label: string;
    description: string;
    status: 'ATIVO' | 'INATIVO';
    conditionField?: string;
}

export interface FormTemplate {
    id: string;
    name: string;
    description: string;
    updatedAt: string;
    content: string;
    header: string;
    footer: string;
    menuIds: string[];
    docxTemplate?: string;
}

export interface FormContextDefinition {
    menuId: string;
    label: string;
    module: string;
    targetTypes: ('modal' | 'grid')[];
    entityType: string;
    availableVariablePrefixes: string[];
    description?: string;
}

export type TitleStatus = 'ABERTO' | 'PAGO' | 'PARCIAL' | 'CANCELADO' | 'AGRUPADO' | 'FATURA_GERADA' | 'ADIANTAMENTO' | 'ADIANTAMENTO_PARCIAL' | 'DEVOLUCAO' | 'DEVOLUCAO_VINCULADA' | 'DEVOLUCAO_PARCIAL' | 'PROTESTADO' | 'PROVISAO';
export type TitleSource = 'MANUAL' | 'AUDITORIA' | 'RECORRENCIA' | 'IMPORTACAO' | 'NEGOCIACAO';
export type TitleType = 'PADRAO' | 'ADIANTAMENTO' | 'DEVOLUCAO' | 'FATURA';

export interface SettlementHistory {
    id: string;
    date: string;
    amount: number;
    interest: number;
    penalty: number;
    discount: number;
    source: string;
    history: string;
    userName?: string;
    movementId?: string;
}

export interface FinancialRecord {
    id: string;
    description: string;
    categoryId: string;
    documentTypeId: string;
    bearerId: string;
    departmentId?: string;
    value: number;
    status: TitleStatus;
    clientId: string;
    clientName: string;
    issueDate: string;
    dueDate: string;
    originalValue: number;
    currentBalance: number;
    documentNumber: string;
    source: TitleSource;
    type: TitleType;
    recurrenceId?: string;
    parentId?: string;
    installmentNumber?: number;
    totalInstallments?: number;
    isProtested?: boolean;
    isProvision?: boolean;
    accountingType?: 'CONTABIL' | 'NAO_CONTABIL';
    expectedDate?: string;
    protestDays?: number;
    returnDate?: string;
    interestValue?: number;
    discountValue?: number;
    penaltyValue?: number;
    discountValidity?: string;
    bankAccountId?: string;
    unitId?: string;
    sellerId?: string;
    settlements?: SettlementHistory[];
    creationDate?: string;
    invoiceGroupId?: string;
    originTitleIds?: string[];
    collectionStatus?: 'EM_DIA' | 'COBRAR' | 'NAO_COBRAR';
    assignedCollaboratorId?: string;
    protestReleaseLog?: { userName: string; date: string; reason: string };
    provisionReleaseLog?: { userName: string; date: string; reason: string };
    advanceLinks?: { titleId: string; amount: number; date: string }[];
    returnLinks?: { titleId: string; amount: number; date: string }[];
    admissionId?: string;
    negotiationId?: string;
}

export interface EscalaDia {
    startTime: string;
    endTime: string;
    isDayOff: boolean;
}

export interface EscalaUserEntry {
    userId: string;
    schedule: Record<string, EscalaDia>;
}

export interface EscalaDeTrabalho {
    id: string;
    name: string;
    active: boolean;
    visibility: 'PRIVATE' | 'PUBLIC';
    unitId?: string;
    year: number;
    entries: EscalaUserEntry[];
    createdAt: string;
    updatedAt?: string;
}

export interface PortalConfig {
    companyName: string;
    logoUrl: string;
    marketingTitle: string;
    marketingText: string;
    companyInfo: CompanyInfo;
    units: CompanyInfo[];
    userGroups: UserGroup[];
    users: User[];
    emailTemplates: EmailTemplate[];
    apiIntegrations: ApiIntegration[];
    clients: Client[];
    collaborators: Collaborator[];
    roles: Role[];
    banks: Bank[];
    bankAccounts: BankAccount[];
    modalities: Modality[];
    products: Product[];
    measurementUnits: MeasurementUnit[];
    series: Series[];
    admissions: Admission[];
    services: ServiceItem[];
    appointments: Appointment[];
    agendaConfig: AgendaConfig;
    scheduleBlocks?: ScheduleBlock[];
    waitlist?: WaitlistItem[];
    schedulingQueue?: SchedulingQueueEntry[];
    auditLogs: AuditLog[];
    documentTypes: DocumentType[]; 
    bearers: Bearer[];
    chartOfAccounts: FinancialAccount[];
    departments: Department[];
    maritalStatusOptions: string[];
    jobTitles: string[];
    modalityTypes: string[];
    paymentTypes: string[];
    helpTopics?: HelpTopic[];
    auditCheckItems?: AuditCheckItem[];
    formTemplates?: FormTemplate[];
    receivableTitles?: FinancialRecord[];
    negotiationRecords?: NegotiationRecord[];
    escalas?: EscalaDeTrabalho[];
    companyLegalProcesses?: CompanyLegalProcess[];
    theme: {
        loginLeftBgColor: string;
        loginLeftTextColor: string;
        loginLeftBgImage?: string;
        loginRightBgColor: string;
        loginRightTextColor: string;
        sidebarBgColor: string;
        sidebarTextColor: string;
        headerBgColor: string;
        headerTextColor: string;
        mainContentBgColor: string;
        mainContentBgImage?: string;
    };
}

export interface AppState {
    isAuthenticated: boolean;
    currentUser: User | null;
    config: PortalConfig;
    logoutReason?: 'idle' | 'manual' | 'schedule_end';
}

export interface MessageAttachment {
    name: string;
    type: string;
    size: number;
    data: string;
}

export interface Message {
    id: string;
    sender_id: string;
    sender_name: string;
    recipient_type: 'USER' | 'GROUP' | 'ALL';
    recipient_id: string;
    subject?: string;
    body: string;
    attachments: MessageAttachment[];
    is_system: boolean;
    metadata?: Record<string, any>;
    created_at: string;
    read?: boolean;
    delivered?: boolean;
}

export interface Conversation {
    id: string;
    name: string;
    type: 'USER' | 'GROUP' | 'SYSTEM';
    lastMessage?: Message;
    unreadCount: number;
    avatarInitials: string;
    /** Rótulo do canal/origem (ex: "WhatsApp - Canal Principal", "Mensagem Interna") */
    channelLabel?: string;
}
-- ============================================================
-- MIGRAÇÃO 024: bank_contacts
-- Criado em: 2026-04-09
-- Descrição: Tabela de contatos por banco (nome, setor, telefone,
--            celular, marcação WhatsApp e e-mail).
-- ============================================================

CREATE TABLE IF NOT EXISTS bank_contacts (
    id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bank_id     UUID NOT NULL REFERENCES banks(id) ON DELETE CASCADE,
    name        VARCHAR(200) NOT NULL,
    sector      VARCHAR(100),
    phone       VARCHAR(30),
    mobile      VARCHAR(30),
    is_whatsapp BOOLEAN NOT NULL DEFAULT FALSE,
    email       VARCHAR(200),
    created_at  TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_bank_contacts_bank_id ON bank_contacts(bank_id);

-- ============================================================
-- FIM DA MIGRAÇÃO 024
-- ============================================================

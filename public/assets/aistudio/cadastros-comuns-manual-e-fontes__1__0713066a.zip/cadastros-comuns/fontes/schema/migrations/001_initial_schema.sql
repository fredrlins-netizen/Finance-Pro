-- ============================================================
-- MIGRAÇÃO 001: Schema inicial completo
-- Criado em: 2026-02-24
-- Descrição: Todas as tabelas do sistema. Seguro para executar
--            em banco vazio ou já existente (IF NOT EXISTS).
-- ============================================================

-- 0. Extensões
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================
-- 1. TABELA DE CONFIGURAÇÃO GERAL (JSONB)
-- ============================================================
CREATE TABLE IF NOT EXISTS app_data (
    key TEXT PRIMARY KEY,
    value JSONB NOT NULL DEFAULT '{}',
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 2. EMPRESA / UNIDADES
-- ============================================================
CREATE TABLE IF NOT EXISTS companies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    razao_social VARCHAR(255) NOT NULL,
    cnpj VARCHAR(20) UNIQUE,
    telefone VARCHAR(30),
    email VARCHAR(255),
    cep VARCHAR(12),
    endereco VARCHAR(255),
    numero VARCHAR(20),
    complemento VARCHAR(100),
    bairro VARCHAR(100),
    cidade VARCHAR(100),
    estado VARCHAR(2),
    email_sender_name VARCHAR(100),
    email_host VARCHAR(255),
    email_port VARCHAR(10),
    email_user VARCHAR(255),
    email_security VARCHAR(10) DEFAULT 'TLS',
    google_connected BOOLEAN DEFAULT FALSE,
    google_account_email VARCHAR(255),
    google_last_sync TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 3. GRUPOS DE USUÁRIOS E PERMISSÕES
-- ============================================================
CREATE TABLE IF NOT EXISTS user_groups (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_group_permissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    group_id UUID NOT NULL REFERENCES user_groups(id) ON DELETE CASCADE,
    permission VARCHAR(100) NOT NULL,
    UNIQUE(group_id, permission)
);

CREATE INDEX IF NOT EXISTS idx_ugp_group ON user_group_permissions(group_id);

-- ============================================================
-- 4. USUÁRIOS
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    role VARCHAR(10) NOT NULL DEFAULT 'USER' CHECK (role IN ('ADMIN','USER')),
    status VARCHAR(10) NOT NULL DEFAULT 'ATIVO' CHECK (status IN ('ATIVO','INATIVO')),
    photo_url TEXT,
    initial_password VARCHAR(100),
    force_change_password BOOLEAN DEFAULT FALSE,
    collaborator_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS user_allowed_units (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    unit_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, unit_id)
);

CREATE TABLE IF NOT EXISTS user_group_members (
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    group_id UUID NOT NULL REFERENCES user_groups(id) ON DELETE CASCADE,
    PRIMARY KEY (user_id, group_id)
);

-- ============================================================
-- 5. CLIENTES
-- ============================================================
CREATE TABLE IF NOT EXISTS clients (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    type VARCHAR(10) NOT NULL DEFAULT 'FISICA' CHECK (type IN ('FISICA','JURIDICA')),
    document VARCHAR(20),
    rg VARCHAR(20),
    phone VARCHAR(30),
    phone2 VARCHAR(30),
    is_whatsapp BOOLEAN DEFAULT FALSE,
    email VARCHAR(255),
    profession VARCHAR(100),
    marital_status VARCHAR(50),
    birth_date DATE,
    cep VARCHAR(12),
    address VARCHAR(255),
    number VARCHAR(20),
    complement VARCHAR(100),
    district VARCHAR(100),
    city VARCHAR(100),
    state VARCHAR(2),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_clients_name ON clients(name);
CREATE INDEX IF NOT EXISTS idx_clients_document ON clients(document);

-- ============================================================
-- 6. COLABORADORES
-- ============================================================
CREATE TABLE IF NOT EXISTS collaborators (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    photo_url TEXT,
    job_title VARCHAR(100),
    phone VARCHAR(30),
    is_whatsapp BOOLEAN DEFAULT FALSE,
    email VARCHAR(255),
    marital_status VARCHAR(50),
    birth_date DATE,
    cep VARCHAR(12),
    address VARCHAR(255),
    number VARCHAR(20),
    complement VARCHAR(100),
    district VARCHAR(100),
    city VARCHAR(100),
    state VARCHAR(2),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 7. BANCOS E SERVIÇOS BANCÁRIOS
-- ============================================================
CREATE TABLE IF NOT EXISTS banks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    status VARCHAR(10) NOT NULL DEFAULT 'ATIVO' CHECK (status IN ('ATIVO','INATIVO')),
    febraban_code VARCHAR(10),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS bank_services (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bank_id UUID NOT NULL REFERENCES banks(id) ON DELETE CASCADE,
    name VARCHAR(200) NOT NULL,
    negotiation_percentage NUMERIC(8,2) DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_bank_services_bank ON bank_services(bank_id);

-- ============================================================
-- 8. CONTAS BANCÁRIAS
-- ============================================================
CREATE TABLE IF NOT EXISTS bank_accounts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    description VARCHAR(200) NOT NULL,
    account_type VARCHAR(20) NOT NULL DEFAULT 'CORRENTE'
        CHECK (account_type IN ('CORRENTE','POUPANCA','INVESTIMENTO','CAIXA')),
    bank_id UUID REFERENCES banks(id) ON DELETE SET NULL,
    bank_name VARCHAR(200),
    agency VARCHAR(30),
    account_number VARCHAR(30),
    account_nature VARCHAR(10) CHECK (account_nature IN ('FISICA','JURIDICA')),
    agency_name VARCHAR(100),
    assignor_number VARCHAR(50),
    initial_balance NUMERIC(18,2) DEFAULT 0,
    initial_balance_date DATE,
    current_balance NUMERIC(18,2) DEFAULT 0,
    is_default BOOLEAN DEFAULT FALSE,
    status VARCHAR(10) NOT NULL DEFAULT 'ATIVA' CHECK (status IN ('ATIVA','INATIVA')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_bank_accounts_bank ON bank_accounts(bank_id);

-- ============================================================
-- 9. MODALIDADES
-- ============================================================
CREATE TABLE IF NOT EXISTS modalities (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type VARCHAR(50) NOT NULL,
    description VARCHAR(255)
);

-- ============================================================
-- 10. UNIDADES DE MEDIDA
-- ============================================================
CREATE TABLE IF NOT EXISTS measurement_units (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(50) NOT NULL,
    conversion_factor NUMERIC(12,6) DEFAULT 1
);

-- ============================================================
-- 11. PRODUTOS
-- ============================================================
CREATE TABLE IF NOT EXISTS products (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type VARCHAR(10) NOT NULL DEFAULT 'SERVICO' CHECK (type IN ('SERVICO','MATERIAL')),
    description VARCHAR(255) NOT NULL,
    unit_id UUID REFERENCES measurement_units(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 12. SÉRIES / NUMERAÇÃO
-- ============================================================
CREATE TABLE IF NOT EXISTS series (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sigla VARCHAR(20) NOT NULL,
    description VARCHAR(200),
    general_number INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS series_unit_numbering (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    series_id UUID NOT NULL REFERENCES series(id) ON DELETE CASCADE,
    unit_id UUID NOT NULL REFERENCES companies(id) ON DELETE CASCADE,
    current_number INTEGER DEFAULT 0,
    UNIQUE(series_id, unit_id)
);

-- ============================================================
-- 13. SERVIÇOS (AGENDA)
-- ============================================================
CREATE TABLE IF NOT EXISTS service_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    duration_minutes INTEGER DEFAULT 30,
    price NUMERIC(12,2) DEFAULT 0,
    color VARCHAR(10) DEFAULT '#3b82f6'
);

-- ============================================================
-- 14. AGENDAMENTOS
-- ============================================================
CREATE TABLE IF NOT EXISTS appointments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
    client_name VARCHAR(255),
    collaborator_id UUID REFERENCES collaborators(id) ON DELETE SET NULL,
    service_id UUID REFERENCES service_items(id) ON DELETE SET NULL,
    date DATE NOT NULL,
    start_time VARCHAR(5) NOT NULL,
    end_time VARCHAR(5) NOT NULL,
    status VARCHAR(30) NOT NULL DEFAULT 'AGENDADO'
        CHECK (status IN ('AGUARDANDO','AGENDADO','CONFIRMADO','CANCELADO_CLIENTE','CANCELADO_CONSULTOR','NAO_COMPARECEU')),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_appointments_date ON appointments(date);
CREATE INDEX IF NOT EXISTS idx_appointments_client ON appointments(client_id);
CREATE INDEX IF NOT EXISTS idx_appointments_collaborator ON appointments(collaborator_id);

-- ============================================================
-- 15. BLOQUEIOS DE AGENDA
-- ============================================================
CREATE TABLE IF NOT EXISTS schedule_blocks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    collaborator_id UUID REFERENCES collaborators(id) ON DELETE CASCADE,
    is_whole_day BOOLEAN DEFAULT FALSE,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    start_time VARCHAR(5),
    end_time VARCHAR(5),
    repeat_days INTEGER[] DEFAULT '{}',
    reason VARCHAR(255)
);

-- ============================================================
-- 16. LISTA DE ESPERA
-- ============================================================
CREATE TABLE IF NOT EXISTS waitlist (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    client_id UUID REFERENCES clients(id) ON DELETE CASCADE,
    client_name VARCHAR(255),
    service_id UUID REFERENCES service_items(id) ON DELETE SET NULL,
    service_name VARCHAR(200),
    collaborator_id UUID REFERENCES collaborators(id) ON DELETE SET NULL,
    collaborator_name VARCHAR(200),
    date DATE,
    time VARCHAR(5),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- 17. CONFIGURAÇÃO DA AGENDA
-- ============================================================
CREATE TABLE IF NOT EXISTS agenda_config (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    start_hour VARCHAR(5) DEFAULT '08:00',
    end_hour VARCHAR(5) DEFAULT '18:00',
    slot_interval INTEGER DEFAULT 30
);

-- ============================================================
-- 18. ADMISSÕES (COMERCIAL)
-- ============================================================
CREATE TABLE IF NOT EXISTS admissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    date TIMESTAMPTZ DEFAULT NOW(),
    client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
    client_name VARCHAR(255),
    bank_id UUID REFERENCES banks(id) ON DELETE SET NULL,
    collaborator_id UUID REFERENCES collaborators(id) ON DELETE SET NULL,
    series_id UUID REFERENCES series(id) ON DELETE SET NULL,
    modality_id UUID REFERENCES modalities(id) ON DELETE SET NULL,
    contract_number VARCHAR(50),
    total_installments VARCHAR(10),
    paid_installments VARCHAR(10),
    overdue_installments VARCHAR(10),
    financed_amount VARCHAR(30),
    installment_value VARCHAR(30),
    due_day VARCHAR(5),
    payment_type VARCHAR(50),
    indication_type VARCHAR(50),
    status VARCHAR(30) NOT NULL DEFAULT 'PENDENTE'
        CHECK (status IN ('PENDENTE','NEGOCIAÇÃO','APROVADA','ANÁLISE CLIENTE','REPROVADA','AUDITADA','FINALIZADA','CONCLUIDO','RETORNO AUDITORIA')),
    vehicle_brand VARCHAR(100),
    vehicle_model VARCHAR(100),
    vehicle_color VARCHAR(50),
    vehicle_year VARCHAR(10),
    vehicle_plate VARCHAR(20),
    vehicle_chassis VARCHAR(50),
    vehicle_renavam VARCHAR(30),
    is_electric_vehicle BOOLEAN DEFAULT FALSE,
    first_installment_due_date DATE,
    has_bank_fee_included BOOLEAN DEFAULT FALSE,
    is_third_party_contract BOOLEAN DEFAULT FALSE,
    audit_critique TEXT,
    parcela1 VARCHAR(30),
    parcela2 VARCHAR(30),
    taxa_cobranca VARCHAR(30),
    other_info1 TEXT,
    other_info2 TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_admissions_client ON admissions(client_id);
CREATE INDEX IF NOT EXISTS idx_admissions_status ON admissions(status);
CREATE INDEX IF NOT EXISTS idx_admissions_collaborator ON admissions(collaborator_id);

-- ============================================================
-- 18a. CENÁRIOS DE RECÁLCULO (ADMISSÃO)
-- ============================================================
CREATE TABLE IF NOT EXISTS recalc_scenarios (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admission_id UUID NOT NULL REFERENCES admissions(id) ON DELETE CASCADE,
    label VARCHAR(100),
    installments_to_pay VARCHAR(10),
    original_debt VARCHAR(30),
    installment_value VARCHAR(30),
    new_debt VARCHAR(30),
    savings VARCHAR(30),
    due_day VARCHAR(5)
);

CREATE INDEX IF NOT EXISTS idx_recalc_admission ON recalc_scenarios(admission_id);

-- ============================================================
-- 18b. ANEXOS DA ADMISSÃO
-- ============================================================
CREATE TABLE IF NOT EXISTS admission_attachments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admission_id UUID NOT NULL REFERENCES admissions(id) ON DELETE CASCADE,
    title VARCHAR(200),
    file_name VARCHAR(255),
    file_data TEXT
);

CREATE INDEX IF NOT EXISTS idx_attach_admission ON admission_attachments(admission_id);

-- ============================================================
-- 18c. CONSULTA JURÍDICA (ADMISSÃO)
-- ============================================================
CREATE TABLE IF NOT EXISTS admission_legal_scans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    admission_id UUID NOT NULL REFERENCES admissions(id) ON DELETE CASCADE,
    found BOOLEAN DEFAULT FALSE,
    process_number VARCHAR(50),
    court VARCHAR(200),
    last_movement TEXT,
    last_update TIMESTAMPTZ,
    plaintiff VARCHAR(255),
    UNIQUE(admission_id)
);

-- ============================================================
-- 19. TIPOS DE DOCUMENTO (FINANCEIRO)
-- ============================================================
CREATE TABLE IF NOT EXISTS document_types (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    description VARCHAR(200) NOT NULL,
    category VARCHAR(10) NOT NULL DEFAULT 'AMBOS'
        CHECK (category IN ('PAGAR','RECEBER','AMBOS')),
    is_fiscal BOOLEAN DEFAULT FALSE,
    status VARCHAR(10) NOT NULL DEFAULT 'ATIVO' CHECK (status IN ('ATIVO','INATIVO')),
    requires_doc_number BOOLEAN DEFAULT FALSE
);

-- ============================================================
-- 20. PORTADORES
-- ============================================================
CREATE TABLE IF NOT EXISTS bearers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(20) NOT NULL,
    name VARCHAR(200) NOT NULL,
    type VARCHAR(20) NOT NULL DEFAULT 'CARTEIRA'
        CHECK (type IN ('CARTEIRA','BANCO','CARTORIO','JURIDICO','TERCEIROS')),
    associated_bank_account_id UUID REFERENCES bank_accounts(id) ON DELETE SET NULL,
    status VARCHAR(10) NOT NULL DEFAULT 'ATIVO' CHECK (status IN ('ATIVO','INATIVO')),
    agency_code VARCHAR(30),
    contract_code VARCHAR(30)
);

-- ============================================================
-- 21. PLANO DE CONTAS
-- ============================================================
CREATE TABLE IF NOT EXISTS chart_of_accounts (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(20) NOT NULL,
    name VARCHAR(200) NOT NULL,
    type VARCHAR(10) NOT NULL CHECK (type IN ('RECEITA','DESPESA')),
    parent_id UUID REFERENCES chart_of_accounts(id) ON DELETE SET NULL,
    is_analytical BOOLEAN DEFAULT FALSE,
    is_system BOOLEAN DEFAULT FALSE
);

CREATE INDEX IF NOT EXISTS idx_coa_parent ON chart_of_accounts(parent_id);
CREATE INDEX IF NOT EXISTS idx_coa_code ON chart_of_accounts(code);

-- ============================================================
-- 22. DEPARTAMENTOS
-- ============================================================
CREATE TABLE IF NOT EXISTS departments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    code VARCHAR(20),
    name VARCHAR(200) NOT NULL,
    manager_name VARCHAR(200),
    status VARCHAR(10) NOT NULL DEFAULT 'ATIVO' CHECK (status IN ('ATIVO','INATIVO'))
);

-- ============================================================
-- 23. TÍTULOS FINANCEIROS
-- ============================================================
CREATE TABLE IF NOT EXISTS financial_titles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title_scope VARCHAR(10) NOT NULL CHECK (title_scope IN ('RECEBER','PAGAR')),
    description VARCHAR(255),
    category_id UUID REFERENCES chart_of_accounts(id) ON DELETE SET NULL,
    document_type_id UUID REFERENCES document_types(id) ON DELETE SET NULL,
    bearer_id UUID REFERENCES bearers(id) ON DELETE SET NULL,
    department_id UUID REFERENCES departments(id) ON DELETE SET NULL,
    value NUMERIC(18,2) NOT NULL DEFAULT 0,
    status VARCHAR(30) NOT NULL DEFAULT 'ABERTO'
        CHECK (status IN ('ABERTO','PAGO','PARCIAL','CANCELADO','AGRUPADO',
            'ADIANTAMENTO','ADIANTAMENTO_PARCIAL','DEVOLUCAO','DEVOLUCAO_VINCULADA','DEVOLUCAO_PARCIAL',
            'PROTESTADO','PROVISAO')),
    client_id UUID REFERENCES clients(id) ON DELETE SET NULL,
    client_name VARCHAR(255),
    issue_date DATE,
    due_date DATE,
    original_value NUMERIC(18,2) DEFAULT 0,
    current_balance NUMERIC(18,2) DEFAULT 0,
    document_number VARCHAR(50),
    source VARCHAR(20) DEFAULT 'MANUAL'
        CHECK (source IN ('MANUAL','AUDITORIA','RECORRENCIA','IMPORTACAO','BAIXA EM LOTE')),
    type VARCHAR(20) DEFAULT 'PADRAO'
        CHECK (type IN ('PADRAO','ADIANTAMENTO','DEVOLUCAO','FATURA')),
    recurrence_id UUID,
    parent_id UUID REFERENCES financial_titles(id) ON DELETE SET NULL,
    installment_number INTEGER,
    total_installments INTEGER,
    is_protested BOOLEAN DEFAULT FALSE,
    is_provision BOOLEAN DEFAULT FALSE,
    accounting_type VARCHAR(20) DEFAULT 'CONTABIL'
        CHECK (accounting_type IN ('CONTABIL','NAO_CONTABIL')),
    expected_date DATE,
    protest_days INTEGER,
    return_date DATE,
    interest_value NUMERIC(18,2) DEFAULT 0,
    discount_value NUMERIC(18,2) DEFAULT 0,
    penalty_value NUMERIC(18,2) DEFAULT 0,
    discount_validity DATE,
    bank_account_id UUID REFERENCES bank_accounts(id) ON DELETE SET NULL,
    unit_id UUID REFERENCES companies(id) ON DELETE SET NULL,
    seller_id UUID REFERENCES collaborators(id) ON DELETE SET NULL,
    invoice_group_id UUID,
    origin_title_ids UUID[],
    collection_status VARCHAR(15) CHECK (collection_status IN ('EM_DIA','COBRAR','NAO_COBRAR')),
    assigned_collaborator_id UUID REFERENCES collaborators(id) ON DELETE SET NULL,
    protest_release_user VARCHAR(200),
    protest_release_date TIMESTAMPTZ,
    protest_release_reason TEXT,
    provision_release_user VARCHAR(200),
    provision_release_date TIMESTAMPTZ,
    provision_release_reason TEXT,
    creation_date TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ft_scope ON financial_titles(title_scope);
CREATE INDEX IF NOT EXISTS idx_ft_client ON financial_titles(client_id);
CREATE INDEX IF NOT EXISTS idx_ft_status ON financial_titles(status);
CREATE INDEX IF NOT EXISTS idx_ft_due_date ON financial_titles(due_date);
CREATE INDEX IF NOT EXISTS idx_ft_invoice_group ON financial_titles(invoice_group_id);
CREATE INDEX IF NOT EXISTS idx_ft_parent ON financial_titles(parent_id);
CREATE INDEX IF NOT EXISTS idx_ft_assigned_collab ON financial_titles(assigned_collaborator_id);

-- ============================================================
-- 23a. BAIXAS / LIQUIDAÇÕES DOS TÍTULOS
-- ============================================================
CREATE TABLE IF NOT EXISTS title_settlements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    title_id UUID NOT NULL REFERENCES financial_titles(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    amount NUMERIC(18,2) NOT NULL DEFAULT 0,
    interest NUMERIC(18,2) DEFAULT 0,
    penalty NUMERIC(18,2) DEFAULT 0,
    discount NUMERIC(18,2) DEFAULT 0,
    source VARCHAR(50),
    history TEXT,
    user_name VARCHAR(200),
    movement_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_ts_title ON title_settlements(title_id);
CREATE INDEX IF NOT EXISTS idx_ts_movement ON title_settlements(movement_id);

-- ============================================================
-- 23b. VÍNCULOS DE ADIANTAMENTO
-- ============================================================
CREATE TABLE IF NOT EXISTS title_advance_links (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_title_id UUID NOT NULL REFERENCES financial_titles(id) ON DELETE CASCADE,
    linked_title_id UUID NOT NULL REFERENCES financial_titles(id) ON DELETE CASCADE,
    amount NUMERIC(18,2) NOT NULL,
    date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tal_source ON title_advance_links(source_title_id);
CREATE INDEX IF NOT EXISTS idx_tal_linked ON title_advance_links(linked_title_id);

-- ============================================================
-- 23c. VÍNCULOS DE DEVOLUÇÃO
-- ============================================================
CREATE TABLE IF NOT EXISTS title_return_links (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_title_id UUID NOT NULL REFERENCES financial_titles(id) ON DELETE CASCADE,
    linked_title_id UUID NOT NULL REFERENCES financial_titles(id) ON DELETE CASCADE,
    amount NUMERIC(18,2) NOT NULL,
    date DATE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_trl_source ON title_return_links(source_title_id);
CREATE INDEX IF NOT EXISTS idx_trl_linked ON title_return_links(linked_title_id);

-- ============================================================
-- 24. MOVIMENTAÇÕES BANCÁRIAS
-- ============================================================
CREATE TABLE IF NOT EXISTS bank_movements (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    bank_account_id UUID NOT NULL REFERENCES bank_accounts(id) ON DELETE CASCADE,
    date DATE NOT NULL,
    type VARCHAR(10) NOT NULL CHECK (type IN ('CREDITO','DEBITO')),
    amount NUMERIC(18,2) NOT NULL DEFAULT 0,
    description VARCHAR(255),
    category_id UUID REFERENCES chart_of_accounts(id) ON DELETE SET NULL,
    document_number VARCHAR(50),
    reconciled BOOLEAN DEFAULT FALSE,
    source VARCHAR(20) DEFAULT 'MANUAL'
        CHECK (source IN ('MANUAL','BAIXA','IMPORTACAO')),
    title_id UUID REFERENCES financial_titles(id) ON DELETE SET NULL,
    unit_id UUID REFERENCES companies(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_bm_account ON bank_movements(bank_account_id);
CREATE INDEX IF NOT EXISTS idx_bm_date ON bank_movements(date);
CREATE INDEX IF NOT EXISTS idx_bm_title ON bank_movements(title_id);

-- ============================================================
-- 25. OPÇÕES DE CONFIGURAÇÃO GERAL
-- ============================================================
CREATE TABLE IF NOT EXISTS config_options (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    option_type VARCHAR(50) NOT NULL,
    value VARCHAR(255) NOT NULL,
    sort_order INTEGER DEFAULT 0
);

CREATE INDEX IF NOT EXISTS idx_config_type ON config_options(option_type);

-- ============================================================
-- FUNÇÃO: Atualizar updated_at automaticamente
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DO $$
DECLARE
    tbl TEXT;
BEGIN
    FOR tbl IN
        SELECT table_name FROM information_schema.columns
        WHERE column_name = 'updated_at'
          AND table_schema = 'public'
        GROUP BY table_name
    LOOP
        EXECUTE format(
            'DROP TRIGGER IF EXISTS set_updated_at ON %I; CREATE TRIGGER set_updated_at BEFORE UPDATE ON %I FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();',
            tbl, tbl
        );
    END LOOP;
END;
$$;

-- ============================================================
-- FIM DA MIGRAÇÃO 001
-- ============================================================

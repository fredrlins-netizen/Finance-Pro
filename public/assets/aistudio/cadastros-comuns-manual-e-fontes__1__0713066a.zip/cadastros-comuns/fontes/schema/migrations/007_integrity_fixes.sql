-- Migration 007: Database Integrity Fixes
-- Fixes type mismatches, missing FKs, missing indexes, and removes redundant tables
-- 2026-03-09

BEGIN;

-- ============================================================
-- 0. ENSURE COLUMNS EXIST (for clean installs from repo migrations)
-- ============================================================
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'collaborators' AND column_name = 'unit_id'
  ) THEN
    ALTER TABLE collaborators ADD COLUMN unit_id UUID;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'collaborators' AND column_name = 'department_id'
  ) THEN
    ALTER TABLE collaborators ADD COLUMN department_id UUID;
  END IF;
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'collaborators' AND column_name = 'active'
  ) THEN
    ALTER TABLE collaborators ADD COLUMN active BOOLEAN DEFAULT TRUE;
  END IF;
END $$;

-- ============================================================
-- A. FIX TYPE MISMATCHES: collaborators.unit_id (TEXT -> UUID)
-- ============================================================
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'collaborators' AND column_name = 'unit_id' AND data_type = 'text'
  ) THEN
    UPDATE collaborators SET unit_id = NULL
      WHERE unit_id IS NOT NULL
        AND unit_id !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
    ALTER TABLE collaborators ALTER COLUMN unit_id TYPE UUID USING unit_id::UUID;
  END IF;
END $$;

-- ============================================================
-- B. FIX TYPE MISMATCHES: collaborators.department_id (TEXT -> UUID)
-- ============================================================
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'collaborators' AND column_name = 'department_id' AND data_type = 'text'
  ) THEN
    UPDATE collaborators SET department_id = NULL
      WHERE department_id IS NOT NULL
        AND department_id !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
    ALTER TABLE collaborators ALTER COLUMN department_id TYPE UUID USING department_id::UUID;
  END IF;
END $$;

-- ============================================================
-- C. FIX TYPE MISMATCHES: legal_processes.unit_id (TEXT -> UUID)
-- ============================================================
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'legal_processes' AND column_name = 'unit_id' AND data_type = 'text'
  ) THEN
    UPDATE legal_processes SET unit_id = NULL
      WHERE unit_id IS NOT NULL
        AND unit_id !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
    ALTER TABLE legal_processes ALTER COLUMN unit_id TYPE UUID USING unit_id::UUID;
  END IF;
END $$;

-- ============================================================
-- D. FIX TYPE MISMATCHES: legal_processes.partner_id (TEXT -> UUID)
-- ============================================================
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'legal_processes' AND column_name = 'partner_id' AND data_type = 'text'
  ) THEN
    UPDATE legal_processes SET partner_id = NULL
      WHERE partner_id IS NOT NULL
        AND partner_id !~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$';
    ALTER TABLE legal_processes ALTER COLUMN partner_id TYPE UUID USING partner_id::UUID;
  END IF;
END $$;

-- ============================================================
-- E. ADD MISSING FK CONSTRAINTS
-- ============================================================

-- collaborators.unit_id -> companies.id
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'collaborators_unit_id_fkey' AND table_name = 'collaborators'
  ) THEN
    ALTER TABLE collaborators
      ADD CONSTRAINT collaborators_unit_id_fkey
      FOREIGN KEY (unit_id) REFERENCES companies(id) ON DELETE SET NULL;
  END IF;
END $$;

-- collaborators.department_id -> departments.id
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'collaborators_department_id_fkey' AND table_name = 'collaborators'
  ) THEN
    ALTER TABLE collaborators
      ADD CONSTRAINT collaborators_department_id_fkey
      FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL;
  END IF;
END $$;

-- legal_processes.unit_id -> companies.id
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'legal_processes_unit_id_fkey' AND table_name = 'legal_processes'
  ) THEN
    ALTER TABLE legal_processes
      ADD CONSTRAINT legal_processes_unit_id_fkey
      FOREIGN KEY (unit_id) REFERENCES companies(id) ON DELETE SET NULL;
  END IF;
END $$;

-- legal_processes.partner_id -> clients.id
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'legal_processes_partner_id_fkey' AND table_name = 'legal_processes'
  ) THEN
    ALTER TABLE legal_processes
      ADD CONSTRAINT legal_processes_partner_id_fkey
      FOREIGN KEY (partner_id) REFERENCES clients(id) ON DELETE SET NULL;
  END IF;
END $$;

-- users.collaborator_id -> collaborators.id
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'users_collaborator_id_fkey' AND table_name = 'users'
  ) THEN
    ALTER TABLE users
      ADD CONSTRAINT users_collaborator_id_fkey
      FOREIGN KEY (collaborator_id) REFERENCES collaborators(id) ON DELETE SET NULL;
  END IF;
END $$;

-- title_settlements.movement_id -> bank_movements.id
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.table_constraints
    WHERE constraint_name = 'title_settlements_movement_id_fkey' AND table_name = 'title_settlements'
  ) THEN
    ALTER TABLE title_settlements
      ADD CONSTRAINT title_settlements_movement_id_fkey
      FOREIGN KEY (movement_id) REFERENCES bank_movements(id) ON DELETE SET NULL;
  END IF;
END $$;

-- ============================================================
-- F. ADD MISSING INDEXES ON FK COLUMNS
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_collaborators_unit ON collaborators(unit_id);
CREATE INDEX IF NOT EXISTS idx_collaborators_department ON collaborators(department_id);
CREATE INDEX IF NOT EXISTS idx_legal_processes_partner ON legal_processes(partner_id);
CREATE INDEX IF NOT EXISTS idx_users_collaborator ON users(collaborator_id);
CREATE INDEX IF NOT EXISTS idx_ts_movement ON title_settlements(movement_id);

CREATE INDEX IF NOT EXISTS idx_sun_series ON series_unit_numbering(series_id);
CREATE INDEX IF NOT EXISTS idx_sun_unit ON series_unit_numbering(unit_id);
CREATE INDEX IF NOT EXISTS idx_uau_user ON user_allowed_units(user_id);
CREATE INDEX IF NOT EXISTS idx_uau_unit ON user_allowed_units(unit_id);
CREATE INDEX IF NOT EXISTS idx_ugm_user ON user_group_members(user_id);
CREATE INDEX IF NOT EXISTS idx_ugm_group ON user_group_members(group_id);

-- ============================================================
-- G. REMOVE REDUNDANT units TABLE
--    (units.js route already operates on 'companies' table)
-- ============================================================
DROP TABLE IF EXISTS units;

-- ============================================================
-- H. ANALYZE updated tables for query planner
-- ============================================================
ANALYZE collaborators;
ANALYZE legal_processes;
ANALYZE users;
ANALYZE title_settlements;
ANALYZE series_unit_numbering;
ANALYZE user_allowed_units;
ANALYZE user_group_members;

COMMIT;

-- Type: SCHEMA
-- Complete the clean-install schema using fields already in schema-contract.json.
-- No existing values are backfilled or replaced. Defaults apply to future rows.
ALTER TABLE modalities ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE modalities ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE products ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE products ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE series ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE series ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE config_options ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE config_options ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE bearers ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE bearers ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE departments ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE departments ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE document_types ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE document_types ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE chart_of_accounts ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE chart_of_accounts ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE measurement_units ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE measurement_units ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE appointments ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE appointments ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE schedule_blocks ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE schedule_blocks ALTER COLUMN updated_at SET DEFAULT NOW();
ALTER TABLE title_settlements ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE title_settlements ALTER COLUMN updated_at SET DEFAULT NOW();

ALTER TABLE bank_movements
  ADD COLUMN IF NOT EXISTS category_name VARCHAR(200),
  ADD COLUMN IF NOT EXISTS document_type_id VARCHAR(100),
  ADD COLUMN IF NOT EXISTS bearer_id VARCHAR(100),
  ADD COLUMN IF NOT EXISTS department_id VARCHAR(100),
  ADD COLUMN IF NOT EXISTS cost_center_id VARCHAR(100),
  ADD COLUMN IF NOT EXISTS origin VARCHAR(30),
  ADD COLUMN IF NOT EXISTS title_source VARCHAR(20),
  ADD COLUMN IF NOT EXISTS reconciliation_date DATE,
  ADD COLUMN IF NOT EXISTS compensation_date DATE,
  ADD COLUMN IF NOT EXISTS transfer_id VARCHAR(100),
  ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ;
ALTER TABLE bank_movements
  ALTER COLUMN origin SET DEFAULT 'MANUAL',
  ALTER COLUMN updated_at SET DEFAULT NOW();

# Pacote — Cadastros Comuns

Este ZIP reúne um manual técnico-funcional e os arquivos-fonte centrais das oito opções exibidas em **Menu Lateral → Cadastros Comuns**:

1. Clientes
2. Cargos
3. Colaboradores
4. Departamentos
5. Bancos
6. Modalidades
7. Produtos
8. Série/Números

## Conteúdo

- `manual/Manual-Cadastros-Comuns.md`: grids, filtros, formulários, modais/diálogos, ações, vínculos e observações sobre diferenças entre a interface e o modelo de dados.
- `fontes/components/cadastros/`: os oito painéis da interface.
- `fontes/components/layout/`, `fontes/components/ui/`, `fontes/components/attachments/` e `fontes/components/gotalk/`: componentes de menu, formulários e recursos usados diretamente pelas telas.
- `fontes/server/`: rotas de API e lógica CRUD relacionada.
- `fontes/types.ts`, `fontes/constants.ts`, hooks, serviços, contextos e utilitários relacionados.
- `fontes/schema/`: esquema de referência e migrações relacionadas aos vínculos descritos.
- `fontes/MANIFESTO.md`: lista dos arquivos de código incluídos.

O pacote contém **código-fonte de referência**, não uma cópia executável completa do aplicativo. Dependências, outras telas, configuração de execução, dados e arquivos de ambiente não estão incluídos. Nenhuma credencial ou dado de usuário faz parte do pacote.

O manual descreve o comportamento encontrado no código incluído. Quando o texto da Central de Ajuda diverge da tela implementada, prevalece a implementação e a divergência é registrada.

# Cadastros Comuns — manual técnico-funcional

**Escopo:** opções de primeiro nível sob “Cadastros Comuns” no menu lateral.  
**Levantamento:** código-fonte incluído neste pacote; não inclui inspeção de dados reais do banco.

## Menu

| Ordem | Opção | Identificador interno |
|---:|---|---|
| 1 | Clientes | `cad_clientes` |
| 2 | Cargos | `cad_cargos` |
| 3 | Colaboradores | `cad_colaboradores` |
| 4 | Departamentos | `cad_departamentos` |
| 5 | Bancos | `cad_bancos` |
| 6 | Modalidades | `cad_modalidades` |
| 7 | Produtos | `cad_produtos` |
| 8 | Série/Números | `cad_series` |

## Comportamentos comuns

- As telas de cadastro dão acesso a inclusão, alteração e exclusão conforme permissões específicas do módulo. Os painéis também oferecem consulta ao histórico de auditoria quando essa ação está disponível.
- Vários cadastros têm ações de **Duplicar**. Isso abre a tela de edição com valores copiados e permite salvar um novo registro.
- A maioria das telas troca a grade pelo formulário dentro da própria página; isso não é um modal. Os modais/diálogos existentes estão discriminados por cadastro.
- Filtros, ordenação e paginação variam por tela. Os itens abaixo listam o que o código da interface realmente mostra.
- Relacionamentos são resumidos a partir da interface, das rotas e do esquema/migrações incluídos. “Bloqueio de exclusão” significa que a API ou a interface impede remover um registro relacionado; não significa que todo vínculo exibido na interface seja uma chave estrangeira.

---

## 1. Clientes

**Uso:** cadastro de pessoa física ou jurídica; cliente pode aparecer em admissões, atendimentos e rotinas financeiras.

### Grade principal

Colunas:

1. Descrição (nome/razão social), com indicador de bloqueio quando aplicável.
2. Natureza.
3. CPF/CNPJ.
4. Telefone, com atalho de contato GoTalk.
5. Cidade/UF.
6. Ações: auditoria, editar, duplicar e excluir, conforme permissão.

Busca por nome, código ou CPF/CNPJ. Filtros avançados por tipo de pessoa, CPF/CNPJ, cidade e UF. Ordenação nos cabeçalhos de nome, documento e telefone/cidade; listagem paginada pelo servidor, com 50 itens por página.

### Formulário e abas

- **Dados do Cliente:** código, natureza (Física/Jurídica), nome/razão social, CPF/CNPJ, RG, telefone principal, indicação de WhatsApp, telefone secundário, estado civil, nascimento, e-mail, profissão, CEP, endereço, número, complemento, bairro, cidade, UF e anotações.
- CPF/CNPJ é validado conforme a natureza. Para pessoa jurídica, RG e nascimento deixam de ser aplicáveis. O CEP pode preencher endereço por consulta.
- **Conversas WhatsApp:** disponível ao editar cliente existente; carrega histórico e permite abrir o painel unificado GoTalk/uazapi.
- **Documentos:** disponível em cliente existente. O envio depende de permissão; para novo cliente é preciso salvar antes de anexar.
- Ao editar, uma seção de vínculos lista admissões em que o cliente participa, incluindo número do contrato, data, papel, status, outro cliente vinculado e ação para abrir a ficha.

### Modais e confirmações

- **Gerenciar Estados Civis:** adiciona/remove opções da lista compartilhada de estado civil.
- **Bloquear/Suspender cliente:** `BlockClientModal`; também permite administrar a restrição. Desbloqueio é condicionado a perfil de administrador.
- **Conversas WhatsApp:** abre painel em tela cheia associado ao telefone/cliente.
- **Excluir cliente:** diálogo com abas de dados e documentos. A exclusão fica desabilitada se ainda houver documentos; o usuário precisa tratá-los antes.
- **Visualizar admissão:** abre a ficha selecionada na seção de admissões.
- A edição de dados é uma tela dentro do painel, não um modal.

### Relacionamentos

- **Admissões:** cliente pode ser responsável (`client_id`) ou titular (`titular_client_id`); uma admissão pode mostrar o outro cliente relacionado.
- **Documentos:** `client_attachments.client_id` referencia o cliente; exclusão é bloqueada quando há documentos associados.
- **Títulos financeiros** e **agendamentos:** são dependências reconhecidas pela API ao excluir.
- **Conversas:** o backend tenta associar conversas GoTalk pelo telefone; telefone é dado de contato, não uma chave estrangeira de cliente.

---

## 2. Cargos

**Uso:** catálogo de funções e configuração de participação na fila de agendamento.

### Grade principal

Colunas: **Nome**, **Fila de Agendamento** (Sim/Não) e **Ações** (auditoria, editar, duplicar, excluir). Há busca pelo nome, ordenação por nome e paginação ajustável.

### Formulário

- Nome do cargo (obrigatório).
- Checkbox “Participa da Fila de Agendamento”.
- Formulário exibido dentro da página, não em modal.
- Exclusão pede confirmação do navegador e pode ser impedida se o cargo estiver em uso.

### Relacionamentos e armazenamento

- Os cargos são armazenados como opção do tipo `role` na tabela `config_options`; o valor inclui nome e configuração da fila.
- A tela de colaboradores carrega esses cargos para montar a seleção.
- **Importante:** no código atual, o campo `collaborators.job_title` é gravado como texto com o nome do cargo; a seleção não persiste o ID da opção de cargo. O teste local de dependência compara esse texto ao ID, enquanto a API CRUD de cargos não declara dependência de colaboradores. Portanto, a proteção de exclusão pode não detectar todos os usos. Isso é uma observação do código, não uma confirmação de comportamento em produção.

---

## 3. Colaboradores

**Uso:** equipe vinculada à unidade, setor e função, com dados de contato e endereço.

### Grade principal

Não é uma tabela plana. É uma árvore expansível:

1. Agrupamento por **Unidade**, com total de colaboradores.
2. Dentro da unidade, agrupamento por **Cargo/Função**, também com contagem.
3. Em cada pessoa: foto/iniciais, nome, status Ativo/Inativo, departamento, telefone e e-mail.
4. Ações por pessoa: auditoria, editar, duplicar e excluir, segundo as permissões.

Há busca textual e comandos de expandir/recolher todos; o rodapé mostra o total de resultados. Os dados são carregados com limite ampliado e a interface os organiza localmente.

### Formulário

- Foto: câmera, arquivo ou remoção.
- Código e status.
- Unidade (obrigatória), cargo/função (obrigatório) e setor/departamento (obrigatório).
- Nome completo, e-mail, telefone, indicação de WhatsApp, nascimento e estado civil.
- CEP, endereço, número, complemento, bairro, cidade e UF; anotações.
- O formulário ocupa a área do painel. **Captura de câmera** abre `CameraCapture`; exclusão usa confirmação nativa do navegador.

### Relacionamentos

- `unit_id` → unidade/empresa.
- `department_id` → departamento, com relação no esquema e política de exclusão `SET NULL`.
- Colaborador pode ser referenciado por admissões, agendamentos, bloqueios de agenda e usuários; a exclusão pode ser bloqueada por dependências.
- O cargo é atualmente persistido em `job_title` como texto, conforme descrito em **Cargos**; não é vínculo por ID no cadastro mostrado.
- O campo “Setor” usa a lista da API `/api/lookups/departments`; veja a observação sobre Departamentos.

---

## 4. Departamentos

**Uso:** setores organizacionais e centros de custo.

### Grade principal

Colunas efetivamente exibidas: **Descrição**, **Responsável**, **Status** e **Ações** (auditoria, editar e excluir). Há busca por nome/código. A implementação atual não mostra a coluna Código, embora o campo possa ser pesquisado e editado. Não há paginação na tela.

### Formulário

- Código.
- Nome (obrigatório; a entrada é convertida para maiúsculas).
- Responsável/Gerente.
- Status Ativo/Inativo.
- O formulário substitui a grade dentro da página; não é modal. Exclusão pede confirmação do navegador e verifica dependências no estado de configuração.

### Relacionamentos e observação de implementação

- No esquema do banco, `collaborators.department_id` e `financial_titles.department_id` apontam para departamentos.
- **Diferença importante:** esta tela lê e atualiza `config.departments` pela configuração do portal. O salvamento chama `/api/settings/section`, que atualiza `portal_config`; já a seleção de setor em Colaboradores consulta `/api/lookups/departments`, que lê a tabela PostgreSQL `departments`. Não foi identificada sincronização imediata entre essas duas operações. Confira essa integração antes de tratar a tela como a única fonte de verdade.
- A rota da tabela `departments` declara títulos financeiros como dependência; o vínculo de colaboradores usa `ON DELETE SET NULL`. A interface também tenta bloquear a exclusão com base nas relações em `config`.
- A ajuda antiga descreve um modal e lista Código na grade; o painel implementado usa formulário na página e não mostra Código como coluna.

---

## 5. Bancos

**Uso:** instituições financeiras, serviços de negociação, contatos e dados de referência bancária.

### Grade principal

Colunas: **Descrição (Nome)**, **Status** e **Ações** (auditoria, editar, duplicar, excluir). Busca por nome, código ou FEBRABAN. Filtro por status; ordenação por nome/status e paginação.

### Formulário e subgrades

- Código interno, nome, status e código FEBRABAN.
- Seletor FEBRABAN com busca por código/nome; ao selecionar, preenche código e nome do banco.
- **Serviços Bancários & Percentuais de Negociação** — subgrade com Serviço, Modalidade, Percentual e Ação. Permite adicionar, editar e remover linhas.
- **Contatos** — subgrade com Nome, Setor, Telefone, Celular, Zap, E-mail e Ação. Permite inclusão/edição em linha e remoção.
- Anotações.
- O formulário é uma tela dentro do painel. Não há modal específico para editar banco, serviço ou contato. Exclusão do banco usa confirmação nativa e checagem de dependências.

### Relacionamentos

- `bank_services.bank_id` → banco (exclusão em cascata no esquema).
- Serviço pode referenciar uma **Modalidade** por `modality_id`; a API apresenta a descrição da modalidade associada.
- `bank_contacts.bank_id` → banco (cascata).
- Banco pode estar relacionado a **admissões** e **contas bancárias**; esses usos impedem a exclusão.
- As subgrades são carregadas/salvas por rotas dedicadas de serviços e contatos do banco.

---

## 6. Modalidades

**Uso:** classificar modalidades de negócio/negociação.

### Grade principal

Colunas: **Tipo**, **Descrição** e **Ações** (auditoria, editar, duplicar, excluir). Busca, ordenação por tipo/descrição e paginação.

### Formulário

- Tipo obrigatório: permite selecionar um tipo existente ou digitar um novo; os tipos conhecidos são sugeridos e um novo tipo pode ser gravado.
- Descrição.
- Formulário dentro da página, não modal. Exclusão pede confirmação nativa e a API pode recusá-la por uso existente.

### Relacionamentos

- **Admissões** podem apontar para modalidade; a API declara esse vínculo como dependência de exclusão.
- **Serviços bancários** podem apontar para modalidade por `modality_id` e mostram a descrição selecionada na subgrade de Bancos.

---

## 7. Produtos

**Uso:** catálogo de serviços e materiais com unidade de medida.

### Grade principal

Colunas: **Tipo**, **Descrição**, **Unidade** e **Ações** (auditoria, editar, duplicar, excluir). Busca por descrição/tipo, filtro de tipo (Serviço/Material), ordenação e paginação.

### Formulário e modal

- Tipo: Serviço ou Material.
- Descrição (obrigatória).
- Unidade de medida (obrigatória na tela).
- Botão para editar a unidade selecionada e botão para criar unidade.
- **Modal de unidade de medida:** nome/sigla (até 5 caracteres) e fator de conversão. Permite criar ou atualizar a unidade sem sair do cadastro de produto.
- O formulário do produto em si ocupa a página; a exclusão usa confirmação nativa.

### Relacionamentos

- Produto referencia unidade por `products.unit_id` → `measurement_units.id`; a referência no esquema permite `SET NULL` quando unidade é removida.
- A unidade inclui fator de conversão.
- A rota de produto não declara dependências adicionais de exclusão.

---

## 8. Série/Números

**Uso:** séries de documentos/contratos, com número geral e contadores por unidade.

### Grade principal

Colunas: **Sigla**, **Descrição**, **Nº Geral** e **Ações** (auditoria, editar, duplicar, excluir). Busca por sigla/descrição, ordenação e paginação.

### Formulário e subgrade

- Sigla e descrição (ambas obrigatórias).
- Número geral.
- **Numeração por Unidade** — seleciona uma unidade, adiciona à subgrade e define o número atual. Colunas: Unidade, Numeração Atual e Ação (Remover).
- O formulário abre na página; não há modal dedicado. Exclusão pede confirmação nativa e pode ser recusada se houver admissões ou registros de numeração vinculados.

### Relacionamentos

- `series_unit_numbering.series_id` → série; `unit_id` → unidade/empresa; unicidade por par série/unidade.
- Série pode ser referenciada por admissões.
- A subgrade de numeração é uma relação muitos-para-muitos entre série e unidade, com um contador atual para cada par.
- **Limite da implementação atual:** o formulário permite montar essa subgrade, mas o salvamento da série envia apenas sigla, descrição e número geral. O painel também não carrega `series_unit_numbering` ao abrir uma série. Portanto, a leitura e a persistência dos números por unidade não estão ligadas à subgrade neste componente; o esquema de banco, por si só, não comprova que essa tela salve os valores.

---

## Mapa resumido de vínculos

| Cadastro | Relações principais |
|---|---|
| Clientes | Admissões (responsável/titular), documentos, títulos financeiros, agendamentos, conversas associadas por telefone |
| Cargos | Opções `role`; `job_title` do colaborador atualmente guarda texto/nome |
| Colaboradores | Unidade, departamento, admissões, agendamentos, bloqueios de agenda e usuários |
| Departamentos | Colaboradores e títulos financeiros; a tela e o lookup usam fontes diferentes no código |
| Bancos | Serviços, contatos, modalidades, admissões e contas bancárias |
| Modalidades | Admissões e serviços bancários |
| Produtos | Unidade de medida |
| Série/Números | Admissões e numeração por unidade |

## Limites deste levantamento

- Grids, campos e interações foram listados a partir da implementação, não de uma sessão autenticada no ambiente publicado.
- O esquema SQL incluído serve de referência; instalações antigas podem ter diferenças cobertas por migrações.
- Não foram consultados registros nem credenciais da aplicação.
- O manual não modifica ou propõe migrações; registra apenas comportamento e vínculos observados.

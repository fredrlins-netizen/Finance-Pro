# Organização > Tarefas

## 1. Acesso e finalidade

A opção abre o gerenciamento de tarefas da organização. A entrada geral carrega `TarefasView` e inicia na guia **Lista**. A tela também pode ser aberta a partir de um projeto; nesse caso recebe o escopo daquele projeto, oferece retorno ao projeto e limita a seleção ao contexto autorizado.

A tela organiza tarefas e subtarefas, permite acompanhar status e tempo, associar cliente/projeto, registrar prazos, filtrar origens e compartilhar itens quando o perfil e as permissões permitem.

## 2. Guias/modos da tela

### 2.1 Lista

- Mostra cartões agrupados por cliente e criticidade/prioridade. Cada cartão resume título, projeto/responsável, prazo, estado, tempo e progresso.
- Clicar no cartão ou no título abre **Detalhes da tarefa**.
- O botão de cronômetro inicia a execução; quando já estiver rodando, abre a justificativa para pausar.
- Compartilhamento aparece somente quando a tarefa e o usuário atendem às regras de acesso e permissão.
- Tarefas concluídas ficam ocultas por padrão. Um aviso com **Mostrar** habilita sua exibição.
- **Nova Tarefa** abre o formulário completo.
- **Selecionar** habilita seleção múltipla. **Selecionar todas** seleciona a lista ordenada atualmente exibida; **Excluir selecionadas** pede confirmação nativa do navegador e, confirmado, exclui em lote.

### 2.2 Quadro

- Exibe cartões em colunas de status. Se não houver configuração disponível, usa como fallback Pendente, Em Execução e Concluído.
- Arrastar uma tarefa para outra coluna muda seu status, respeitando cliente obrigatório, dependências, subtarefas e regras de encerramento.
- Reordenar cartões na mesma coluna guarda ordem local no navegador, por conta; não altera o conteúdo da tarefa.
- Arrastar para coluna final inicia o fluxo de encerramento. Bloqueios de dependência ou subtarefas pendentes podem impedir a ação.
- A primeira coluna oferece **Nova**, um cadastro rápido sem modal.
- **Configurar Colunas** abre a edição das colunas do quadro.

### 2.3 Semana

- Apresenta sete dias e a área **Sem data**; a semana inicial é a semana corrente.
- Setas avançam/retornam uma semana; **Hoje** volta à semana atual.
- Expandir um dia dá foco naquele dia; em telas estreitas o quadro permite rolagem horizontal.
- Tarefas e subtarefas abertas podem ser arrastadas para um dia, ou selecionadas e depois colocadas no dia. A data escolhida vira prazo às 09:00. Arrastar para **Sem data** remove a data.
- Tarefas concluídas não entram no planejamento. Chamados abertos do Help Desk também podem aparecer e ser planejados; planejar/desplanejar um chamado atualiza o evento correspondente.
- O botão **+** cria tarefa já associada ao dia; **Subtarefa** cria subtarefa para a tarefa naquele dia.
- O lápis abre edição; compartilhar é condicionado à permissão.

### 2.4 Central de suporte (condicional)

Só aparece para usuários com permissão de visualização. Incorpora o Help Desk e disponibiliza as guias:

- **Tickets:** lista e filtros de chamados, criação, conversa e ações conforme permissão.
- **Kanban:** quadro de chamados, incluindo resolvidos, com status.
- **Portal dos Clientes:** consulta/gestão do contexto de portal permitido ao usuário.
- **Indicadores:** métricas de atendimento.

No fluxo de criação de chamado, os campos, estados e operações estão detalhados na seção 11. É uma área de atendimento separada da gestão de tarefa, apesar de aparecer como quarto modo da tela Tarefas.

## 3. Filtros e origem

### 3.1 Origem das tarefas

O painel **Origem das tarefas** vale para Lista, Quadro e Semana. Por padrão inclui tarefas diretas/Notas Rápidas; a seleção de projetos começa vazia. Pode combinar tarefas diretas com um ou mais projetos.

- **Tarefas diretas e de Notas Rápidas:** incluir/excluir essa origem.
- **Projetos:** marca individualmente os projetos que podem ser exibidos.
- **Todas as origens:** seleciona diretas e todos os projetos disponíveis.
- **Somente diretas/Notas Rápidas:** desmarca projetos e deixa diretas ativas.

É um filtro visual: criar tarefa nessa tela não cria automaticamente um vínculo de projeto. Quando a tela está presa a um projeto, esse seletor de origem não aparece.

### 3.2 Filtros gerais

Painel **Filtros** recolhível, com contador de tarefas resultantes e indicador de filtros ativos. **Limpar** repõe:

- Status = Todos (apenas Lista);
- Prioridade = Todas;
- Projeto = Todos, se o modo estiver em escopo de projeto e o campo for exibido;
- Cliente = Todos;
- Colaborador = Todos;
- Prazo De/Até = vazios;
- Mostrar concluídas = desativado.

Status é representado pelas colunas no Quadro, portanto o filtro de status não aparece nesse modo. A opção **Mostrar tarefas concluídas** existe nos controles de status da Lista. Resultado zero pode significar ausência de registros, origem não selecionada ou filtros sem correspondência; a tela apresenta mensagens diferentes para esses casos.

## 4. Formulários de criação

### 4.1 Modal “Nova Tarefa”

Abre pelo botão no topo ou no rodapé da Lista, e pode ser aberto a partir de um projeto ou dia semanal. No celular aparece como painel inferior; no desktop como diálogo. O painel tenta ancorar-se ao botão que o abriu.

| Campo | Inicial / opções | Efeito |
|---|---|---|
| Título | Vazio; obrigatório | Identifica a tarefa. Inclui botão para ditado por voz. |
| Cliente | Vazio; obrigatório | Seleciona cliente disponível ou abre cadastro rápido. É exigido antes de salvar/status/cronômetro em diversas regras. |
| Projeto | Sem vínculo no fluxo geral; pode ser fixo se a tela veio de projeto | Ao selecionar projeto, podem surgir campos de planejamento. Botão adjacente cadastra projeto. |
| Entrega | Sem vínculo | Só aparece após selecionar projeto e carregar o planejamento; lista entregas não canceladas. |
| Marco | Sem vínculo | Só aparece com projeto; lista marcos não cancelados. |
| Solicitação de mudança | Sem vínculo | Só aparece com projeto; lista solicitações aprovadas/implementadas. |
| Não prevista na linha de base | Desativado | Marca a tarefa como não prevista; aparece na área de planejamento do projeto. |
| Criticidade | Média | Baixo, Médio, Alto, Crítico ou Emergencial. |
| Status | Primeiro status configurado; fallback Pendente | Opções vêm das colunas ativas e ordenadas. |
| Colaborador | Vazio; obrigatório | Seleciona colaborador ou abre cadastro rápido. |
| Descrição | Vazia | Texto rico; inclui ditado por voz. |
| Solução (opcional) | Vazia | Observação/solução; oferece auxílio de escrita e ditado. |
| Prazo | Vazio | Data e hora. |
| Tempo estimado (min) | Vazio | Inteiro positivo; mínimo 1. |
| Cadastro | Data/hora atual | Apenas informativo, não editável. |

**Salvar Tarefa** envia a criação; validações podem manter o diálogo aberto com erro. **Cancelar** ou fechar descarta o formulário. O botão Salvar não deve ser interpretado como aprovar outros planos ou executar integrações externas.

### 4.2 Cadastro rápido de tarefa no Quadro

O botão **Nova** da primeira coluna expande um formulário embutido, não um modal:

- Título: vazio, obrigatório.
- Descrição: vazia, obrigatória; a Sing avalia o contexto.
- Cliente: começa sem seleção; pode cadastrar cliente.
- Projeto e vínculos de entrega/marco/solicitação de mudança: condicionados ao escopo/seleção do projeto.
- Criticidade: Média por padrão; opções Baixo, Médio, Alto, Crítico, Emergencial.
- Colaborador: sem seleção; obrigatório.
- Subtarefa (opcional): título vazio; descrição da subtarefa se título informado é obrigatória.

Antes de criar, a Sing revisa a descrição da tarefa e, se houver, da subtarefa. O status inicial é a coluna onde o formulário está, e certos campos internos mantêm prioridade Média. **Adicionar** cria tarefa e subtarefa opcional; **Cancelar** fecha e limpa o formulário.

### 4.3 Criar subtarefa nos detalhes

**Adicionar Subtarefa** revela formulário inline:

- Título: vazio.
- Descrição: vazia; texto rico. A Sing avalia a clareza e pode solicitar complementos.
- Criticidade: Média; opções Baixo, Médio, Alto, Crítico, Emergencial.
- Estimativa (min): vazia; mínimo 1.

Ao criar, campos internos iniciam sem responsável, prioridade Média, solução/prazo sem valor e sem exigência de precedência. O cadastro fica vinculado à tarefa-pai. **Adicionar** tenta salvar; **Cancelar** fecha e mantém a tarefa sem essa nova subtarefa.

## 5. Detalhes da tarefa

Abre ao selecionar uma tarefa na Lista, no Quadro ou na Semana. Em layout móvel ocupa a parte inferior; no desktop centraliza. Exibe título e cliente/projeto/responsável, criticidade/prioridade, status, resumo das subtarefas, prazo, descrição, solução, bloqueio, encerramento, tempo e anexos.

### 5.1 Ações do cabeçalho

- **Editar:** entra em edição se o usuário pode editar. Tarefas antigas sem cliente exibem alerta e não deixam trocar status ou salvar outras mudanças até selecionar cliente válido.
- **Compartilhar:** abre o modal de compartilhamento se houver permissão.
- **Status:** seleciona uma coluna do quadro; fica desabilitado se não houver cliente válido. Mudanças seguem as regras de bloqueio e encerramento.
- **Fechar:** fecha detalhes. O foco retorna ao controle que abriu o modal, se ainda estiver disponível.

### 5.2 Campos de edição

| Campo | Inicial | Regras/efeito |
|---|---|---|
| Título | Valor atual | Texto; vazio ao salvar mantém título atual. |
| Cliente | Valor atual; obrigatório e precisa estar disponível | Evita usar seleção antiga indisponível; cadastro rápido possível. |
| Projeto | Projeto atualmente vinculado ou sem vínculo | Em edição de tarefa fora do escopo, pode remover vínculo; no escopo do projeto fica fixo. |
| Entrega, Marco, Solicitação de mudança | Seleção atual ou sem vínculo | Depende do projeto e do planejamento carregado. |
| Não prevista na linha de base | Valor atual | Atualiza indicador do planejamento. |
| Colaborador | Valor atual ou vazio | Lista de colaboradores; cadastro rápido possível. |
| Prioridade | Atual; Alta/Média/Baixa | Campo de prioridade operacional. |
| Estimativa (min) | Valor atual | Mínimo 1. Se calculada pelas estimativas das subtarefas, fica bloqueada e mostra o somatório automático. |
| Prazo | Valor atual ou vazio | Data/hora. |
| Descrição | Valor atual ou vazia | Texto rico. |
| Solução / Observações | Valor atual ou vazia | Texto. |
| Ocorrência / O que aconteceu | Valor atual ou vazia | Texto de ocorrência. |
| Bloqueio | Valor atual ou vazio | Descreve o impedimento. |

**Salvar alterações** atualiza a tarefa; campos opcionais vazios são persistidos como ausentes/vazios conforme o mapeamento do formulário. **Cancelar** descarta edição. A estimativa da tarefa é preservada se estiver derivada de subtarefas.

### 5.3 Subtarefas no detalhe

Cada subtarefa pode exibir título, descrição, solução, prioridade/criticidade, cronômetro, parcela do tempo total, precedência e anexos. A subtarefa anterior precisa estar concluída quando a opção “Requer conclusão da subtarefa anterior” estiver ativa; nesse caso o cronômetro e início ficam bloqueados.

**Editar** aparece somente quando o usuário tem permissão e a subtarefa está Pendente. Campos: título, descrição, solução aplicada, prioridade (Alta/Média/Baixa), responsável, prazo, estimativa (min) e “Requer conclusão da subtarefa anterior”. Salvar persiste; Cancelar descarta.

Outras ações por subtarefa: iniciar/pausar cronômetro; concluir; anexar arquivo local; anexar do Google quando conectado; ver histórico quando há dados; excluir. Exclusão pode falhar se não for possível persistir no dispositivo/rede e mostra mensagem para tentar de novo. Se houver edição em curso e a pessoa tentar concluir, o navegador pergunta se deseja descartar a edição.

### 5.4 Central Hub e clientes associados

Quando a integração estiver configurada, os detalhes mostram clientes associados à tarefa e ações **Associar cliente**, **Replicar** ou **Re-sincronizar**. O seletor lista clientes ainda não associados. Adicionar/remove vínculo atualiza a lista; se a tarefa já estiver replicada, a alteração também pode disparar nova sincronização. O ID externo é apresentado quando existe. Falhas são mostradas no próprio detalhe.

## 6. Modais e diálogos auxiliares

### 6.1 “Registrar Encerramento”

Aberto ao concluir tarefa/subtarefa, ou ao mover tarefa para uma coluna final. Campos:

- **Ocorrência / O que aconteceu:** inicia com a ocorrência anteriormente salva; senão vazio.
- **Solução Adotada:** inicia com solução previamente salva; senão vazio.

**Validar e concluir** exige texto operacional em pelo menos um campo e envia a Sing para revisão. Durante a revisão campos e cancelamento ficam bloqueados. Se a Sing pedir complemento ou falhar, a mensagem de erro aparece e o item permanece aberto. Se aprovado, subtarefa recebe status Concluído e registro de conclusão; tarefa recebe status final, encerra cronômetro e registra os textos. **Cancelar** fecha sem encerrar. A conclusão da tarefa é bloqueada se houver subtarefas não concluídas.

### 6.2 “Justificativa de Pausa”

Disponível ao pausar o cronômetro de tarefa ou subtarefa. Campo texto com placeholder de motivo (reunião, bloqueio técnico, almoço etc.), começa vazio. **Pausar** registra a justificativa e encerra o cronômetro; **Cancelar** abandona a pausa. O cronômetro não inicia se cliente estiver ausente ou existirem predecessoras não concluídas.

### 6.3 Cadastro rápido “Novo Cliente”, “Novo Projeto” ou “Novo Colaborador”

Aberto pelo botão `+` ao lado do campo de entidade.

- Nome/razão social: vazio, obrigatório na ação de salvar.
- Em cadastro de projeto, **Cliente do projeto** é opcional e inicia sem vínculo; o projeto pode ficar sem cliente.
- **Salvar** cria a entidade e seleciona o item criado no formulário original.
- **Cancelar** fecha sem criar.
- Se houver resultado incerto ao salvar projeto, os campos ficam temporariamente bloqueados e aparece **Tentar novamente** para repetir com a mesma chave de idempotência; não iniciar um segundo cadastro com dados diferentes durante essa incerteza.

### 6.4 “Configurar Colunas do Quadro”

Abre quando as colunas terminaram de carregar. Para cada coluna:

- Cor (se vier vazia, o controle mostra `#C4A484`);
- Nome;
- Indicador **Final**;
- posição, controlada por setas para cima/baixo;
- botão remover.

**Adicionar Coluna** cria rascunho com nome “Nova Coluna”, cor `#6b7280`, posição no fim e Final desativado. **Salvar** descarta rascunhos sem nome, exige ao menos uma coluna nomeada, persiste a nova lista e reconcilia status legados; a coluna final participa da regra de encerramento. Não é permitido deixar o quadro sem coluna. **Cancelar/fechar** descarta o rascunho. Durante erro, alerta permite entender que as alterações não foram salvas.

### 6.5 Seletor “Anexar do Google”

Modal com abas **Gmail** e **Drive**; inicia em Gmail e carrega listas de mensagens e arquivos. Campo de busca muda o placeholder para “Buscar e-mails...” ou “Buscar arquivos...”.

- Gmail lista assunto/remetente e anexos. **Vincular** associa o e-mail/anexo por referência; **Copiar** transfere o arquivo para o armazenamento do app.
- Drive lista nome, tamanho e data de modificação. **Vincular** usa link do Drive; **Copiar** importa o arquivo para o app.
- A tela indica conteúdo já adicionado e progresso da cópia; falha do carregamento pode mostrar lista vazia, sem provar que não há conteúdo no provedor.
- Exige integração Google conectada; pode ser fechado sem selecionar.

### 6.6 Compartilhamento

Modal “Compartilhamento” mostra título da tarefa, usuários elegíveis e acessos atuais.

- **Destinatário:** inicia sem seleção; opções são usuários retornados como elegíveis.
- **Conceder:** cria acesso ao item selecionado; desabilitado sem destinatário ou durante salvamento.
- **Pessoas com acesso:** lista concessões ativas.
- **Revogar:** remove a concessão selecionada.
- **Fechar/Esc/clicar no fundo:** fecha o modal. Falhas de carregamento, concessão ou revogação aparecem como mensagem.

O botão só aparece para tarefa própria/compartilhável e quando a permissão correspondente ao modo (Lista, Quadro ou Semana) está liberada.

### 6.7 Visualizador de anexos

Ao clicar num anexo, o visualizador trata o tipo de arquivo conforme as fontes aceitas (por exemplo imagem/PDF/documento). Controles variam com formato; serve para abrir/ler, não para editar os dados da tarefa. `AttachmentViewer` é o componente de renderização.

### 6.8 Confirmações nativas de exclusão

- **Excluir tarefa:** diálogo nativo “Deseja excluir esta tarefa?”; confirmar remove a tarefa, cancelar mantém.
- **Excluir selecionadas:** informa quantidade e que não pode ser desfeito; somente confirmação executa a exclusão em lote.
- **Concluir com edição de subtarefa aberta:** pergunta se pode descartar as alterações em andamento antes de concluir.

Esses são `confirm()` do navegador, não modais próprios do aplicativo.

## 7. Semana: comandos e conteúdo

Cartões podem ser tarefa, subtarefa ou ticket aberto. Ao tocar/selecionar, o item fica selecionado e um dia escolhido agenda a tarefa/subtarefa; o resumo “selecionado” permite cancelar a seleção.

- Para tarefa/subtarefa, agendar atualiza prazo para 09:00 daquele dia e persiste localmente; sincronização de rede entra na fila para nova tentativa se estiver offline.
- Desagendar remove o prazo.
- Para ticket, o planejamento cria/remove o evento relacionado ao chamado.
- O cartão pode mostrar controles para editar, compartilhar e abrir detalhes conforme o tipo e permissão.
- O dia expandido pode ser recolhido; ir a outra semana limpa a expansão se o dia expandido não pertencer mais à semana mostrada.

## 8. Regras de status, dependências e progresso

- Valores legados padrão: Pendente (`PENDENTE`), Em Execução (`EM_EXECUCAO`) e Concluído (`CONCLUIDO`). O servidor pode devolver colunas customizadas.
- Colunas finais acionam encerramento; nome e quantidade podem ser personalizados.
- Alterações para etapas mais avançadas verificam bloqueadores de dependência. Bloqueadores impedem início/avanço e apresentam alerta.
- Tarefa sem cliente: status e cronômetro podem ficar bloqueados; o detalhe pede que seja selecionado cliente válido.
- Concluir tarefa requer todas as subtarefas concluídas.
- Estimativa da tarefa pode ser derivada pela soma das estimativas das subtarefas.
- Conclusão registra data/hora, ocorrência e solução; o histórico aparece no detalhe/cartão conforme informação disponível.
- Indicadores de progresso e tempo são calculados; não são campos editáveis.

## 9. Estados iniciais — referência rápida

| Elemento | Valor inicial |
|---|---|
| Guia da tela | Lista |
| Seleção múltipla | Desligada |
| Filtros de lista | Todos, datas vazias, concluídas ocultas |
| Origem | Diretas/Notas Rápidas incluídas; sem projeto selecionado |
| Nova tarefa | Prioridade Média, criticidade Média, status selecionado pelo primeiro status; demais campos de texto/data vazios |
| Nova subtarefa | Prioridade Média, criticidade Média, sem responsável/prazo/estimativa/solução, sem precedência exigida |
| Formulário rápido do Quadro | Prioridade interna Média, criticidade Média, sem cliente/projeto/colaborador/texto |
| Quadro padrão de segurança | Pendente → Em Execução → Concluído; Concluído é final |
| Seletor Google | Aba Gmail, busca vazia |
| Cadastro rápido de projeto | Sem vínculo com cliente |
| Semana | Semana atual; dias em modo geral, sem seleção |

## 10. Diferença entre ação visual e mudança nos dados

| Ação | Altera dado? | O que muda |
|---|---|---|
| Abrir cartão / expandir filtro ou dia | Não | Só apresentação/estado da tela. |
| Reordenar cartão na mesma coluna | Não no servidor | Ordem local do Quadro no navegador/conta. |
| Mover cartão entre colunas | Sim | Status da tarefa; respeita validações. |
| Arrastar tarefa na Semana | Sim | Prazo da tarefa; não muda status ou projeto. |
| Arrastar subtarefa na Semana | Sim | Prazo da subtarefa. |
| Arrastar ticket na Semana | Sim | Planejamento do chamado/evento. |
| Alterar posição do formulário/lista | Não | Não altera hierarquia da tarefa. |
| Adicionar subtarefa | Sim | Cria subtarefa vinculada à tarefa-pai. |
| Compartilhar | Sim | Cria/revoga concessão de acesso; não transfere propriedade. |
| Vincular anexo | Sim | Guarda a referência do provedor/arquivo; cópia importa bytes ao app. |

## 11. Guia incorporada: Central de suporte

Esta área é apresentada dentro de Tarefas, mas controla **tickets** (chamados), não tarefas operacionais. A criação e atualização podem também originar uma tarefa separada.

### 11.1 Tickets e Kanban

O cabeçalho mostra contagens de Abertos, Em Análise, Suporte 2º nível e Resolvidos. A lista tem:

- Busca por título, cliente ou descrição.
- Status: Todos, Abertos, Em Análise, Suporte 2º nível; Resolvidos também no Kanban.
- Tipo: Todos, Suporte, Sugestões.
- Cliente: Todos ou cliente selecionado.
- Colaborador: Todos, Sem colaborador ou usuário selecionado.
- Atualizar lista.

Os resultados são ordenados por criticidade. No modo Tickets, resolvidos podem não estar na lista principal; no Kanban, o quadro inclui chamados resolvidos. Ao abrir um cartão aparecem descrição, conversa, ticket vinculado (se convertido), vínculo com segundo nível, campos de atribuição e ações, respeitando a permissão:

- **Responsável e criticidade:** responsável inicia com o atribuído atualmente ou “Sem responsável”; criticidade inicia no valor atual ou Média. **Salvar alterações** persiste as mudanças; edição não autorizada é ocultada.
- **Status:** botões “Mover para” para transições permitidas. Estados possíveis incluem Aberto, Em Análise, Resolvido e Suporte 2º nível. O ticket original encaminhado ao suporte de segundo nível informa que seu andamento é controlado pela cópia interna.
- **Compartilhar:** abre a concessão empresarial quando autorizado.
- **Converter em Tarefa:** aparece quando ainda não existe tarefa vinculada e para tickets que permitem conversão. Cria uma tarefa associada; depois exibe o vínculo.
- **Excluir ticket:** aparece apenas em registros elegíveis sem vínculo protegido; a tela aplica a confirmação/controle configurado pelo fluxo de exclusão.
- **Visível para o cliente:** alterna visibilidade de tickets criados internamente. Desligado significa que não aparece no portal do cliente.

Chamados vinculados a atendimento de segundo nível preservam o original e a cópia interna: resposta pública e conclusão podem refletir no original, enquanto notas internas ficam na equipe.

### 11.2 Criar ticket

O botão de novo ticket revela o formulário. O rascunho é mantido localmente por usuário, podendo reaparecer após reabrir o formulário.

| Campo | Inicial/opções | Efeito e validação |
|---|---|---|
| Cliente | Vazio | Obrigatório; escolhe cliente da lista. |
| Tipo | Suporte | Suporte ou Sugestão. |
| Título | Vazio | Obrigatório; resumo do ticket. |
| Descrição | Vazia | Obrigatória e precisa conter texto operacional; a Sing avalia clareza e pode pedir complemento. |
| Criticidade | Média | Baixo, Médio, Alto, Crítico, Emergencial. |
| Colaborador responsável | Automático (valor vazio) | Pode escolher responsável; sem escolha, distribuição automática pode atribuir. |
| Visível para o cliente | Desativado | Ativar torna o chamado interno visível no portal. |

**Criar/Enviar** valida cliente, título, descrição e clareza antes de abrir; durante gravação mostra estado ocupado. **Cancelar/fechar** encerra o formulário; o rascunho pode ser restaurado enquanto persistir no armazenamento local. A Sing avalia a descrição; a decisão final de abrir continua explícita pelo usuário.

### 11.3 Conversa, respostas e notas

Ao expandir ticket, a seção **Conversa** carrega cronologia, protocolo e notificações associadas. **Atualizar** busca o histórico novamente.

- **Resposta pública ao cliente:** começa vazia; envio publica mensagem para o cliente.
- **Observação interna:** começa vazia; envio registra nota visível somente para a equipe.
- Enviar mensagem não equivale a alterar status. Cada envio usa chave de idempotência para reduzir duplicação em retry.
- Chamado original de segundo nível fica somente leitura nessa conversa; responder/notar pela cópia interna vinculada.
- Avisos de WhatsApp (quando existentes) mostram estado, evento, horário, remetente e quantidade de tentativas. “Requer conciliação” informa que o sistema interrompeu novo envio para evitar duplicidade.

### 11.4 Encerrar ticket

Mover para Resolvido abre **Registrar Encerramento**:

- **Ocorrência / O que aconteceu:** começa vazia.
- **Solução Adotada:** começa vazia.
- **Validar e concluir:** exige texto operacional em pelo menos um campo e aciona revisão da Sing/encerramento.
- **Cancelar:** fecha sem concluir.

Durante salvamento campos e fechamento ficam bloqueados. Erro mantém o ticket sem encerramento e apresenta mensagem. Para tickets de segundo nível, resposta e conclusão podem ser refletidas no ticket original conforme o vínculo.

### 11.5 Portal dos Clientes e prévia

A guia mostra instruções para convidar o usuário do portal em Cadastros → Clientes → Convidar para o Portal. Uma vez habilitado, o cliente pode ver tarefas permitidas e abrir tickets/sugestões. Chamados internos só aparecem se **Visível para o cliente** estiver ativo.

- Lista de clientes com acesso ativo mostra cliente, usuário e e-mail.
- Atualizar recarrega a lista.
- **Ver prévia** abre modal de leitura com tarefas e tickets que aquele usuário verá, sem editar os dados do cliente.
- **Ir para Equipe / Usuários** navega para o cadastro de usuários quando a navegação é fornecida.

### 11.6 Indicadores

Os filtros são salvos localmente por organização/usuário e inicialmente sem valores; datas em branco consideram os últimos 30 dias.

- De e Até (data final inclusiva);
- Cliente;
- Colaborador;
- Criticidade;
- Competência;
- Status.

Data inicial posterior à final impede carregar o recorte e mostra erro de ordem. **Atualizar dados** busca de novo.

Cartões do resumo incluem chamados no recorte, em aberto, resolvidos, tempo médio de resposta, tempo médio de resolução e mensagens da Sing. Selecionar um cartão muda o indicador utilizado nas classificações/gráficos. Seções recolhíveis e classificações são interativas; respostas/resoluções sem amostra e mensagens humanas aparecem separadamente. Também podem ser executados insights pela Sing e vistas por competência/carga/SLA conforme as seções de dados disponíveis.

**Metas de SLA:** painel separado por criticidade (Baixo, Médio, Alto, Crítico, Emergencial), cada uma com metas em minutos para primeira resposta humana e resolução. Vazio significa “sem meta”. Sugestões visuais iniciais: 48 min para Baixo, 24 para Médio, nenhuma sugestão numérica para Alto, 12 para Crítico e 4 para Emergencial; a configuração carregada do servidor é a referência efetiva. Intervalo aceito: 1 a 525600 minutos. **Salvar** cria nova versão da configuração; conflito exige descartar edição e recarregar antes de repetir.

**Histórico de calendário:** lista/atualiza eventos planejados em conexão com chamados; é informativo e distinto do calendário semanal de tarefas.

## 12. Inventário do escopo de suporte

O CSV registra campos e filtros principais dessa guia. Também há estados de atendimento por cartão, respostas públicas/notas internas, metas de SLA, histórico de planejamento, prévia do portal, indicadores agregados e notificações. Botões de ação podem não aparecer para usuário sem permissão ou para ticket bloqueado por vínculo/estado.


# Guia — Organização > Tarefas

Pacote de referência produzido a partir da leitura do código do projeto.

## Arquivos

- `guia-organizacao-tarefas.md` — telas, guias, formulários, modais, defaults e efeitos das ações.
- `inventario-campos.csv` — inventário tabular de campos e controles, em UTF-8, separado por ponto e vírgula.
- `fontes-e-escopo.md` — arquivos-fonte consultados e limites da documentação.

## Leitura do CSV

Abra como UTF-8 e escolha `;` como separador. O CSV tem quatro colunas; a coluna final combina valor inicial/opções e efeito do acionamento. “Vazio” significa que o campo começa sem valor; o guia explica o comportamento detalhado.

## Limites

O conteúdo descreve o comportamento implementado no código consultado; não é uma gravação de sessão autenticada. A disponibilidade das opções pode variar por organização, permissões, projeto, conexão com Google e resposta do servidor. A documentação não altera dados nem configuração do aplicativo.

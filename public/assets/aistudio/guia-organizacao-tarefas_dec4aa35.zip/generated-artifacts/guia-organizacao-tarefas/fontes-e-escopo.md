# Fontes e escopo

## Escopo principal

“Organização > Tarefas” é documentada como a tela `TarefasView`, iniciada no modo Lista. Inclui os modos Lista, Quadro, Semana e, para quem tem acesso, Central de suporte. Abrange filtros, origem, tarefas e subtarefas, registros de tempo, anexos, compartilhamento e modais que aparecem nesse fluxo.

## Fontes consultadas

- `src/App.tsx` — montagem da tela, navegação e integração com o estado geral.
- `src/components/TarefasView.tsx` — tela principal, Lista, Quadro, filtros, criação, edição, subtarefas e modais.
- `src/components/TaskSourceFilter.tsx` — filtro de origem das tarefas.
- `src/components/WeeklyPlanner.tsx` — grade semanal, arraste, agendamento e cartões.
- `src/components/EntityField.tsx` — seleção e cadastro rápido de cliente/colaborador.
- `src/components/EnterpriseShareModal.tsx` — concessão e revogação de compartilhamento.
- `src/components/AttachmentViewer.tsx` — abertura/visualização de anexos.
- `src/components/HelpdeskView.tsx` — Central de suporte incorporada.
- `src/components/HelpdeskKanban.tsx` — quadro do suporte.
- `src/components/HelpdeskIndicatorsPanel.tsx` — indicadores do suporte.
- `src/components/HelpdeskSlaSettings.tsx` — metas de SLA por criticidade.
- `src/components/HelpdeskCalendarHistory.tsx` — histórico de agendamentos do suporte.
- `src/components/HelpdeskCompletionDialog.tsx` — encerramento de ticket do suporte.
- `src/components/HelpdeskTicketSummary.tsx` — resumo e dados do cartão de ticket.
- `src/services/task-status.ts` — colunas/status de fallback e resolução de status.
- `shared/task-project.ts` — regras de origem e inclusão de tarefas.
- `src/types.ts` — tipos dos dados de tarefas, subtarefas e anexos.
- `src/services/api.ts` — chamadas de serviço usadas pela tela.

## Como interpretar os dados

- Os valores chamados “padrão” são iniciais do estado do formulário ou fallback no código. Uma configuração salva no servidor pode substituí-los.
- Opções como cliente, projeto, colaborador, marcos e permissões dependem do catálogo e da organização ativa.
- Recursos Google só aparecem se a conexão estiver disponível.
- A tela pode ser aberta em escopo de projeto; nesse caso filtros de origem e alguns vínculos ficam restritos.
- Nenhuma operação real foi executada durante a elaboração deste pacote.
- Este inventário foi derivado da implementação e dos rótulos/callbacks, não de um teste visual autenticado de cada caso de permissão. Um rótulo pode mudar sem mudar o efeito interno descrito.

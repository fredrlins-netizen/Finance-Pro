# Opções e diálogos dos plugins TinyMCE instalados

Versão: 8.3.2. Este é um inventário de biblioteca, não garantia de exibição de cada item em toda seleção. Valores são os rótulos originais em inglês; a aplicação não configura pacote de idioma neste componente.

## image

### Rótulos, comandos e opções por contexto

- Advanced
- Vertical space
- Horizontal space
- Border width
- Border style
- Select...
- Solid
- Dotted
- Dashed
- Double
- Groove
- Ridge
- Inset
- Outset
- None
- Hidden
- Source
- Image list
- Alternative description
- Image title
- Accessibility
- Image is decorative
- Class
- Caption
- Show caption
- General
- Upload
- Insert/Edit Image
- Cancel
- Save
- Insert/edit image
- Image...

### Declarações de configuração padrão

| Opção | Definição no plugin |
| --- | --- |
| image_dimensions | processor: 'boolean',<br>            default: true |
| image_advtab | processor: 'boolean',<br>            default: false |
| image_uploadtab | processor: 'boolean',<br>            default: true |
| image_prepend_url | processor: 'string',<br>            default: '' |
| image_class_list | processor: 'object[]' |
| image_description | processor: 'boolean',<br>            default: true |
| image_title | processor: 'boolean',<br>            default: false |
| image_caption | processor: 'boolean',<br>            default: false |
| image_list | processor: (value) => {<br>                const valid = value === false \|\| isString(value) \|\| isArrayOf(value, isObject) \|\| isFunction(value);<br>                return valid ? { value, valid } : { valid: false, message: 'Must be false, a string, an array or a function.' };<br>            },<br>            default: false |


## link

### Rótulos, comandos e opções por contexto

- None
- Current window
- New window
- Upload
- General
- URL
- Text to display
- Title
- Insert/Edit Link
- Cancel
- Save
- Insert/edit link
- Open link
- Remove link
- Link...
- Link

### Declarações de configuração padrão

| Opção | Definição no plugin |
| --- | --- |
| link_assume_external_targets | processor: (value) => {<br>                const valid = isString(value) \|\| isBoolean(value);<br>                if (valid) {<br>                    if (value === true) {<br>                        return { value: 1 /* AssumeExternalTargets.WARN */, valid };<br>                    }<br>                    else if (value === "http" /* AssumeExternalTargets.ALWAYS_HTTP */ \|\| value === "https" /* AssumeExternalTargets.ALWAYS_HTTPS */) {<br>                        return { value, valid };<br>                    }<br>                    else {<br>                        return { value: 0 /* AssumeExternalTargets.OFF */, valid };<br>                    }<br>                }<br>                else {<br>                    return { valid: false, message: 'Must be a string or a boolean.' };<br>                }<br>            },<br>            default: false |
| link_context_toolbar | processor: 'boolean',<br>            default: false |
| link_list | processor: (value) => isString(value) \|\| isFunction(value) \|\| isArrayOf(value, isObject) |
| link_default_target | processor: 'string' |
| link_default_protocol | processor: 'string',<br>            default: 'https' |
| link_target_list | processor: (value) => isBoolean(value) \|\| isArrayOf(value, isObject),<br>            default: true |
| link_rel_list | processor: 'object[]',<br>            default: [] |
| link_class_list | processor: 'object[]',<br>            default: [] |
| link_title | processor: 'boolean',<br>            default: true |
| allow_unsafe_link_target | processor: 'boolean',<br>            default: false |
| link_quicklink | processor: 'boolean',<br>            default: false |
| link_attributes_postprocess | processor: 'function', |
| files_upload_handler | processor: 'function' |
| link_uploadtab | processor: 'boolean',<br>            default: true |


## table

### Rótulos, comandos e opções por contexto

- None
- Top
- Middle
- Bottom
- Select...
- Class
- Width
- Cell type
- Cell
- Header cell
- Scope
- Row
- Column
- Row group
- Column group
- Horizontal align
- Left
- Center
- Right
- Vertical align
- Border style
- Border color
- Background color
- Border width
- Advanced
- General
- Cell Properties
- Cancel
- Save
- Row type
- Header
- Body
- Footer
- Alignment
- Height
- Row Properties
- Cols
- Rows
- Cell spacing
- Cell padding
- Caption
- Show caption
- Table Properties
- Table
- Table properties
- Delete table
- Cell properties
- Merge cells
- Split cell
- Insert row before
- Insert row after
- Delete row
- Row properties
- Insert column before
- Insert column after
- Delete column
- Cut row
- Copy row
- Paste row before
- Paste row after
- Cut column
- Copy column
- Paste column before
- Paste column after
- Insert table
- Table styles
- Cell styles
- Table caption
- Row header
- Column header

### Declarações de configuração padrão

| Opção | Definição no plugin |
| --- | --- |
| table_border_widths | processor: 'object[]',<br>            default: defaultCellBorderWidths |
| table_border_styles | processor: 'object[]',<br>            default: defaultCellBorderStyles |
| table_cell_advtab | processor: 'boolean',<br>            default: true |
| table_row_advtab | processor: 'boolean',<br>            default: true |
| table_advtab | processor: 'boolean',<br>            default: true |
| table_appearance_options | processor: 'boolean',<br>            default: true |
| table_grid | processor: 'boolean',<br>            // Table grid relies on hover, which isn't available on touch devices so use the dialog instead<br>            default: !global$1.deviceType.isTouch() |
| table_cell_class_list | processor: 'object[]',<br>            default: [] |
| table_row_class_list | processor: 'object[]',<br>            default: [] |
| table_class_list | processor: 'object[]',<br>            default: [] |
| table_toolbar | processor: 'string',<br>            default: defaultTableToolbar |
| table_background_color_map | processor: 'object[]',<br>            default: [] |
| table_border_color_map | processor: 'object[]',<br>            default: [] |


## code

### Rótulos, comandos e opções por contexto

- Source Code
- Cancel
- Save
- Source code

### Declarações de configuração padrão

| Opção | Definição no plugin |
| --- | --- |



## pagebreak

### Rótulos, comandos e opções por contexto

- Page break

### Declarações de configuração padrão

| Opção | Definição no plugin |
| --- | --- |
| pagebreak_separator | processor: 'string',<br>            default: '<!-- pagebreak -->' |
| pagebreak_split_block | processor: 'boolean',<br>            default: false |


## lists

### Rótulos, comandos e opções por contexto

- List Properties
- Start list at number
- Cancel
- Save
- Numbered list
- Bullet list
- List properties...

### Declarações de configuração padrão

| Opção | Definição no plugin |
| --- | --- |




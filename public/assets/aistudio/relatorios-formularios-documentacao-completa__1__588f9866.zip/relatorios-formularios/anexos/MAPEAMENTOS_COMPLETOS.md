# Mapeamentos completos de preenchimento

Extraídos da árvore sintática; expressões são código de origem, não valores de dados reais. SEM MAPEAMENTO significa que aquele renderizador não possui a chave; um token ausente pode permanecer literal no documento.

## admissao_html — 76 chaves

| Token | Expressão de origem / valor padrão | Evidência |
| --- | --- | --- |
| {{cliente.id}} | clientObj?.id \|\| '' | utils/admissionVariables.ts:84 |
| {{cliente.nome}} | clientObj?.name \|\| data.clientName \|\| '' | utils/admissionVariables.ts:85 |
| {{cliente.tipo}} | clientObj?.type \|\| '' | utils/admissionVariables.ts:86 |
| {{cliente.documento}} | clientObj?.document \|\| '' | utils/admissionVariables.ts:87 |
| {{cliente.rg}} | clientObj?.rg \|\| '' | utils/admissionVariables.ts:88 |
| {{cliente.email}} | clientObj?.email \|\| '' | utils/admissionVariables.ts:89 |
| {{cliente.telefone}} | clientObj?.phone \|\| '' | utils/admissionVariables.ts:90 |
| {{cliente.telefone2}} | clientObj?.phone2 \|\| '' | utils/admissionVariables.ts:91 |
| {{cliente.whatsapp}} | clientObj?.isWhatsapp ? 'Sim' : 'Não' | utils/admissionVariables.ts:92 |
| {{cliente.profissao}} | clientObj?.profession \|\| '' | utils/admissionVariables.ts:93 |
| {{cliente.estado_civil}} | clientObj?.maritalStatus \|\| '' | utils/admissionVariables.ts:94 |
| {{cliente.data_nascimento}} | clientObj?.birthDate ? new Date(clientObj.birthDate).toLocaleDateString('pt-BR') : '' | utils/admissionVariables.ts:95 |
| {{cliente.cep}} | clientObj?.cep \|\| '' | utils/admissionVariables.ts:96 |
| {{cliente.endereco}} | clientObj?.address \|\| '' | utils/admissionVariables.ts:97 |
| {{cliente.numero}} | clientObj?.number \|\| '' | utils/admissionVariables.ts:98 |
| {{cliente.complemento}} | clientObj?.complement \|\| '' | utils/admissionVariables.ts:99 |
| {{cliente.bairro}} | clientObj?.district \|\| '' | utils/admissionVariables.ts:100 |
| {{cliente.cidade}} | clientObj?.city \|\| '' | utils/admissionVariables.ts:101 |
| {{cliente.uf}} | clientObj?.state \|\| '' | utils/admissionVariables.ts:102 |
| {{cliente.anotacoes}} | clientObj?.notes \|\| '' | utils/admissionVariables.ts:103 |
| {{banco.id}} | bank?.id \|\| '' | utils/admissionVariables.ts:104 |
| {{banco.nome}} | bank?.name \|\| '' | utils/admissionVariables.ts:105 |
| {{colaborador.id}} | collaborator?.id \|\| '' | utils/admissionVariables.ts:106 |
| {{colaborador.nome}} | collaborator?.name \|\| '' | utils/admissionVariables.ts:107 |
| {{empresa.razao_social}} | unit?.razaoSocial \|\| '' | utils/admissionVariables.ts:108 |
| {{empresa.cnpj}} | unit?.cnpj \|\| '' | utils/admissionVariables.ts:109 |
| {{empresa.telefone}} | unit?.telefone \|\| '' | utils/admissionVariables.ts:110 |
| {{empresa.email}} | unit?.email \|\| '' | utils/admissionVariables.ts:111 |
| {{empresa.cep}} | unit?.cep \|\| '' | utils/admissionVariables.ts:112 |
| {{empresa.endereco}} | unit?.endereco \|\| '' | utils/admissionVariables.ts:113 |
| {{empresa.numero}} | unit?.numero \|\| '' | utils/admissionVariables.ts:114 |
| {{empresa.complemento}} | unit?.complemento \|\| '' | utils/admissionVariables.ts:115 |
| {{empresa.bairro}} | unit?.bairro \|\| '' | utils/admissionVariables.ts:116 |
| {{empresa.cidade}} | unit?.cidade \|\| '' | utils/admissionVariables.ts:117 |
| {{empresa.uf}} | unit?.estado \|\| '' | utils/admissionVariables.ts:118 |
| {{empresa.taxa_minima}} | unit?.taxaMinima \|\| '' | utils/admissionVariables.ts:119 |
| {{admissao.id}} | data.id \|\| '' | utils/admissionVariables.ts:120 |
| {{admissao.data}} | data.date ? new Date(data.date).toLocaleDateString('pt-BR') : '' | utils/admissionVariables.ts:121 |
| {{admissao.cliente}} | data.clientName \|\| '' | utils/admissionVariables.ts:122 |
| {{admissao.contrato}} | data.contractNumber \|\| '' | utils/admissionVariables.ts:123 |
| {{admissao.total_parcelas}} | data.totalInstallments \|\| '' | utils/admissionVariables.ts:124 |
| {{admissao.parcelas_pagas}} | data.paidInstallments \|\| '' | utils/admissionVariables.ts:125 |
| {{admissao.parcelas_atraso}} | data.overdueInstallments \|\| '' | utils/admissionVariables.ts:126 |
| {{admissao.parcelas_a_pagar}} | parcelasAPagar | utils/admissionVariables.ts:127 |
| {{admissao.valor_financiado}} | data.financedAmount \|\| '' | utils/admissionVariables.ts:128 |
| {{admissao.valor_parcela}} | data.installmentValue \|\| '' | utils/admissionVariables.ts:129 |
| {{admissao.dia_vencimento}} | data.dueDay \|\| '' | utils/admissionVariables.ts:130 |
| {{admissao.forma_pagamento}} | data.paymentType \|\| '' | utils/admissionVariables.ts:131 |
| {{admissao.tipo_indicacao}} | data.indicationType \|\| '' | utils/admissionVariables.ts:132 |
| {{admissao.tipo_origem}} | data.originType \|\| '' | utils/admissionVariables.ts:133 |
| {{admissao.status}} | data.status \|\| '' | utils/admissionVariables.ts:134 |
| {{admissao.taxa_administrativa}} | data.parcela1 \|\| '' | utils/admissionVariables.ts:135 |
| {{admissao.parcela1}} | data.parcela1 \|\| '' | utils/admissionVariables.ts:136 |
| {{admissao.parcela_inicial}} | data.parcela2 \|\| '' | utils/admissionVariables.ts:137 |
| {{admissao.parcela2}} | data.parcela2 \|\| '' | utils/admissionVariables.ts:138 |
| {{admissao.valor_boletos}} | data.taxaCobranca \|\| '' | utils/admissionVariables.ts:139 |
| {{admissao.taxa_cobranca}} | data.taxaCobranca \|\| '' | utils/admissionVariables.ts:140 |
| {{admissao.info1}} | data.otherInfo1 \|\| '' | utils/admissionVariables.ts:141 |
| {{admissao.info2}} | data.otherInfo2 \|\| '' | utils/admissionVariables.ts:142 |
| {{admissao.marca_veiculo}} | data.vehicleBrand \|\| '' | utils/admissionVariables.ts:143 |
| {{admissao.modelo_veiculo}} | data.vehicleModel \|\| '' | utils/admissionVariables.ts:144 |
| {{admissao.cor_veiculo}} | data.vehicleColor \|\| '' | utils/admissionVariables.ts:145 |
| {{admissao.ano_veiculo}} | data.vehicleYear \|\| '' | utils/admissionVariables.ts:146 |
| {{admissao.placa}} | data.vehiclePlate \|\| '' | utils/admissionVariables.ts:147 |
| {{admissao.chassi}} | data.vehicleChassis \|\| '' | utils/admissionVariables.ts:148 |
| {{admissao.renavam}} | data.vehicleRenavam \|\| '' | utils/admissionVariables.ts:149 |
| {{admissao.primeiro_vencimento}} | data.firstInstallmentDueDate \|\| '' | utils/admissionVariables.ts:150 |
| {{modalidade.id}} | modality?.id \|\| '' | utils/admissionVariables.ts:151 |
| {{modalidade.tipo}} | modality?.type \|\| '' | utils/admissionVariables.ts:152 |
| {{modalidade.descricao}} | modality?.description \|\| '' | utils/admissionVariables.ts:153 |
| {{recalculo.parcelas_a_pagar}} | scenario?.installmentsToPay \|\| parcelasAPagar | utils/admissionVariables.ts:154 |
| {{recalculo.divida_original}} | scenario?.originalDebt \|\| '' | utils/admissionVariables.ts:155 |
| {{recalculo.parcela}} | scenario?.installmentValue \|\| '' | utils/admissionVariables.ts:156 |
| {{recalculo.divida}} | scenario?.newDebt \|\| '' | utils/admissionVariables.ts:157 |
| {{recalculo.economia}} | scenario?.savings \|\| '' | utils/admissionVariables.ts:158 |
| {{recalculo.dia_vencimento}} | scenario?.dueDay \|\| '' | utils/admissionVariables.ts:159 |

## auditoria_html — 103 chaves

| Token | Expressão de origem / valor padrão | Evidência |
| --- | --- | --- |
| {{cliente.id}} | client?.id \|\| '' | components/atendimento/AuditPanel.tsx:645 |
| {{cliente.nome}} | client?.name \|\| admission.clientName \|\| '' | components/atendimento/AuditPanel.tsx:646 |
| {{cliente.tipo}} | client?.type \|\| '' | components/atendimento/AuditPanel.tsx:647 |
| {{cliente.documento}} | client?.document \|\| '' | components/atendimento/AuditPanel.tsx:648 |
| {{cliente.rg}} | client?.rg \|\| '' | components/atendimento/AuditPanel.tsx:649 |
| {{cliente.email}} | client?.email \|\| '' | components/atendimento/AuditPanel.tsx:650 |
| {{cliente.telefone}} | client?.phone \|\| '' | components/atendimento/AuditPanel.tsx:651 |
| {{cliente.telefone2}} | client?.phone2 \|\| '' | components/atendimento/AuditPanel.tsx:652 |
| {{cliente.profissao}} | client?.profession \|\| '' | components/atendimento/AuditPanel.tsx:653 |
| {{cliente.estado_civil}} | client?.maritalStatus \|\| '' | components/atendimento/AuditPanel.tsx:654 |
| {{cliente.data_nascimento}} | fmtDate(client?.birthDate) | components/atendimento/AuditPanel.tsx:655 |
| {{cliente.cep}} | client?.cep \|\| '' | components/atendimento/AuditPanel.tsx:656 |
| {{cliente.endereco}} | client?.address \|\| '' | components/atendimento/AuditPanel.tsx:657 |
| {{cliente.numero}} | client?.number \|\| '' | components/atendimento/AuditPanel.tsx:658 |
| {{cliente.complemento}} | client?.complement \|\| '' | components/atendimento/AuditPanel.tsx:659 |
| {{cliente.bairro}} | client?.district \|\| '' | components/atendimento/AuditPanel.tsx:660 |
| {{cliente.cidade}} | client?.city \|\| '' | components/atendimento/AuditPanel.tsx:661 |
| {{cliente.uf}} | client?.state \|\| '' | components/atendimento/AuditPanel.tsx:662 |
| {{cliente.anotacoes}} | client?.notes \|\| '' | components/atendimento/AuditPanel.tsx:663 |
| {{titular.id}} | titular?.id \|\| '' | components/atendimento/AuditPanel.tsx:665 |
| {{titular.nome}} | titular?.name \|\| '' | components/atendimento/AuditPanel.tsx:666 |
| {{titular.tipo}} | titular?.type \|\| '' | components/atendimento/AuditPanel.tsx:667 |
| {{titular.documento}} | titular?.document \|\| '' | components/atendimento/AuditPanel.tsx:668 |
| {{titular.rg}} | titular?.rg \|\| '' | components/atendimento/AuditPanel.tsx:669 |
| {{titular.email}} | titular?.email \|\| '' | components/atendimento/AuditPanel.tsx:670 |
| {{titular.telefone}} | titular?.phone \|\| '' | components/atendimento/AuditPanel.tsx:671 |
| {{titular.telefone2}} | titular?.phone2 \|\| '' | components/atendimento/AuditPanel.tsx:672 |
| {{titular.profissao}} | titular?.profession \|\| '' | components/atendimento/AuditPanel.tsx:673 |
| {{titular.estado_civil}} | titular?.maritalStatus \|\| '' | components/atendimento/AuditPanel.tsx:674 |
| {{titular.data_nascimento}} | fmtDate(titular?.birthDate) | components/atendimento/AuditPanel.tsx:675 |
| {{titular.cep}} | titular?.cep \|\| '' | components/atendimento/AuditPanel.tsx:676 |
| {{titular.endereco}} | titular?.address \|\| '' | components/atendimento/AuditPanel.tsx:677 |
| {{titular.numero}} | titular?.number \|\| '' | components/atendimento/AuditPanel.tsx:678 |
| {{titular.complemento}} | titular?.complement \|\| '' | components/atendimento/AuditPanel.tsx:679 |
| {{titular.bairro}} | titular?.district \|\| '' | components/atendimento/AuditPanel.tsx:680 |
| {{titular.cidade}} | titular?.city \|\| '' | components/atendimento/AuditPanel.tsx:681 |
| {{titular.uf}} | titular?.state \|\| '' | components/atendimento/AuditPanel.tsx:682 |
| {{titular.anotacoes}} | titular?.notes \|\| '' | components/atendimento/AuditPanel.tsx:683 |
| {{banco.id}} | bank?.id \|\| '' | components/atendimento/AuditPanel.tsx:685 |
| {{banco.nome}} | bank?.name \|\| '' | components/atendimento/AuditPanel.tsx:686 |
| {{colaborador.id}} | collaborator?.id \|\| '' | components/atendimento/AuditPanel.tsx:688 |
| {{colaborador.nome}} | collaborator?.name \|\| '' | components/atendimento/AuditPanel.tsx:689 |
| {{empresa.razao_social}} | unit?.razaoSocial \|\| '' | components/atendimento/AuditPanel.tsx:691 |
| {{empresa.cnpj}} | unit?.cnpj \|\| '' | components/atendimento/AuditPanel.tsx:692 |
| {{empresa.telefone}} | unit?.telefone \|\| '' | components/atendimento/AuditPanel.tsx:693 |
| {{empresa.email}} | unit?.email \|\| '' | components/atendimento/AuditPanel.tsx:694 |
| {{empresa.cep}} | unit?.cep \|\| '' | components/atendimento/AuditPanel.tsx:695 |
| {{empresa.endereco}} | unit?.endereco \|\| '' | components/atendimento/AuditPanel.tsx:696 |
| {{empresa.numero}} | unit?.numero \|\| '' | components/atendimento/AuditPanel.tsx:697 |
| {{empresa.complemento}} | unit?.complemento \|\| '' | components/atendimento/AuditPanel.tsx:698 |
| {{empresa.bairro}} | unit?.bairro \|\| '' | components/atendimento/AuditPanel.tsx:699 |
| {{empresa.cidade}} | unit?.cidade \|\| '' | components/atendimento/AuditPanel.tsx:700 |
| {{empresa.uf}} | unit?.estado \|\| '' | components/atendimento/AuditPanel.tsx:701 |
| {{admissao.id}} | admission.id \|\| '' | components/atendimento/AuditPanel.tsx:703 |
| {{admissao.data}} | fmtDate(admission.date) | components/atendimento/AuditPanel.tsx:704 |
| {{admissao.cliente}} | admission.clientName \|\| '' | components/atendimento/AuditPanel.tsx:705 |
| {{admissao.contrato}} | admission.contractNumber \|\| '' | components/atendimento/AuditPanel.tsx:706 |
| {{admissao.tipo_cliente}} | admission.tipoCliente \|\| 'RESPONSÁVEL' | components/atendimento/AuditPanel.tsx:707 |
| {{admissao.total_parcelas}} | admission.totalInstallments \|\| '' | components/atendimento/AuditPanel.tsx:708 |
| {{admissao.parcelas_pagas}} | admission.paidInstallments \|\| '' | components/atendimento/AuditPanel.tsx:709 |
| {{admissao.parcelas_atraso}} | admission.overdueInstallments \|\| '' | components/atendimento/AuditPanel.tsx:710 |
| {{admissao.parcelas_a_pagar}} | parcelasAPagar | components/atendimento/AuditPanel.tsx:711 |
| {{admissao.valor_financiado}} | admission.financedAmount \|\| '' | components/atendimento/AuditPanel.tsx:712 |
| {{admissao.valor_parcela}} | admission.installmentValue \|\| '' | components/atendimento/AuditPanel.tsx:713 |
| {{admissao.dia_vencimento}} | admission.dueDay \|\| '' | components/atendimento/AuditPanel.tsx:714 |
| {{admissao.forma_pagamento}} | admission.paymentType \|\| '' | components/atendimento/AuditPanel.tsx:715 |
| {{admissao.status}} | admission.status \|\| '' | components/atendimento/AuditPanel.tsx:716 |
| {{admissao.taxa_administrativa}} | admission.taxaCobranca \|\| '' | components/atendimento/AuditPanel.tsx:717 |
| {{admissao.veiculo_marca}} | admission.vehicleBrand \|\| '' | components/atendimento/AuditPanel.tsx:718 |
| {{admissao.veiculo_modelo}} | admission.vehicleModel \|\| '' | components/atendimento/AuditPanel.tsx:719 |
| {{admissao.veiculo_cor}} | admission.vehicleColor \|\| '' | components/atendimento/AuditPanel.tsx:720 |
| {{admissao.veiculo_ano}} | admission.vehicleYear \|\| '' | components/atendimento/AuditPanel.tsx:721 |
| {{admissao.veiculo_placa}} | admission.vehiclePlate \|\| '' | components/atendimento/AuditPanel.tsx:722 |
| {{admissao.veiculo_renavam}} | admission.vehicleRenavam \|\| '' | components/atendimento/AuditPanel.tsx:723 |
| {{admissao.veiculo_chassi}} | admission.vehicleChassis \|\| '' | components/atendimento/AuditPanel.tsx:724 |
| {{admissao.marca_veiculo}} | admission.vehicleBrand \|\| '' | components/atendimento/AuditPanel.tsx:725 |
| {{admissao.modelo_veiculo}} | admission.vehicleModel \|\| '' | components/atendimento/AuditPanel.tsx:726 |
| {{admissao.cor_veiculo}} | admission.vehicleColor \|\| '' | components/atendimento/AuditPanel.tsx:727 |
| {{admissao.ano_veiculo}} | admission.vehicleYear \|\| '' | components/atendimento/AuditPanel.tsx:728 |
| {{admissao.placa}} | admission.vehiclePlate \|\| '' | components/atendimento/AuditPanel.tsx:729 |
| {{admissao.renavam}} | admission.vehicleRenavam \|\| '' | components/atendimento/AuditPanel.tsx:730 |
| {{admissao.chassi}} | admission.vehicleChassis \|\| '' | components/atendimento/AuditPanel.tsx:731 |
| {{admissao.parcela1}} | admission.parcela1 \|\| '' | components/atendimento/AuditPanel.tsx:732 |
| {{admissao.parcela2}} | admission.parcela2 \|\| '' | components/atendimento/AuditPanel.tsx:733 |
| {{admissao.info1}} | admission.otherInfo1 \|\| '' | components/atendimento/AuditPanel.tsx:734 |
| {{admissao.info2}} | admission.otherInfo2 \|\| '' | components/atendimento/AuditPanel.tsx:735 |
| {{admissao.tipo_indicacao}} | admission.indicationType \|\| '' | components/atendimento/AuditPanel.tsx:736 |
| {{admissao.tipo_origem}} | admission.originType \|\| '' | components/atendimento/AuditPanel.tsx:737 |
| {{admissao.primeiro_vencimento}} | admission.firstInstallmentDueDate ? fmtDate(admission.firstInstallmentDueDate) : '' | components/atendimento/AuditPanel.tsx:738 |
| {{modalidade.id}} | modality?.id \|\| '' | components/atendimento/AuditPanel.tsx:740 |
| {{modalidade.tipo}} | modality?.type \|\| '' | components/atendimento/AuditPanel.tsx:741 |
| {{modalidade.descricao}} | modality?.description \|\| '' | components/atendimento/AuditPanel.tsx:742 |
| {{recalculo.divida_original}} | scenario?.originalDebt \|\| '' | components/atendimento/AuditPanel.tsx:744 |
| {{recalculo.parcela}} | scenario?.installmentValue \|\| '' | components/atendimento/AuditPanel.tsx:745 |
| {{recalculo.divida}} | scenario?.newDebt \|\| '' | components/atendimento/AuditPanel.tsx:746 |
| {{recalculo.economia}} | scenario?.savings \|\| '' | components/atendimento/AuditPanel.tsx:747 |
| {{recalculo.dia_vencimento}} | scenario?.dueDay \|\| '' | components/atendimento/AuditPanel.tsx:748 |
| {{data.hoje}} | now.toLocaleDateString('pt-BR', dateOptions) | components/atendimento/AuditPanel.tsx:750 |
| {{data.extenso}} | now.toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' }) | components/atendimento/AuditPanel.tsx:751 |
| {{data.dia_semana}} | now.toLocaleDateString('pt-BR', { weekday: 'long' }) | components/atendimento/AuditPanel.tsx:752 |
| {{data.mes}} | now.toLocaleDateString('pt-BR', { month: 'long' }) | components/atendimento/AuditPanel.tsx:753 |
| {{data.ano}} | String(now.getFullYear()) | components/atendimento/AuditPanel.tsx:754 |
| {{hora.atual}} | now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) | components/atendimento/AuditPanel.tsx:755 |

## processos_grid — 19 chaves

| Token | Expressão de origem / valor padrão | Evidência |
| --- | --- | --- |
| {{processo.numero}} | proc.processNumber \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:173 |
| {{processo.vara}} | proc.court \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:174 |
| {{processo.comarca}} | proc.jurisdiction \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:175 |
| {{processo.tipo}} | proc.type \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:176 |
| {{processo.status}} | proc.status \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:177 |
| {{processo.assunto}} | proc.subject \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:178 |
| {{processo.valor_causa}} | proc.causeValue \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:179 |
| {{processo.valor_provisionado}} | proc.provisionValue \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:180 |
| {{processo.risco}} | proc.riskLevel \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:181 |
| {{processo.parte_adversa}} | proc.opposingParty \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:182 |
| {{processo.advogado_responsavel}} | proc.responsibleLawyer \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:183 |
| {{cliente.nome}} | partner?.name \|\| proc.opposingParty \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:184 |
| {{cliente.documento}} | partner?.document \|\| proc.opposingPartyDocument \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:185 |
| {{cliente.telefone}} | partner?.phone \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:186 |
| {{empresa.razao_social}} | unit.razaoSocial \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:187 |
| {{empresa.cnpj}} | unit.cnpj \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:188 |
| {{empresa.cidade}} | unit.cidade \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:189 |
| {{colaborador.nome}} | proc.responsibleLawyer \|\| '' | components/acompanhamento-juridico/ProcessList.tsx:190 |
| {{data.hoje}} | new Date().toLocaleDateString('pt-BR') | components/acompanhamento-juridico/ProcessList.tsx:191 |

## processos_detalhes — 19 chaves

| Token | Expressão de origem / valor padrão | Evidência |
| --- | --- | --- |
| {{processo.numero}} | process.processNumber \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:175 |
| {{processo.vara}} | process.court \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:176 |
| {{processo.comarca}} | process.jurisdiction \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:177 |
| {{processo.tipo}} | process.type \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:178 |
| {{processo.status}} | process.status \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:179 |
| {{processo.assunto}} | process.subject \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:180 |
| {{processo.valor_causa}} | process.causeValue \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:181 |
| {{processo.valor_provisionado}} | process.provisionValue \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:182 |
| {{processo.risco}} | process.riskLevel \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:183 |
| {{processo.parte_adversa}} | process.opposingParty \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:184 |
| {{processo.advogado_responsavel}} | process.responsibleLawyer \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:185 |
| {{cliente.nome}} | partner?.name \|\| process.opposingParty \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:186 |
| {{cliente.documento}} | partner?.document \|\| process.opposingPartyDocument \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:187 |
| {{cliente.telefone}} | partner?.phone \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:188 |
| {{empresa.razao_social}} | unit.razaoSocial \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:189 |
| {{empresa.cnpj}} | unit.cnpj \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:190 |
| {{empresa.cidade}} | unit.cidade \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:191 |
| {{colaborador.nome}} | process.responsibleLawyer \|\| '' | components/acompanhamento-juridico/ProcessDetail.tsx:192 |
| {{data.hoje}} | new Date().toLocaleDateString('pt-BR') | components/acompanhamento-juridico/ProcessDetail.tsx:193 |

## processos_formulario — 29 chaves

| Token | Expressão de origem / valor padrão | Evidência |
| --- | --- | --- |
| {{processo.numero}} | formData.processNumber \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:199 |
| {{processo.vara}} | formData.court \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:200 |
| {{processo.comarca}} | formData.jurisdiction \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:201 |
| {{processo.tipo}} | formData.type \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:202 |
| {{processo.papel}} | formData.role \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:203 |
| {{processo.status}} | formData.status \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:204 |
| {{processo.assunto}} | formData.subject \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:205 |
| {{processo.valor_causa}} | formData.causeValue \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:206 |
| {{processo.valor_provisionado}} | formData.provisionValue \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:207 |
| {{processo.risco}} | formData.riskLevel \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:208 |
| {{processo.data_distribuicao}} | formData.distributionDate ? new Date(formData.distributionDate).toLocaleDateString('pt-BR') : '' | components/acompanhamento-juridico/ProcessForm.tsx:209 |
| {{processo.parte_adversa}} | formData.opposingParty \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:210 |
| {{processo.documento_adversa}} | formData.opposingPartyDocument \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:211 |
| {{processo.advogado_adverso}} | formData.opposingPartyLawyer \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:212 |
| {{processo.oab_adverso}} | formData.opposingPartyLawyerOAB \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:213 |
| {{processo.advogado_responsavel}} | formData.responsibleLawyer \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:214 |
| {{cliente.nome}} | partner?.name \|\| formData.opposingParty \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:215 |
| {{cliente.documento}} | partner?.document \|\| formData.opposingPartyDocument \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:216 |
| {{cliente.telefone}} | partner?.phone \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:217 |
| {{cliente.email}} | partner?.email \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:218 |
| {{empresa.razao_social}} | unit.razaoSocial \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:219 |
| {{empresa.cnpj}} | unit.cnpj \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:220 |
| {{empresa.telefone}} | unit.telefone \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:221 |
| {{empresa.endereco}} | unit.endereco \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:222 |
| {{empresa.cidade}} | unit.cidade \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:223 |
| {{empresa.uf}} | unit.estado \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:224 |
| {{colaborador.nome}} | lawyer?.name \|\| formData.responsibleLawyer \|\| '' | components/acompanhamento-juridico/ProcessForm.tsx:225 |
| {{data.hoje}} | new Date().toLocaleDateString('pt-BR') | components/acompanhamento-juridico/ProcessForm.tsx:226 |
| {{data.extenso}} | new Date().toLocaleDateString('pt-BR', { day: 'numeric', month: 'long', year: 'numeric' }) | components/acompanhamento-juridico/ProcessForm.tsx:227 |

## admissao_docx — 51 chaves

| Token | Expressão de origem / valor padrão | Evidência |
| --- | --- | --- |
| {{id}} | data.id \|\| '' | utils/admissionVariables.ts:12 |
| {{date}} | data.date ? new Date(data.date).toLocaleDateString('pt-BR') : '' | utils/admissionVariables.ts:13 |
| {{clientName}} | data.clientName \|\| '' | utils/admissionVariables.ts:14 |
| {{clientDocument}} | client?.document \|\| '' | utils/admissionVariables.ts:15 |
| {{clientPhone}} | client?.phone \|\| '' | utils/admissionVariables.ts:16 |
| {{clientEmail}} | client?.email \|\| '' | utils/admissionVariables.ts:17 |
| {{clientAddress}} | client?.address \|\| '' | utils/admissionVariables.ts:18 |
| {{clientCity}} | client?.city \|\| '' | utils/admissionVariables.ts:19 |
| {{clientState}} | client?.state \|\| '' | utils/admissionVariables.ts:20 |
| {{clientCep}} | client?.cep \|\| '' | utils/admissionVariables.ts:21 |
| {{clientBirthDate}} | client?.birthDate \|\| '' | utils/admissionVariables.ts:22 |
| {{clientRg}} | client?.rg \|\| '' | utils/admissionVariables.ts:23 |
| {{clientDistrict}} | client?.district \|\| '' | utils/admissionVariables.ts:24 |
| {{clientNumber}} | client?.number \|\| '' | utils/admissionVariables.ts:25 |
| {{clientComplement}} | client?.complement \|\| '' | utils/admissionVariables.ts:26 |
| {{bankName}} | bank?.name \|\| '' | utils/admissionVariables.ts:27 |
| {{collaboratorName}} | collaborator?.name \|\| '' | utils/admissionVariables.ts:28 |
| {{seriesName}} | series?.description \|\| '' | utils/admissionVariables.ts:29 |
| {{seriesSigla}} | series?.sigla \|\| '' | utils/admissionVariables.ts:30 |
| {{modalityName}} | modality?.description \|\| '' | utils/admissionVariables.ts:31 |
| {{modalityType}} | modality?.type \|\| '' | utils/admissionVariables.ts:32 |
| {{contractNumber}} | data.contractNumber \|\| '' | utils/admissionVariables.ts:33 |
| {{totalInstallments}} | data.totalInstallments \|\| '' | utils/admissionVariables.ts:34 |
| {{paidInstallments}} | data.paidInstallments \|\| '' | utils/admissionVariables.ts:35 |
| {{overdueInstallments}} | data.overdueInstallments \|\| '' | utils/admissionVariables.ts:36 |
| {{financedAmount}} | data.financedAmount \|\| '' | utils/admissionVariables.ts:37 |
| {{installmentValue}} | data.installmentValue \|\| '' | utils/admissionVariables.ts:38 |
| {{dueDay}} | data.dueDay \|\| '' | utils/admissionVariables.ts:39 |
| {{paymentType}} | data.paymentType \|\| '' | utils/admissionVariables.ts:40 |
| {{indicationType}} | data.indicationType \|\| '' | utils/admissionVariables.ts:41 |
| {{originType}} | data.originType \|\| '' | utils/admissionVariables.ts:42 |
| {{status}} | data.status \|\| '' | utils/admissionVariables.ts:43 |
| {{vehicleBrand}} | data.vehicleBrand \|\| '' | utils/admissionVariables.ts:44 |
| {{vehicleModel}} | data.vehicleModel \|\| '' | utils/admissionVariables.ts:45 |
| {{vehicleColor}} | data.vehicleColor \|\| '' | utils/admissionVariables.ts:46 |
| {{vehicleYear}} | data.vehicleYear \|\| '' | utils/admissionVariables.ts:47 |
| {{vehiclePlate}} | data.vehiclePlate \|\| '' | utils/admissionVariables.ts:48 |
| {{vehicleChassis}} | data.vehicleChassis \|\| '' | utils/admissionVariables.ts:49 |
| {{vehicleRenavam}} | data.vehicleRenavam \|\| '' | utils/admissionVariables.ts:50 |
| {{firstInstallmentDueDate}} | data.firstInstallmentDueDate \|\| '' | utils/admissionVariables.ts:51 |
| {{parcela1}} | data.parcela1 \|\| '' | utils/admissionVariables.ts:52 |
| {{parcela2}} | data.parcela2 \|\| '' | utils/admissionVariables.ts:53 |
| {{taxaCobranca}} | data.taxaCobranca \|\| '' | utils/admissionVariables.ts:54 |
| {{otherInfo1}} | data.otherInfo1 \|\| '' | utils/admissionVariables.ts:55 |
| {{otherInfo2}} | data.otherInfo2 \|\| '' | utils/admissionVariables.ts:56 |
| {{unitName}} | unit?.nomeFantasia \|\| unit?.razaoSocial \|\| '' | utils/admissionVariables.ts:57 |
| {{unitCnpj}} | unit?.cnpj \|\| '' | utils/admissionVariables.ts:58 |
| {{unitEndereco}} | unit?.endereco \|\| '' | utils/admissionVariables.ts:59 |
| {{unitTelefone}} | unit?.telefone \|\| '' | utils/admissionVariables.ts:60 |
| {{unitCidade}} | unit?.cidade \|\| '' | utils/admissionVariables.ts:61 |
| {{unitEstado}} | unit?.estado \|\| '' | utils/admissionVariables.ts:62 |


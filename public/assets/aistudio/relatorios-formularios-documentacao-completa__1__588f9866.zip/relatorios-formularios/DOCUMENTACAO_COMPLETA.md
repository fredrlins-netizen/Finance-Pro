# Relatórios → Formulários
## Documentação funcional e técnica detalhada

Base: implementação local examinada nesta entrega. Não contém registros reais nem credenciais.

# 01 — Escopo, método e leitura do pacote
Esta documentação descreve a implementação local de Relatórios → Formulários no projeto Meu Gestor Inteligente. Não é uma proposta de sistema novo, nem uma declaração de que toda opção cadastrada está integralmente implementada em todos os módulos.

Foram examinados o componente FormsBuilder, o registro de contextos, tipos, hooks, componente compartilhado de seleção, endpoints Express, validação de entrada, migração da tabela, carregamento de configuração, utilitários de impressão e renderizadores de Admissão, Auditoria e Processos Jurídicos. Os inventários de variáveis, modelos embutidos e mapeamentos foram extraídos programaticamente da árvore sintática TypeScript, evitando transcrição incompleta. O manifesto lista os arquivos consultados com SHA-256.

**Limite de verificação:** a navegação pública mostra a tela de autenticação. Não houve login, retirada de autenticação, consulta a cadastros reais nem operação CRUD contra a base do aplicativo. A captura em evidencias/acesso-publico.jpg comprova apenas esse acesso público; não é uma captura de Formulários. A interface autenticada e seus modais não foram verificados visualmente. Os acionamentos descritos foram rastreados no código, não clicados em sessão real. Não se afirma paridade com a versão publicada.

**Verificação automatizada realizada:** node --test tests/formTemplatesPermissions.test.js — 3 testes passaram, sem falhas. Essa suíte usa um pool simulado e servidor HTTP temporário; comprova as verificações de permissões cobertas, mas não a integração com PostgreSQL real, impressão, persistência real ou renderização no navegador.

**Dados padrão versus dados cadastrados:** os valores iniciais do editor estão documentados integralmente. Os cinco modelos MOCK_FORMS são constantes embutidas não conectadas ao fluxo atual da lista; foram incluídos como referência, não como prova de registros existentes. Não foi exportado conteúdo real de clientes, usuários ou modelos salvos em banco. Valores dinâmicos são descritos por suas origens e expressões padrão, e não por dados pessoais.

Abra LEIA-ME.html ou DOCUMENTACAO_COMPLETA.html no navegador. As versões Markdown permitem pesquisa e edição. CSVs usam ponto e vírgula e UTF-8 com BOM, próprios para abertura em planilhas. JSONs contêm os catálogos estruturados. O ZIP é documental: não instala nem altera a aplicação.

# 02 — Navegação, arquitetura e estrutura das telas
O menu Relatórios contém o item Formulários, identificado por rel_formularios. DashboardLayout carrega FormsBuilder de forma preguiçosa. A troca de opção ocorre pelo shell do aplicativo: não foi encontrada uma URL pública autônoma específica para este editor. O endereço raiz informado pelo usuário leva ao shell ou ao login conforme a sessão.

Há dois modos internos: LIST e EDITOR. A inclusão e alteração são telas no conteúdo principal, não modais CRUD. Não existe modo DETAIL separado em FormsBuilder. A visualização da lista exige rel_formularios:VISUALIZAR; sem ela, aparece: Você não tem permissão para visualizar e gerenciar modelos de formulário.

**Lista:** contêiner flex de altura total; cabeçalho Gerenciador de Formulários; botão Novo Formulário condicionado à inclusão; tabela HTML em cartão branco com borda e rolagem horizontal. Largura mínima da tabela: 760px. Cabeçalhos em caixa alta; hover por linha. Não é um DataGrid de biblioteca com filtros/ordenação/CRUD automáticos: as operações foram programadas explicitamente.

**Editor:** barra superior com Voltar, título Editor, selo A4, Salvar, Cancelar, Imprimir e Importar DOCX; abaixo, Nome do Formulário e Descrição Curta; depois área do documento e painel lateral. As duas entradas ficam empilhadas em telas pequenas e lado a lado a partir de sm. A barra de ações quebra linha. Documento e painel ficam em coluna antes de lg e lado a lado a partir de lg.

**Documento:** folha branca com largura de 210mm e altura mínima 297mm; área cinza externa rolável; folha não é reduzida proporcionalmente para caber no celular. As seções são cabeçalho opcional, corpo e rodapé opcional. Cabeçalho ativo usa indicação azul; corpo, verde; rodapé, âmbar. A seção ativa determina onde clicar em uma variável insere seu token.

**Painel lateral:** abas Variáveis e Rotinas; botão Recolher painel; modo recolhido com Expandir painel, Var e Rot. Variáveis são agrupadas e expansíveis, com token aparecendo no hover. Rotinas são agrupadas por módulo e oferecem seleção múltipla por cartão/checkbox. O contador mostra N de 12 rotinas selecionadas. Badges Grid e Modal informam o contexto previsto, não escolhem individualmente o tipo de alvo.

**Usabilidade e limites:** há rótulos nas entradas, aria-label na tabela e editor rolável, botões nativos e indicação de foco por estilos. Não foi certificado suporte completo a leitor de tela, alto contraste, navegação apenas por teclado ou zoom. Os cartões de rotinas usam onClick em div, e não um acionador de cartão por teclado explicitamente implementado. Não há wizard, autosave, histórico de versões ou aviso de saída com alterações pendentes neste componente.

# 03 — Data grid e estados de leitura
| Coluna | Origem | Exibição | Acionamento / limite |
| --- | --- | --- | --- |
| Nome | form.name | Texto sem quebra; fonte de destaque | Não abre detalhe ao clicar no nome |
| Descrição | form.description | Texto truncado, largura máxima max-w-xs | Sem filtro ou expansão dedicados |
| Rotinas Vinculadas | FORM_CONTEXT_REGISTRY filtrado por menuIds | Badges verdes por rotina; G azul para grid e M roxo para modal | Nenhuma se não houver ID reconhecido; IDs antigos não ganham badge |
| Última Atualização | form.updatedAt | toLocaleDateString(pt-BR); — para ausência/inválida | Sem ordenação clicável |
| Ações | Permissões do usuário | Editar e Excluir somente se autorizados | Sem Imprimir, Duplicar, Baixar ou seleção múltipla na linha |


**Estados previstos:** Carregando formulários... ocupa as cinco colunas quando apiLoading e a lista ainda está vazia. Não foi possível carregar os formulários: {apiError} aparece em linha de alerta na falha. Nenhum formulário encontrado. aparece sem carregamento, sem erro e com zero registros. Os três estados não são equivalentes.

A lista inicia com config.formTemplates. O hook useEntityCRUD consulta /api/form-templates com pageSize 500. Quando termina sem erro, os resultados da API substituem o estado da lista. O hook possui cache compartilhado em memória com padrão de 30 segundos e deduplicação de requisições simultâneas. A atualização explícita após mutações invalida/recarrega os dados pelo hook.

O servidor entrega resultados ordenados por updated_at DESC. A API possui paginação e busca por nome/descrição, mas esta tela não conecta controles de busca, filtros, paginação, troca de tamanho, ordenação por cabeçalho, exportação do grid, agrupamento, seleção em lote, duplicação ou personalização de colunas. Assim, carregar 500 itens não equivale a navegar por todos os modelos além desse limite. A data mostra somente dia/mês/ano e segue o fuso local aplicado por Date/toLocaleDateString.

Os badges vêm apenas de menuIds reconhecidos pelo registro. Não há número do contrato, cliente, unidade ou usuário criador nas colunas. O ID técnico do modelo não é exibido.

# 04 — Todos os campos e conteúdos iniciais
| Banco | Estado / contrato cliente | Tipo | Conteúdo padrão | Função e regra |
| --- | --- | --- | --- | --- |
| id | id | UUID | Gerado por gen_random_uuid() | Somente leitura; chave primária; não exibido no grid |
| name | formName / name | VARCHAR(255), NOT NULL | Vazio no novo formulário | Nome do Formulário; obrigatório; validação de vazio no cliente e trim no servidor |
| description | formDesc / description | TEXT, anulável | Vazio | Descrição Curta; opcional; truncada no grid |
| content | bodyHtml / content | TEXT, anulável | <p>Comece a digitar...</p> | Corpo HTML; edição TinyMCE; getContent() ao salvar |
| header | headerHtml / header | TEXT, anulável | Vazio; painel oculto | HTML do cabeçalho; ocultar não limpa o conteúdo armazenado |
| footer | footerHtml / footer | TEXT, anulável | Vazio; painel oculto | HTML do rodapé; ocultar não limpa o conteúdo armazenado |
| menu_ids | formMenuIds / menuIds | JSONB | [] | Seleção múltipla; IDs de rotinas; sem FK declarada para os elementos JSON |
| docx_template | docxTemplateBase64 / docxTemplate | TEXT, anulável | undefined no cliente; NULL quando omitido na inclusão | Original DOCX em Base64; não regenerado pelas edições do HTML |
| created_at | Sem campo editável | TIMESTAMPTZ | NOW() na inclusão | Ignorado no PUT; não mostrado no grid |
| updated_at | updatedAt | TIMESTAMPTZ | NOW() na inclusão; ISO gerado pelo servidor no PUT | Exibido como data pt-BR, sem horário; — quando ausente ou inválido |


**Estado de um novo modelo:** currentFormId=null; formName=''; formDesc=''; headerHtml=''; footerHtml=''; bodyHtml='<p>Comece a digitar...</p>'; formMenuIds=[]; docxTemplateBase64=undefined; showHeader=false; showFooter=false; sidebarTab=VARIABLES. O componente inicialmente define activeSection=BODY, sidebarOpen=true, expandedCategories vazio, isSaving=false e isImporting=false. Ao abrir um novo modelo, nem activeSection, nem expandedCategories, nem sidebarOpen são explicitamente reinicializados; podem conservar o estado da visita anterior enquanto o componente continuar montado.

**Alteração:** carrega ID, nome, descrição, cabeçalho, corpo, rodapé, menuIds e DOCX do modelo escolhido. Cabeçalho/rodapé aparecem se o respectivo HTML tiver texto não vazio após trim. Há tentativa de ajustar os editores por refs após 100ms. A seção ativa não é explicitamente reiniciada por handleOpenEditor.

**Obrigatoriedade:** o cliente verifica apenas se formName é falsy. Espaços isolados podem passar nessa verificação local, mas o servidor sanitiza/trim e rejeita nome vazio na inclusão. Não há maxLength=255 declarado no Input desta tela; o banco limita name a VARCHAR(255). Corpo, descrição, cabeçalho, rodapé, vínculos e original DOCX não são obrigatórios no formulário.

**Validação do PUT:** validateBody([]) não exige nome em toda atualização. O servidor aceita atualização parcial das sete colunas autorizadas e não implementa uma validação semântica específica de menu_ids ou conteúdo DOCX nesta rota. NULL e tipos incompatíveis continuam sujeitos às restrições PostgreSQL.

**Valor dinâmico não é padrão fixo:** clicar em Nome / Razão Social insere {{cliente.nome}}, não uma pessoa fictícia nem o primeiro cliente da base. O preenchimento ocorre no renderizador do módulo consumidor. Onde não há mapeamento, o token não é substituído por esse renderizador.

# 05 — Matriz de acionamentos e CRUD completo
| Opção | Onde | Permissão / condição | O que acontece ao acionar | Efeito / limite |
| --- | --- | --- | --- | --- |
| Novo Formulário | Lista | INCLUIR | Abre EDITOR com nome/descrição vazios, corpo inicial, cabeçalho/rodapé ocultos, nenhum vínculo e sem DOCX | Sem gravação até Salvar |
| Editar | Linha do grid | ALTERAR | Carrega os campos do modelo; exibe cabeçalho/rodapé se HTML não vazio; abre EDITOR | Sem modal de edição; não existe editor somente leitura nesta tela |
| Excluir | Linha do grid | EXCLUIR | Abre confirmação nativa Excluir este formulário?; OK chama DELETE; Cancelar mantém registro | Exclusão física; sem lixeira neste fluxo |
| Voltar | Barra do editor | VISUALIZAR para acesso à tela | Retorna à lista sem salvar | Não há confirmação de alterações pendentes |
| Cancelar | Barra do editor | VISUALIZAR para acesso à tela | Retorna à lista sem salvar | Não chama API de escrita nem restaura editor por solicitação ao servidor |
| Salvar | Barra do editor | INCLUIR se novo; ALTERAR se existente | Valida nome; captura HTML; envia POST/PUT; atualiza lista, registra auditoria, recarrega e chama onRefresh | Loading em isSaving; sucesso retorna à lista; erro mantém editor |
| Ctrl+Enter / Cmd+Enter | Editor registrado no contexto global | Mesma de Salvar | Invoca callback de salvamento registrado | O contexto não implementa Escape; callback pode conservar estado capturado no registro, pois o efeito depende apenas de viewMode |
| Imprimir | Barra do editor | IMPRIMIR | Abre janela Blob HTML com conteúdo das refs; print ao carregar e close | Não faz merge de variáveis nem salva; PDF somente pelo diálogo do navegador, se disponível |
| Importar DOCX | Editor | INCLUIR ou ALTERAR conforme modo | Abre seletor nativo; valida extensão e tamanho; converte via Mammoth; guarda original Base64 e substitui corpo | Não grava automaticamente; imagens removidas da conversão |
| + Cabeçalho | Área A4 | Acesso ao editor | Exibe TinyMCE do cabeçalho e define HEADER como alvo | Não preenche empresa automaticamente |
| Ocultar cabeçalho | Cabeçalho | Acesso ao editor | Desmonta visualmente o editor de cabeçalho; alvo volta a BODY | Não limpa headerHtml; conteúdo pode continuar no payload |
| + Rodapé | Área A4 | Acesso ao editor | Exibe TinyMCE do rodapé e define FOOTER como alvo | Não calcula número de página |
| Ocultar rodapé | Rodapé | Acesso ao editor | Oculta editor de rodapé e ativa BODY | Não limpa footerHtml |
| Variáveis | Painel lateral | Acesso ao editor | Seleciona aba VARIABLES; mostra grupos e alvo de inserção | Não consulta banco ao clicar em uma variável |
| Rotinas | Painel lateral | Acesso ao editor | Seleciona aba MENUS; mostra agrupamento por módulo | Alterações só persistem ao salvar modelo |
| Categoria de variáveis | Aba Variáveis | Acesso ao editor | Expande/recolhe categoria por Set de categorias | Estado não persistido no banco |
| Variável | Categoria expandida | Grupo ativo | Foca editor da seção ativa e insere token {{prefixo.campo}} no cursor | Não insere valor de cliente; refs ausentes tornam chamada sem efeito |
| Rotina / checkbox | Aba Rotinas | Acesso ao editor | Clique no cartão adiciona/remove menuId; contador reflete IDs registrados | Grid e Modal são badges informativos, não caixas independentes |
| Recolher painel | Barra lateral | Acesso ao editor | Troca painel por faixa estreita w-10 | Documento continua editável |
| Expandir painel / Var / Rot | Painel recolhido | Acesso ao editor | Abre painel; Var e Rot também escolhem aba | Sem persistência |
| Enter | Nome / descrição | Acesso ao editor | Previne submit e move foco ao próximo campo elegível no contêiner | Não é comando de salvar; no último campo não há próximo |
| Focar seção | Cabeçalho / corpo / rodapé | Acesso ao editor | Muda activeSection e destaque; define destino das variáveis | Não modifica conteúdo |
| Posição da Imagem | Toolbar do corpo | Imagem selecionada | Abre menu específico com seis posições e quatro movimentos de 5px | Sem imagem selecionada mostra item desabilitado Selecione uma imagem primeiro |


**Inclusão:** acessar menu → Novo Formulário → preencher nome → editar as seções → escolher rotinas → Salvar → POST → receber modelo com UUID → inserir no estado local → logTransaction → refreshFormTemplates → onRefresh → mensagem de sucesso → LIST.

**Alteração:** Editar na linha → preencher estado existente → modificar → Salvar → PUT pelo ID → substituir item local → logTransaction com antes/depois → refresh → onRefresh → LIST. Não existe controle de revisão, ETag ou comparação de updated_at antes de gravar nesta rota.

**Exclusão:** Excluir → confirmação nativa → DELETE → logTransaction com snapshot anterior e null no depois → retirar do estado → refresh → onRefresh → Formulário removido. Não há restauração, soft delete, motivo obrigatório ou modal de dependências nesse fluxo.

**Leitura:** a tela usa a listagem. Existe GET por ID no backend, mas o botão Editar usa o objeto já carregado; não dispara esse GET individual.

**Cancelamento:** Voltar e Cancelar retornam a LIST sem salvar, sem alerta de perda e sem escrita compensatória. Ocultar cabeçalho/rodapé não é excluir seu HTML. Não existe botão específico de apagar original DOCX do modelo.

**Auditoria:** o componente chama useAudit.logTransaction com tipo FORMULARIO ao salvar/excluir. O arquivo de auditoria do servidor reconhece form_templates como FORMULARIO. Esta rota especializada não chama createAuditHooks ou logAudit diretamente; não se deve inferir que chamar a API sem passar pela interface gere o mesmo evento da chamada logTransaction do cliente. A conclusão se limita ao caminho aqui rastreado.

# 06 — Editor rico, barras e comandos
O editor é TinyMCE 8.3.2 instalado no projeto, com licença configurada gpl. Usa skin local /tinymce-skins/ui/oxide e CSS /tinymce-skins/content/default/content.min.css. A configuração comum desativa menubar, resize, promotion e branding. Não define language nem language_url: rótulos dos plugins podem aparecer em inglês, embora os controles próprios do aplicativo sejam em português.

**Corpo — plugins:** lists, table, image, link, code, pagebreak. Toolbar na ordem efetiva:

undo redo | blocks fontfamily fontsize | bold italic underline strikethrough | forecolor backcolor | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | table image imageposition link | pagebreak | code

**Funções por comando:** undo desfaz e redo refaz dentro do editor; blocks muda parágrafo/título/bloco; fontfamily muda fonte; fontsize muda tamanho; bold/italic/underline/strikethrough aplicam negrito/itálico/sublinhado/tachado; forecolor e backcolor definem cor de texto e fundo; alignleft/aligncenter/alignright/alignjustify alinham; bullist/numlist criam listas; outdent/indent diminuem/aumentam recuo; table insere e altera tabelas; image abre propriedades de imagem; imageposition abre o menu próprio de posicionamento; link abre editor de link; pagebreak insere marcador de quebra; code abre código-fonte HTML.

**Cabeçalho e rodapé — plugins:** lists, image, link. Toolbar: bold italic underline | forecolor backcolor | alignleft aligncenter alignright | fontsize | image. Não há botões table, code, pagebreak, listas, link ou imageposition nessa toolbar, apesar de lists/link estarem carregados. Não presumir equivalência de barras entre as três seções.

**Aparência do corpo:** Times New Roman, 16px, line-height 1.5, padding 10mm 20mm, min_height=600, statusbar=true, object_resizing=true. Existe autoresize_bottom_margin=50, mas o plugin autoresize não foi importado/configurado; não é prova de redimensionamento automático habilitado.

**Cabeçalho:** altura 120px; Times New Roman 14px, line-height 1.4, padding 8px 20mm, statusbar false. **Rodapé:** altura 100px; Times New Roman 12px e demais características equivalentes ao cabeçalho.

**Imagem redimensionada no corpo:** evento ObjectResized grava width e height em px no style do IMG. Todas as seções limitam max-width a 100%. As posições usam classes img-behind-text, img-front-text, img-float-left, img-float-right e img-center.

**Menu Posição da Imagem:** Normal (inline) limpa className, position, float, zIndex, margin e display; Atrás do Texto usa posição absoluta, z-index -1, opacity .9; Na Frente do Texto usa relative e z-index 10; Flutuando à Esquerda usa float left e margem 4px 12px 4px 0; Flutuando à Direita usa float right e margem 4px 0 4px 12px; Centralizado usa display block e margin 8px auto. Mover para Cima/Baixo altera marginTop em -5/+5px; Esquerda/Direita altera marginLeft em -5/+5px. Os estilos não constituem um editor de coordenadas X/Y persistido em campos separados.

**Tabelas:** o plugin permite inserir tabela pela grade/menu, abrir propriedades da tabela, linha e célula; inserir/excluir linhas e colunas, mesclar/dividir células, cortar/copiar/colar linhas ou colunas e alterar cabeçalhos conforme contexto. Inventário literal das opções do plugin instalado consta em inventarios/opcoes-plugins.json e anexos/COMANDOS_PLUGINS.md. A existência de uma opção no plugin não significa que ela seja visível em todo contexto ou toolbar.

**Não configurados neste editor:** upload remoto de imagens com endpoint próprio, imagens de catálogo, mala direta universal no gerenciador, assinatura eletrônica, envio WhatsApp/e-mail, serviço externo de conversão DOCX/PDF, cálculo automático de número de página, revisão colaborativa e assinatura digital.

# 07 — Modais, diálogos e janelas
| Diálogo | Campos / conteúdo | Padrão | Confirmação e efeito |
| --- | --- | --- | --- |
| Exclusão de modelo | Mensagem Excluir este formulário?; botões nativos OK e Cancelar | Modelo da linha clicada | OK executa DELETE; Cancelar não executa escrita |
| Seletor de arquivo DOCX | Arquivo local; accept .doc,.docx | Nenhum arquivo selecionado; reset após operação | Cancelamento não faz nada; seleção chama handleImportDocx |
| Alerta de .doc | O formato .doc (Word 97-2003) não é suportado; instrução para salvar como .docx no Word | Mensagem fixa | OK fecha alerta e limpa seletor |
| Alerta de extensão | Por favor, selecione um arquivo .docx válido. | Mensagem fixa | OK fecha; não altera documento |
| Alerta de tamanho | O arquivo .docx excede o limite de 10 MB. | 10 × 1024 × 1024 bytes | OK fecha; não importa |
| Alerta de falha de importação | Erro ao importar o arquivo. Verifique se é um arquivo .docx válido e tente novamente. | Mensagem fixa | Fecha alerta; finally remove estado de importação e limpa input |
| TinyMCE — Insert/Edit Image | General: Source, Alternative description, Image title, dimensões largura/altura, Class, Show caption. Advanced: Vertical space, Horizontal space, Border width, Border style | Imagem selecionada preenche valores existentes; nova imagem começa sem URL, título e descrição; sem classe específica | Save insere/altera IMG no editor da seção; Cancel não confirma |
| TinyMCE — Insert/Edit Link | URL, Text to display quando aplicável, Title, Open link in (alvo); catálogos/rel/classes condicionais à configuração | URL/texto da seleção quando houver; protocolo padrão https; alvo padrão não customizado | Save cria/atualiza link; Cancel fecha sem confirmar; listas adicionais não foram configuradas pelo app |
| TinyMCE — Table Properties | Cols/Rows quando inclusão via diálogo; Width, Height, Cell spacing, Cell padding, Border width, Show caption, Alignment; aba Advanced com estilos e cores conforme plugin | Derivado da seleção e defaults do TinyMCE; não há formulário de negócio próprio | Save aplica tabela/propriedades; Cancel fecha; opções por contexto |
| TinyMCE — Row Properties | Row type, Alignment, Height; estilos de borda/fundo na aba Advanced conforme plugin | Valores das linhas selecionadas; sem catálogo de classes configurado | Aplica às linhas selecionadas; não cria registro em form_templates por si só |
| TinyMCE — Cell Properties | Width, Height, Cell type, Scope, Horizontal align, Vertical align, Border width; Advanced: Border style, Border color, Background color | Valores atuais das células; sem catálogo de classes configurado | Aplica à seleção; só persiste ao salvar modelo |
| TinyMCE — Source Code | Área de texto com HTML do corpo | getContent do corpo | Save substitui HTML no editor; Cancel não aplica; apenas no corpo pela toolbar configurada |
| Impressão do gerenciador | Janela HTML e diálogo nativo de impressão; impressora, páginas, cópias, layout etc. dependem do navegador/OS | Título do modelo ou Formulário; corpo Times New Roman 16px | Ao load, chama print e depois close; destino PDF depende de opção do navegador |
| Admissão — Exportar para Word | Templates Salvos com nome; botão de enviar template .docx; fechar X; estado Gerando documento... | Lista de config.formTemplates que possuem docxTemplate | Escolher modelo gera Word imediatamente; não há tela de revisão intermediária do DOCX |
| Processos — seleção de formulário na aba Notas | Select Formulário de Impressão; opções pelo nome; Imprimir e Limpar quando previewHtml existe | Selecione um formulário... e selectedTemplateId vazio | Selecionar monta preview; Imprimir abre janela; Limpar zera preview e seleção |


Os formulários Novo/Editar não são modais. Não há modal de visualização de modelo no gerenciador, modal de permissões por modelo, modal de confirmar salvamento nem modal de associação de rotinas separado: rotinas ficam no painel lateral.

**Imagem e upload:** image_advtab, image_caption, image_title e image_description estão habilitados no app. image_dimensions é true por padrão do plugin. A aba Upload só aparece se as condições internas do TinyMCE detectarem suporte de upload; o app não fornece images_upload_url nem images_upload_handler neste componente. Portanto, não se afirma existir upload remoto funcional por essa aba. Imagens importadas via Mammoth são removidas. Descrição alternativa e título devem ser preenchidos manualmente quando desejados.

**Defaults dos modais:** não existem valores de negócio universais para largura/altura/cor de tabela ou imagem. O plugin deriva initialData da seleção, atributos e estilos, e dos seus defaults internos. Os anexos incluem as declarações de opções/defaults e os rótulos literais da versão instalada para distinguir comportamento de biblioteca de configuração do aplicativo.

# 08 — Importação DOCX em detalhes
1. O botão abre input hidden com accept .doc,.docx. A seleção usa apenas files[0].
2. O nome é comparado em minúsculas. .doc é recusado com orientação de conversão; demais extensões diferentes de .docx também são recusadas.
3. O limite local é 10 MiB (10.485.760 bytes), embora a mensagem diga 10 MB. Valor acima é recusado antes de ler o conteúdo.
4. isImporting=true. O arquivo é lido como ArrayBuffer; bytes são convertidos em string binária para btoa. O original é guardado em docxTemplateBase64.
5. Mammoth é importado dinamicamente no navegador. Title e Heading 1 viram h1; Heading 2 e Subtitle viram h2; Heading 3 vira h3; b/i/u/strike recebem regras para b/i/u/s.
6. A conversão de imagens devolve src vazio; tags IMG com src vazio são removidas. A mensagem informa para inserir imagens manualmente pelo editor. Não se trata de preservação fiel do DOCX.
7. O HTML é reprocessado por DOMParser: tabelas width 100%, border-collapse collapse, Arial 11px, margin-bottom 12px, cellpadding/cellspacing 0; td/th padding 6px, borda 1px solid #ccc, vertical-align top; th negrito, fundo #f0f0f0, alinhamento esquerdo; img max-width 100%, height auto, display block, margin 4px 0; p recebe margin-bottom 4px e line-height 1.4 se ausentes; títulos recebem margin-top 12px, margin-bottom 6px e bold.
8. O corpo é substituído por setContent(styledHtml) se a ref estiver disponível; o alvo passa a BODY. Cabeçalho e rodapé do Word não são extraídos para campos correspondentes do editor por esse fluxo.
9. Se Nome do Formulário estava vazio, recebe o nome do arquivo sem extensão .docx. Se já preenchido, é preservado. Descrição e rotinas não são inferidas do arquivo.
10. Avisos Mammoth são enviados ao console; sucesso produz Importado / Documento .docx importado com sucesso! Insira imagens manualmente pelo editor.
11. Em erro, console + alerta de arquivo inválido. finally restaura isImporting=false e limpa o seletor, permitindo escolher novamente o mesmo arquivo.
12. Apenas Salvar envia corpo convertido e original ao backend. O endpoint aceita JSON até 20mb por configuração específica; Base64 aumenta o tamanho comparado ao binário. O limite de 10 MiB é do fluxo de importação local, não uma validação de conteúdo DOCX implementada na rota.

**Separação crítica:** HTML editado e DOCX original são representações independentes. Alterar texto no editor não reescreve o original Base64. A exportação Word da Admissão usa o original, enquanto a prévia HTML usa content/header/footer. Também há dois dialetos de variáveis: HTML {{cliente.nome}} e Word {{clientName}}, com mapeamentos diferentes. Não são intercambiáveis automaticamente.

# 09 — Rotinas, relacionamentos e acionamento efetivo
| Módulo | Rotina / menuId | Alvos declarados | Entidade | Prefixos declarados | Estado observado |
| --- | --- | --- | --- | --- | --- |
| Comercial | Admissão / com_admissao | modal, grid | admission | cliente, admissao, banco, colaborador, empresa, modalidade, recalculo, serie, geral | Consumidor específico encontrado; ler diferenças abaixo |
| Comercial | Negociação Comercial / com_negociacao | modal, grid | negotiation | cliente, colaborador, empresa, geral | Vínculo configurável no registro; consumidor de geração não localizado na busca de uso |
| Cadastros | Clientes / cad_clientes | modal, grid | client | cliente, empresa, geral | Vínculo configurável no registro; consumidor de geração não localizado na busca de uso |
| Cadastros | Colaboradores / cad_colaboradores | modal | collaborator | colaborador, empresa, geral | Vínculo configurável no registro; consumidor de geração não localizado na busca de uso |
| Atendimento | Jurídico / juridico | modal, grid | legal | cliente, colaborador, empresa, geral | Vínculo configurável no registro; consumidor de geração não localizado na busca de uso |
| Financeiro | Contas a Receber / fin_receber | grid | financial_receivable | cliente, empresa, portador, tipo_documento, geral | Vínculo configurável no registro; consumidor de geração não localizado na busca de uso |
| Financeiro | Contas a Pagar / fin_pagar | grid | financial_payable | empresa, portador, tipo_documento, geral | Vínculo configurável no registro; consumidor de geração não localizado na busca de uso |
| Financeiro | Negociação Financeira / fin_negociacao | modal, grid | financial_negotiation | cliente, empresa, geral | Vínculo configurável no registro; consumidor de geração não localizado na busca de uso |
| Financeiro | Cobrança - Coordenadores / fin_cob_coordenador | grid | collection | cliente, colaborador, admissao, empresa, geral | Vínculo configurável no registro; consumidor de geração não localizado na busca de uso |
| Financeiro | Cobrança - Operacional / fin_cob_operacional | grid | collection | cliente, colaborador, admissao, empresa, geral | Vínculo configurável no registro; consumidor de geração não localizado na busca de uso |
| Atendimento | Auditoria / auditoria | modal, grid | audit | cliente, admissao, banco, colaborador, empresa, geral | Consumidor específico encontrado; ler diferenças abaixo |
| Acompanhamento Jurídico | Acomp. Jurídico - Processos / jur_processos | grid, modal | company_legal_process | cliente, empresa, colaborador, processo, geral | Consumidor específico encontrado; ler diferenças abaixo |


**Registro não é implementação automática:** FORM_CONTEXT_REGISTRY oferece os cartões, rótulos, alvos e prefixos. useFormTemplates encontra o contexto, valida targetType quando informado e filtra modelos por menuIds.includes(menuId). Isso não injeta um botão automaticamente nas telas nem implementa preenchimento das entidades. A busca por useFormTemplates, FormTemplateButton, docxTemplate, onRenderTemplate e renderizadores identificou consumidores em Admissão, Auditoria e Processos Jurídicos. Para as outras nove rotinas, o registro por si só não comprova geração disponível.

**Botão compartilhado:** exige permissão rel_formularios:IMPRIMIR OU {menuId}:IMPRIMIR, contexto conhecido e pelo menos um modelo. Zero modelos/permissão ausente: não renderiza. Um modelo: clicar chama onRenderTemplate diretamente. Vários: dropdown com nome, descrição curta se houver e título do contexto; selecionar fecha e chama callback; clique fora fecha. O componente não implementa consulta por cliente, seleção de registro, merge ou impressão: isso é responsabilidade do callback da tela.

**Admissão — HTML:** modelos vêm de useFormTemplates('com_admissao', config.formTemplates || []). A prévia seleciona modelo por ID, aplica replaceTemplateVariables separadamente em cabeçalho/corpo/rodapé e usa dados da admissão em edição. A seleção vazia mostra Selecione um formulário.... A tela de impressão tem VOLTAR e IMPRIMIR. Os vínculos por ID localizam banco, colaborador, série, modalidade e unidade; clientObj é o cliente carregado na tela. A unidade usa fallback config.companyInfo. O recálculo usa somente o primeiro cenário.

**Admissão — efeito de imprimir:** a ação exige perfis carregados, cliente presente e titular presente quando exigido. Recalcula cenários por serviços do banco; se status era PENDENTE, muda estado local para NEGOCIAÇÃO e, para registro com ID, tenta PATCH /api/admissions/:id/status e auditoria. A exceção desse PATCH é capturada sem mensagem nesse trecho. Depois chama window.print(). Portanto essa impressão de Admissão não deve ser tratada como operação puramente visual; pode alterar status. Não foi acionada nesta documentação.

**Admissão — Word:** formsWithDocx filtra todos os modelos recebidos na configuração por presença de docxTemplate, sem filtrar menuId de admissão nesse filtro específico. O modal exibe Templates Salvos e envio direto de arquivo. A geração usa PizZip + Docxtemplater, paragraphLoop=true, linebreaks=true e delimitadores {{ }}. Chama getAdmissionVariables; gera Blob DOCX e saveAs com nome cliente_contrato.docx, usando admissao/sem-contrato quando os valores faltam. Fecha modal no sucesso; falha avisa que o template deve usar variáveis como {{clientName}}. A alteração de HTML do gerenciador não modifica esse arquivo original.

**Auditoria:** usa useFormTemplates('auditoria', ...). No workflow de uma admissão, encontra responsável e titular pelos IDs vinculados. Substitui valores com renderizador próprio; usa primeiro cenário; separa corpo pelos marcadores de quebra TinyMCE em páginas A4, com cabeçalho e rodapé repetidos no desenho das páginas. Conteúdo inserido na prévia é passado por sanitizeHtml. Há mais variáveis de data e titular implementadas aqui do que no renderizador da Admissão. Os prefixos no registro não revelam sozinhos essa diferença.

**Processos Jurídicos — grid:** FormTemplateButton de targetType grid chama handleRenderTemplate. Concatena cabeçalho/corpo/rodapé; se a página tem processos, usa paginatedProcesses[0] para substituição. Isso significa primeiro registro da página atual, não todos os resultados e não seleção em lote. Sem registro, não ocorre substituição nesse trecho. Gera HTML sanitizado, janela e impressão.

**Processos Jurídicos — detalhes:** FormTemplateButton de targetType modal usa o processo em detalhe. Concatena seções, substitui pelo mapa específico e imprime HTML sanitizado. Usa unidade do processo ou companyInfo e parceiro relacionado ou parte adversa para alguns campos.

**Processos Jurídicos — formulário / aba Notas:** usa useFormTemplates('jur_processos', ..., 'modal'). Select Formulário de Impressão monta previewHtml a partir de formData e selectedPartner; encontra advogado comparando nome do colaborador com responsibleLawyer nesse trecho. O botão Limpar retira prévia e seleção. Imprimir abre janela com o preview. O mapeamento aqui é maior que o do grid/detalhes e inclui papel, distribuição, documento adverso, advogado adverso e OAB.

**Relacionamentos:** form_templates.id identifica o modelo; menu_ids contém relacionamentos lógicos com rotinas, não registros de clientes ou admissões. Os dados de uma emissão vêm do contexto consumidor: admission.clientId → clientes; titularClientId → cliente titular; bankId → bancos; collaboratorId → colaboradores; modalityId → modalidades; seriesId → séries; unitId → unidades. Processos usam partnerId → clientes e unitId → unidades; o vínculo do advogado neste renderizador ainda usa busca pelo nome. A escolha do modelo não cria nem altera esses relacionamentos.

**Escopo por unidade:** a rota form-templates não tem coluna unit_id nem filtro de unidade no SQL mostrado. Não confundir modelo global disponível por permissões com dados de emissão, que vêm do registro e sua unidade. Não foi realizada auditoria integral de RLS ou de políticas externas ao trecho de armazenamento do modelo.

# 10 — Catálogo integral de variáveis e valores padrão
O editor pode disponibilizar 18 categorias e 171 tokens quando todas as propriedades condicionais da configuração estão presentes. Array vazio é truthy e não esconde a categoria; propriedade ausente pode escondê-la. Processo Jurídico e Geral (Sistema) são sempre adicionados. Titular replica todos os campos de Cliente com prefixo titular.

**Inserção:** o conteúdo padrão inserido de cada item é o token literal indicado no catálogo, sem consultar valor real. **Preenchimento:** ver os CSV/JSON/Markdown de mapeamentos; cada linha informa a expressão de origem e seus fallbacks, incluindo string vazia, cálculo, Sim/Não, data atual ou RESPONSÁVEL.

**Filtro por rotina:** com nenhum vínculo ou nenhum contexto reconhecido, activeVariablePrefixes=null e os grupos ficam ativos. Com vínculos reconhecidos, há união dos prefixos. Porém o teste implementado também considera ativo todo grupo se essa união contiver geral. Todas as 12 entradas atuais contêm geral; portanto a seleção de uma dessas rotinas não restringe efetivamente as categorias pelo prefixo. A mensagem sobre filtragem não deve ser tomada como garantia de compatibilidade de preenchimento.

**Ausência de mapeamento:** os renderizadores fazem replace literal dos tokens conhecidos, usando split/join. O token desconhecido não recebe fallback universal nem erro automático; pode permanecer visível no documento. O catálogo estruturado identifica SEM MAPEAMENTO NESTE RENDERIZADOR por consumidor. O gerenciador Imprimir não chama esses renderizadores e mantém variáveis sem merge.

### Cliente (Responsável)

Condição: config.clients presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{cliente.id}} |
| Nome / Razão Social | {{cliente.nome}} |
| Tipo (Física/Jurídica) | {{cliente.tipo}} |
| CPF / CNPJ | {{cliente.documento}} |
| RG | {{cliente.rg}} |
| E-mail | {{cliente.email}} |
| Telefone Principal | {{cliente.telefone}} |
| Telefone Secundário | {{cliente.telefone2}} |
| Profissão | {{cliente.profissao}} |
| Estado Civil | {{cliente.estado_civil}} |
| Data de Nascimento | {{cliente.data_nascimento}} |
| CEP | {{cliente.cep}} |
| Endereço (Rua) | {{cliente.endereco}} |
| Número | {{cliente.numero}} |
| Complemento | {{cliente.complemento}} |
| Bairro | {{cliente.bairro}} |
| Cidade | {{cliente.cidade}} |
| Estado (UF) | {{cliente.uf}} |
| Anotações | {{cliente.anotacoes}} |

### Titular (quando aplicável)

Condição: config.clients presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{titular.id}} |
| Nome / Razão Social | {{titular.nome}} |
| Tipo (Física/Jurídica) | {{titular.tipo}} |
| CPF / CNPJ | {{titular.documento}} |
| RG | {{titular.rg}} |
| E-mail | {{titular.email}} |
| Telefone Principal | {{titular.telefone}} |
| Telefone Secundário | {{titular.telefone2}} |
| Profissão | {{titular.profissao}} |
| Estado Civil | {{titular.estado_civil}} |
| Data de Nascimento | {{titular.data_nascimento}} |
| CEP | {{titular.cep}} |
| Endereço (Rua) | {{titular.endereco}} |
| Número | {{titular.numero}} |
| Complemento | {{titular.complemento}} |
| Bairro | {{titular.bairro}} |
| Cidade | {{titular.cidade}} |
| Estado (UF) | {{titular.uf}} |
| Anotações | {{titular.anotacoes}} |

### Colaborador

Condição: config.collaborators presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{colaborador.id}} |
| Nome Completo | {{colaborador.nome}} |
| Cargo / Função | {{colaborador.cargo}} |
| E-mail | {{colaborador.email}} |
| Telefone | {{colaborador.telefone}} |
| É Whatsapp? | {{colaborador.whatsapp}} |
| Estado Civil | {{colaborador.estado_civil}} |
| Data de Nascimento | {{colaborador.data_nascimento}} |
| CEP | {{colaborador.cep}} |
| Endereço | {{colaborador.endereco}} |
| Número | {{colaborador.numero}} |
| Complemento | {{colaborador.complemento}} |
| Bairro | {{colaborador.bairro}} |
| Cidade | {{colaborador.cidade}} |
| Estado (UF) | {{colaborador.uf}} |
| Anotações | {{colaborador.anotacoes}} |

### Banco

Condição: config.banks presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{banco.id}} |
| Nome do Banco | {{banco.nome}} |
| Cód. Febraban | {{banco.febraban}} |
| Status | {{banco.status}} |
| Anotações | {{banco.anotacoes}} |

### Empresa / Unidade

Condição: config.units presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Razão Social | {{empresa.razao_social}} |
| CNPJ | {{empresa.cnpj}} |
| Telefone Geral | {{empresa.telefone}} |
| E-mail Geral | {{empresa.email}} |
| CEP | {{empresa.cep}} |
| Endereço | {{empresa.endereco}} |
| Número | {{empresa.numero}} |
| Complemento | {{empresa.complemento}} |
| Bairro | {{empresa.bairro}} |
| Cidade | {{empresa.cidade}} |
| Estado (UF) | {{empresa.uf}} |
| Taxa Mínima | {{empresa.taxa_minima}} |

### Admissão

Condição: config.admissions presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{admissao.id}} |
| Data | {{admissao.data}} |
| Nome do Cliente | {{admissao.cliente}} |
| Nº do Contrato | {{admissao.contrato}} |
| Total de Parcelas | {{admissao.total_parcelas}} |
| Parcelas Pagas | {{admissao.parcelas_pagas}} |
| Parcelas em Atraso | {{admissao.parcelas_atraso}} |
| Parcelas a Pagar | {{admissao.parcelas_a_pagar}} |
| Valor Financiado | {{admissao.valor_financiado}} |
| Valor da Parcela | {{admissao.valor_parcela}} |
| Dia de Vencimento | {{admissao.dia_vencimento}} |
| Forma de Pagamento | {{admissao.forma_pagamento}} |
| Tipo de Indicação | {{admissao.tipo_indicacao}} |
| Tipo de Origem | {{admissao.tipo_origem}} |
| Status | {{admissao.status}} |
| Taxa Administrativa | {{admissao.taxa_administrativa}} |
| 1ª Parcela | {{admissao.parcela1}} |
| Valor Boletos | {{admissao.parcela2}} |
| Info Adicional 1 | {{admissao.info1}} |
| Info Adicional 2 | {{admissao.info2}} |
| Marca do Veículo | {{admissao.marca_veiculo}} |
| Modelo do Veículo | {{admissao.modelo_veiculo}} |
| Cor do Veículo | {{admissao.cor_veiculo}} |
| Ano do Veículo | {{admissao.ano_veiculo}} |
| Placa do Veículo | {{admissao.placa}} |
| Chassi do Veículo | {{admissao.chassi}} |
| Renavam do Veículo | {{admissao.renavam}} |
| 1ª Parcela Vencimento | {{admissao.primeiro_vencimento}} |

### Recálculo (Cenário)

Condição: config.admissions presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Parcelas a Pagar | {{recalculo.parcelas_a_pagar}} |
| Dívida Original | {{recalculo.divida_original}} |
| Parcela Recálculo | {{recalculo.parcela}} |
| Dívida Recálculo | {{recalculo.divida}} |
| Economia | {{recalculo.economia}} |
| Dia de Vencimento | {{recalculo.dia_vencimento}} |

### Modalidade

Condição: config.modalities presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{modalidade.id}} |
| Tipo | {{modalidade.tipo}} |
| Descrição | {{modalidade.descricao}} |

### Produto

Condição: config.products presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{produto.id}} |
| Tipo | {{produto.tipo}} |
| Descrição | {{produto.descricao}} |
| Unidade | {{produto.unidade}} |

### Serviço

Condição: config.services presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{servico.id}} |
| Nome | {{servico.nome}} |
| Duração (min) | {{servico.duracao}} |
| Preço | {{servico.preco}} |

### Conta Bancária

Condição: config.bankAccounts presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{conta_bancaria.id}} |
| Descrição | {{conta_bancaria.descricao}} |
| Tipo de Conta | {{conta_bancaria.tipo}} |
| Nome do Banco | {{conta_bancaria.banco}} |
| Agência | {{conta_bancaria.agencia}} |
| Nº da Conta | {{conta_bancaria.numero_conta}} |
| Saldo Inicial | {{conta_bancaria.saldo_inicial}} |
| Saldo Atual | {{conta_bancaria.saldo_atual}} |
| Status | {{conta_bancaria.status}} |

### Tipo de Documento

Condição: config.documentTypes presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{tipo_documento.id}} |
| Descrição | {{tipo_documento.descricao}} |
| Categoria | {{tipo_documento.categoria}} |
| É Fiscal? | {{tipo_documento.fiscal}} |
| Status | {{tipo_documento.status}} |

### Portador

Condição: config.bearers presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{portador.id}} |
| Código | {{portador.codigo}} |
| Nome | {{portador.nome}} |
| Tipo | {{portador.tipo}} |
| Status | {{portador.status}} |

### Plano de Contas

Condição: config.chartOfAccounts presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{plano_contas.id}} |
| Código | {{plano_contas.codigo}} |
| Nome | {{plano_contas.nome}} |
| Tipo | {{plano_contas.tipo}} |
| É Analítica? | {{plano_contas.analitica}} |

### Departamento

Condição: config.departments presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{departamento.id}} |
| Código | {{departamento.codigo}} |
| Nome | {{departamento.nome}} |
| Gerente | {{departamento.gerente}} |
| Status | {{departamento.status}} |

### Série

Condição: config.series presente/truthy.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Código (ID) | {{serie.id}} |
| Sigla | {{serie.sigla}} |
| Descrição | {{serie.descricao}} |

### Processo Jurídico

Condição: sempre.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Número do Processo | {{processo.numero}} |
| Vara | {{processo.vara}} |
| Comarca / Jurisdição | {{processo.comarca}} |
| Tipo | {{processo.tipo}} |
| Papel (Autor/Réu) | {{processo.papel}} |
| Status | {{processo.status}} |
| Assunto | {{processo.assunto}} |
| Valor da Causa | {{processo.valor_causa}} |
| Valor Provisionado | {{processo.valor_provisionado}} |
| Nível de Risco | {{processo.risco}} |
| Data de Distribuição | {{processo.data_distribuicao}} |
| Parte Adversa | {{processo.parte_adversa}} |
| Documento da Parte Adversa | {{processo.documento_adversa}} |
| Advogado Adverso | {{processo.advogado_adverso}} |
| OAB do Adverso | {{processo.oab_adverso}} |
| Advogado Responsável | {{processo.advogado_responsavel}} |

### Geral (Sistema)

Condição: sempre.

| Rótulo exibido | Token / conteúdo ao inserir |
| --- | --- |
| Data Atual (DD/MM/AAAA) | {{data.hoje}} |
| Data por Extenso | {{data.extenso}} |
| Dia da Semana | {{data.dia_semana}} |
| Mês Atual | {{data.mes}} |
| Ano Atual | {{data.ano}} |
| Hora Atual | {{hora.atual}} |
| Usuário Logado | {{usuario.nome}} |


Os mapeamentos completos incluem ainda aliases usados pelos consumidores, mesmo quando não listados na barra lateral: por exemplo cliente.whatsapp, admissao.tipo_cliente, nomes alternativos de veículo e campos de cobrança. O catálogo Word separado cobre o objeto plano de exportação.

# 11 — Permissões, API, armazenamento e integrações técnicas
| Método | Caminho | Permissão específica | Entrada | Resultado |
| --- | --- | --- | --- | --- |
| GET | /api/form-templates | VISUALIZAR | page=1; limit até 500; search opcional em name/description com ILIKE | 200 {data,total,page,limit,totalPages}; updated_at DESC |
| GET | /api/form-templates/:id | VISUALIZAR | UUID válido | 200 {data}; 404 Formulário não encontrado |
| POST | /api/form-templates | INCLUIR | name obrigatório; sete colunas permitidas; id descartado | 201 {data}; UUID e timestamps gerados pelo banco |
| PUT | /api/form-templates/:id | ALTERAR | UUID; atualização parcial das colunas permitidas; id e created_at descartados | 200 {data}; updated_at renovado; 404 se ausente |
| DELETE | /api/form-templates/:id | EXCLUIR | UUID válido | 200 {success:true,message:Formulário excluído com sucesso}; 404 se ausente |


Todas essas rotas são montadas com extractUser e requireAuth. requireFormPermission exige usuário identificado; administrador passa diretamente; usuário comum precisa de pelo menos um grupo e de uma linha em user_group_permissions com group_id no conjunto dos seus grupos e permission exatamente rel_formularios:{AÇÃO}. Uma concessão em qualquer grupo basta para a ação. Sem grupos/concessão retorna 403. Sem usuário, 401. Erro na consulta de permissão retorna 500.

**Campos permitidos em escrita:** name, description, content, header, footer, menu_ids, docx_template. Campos extras não entram no SQL. POST descarta id; PUT descarta id e created_at e impõe updated_at novo. As consultas usam parâmetros para os valores e whitelist para nomes de colunas.

**Validação:** ID inválido retorna 400 com ID inválido / O ID deve ser um UUID válido. Corpo ausente/não objeto retorna 400. Inclusão sem name não vazio retorna 400 Campos obrigatórios ausentes com detalhes. sanitizeString remove blocos script, aplica remoção simples de atributos de evento e trim; sanitizeObject trata strings e strings de arrays no primeiro nível. Não equivale a validação estrutural completa de HTML, DOCX ou JSONB.

**Busca:** usa search sanitizado, ILIKE em name OR description; padrão %termo%. Listagem retorna COUNT separado e SELECT * ordenado por updated_at DESC. validateQueryParams conhece sort/order, mas essa rota não usa esses parâmetros para mudar sua ordem. page padrão 1, limit padrão 50 com teto 500; o hook da tela pede 500. Não foi identificado clamp inferior explícito na expressão desses parâmetros.

**Erros de operação:** em falhas de banco, respostas 500 com error português e details de err.message. A interface usa toast para salvar/excluir; nem toda falha vira modal. Não foi feita provocação de erro com dados reais.

**Persistência:** PostgreSQL, tabela form_templates. Chave primária UUID; name obrigatório; menu_ids JSONB padrão []; campos de conteúdo TEXT; índices por name e updated_at DESC. A migração inspecionada não declara FK em menu_ids, unit_id, owner_id ou tabela de versões. A remoção executa DELETE físico.

**Carga da configuração:** consulta os modelos e os mapeia para camelCase em config.formTemplates. Administrador ou usuário com rel_formularios:VISUALIZAR recebe os modelos nesse filtro. Outros usuários podem receber modelos se tiverem uma das ações listadas (VISUALIZAR, INCLUIR, ALTERAR, EXCLUIR, CANCELAR, INATIVAR, IMPRIMIR) em algum menu vinculado. Isso permite consumo contextual sem acesso ao gerenciador, mas não dispensa a permissão verificada pelo botão consumidor. Falha na consulta de modelos pode resultar em lista vazia nesse carregamento de configuração.

**Integrações técnicas confirmadas:** React e estados/refs; TinyMCE e skins locais; Mammoth no navegador para DOCX→HTML; API HTTP same-origin; Express e PostgreSQL; contexto de segurança; contexto de auditoria; contexto de atalhos; openPrintWindow usando Blob URL; PizZip/Docxtemplater/file-saver na emissão Word da Admissão; sanitização HTML em consumidores específicos.

**Sem evidência de acionamento por esta opção:** e-mail, WhatsApp/GoTalk, IA, DataJud, assinatura digital externa, bucket/App Storage para arquivos do modelo, webhook, automação de envio e integração fiscal. Não foram acessados segredos nem conectores para produzir este pacote.

# 12 — Impressão, limites e diferenças que afetam o uso
**Gerenciador:** lê getContent das refs de corpo, cabeçalho e rodapé (fallback vazio), não faz substituição de variáveis nem salva. Gera uma nova janela HTML por openPrintWindow, com título do modelo ou Formulário. Script de load chama window.print() e window.close(). Blob URL é revogada após load ou após 60 segundos; bloqueio de pop-up não gera toast específico neste utilitário.

**Estilo:** @page margin 0; body sem margem, Times New Roman 16px, line-height 1.5. Cabeçalho fixo no topo, width 100%, padding 10mm 20mm 5mm, height 30mm, overflow hidden e box-sizing border-box. Rodapé fixo embaixo, padding 5mm 20mm 10mm, height 20mm. Corpo com padding 35mm 20mm 25mm. Imagens max-width 100%; tabelas colapsadas, borda em td/th e padding 4px 8px. Conteúdo grande nas áreas fixas pode ser cortado.

**Preview não garante paginação idêntica:** a folha visual é A4, mas o HTML de handlePrint não declara size:A4 em @page. O tamanho final pode depender das preferências de impressão. Não há paginação automática de contador Página X de Y. Quebras inseridas pelo editor não equivalem a uma prova de que todos os consumidores as tratam igual; Auditoria tem divisão explícita por marcadores.

**Diferenças confirmadas que devem acompanhar a operação:**

- Vínculos configuráveis não asseguram botão consumidor em nove rotinas cadastradas.
- As permissões são separadas por ação. Ter apenas IMPRIMIR não abre gerenciador sem VISUALIZAR; e a lista não tem impressão direta.
- O atual editor só abre modelo existente com ALTERAR, não com modo somente leitura. Usuário com VISUALIZAR + IMPRIMIR e sem ALTERAR não recebe o botão Editar para imprimir por essa tela.
- Todas as rotinas declaram geral, tornando efetivamente permissivo o teste de grupos ativos.
- Tokens de titular existem no catálogo e são preenchidos na Auditoria, mas não no mapa HTML compartilhado da Admissão analisado.
- {{usuario.nome}} está no catálogo, mas não nos mapas de substituição aqui extraídos. O mapa HTML da Admissão também não implementa as variáveis gerais de data/hora que a Auditoria implementa.
- {{admissao.taxa_administrativa}} vem de data.parcela1 no HTML da Admissão, enquanto vem de admission.taxaCobranca na Auditoria. Não uniformizar esses valores na documentação.
- O rótulo Valor Boletos da barra lateral usa {{admissao.parcela2}}, enquanto o renderizador da Admissão também possui {{admissao.valor_boletos}} ligado a taxaCobranca. São chaves e origens distintas.
- Cálculo de parcelas a pagar na Admissão/Auditoria usa totalInstallments e paidInstallments em condição truthy; zero numérico e string '0' não são equivalentes nessa condição.
- Grid de Processos gera com o primeiro processo da página; detalhes usam o processo aberto; formulário usa dados atuais de formData. Não são emissores equivalentes.
- HTML e Word usam mapas diferentes; editar HTML não sincroniza DOCX original.
- Ocultar seções não remove seu conteúdo do payload; a impressão usa refs e pode depender da montagem atual dos editores.
- Não há proteção de concorrência por revisão no PUT; nem histórico/restauração nesta tela.
- Sucesso de salvar depende da sequência API/auditoria/refresh/onRefresh; falha posterior à escrita não deve ser interpretada automaticamente como prova de que nada foi persistido.

Esses pontos são constatações do código, não correções implementadas nem tarefas propostas. O aplicativo foi mantido inalterado.

# 13 — Roteiros de uso e verificação futura sem ambiguidade
**Cadastrar um modelo HTML:** entrar com VISUALIZAR e INCLUIR → Relatórios → Formulários → Novo Formulário → preencher Nome do Formulário → escrever no corpo → mostrar Cabeçalho/Rodapé se necessário → selecionar seção e inserir tokens → Rotinas → marcar destinos → Salvar → confirmar mensagem e linha.

**Alterar:** exigir ALTERAR → Editar na linha → conferir nome e conteúdo existente → modificar → Salvar. Cancelar/Voltar descartam alterações não salvas.

**Importar:** Novo ou Editar → Importar DOCX → escolher .docx até 10 MiB → conferir corpo convertido e inserir imagens manualmente → conferir tokens compatíveis com consumidor → Salvar. Para Word, preparar variáveis do mapa plano de exportação, não assumir equivalência com HTML.

**Excluir:** exigir EXCLUIR → Excluir na linha → ler confirmação → OK só quando desejar remoção definitiva. Não há restauração por essa interface.

**Vincular e consumir:** marcar rotina no modelo e salvar → abrir consumidor efetivamente implementado → verificar permissão de impressão e contexto → escolher modelo → conferir prévia → emitir. Em Admissão, considerar o possível efeito no status PENDENTE → NEGOCIAÇÃO antes de imprimir.

**Checklist de homologação ainda não executado em sessão real:** criar/editar/excluir registro descartável; conferir persistência após reload; testar ausência de permissões por papel; validar nome vazio/espaços/255+ caracteres; importar Word com tabelas/imagens; comparar HTML e DOCX; conferir todos os tokens usados pelo modelo no módulo escolhido; testar titular/unidade/banco/primeiro cenário; confirmar limite de 500 e existência de modelos além dele; testar pop-up bloqueado, impressão multipágina, A4 e margens; testar teclado, celular, zoom; garantir que cancelar não grava. Esses itens são roteiro documental, não confirmação de aprovação.

**O que já foi verificado nesta entrega:** extração consistente de categorias/tokens/contextos/modelos; rastreamento das ações no código; execução dos três testes existentes de permissão; captura pública do login; integridade ZIP, arquivos esperados e manifesto SHA-256. Nenhum dado real foi alterado.

**Como localizar evidência:** consulte inventarios/fontes.json; anexos/MAPEAMENTOS_COMPLETOS.md traz expressões e arquivo:linha por token; inventarios/variaveis.csv permite filtrar todas as colunas de suporte. Os números de linha correspondem ao conteúdo local capturado e podem mudar após alterações futuras.


## Tratamento dos originais Word legados

Três constantes de modelo possuem binários DOCX originais. A inspeção local identificou preenchimentos pessoais nesses arquivos; os binários não foram incluídos no pacote. Foram preservados os modelos HTML com campos dinâmicos e seus metadados, e foi documentada a existência dos originais. Este ZIP não é uma cópia integral de arquivos pessoais legados nem um backup dos modelos cadastrados.

# Financeiro — Contas a Receber e Contas a Pagar

## 1. Escopo, método e leitura deste documento

Este manual relaciona os campos, funções, padrões, Data Grids, CRUD, modais, integrações e relacionamentos das opções **Financeiro → Contas a Receber** e **Financeiro → Contas a Pagar** no código disponível nesta sessão.

Não foram realizados login, consulta a dados reais, gravação, baixa, cancelamento, exclusão ou teste de pagamento. A interface autenticada não foi verificada em navegador. As descrições separam **o que a interface oferece**, **o que o servidor grava** e **o que depende de integração ou apresenta limitação**.

**Padrão** é o valor inicial do controle, não conteúdo de um registro real. Datas iniciais usam em geral `new Date().toISOString()`, portanto referência UTC, que pode diferir do dia local perto da virada. Valores são apresentados em reais com máscara brasileira.

**Legenda:** C = criar; R = consultar; U = alterar; D = excluir. Cancelar, reabrir e estornar baixa são operações diferentes de exclusão.

## 2. Visão geral das duas opções

| Aspecto | Contas a Receber | Contas a Pagar |
|---|---|---|
| Finalidade | Direitos de recebimento de parceiros/clientes | Obrigações de pagamento a fornecedores |
| Escopo interno | RECEBER | PAGAR |
| Entidade de auditoria | CONTA_RECEBER | CONTA_PAGAR |
| Cadastro da pessoa | Cadastro compartilhado de clientes/parceiros | O mesmo cadastro compartilhado; rótulo Fornecedor |
| Movimento de baixa | Crédito, origem BAIXA_RECEBER | Débito, origem BAIXA_PAGAR |
| Consulta de títulos | API de títulos financeiros, 50 por página | Mesma API, 50 por página |
| Tela Novo/Editar | Substitui a listagem por formulário com três abas | Mesmo padrão, com diferenças de campos indicadas adiante |
| Recorrência | Envia criação das parcelas ao servidor | No fluxo examinado, cria parcelas apenas na lista local |
| Parcelas do modelo | Botão Parcelas condicional e modal dedicado | Não há botão equivalente nessa grade |
| Ficha de Admissão | Acesso condicional para título ligado à auditoria/admissão | Não encontrado no formulário de Pagar |

Os módulos não efetuam pagamentos bancários, não emitem automaticamente boletos/Pix e não enviam cobranças pelos botões documentados. Baixar significa registrar a liquidação no sistema.

## 3. Tela de listagem — áreas e valores iniciais

As duas listagens têm cinco cartões de vencidos, Novo Lançamento, menu Ações, pesquisa/status, filtros avançados, seleção de colunas, grade, totais recolhidos e paginação.

| Área / campo | Padrão | Acionamento |
|---|---|---|
| Pesquisa | Vazia | Digitar cliente/fornecedor, documento ou histórico; busca na API após 300 ms sem nova digitação |
| Status | Em Aberto | Altera o filtro local por status exato |
| Faixa de atraso | Nenhuma | Clique em um cartão ativa/desativa a faixa |
| Filtros avançados | Recolhidos | Botão de filtros mostra/esconde os campos adicionais |
| Colunas Visíveis | Seletor recolhido | Botão de colunas abre checkboxes |
| Emissão na grade | Oculta | Pode ser marcada no seletor |
| Demais colunas de dados | Visíveis | Podem ser ocultadas individualmente |
| Ordenação | Vencimento crescente | Clique no cabeçalho alterna crescente/decrescente |
| Seleção de títulos | Nenhuma | Checkbox da linha ou do cabeçalho |
| Totais | Recolhidos | Ver Totais / Ocultar Totais |
| Página | Primeira; 50 registros por página | Controles da paginação consultam outra página |

### 3.1 Cartões de vencidos

| Cartão | Faixa considerada |
|---|---|
| Venc. até 5 dias | 1 a 5 dias de atraso |
| Venc. 6 a 30 dias | 6 a 30 |
| Venc. 31 a 60 dias | 31 a 60 |
| Venc. 61 a 90 dias | 61 a 90 |
| Venc. +90 dias | Mais de 90 |

Cada cartão mostra soma dos saldos atuais e quantidade de títulos **ABERTO ou PARCIAL**, vencidos antes de hoje. Clique novamente na faixa ativa limpa a faixa. Título vencendo hoje não entra nos cartões.

Os cartões são calculados sobre os títulos carregados, antes dos filtros locais; não são um total global garantido de todas as páginas. O filtro Em Aberto inicial continua ativo ao selecionar uma faixa: títulos parciais podem compor o cartão e ainda assim não aparecer na grade por causa do status escolhido.

### 3.2 Todos os filtros avançados

| Campo | Padrão | Regra |
|---|---|---|
| Cliente / Fornecedor | Vazio | Trecho do nome, sem diferenciar maiúsculas/minúsculas |
| Emissão (De) | Vazio | Limite inicial pela data de emissão |
| Emissão (Até) | Vazio | Limite final pela emissão |
| Vencimento (De) | Vazio | Limite inicial pelo vencimento |
| Vencimento (Até) | Vazio | Limite final pelo vencimento |
| Data Baixa (De) | Vazio | Compara com a data do último elemento do array de baixas carregado |
| Data Baixa (Até) | Vazio | Mesmo critério |
| Tipo de Documento | Todos | Igualdade do ID selecionado |
| Limpar Filtros | Botão | Limpa nome, datas, tipo documental, status e pesquisa |

Não há botão Aplicar. Recolher o painel não limpa valores. **Limpar Filtros não limpa explicitamente a faixa de atraso ativa**, que deve ser desativada pelo cartão.

O filtro Data Baixa não procura qualquer baixa no intervalo: usa um elemento específico da lista disponível. A consulta de baixas do servidor ordena da mais recente para a mais antiga; usar o último elemento pode representar a mais antiga, não a última cronologicamente. A lista da página pode não trazer todo o histórico aninhado.

### 3.3 Opções completas do filtro Status

| Código | Apresentação / significado |
|---|---|
| Vazio | Todos Status |
| ABERTO | Em Aberto |
| PARCIAL | Parcial |
| PAGO | Liquidado |
| CANCELADO | Cancelado |
| ADIANTAMENTO | Adiantamento |
| ADIANTAMENTO_PARCIAL | Adiant. Parcial |
| DEVOLUCAO | Devolução |
| DEVOLUCAO_PARCIAL | Dev. Parcial |
| DEVOLUCAO_VINCULADA | Dev. Vinculada |
| AGRUPADO | Baixada Por Fatura |
| FATURA_GERADA | Faturas Geradas / Fatura Gerada |
| PROTESTADO | Protestado |
| PROVISAO | Provisão |

O status não é um seletor livre no formulário de título; em geral resulta da operação, do tipo e dos marcadores.

## 4. Data Grids principais — campos, consultas e totais

### 4.1 Todas as colunas

| Coluna | Conteúdo | Inicial | Ordenável |
|---|---|---|---|
| Seleção | Checkbox do título | Desmarcado | Não |
| Vencimento | Data de vencimento | Visível | Sim |
| Emissão | Data de emissão | Oculta | Sim |
| Cliente / Histórico ou Fornecedor / Histórico | Nome e descrição em segunda linha; sinalização de bloqueio quando aplicável | Visível | Sim, pelo nome |
| Documento | Número do documento | Visível | Sim |
| Valor Original | originalValue; na ausência/zero usa value | Visível | Sim |
| Valor Baixado | Soma de amount no histórico de baixas carregado | Visível | Sim |
| Saldo | currentBalance quando disponível; senão cálculo auxiliar | Visível | Sim |
| Status | Etiqueta do status; Rastreio e Parcelas quando aplicáveis | Visível | Sim |
| Cancelar | Ícone conforme permissão e status | Condicional | Não |
| Excluir | Lixeira para cancelados, conforme permissão | Condicional | Não |
| Auditoria | Relógio com histórico do ID | Visível | Não |

- Clique na linha abre o formulário; botões/checkboxes impedem propagação para não abrir indevidamente.
- Cabeçalhos de dados aceitam clique, Enter e Espaço.
- Grade virtualizada: linhas de 40 px e área de lista limitada a cerca de 520 px; rolagem não carrega automaticamente todas as páginas.
- Sem edição de célula, arrastar linhas, duplicar, importar/exportar ou excluir em massa nessas grades.
- Selecionar todos considera apenas as linhas atualmente filtradas/carregadas, não todo o banco.
- Mudanças de filtro não são um mecanismo explícito de limpeza geral de seleção.
- Devoluções recebem prefixo negativo na exibição de valor/saldo; adiantamentos usam destaque laranja; protesto e provisão recebem sinalizações próprias.

### 4.2 Cálculos e rodapé

**Valor Baixado** = soma dos valores das baixas disponíveis. **Saldo** prioriza currentBalance; se ausente, usa valor original/valor + juros do título + multa do título − desconto do título − baixas.

Ver Totais expande:

- quantidade de títulos filtrados;
- soma do Valor Original;
- soma do Valor Baixado;
- soma do Saldo.

Os totais são do conjunto filtrado da página, não necessariamente todo o resultado da pesquisa. O prefixo negativo visual da devolução não significa que o rodapé subtrai automaticamente sua quantia: o cálculo soma os números armazenados.

### 4.3 Paginação, busca e amplitude da consulta

A API pagina em 50. Pesquisa por nome/documento/histórico é enviada ao servidor; status/datas/tipo/faixa/ordenação são tratados localmente sobre a página carregada. Assim, filtrar localmente uma página pode produzir lista vazia enquanto há registros elegíveis em outra.

Rastreio de grupos, procura de adiantamentos/devoluções e alguns indicadores também partem da lista disponível. Não se deve interpretar ausência nessas listas como prova de inexistência no histórico inteiro.

Em Pagar, algumas operações mantêm uma lista local marcada como alterada; recarregar a API não significa, por si, que essa lista local foi abandonada.

## 5. Menu Ações — todas as opções

| Opção | Condição / operação |
|---|---|
| Baixa Total | Um ou mais títulos elegíveis, mesmo parceiro; abre modal de baixa ou liberação/dedução preliminar |
| Baixa Parcial | Receber exige exatamente um; Pagar não aplica a mesma restrição explícita na abertura |
| Gerar Faturas | Um ou mais selecionados na interface; servidor exige no mínimo dois |
| Lançamento Recorrente | Exatamente um modelo não cancelado |
| Liberar Protesto | Aparece se há selecionado protestado ainda sem registro de liberação |
| Liberar Provisão | Aparece se há selecionado em provisão ainda sem registro de liberação |
| Reabrir Título | Aparece se existe selecionado cancelado; pede confirmação nativa |
| Cancelar Baixa | Carrega baixas dos títulos selecionados e abre seleção de baixas a reverter |
| Cancelar | Visível para administrador ou permissão CANCELAR; mostra impacto ou fluxo específico de fatura |

Presença de AGRUPADO na seleção desabilita Baixa Total, Baixa Parcial, Cancelar Baixa e Cancelar no menu. O fluxo orienta operar nas faturas geradas, não no título de origem já agrupado.

Antes de executar ações do menu, existe verificação de parceiro bloqueado; a seleção com bloqueado interrompe a operação. Os controles de cancelamento/exclusão por linha têm verificações próprias de permissão.

## 6. CRUD — criar, consultar e editar título

### 6.1 Abertura e fechamento

**+ Novo Lançamento** inicializa título novo e abre **Dados do Título**. Clique na linha carrega as baixas e abre edição. Não é um modal sobreposto à grade: é um formulário que substitui a listagem dentro do módulo.

Três abas: **Dados do Título**, **Classificação e Origem**, **Baixas do Título**. Cancelar ou X retorna à lista sem salvar alterações do formulário. Não há confirmação de descarte implementada ali.

Salvar Título envia POST em inclusão e PUT em edição, espera a resposta, atualiza a lista, registra auditoria e fecha em sucesso. Erro é mostrado por aviso. Ctrl+Enter/Command+Enter registra a ação de salvar enquanto o formulário está aberto.

### 6.2 Padrões internos de um título novo

| Campo interno | Padrão comum |
|---|---|
| ID | Vazio; servidor atribui na inclusão |
| Escopo | RECEBER ou PAGAR, imposto pelo módulo |
| Status | ABERTO |
| Tipo | PADRAO |
| Origem | MANUAL |
| Emissão, vencimento e previsão | Hoje em ISO/UTC |
| Valor, valor original, saldo | Zero antes de salvar |
| Unidade | Primeira unidade da lista, não uma procura explícita pela unidade ativa |
| Contábil | NAO_CONTABIL |
| Protestado / provisão | Falso |
| Juros, multa e desconto do título | Zero |
| Documento, pessoa, histórico e classificações | Vazios |
| Data de criação | Momento atual em ISO |
| Situação de cobrança | COBRAR, somente inicializada em Receber |

Na inclusão, valor original e saldo são igualados ao Valor Total informado. Juros/multa/desconto do título não são somados a essa inicialização. Na edição, o payload remove explicitamente valor original e saldo; alterar Valor Total não equivale a recalculá-los nesse método.

### 6.3 Validações de Salvar Título

O formulário exige:

1. Nº Documento não vazio;
2. Parceiro/Fornecedor;
3. Tipo de Documento;
4. Portador;
5. Histórico;
6. Valor maior que zero.

As classificações não são marcadas como obrigatórias por esse validador local. Datas/referências ainda podem ser recusadas pelo servidor ou banco. Alguns identificadores de relacionamentos que não sejam UUID são retirados do payload pelo sanitizador, em vez de enviados tal como aparecem no estado.

## 7. Aba Dados do Título — campos completos

### 7.1 Informações do Documento

| Campo | Receber | Pagar | Padrão / efeito |
|---|---|---|---|
| Nº Documento | Texto | Texto | Vazio; obrigatório |
| Tipo do Título | Lista Padrão, Adiantamento, Devolução | Dois checkboxes Adiantamento e Devolução | Padrão; em Pagar ambos escrevem no mesmo campo type e são mutuamente exclusivos no estado |
| Parceiro / Fornecedor | Lista do cadastro compartilhado | Lista do mesmo cadastro | Sem seleção; atribui ID e nome |
| Editar parceiro/fornecedor | Botão ao lado da pessoa | Botão ao lado da pessoa | Desabilitado sem pessoa; disponibilidade efetiva do modal em Pagar tem ressalva na seção 21 |
| Situação | Em dia, Cobrar, Não Cobrar | Não há controle equivalente | Receber inicia Cobrar; não é o status financeiro |
| Tipo de Documento | Lista de descrições | Mesma função | Sem seleção; obrigatório |
| Portador | Lista de nomes | Mesma função | Sem seleção; obrigatório |
| Histórico | Área de texto | Área de texto | Vazio; obrigatório |
| Aviso de bloqueio | Banner se pessoa bloqueada | Mesmo | Informativo, com salvamento desabilitado para pessoa bloqueada |

As listas de pessoas exibem a coleção recebida; não há filtro local explícito que exija uma categoria específica de “fornecedor” para Pagar. Tipo do título não é tipo de documento.

### 7.2 Valores e Prazos

| Campo | Padrão | Função |
|---|---|---|
| Data de Emissão | Hoje | Data do documento |
| Data de Vencimento | Hoje | Base dos filtros, atrasos e recorrência |
| Data de Previsão | Hoje; fallback visual para vencimento quando ausente | Previsão de recebimento/pagamento |
| Valor Total | 0,00 | Principal informado, positivo |
| Juros | 0,00 | Valor monetário do título; não percentual diário |
| Desconto | 0,00 | Valor monetário cadastrado |
| Multa | 0,00 | Valor monetário cadastrado |
| Validade Desconto | Vazia | Data-limite cadastrada; não há aplicação automática dessa validade no fluxo de baixa examinado |

Campos de juros/multa/desconto da baixa são inicializados separadamente em zero; não são preenchidos automaticamente com os valores dessa aba pelo método de abertura.

## 8. Aba Classificação e Origem — campos completos

| Campo | Padrão | Conteúdo e funcionamento |
|---|---|---|
| Departamento | Sem seleção | Código e nome dos departamentos |
| Unidade | Primeira unidade | Nome fantasia ou razão social |
| Categoria Contábil | Sem seleção | Código e nome das contas analíticas do plano |
| Conta Bancária | Sem seleção | Descrição das contas cadastradas |
| Vendedor | Sem seleção | Colaboradores cujo active não seja falso |
| Colaborador Responsável | Sem seleção | Presente nas duas opções; mesma filtragem de ativos e ID do responsável |
| Tipo Contábil | Não Contábil | Não Contábil / Contábil |
| Parcela | Vazia | Número mínimo 1; desabilita se há parentId ou recurrenceId |
| Total Parcelas | Vazio | Número mínimo 1; mesmo bloqueio |
| Protestar título | Desmarcado | Somente tipo Padrão não pago/cancelado |
| Marcar como provisão | Desmarcado | Somente Padrão não pago/cancelado/protestado |

No seletor Categoria Contábil, o filtro explícito é **isAnalytical**; não há recorte por Receita em Receber ou Despesa em Pagar nesse seletor.

Apesar do nome da aba, **não há seletor livre de Origem**: MANUAL/RECORRENCIA/AUDITORIA/IMPORTACAO são metadados definidos pelos fluxos.

Ao salvar:

- Adiantamento assume status ADIANTAMENTO, exceto situações já pagas/canceladas ou status específicos preservados.
- Devolução assume DEVOLUCAO sob regra equivalente.
- Título Padrão protestado pode assumir PROTESTADO.
- Provisão assume PROVISAO quando não prevalece protesto/pagamento/cancelamento/parcial.
- Retirar os dois marcadores de título anteriormente protestado/provisionado pode retornar ABERTO.
- Marcar protesto não comunica cartório; provisão não produz lançamento externo de contabilidade.

## 9. Aba Baixas do Título — grade e rastreabilidade

Ao entrar na aba em título existente, consulta as baixas no servidor. A área é de consulta; lançar/estornar ocorre pelo menu da listagem.

| Coluna | Conteúdo |
|---|---|
| Seq | Sequência visual, com zeros à esquerda |
| Data | Data da baixa |
| Juros | Juros registrados nessa baixa |
| Multa | Multa registrada |
| Desconto | Desconto registrado |
| Valor Pago | amount persistido |
| Origem | BAIXA MANUAL, BAIXA EM LOTE, FATURA GERADA ou valor existente |
| Histórico | Texto da operação |
| Movimento | Botão Ver se há movimento referenciado e callback de navegação; senão “-” |

Resumo: quantidade, juros totais, multas totais, descontos totais, total pago, valor em aberto e valor original. Vazio: orienta usar Ações para registrar baixa.

O Hub fornece navegação para Movimento nas duas opções. Essa navegação muda a opção financeira e tenta destacar a linha; depende da existência do ID, da carga e dos filtros de Movimento.

### 9.1 Rastreabilidade na aba

Se existe invoiceGroupId:

- Exibe código do grupo e indicação **Baixada Por Fatura** ou **Fatura Gerada**.
- Em título de origem: grade Faturas Geradas com Documento, Parcela, Vencimento, Valor e Status.
- Em fatura: grade Títulos de Origem com Documento, Descrição, Vencimento e Valor Original.
- Clicar numa linha relacionada muda o título exibido no formulário.
- A composição do grupo nessa área usa os títulos carregados, não uma busca integral do grupo.

## 10. Modal de baixa total/parcial — pré-condições

### 10.1 Regras comuns de abertura

- Deve existir seleção.
- Não admite cancelados ou AGRUPADO.
- Baixa Total recusa PAGO.
- Os selecionados devem pertencer ao mesmo parceiro/fornecedor.
- Protesto/provisão sem liberação abre primeiro o modal correspondente.
- Adiantamentos/devoluções disponíveis do mesmo parceiro podem abrir antes o modal de deduções.

### 10.2 Diferenças relevantes

| Regra | Receber | Pagar |
|---|---|---|
| Baixa Parcial de vários títulos | Bloqueada na abertura; exige um | Não tem a mesma trava explícita |
| Devolução | Bloqueia no caso de devolução aberta sem vínculo de devolução | Bloqueia qualquer título de tipo Devolução na seleção para baixa direta |
| Pessoas bloqueadas | Verificação no menu; botão Salvar do título desabilitado | Mesmas proteções gerais; abertura de edição também tem bloqueio |

Bloqueios visuais não substituem validação do servidor. O servidor também rejeita título pago/cancelado no endpoint de liquidação.

## 11. Modal Baixa Total em Lote / Baixa Parcial — todos os campos

### 11.1 Cabeçalho e abas

Mesmo com apenas um título, a baixa total usa o título **Baixa Total em Lote**. Mostra nome da pessoa e quantidade de títulos.

Abas **Valores & Datas** e **Conta & Histórico**; inicia em Valores & Datas.

### 11.2 Valores & Datas

| Campo / área | Padrão | Controle / regra |
|---|---|---|
| Títulos Selecionados | Seleção da listagem | Na baixa total com vários: Documento, Vencimento, Valor Original, Saldo e totais |
| Data do Pagamento | Hoje ISO/UTC | Data enviada à liquidação |
| Total Pago, modo total | Soma dos saldos | Somente leitura; recalcula saldo + juros + multa − desconto, mínimo zero |
| Valor a Receber, parcial em Receber | Soma do saldo selecionado | Editável, moeda |
| Valor a Pagar, parcial em Pagar | Soma dos saldos | Editável, moeda |
| Juros (+) | 0,00 | Moeda |
| Multa (+) | 0,00 | Moeda |
| Desconto (-) | 0,00 | Moeda |

### 11.3 Conta & Histórico

| Campo | Padrão | Conteúdo / efeito |
|---|---|---|
| Conta de Recebimento / Conta de Pagamento | Primeira conta disponível | Opção mostra descrição e saldo atual cadastrado |
| Saldo Atual da Conta | Da conta selecionada | Informação do cadastro, não consulta ao banco |
| Histórico | “Baixa - [histórico do título]” ou “Baixa em lote - [nome] - [quantidade] título(s)” | Texto editável |
| Forma de Pagamento | Depósito / Transferência | Dinheiro, Boleto Bancário, Depósito / Transferência, PIX |

A conta escolhida na classificação do título e a marca de conta padrão do cadastro não são procuradas para determinar esse padrão: o fluxo usa a primeira conta da lista.

**Forma de Pagamento está no estado/modal, mas não é enviada no payload de liquidação nem no movimento gerado por esses métodos.** Não há emissão de boleto/Pix ou disparo de transferência pela escolha.

### 11.4 Confirmar Baixa

1. Valida conta selecionada e valor informado maior que zero.
2. O servidor exige data e quantia positiva, recusa título inexistente/pago/cancelado.
3. Distribui juros, multa e desconto proporcionalmente aos saldos, arredondando por título.
4. Modo total usa o saldo de cada título como base; modo parcial usa o menor entre saldo do título e amountPaid.
5. Envia uma requisição de liquidação por título.
6. Após sucesso de todos, solicita um movimento bancário agregado, registra auditoria, fecha e limpa seleção.

**Fórmula enviada por título:** base + juros rateados + multa rateada − desconto rateado. O servidor reduz saldo por soma dos valores pagos, não separando o principal dos encargos para esse cálculo.

### 11.5 Limites de cálculo e gravação

- Servidor calcula saldo = máximo entre zero e value − soma(amount das baixas); juros/desconto/multa ficam em colunas próprias, mas amount também os contém.
- Consequentemente, um desconto pode deixar saldo residual em baixa chamada “total”; não se deve prometer quitação forçada independente dos valores.
- Na parcial, o amountPaid digitado participa da base e os encargos ainda são adicionados/subtraídos no valor enviado.
- Em Pagar, parcial com vários títulos não faz rateio explícito do principal informado entre eles: o mesmo amountPaid limita a base de cada título. Não pressupor que o total final persistido será igual ao valor digitado uma única vez.
- O movimento bancário usa amountPaid do modal, não uma recomposição garantida da soma exata das baixas.
- Falha no meio do lote interrompe os próximos e informa quantos foram baixados antes. Não há transação única envolvendo todos os títulos.
- Não há bloqueio geral de reenvio/botão ocupado no modal compartilhado.
- A gravação do movimento bancário é posterior e separada; a mensagem de baixa não comprova que o movimento bancário foi criado com êxito.
- Não há validação local de saldo bancário suficiente no pagamento.

### 11.6 Fechar e atalhos

Cancelar ou X fecha. O fundo não tem ação de fechamento nesse modal. Ctrl+Enter/Command+Enter confirma a baixa. Não confundir com Escape: esse modal não implementa Escape no código consultado.

## 12. Movimento bancário gerado pela baixa

| Campo | Receber | Pagar |
|---|---|---|
| Conta | Escolhida na baixa | Escolhida na baixa |
| Data | Data do pagamento | Mesma |
| Tipo | CREDITO | DEBITO |
| Origem | BAIXA_RECEBER | BAIXA_PAGAR |
| Descrição | Histórico ou “Recebimento” | Histórico ou “Pagamento” |
| Documento | LOTE se vários; documento do título ou AVULSO se único | Mesma regra |
| Valor | amountPaid do modal | Mesmo |
| Categoria | Do primeiro título selecionado | Do primeiro |
| Nome da categoria enviado | Recebimento | Pagamento |
| Status | CONCILIADO | CONCILIADO |
| titleId / titleSource | Primeiro título / RECEBER | Primeiro título / PAGAR |
| ID solicitado | UUID compartilhado pelas baixas do lote | Mesmo mecanismo |

Embora o status enviado seja CONCILIADO, o objeto não preenche explicitamente o booleano reconciled. A tela Conciliação Bancária usa essa marca, enquanto Movimento usa status.

Em lote, só o primeiro título é colocado em titleId do movimento agregado. Cada baixa guarda uma referência de movimento. A API genérica pode atribuir seu próprio ID ao criar o movimento; não se deve garantir correspondência do UUID solicitado sem verificar o registro gravado.

O Hub tenta atualizar o saldo atual configurado da conta após criar movimento. Não há operação bancária real nem transação única que cubra títulos, movimento e configuração.

## 13. Modal Dedução de Adiantamentos / Devoluções na Baixa

Abre automaticamente antes da baixa se a lista carregada contém créditos elegíveis da mesma pessoa, fora da seleção e com saldo positivo:

- Adiantamento em ADIANTAMENTO, ADIANTAMENTO_PARCIAL ou ABERTO.
- Devolução em DEVOLUCAO, DEVOLUCAO_PARCIAL ou ABERTO.

### 13.1 Conteúdo completo

| Área | Campos / colunas |
|---|---|
| Títulos que serão baixados | Documento, Descrição, Vencimento, Valor Original, Saldo Atual |
| Disponíveis para dedução | Seleção, Tipo, Documento, Descrição, Vencimento, Saldo, Valor a Deduzir |
| Resumo | Saldo dos Títulos, Total Deduções, Valor Líquido |

Inicia sem itens selecionados e sem valores digitados. Ao selecionar um disponível, preenche seu saldo; o campo limita ao saldo do item.

### 13.2 Todas as ações

- **Prosseguir sem deduzir:** fecha dedução e abre baixa com saldo original.
- **Continuar sem Deduções:** mesmo prosseguimento quando total deduzido é zero.
- **Aplicar Deduções e Continuar:** valida total não superior ao saldo dos títulos; reduz disponíveis e destinos no estado local.
- **Cancelar/X:** fecha sem continuar.

Distribui dedução proporcionalmente aos saldos dos títulos de destino, com arredondamento. Guarda vínculos locais de título/valor/data em advanceLinks ou returnLinks.

Se houver saldo líquido, abre baixa para o restante; se a dedução cobrir tudo, informa compensação e limpa a seleção sem criar a baixa bancária habitual.

**Ressalva:** os métodos de dedução modificam a lista local e chamam atualização de lista, sem requisição específica de persistência dos vínculos/saldos ao servidor. Não há comprovação de gravação durável por esse caminho. Em lote, o vínculo do disponível aponta para o primeiro destino, embora os destinos recebam valores proporcionais.

## 14. Modal Vincular Adiantamento / Vincular Devolução

É oferecido após salvar título Padrão quando há disponíveis da mesma pessoa na lista carregada. Em Receber, o oferecimento também exige que o título salvo não tenha baixas carregadas. Em Pagar, não há essa condição adicional equivalente.

Se há adiantamentos, eles são oferecidos primeiro; devoluções são a alternativa quando não existem adiantamentos. Não há fluxo automático garantido de abrir os dois modais em sequência.

| Controle | Receber | Pagar |
|---|---|---|
| Contexto | Documento/pessoa/saldo do destino e quantidade de disponíveis | Fornecedor, documento e saldo do destino |
| Grade | Seleção, Documento/descrição, Saldo, Valor a Vincular | Seleção, Documento, Fornecedor, Saldo Disponível, Valor a Vincular |
| Seleção inicial | Nenhuma | Nenhuma |
| Valor inicial por item | Menor entre saldo disponível e saldo do destino | Ao selecionar, saldo completo do disponível |
| Edição de valor | Habilita somente se selecionado; limita ao saldo do disponível | Mesmo |
| Total a vincular | Soma dos valores selecionados | Mesmo |
| Ação de dispensar | Ignorar / X | Pular / X |
| Confirmar | Habilita com seleção | Confirmar Vinculação, com seleção |

Confirmação reduz saldos e registra vínculos locais. Adiantamento esgotado vira PAGO; devolução esgotada vira DEVOLUCAO_VINCULADA; sobras ficam em status parcial específico. Destino esgotado vira PAGO.

Receber limita sequencialmente a aplicação ao saldo restante do destino. Pagar soma os valores selecionados e zera o destino com piso zero, sem a mesma limitação agregada explícita; não assumir prevenção equivalente de excesso.

**Persistência:** as duas implementações operam sobre os arrays locais nesse fluxo. O Hub de Receber apenas recarrega títulos; Pagar mantém estado local. Não foi encontrado envio dedicado dos vínculos/saldos por esse método.

## 15. Modal Liberação de Protesto / Provisão

Acesso pelo item condicional no menu ou automaticamente ao tentar baixar título protegido. Trabalha um título elegível por vez, não todos de uma só vez.

| Campo / informação | Padrão / regra |
|---|---|
| Cabeçalho | Liberação de Protesto ou Liberação de Provisão |
| Alerta | Explica condição protegida e necessidade de motivo |
| Motivo da Liberação * | Vazio; área de texto obrigatória |
| Cancelar / X | Fecha e cancela continuação de baixa pendente |
| Confirmar Liberação | Exige motivo não vazio; altera marcador/status no estado local |

Guarda nome textual “Administrador”, data ISO e motivo no objeto de log de liberação. Esse texto não é necessariamente a identidade autenticada.

Ao liberar protesto, limpa isProtested e volta para PROVISAO ou ABERTO conforme o outro marcador. Ao liberar provisão, limpa isProvision e pode retornar ABERTO. Se abriu durante baixa, retoma a tentativa após fechar.

Não comunica cartório e não desfaz protesto externo. Não foi encontrado PUT específico desse método para persistir a liberação; o objeto de log local não deve ser confundido com as colunas de liberação existentes no banco.

## 16. Modal Cancelar Baixa(s)

### 16.1 Abertura e grade

Selecionar títulos → Ações → Cancelar Baixa. Busca baixas de cada título no servidor. Sem baixas, mostra aviso e não abre.

| Coluna | Conteúdo |
|---|---|
| Seleção | Checkbox por baixa; checkbox do cabeçalho está desabilitado |
| Documento | O código preenche com a descrição do título, apesar do rótulo |
| Data Baixa | Data registrada |
| Valor | Valor da baixa |
| Histórico | Histórico da baixa |

Inicia sem seleção; clicar na linha ou checkbox alterna seleção. Rodapé mostra número de itens selecionados.

### 16.2 Ações e efeitos

- **Confirmar Cancelamento:** exige pelo menos uma baixa e solicita DELETE individual para cada uma.
- O servidor recalcula saldo/status do título pela soma das baixas restantes.
- **Cancelar/X:** fecha sem excluir baixas.
- Ctrl+Enter/Command+Enter confirma se há seleção.
- Não há fechamento por fundo implementado.

A rota de exclusão de baixas examinada **não exclui automaticamente o movimento bancário relacionado**. Não se deve prometer estorno bancário completo; a operação remove a liquidação e recalcula o título.

Se uma exclusão falhar depois de anteriores terem sucesso, não há rollback único do lote. Após sucesso, recarrega títulos/baixas; há cálculo local alternativo se a releitura do título falhar. Auditoria e mensagem são registradas após a reversão.

## 17. Modal Lançamento Recorrente

### 17.1 Campos e prévia

Exige exatamente um título não cancelado. Não exige explicitamente que o modelo esteja aberto.

| Área / campo | Padrão / conteúdo |
|---|---|
| Modelo | Pessoa, histórico e valor original/valor do título |
| Nº de Parcelas | 2; controle limita de 1 a 120 |
| Periodicidade | Mensal, informação fixa |
| Prévia | Parcela, Documento, Vencimento, Valor |
| Total das Parcelas | Soma dos valores da prévia |

Primeira parcela no mês seguinte ao vencimento do modelo; demais mensalmente. Cada parcela repete o valor integral do modelo, não divide o principal. Datas usam adição de mês nativa: vencimentos no fim do mês podem sofrer transbordamento; não há ajuste explícito para último dia útil.

Documento na prévia: documento-base + parcela/total com zeros à esquerda. Pagar gera localmente documento com numeração não necessariamente idêntica ao preenchimento visual da prévia.

### 17.2 Gerar Parcelas — diferença entre módulos

**Receber:** envia `/api/financial-titles/create-installments`, escopo RECEBER e modelo existente. Servidor cria filhos vinculados por parent_id em transação, com status ABERTO, origem RECORRENCIA e valor integral do modelo por filho. O modelo é preservado. Copia categoria, tipo documental, portador, departamento, unidade e vendedor enviados. A conta bancária do modelo não é enviada nesse callback, embora a rota tenha suporte a esse campo.

**Pagar:** monta novos objetos com IDs locais, parentId e recurrenceId e os adiciona à lista local. Não chama o endpoint de criação nesse método. A mensagem “Recorrência Gerada” não comprova persistência; recarga/nova sessão pode não manter as parcelas.

Gerar Parcelas, Cancelar e X. Ctrl+Enter/Command+Enter executa gerar. Não há geração contínua por agendador nessa função; ela cria/solicita a quantidade configurada de uma vez.

## 18. Modal Parcelas Recorrentes — exclusivo da grade Receber

O botão **Parcelas** aparece no modelo se a lista carregada contém algum título com parentId apontando para ele. Não é uma detecção global garantida de filhos.

Ao clicar:

1. Mostra contexto da pessoa e documento do modelo.
2. Mostra Documento, Vencimento e Valor do Título Modelo.
3. Consulta `/api/financial-titles/:id/children`.
4. Lista Parcela, Documento, Vencimento, Valor, Saldo e Status.
5. Apresenta quantidade, total, carregamento ou ausência de parcelas.

É somente consulta: sem CRUD individual dentro desse modal. Fechar/X encerra. Em Pagar não foi encontrado modal equivalente de parcelas na grade atual.

## 19. Modal Gerar Faturas

### 19.1 Seleção e campos padrão

Mesma pessoa em todos os títulos. Interface impede cancelados, agrupados, pagos e faturas já geradas. A interface permite abrir com um título, mas o servidor **exige ao menos dois** para concluir.

| Campo / área | Padrão | Conteúdo |
|---|---|---|
| Pessoa e quantidade | Seleção atual | Cabeçalho |
| Títulos de Origem | Seleção | Documento, Descrição, Vencimento, Saldo; soma dos saldos |
| Nº Documento | Seis últimos dígitos do relógio em milissegundos | Base com prefixo FAT- na interface |
| Nº de Parcelas | 1 | Limite 1 a 60 |
| 1º Vencimento | Hoje + 30 dias | Editável |
| Período (dias) | 30 | 7, 10, 15, 20, 30, 45, 60 ou 90 |
| Prévia das Faturas | Recalculada | Parcela, Documento, Vencimento, Valor |
| Total das Faturas | Soma da prévia | Leitura |

Divide a soma dos saldos pelas parcelas, arredonda centavos e ajusta a última. Documento: FAT-base-01, FAT-base-02 etc. Intervalo é em dias corridos, não mensalidade por calendário nem dia útil.

### 19.2 Acionamento e persistência

- **Gerar Faturas:** exige base documental não vazia e envia agrupamento ao servidor.
- Em transação, servidor valida títulos e escopo/pessoa, cria grupo UUID e faturas de tipo FATURA/status FATURA_GERADA.
- Novas faturas guardam IDs dos títulos de origem e código do grupo.
- Originais viram AGRUPADO e saldo zero.
- Registra baixa técnica com origem FATURA GERADA e amount zero no original; isso não é recebimento/pagamento bancário.
- Copia para faturas classificação do título modelo usado pelo servidor; não faz rateio de diferentes categorias dos títulos de origem.
- Data prevista acompanha vencimento das novas faturas.
- Geração não cria operação bancária nem nota fiscal/serviço.

Cancelar/X fecha; Ctrl+Enter/Command+Enter gera. Os dados de rastreio passam a ser consultados pela grade/aba de baixas.

## 20. Modal Rastreio de Fatura

Acionado por **Rastreio** em título com invoiceGroupId. Mostra:

- Pessoa e documento do título acionado.
- Identificação “Baixada Por Fatura” ou “Fatura Gerada”.
- ID do grupo.
- Grade **Títulos de Origem**, com total de valores originais.
- Ligação visual “Gerou”.
- Grade **Faturas Geradas**, com total.

| Grade | Colunas |
|---|---|
| Origens — Receber | Documento, Descrição, Vencimento, Valor Original, Baixa, Status |
| Origens — Pagar | Documento, Descrição, Vencimento, Valor Original, Status |
| Faturas — ambas | Parcela, Documento, Vencimento, Valor, Saldo, Status |

Receber consulta baixas técnicas de origem FATURA GERADA para preencher a coluna Baixa com valor/data. Como a baixa técnica é de valor zero, isso não significa pagamento em dinheiro.

Somente leitura, sem alterar grupo, excluir fatura ou cancelar pela grade do modal. Fechar/X encerra. O grupo é reconstruído a partir dos títulos carregados; pode ficar incompleto entre páginas.

## 21. Modal Editar Parceiro / Fornecedor

### 21.1 Disponibilidade

- **Receber:** botão ao lado de Parceiro abre Editar Parceiro quando há pessoa selecionada.
- **Pagar:** o botão define a pessoa, mas o modal está condicionado também a onUpdateConfig e config. A montagem do FinancialPanel examinada **não fornece essas duas propriedades**. Portanto, o botão não tem abertura efetiva desse modal por essa montagem.

### 21.2 Todos os campos

O formulário copia o cadastro existente, não preenche dados fictícios.

| Campo | Conteúdo / regra |
|---|---|
| ID | Exibido no cabeçalho, não editável |
| Nome / Razão Social * | Obrigatório; botão de salvar bloqueia nome em branco |
| Tipo | Pessoa Física ou Pessoa Jurídica |
| CPF / CNPJ | Rótulo e sugestão mudam conforme tipo |
| Telefone / WhatsApp | Texto |
| E-mail | Entrada de e-mail |
| Endereço | Texto |
| Número | Texto |
| Complemento | Texto |
| Bairro | Texto |
| Cidade | Texto |
| Estado | Até dois caracteres, convertidos para maiúsculas |
| CEP | Texto |
| Observações | Área de texto |

**Salvar Alterações:** PUT no cadastro compartilhado, auditoria, atualização do nome no título em edição e fechamento. Cancelar/X/fundo fecha; atalho de salvar é registrado.

**Limitação:** o tratamento de erro do próprio modal também registra auditoria, atualiza nome local e fecha, sem apresentar falha ao usuário. Fechar não comprova que a alteração foi aceita pela API. Não cria um fornecedor separado nem atualiza automaticamente todos os nomes históricos de títulos.

## 22. Cancelar título — fluxo comum e modal de impacto

### 22.1 Como acionar

- Menu Ações → Cancelar, com permissão.
- Ícone Cancelar na linha, quando não CANCELADO/PAGO/PARCIAL/FATURA_GERADA e com permissão.
- Cancelamento de faturas pelo menu segue o fluxo específico da seção 23.

### 22.2 Modal de impacto — conteúdo e controles

Cabeçalho **Cancelar título** ou **Cancelar N título(s)**, advertência de operação e consulta de impacto antes de confirmar.

| Área | Conteúdo |
|---|---|
| Títulos a cancelar | Pessoa, vencimento e saldo dos títulos |
| Notas de Cobrança | Quantidade vinculada; informa que não serão alteradas |
| Registros de Negociação | Quantidade ativa; informa encerramento com status CANCELADA |
| Processos Jurídicos | Quantidade ativa vinculada por admissão; informa marcação CANCELADO |
| Alerta jurídico | Aparece se houver processos relacionados |
| Estado de consulta | Verificando impacto... ou erro de carregamento |

- **Voltar:** não cancela.
- **Confirmar Cancelamento:** bloqueado ao carregar impacto, em erro de impacto ou já confirmando.
- Escape/fundo fecha enquanto não está confirmando.
- Não há campo de motivo nesse modal.

### 22.3 Resultado

Chama cancelamento em lote; servidor pode retornar cancelados, bloqueados e ignorados. PAGO e PARCIAL são bloqueados e exigem cancelar as baixas antes. CANCELADO/AGRUPADO não seguem o mesmo cancelamento comum.

Para títulos elegíveis, zera saldo e marca CANCELADO; encerra negociações ativas e marca processos relacionados conforme vínculo por admissão. Notas de cobrança são preservadas. A interface mostra quantidades e motivos de bloqueio retornados.

O efeito jurídico é alteração de status interno; não protocolo automático de desistência em tribunal. Não confundir com consulta jurídica externa.

## 23. Cancelamento de faturas — dois modais específicos

### 23.1 Cancelamento Bloqueado

Ao selecionar fatura e Cancelar, procura faturas do mesmo grupo na lista. Se alguma está paga/parcial ou possui baixa efetiva, abre:

- Explicação de que primeiro é necessário cancelar baixas.
- Grade **Faturas com Baixa**: Descrição, Valor, Status, Vencimento.
- Fechar/X, sem ação de forçar cancelamento.

### 23.2 Confirmar Cancelamento de Faturas

Quando o grupo não tem baixa impeditiva:

- Explica que todas as faturas do grupo serão canceladas e títulos de origem reabertos.
- Grade **Faturas que serão Canceladas**: Descrição, Valor, Parcela, Vencimento.
- Grade **Títulos de Origem que serão Reabertos**: Descrição, Valor Original, Vencimento.
- Contadores e advertência.
- Cancelar/X fecha; **Confirmar Cancelamento** executa; Ctrl+Enter/Command+Enter confirma.

A interface envia cancelamentos e reaberturas individualmente. O endpoint de cancelamento de fatura já possui tratamento transacional do grupo, inclusive reabertura de origens elegíveis e remoção de baixas técnicas. Chamadas seguintes da interface podem ser redundantes; contagens visuais não devem ser tratadas como uma transação única de toda a sequência.

O servidor também verifica impedimentos de faturas pagas/parciais. O grupo mostrado no modal depende da lista carregada, enquanto o endpoint consulta o banco.

## 24. Reabrir título e excluir definitivamente

### 24.1 Reabrir Título

Ações → Reabrir Título aparece quando há cancelado selecionado.

- Trabalha títulos cancelados da seleção.
- Abre confirmação **nativa do navegador**, com quantidade, sem formulário próprio.
- Envia PATCH individual por título; conta sucessos, mostra falhas específicas e atualiza lista.
- Servidor aceita CANCELADO/AGRUPADO, restaura ABERTO e saldo a partir de valor original/valor.
- Para origem agrupada, remove baixa técnica FATURA GERADA e vínculo de grupo conforme endpoint.
- Não recria automaticamente movimento bancário nem reabre negociação/processo jurídico encerrado pelo cancelamento.

### 24.2 Excluir Título

Lixeira aparece somente para CANCELADO, com permissão EXCLUIR ou administrador.

Modal **Excluir Título (Contas a Receber/Pagar)**:

- Documento ou pessoa identificando o título.
- Advertência de exclusão permanente.
- Cancelar, Excluir; Escape/fundo cancela.
- Não há motivo, anexo ou escolha de destino.

Confirmação faz DELETE. Servidor bloqueia dependências de liquidações, título pago e algumas situações de grupo com título pago; outras restrições relacionais também podem impedir.

Não há lixeira/restauração de títulos nessa função. Cancelar preserva registro; excluir remove. Auditoria permanece uma trilha distinta do título.

## 25. Auditoria — modal por relógio da grade

Consulta histórico do ID do título.

| Coluna | Conteúdo |
|---|---|
| Data/Hora | Momento do evento |
| Usuário | Responsável registrado |
| Ação | Tipo de alteração |
| Campo | Campo detalhado |
| De | Valor anterior |
| → | Separador |
| Para | Valor posterior |

Consulta até 500 eventos, do mais recente para o mais antigo. Uma alteração de vários campos pode renderizar várias linhas; contador de eventos não equivale necessariamente à quantidade de linhas. Paginação de 15 linhas, Anterior/Próxima.

Carregamento/ausência de histórico, fechamento por X/Fechar/fundo. Somente leitura, sem apagar eventos, desfazer título ou exportar pelo modal.

Há auditoria no cliente e nos endpoints de determinadas operações. O registro de uma tentativa/alteração local não deve ser usado isoladamente como comprovante de persistência de todos os seus efeitos.

## 26. Integração com Auditoria e Ficha de Admissão — Receber

### 26.1 Banner e abertura

Em título com source AUDITORIA ou admissionId, o formulário Receber mostra:

- Identificação **Auditoria**.
- Texto “Lançamento gerado pela Auditoria”.
- Referência de contrato derivada do número de documento.
- Se existe admissionId, botão para visualizar a ficha/contrato, com carregamento.

Consulta admissão na API. Sem permissão mostra aviso de acesso negado; erro não abre a ficha.

### 26.2 Modal Ficha de Admissão — característica

É um visualizador, não cadastro da admissão. Inicia na aba **FICHA**, com abas **FINANCEIRO**, **DOCUMENTOS** e **AUDITORIA**. Rodapé “Somente visualização” e Fechar; X também encerra.

A chamada de Receber fornece apenas objeto de admissão e nome, não os objetos opcionais de cliente, titular, banco, modalidade, série, unidade e colaborador. Assim, seções dependentes desses objetos não são garantidas nesse caminho, mesmo existindo no visualizador compartilhado.

### 26.3 Aba Ficha — campos do visualizador

| Bloco | Campos de leitura |
|---|---|
| Identificação do Processo | Cliente/Responsável, Contrato, Data Admissão, Status, Tipo Cliente, Série, Colaborador, Indicação, Origem, Unidade quando disponível |
| Dados do Responsável, se objeto fornecido | CPF/CNPJ, RG, Data de Nascimento, Estado Civil, Profissão, Tipo, Telefone, Telefone 2, E-mail, Endereço completo, CEP e Anotações |
| Dados do Titular, se objeto fornecido | Nome, CPF/CNPJ, RG, Telefone, E-mail |
| Dados do Veículo, se preenchido | Marca, Modelo, Ano, Placa, Cor, Chassi, Renavam; indicador Elétrico |
| Informações Adicionais, se preenchidas | Taxa Administração e Primeira Parcela |

Valores ausentes usam traço ou ocultam o bloco condicional. Não há controles de criação/edição/exclusão nessa aba.

### 26.4 Aba Financeiro — campos do visualizador

| Bloco | Conteúdo |
|---|---|
| Banco e Modalidade | Banco, Modalidade, indicador Tarifa Bancária Inclusa e Contrato de Terceiro |
| Serviços bancários | Serviço, % Negociação, Sobre Valor Financiado, quando cadastrados |
| Dados Financeiros do Contrato | Valor Financiado, Valor Parcela Atual, Total Parcelas, Pagas/Em Atraso, Dia Vencimento, Tipo Pagamento, Venc. 1ª Parcela, Taxa Administrativa, 1ª Parcela Real, Taxa de Cobrança e Desconto quando existentes |
| Cenários de Recálculo | Cenário, Dívida Original, Nova Dívida, Economia, Parcelas, Valor da Parcela, Dia Vencimento |

São dados de contrato/admissão, não o formulário de baixa do título aberto.

### 26.5 Aba Documentos

- Consulta anexos da admissão ao abrir.
- Integra painel de anexos do cliente em modo somente leitura, no contexto ADMISSION.
- Mostra título e nome do arquivo; imagem pode ter miniatura clicável.
- Visualizar abre arquivo; Baixar documento inicia download.
- Carregando, vazio, erro e Tentar novamente são estados previstos.
- Não há upload/edição/exclusão no modo somente leitura usado aqui.
- Permissões e conteúdo do painel de anexos dependem da API e ACL; abrir a ficha não concede acesso irrestrito a arquivos.

### 26.6 Aba Auditoria

Consulta jurídica registrada, carregada sob demanda: carregamento, sem permissão, erro ou histórico disponível. Não dispara nova consulta jurídica.

Rounds de Auditoria: quantidade; número do round; data, autor e texto da crítica; resposta, autor e data quando presentes. Sem rounds, apresenta mensagem de ausência.

O conteúdo jurídico é histórico. Não é uma nova integração DataJud ativada por esse visualizador.

## 27. Integrações, relacionamentos e dicionário de dados

### 27.1 Mapa funcional

| Origem / entidade | Relação com o título |
|---|---|
| Clientes/Parceiros | clientId identifica a pessoa; clientName é nome copiado |
| Unidades | unitId |
| Plano de Contas | categoryId; categoria analítica no formulário |
| Tipos de Documento | documentTypeId; natureza documental, não número |
| Portadores | bearerId |
| Departamentos | departmentId |
| Contas Bancárias | bankAccountId no título e conta independente na baixa |
| Colaboradores | sellerId e assignedCollaboratorId nas duas opções |
| Admissões/Auditoria | admissionId e source AUDITORIA |
| Baixas | title_settlements por titleId |
| Movimentos bancários | movementId na baixa; titleId/titleSource no movimento agregado |
| Recorrência | parentId, recurrenceId, installmentNumber, totalInstallments |
| Faturas | invoiceGroupId, originTitleIds, type FATURA |
| Adiantamentos | advanceLinks no objeto local dos fluxos examinados |
| Devoluções | returnLinks no objeto local |
| Cobrança | collectionStatus, notas de cobrança relacionadas |
| Negociações | negotiationId e registros que podem ser cancelados com o título |
| Jurídico | Processos relacionados pela admissão para cálculo de impacto/cancelamento |
| Auditoria | Eventos por ID/entidade financeira |

### 27.2 Campos persistentes sem controle livre nas abas

O modelo/API também aceita ou mantém metadados como ID, escopo, origem, status, originalValue, currentBalance, creationDate/updatedAt, recurrenceId, parentId, invoiceGroupId, originTitleIds, admissionId, negotiationId e contractNumber.

Existem ainda protestDays, returnDate e colunas separadas de usuário/data/motivo de liberação de protesto/provisão. **Não há controles correspondentes nas abas atuais examinadas.** A liberação local usa objetos de log diferentes; não presumir mapeamento automático para essas colunas.

### 27.3 Listas auxiliares

Portadores, tipos de documento e plano são procurados em endpoints de lookup; se a resposta de uma lista está vazia, o componente usa a coleção recebida da configuração.

Departamentos, unidades, pessoas, contas bancárias e colaboradores são fornecidos ao componente pelo Hub. A seleção usa IDs, não associação apenas por nome. O servidor valida relação de admissão/cliente e existência das referências configuradas na rota.

### 27.4 Rotas acionadas ou relacionadas diretamente

| Rota / operação | Uso |
|---|---|
| GET /api/financial-titles | Listar/pesquisar/paginar pelo escopo |
| POST /api/financial-titles | Incluir título |
| PUT /api/financial-titles/:id | Alterar título |
| DELETE /api/financial-titles/:id | Exclusão permanente |
| GET /api/financial-titles/:id/settlements | Baixas do título |
| POST /api/financial-titles/:id/settle | Registrar baixa |
| DELETE /api/settlements/:id | Cancelar baixa e recalcular saldo/status |
| GET /api/financial-titles/cancel-impact | Calcular impacto do cancelamento |
| POST /api/financial-titles/batch-cancel | Cancelamento comum da seleção |
| PATCH /api/financial-titles/:id/cancel | Cancelamento, incluindo regras de grupo |
| PATCH /api/financial-titles/:id/reopen | Reabrir |
| POST /api/financial-titles/group-invoice | Gerar grupo/faturas |
| POST /api/financial-titles/create-installments | Parcelas persistentes em Receber |
| GET /api/financial-titles/:id/children | Parcelas do modelo em Receber |
| /api/bank-movements | Registro/consulta do movimento gerado |
| PUT /api/clients/:id | Editar cadastro compartilhado da pessoa |
| GET /api/audit-logs | Histórico por ID |
| GET /api/admissions/:id | Visualização da admissão, somente Receber |
| GET /api/admissions/:id/attachments | Arquivos da ficha |
| GET /api/admissions/:id/legal-scan | Consulta jurídica histórica |

Não listar capacidades adicionais de API como botões existentes: endpoints em lote não significam que a UI usa uma transação única para baixa.

## 28. Permissões e bloqueios

| Controle | Regra explícita encontrada |
|---|---|
| Cancelar Receber | Administrador ou fin_receber:CANCELAR |
| Excluir Receber | Administrador ou fin_receber:EXCLUIR |
| Cancelar Pagar | Administrador ou fin_pagar:CANCELAR |
| Excluir Pagar | Administrador ou fin_pagar:EXCLUIR |
| Pessoa bloqueada | Banner, ações do menu impedidas e Salvar Título desabilitado |
| Pagar: abrir edição com bloqueado | Método da linha impede abrir |
| Receber: abrir edição com bloqueado | Existe método com bloqueio, mas a grade usa callback próprio sem essa checagem; o formulário ainda desabilita Salvar |
| Pago/parcial no cancelamento | Regras de servidor impedem cancelar diretamente; primeiro cancelar baixas |
| Dependência na exclusão | Servidor impede excluir com liquidações e outros impedimentos |

Criar, editar e baixar não têm nos componentes o mesmo cálculo explícito por botão que CANCELAR/EXCLUIR; navegação, sessão e servidor podem ter restrições adicionais. Não houve teste por perfil, bypass, RLS ou permissão de produção.

O banner “somente consulta” de bloqueados não significa que toda implementação de abertura de formulário seja idêntica entre as duas opções.

## 29. Matriz final de operações

| Operação | Receber | Pagar | Observação |
|---|---|---|---|
| Criar/consultar/editar título | Sim | Sim | API; formulário com abas |
| Cancelar título | Sim | Sim | Permissão e impacto |
| Excluir título | Cancelado + permissão | Mesmo | Dependências podem impedir |
| Reabrir | Sim | Sim | Confirmação nativa e PATCH |
| Baixa total | Sim | Sim | Mesmo parceiro em lote |
| Baixa parcial | Um título | Sem a mesma trava de um | Regras de cálculo distintas do esperado para lote |
| Cancelar baixas | Sim | Sim | Seleção de baixas; não estorna automaticamente movimento bancário |
| Deduções | Interface local | Interface local | Persistência não comprovada pelo método |
| Vincular adiantamento/devolução | Interface local | Interface local | Não confundir com liquidação bancária |
| Liberar protesto/provisão | Interface local | Interface local | Motivo obrigatório; sem chamada específica |
| Recorrência | API com filhos persistentes | Lista local no fluxo atual | Não são equivalentes |
| Consultar parcelas em modal | Sim, condicional | Não encontrado | Detecção inicial depende da página |
| Gerar faturas | Sim | Sim | API; pelo menos dois títulos |
| Rastreio de fatura | Sim | Sim | Grupo da lista carregada |
| Editar pessoa | Modal disponível | Montagem atual não fornece requisitos do modal | Cadastro compartilhado |
| Ficha de Admissão | Condicional | Não encontrado | Consulta, sem CRUD da admissão |
| Auditoria | Sim | Sim | Consulta por ID |
| Exportar/importar títulos pela tela | Não encontrado | Não encontrado | Não confundir com opção separada Importação Excel |
| Pagamento bancário externo | Não | Não | Apenas registro interno |

## 30. Roteiros de acionamento

### 30.1 Incluir título a receber

Financeiro → Contas a Receber → Novo Lançamento → Dados do Título: documento, tipo, parceiro, situação, tipo documental, portador, histórico, datas e valor → Classificação e Origem: relações e controles → Salvar Título.

### 30.2 Incluir título a pagar

Financeiro → Contas a Pagar → Novo Lançamento → documento, fornecedor, tipo documental, portador, histórico, datas e valor → marcar adiantamento/devolução somente se aplicável → classificações → Salvar.

### 30.3 Baixar e consultar o movimento

Selecionar título(s) → Ações → Baixa Total/Parcial → tratar liberação/deduções se oferecidas → Valores & Datas → Conta & Histórico → Confirmar Baixa. Depois abrir título → Baixas do Título → Ver, se houver ID de movimento acessível.

### 30.4 Estornar baixa

Selecionar títulos → Ações → Cancelar Baixa → marcar baixas específicas → Confirmar Cancelamento. Conferir separadamente o movimento bancário, pois a rota examinada não o remove automaticamente.

### 30.5 Faturar e rastrear

Selecionar ao menos dois títulos elegíveis da mesma pessoa → Gerar Faturas → número-base, parcelas, primeiro vencimento e intervalo → conferir prévia → Gerar Faturas → Rastreio na grade ou aba de baixas.

### 30.6 Cancelar, reabrir ou excluir

Cancelar: selecionar elegíveis → Ações → Cancelar → conferir impacto → Confirmar. Fatura pode abrir bloqueio/confirmação específica.

Reabrir: selecionar cancelado → Reabrir Título → aceitar confirmação nativa.

Excluir: localizar cancelado → lixeira → Excluir; depende de permissão e ausência de impedimentos.

## 31. Evidências e limites do levantamento

Fontes principais:

- `components/financeiro/AccountsReceivableManager.tsx`
- `components/financeiro/AccountsPayableManager.tsx`
- `components/financeiro/FinancialPanel.tsx`
- `components/financeiro/modals/SettlementModal.tsx`
- `components/financeiro/modals/CancelSettlementModal.tsx`
- `components/financeiro/modals/InvoiceModal.tsx`
- `components/financeiro/modals/RecurringModal.tsx`
- `components/financeiro/modals/InvoiceCancelModal.tsx`
- `components/financeiro/EditPartnerModal.tsx`
- `components/ui/CancelImpactModal.tsx`
- `components/ui/ConfirmDeleteModal.tsx`
- `components/ui/AdmissionViewerModal.tsx`
- `components/ui/AuditLogButton.tsx`
- `server/routes/financialTitles.js`
- `server/routes/settlements.js`

O objetivo deste pacote é documentar o comportamento encontrado, não corrigir as diferenças apontadas. O ZIP não contém dados reais, extratos, credenciais nem cópia de banco. Os padrões das listas auxiliares dependem dos cadastros existentes e não podem ser enumerados como se fossem valores fixos da empresa.

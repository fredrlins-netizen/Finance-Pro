MANUAL FUNCIONAL — CONTAS A RECEBER E CONTAS A PAGAR
Meu Gestor Inteligente

CONTEÚDO
1. manual-contas-receber-pagar.html — leitura no navegador e impressão.
2. manual-contas-receber-pagar.md — mesma documentação em texto Markdown.
3. inventario-campos.csv — inventário tabular dos controles e seus padrões.
4. README.txt — estas instruções.

ESCOPO
Financeiro > Contas a Receber e Financeiro > Contas a Pagar:
telas, indicadores, filtros, grades, CRUD, abas de lançamento, baixas totais
e parciais, cancelamento, reabertura, faturas, recorrência, rastreabilidade,
adiantamentos, devoluções, permissões, integrações e relacionamentos.

MÉTODO
Levantamento baseado no código consultado nesta sessão. Não houve login,
alteração de dados, consulta a registros reais, teste de mutação ou operação
bancária. Os padrões são os definidos na abertura dos controles, não dados
da empresa. Diferenças e limitações encontradas estão explicitadas no manual.

O CSV usa ponto e vírgula como separador e codificação UTF-8 com BOM.
Os arquivos HTML e Markdown não precisam de instalação nem de conexão.

# Relatórios → Relatórios Gerais
## Documentação funcional e técnica e manual de utilização

Base: implementação local, sem exportação de dados reais.

# 01 — Escopo, método, evidências e limites
Esta é uma documentação da implementação local de Relatórios → Relatórios Gerais do Meu Gestor Inteligente. O módulo real é ReportBuilder. Foram rastreadas as telas, callbacks, contratos, rotas de API, regras de autorização, renderização, exportadores, migração e guia interno. Não se trata de proposta de reconstrução, backup de registros ou comprovação do comportamento de uma versão publicada.

Os inventários foram extraídos por análise sintática TypeScript/JSX de todos os 21 arquivos do diretório do construtor. Cada controle informa arquivo e linha, rótulo textual quando identificável, valor/checked, opções, eventos, condições e restrições presentes no código. Um controle repetido em uma lista tem uma definição no catálogo e pode originar várias instâncias na tela. Expressões não são dados de pessoas nem valores atuais de uma sessão.

Para não confundir intenções com funcionamento, esta documentação distingue: configuração oferecida, lógica efetivamente conectada e limitações observadas. O guia interno foi incluído integralmente como anexo de referência; em divergência, prevalece o comportamento rastreado nos capítulos técnicos.

**Verificação:** foram executados os três testes existentes de reportSecurity, com sucesso. Eles verificam seleção SQL somente leitura, validação de definição e lookup de visibilidade com pool simulado. Os roteiros sintéticos adicionais do pacote verificam funções puras extraídas, sem consultar o banco. Não certificam PostgreSQL real, autenticação ponta a ponta ou geração de arquivos em sessão autenticada.

**Limite visual:** a captura pública mostra a tela de login. A interface autenticada, os gráficos do usuário e o modal Salvar não foram abertos com credenciais nem verificados visualmente. Nenhuma autenticação foi removida. Não foram lidos segredos, consultados registros reais, disparadas consultas de relatórios no banco ou realizadas escritas no aplicativo.

**O que significa TODOS os campos:** os campos fixos de configuração, tipos e opções estão inventariados. As colunas de dados de um relatório são dinâmicas: dependem do SELECT salvo e do esquema acessível em public no ambiente. Não existe uma lista universal fixa de colunas de resultado, e este pacote não afirma enumerar o catálogo vivo do banco. O esquema exibido como exemplo no guia também não comprova que todas essas tabelas existam no ambiente atual.

Abra DOCUMENTACAO_COMPLETA.html para leitura integral offline. CSVs usam UTF-8 com BOM e ponto e vírgula. JSONs preservam estrutura e expressões. O manifesto SHA-256 permite conferir a integridade. Nenhuma alteração funcional foi feita.

# 02 — Navegação e estrutura da tela por perfil e dispositivo
O menu Relatórios contém Relatórios Gerais, ID rel_gerais. DashboardLayout carrega ReportBuilder de forma preguiçosa e passa config e currentUser. A navegação é controlada pelo shell; não foi identificada uma página pública autônoma do construtor. O endereço raiz informado pelo usuário exige sessão para alcançar o conteúdo do aplicativo.

**Tela principal:** painel Relatórios Salvos à esquerda; barra de ações; área do editor com abas; painel Preview executável. A árvore tem largura w-72, categorias expansíveis, contador por categoria, título truncado, ícone conforme modo de conteúdo e cadeado quando existem restrições. Categorias vazias mostram Nenhum relatório.

**Categorias fixas:** Cadastrais; Financeiro; Comercial; Jurídico; Negociação; Cobrança; Administrativo; Gerenciais; Outros. Todas começam expandidas. A árvore agrupa somente categorias conhecidas; valores de categoria fora dessa lista não são adicionados como grupo dinâmico.

**Barra superior:** mostrar/ocultar painel; Novo, Salvar e Excluir para administrador; Conteúdo com Dados/Gráficos/Ambos; Layout com Responsivo/Web/Mobile; nome do modelo salvo à direita. Excluir fica desabilitado sem ID salvo. Não há campo de busca de modelos na árvore nem paginação dessa listagem.

**Seis abas do administrador:** Fonte de Dados; Layout; Gráficos; Filtros; Subrelatórios; Guia. A aba inicial é Fonte de Dados. Preview é painel separado permanentemente disponível na composição ampla, não uma sétima aba na barra atual.

**Perfil não administrador:** não vê Novo/Salvar/Excluir nem abas de edição. A área central mostra orientação para selecionar relatório autorizado; um aviso informa que só administradores criam/editam templates SQL. Pode selecionar e executar relatório permitido. Os selects de Conteúdo e Layout da barra não são envolvidos pela mesma condição ADMIN: continuam presentes e alteram estado local da visualização, sem conceder gravação de modelo.

**Responsividade:** abaixo de 1200px, isNarrow=true. A árvore vira gaveta fixa de largura w-72, com overlay e botão fechar; clique fora fecha. Selecionar modelo fecha a árvore em tela estreita. Editor e preview alternam pelos botões Abrir preview/Voltar ao editor, evitando duas colunas simultâneas. Em largura de 1200px ou maior, o conteúdo usa grid de duas colunas e o painel lateral pode recolher a largura zero.

**Layout de saída não é breakpoint do editor:** target_layout mobile limita o contêiner do preview a 360px; web usa largura total; responsive usa max-w-4xl. O próprio ReportRenderer ainda desenha páginas com proporções A4 por seu cálculo interno; isso não cria um aplicativo móvel separado.

**Estados de usabilidade:** carregamento de templates, avisos de erro dispensáveis, estado sem consulta, estado antes da execução, carregamento da consulta, acesso negado, nenhum resultado e truncamento a 500 linhas. Há rótulos e botões nativos, mas não houve certificação de acessibilidade com leitor de tela, contraste, zoom ou teclado. Não foi encontrado autosave nem alerta de alterações pendentes ao trocar modelo, acionar Novo ou navegar.

# 03 — Modelo persistido, campos e valores padrão
O objeto ReportTemplate é persistido em report_templates. O ID é UUID gerado pelo PostgreSQL. Nome é VARCHAR(255) obrigatório; descrição é TEXT; categoria VARCHAR(100); layout de destino e modo de conteúdo VARCHAR(20); sql_query é TEXT obrigatório; layout, filters, subreports e charts são JSONB; allowed_users e allowed_groups são arrays de UUID; created_by é UUID; timestamps usam TIMESTAMPTZ; is_active é BOOLEAN.

| Campo | Padrão no cliente / função | Observação |
| --- | --- | --- |
| id | String vazia em novo; UUID depois de gravar | Não é entrada editável |
| name | Vazio | Nome * no modal; trim; Salvar desabilitado sem texto |
| description | Vazio | Textarea opcional de 2 linhas; trim no modal |
| category | Outros | Nove categorias fixas |
| target_layout | responsive | responsive / web / mobile |
| content_mode | both | data / charts / both |
| sql_query | Vazio | Servidor exige consulta válida; modal valida apenas nome localmente |
| layout | Cópia rasa de DEFAULT_LAYOUT | Detalhamento abaixo; não há clonagem profunda explícita nessa fábrica |
| filters / subreports / charts | [] / [] / [] | Itens configurados nas abas correspondentes |
| allowed_users / allowed_groups | null / null | Sem restrição apenas quando ambos são NULL; ver regra de acesso |
| created_by | userId do cliente ou null no rascunho | POST ignora autoria enviada e usa usuário do JWT verificado |
| created_at / updated_at | new Date().toISOString() no rascunho | Banco gera NOW(); PUT atualiza updated_at |
| is_active | true | DELETE do template muda para false; não apaga fisicamente |


**Cabeçalho padrão:** show=true; title=''; subtitle=''; logo=''; alignment=left; showDate=true; showLogo=true.

**Corpo padrão:** columns=[]; grouping=null.

**Rodapé padrão:** show=true; showTotals=false; totalizers=[]; showPageNumbers=true; showDateTime=false; customText=''.

**Configuração geral padrão:** pageSize=A4; orientation=portrait; fontSize=12; fontFamily=Arial; zebra=true; margins.top=20, bottom=20, left=15, right=15 (mm).

O esquema de banco usa layout={} como default, enquanto o cliente inicia com DEFAULT_LAYOUT completo. Não confundir esses padrões. Os arrays JSONB começam vazios no banco. Índices declarados: category, is_active e created_by. A migração inspecionada não declara FKs para created_by nem para elementos de allowed_users/allowed_groups.

Os arquivos padroes/*.json trazem todos os valores iniciais, inclusive objetos aninhados. O inventário contratos-e-campos lista cada membro dos contratos e seus tipos, incluindo campos sem entrada própria na interface.

# 04 — CRUD real, árvore de modelos e todos os modais
**Criar:** ADMIN → Novo → template vazio → configurar fonte/layout/filtros/gráficos/subrelatórios → Salvar → modal Salvar Relatório → preencher nome e demais metadados → Salvar → POST /api/reports/templates → retornar modelo salvo, fechar modal e recarregar árvore. O servidor exige name e sql_query; receber erro por SQL vazio não é impedido pelo botão Salvar do modal, pois ele testa somente nome.

**Ler/selecionar:** clicar no nome na árvore copia o template para o editor, reconstrói availableColumns a partir de colunas, filtros, subrelatórios e eixos dos gráficos e zera previewData. Seleciona Fonte de Dados e fecha preview móvel. Não realiza GET individual por ID nesse callback: usa o objeto da listagem. Existe endpoint GET por ID para consumo técnico.

**Editar:** selecionar template, alterar configurações e Salvar. Não há botão Editar separado nem modal de edição do dataset. O mesmo modal salva metadados e as configurações atualmente presentes no objeto. Não há edição de linhas das tabelas de negócio.

**Excluir:** modelo com ID → Excluir → confirmação nativa Tem certeza que deseja excluir este relatório? → OK → DELETE → servidor faz UPDATE is_active=false e updated_at=NOW() → cliente chama Novo e recarrega modelos. Cancelar confirmação não envia DELETE. Não há lixeira/restauração nesta tela, embora o registro seja preservado como inativo.

| Diálogo / camada | Todos os campos ou conteúdo | Padrão | Acionamento |
| --- | --- | --- | --- |
| Salvar Relatório | Nome *; Descrição; Categoria; Layout; Conteúdo; Usuários Permitidos; Grupos Permitidos; X; Cancelar; Salvar | Valores do template; seleções vazias viram NULL | Salvar chama handleSave; Ctrl/Cmd+Enter também; nome recebe trim; sem texto retorna sem salvar |
| Confirmação de exclusão | Mensagem fixa e botões nativos OK/Cancelar | Modelo selecionado | OK inativa no servidor; Cancelar preserva |
| Seletor de logotipo | Arquivo local accept image/* | Nenhum arquivo | FileReader.readAsDataURL grava string no cabeçalho e marca showLogo=true |
| Impressão | Janela HTML e diálogo nativo da plataforma | Conteúdo já gerado | window.open; após 500ms chama print; campos de impressora/páginas/cópias dependem do navegador |
| Gaveta estreita de relatórios | Categorias e modelos, botão fechar e overlay | sidebarOpen inicialmente true | Clique no overlay/X fecha; seleção carrega modelo |
| Histórico SQL | Lista local de até dez consultas com timestamp | Vazio ao montar Fonte de Dados | Clicar em entrada restaura SQL e fecha lista; não executa consulta automaticamente |
| Guias/configurações expansíveis | Seções de Layout, filtros e subrelatórios | Estados em inventário | Expandir/recolher não abre modal de sistema nem persiste sozinho |
| Downloads PDF/Excel/Word/CSV/HTML | Não há modal próprio de escolha de campos/destino no código | Nome deriva do título ou relatorio | Dispara download do navegador; comportamento Salvar como depende das preferências do navegador |


**Modal Salvar — detalhes:** largura max-w-lg, altura máxima 90vh, rolagem vertical, fundo preto translúcido e blur. Usuários vêm de config.users; grupos de config.userGroups. Cada lista mostra nomes com checkbox; ausência mostra Nenhum usuário/Nenhum grupo. Seleções são IDs, não nomes. A linha Categoria/Layout/Conteúdo usa três colunas. Cancelar e X fecham sem aplicar o estado local do modal ao template. O overlay não possui handler próprio para fechar por clique fora. Não há tratamento de Escape ou focus trap explicitamente implementado nesse componente. O atalho Ctrl/Cmd+Enter é registrado no window enquanto o modal está montado.

**Mensagens no modal versus regra real:** Vazio = todos têm acesso e Vazio = todos os grupos são dicas simplificadas. A regra do servidor é: ambos NULL liberam; caso contrário, basta usuário explicitamente permitido OU interseção com grupo permitido. Uma lista vazia convertida em NULL não anula uma restrição existente na outra lista.

**Concorrência e integridade:** não há ETag, número de revisão ou comparação de updated_at antes de atualizar. Não há duplicação de template, importação/exportação JSON de definição ou versionamento disponíveis na barra atual. As exportações documentadas são do resultado gerado, não backup do template.

# 05 — Fonte de Dados: modo SQL, construtor visual e schema
A aba inicia no modo SQL. rawSql recebe sqlQuery. Há alternância Visual/SQL, histórico local e teste da consulta. O editor SQL é textarea, não um editor com autocomplete semântico de banco. Alterações são comunicadas ao objeto ao perder foco e ao executar o preview.

**SQL:** digitar uma única consulta SELECT ou WITH ... SELECT; confirmar aliases estáveis para as colunas retornadas; executar preview da fonte. O teste envia POST /api/reports/preview-query com sql e limit=50, sem fornecer valores de filtros. Consultas contendo placeholders ainda não preenchidos podem falhar nesse teste, mesmo que o preview final com parâmetros seja utilizável.

**Histórico:** adiciona SQL executado com timestamp antes da resposta; remove duplicatas por texto exato; mantém dez entradas mais recentes. Não usa banco nem localStorage para persistência. Reabrir/remontar a aba pode reiniciar esse estado.

**Explorador de esquema:** busca tabelas em /api/reports/schema/tables; filtro Buscar tabela... é parcial e sem distinção de maiúsculas; selecionar tabela a adiciona e busca colunas sob demanda; abre/fecha suas colunas; tipos recebem badges. Remover tabela retira suas colunas selecionadas e joins em que participa. A remoção não limpa explicitamente todas as condições WHERE, GROUP BY e ORDER BY já montadas.

**Metadados de coluna recebidos:** column_name, data_type, is_nullable, column_default, ordinal_position, character_maximum_length, numeric_precision e numeric_scale. São propriedades do esquema real consultado, não campos editáveis de cadastro. Os endpoints limitam a inspeção ao schema public e exigem administrador.

**Seleção de colunas:** cada entrada guarda table, column e type. Marcar adiciona; desmarcar retira. A primeira tabela selecionada é a tabela base do FROM. A seleção não cria tabela/coluna no banco.

**Geração visual:** cada coluna vira "tabela"."coluna" AS "tabela__coluna". Identificadores aceitam somente letra/underscore inicial e letras/dígitos/underscore posteriores; recebe aspas duplas. A geração exige pelo menos uma tabela e uma coluna. A lista de campos passa a usar aliases após executar o preview.

**Relacionamentos JOIN:** disponível com duas ou mais tabelas. Busca FKs em /schema/foreign-keys. Quando nenhum join existe, tenta sugerir vínculos entre pares adjacentes de tabelas selecionadas. Usa a primeira FK encontrada em qualquer direção; sem FK, cria colunas vazias para escolha manual. Campos de join: id UUID, leftTable, leftColumn, joinType, rightTable, rightColumn. Padrão INNER JOIN; tabela esquerda primeira seleção e direita segunda. A interface oferece INNER JOIN, LEFT JOIN e RIGHT JOIN; o gerador também admite FULL JOIN em sua whitelist, embora não conste da união JoinConfig nem das opções normais.

**JOIN não significa criação de FK:** a configuração somente constrói SELECT ... ON esquerda= direita. Não grava relacionamento de negócio nem altera schema. Join com colunas vazias não é adicionado ao FROM pelo trecho condicional; configurações incompletas podem causar consulta inválida ou impedir a geração conforme o campo.

**ORDER BY / GROUP BY:** o usuário adiciona campos dentre as colunas selecionadas; novo item inicia pelo primeiro campo disponível. Remover retira o item. A geração acrescenta listas de campos qualificados; não há direção ASC/DESC por item nesse gerador. GROUP BY visual não cria expressões SUM/COUNT automaticamente: selecionar campos não agrupados sem agregação pode produzir erro PostgreSQL.

**Limite da conversão Visual↔SQL:** o modo visual mantém arrays locais e não faz parsing reverso completo do SQL salvo para reconstruí-los. Trocar para Visual não significa que uma consulta SQL arbitrária foi compreendida. A geração automática só substitui SQL quando generateSql retorna string não vazia; configuração visual inválida pode deixar SQL anterior no objeto. Conferir SQL final antes de salvar.

# 06 — WHERE visual, parâmetros e filtros de utilização
Há dois mecanismos separados: condições WHERE da construção de SQL e filtros de utilização preenchidos no preview. Acrescentar WHERE altera o texto SQL; criar filtro na aba Filtros define entradas e parâmetros do modelo.

**WHERE visual — todos os campos:** id gerado; field inicialmente vazio; operator='='; value=''; connector=AND. Campo vem da seleção de colunas qualificadas tabela.coluna. Operadores da UI: =, !=, >, <, >=, <=, LIKE, IN, BETWEEN, IS NULL e IS NOT NULL. A whitelist do gerador também reconhece <> e ILIKE. O conector AND/OR aparece a partir da segunda condição; sua validação aceita somente esses valores. Não há editor de parênteses/grupos lógicos aninhados.

**Literais:** aspas simples no texto são duplicadas. IN divide uma lista por vírgulas; BETWEEN literal espera dois valores separados por vírgula; NULL/NOT NULL dispensam entrada de valor. Identificadores inválidos, campos fora de tabela selecionada, operadores não permitidos ou tokens malformados fazem a geração retornar vazia. A UI só oferece AND/OR; se um conector inválido for colocado no estado por outro meio, o gerador omite o conector nesse trecho, podendo produzir SQL inválido em vez de retornar vazio.

**Parâmetros visuais:** {{nome}} reconhece um token completo com nome alfanumérico/underscore e início válido. IN com tokens admite lista de tokens separados por vírgula; BETWEEN com tokens exige {{inicio}} AND {{fim}}. A indicação dinâmico verifica começo/fim {{ }} no controle, mas a validação efetiva é mais restrita na geração.

**Aba Filtros — CRUD local:** Adicionar Filtro cria UUID, placeholder=primeira coluna disponível ou campo, label='', type=text, defaultValue='', options=[]. Abre o item recém-criado. Pode editar, remover e mover para cima/baixo; limites desabilitam o deslocamento. Cabeçalho recolhe/expande o filtro. Essas mudanças só persistem no template ao Salvar.

**Campos de cada filtro:** Rótulo (exibido ao usuário); Coluna / Campo (select se colunas disponíveis, input textual em outro caso); Tipo de filtro (Texto/busca parcial, Seleção/lista, Data, Número); Valor padrão opcional; Opções de seleção, uma por linha, quando type=select. As opções são separadas por quebra de linha, trimadas e vazias removidas. Aviso orienta executar preview da fonte para detectar colunas.

**Preview — conteúdo inicial:** filterValues começa {}; cada campo usa valor local se definido, senão defaultValue ou ''. Select inclui — Todos — com value vazio. Texto mostra Todos (deixe vazio); data usa input date; número usa input number. Limpar filtros define filterValues={} e, por isso, volta a aplicar valores padrão existentes; não garante que todos os campos fiquem vazios. Para ignorar explicitamente um default, apagar o conteúdo ou selecionar — Todos — gera valor local vazio.

**Parametrização:** para cada filtro procura {{placeholder}} e, se não encontrou esse estilo, :placeholder. Substitui as ocorrências pelo mesmo $N e acumula valor num array de parâmetros. O valor vazio também é enviado ao SQL quando há placeholder. O SQL deve tratar vazio quando se deseja Todos, por exemplo NULLIF({{status}}, '') IS NULL OR status = {{status}}. Não colocar aspas em torno de {{status}}: o driver parametriza o valor.

**Filtro sem placeholder no SQL:** aplicado no navegador depois da consulta. Texto é includes sem distinção de caixa; select é igualdade exata; data compara os primeiros dez caracteres; número compara parseFloat. Usa row[f.placeholder], portanto deve corresponder ao nome/alias retornado. Todos os filtros locais ativos se combinam por AND.

**Filtro já aplicado no SQL:** o ID entra em appliedFilterIds e não é reaplicado localmente. Um mesmo filtro pode ser SQL no relatório principal e local em subrelatório sem o token, conforme cada consulta.

**Consequência do limite:** filtrar localmente somente reduz as linhas já recebidas, no máximo 500; não consulta as linhas além do corte. Para totalizações completas e grandes volumes, definir filtros/agregações no SQL, não presumir que limpar filtros descarrega toda a base.

**Regras do servidor:** máximo de 50 filtros; IDs não vazios e únicos; placeholder com segmentos separados por ponto e cada segmento sendo identificador válido; tipos text/date/number/select. Rótulo, default e options não recebem a mesma validação estrutural completa nessa função. O inventário registra o contrato exato e não atribui restrições inexistentes.

# 07 — Layout: cabeçalho, colunas, agrupamento, rodapé e página
A aba Layout organiza seções recolhíveis. Todas as entradas alteram o objeto layout em memória. Para persistir, usar Salvar modelo.

**Cabeçalho:** botão/chave de exibição; Título; Subtítulo; Logotipo por URL ou arquivo local; opção de mostrar logo; alinhamento esquerda/centro/direita; mostrar data. Arquivo é convertido em Data URL por FileReader, não enviado a bucket por esse controle. O input aceita image/*, sem limite explícito de tamanho neste handler. Não se trata de assinatura digital.

**Origem do logo no uso:** PreviewTab recebe config.logoUrl. Para exportação, quando esse valor existe, substitui layout.header.logo por ele. No desenho do cabeçalho, logoUrl também participa da escolha do logo. Um upload no layout pode ser sobreposto pelo logotipo geral do aplicativo em determinados caminhos. Verificar antes de concluir que o logo específico sempre prevalecerá.

**Colunas — todos os campos:** field (nome técnico); label (Rótulo); visible (checkbox); width (Largura %, string); align (left/center/right); format. O movimento para cima/baixo reordena; não altera SQL. Novas colunas detectadas iniciam field/label iguais ao alias, width='100', align=left, format=text e visible=true. Configurações anteriores são preservadas para field já conhecido quando os campos retornados são reprocessados.

**Formatos de coluna:** Texto (text), Número (number), Moeda BRL (currency_brl), Data (date), CPF/CNPJ (cpf_cnpj), Percentual (percent). Formatação não transforma o tipo PostgreSQL nem atualiza o registro original. As larguras são relativas e não incluem redistribuição automática obrigatória para somar 100.

**Agrupamento e Quebras:** selecionar campos de agrupamento; texto/modelo de cabeçalho; Mostrar subtotais; operação por coluna numérica. O objeto nasce null. Quando necessário, passa a fields=[], headerTemplate='', showSubtotals=false e totalizers=[]. Retirar último campo só retorna a null se também não houver subtotais e totalizadores.

**Agrupamento visual versus GROUP BY SQL:** o layout agrupa linhas já retornadas, combinando valores dos campos por ' / ' e usando Sem grupo para ausentes. Não cria GROUP BY no banco. Os dois níveis são independentes e podem ser usados juntos, com significado diferente.

**Totalizadores do agrupamento:** operações Nenhum, Soma, Contagem, Média, Mín e Máx. A configuração oferece campos cujo formato é number/currency_brl/percent. Escolher Nenhum retira o item. As funções de renderização também reconhecem aliases ingleses para várias operações; conferir diferenças no capítulo de limites.

**Rodapé:** chave de exibição; Mostrar totais; totalizador por coluna; Mostrar números de página; Mostrar data/hora; Texto personalizado. Padrões e tipos completos constam no capítulo 03. Os totais se baseiam nos resultados disponíveis, não fazem uma consulta extra COUNT/SUM à base inteira.

**Geral:** orientação portrait/landscape (Retrato/Paisagem); tamanho A4/Letter/Legal; margens superior/inferior/esquerda/direita em mm, inputs number; tamanho da fonte por lista; linhas alternadas (zebra); layout de destino Responsivo/Web/Mobile. fontFamily existe no contrato e tem Arial por padrão, mas não há seletor explícito de família de fonte na aba atual.

**Preview paginado:** ReportRenderer calcula dimensão A4 210×297mm, conversão 3,78px/mm, reserva estimada para cabeçalho/rodapé e altura de linha. Divide itens de dados/grupo/subtotal por quantidade calculada, com mínimo de três itens por página. Não mede cada célula após quebra de texto. Portanto tamanho da fonte, texto extenso, imagens e papel/orientação selecionados não garantem paginação idêntica ao PDF e impressão.

O anexo de controles lista os valores min/max/step, as opções de fonte, as expressões de cada toggle e os handlers exatos. Nenhum valor é presumido a partir apenas do rótulo.

# 08 — Gráficos: configuração integral e diferença entre exemplo e dados
**CRUD local:** Adicionar Gráfico acrescenta createEmptyChart; alterar substitui por índice; remover exclui do array; mover troca posições respeitando limites. As alterações persistem apenas ao Salvar template.

**Padrões completos:** id UUID; type=bar; subType=vertical; title=''; xField=''; yFields=[]; colors=paleta padrao; palette=padrao; position=after; width=100%; showLegend=true; showDataLabels=false; showGrid=true.

**Tipos e subtipos:** Barra (vertical, horizontal, empilhado); Pizza (pizza, rosca/donut); Linhas (linha, área preenchida); Misto (barra+linha, sem subtipo obrigatório). Alterar tipo reinicia subType para o primeiro desse tipo, ou vazio no misto.

**Campos de cada gráfico:** Título; Tipo; Subtipo quando aplicável; Eixo X a partir dos campos do relatório; campos/séries Y, operação de agregação, cor; tipo de série barra/linha no misto e eixo secundário; paleta; posição antes/depois/entre; largura 100%/50%; legenda; rótulos de dados; grade.

**Série Y:** adicionar não duplica mesmo field; operação inicial direto; cor segue índice na paleta ou #3B82F6; seriesType=bar no misto; secondaryAxis=false. Remover retira da lista. Operações da UI: Valor direto, Soma, Contagem e Média. Alterar paleta redefine cores de todas as séries pela nova lista.

**Paletas e hexadecimais:** padrao, pastel, escuro e monocromatico, com oito cores cada. Todas as cores estão em catalogos-e-padroes.json e no catálogo literal incluído no relatório. Personalizar cor de série é possível; não há serviço externo de paleta.

**Prévia na aba Gráficos:** ChartPreview usa rótulos Jan/Fev/Mar/Abr/Mai/Jun e valores aleatórios gerados no navegador. É amostra de estilo, não dados consultados do relatório. Sem X ou pelo menos um Y mostra Configure o eixo X e pelo menos um campo Y para ver o preview.

**Gráfico do preview executável:** ReportRenderer recebe os resultados reais da execução (limitados e filtrados) e renderiza via Chart.js/react-chartjs-2. Agrupa por xField e calcula valores por série. Pizza usa a primeira série Y. Séries de tipo misto/eixo secundário dependem das configurações conectadas ao renderer.

**Diferença importante:** aggregateChartData trata contagem e média explicitamente e usa soma nos demais casos, inclusive quando operation=direto no caminho de agregação. Não presumir que Valor direto conserva uma linha por registro se houver categorias X repetidas.

**Posição:** before é renderizado antes; after e between entram no bloco posterior na implementação do ReportRenderer. A opção Entre, portanto, não significa inserção automática entre grupos ou linhas no desenho atual.

**Opções sem garantia visual universal:** showDataLabels existe no formulário e contrato, porém não foi identificado plugin de datalabels conectado ao renderer. Campo configurável não é prova de rótulos aparecendo. A biblioteca e os exportadores não usam todos os ajustes visuais de forma idêntica.

Esta documentação não executou consultas nem gerou gráficos de dados reais. O anexo do guia interno é informativo e não uma medição.

# 09 — Subrelatórios: resumo, SQL, colunas, operações e vínculos
**Adicionar Subrelatório:** cria id com prefixo sub_ e trecho aleatório; type=summary; title=''; columns=[]; totalizers=[]; summary_config={groupField:'',operations:[]}. Abre o cartão. Há expandir/recolher, editar título/tipo, mover e remover. Campos modificados só persistem ao salvar o modelo.

**Tipos:** summary calcula resumo da fonte principal; query executa SQL próprio. Não há vínculo automático por FK entre cada linha do relatório e subrelatório. O relacionamento entre SQLs é definido pelos parâmetros compartilhados e texto de consulta, não por uma ligação mestre-detalhe por registro.

**Resumo:** Campo de Agrupamento vem das colunas disponíveis; operações por campo são none, sum, count, avg, min e max. Opções de formatos: Nenhum, Texto, Número, Moeda (R$), Percentual (%), Data, Data/Hora. NumericColumns na configuração depende de dataType conter um dos tipos numéricos conhecidos.

**SQL:** editar sql_query e Testar Query → POST /api/reports/preview-query; resultado local com campos/linhas/erro/loading, limite padrão 50 nesse endpoint. O teste não envia os valores de filtros do preview final. No relatório final, cada query de subrelatório envia templateId e subreportId e usa a mesma coleção de filterValues; servidor verifica pertença ao template para usuário comum.

**Colunas do subrelatório:** field, label, width numérica (padrão 20), format='' e align=left. Pode adicionar/remover e configurar cada linha de coluna. Não confundir com width string do layout principal nem com sua lista de formatos. Os resultados de query possuem aliases próprios.

**Totalizadores:** field e operation por configuração, com operações inglesas. São calculados sobre as linhas do subrelatório disponível e renderizados/exportados conforme cada formato.

**Execução final:** executa consulta principal primeiro; percorre subrelatórios sequencialmente; query faz nova requisição; summary usa computeSummaryRows(result.rows). A consulta de resumo não é enviada ao PostgreSQL; groupField vazio resulta em []; grupos sem valor usam (vazio); count conta linhas; sum/avg/min/max usam valores Number finitos; média sem valores é 0; min/max sem valores também são 0.

**Limite importante no editor:** ReportBuilder mantém previewData e o passa como parentData a SubreportsTab, mas não conecta retorno de PreviewTab para atualizar esse estado com as linhas executadas. previewData é apenas reiniciado nos caminhos inspecionados. Assim, o preview resumido dentro da aba de configuração pode ficar sem dados apesar de o preview final conseguir calcular o resumo. Não documentar essa ligação como implementada.

**Ordem de filtros:** resumos são construídos a partir de result.rows antes dos filtros locais do relatório principal. Depois o resultado resumido recebe sua própria passagem por applyClientFilters. Portanto filtrar uma coluna que não existe no resumo pode eliminar linhas resumidas, e o resumo não é necessariamente a agregação das linhas visíveis finais do principal.

**Limites do servidor:** no máximo 25 subrelatórios; id não vazio; tipo query/summary; query precisa de SELECT válido; summary exige summary_config. Não se afirma uma validação profunda universal de todas as colunas, operações ou IDs duplicados de subrelatório, pois essa função não a implementa integralmente.

Não há tabela de banco separada para cada subrelatório: a definição fica no JSONB subreports do template.

# 10 — Preview executável, tabelas e estados do resultado
**Antes de executar:** sem SQL, orienta configurar Fonte de Dados; com SQL, mostra Clique em Gerar Relatório. Botão Gerar Relatório fica desabilitado com loading ou SQL vazio. Filtros aparecem antes do botão se existirem.

**Ao executar:** limpa dados anteriores, reseta erro/acesso negado/truncamento, marca loading; constrói parâmetros; POST /api/reports/execute-query com sql, params, templateId, filterValues, limit=500. Admin pode testar rascunho; usuário comum precisa de template salvo autorizado.

**Resposta principal:** rows, fields (name/dataTypeID), rowCount, limit, truncated e duration. O preview final guarda linhas e truncamento; não mostra todos esses metadados como colunas do relatório. Subrelatórios query são buscados depois, um de cada vez.

**Ao mudar filtros:** muda filterValues, executed=false, limpa erro e truncamento. Exige gerar novamente. Alterar sqlQuery, filtros ou subrelatórios limpa a execução por efeito. Alterar somente layout/gráficos pode redesenhar a visualização com o conjunto existente, pois não consta das mesmas dependências de limpeza.

**Resultados somente leitura:** a tabela da prévia SQL e a tabela final não oferecem criar/editar/excluir linhas da base, formulário inline, duplo clique de edição, seleção em lote ou modal CRUD de entidade. O CRUD do módulo pertence aos modelos, descrito no capítulo 04. Não interpretar SELECT como um cadastro universal.

**Preview SQL da fonte:** cabeçalhos vêm dos fields retornados; linhas e células são exibidas conforme QueryPreview; contador de registros e duração; loading e mensagem de erro. É uma amostra de até 50 linhas solicitadas, sem paginação de registros além da amostra na interface.

**Tabela final:** usa layout.columns visíveis, rótulos, ordem, alinhamento, largura e applyFormat. Sem colunas visíveis, não desenha automaticamente todas as chaves do objeto. Pode incluir cabeçalhos de grupo, subtotais e totais. Zebra segue a configuração. Páginas são estimadas por altura de linha; não há sort por clique no cabeçalho nem busca universal nesse resultado.

**Estados:** acesso 401/403 exibe Acesso não autorizado e estilo âmbar; outros erros em vermelho; execução sem resultados tem mensagem própria; limite alcançado mostra aviso A execução atingiu o limite de 500 linhas. Ajuste os filtros para consultar um intervalo menor. Não tratar corte como consulta completa.

**Subrelatório truncado:** o código final marca truncated a partir da resposta principal; não agrega os flags de todas as respostas de subrelatório. Uma query secundária também pode estar limitada sem produzir o mesmo aviso principal.

**Exportações disponíveis:** só depois de executed e com pelo menos uma linha no principal ou em algum subrelatório. Gráfico configurado sem linhas não satisfaz sozinho essa condição. Botões usam dados já carregados, não refazem a consulta para obter tudo.

**Formatações:** valores nulos/vazios viram texto vazio nos formatadores; moeda usa pt-BR/BRL; datas tentam Date e devolvem texto original se inválidas; CPF/CNPJ aplica máscara conforme quantidade de dígitos; percentuais e números seguem funções específicas. Consulte anexo de funções para expressões exatas, inclusive uso de parseFloat e diferenças com números localizados por vírgula.

# 11 — Impressão, PDF, Excel, Word, CSV e HTML
Todos os botões exportam o resultado atual carregado e seus subrelatórios, com diferenças por formato. Não são serviços de exportação assíncrona do servidor, nem inclusão de arquivos no banco/bucket.

| Saída | Tecnologia / extensão | O que contém | Limites / acionamento |
| --- | --- | --- | --- |
| Imprimir | HTML em nova janela + print | Cabeçalho, tabela, agrupamentos, gráficos capturados e tabelas dos gráficos, subrelatórios, rodapé | Após 500ms chama print; pop-up bloqueado retorna sem mensagem própria; depende de navegador/impressora |
| PDF | pdfmake + fontes VFS; .pdf | Documento construído com tabelas, dados de gráficos, imagens de canvas quando capturadas e subrelatórios | Download direto; usa pageSize/orientation/margens da definição e fonte Roboto; não é captura idêntica do HTML |
| Excel | ExcelJS; .xlsx | Planilha Relatório, agrupamentos/totais, resumos tabulares de gráficos e abas de subrelatórios | Não cria gráficos nativos equivalentes ao Chart.js; nomes de abas são saneados, limitados e deduplicados |
| Word | HTML com MIME application/msword; .doc | Tabelas, cabeçalho, gráficos capturados e resumos, subrelatórios, texto de rodapé | É .doc baseado em HTML, não DOCX nativo; difere da opção Formulários/Admissão |
| CSV | Texto UTF-8 BOM; .csv | Seções com tabelas de dados, gráficos agregados e subrelatórios; delimitador ; | Não contém imagem/diagrama; protege células começando com caracteres de fórmula |
| HTML | Documento .html | Conteúdo formatado e imagens de gráficos capturadas em data URLs, mais tabelas de resumo | Não mantém interatividade Chart.js; logotipo externo pode depender da URL configurada |


**Nome de arquivo:** título do cabeçalho ou relatorio, com extensão do formato. Nome cadastral do template e título do cabeçalho são campos distintos; não pressupor que o nome do modelo será usado automaticamente no download.

**Conteúdo:** data exclui gráficos; charts exclui tabela principal; both inclui ambos. Os subrelatórios são adicionados pelos caminhos próprios de exportação. Os ajustes de fonte/cor/largura/legenda não são uma garantia de fidelidade pixel a pixel entre formatos.

**Gráficos em exportações:** captureChartImages busca canvases dentro de #report-render-area em charts-before e charts-after e chama toDataURL('image/png'). Falha de captura é tratada sem incluir a imagem. Além das imagens, vários exportadores incluem tabelas agregadas dos dados dos gráficos, permitindo leitura dos números. Excel e CSV recebem a definição e os dados, não imagens de canvas.

**Excel:** cabeçalho com fundo azul e fonte branca; colunas com ajuste de largura; sheet names de subrelatório removem caracteres inválidos, limitam a 31 caracteres e recebem sufixo quando repetidos. Não representa uma exportação CRUD reimportável de cadastros.

**CSV:** aspas são duplicadas; campos são delimitados por aspas; valores de célula iniciados por =, +, -, @, tab ou CR, após espaço, recebem prefixo de apóstrofo para reduzir interpretação como fórmula. Gráficos são números agregados, não PNG. Não é uma única tabela retangular universal quando há várias seções.

**HTML e impressão:** buildFullHTML escapa textos e valores; renderiza cabeçalho e rodapé em fluxo. O helper não reproduz integralmente o mecanismo A4 paginado do ReportRenderer. Configurações de numeração de página e margens não têm exatamente o mesmo efeito em todas as saídas.

**PDF:** importa pdfmake e vfs_fonts sob demanda; defaultStyle usa Roboto e tamanho selecionado. O rodapé PDF é uma função própria, com numeração e customText, não o mesmo HTML do rodapé do preview. Marcar/ocultar show do rodapé não é tratado de maneira idêntica nesse caminho. Não houve geração real de PDF/Excel/Word nesta sessão autenticada.

Não existe envio automático das saídas por e-mail, WhatsApp, webhook, assinatura eletrônica ou integração fiscal acionado por esses botões.

# 12 — APIs, permissões, SQL somente leitura e relacionamentos
| Método / endpoint | Acesso | Entrada / saída | Função |
| --- | --- | --- | --- |
| GET /api/reports/schema/tables | Admin autenticado | {tables:[nome]} | Lista tabelas do schema public |
| GET /api/reports/schema/columns?table=... | Admin autenticado | table obrigatório; {columns:[metadados]} | Colunas em ordinal_position |
| GET /api/reports/schema/foreign-keys | Admin autenticado | {foreignKeys:[source_table,source_column,foreign_table,foreign_column]} | Sugestão de JOIN a partir do catálogo PostgreSQL |
| POST /api/reports/preview-query | Admin autenticado | {sql,params?,limit?}; rows/fields/rowCount/limit/truncated/duration | Teste de SQL; padrão 50, faixa 1–500 |
| POST /api/reports/execute-query | Autenticado; regra por perfil | {sql,params,templateId,subreportId?,filterValues,limit}; mesmo formato de resultados | Consulta principal/secundária; padrão 500, faixa 1–500 |
| GET /api/reports/templates | Autenticado | {templates:[...]} | Ativos visíveis; ordem category,name |
| GET /api/reports/templates/:id | Autenticado, com visibilidade | {template}; 404 ausente/não visível | Leitura individual |
| POST /api/reports/templates | Role ADMIN no JWT | Definição; {template}; status 200 no código | Inclusão; autoria do JWT |
| PUT /api/reports/templates/:id | Role ADMIN no JWT | Definição/atualização; {template} | Alteração de modelo ativo |
| DELETE /api/reports/templates/:id | Role ADMIN no JWT | {success:true}; 404 se inexistente | Inativação lógica |


**Não confundir com Consultas:** /api/reports/queries é outro recurso montado no projeto, ligado à opção de consultas predefinidas. A fonte/preview do construtor aqui documentado chama os endpoints acima, não depende desse serviço para executar o SQL do template.

**Acesso de usuário comum:** listagem e leitura aceitam modelo ativo quando allowed_users IS NULL AND allowed_groups IS NULL, OU allowed_users contém o ID do usuário, OU allowed_groups intersecta seus grupos. As condições são OR, não exigem que usuário e grupo estejam simultaneamente nas listas. Admin lista todos os ativos. Parâmetros de URL isAdmin/userId não definem a identidade: o servidor usa req.currentUser derivado de autenticação.

**Execução de usuário comum:** precisa informar templateId. O servidor busca template visível, escolhe sql_query armazenado ou subreport query pertencente a esse template e reconstrói parâmetros com filtros salvos. Não usa SQL arbitrário do corpo enviado pelo usuário comum. subreportId inválido/tipo incorreto retorna 403. SQL inválido no template retorna 403.

**Execução de administrador:** permite SQL somente leitura enviado no corpo, necessário ao teste do rascunho. Não é uma licença para UPDATE/DELETE; ainda passa pelo validador e transação read-only.

**Proteção SQL:** máximo de 100.000 caracteres; remove comentários para análise; admite SELECT ou WITH; somente um comando, tolerando ponto e vírgula final; bloqueia palavras INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, CREATE, GRANT, REVOKE e COPY; bloqueia SELECT INTO e locks FOR UPDATE/SHARE e variantes; bloqueia funções como nextval/setval, advisory locks, pg_sleep, leitura/escrita de arquivos e dblink previstas na expressão. É um filtro por expressões, não parser SQL semântico completo, e pode recusar palavras em literais.

**Execução efetiva:** conexão do pool → BEGIN READ ONLY → SET LOCAL statement_timeout='15s' → consulta envolvida em SELECT * FROM (...) AS _report_result LIMIT limite+1 → COMMIT → release. Em erro faz ROLLBACK e release. Retorna somente limite linhas e sinaliza truncamento se havia a extra. Isso limita linhas devolvidas, mas não torna qualquer consulta complexa barata.

**Escrita de modelos:** requireAdminRole lê userRole do JWT já verificado. POST deriva created_by de userId do JWT. Valida SQL, lista de filtros/subrelatórios e enums de layout/conteúdo. PUT usa COALESCE para vários campos, mas descrição, allowed_users e allowed_groups são atribuídos diretamente: enviar atualização parcial sem esses dados pode limpá-los. A interface normal envia objeto completo; cliente externo deve conhecer esse contrato. A validação não certifica que todo campo de gráfico/layout referencie coluna real.

**Relacionamentos persistidos:** template.id identifica a definição; allowed_users armazena IDs de usuários; allowed_groups, IDs de grupos; created_by identifica autoria. Arrays e JSONs não são tabelas normalizadas de vínculo no esquema inspecionado. Selecionar permissões não cria usuários/grupos. Usuários e grupos são carregados de config, sem publicar seus nomes/IDs reais neste pacote.

**Relacionamentos das consultas:** definidos por SQL, FKs do catálogo e parâmetros. O módulo não injeta filtro universal de unidade no SQL demonstrado: o administrador deve considerar escopo das consultas e políticas do banco; não foi auditada integralmente RLS nem concedida certificação de isolamento entre unidades.

**Integrações reais:** React; fetch same-origin; Express; PostgreSQL/information_schema; Chart.js/react-chartjs-2; pdfmake; ExcelJS; FileReader/Blob/URL; APIs de impressão e download do navegador; config.logoUrl, config.users, config.userGroups e currentUser. Não foi encontrado consumo de IA, GoTalk, DataJud, bucket ou API externa de relatórios nesse fluxo.

# 13 — Guia interno, exemplos e informações auxiliares
A aba Guia possui dez seções: Visao Geral; Fonte de Dados; Layout; Graficos; Sub-relatorios; Preview e Exportacao; Modelos de Relatorios; Tabelas do Banco; Referencia SQL; Dicas e Solucoes. Os textos usam a grafia original do componente.

O anexo GUIA_INTERNO_INTEGRAL.html foi renderizado diretamente das funções de cada seção do GuideTab, sem executar consultas. Inclui todos os textos, tabelas e exemplos SQL estáticos do guia, em uma página pesquisável. Não representa templates reais cadastrados nem inventário vivo de tabelas.

**Como usar:** consultar o guia para entender SQL/fluxos e confrontar com os capítulos de comportamento real. Algumas orientações são genéricas e podem descrever funcionalidades desejadas ou configurações com suporte parcial. Por exemplo, chamar Word de formato compatível não o torna DOCX nativo; opção Entre não implica quebra real entre agrupamentos; resumo do editor não está conectado ao previewData principal.

Os exemplos do guia não foram executados e podem precisar de adaptação ao schema, aliases, permissões e regras de unidade do ambiente. A ausência de erro na leitura de um exemplo não comprova autorização de acesso aos dados correspondentes.

Os inventários de fontes incluem hashes e linhas, mas não copiam segredos nem o servidor inteiro. O pacote não inclui dumps de banco, credenciais ou registros reais.

# 14 — Manual de utilização completo por objetivo e perfil
### A. Executar um relatório como usuário autorizado

1. Entrar no aplicativo e escolher Relatórios → Relatórios Gerais.
2. Abrir Relatórios Salvos; expandir a categoria desejada.
3. Selecionar o relatório. Se ele não aparece, não presumir falha: pode estar inativo, fora da categoria conhecida ou sem permissão para seu usuário/grupos.
4. Em tela estreita, Abrir preview. Em tela ampla, usar o painel Preview executável à direita.
5. Preencher os filtros exibidos; conferir valores padrão. Campo vazio significa Todos apenas se a consulta parametrizada tratar vazio adequadamente ou se o filtro for local.
6. Acionar Gerar Relatório e aguardar consulta principal e subrelatórios.
7. Conferir registros, valores, agrupamentos e aviso de limite. Se houve truncamento, restringir o SQL/filtros de servidor; não usar totais como se abrangessem toda a base.
8. Escolher Imprimir/PDF/Excel/Word/CSV/HTML conforme necessidade. O arquivo contém o conjunto carregado; guardar conforme a política de privacidade da organização.

### B. Criar um relatório SQL como administrador

1. Acionar Novo. Sem salvar, alterações ficam apenas no navegador.
2. Na Fonte de Dados/SQL, escrever SELECT somente leitura com aliases claros. Exemplo sintético sem dados pessoais: SELECT 'Exemplo' AS categoria, 10::numeric AS valor.
3. Executar o preview da fonte para detectar campos e conferir amostra. Esse teste não aplica automaticamente os filtros de geração.
4. Na aba Layout, definir título/subtítulo; conferir logo; ajustar rótulo, largura, alinhamento e formato de cada coluna. Formatar valor como Moeda BRL se esse for o significado.
5. Configurar agrupamento/rodapé/totais apenas quando fizerem sentido para os dados retornados.
6. Se necessário, adicionar gráficos, filtros de execução e subrelatórios; usar aliases consistentes.
7. No preview executável, preencher filtros e Gerar Relatório. Confirmar dados, formatos e limites.
8. Salvar → Nome obrigatório; descrição/categoria; layout/conteúdo; usuários e grupos permitidos. Conferir a regra OR de permissões e salvar.
9. Selecionar novamente pela árvore para conferir a definição persistida. Esse passo é orientação de uso; não foi executado com registros reais nesta entrega.

### C. Criar consulta pelo modo Visual

1. Novo → Fonte de Dados → Visual.
2. Buscar tabela e clicar para selecionar; marcar colunas necessárias. Repetir para tabelas relacionadas.
3. Conferir JOIN sugerido. Selecionar tabelas/colunas corretas; usar LEFT JOIN se a regra exige manter linhas sem correspondente. Não escolher apenas pelo nome parecido.
4. Adicionar condições WHERE; escolher operador e valor; usar IN e BETWEEN na sintaxe indicada no capítulo 06.
5. Adicionar GROUP BY/ORDER BY quando adequado. Conferir que GROUP BY e expressões agregadas obedecem às regras SQL.
6. Revisar SQL gerado e testar. A UI visual não reconstrói automaticamente qualquer SQL manual.
7. Continuar nas abas e salvar conforme fluxo B.

### D. Configurar filtro parametrizado

1. Criar consulta com token sem aspas, por exemplo WHERE (NULLIF({{status}}, '') IS NULL OR status = {{status}}).
2. Aba Filtros → Adicionar Filtro → campo/placeholder status; rótulo Status; tipo select; opções uma por linha; default opcional.
3. Gerar com uma opção e com valor vazio; confirmar semântica. O exemplo depende de existir coluna status no SQL escolhido.
4. Não declarar filtro para um nome de coluna que não está no resultado quando se pretende filtragem local.
5. Salvar o modelo completo após validar.

### E. Configurar gráfico

1. Detectar colunas pela fonte.
2. Adicionar Gráfico → título/tipo/subtipo → campo X → campos Y.
3. Definir operação e cor de cada série; em misto, tipo/eixo secundário quando necessário.
4. Escolher paleta, largura e posição. Tratar preview Jan–Jun como exemplo de aparência.
5. Gerar no preview executável para usar o conjunto consultado e conferir agregações por categoria.
6. Exportar e conferir diferenças do formato escolhido antes de distribuir.

### F. Configurar subrelatório

1. Adicionar Subrelatório e dar título.
2. Para resumo, escolher campo de agrupamento e operações; para query, definir SQL somente leitura e testar.
3. Definir colunas/rótulos/formatos/larguras/alinhamento e totalizadores próprios.
4. Compartilhar filtros via placeholders quando necessário; não presumir ligação automática por registro principal.
5. Gerar relatório final para validar; o resumo local da aba pode não ter parentData conectado.
6. Salvar.

### G. Alterar ou excluir modelo

Selecionar na árvore → alterar abas → Salvar. Para excluir, conferir o nome selecionado → Excluir → confirmar. A operação inativa; não há restaurar nessa tela. Novo ou troca de seleção podem abandonar alterações sem confirmação. Usuário comum não tem gravação.

### H. Escolher formato de saída

PDF para documento paginado gerado por pdfmake; Excel para planilhas com abas; CSV para integração textual por seções; Word para edição em arquivo .doc baseado em HTML; HTML para leitura em navegador; Imprimir para impressora/PDF nativo conforme navegador. Escolher formato não amplia o conjunto de dados além do limite carregado.

# 15 — Limitações, divergências e solução de problemas
| Situação | Explicação na implementação | Conduta no uso |
| --- | --- | --- |
| Relatório não aparece | Ativos e ACL; árvore só categorias fixas | Conferir categoria conhecida, autorização e inativação com administrador |
| Não posso editar | Edição e gravação restritas a ADMIN | Usuário comum executa somente templates autorizados |
| Salvar falha embora nome esteja preenchido | Servidor exige SQL válido e valida filtros/subrelatórios | Conferir SELECT, placeholders, enums, limites e erro mostrado |
| Filtro vazio não mostra tudo | Placeholder vazio ainda é enviado ao SQL | Escrever condição opcional no SQL; não confiar só na dica da interface |
| Filtro encontra poucos registros | Filtro local só analisa resultado limitado | Aplicar filtro no SQL e gerar novamente |
| Totais diferentes do banco completo | Totaliza somente linhas carregadas; principal pode ser truncado | Usar agregação SQL e intervalo definido |
| Amostra SQL falha com {{filtro}} | Preview da fonte não manda valores de filtros | Validar estrutura com consulta de teste apropriada e usar preview executável parametrizado |
| Visual não reproduz SQL salvo | Sem parser reverso completo para os arrays locais | Revisar SQL final; não presumir conversão automática |
| Gráfico da aba muda números sozinho | Amostra aleatória Jan–Jun | Validar dados no preview executável |
| Entre aparece depois | between é tratado no bloco after | Não considerar posição entre grupos implementada |
| Valor direto soma por categoria | Agregador usa soma para operações diferentes de média/contagem | Conferir repetição de X e SQL agregado |
| Rótulos de dados não aparecem | showDataLabels configurável, sem plugin de labels identificado no renderer | Não certificar efeito só por marcar checkbox |
| Resumo da aba fica vazio | previewData principal não é atualizado pelo PreviewTab nesse componente | Validar resumo na execução final |
| Resumo não bate com filtro local do principal | Resumo nasce de result.rows antes da filtragem local | Usar filtros SQL compartilhados e conferir campos do resumo |
| Totalizador não corresponde ao esperado | Operação, formato e valores numéricos têm caminhos de conversão próprios; renderer reconhece min/max e aliases minimo/maximo | Conferir coluna, operação, valores ausentes e formato de saída |
| Papel/orientação não mudam proporção do preview | Métricas do renderer fixas em A4 retrato | Comparar com saída PDF, que usa definição de papel/orientação |
| Título do grupo personalizado não aparece | headerTemplate é armazenado/editável, mas não foi encontrado uso dele no renderer ou exportadores atuais | O cabeçalho efetivo usa a chave de agrupamento; não presumir aplicação do modelo textual |
| Logo do template é substituído | config.logoUrl pode prevalecer nos caminhos de preview/exportação | Conferir logotipo institucional e específico |
| Word não é DOCX | Exportador cria HTML com extensão .doc | Abrir como documento compatível; não tratar como arquivo OOXML nativo |
| Download/print não abre | Bloqueio de pop-up ou comportamento de download do navegador | Permitir ação no navegador e repetir após gerar |
| Gráfico falta na exportação | Canvas não capturado ou formato não leva imagens | Conferir tabelas agregadas e tipo de saída |
| Aviso de limite não cobre subrelatório | Flag principal não agrega truncated das consultas secundárias | Restringir SQL secundário e conferir volume explicitamente |


**Campos configuráveis com uso parcial:** headerTemplate, showDataLabels, target_layout, fontFamily, pageSize, orientation, showPageNumbers e flags do rodapé devem ser avaliados no caminho de renderização/exportação, não apenas pela existência no contrato. O anexo de controles e funções mostra as expressões originais para verificar diferenças.

**Dados numéricos:** vários caminhos usam parseFloat/Number. Texto monetário com separador de milhar brasileiro pode ser interpretado de forma diferente de um numeric PostgreSQL. Preferir que SQL retorne valores numéricos, aplicando a máscara somente no layout.

**Segurança operacional:** SELECT read-only e limite não substituem regras de acesso ao conteúdo. Não foi comprovado isolamento universal por unidade nem que todo template de administrador esteja semanticamente correto. Arquivos exportados podem conter informações sensíveis na utilização real; este pacote documental não contém esses dados.

Não foram implementadas correções, criadas tarefas adicionais ou alteradas regras do sistema como parte do levantamento.

# 16 — Catálogos integrais, validação e mapa dos arquivos
**Inventários pesquisáveis:** controles (inputs, selects, textareas e botões); opções literais de seleção; estados e valores iniciais; contratos e campos; funções e acionamentos; catálogos/padrões; mensagens; chamadas HTTP; fontes com SHA-256. A enumeração é de definições de controle no código, não da quantidade de elementos renderizados em uma sessão.

**Valores dinâmicos:** nomes de tabelas/colunas vêm de information_schema; linhas vêm da consulta; usuários/grupos de config; filtros e séries repetem controles conforme configuração. O pacote informa a origem e expressão de cada um, sem inventar listas de dados pessoais ou catálogo vivo.

**Anexos técnicos:** GUIA_INTERNO_INTEGRAL.html conserva as dez seções do guia existente; CONTROLES_COMPLETOS.md relaciona todos os controles e seus handlers; CONTRATOS_COMPLETOS.md detalha campos/tipos; FUNCOES_COMPLETAS.md permite conferir a implementação exata de callbacks e funções puras, com referência de origem; PADROES_COMPLETOS.md lista os defaults e listas estáticas. São evidências técnicas, não arquivos para instalar no app.

**Validação já feita:** três testes existentes de segurança passaram; testes sintéticos de geração SQL e filtros foram executados sem banco; dados estruturados e links foram conferidos; o ZIP foi testado por CRC e hashes. VALIDACAO.txt registra o resultado final e seu alcance.

**Não verificado:** aparência autenticada, execução real de templates cadastrados, SQL contra PostgreSQL real, ACL ponta a ponta de sessão, download real de cada exportador e equivalência entre formatos em produção. O roteiro de manual descreve como o recurso deve ser acionado segundo o código, não prova que esses testes reais foram realizados.

**Arquivos para leitura:** LEIA-ME.html; DOCUMENTACAO_COMPLETA.html (autocontido); DOCUMENTACAO_COMPLETA.md; capitulos/01.md a 16.md; anexos/; inventarios/; padroes/; evidencias/; MANIFESTO_SHA256.txt.

A fonte de cada afirmação técnica é a implementação local identificada no manifesto. Alterações futuras podem mudar linhas e comportamentos; os hashes permitem reconhecer a versão de conteúdo examinada.

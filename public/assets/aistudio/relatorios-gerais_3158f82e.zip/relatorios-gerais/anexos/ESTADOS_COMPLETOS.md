# Estados e valores iniciais completos

| Componente | Estado | Inicialização | Origem |
| --- | --- | --- | --- |
| DataSourceTab.tsx | [mode, setMode] | 'sql' | components/relatorios/report-builder/DataSourceTab.tsx:139 |
| DataSourceTab.tsx | [rawSql, setRawSql] | sqlQuery | components/relatorios/report-builder/DataSourceTab.tsx:140 |
| DataSourceTab.tsx | [selectedTables, setSelectedTables] | [] | components/relatorios/report-builder/DataSourceTab.tsx:141 |
| DataSourceTab.tsx | [selectedColumns, setSelectedColumns] | [] | components/relatorios/report-builder/DataSourceTab.tsx:142 |
| DataSourceTab.tsx | [joins, setJoins] | [] | components/relatorios/report-builder/DataSourceTab.tsx:143 |
| DataSourceTab.tsx | [conditions, setConditions] | [] | components/relatorios/report-builder/DataSourceTab.tsx:144 |
| DataSourceTab.tsx | [orderBy, setOrderBy] | [] | components/relatorios/report-builder/DataSourceTab.tsx:145 |
| DataSourceTab.tsx | [groupBy, setGroupBy] | [] | components/relatorios/report-builder/DataSourceTab.tsx:146 |
| DataSourceTab.tsx | [previewRows, setPreviewRows] | [] | components/relatorios/report-builder/DataSourceTab.tsx:148 |
| DataSourceTab.tsx | [previewFields, setPreviewFields] | [] | components/relatorios/report-builder/DataSourceTab.tsx:149 |
| DataSourceTab.tsx | [previewRowCount, setPreviewRowCount] | undefined | components/relatorios/report-builder/DataSourceTab.tsx:150 |
| DataSourceTab.tsx | [previewDuration, setPreviewDuration] | undefined | components/relatorios/report-builder/DataSourceTab.tsx:151 |
| DataSourceTab.tsx | [previewLoading, setPreviewLoading] | false | components/relatorios/report-builder/DataSourceTab.tsx:152 |
| DataSourceTab.tsx | [previewError, setPreviewError] | undefined | components/relatorios/report-builder/DataSourceTab.tsx:153 |
| DataSourceTab.tsx | [history, setHistory] | [] | components/relatorios/report-builder/DataSourceTab.tsx:155 |
| DataSourceTab.tsx | [showHistory, setShowHistory] | false | components/relatorios/report-builder/DataSourceTab.tsx:156 |
| FiltersTab.tsx | [expandedId, setExpandedId] | null | components/relatorios/report-builder/FiltersTab.tsx:29 |
| GuideTab.tsx | [activeSection, setActiveSection] | 'visao_geral' | components/relatorios/report-builder/GuideTab.tsx:940 |
| JoinBuilder.tsx | [foreignKeys, setForeignKeys] | [] | components/relatorios/report-builder/JoinBuilder.tsx:26 |
| JoinBuilder.tsx | [loaded, setLoaded] | false | components/relatorios/report-builder/JoinBuilder.tsx:27 |
| LayoutTab.tsx | [open, setOpen] | defaultOpen | components/relatorios/report-builder/LayoutTab.tsx:21 |
| PreviewTab.tsx | [rawData, setRawData] | [] | components/relatorios/report-builder/PreviewTab.tsx:124 |
| PreviewTab.tsx | [rawSubreportsData, setRawSubreportsData] | [] | components/relatorios/report-builder/PreviewTab.tsx:125 |
| PreviewTab.tsx | [loading, setLoading] | false | components/relatorios/report-builder/PreviewTab.tsx:126 |
| PreviewTab.tsx | [error, setError] | null | components/relatorios/report-builder/PreviewTab.tsx:127 |
| PreviewTab.tsx | [accessDenied, setAccessDenied] | false | components/relatorios/report-builder/PreviewTab.tsx:128 |
| PreviewTab.tsx | [filterValues, setFilterValues] | {} | components/relatorios/report-builder/PreviewTab.tsx:129 |
| PreviewTab.tsx | [executed, setExecuted] | false | components/relatorios/report-builder/PreviewTab.tsx:130 |
| PreviewTab.tsx | [appliedFilterIds, setAppliedFilterIds] | new Set() | components/relatorios/report-builder/PreviewTab.tsx:131 |
| PreviewTab.tsx | [truncated, setTruncated] | false | components/relatorios/report-builder/PreviewTab.tsx:132 |
| ReportBuilder.tsx | [templates, setTemplates] | [] | components/relatorios/report-builder/ReportBuilder.tsx:31 |
| ReportBuilder.tsx | [currentTemplate, setCurrentTemplate] | createEmptyTemplate(currentUser?.id) | components/relatorios/report-builder/ReportBuilder.tsx:32 |
| ReportBuilder.tsx | [activeTab, setActiveTab] | 'datasource' | components/relatorios/report-builder/ReportBuilder.tsx:33 |
| ReportBuilder.tsx | [showSaveModal, setShowSaveModal] | false | components/relatorios/report-builder/ReportBuilder.tsx:34 |
| ReportBuilder.tsx | [loading, setLoading] | false | components/relatorios/report-builder/ReportBuilder.tsx:35 |
| ReportBuilder.tsx | [error, setError] | null | components/relatorios/report-builder/ReportBuilder.tsx:36 |
| ReportBuilder.tsx | [availableColumns, setAvailableColumns] | [] | components/relatorios/report-builder/ReportBuilder.tsx:37 |
| ReportBuilder.tsx | [previewData, setPreviewData] | [] | components/relatorios/report-builder/ReportBuilder.tsx:38 |
| ReportBuilder.tsx | [isNarrow, setIsNarrow] | () => window.innerWidth < 1200 | components/relatorios/report-builder/ReportBuilder.tsx:39 |
| ReportBuilder.tsx | [sidebarOpen, setSidebarOpen] | true | components/relatorios/report-builder/ReportBuilder.tsx:40 |
| ReportBuilder.tsx | [mobilePreviewOpen, setMobilePreviewOpen] | false | components/relatorios/report-builder/ReportBuilder.tsx:41 |
| ReportSaveModal.tsx | [name, setName] | template.name | components/relatorios/report-builder/ReportSaveModal.tsx:13 |
| ReportSaveModal.tsx | [description, setDescription] | template.description | components/relatorios/report-builder/ReportSaveModal.tsx:14 |
| ReportSaveModal.tsx | [category, setCategory] | template.category | components/relatorios/report-builder/ReportSaveModal.tsx:15 |
| ReportSaveModal.tsx | [targetLayout, setTargetLayout] | template.target_layout | components/relatorios/report-builder/ReportSaveModal.tsx:16 |
| ReportSaveModal.tsx | [contentMode, setContentMode] | template.content_mode | components/relatorios/report-builder/ReportSaveModal.tsx:17 |
| ReportSaveModal.tsx | [selectedUsers, setSelectedUsers] | template.allowed_users \|\| [] | components/relatorios/report-builder/ReportSaveModal.tsx:18 |
| ReportSaveModal.tsx | [selectedGroups, setSelectedGroups] | template.allowed_groups \|\| [] | components/relatorios/report-builder/ReportSaveModal.tsx:19 |
| ReportTree.tsx | [expandedCategories, setExpandedCategories] | () => {<br>    const init: Record<string, boolean> = {};<br>    REPORT_CATEGORIES.forEach(cat => { init[cat] = true; });<br>    return init;<br>  } | components/relatorios/report-builder/ReportTree.tsx:11 |
| SchemaExplorer.tsx | [tables, setTables] | [] | components/relatorios/report-builder/SchemaExplorer.tsx:68 |
| SchemaExplorer.tsx | [search, setSearch] | '' | components/relatorios/report-builder/SchemaExplorer.tsx:69 |
| SchemaExplorer.tsx | [tableColumns, setTableColumns] | {} | components/relatorios/report-builder/SchemaExplorer.tsx:70 |
| SchemaExplorer.tsx | [loadingTables, setLoadingTables] | false | components/relatorios/report-builder/SchemaExplorer.tsx:71 |
| SchemaExplorer.tsx | [loadingColumns, setLoadingColumns] | {} | components/relatorios/report-builder/SchemaExplorer.tsx:72 |
| SchemaExplorer.tsx | [expandedTable, setExpandedTable] | null | components/relatorios/report-builder/SchemaExplorer.tsx:73 |
| SubreportsTab.tsx | [expandedIds, setExpandedIds] | new Set() | components/relatorios/report-builder/SubreportsTab.tsx:40 |
| SubreportsTab.tsx | [queryResults, setQueryResults] | {} | components/relatorios/report-builder/SubreportsTab.tsx:41 |

# Todos os contratos e campos

| Contrato | Campo | Tipo | Opcional | Origem |
| --- | --- | --- | --- | --- |
| FilterConfig | id | string | Não | components/relatorios/report-builder/types.ts:2 |
| FilterConfig | placeholder | string | Não | components/relatorios/report-builder/types.ts:3 |
| FilterConfig | label | string | Não | components/relatorios/report-builder/types.ts:4 |
| FilterConfig | type | 'text' \| 'date' \| 'number' \| 'select' | Não | components/relatorios/report-builder/types.ts:5 |
| FilterConfig | defaultValue | string | Não | components/relatorios/report-builder/types.ts:6 |
| FilterConfig | options | string[] | Sim | components/relatorios/report-builder/types.ts:7 |
| ColumnFormat | (enumeração / união) | 'text' \| 'number' \| 'currency_brl' \| 'date' \| 'cpf_cnpj' \| 'percent' | Não | components/relatorios/report-builder/types.ts:10 |
| AggregationOp | (enumeração / união) | 'soma' \| 'contagem' \| 'media' \| 'min' \| 'max' \| 'nenhum' | Não | components/relatorios/report-builder/types.ts:11 |
| ColumnDef | field | string | Não | components/relatorios/report-builder/types.ts:14 |
| ColumnDef | label | string | Não | components/relatorios/report-builder/types.ts:15 |
| ColumnDef | width | string | Não | components/relatorios/report-builder/types.ts:16 |
| ColumnDef | align | 'left' \| 'center' \| 'right' | Não | components/relatorios/report-builder/types.ts:17 |
| ColumnDef | format | ColumnFormat | Não | components/relatorios/report-builder/types.ts:18 |
| ColumnDef | visible | boolean | Não | components/relatorios/report-builder/types.ts:19 |
| TotalizerConfig | field | string | Não | components/relatorios/report-builder/types.ts:23 |
| TotalizerConfig | operation | AggregationOp | Não | components/relatorios/report-builder/types.ts:24 |
| ReportLayout | header | {<br>    show: boolean;<br>    title: string;<br>    subtitle: string;<br>    logo: string;<br>    alignment: 'left' \| 'center' \| 'right';<br>    showDate: boolean;<br>    showLogo: boolean;<br>  } | Não | components/relatorios/report-builder/types.ts:28 |
| ReportLayout | header.show | boolean | Não | components/relatorios/report-builder/types.ts:29 |
| ReportLayout | header.title | string | Não | components/relatorios/report-builder/types.ts:30 |
| ReportLayout | header.subtitle | string | Não | components/relatorios/report-builder/types.ts:31 |
| ReportLayout | header.logo | string | Não | components/relatorios/report-builder/types.ts:32 |
| ReportLayout | header.alignment | 'left' \| 'center' \| 'right' | Não | components/relatorios/report-builder/types.ts:33 |
| ReportLayout | header.showDate | boolean | Não | components/relatorios/report-builder/types.ts:34 |
| ReportLayout | header.showLogo | boolean | Não | components/relatorios/report-builder/types.ts:35 |
| ReportLayout | columns | ColumnDef[] | Não | components/relatorios/report-builder/types.ts:37 |
| ReportLayout | grouping | {<br>    fields: string[];<br>    headerTemplate: string;<br>    showSubtotals: boolean;<br>    totalizers: TotalizerConfig[];<br>  } \| null | Não | components/relatorios/report-builder/types.ts:38 |
| ReportLayout | footer | {<br>    show: boolean;<br>    showTotals: boolean;<br>    totalizers: TotalizerConfig[];<br>    showPageNumbers: boolean;<br>    showDateTime: boolean;<br>    customText: string;<br>  } | Não | components/relatorios/report-builder/types.ts:44 |
| ReportLayout | footer.show | boolean | Não | components/relatorios/report-builder/types.ts:45 |
| ReportLayout | footer.showTotals | boolean | Não | components/relatorios/report-builder/types.ts:46 |
| ReportLayout | footer.totalizers | TotalizerConfig[] | Não | components/relatorios/report-builder/types.ts:47 |
| ReportLayout | footer.showPageNumbers | boolean | Não | components/relatorios/report-builder/types.ts:48 |
| ReportLayout | footer.showDateTime | boolean | Não | components/relatorios/report-builder/types.ts:49 |
| ReportLayout | footer.customText | string | Não | components/relatorios/report-builder/types.ts:50 |
| ReportLayout | general | {<br>    pageSize: 'A4' \| 'Letter' \| 'Legal';<br>    orientation: 'portrait' \| 'landscape';<br>    fontSize: number;<br>    fontFamily: string;<br>    zebra: boolean;<br>    margins: { top: number; bottom: number; left: number; right: number };<br>  } | Não | components/relatorios/report-builder/types.ts:52 |
| ReportLayout | general.pageSize | 'A4' \| 'Letter' \| 'Legal' | Não | components/relatorios/report-builder/types.ts:53 |
| ReportLayout | general.orientation | 'portrait' \| 'landscape' | Não | components/relatorios/report-builder/types.ts:54 |
| ReportLayout | general.fontSize | number | Não | components/relatorios/report-builder/types.ts:55 |
| ReportLayout | general.fontFamily | string | Não | components/relatorios/report-builder/types.ts:56 |
| ReportLayout | general.zebra | boolean | Não | components/relatorios/report-builder/types.ts:57 |
| ReportLayout | general.margins | { top: number; bottom: number; left: number; right: number } | Não | components/relatorios/report-builder/types.ts:58 |
| ReportLayout | general.margins.top | number | Não | components/relatorios/report-builder/types.ts:58 |
| ReportLayout | general.margins.bottom | number | Não | components/relatorios/report-builder/types.ts:58 |
| ReportLayout | general.margins.left | number | Não | components/relatorios/report-builder/types.ts:58 |
| ReportLayout | general.margins.right | number | Não | components/relatorios/report-builder/types.ts:58 |
| ChartMainType | (enumeração / união) | 'bar' \| 'pie' \| 'line' \| 'mixed' | Não | components/relatorios/report-builder/types.ts:62 |
| BarSubType | (enumeração / união) | 'vertical' \| 'horizontal' \| 'stacked' | Não | components/relatorios/report-builder/types.ts:63 |
| PieSubType | (enumeração / união) | 'pizza' \| 'donut' | Não | components/relatorios/report-builder/types.ts:64 |
| LineSubType | (enumeração / união) | 'line' \| 'area' | Não | components/relatorios/report-builder/types.ts:65 |
| YFieldOp | (enumeração / união) | 'soma' \| 'contagem' \| 'media' \| 'direto' | Não | components/relatorios/report-builder/types.ts:66 |
| YFieldConfig | field | string | Não | components/relatorios/report-builder/types.ts:69 |
| YFieldConfig | operation | YFieldOp | Não | components/relatorios/report-builder/types.ts:70 |
| YFieldConfig | color | string | Não | components/relatorios/report-builder/types.ts:71 |
| YFieldConfig | seriesType | 'bar' \| 'line' | Sim | components/relatorios/report-builder/types.ts:72 |
| YFieldConfig | secondaryAxis | boolean | Sim | components/relatorios/report-builder/types.ts:73 |
| ChartConfig | id | string | Não | components/relatorios/report-builder/types.ts:77 |
| ChartConfig | type | ChartMainType | Não | components/relatorios/report-builder/types.ts:78 |
| ChartConfig | subType | string | Não | components/relatorios/report-builder/types.ts:79 |
| ChartConfig | title | string | Não | components/relatorios/report-builder/types.ts:80 |
| ChartConfig | xField | string | Não | components/relatorios/report-builder/types.ts:81 |
| ChartConfig | yFields | YFieldConfig[] | Não | components/relatorios/report-builder/types.ts:82 |
| ChartConfig | colors | string[] | Não | components/relatorios/report-builder/types.ts:83 |
| ChartConfig | palette | string | Não | components/relatorios/report-builder/types.ts:84 |
| ChartConfig | position | 'before' \| 'after' \| 'between' | Não | components/relatorios/report-builder/types.ts:85 |
| ChartConfig | width | '100%' \| '50%' | Não | components/relatorios/report-builder/types.ts:86 |
| ChartConfig | showLegend | boolean | Não | components/relatorios/report-builder/types.ts:87 |
| ChartConfig | showDataLabels | boolean | Não | components/relatorios/report-builder/types.ts:88 |
| ChartConfig | showGrid | boolean | Não | components/relatorios/report-builder/types.ts:89 |
| SubreportColumnConfig | field | string | Não | components/relatorios/report-builder/types.ts:93 |
| SubreportColumnConfig | label | string | Não | components/relatorios/report-builder/types.ts:94 |
| SubreportColumnConfig | width | number | Não | components/relatorios/report-builder/types.ts:95 |
| SubreportColumnConfig | format | string | Não | components/relatorios/report-builder/types.ts:96 |
| SubreportColumnConfig | align | string | Não | components/relatorios/report-builder/types.ts:97 |
| SubreportTotalizer | field | string | Não | components/relatorios/report-builder/types.ts:101 |
| SubreportTotalizer | operation | string | Não | components/relatorios/report-builder/types.ts:102 |
| SubreportSummaryConfig | groupField | string | Não | components/relatorios/report-builder/types.ts:106 |
| SubreportSummaryConfig | operations | { field: string; op: string }[] | Não | components/relatorios/report-builder/types.ts:107 |
| SubreportConfig | id | string | Não | components/relatorios/report-builder/types.ts:111 |
| SubreportConfig | type | 'summary' \| 'query' | Não | components/relatorios/report-builder/types.ts:112 |
| SubreportConfig | title | string | Não | components/relatorios/report-builder/types.ts:113 |
| SubreportConfig | sql_query | string | Sim | components/relatorios/report-builder/types.ts:114 |
| SubreportConfig | summary_config | SubreportSummaryConfig | Sim | components/relatorios/report-builder/types.ts:115 |
| SubreportConfig | columns | SubreportColumnConfig[] | Não | components/relatorios/report-builder/types.ts:116 |
| SubreportConfig | totalizers | SubreportTotalizer[] | Não | components/relatorios/report-builder/types.ts:117 |
| ReportTemplate | id | string | Não | components/relatorios/report-builder/types.ts:121 |
| ReportTemplate | name | string | Não | components/relatorios/report-builder/types.ts:122 |
| ReportTemplate | description | string | Não | components/relatorios/report-builder/types.ts:123 |
| ReportTemplate | category | string | Não | components/relatorios/report-builder/types.ts:124 |
| ReportTemplate | target_layout | 'responsive' \| 'web' \| 'mobile' | Não | components/relatorios/report-builder/types.ts:125 |
| ReportTemplate | content_mode | 'data' \| 'charts' \| 'both' | Não | components/relatorios/report-builder/types.ts:126 |
| ReportTemplate | sql_query | string | Não | components/relatorios/report-builder/types.ts:127 |
| ReportTemplate | layout | ReportLayout | Não | components/relatorios/report-builder/types.ts:128 |
| ReportTemplate | filters | FilterConfig[] | Não | components/relatorios/report-builder/types.ts:129 |
| ReportTemplate | subreports | SubreportConfig[] | Não | components/relatorios/report-builder/types.ts:130 |
| ReportTemplate | charts | ChartConfig[] | Não | components/relatorios/report-builder/types.ts:131 |
| ReportTemplate | allowed_users | string[] \| null | Não | components/relatorios/report-builder/types.ts:132 |
| ReportTemplate | allowed_groups | string[] \| null | Não | components/relatorios/report-builder/types.ts:133 |
| ReportTemplate | created_by | string \| null | Não | components/relatorios/report-builder/types.ts:134 |
| ReportTemplate | created_at | string | Não | components/relatorios/report-builder/types.ts:135 |
| ReportTemplate | updated_at | string | Não | components/relatorios/report-builder/types.ts:136 |
| ReportTemplate | is_active | boolean | Não | components/relatorios/report-builder/types.ts:137 |

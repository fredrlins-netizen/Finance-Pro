# Funções e acionamentos completos

Implementação extraída somente dos componentes do construtor. Nenhuma destas funções foi acionada com dados reais para preparar este pacote. As expressões e corpos são evidência técnica complementar ao manual.

## ChartConfig.tsx / update

Origem: components/relatorios/report-builder/ChartConfig.tsx:60

Parâmetros: partial: Partial<ChartConfigType>

```typescript
onChange({ ...chart, ...partial })
```

## ChartConfig.tsx / handleTypeChange

Origem: components/relatorios/report-builder/ChartConfig.tsx:62

Parâmetros: type: ChartMainType

```typescript
{
    const subtypes = SUBTYPES[type];
    update({ type, subType: subtypes.length > 0 ? subtypes[0].value : '' });
  }
```

## ChartConfig.tsx / addYField

Origem: components/relatorios/report-builder/ChartConfig.tsx:67

Parâmetros: field: string

```typescript
{
    if (chart.yFields.some((y) => y.field === field)) return;
    const colorIdx = chart.yFields.length;
    const color = chart.colors[colorIdx % chart.colors.length] || '#3B82F6';
    const newField: YFieldConfig = {
      field,
      operation: 'direto',
      color,
      seriesType: chart.type === 'mixed' ? 'bar' : undefined,
      secondaryAxis: false,
    };
    update({ yFields: [...chart.yFields, newField] });
  }
```

## ChartConfig.tsx / removeYField

Origem: components/relatorios/report-builder/ChartConfig.tsx:81

Parâmetros: idx: number

```typescript
{
    update({ yFields: chart.yFields.filter((_, i) => i !== idx) });
  }
```

## ChartConfig.tsx / updateYField

Origem: components/relatorios/report-builder/ChartConfig.tsx:85

Parâmetros: idx: number, partial: Partial<YFieldConfig>

```typescript
{
    const yFields = chart.yFields.map((y, i) => (i === idx ? { ...y, ...partial } : y));
    update({ yFields });
  }
```

## ChartConfig.tsx / handlePaletteChange

Origem: components/relatorios/report-builder/ChartConfig.tsx:90

Parâmetros: palette: string

```typescript
{
    const colors = COLOR_PALETTES[palette] || COLOR_PALETTES.padrao;
    const yFields = chart.yFields.map((y, i) => ({ ...y, color: colors[i % colors.length] }));
    update({ palette, colors, yFields });
  }
```

## ChartPreview.tsx / generateData

Origem: components/relatorios/report-builder/ChartPreview.tsx:35

Parâmetros: seed: number

```typescript
sampleLabels.map((_, i) => Math.round(Math.random() * 100 + seed * 20 + i * 10))
```

## ChartPreview.tsx / getColor

Origem: components/relatorios/report-builder/ChartPreview.tsx:38

Parâmetros: index: number

```typescript
{
    return chart.yFields[index]?.color || chart.colors[index % chart.colors.length] || '#3B82F6';
  }
```

## ChartsTab.tsx / addChart

Origem: components/relatorios/report-builder/ChartsTab.tsx:12

Parâmetros: 

```typescript
{
    onChartsChange([...charts, createEmptyChart()]);
  }
```

## ChartsTab.tsx / updateChart

Origem: components/relatorios/report-builder/ChartsTab.tsx:16

Parâmetros: index: number, chart: ChartConfig

```typescript
{
    const next = charts.map((c, i) => (i === index ? chart : c));
    onChartsChange(next);
  }
```

## ChartsTab.tsx / removeChart

Origem: components/relatorios/report-builder/ChartsTab.tsx:21

Parâmetros: index: number

```typescript
{
    onChartsChange(charts.filter((_, i) => i !== index));
  }
```

## ChartsTab.tsx / moveChart

Origem: components/relatorios/report-builder/ChartsTab.tsx:25

Parâmetros: index: number, direction: -1 | 1

```typescript
{
    const target = index + direction;
    if (target < 0 || target >= charts.length) return;
    const next = [...charts];
    [next[index], next[target]] = [next[target], next[index]];
    onChartsChange(next);
  }
```

## ColumnConfig.tsx / updateColumn

Origem: components/relatorios/report-builder/ColumnConfig.tsx:10

Parâmetros: index: number, updates: Partial<ColumnDef>

```typescript
{
    const next = columns.map((c, i) => (i === index ? { ...c, ...updates } : c));
    onChange(next);
  }
```

## ColumnConfig.tsx / moveColumn

Origem: components/relatorios/report-builder/ColumnConfig.tsx:15

Parâmetros: index: number, direction: -1 | 1

```typescript
{
    const target = index + direction;
    if (target < 0 || target >= columns.length) return;
    const next = [...columns];
    [next[index], next[target]] = [next[target], next[index]];
    onChange(next);
  }
```

## DataSourceTab.tsx / quoteIdentifier

Origem: components/relatorios/report-builder/DataSourceTab.tsx:31

Parâmetros: value: string

```typescript
{
  if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(value)) return null;
  return `"${value}"`;
}
```

## DataSourceTab.tsx / quoteField

Origem: components/relatorios/report-builder/DataSourceTab.tsx:36

Parâmetros: value: string

```typescript
{
  const parts = value.split('.');
  if (parts.length !== 2) return null;
  const table = quoteIdentifier(parts[0]);
  const column = quoteIdentifier(parts[1]);
  return table && column ? `${table}.${column}` : null;
}
```

## DataSourceTab.tsx / sqlLiteral

Origem: components/relatorios/report-builder/DataSourceTab.tsx:44

Parâmetros: value: string

```typescript
`'${value.replace(/'/g, "''")}'`
```

## DataSourceTab.tsx / generateSql

Origem: components/relatorios/report-builder/DataSourceTab.tsx:46

Parâmetros: selectedTables: string[], selectedColumns: SelectedColumn[], joins: JoinConfig[], conditions: WhereCondition[], orderBy: string[], groupBy: string[]

```typescript
{
  if (selectedTables.length === 0 || selectedColumns.length === 0) return '';

  const selectFields = selectedColumns.map((c) => {
    const field = quoteField(`${c.table}.${c.column}`);
    const alias = quoteIdentifier(`${c.table}__${c.column}`);
    return field && alias ? `${field} AS ${alias}` : null;
  });
  if (selectFields.some(field => !field)) return '';

  const baseTable = quoteIdentifier(selectedTables[0]);
  if (!baseTable) return '';
  let fromClause = baseTable;
  for (const join of joins) {
    if (join.leftColumn && join.rightColumn) {
      const left = quoteField(`${join.leftTable}.${join.leftColumn}`);
      const right = quoteField(`${join.rightTable}.${join.rightColumn}`);
      const rightTable = quoteIdentifier(join.rightTable);
      const joinType = ['INNER JOIN', 'LEFT JOIN', 'RIGHT JOIN', 'FULL JOIN'].includes(join.joinType) ? join.joinType : null;
      if (!joinType || !rightTable || !left || !right || !selectedTables.includes(join.leftTable) || !selectedTables.includes(join.rightTable)) return '';
      fromClause += `\n${joinType} ${rightTable} ON ${left} = ${right}`;
    }
  }

  let sql = `SELECT\n  ${selectFields.join(',\n  ')}\nFROM ${fromClause}`;

  if (conditions.length > 0) {
    const whereParts: string[] = [];
    for (const cond of conditions) {
      if (!cond.field) return '';
      const field = quoteField(cond.field);
      const fieldTable = cond.field.split('.')[0];
      if (!field || !selectedTables.includes(fieldTable)) return '';
      const operator = String(cond.operator || '').toUpperCase();
      const value = String(cond.value ?? '').trim();
      const allowedOperators = ['=', '!=', '<>', '>', '>=', '<', '<=', 'LIKE', 'ILIKE', 'IN', 'BETWEEN', 'IS NULL', 'IS NOT NULL'];
      if (!allowedOperators.includes(operator)) return '';
      let clause: string;
      if (operator === 'IS NULL' || operator === 'IS NOT NULL') {
        clause = `${field} ${operator}`;
      } else if (value.includes('{{') || value.includes('}}')) {
        const isToken = (part: string) => /^\{\{[A-Za-z_][A-Za-z0-9_]*\}\}$/.test(part.trim());
        if (operator === 'IN') {
          const tokens = value.split(',').map(token => token.trim());
          if (tokens.length === 0 || tokens.some(token => !isToken(token))) return '';
          clause = `${field} IN (${tokens.join(', ')})`;
        } else if (operator === 'BETWEEN') {
          const tokens = value.split(/\s+AND\s+/i).map(token => token.trim());
          if (tokens.length !== 2 || tokens.some(token => !isToken(token))) return '';
          clause = `${field} BETWEEN ${tokens[0]} AND ${tokens[1]}`;
        } else {
          if (!isToken(value)) return '';
          clause = `${field} ${operator} ${value}`;
        }
      } else if (operator === 'IN') {
        const values = value.split(',').map(item => item.trim()).filter(Boolean);
        if (values.length === 0) return '';
        clause = `${field} IN (${values.map(sqlLiteral).join(', ')})`;
      } else if (operator === 'BETWEEN') {
        const values = value.split(',').map(item => item.trim());
        if (values.length !== 2 || values.some(value => !value)) return '';
        clause = `${field} BETWEEN ${sqlLiteral(values[0])} AND ${sqlLiteral(values[1])}`;
      } else {
        clause = `${field} ${operator} ${sqlLiteral(value)}`;
      }
      const connector = whereParts.length > 0 && ['AND', 'OR'].includes(cond.connector) ? ` ${cond.connector} ` : '';
      whereParts.push(`${connector}${clause}`);
    }
    if (whereParts.length > 0) sql += `\nWHERE ${whereParts.join('')}`;
  }

  if (groupBy.length > 0) {
    const fields = groupBy.map(quoteField);
    if (fields.some(field => !field)) return '';
    sql += `\nGROUP BY ${fields.join(', ')}`;
  }
  if (orderBy.length > 0) {
    const fields = orderBy.map(quoteField);
    if (fields.some(field => !field)) return '';
    sql += `\nORDER BY ${fields.join(', ')}`;
  }

  return sql;
}
```

## DataSourceTab.tsx / isToken

Origem: components/relatorios/report-builder/DataSourceTab.tsx:94

Parâmetros: part: string

```typescript
/^\{\{[A-Za-z_][A-Za-z0-9_]*\}\}$/.test(part.trim())
```

## DataSourceTab.tsx / handleSelectTable

Origem: components/relatorios/report-builder/DataSourceTab.tsx:178

Parâmetros: table: string

```typescript
{
    setSelectedTables((prev) => (prev.includes(table) ? prev : [...prev, table]));
  }
```

## DataSourceTab.tsx / handleDeselectTable

Origem: components/relatorios/report-builder/DataSourceTab.tsx:182

Parâmetros: table: string

```typescript
{
    setSelectedTables((prev) => prev.filter((t) => t !== table));
    setSelectedColumns((prev) => prev.filter((c) => c.table !== table));
    setJoins((prev) => prev.filter((j) => j.leftTable !== table && j.rightTable !== table));
  }
```

## DataSourceTab.tsx / handleToggleColumn

Origem: components/relatorios/report-builder/DataSourceTab.tsx:188

Parâmetros: table: string, column: string, type: string

```typescript
{
    setSelectedColumns((prev) => {
      const exists = prev.some((c) => c.table === table && c.column === column);
      if (exists) return prev.filter((c) => !(c.table === table && c.column === column));
      return [...prev, { table, column, type }];
    });
  }
```

## DataSourceTab.tsx / handleSqlBlur

Origem: components/relatorios/report-builder/DataSourceTab.tsx:196

Parâmetros: 

```typescript
{
    if (mode === 'sql') onSqlChange(rawSql);
  }
```

## DataSourceTab.tsx / executePreview

Origem: components/relatorios/report-builder/DataSourceTab.tsx:200

Parâmetros: 

```typescript
{
    const sql = mode === 'sql' ? rawSql : generateSql(selectedTables, selectedColumns, joins, conditions, orderBy, groupBy);
    if (!sql.trim()) return;
    onSqlChange(sql);
    setRawSql(sql);

    setPreviewLoading(true);
    setPreviewError(undefined);

    const entry: HistoryEntry = { sql, timestamp: Date.now() };
    setHistory((prev) => [entry, ...prev.filter((h) => h.sql !== sql)].slice(0, 10));

    try {
      const res = await fetch('/api/reports/preview-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql, limit: 50 }),
      });
      const data = await res.json();
      if (!res.ok) {
        setPreviewError(data.error || 'Erro ao executar consulta');
        setPreviewRows([]);
        setPreviewFields([]);
        setPreviewDuration(data.duration);
      } else {
        setPreviewRows(data.rows || []);
        setPreviewFields(data.fields || []);
        setPreviewRowCount(data.rowCount);
        setPreviewDuration(data.duration);
      }
    } catch (err) {
      setPreviewError('Erro de conexão com o servidor');
    } finally {
      setPreviewLoading(false);
    }
  }
```

## DataSourceTab.tsx / loadFromHistory

Origem: components/relatorios/report-builder/DataSourceTab.tsx:237

Parâmetros: entry: HistoryEntry

```typescript
{
    setRawSql(entry.sql);
    onSqlChange(entry.sql);
    setShowHistory(false);
  }
```

## DataSourceTab.tsx / handleAddOrderBy

Origem: components/relatorios/report-builder/DataSourceTab.tsx:243

Parâmetros: 

```typescript
{
    if (selectedColumns.length === 0) return;
    const first = `${selectedColumns[0].table}.${selectedColumns[0].column}`;
    setOrderBy((prev) => [...prev, first]);
  }
```

## DataSourceTab.tsx / handleAddGroupBy

Origem: components/relatorios/report-builder/DataSourceTab.tsx:249

Parâmetros: 

```typescript
{
    if (selectedColumns.length === 0) return;
    const first = `${selectedColumns[0].table}.${selectedColumns[0].column}`;
    setGroupBy((prev) => [...prev, first]);
  }
```

## FiltersTab.tsx / createEmptyFilter

Origem: components/relatorios/report-builder/FiltersTab.tsx:17

Parâmetros: columns: { name: string }[]

```typescript
{
  return {
    id: crypto.randomUUID(),
    placeholder: columns[0]?.name || 'campo',
    label: '',
    type: 'text',
    defaultValue: '',
    options: [],
  };
}
```

## FiltersTab.tsx / addFilter

Origem: components/relatorios/report-builder/FiltersTab.tsx:31

Parâmetros: 

```typescript
{
    const f = createEmptyFilter(availableColumns);
    onFiltersChange([...filters, f]);
    setExpandedId(f.id);
  }
```

## FiltersTab.tsx / updateFilter

Origem: components/relatorios/report-builder/FiltersTab.tsx:37

Parâmetros: id: string, patch: Partial<FilterConfig>

```typescript
{
    onFiltersChange(filters.map(f => f.id === id ? { ...f, ...patch } : f));
  }
```

## FiltersTab.tsx / removeFilter

Origem: components/relatorios/report-builder/FiltersTab.tsx:41

Parâmetros: id: string

```typescript
{
    onFiltersChange(filters.filter(f => f.id !== id));
    if (expandedId === id) setExpandedId(null);
  }
```

## FiltersTab.tsx / moveFilter

Origem: components/relatorios/report-builder/FiltersTab.tsx:46

Parâmetros: index: number, dir: -1 | 1

```typescript
{
    const target = index + dir;
    if (target < 0 || target >= filters.length) return;
    const next = [...filters];
    [next[index], next[target]] = [next[target], next[index]];
    onFiltersChange(next);
  }
```

## GroupConfig.tsx / ensureGrouping

Origem: components/relatorios/report-builder/GroupConfig.tsx:19

Parâmetros: 

```typescript
{
    if (!grouping) {
      return { fields: [], headerTemplate: '', showSubtotals: false, totalizers: [] };
    }
    return grouping;
  }
```

## GroupConfig.tsx / toggleGroupField

Origem: components/relatorios/report-builder/GroupConfig.tsx:26

Parâmetros: field: string

```typescript
{
    const g = ensureGrouping();
    const fields = g.fields.includes(field)
      ? g.fields.filter((f) => f !== field)
      : [...g.fields, field];
    onChange(fields.length === 0 && !g.showSubtotals && g.totalizers.length === 0 ? null : { ...g, fields });
  }
```

## GroupConfig.tsx / updateHeaderTemplate

Origem: components/relatorios/report-builder/GroupConfig.tsx:34

Parâmetros: headerTemplate: string

```typescript
{
    const g = ensureGrouping();
    onChange({ ...g, headerTemplate });
  }
```

## GroupConfig.tsx / updateSubtotals

Origem: components/relatorios/report-builder/GroupConfig.tsx:39

Parâmetros: showSubtotals: boolean

```typescript
{
    const g = ensureGrouping();
    onChange({ ...g, showSubtotals });
  }
```

## GroupConfig.tsx / updateTotalizer

Origem: components/relatorios/report-builder/GroupConfig.tsx:44

Parâmetros: field: string, operation: AggregationOp

```typescript
{
    const g = ensureGrouping();
    let totalizers = [...g.totalizers];
    const idx = totalizers.findIndex((t) => t.field === field);
    if (operation === 'nenhum') {
      totalizers = totalizers.filter((t) => t.field !== field);
    } else if (idx >= 0) {
      totalizers[idx] = { field, operation };
    } else {
      totalizers.push({ field, operation });
    }
    onChange({ ...g, totalizers });
  }
```

## GroupConfig.tsx / getTotalizerOp

Origem: components/relatorios/report-builder/GroupConfig.tsx:58

Parâmetros: field: string

```typescript
{
    return grouping?.totalizers.find((t) => t.field === field)?.operation || 'nenhum';
  }
```

## GuideTab.tsx / renderSection

Origem: components/relatorios/report-builder/GuideTab.tsx:942

Parâmetros: 

```typescript
{
    switch (activeSection) {
      case 'visao_geral': return <VisaoGeral />;
      case 'fonte_dados': return <FonteDados />;
      case 'layout': return <LayoutSection />;
      case 'graficos': return <GraficosSection />;
      case 'subreports': return <SubreportsSection />;
      case 'preview': return <PreviewSection />;
      case 'modelos': return <ModelosSection />;
      case 'tabelas': return <TabelasSection />;
      case 'sql_ref': return <SqlRefSection />;
      case 'dicas': return <DicasSection />;
      default: return null;
    }
  }
```

## HeaderFooterConfig.tsx / handleLogoFile

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:12

Parâmetros: e: React.ChangeEvent<HTMLInputElement>

```typescript
{
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      onChange({ ...header, logo: reader.result as string, showLogo: true });
    };
    reader.readAsDataURL(file);
  }
```

## HeaderFooterConfig.tsx / updateTotalizer

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:101

Parâmetros: field: string, operation: AggregationOp

```typescript
{
    let totalizers = [...footer.totalizers];
    const idx = totalizers.findIndex((t) => t.field === field);
    if (operation === 'nenhum') {
      totalizers = totalizers.filter((t) => t.field !== field);
    } else if (idx >= 0) {
      totalizers[idx] = { field, operation };
    } else {
      totalizers.push({ field, operation });
    }
    onChange({ ...footer, totalizers });
  }
```

## HeaderFooterConfig.tsx / getTotalizerOp

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:114

Parâmetros: field: string

```typescript
{
    return footer.totalizers.find((t: TotalizerConfig) => t.field === field)?.operation || 'nenhum';
  }
```

## JoinBuilder.tsx / updateJoin

Origem: components/relatorios/report-builder/JoinBuilder.tsx:81

Parâmetros: id: string, field: keyof JoinConfig, value: string

```typescript
{
    onJoinsChange(joins.map((j) => (j.id === id ? { ...j, [field]: value } : j)));
  }
```

## JoinBuilder.tsx / removeJoin

Origem: components/relatorios/report-builder/JoinBuilder.tsx:85

Parâmetros: id: string

```typescript
{
    onJoinsChange(joins.filter((j) => j.id !== id));
  }
```

## JoinBuilder.tsx / addJoin

Origem: components/relatorios/report-builder/JoinBuilder.tsx:89

Parâmetros: 

```typescript
{
    onJoinsChange([
      ...joins,
      {
        id: crypto.randomUUID(),
        leftTable: selectedTables[0] || '',
        leftColumn: '',
        joinType: 'INNER JOIN',
        rightTable: selectedTables[1] || '',
        rightColumn: '',
      },
    ]);
  }
```

## LayoutTab.tsx / updateHeader

Origem: components/relatorios/report-builder/LayoutTab.tsx:51

Parâmetros: header: ReportLayout['header']

```typescript
onLayoutChange({ ...layout, header })
```

## LayoutTab.tsx / updateColumns

Origem: components/relatorios/report-builder/LayoutTab.tsx:52

Parâmetros: cols: ColumnDef[]

```typescript
onLayoutChange({ ...layout, columns: cols })
```

## LayoutTab.tsx / updateGrouping

Origem: components/relatorios/report-builder/LayoutTab.tsx:53

Parâmetros: grouping: ReportLayout['grouping']

```typescript
onLayoutChange({ ...layout, grouping })
```

## LayoutTab.tsx / updateFooter

Origem: components/relatorios/report-builder/LayoutTab.tsx:54

Parâmetros: footer: ReportLayout['footer']

```typescript
onLayoutChange({ ...layout, footer })
```

## LayoutTab.tsx / updateGeneral

Origem: components/relatorios/report-builder/LayoutTab.tsx:55

Parâmetros: general: ReportLayout['general']

```typescript
onLayoutChange({ ...layout, general })
```

## PreviewTab.tsx / buildParameterizedQuery

Origem: components/relatorios/report-builder/PreviewTab.tsx:18

Parâmetros: sql: string, filters: FilterConfig[], filterValues: Record<string, string>

```typescript
{
  const params: string[] = [];
  const appliedFilterIds = new Set<string>();
  let paramIndex = 1;
  let processedSql = sql;

  for (const f of filters) {
    const val = filterValues[f.id] !== undefined ? filterValues[f.id] : (f.defaultValue || '');
    const escapedName = f.placeholder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const doubleBrace = new RegExp('\\{\\{' + escapedName + '\\}\\}', 'g');
    const colonStyle = new RegExp(':' + escapedName + '\\b', 'g');

    const matchesBrace = doubleBrace.test(processedSql);
    doubleBrace.lastIndex = 0;
    const matchesColon = !matchesBrace && colonStyle.test(processedSql);
    colonStyle.lastIndex = 0;

    if (matchesBrace) {
      const token = `$${paramIndex}`;
      processedSql = processedSql.replace(doubleBrace, () => token);
      params.push(val);
      appliedFilterIds.add(f.id);
      paramIndex++;
    } else if (matchesColon) {
      const token = `$${paramIndex}`;
      processedSql = processedSql.replace(colonStyle, () => token);
      params.push(val);
      appliedFilterIds.add(f.id);
      paramIndex++;
    }
  }

  return { sql: processedSql, params, appliedFilterIds };
}
```

## PreviewTab.tsx / applyClientFilters

Origem: components/relatorios/report-builder/PreviewTab.tsx:53

Parâmetros: data: any[], filters: FilterConfig[], filterValues: Record<string, string>, appliedFilterIds = new Set<string>()

```typescript
{
  if (filters.length === 0) return data;
  return data.filter(row => {
    for (const f of filters) {
      if (appliedFilterIds.has(f.id)) continue;
      const val = filterValues[f.id] !== undefined ? filterValues[f.id] : (f.defaultValue || '');
      if (val === '' || val === null || val === undefined) continue;

      const rawCell = row[f.placeholder];
      const cellStr = rawCell != null ? String(rawCell) : '';

      if (f.type === 'text') {
        if (!cellStr.toLowerCase().includes(val.toLowerCase())) return false;
      } else if (f.type === 'select') {
        if (cellStr !== val) return false;
      } else if (f.type === 'date') {
        const cellDate = cellStr.slice(0, 10);
        if (cellDate !== val) return false;
      } else if (f.type === 'number') {
        const num = parseFloat(String(rawCell ?? ''));
        if (isNaN(num) || num !== parseFloat(val)) return false;
      }
    }
    return true;
  });
}
```

## PreviewTab.tsx / computeSummaryRows

Origem: components/relatorios/report-builder/PreviewTab.tsx:80

Parâmetros: data: any[], config: SubreportConfig

```typescript
{
  const summary = config.summary_config;
  if (!summary?.groupField) return [];
  const groups = new Map<string, any[]>();
  for (const row of data) {
    const key = String(row[summary.groupField] ?? '(vazio)');
    groups.set(key, [...(groups.get(key) || []), row]);
  }
  return Array.from(groups, ([key, rows]) => {
    const result: Record<string, unknown> = { [summary.groupField]: key };
    for (const { field, op } of summary.operations || []) {
      if (op === 'none') continue;
      if (op === 'count') {
        result[field] = rows.length;
        continue;
      }
      const values = rows.map(row => Number(row[field])).filter(Number.isFinite);
      if (op === 'sum') result[field] = values.reduce((sum, value) => sum + value, 0);
      else if (op === 'avg') result[field] = values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : 0;
      else if (op === 'min') result[field] = values.length ? Math.min(...values) : 0;
      else if (op === 'max') result[field] = values.length ? Math.max(...values) : 0;
    }
    return result;
  });
}
```

## PreviewTab.tsx / captureChartImages

Origem: components/relatorios/report-builder/PreviewTab.tsx:106

Parâmetros: charts: ChartConfig[]

```typescript
{
  const rendered = [
    ...charts.filter(chart => chart.position === 'before'),
    ...charts.filter(chart => chart.position !== 'before'),
  ];
  const canvases = Array.from(document.querySelectorAll<HTMLCanvasElement>(
    '#report-render-area #charts-before canvas, #report-render-area #charts-after canvas',
  ));
  return rendered.flatMap((chart, index) => {
    try {
      return canvases[index] ? [{ title: chart.title || 'Gráfico', position: chart.position, src: canvases[index].toDataURL('image/png') }] : [];
    } catch {
      return [];
    }
  });
}
```

## PreviewTab.tsx / handleFilterChange

Origem: components/relatorios/report-builder/PreviewTab.tsx:142

Parâmetros: id: string, value: string

```typescript
{
    setFilterValues(prev => ({ ...prev, [id]: value }));
    setExecuted(false);
    setError(null);
    setTruncated(false);
  }
```

## PreviewTab.tsx / executeQuery

Origem: components/relatorios/report-builder/PreviewTab.tsx:158

Parâmetros: 

```typescript
{
    if (!sqlQuery.trim()) {
      setError('Nenhuma consulta SQL definida.');
      return;
    }
    setLoading(true);
    setExecuted(false);
    setRawData([]);
    setRawSubreportsData([]);
    setError(null);
    setAccessDenied(false);
    setTruncated(false);
    try {
      const { sql, params, appliedFilterIds: applied } = buildParameterizedQuery(sqlQuery, filters, filterValues);

      const res = await fetch('/api/reports/execute-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        // filterValues é usado pelo servidor (não-admins) para reconstruir a query
        // a partir do SQL armazenado no template; sql/params servem ao preview admin.
        body: JSON.stringify({ sql, params, templateId, filterValues, limit: 500 }),
      });
      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw Object.assign(new Error(errData.error || 'Erro ao executar consulta'), { status: res.status });
      }
      const result = await res.json();
      setRawData(result.rows || []);
      setAppliedFilterIds(applied);
      setTruncated(!!result.truncated);

      const srResults: { config: SubreportConfig; data: any[]; appliedFilterIds: Set<string> }[] = [];
      for (const sr of subreports) {
        if (sr.type === 'query' && sr.sql_query) {
          const srQuery = buildParameterizedQuery(sr.sql_query, filters, filterValues);
          const srRes = await fetch('/api/reports/execute-query', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ sql: srQuery.sql, params: srQuery.params, templateId, subreportId: sr.id, filterValues, limit: 500 }),
          });
          const srResult = await srRes.json().catch(() => ({}));
          if (!srRes.ok) throw Object.assign(new Error(srResult.error || `Erro ao executar o subrelatório "${sr.title}".`), { status: srRes.status });
          srResults.push({ config: sr, data: srResult.rows || [], appliedFilterIds: srQuery.appliedFilterIds });
        } else if (sr.type === 'summary') {
          srResults.push({ config: sr, data: computeSummaryRows(result.rows || [], sr), appliedFilterIds: applied });
        }
      }
      setRawSubreportsData(srResults);
      setExecuted(true);
    } catch (err: any) {
      setError(err.message || 'Erro desconhecido');
      setAccessDenied(err.status === 401 || err.status === 403);
    } finally {
      setLoading(false);
    }
  }
```

## QueryPreview.tsx / formatValue

Origem: components/relatorios/report-builder/QueryPreview.tsx:59

Parâmetros: val: unknown

```typescript
{
    if (val === null || val === undefined) return 'NULL';
    if (typeof val === 'object') return JSON.stringify(val);
    return String(val);
  }
```

## ReportBuilder.tsx / handleResize

Origem: components/relatorios/report-builder/ReportBuilder.tsx:44

Parâmetros: 

```typescript
{
      const narrow = window.innerWidth < 1200;
      setIsNarrow(narrow);
    }
```

## ReportBuilder.tsx / fetchTemplates

Origem: components/relatorios/report-builder/ReportBuilder.tsx:52

Parâmetros: 

```typescript
{
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/reports/templates');
      if (!res.ok) {
        const response = await res.json().catch(() => ({}));
        throw new Error(response.error || 'Erro ao carregar templates');
      }
      const data = await res.json();
      setTemplates(data.templates || []);
    } catch (err: any) {
      setError(err.message);
      setTemplates([]);
    } finally {
      setLoading(false);
    }
  }
```

## ReportBuilder.tsx / handleNew

Origem: components/relatorios/report-builder/ReportBuilder.tsx:75

Parâmetros: 

```typescript
{
    if (currentUser?.role !== 'ADMIN') return;
    setCurrentTemplate(createEmptyTemplate(currentUser?.id));
    setAvailableColumns([]);
    setPreviewData([]);
    setActiveTab('datasource');
    setMobilePreviewOpen(false);
  }
```

## ReportBuilder.tsx / handleSelect

Origem: components/relatorios/report-builder/ReportBuilder.tsx:84

Parâmetros: tpl: ReportTemplate

```typescript
{
    setCurrentTemplate({ ...tpl });
    const savedColumns = new Map<string, string>();
    const addSavedColumn = (field: unknown, dataType = 'text') => {
      if (typeof field !== 'string' || !field.trim()) return;
      if (!savedColumns.has(field)) savedColumns.set(field, dataType);
    };
    for (const column of tpl.layout?.columns || []) {
      const format = String(column.format || '').toLowerCase();
      const dataType = ['number', 'currency', 'currency_brl', 'percent'].includes(format)
        ? 'numeric'
        : ['date', 'datetime'].includes(format) ? 'date' : 'text';
      addSavedColumn(column.field, dataType);
    }
    for (const filter of (tpl as any).filters || []) {
      const field = filter.field || String(filter.placeholder || '').split('.').at(-1);
      const dataType = filter.type === 'number' ? 'numeric' : filter.type === 'date' ? 'date' : 'text';
      addSavedColumn(field, dataType);
    }
    for (const subreport of (tpl as any).subreports || []) {
      for (const column of subreport.columns || []) {
        const format = String(column.format || '').toLowerCase();
        const dataType = ['number', 'currency', 'currency_brl', 'percent'].includes(format)
          ? 'numeric'
          : ['date', 'datetime'].includes(format) ? 'date' : 'text';
        addSavedColumn(column.field, dataType);
      }
      addSavedColumn(subreport.summary_config?.groupField);
    }
    for (const chart of (tpl as any).charts || []) {
      addSavedColumn(chart.xField);
      for (const field of chart.yFields || []) addSavedColumn(typeof field === 'string' ? field : field.field, 'numeric');
    }
    setAvailableColumns(Array.from(savedColumns, ([name, dataType]) => ({ name, dataType })));
    setPreviewData([]);
    setActiveTab('datasource');
    setMobilePreviewOpen(false);
    if (isNarrow) setSidebarOpen(false);
  }
```

## ReportBuilder.tsx / addSavedColumn

Origem: components/relatorios/report-builder/ReportBuilder.tsx:87

Parâmetros: field: unknown, dataType = 'text'

```typescript
{
      if (typeof field !== 'string' || !field.trim()) return;
      if (!savedColumns.has(field)) savedColumns.set(field, dataType);
    }
```

## ReportBuilder.tsx / handleSave

Origem: components/relatorios/report-builder/ReportBuilder.tsx:124

Parâmetros: data: Partial<ReportTemplate>

```typescript
{
    try {
      const payload = { ...currentTemplate, ...data };
      const isNew = !payload.id;
      const url = isNew ? '/api/reports/templates' : `/api/reports/templates/${payload.id}`;
      const method = isNew ? 'POST' : 'PUT';
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      if (!res.ok) {
        const response = await res.json().catch(() => ({}));
        throw new Error(response.error || 'Erro ao salvar o relatório.');
      }
      const saved = await res.json();
      setCurrentTemplate(saved.template || saved);
      setShowSaveModal(false);
      fetchTemplates();
    } catch (err: any) {
      setError(err.message);
    }
  }
```

## ReportBuilder.tsx / handleDelete

Origem: components/relatorios/report-builder/ReportBuilder.tsx:148

Parâmetros: 

```typescript
{
    if (!currentTemplate.id) return;
    if (!window.confirm('Tem certeza que deseja excluir este relatório?')) return;
    try {
      const res = await fetch(`/api/reports/templates/${currentTemplate.id}`, { method: 'DELETE' });
      if (!res.ok) {
        const response = await res.json().catch(() => ({}));
        throw new Error(response.error || 'Erro ao excluir o relatório.');
      }
      handleNew();
      fetchTemplates();
    } catch (err: any) {
      setError(err.message);
    }
  }
```

## ReportBuilder.tsx / handleSqlChange

Origem: components/relatorios/report-builder/ReportBuilder.tsx:164

Parâmetros: sql: string

```typescript
{
    setCurrentTemplate(prev => ({ ...prev, sql_query: sql }));
  }
```

## ReportBuilder.tsx / handleColumnsChange

Origem: components/relatorios/report-builder/ReportBuilder.tsx:168

Parâmetros: cols: { field: string; label: string }[]

```typescript
{
    setAvailableColumns(cols.map(c => ({ name: c.field, dataType: 'text' })));
    setCurrentTemplate(prev => {
      const existingFields = new Set(prev.layout.columns.map(c => c.field));
      const newColumns: ColumnDef[] = cols.map(c => {
        if (existingFields.has(c.field)) {
          return prev.layout.columns.find(ec => ec.field === c.field)!;
        }
        return { field: c.field, label: c.label, width: '100', align: 'left' as const, format: 'text' as const, visible: true };
      });
      return { ...prev, layout: { ...prev.layout, columns: newColumns } };
    });
  }
```

## ReportBuilder.tsx / handleLayoutChange

Origem: components/relatorios/report-builder/ReportBuilder.tsx:182

Parâmetros: layout: ReportLayout

```typescript
{
    setCurrentTemplate(prev => ({ ...prev, layout }));
  }
```

## ReportBuilder.tsx / handleTargetLayoutChange

Origem: components/relatorios/report-builder/ReportBuilder.tsx:186

Parâmetros: target: 'responsive' | 'web' | 'mobile'

```typescript
{
    setCurrentTemplate(prev => ({ ...prev, target_layout: target }));
  }
```

## ReportBuilder.tsx / handleChartsChange

Origem: components/relatorios/report-builder/ReportBuilder.tsx:190

Parâmetros: charts: ChartConfig[]

```typescript
{
    setCurrentTemplate(prev => ({ ...prev, charts }));
  }
```

## ReportBuilder.tsx / handleFiltersChange

Origem: components/relatorios/report-builder/ReportBuilder.tsx:194

Parâmetros: filters: FilterConfig[]

```typescript
{
    setCurrentTemplate(prev => ({ ...prev, filters }));
  }
```

## ReportBuilder.tsx / handleSubreportsChange

Origem: components/relatorios/report-builder/ReportBuilder.tsx:198

Parâmetros: subreports: SubreportConfig[]

```typescript
{
    setCurrentTemplate(prev => ({ ...prev, subreports }));
  }
```

## ReportBuilder.tsx / renderTabContent

Origem: components/relatorios/report-builder/ReportBuilder.tsx:204

Parâmetros: 

```typescript
{
    switch (activeTab) {
      case 'datasource':
        return (
          <DataSourceTab
            sqlQuery={currentTemplate.sql_query}
            onSqlChange={handleSqlChange}
            onColumnsChange={handleColumnsChange}
          />
        );
      case 'layout':
        return (
          <LayoutTab
            layout={currentTemplate.layout}
            onLayoutChange={handleLayoutChange}
            columns={currentTemplate.layout.columns}
            targetLayout={currentTemplate.target_layout}
            onTargetLayoutChange={handleTargetLayoutChange}
          />
        );
      case 'charts':
        return (
          <ChartsTab
            charts={currentTemplate.charts}
            onChartsChange={handleChartsChange}
            columns={columnNames}
          />
        );
      case 'filters':
        return (
          <FiltersTab
            filters={currentTemplate.filters}
            onFiltersChange={handleFiltersChange}
            availableColumns={availableColumns}
          />
        );
      case 'subreports':
        return (
          <SubreportsTab
            subreports={currentTemplate.subreports}
            onSubreportsChange={handleSubreportsChange}
            availableColumns={availableColumns}
            parentData={previewData}
          />
        );
      case 'guide':
        return <GuideTab />;
      default:
        return null;
    }
  }
```

## ReportRenderer.tsx / formatCurrency

Origem: components/relatorios/report-builder/ReportRenderer.tsx:20

Parâmetros: value: any

```typescript
{
  const num = parseFloat(String(value));
  if (isNaN(num)) return String(value ?? '');
  return 'R$ ' + num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
```

## ReportRenderer.tsx / formatDate

Origem: components/relatorios/report-builder/ReportRenderer.tsx:26

Parâmetros: value: any

```typescript
{
  const d = new Date(String(value));
  if (isNaN(d.getTime())) return String(value ?? '');
  return d.toLocaleDateString('pt-BR');
}
```

## ReportRenderer.tsx / formatCPFCNPJ

Origem: components/relatorios/report-builder/ReportRenderer.tsx:32

Parâmetros: value: any

```typescript
{
  const digits = String(value ?? '').replace(/\D/g, '');
  if (digits.length === 11) return digits.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
  if (digits.length === 14) return digits.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
  return String(value ?? '');
}
```

## ReportRenderer.tsx / formatPercent

Origem: components/relatorios/report-builder/ReportRenderer.tsx:39

Parâmetros: value: any

```typescript
{
  const num = parseFloat(String(value));
  if (isNaN(num)) return String(value ?? '');
  return num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '%';
}
```

## ReportRenderer.tsx / formatNumber

Origem: components/relatorios/report-builder/ReportRenderer.tsx:45

Parâmetros: value: any

```typescript
{
  const num = parseFloat(String(value));
  if (isNaN(num)) return String(value ?? '');
  return num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
```

## ReportRenderer.tsx / applyFormat

Origem: components/relatorios/report-builder/ReportRenderer.tsx:51

Parâmetros: value: any, format?: ColumnFormat | string

```typescript
{
  if (value == null) return '';
  if (!format || format === 'text') return String(value);
  switch (format) {
    case 'currency_brl':
    case 'currency': return formatCurrency(value);
    case 'date': return formatDate(value);
    case 'datetime': {
      const date = new Date(value);
      return Number.isNaN(date.getTime()) ? String(value) : date.toLocaleString('pt-BR');
    }
    case 'cpf_cnpj': return formatCPFCNPJ(value);
    case 'percent': return formatPercent(value);
    case 'number': return formatNumber(value);
    default: return String(value);
  }
}
```

## ReportRenderer.tsx / groupData

Origem: components/relatorios/report-builder/ReportRenderer.tsx:69

Parâmetros: data: any[], fields: string[]

```typescript
{
  const groups: Record<string, any[]> = {};
  for (const row of data) {
    const key = fields.map(f => String(row[f] ?? 'Sem grupo')).join(' / ');
    if (!groups[key]) groups[key] = [];
    groups[key].push(row);
  }
  return groups;
}
```

## ReportRenderer.tsx / computeTotalizers

Origem: components/relatorios/report-builder/ReportRenderer.tsx:79

Parâmetros: rows: any[], totalizers: { field: string; operation: string }[], columns: { field: string; label: string; format?: ColumnFormat | string }[]

```typescript
{
  if (!totalizers || totalizers.length === 0) return `${rows.length} registro(s)`;
  const parts: string[] = [];
  for (const t of totalizers) {
    const col = columns.find(c => c.field === t.field);
    const label = col?.label || t.field;
    if (t.operation === 'contagem' || t.operation === 'count') {
      parts.push(`${label}: ${rows.length}`);
    } else if (t.operation === 'soma' || t.operation === 'sum') {
      const sum = rows.reduce((acc, row) => acc + (parseFloat(String(row[t.field] ?? 0)) || 0), 0);
      parts.push(`${label}: ${applyFormat(sum, col?.format as ColumnFormat || 'currency_brl')}`);
    } else if (t.operation === 'media' || t.operation === 'avg') {
      const avg = rows.length > 0 ? rows.reduce((acc, row) => acc + (parseFloat(String(row[t.field] ?? 0)) || 0), 0) / rows.length : 0;
      parts.push(`${label}: ${applyFormat(avg, col?.format as ColumnFormat || 'number')}`);
    } else if (t.operation === 'maximo' || t.operation === 'max') {
      const max = rows.reduce((acc, row) => Math.max(acc, parseFloat(String(row[t.field] ?? 0)) || 0), -Infinity);
      parts.push(`${label} (máx): ${applyFormat(max, col?.format as ColumnFormat || 'number')}`);
    } else if (t.operation === 'minimo' || t.operation === 'min') {
      const min = rows.reduce((acc, row) => Math.min(acc, parseFloat(String(row[t.field] ?? 0)) || 0), Infinity);
      parts.push(`${label} (mín): ${applyFormat(min, col?.format as ColumnFormat || 'number')}`);
    }
  }
  return parts.length > 0 ? parts.join(' | ') : `${rows.length} registro(s)`;
}
```

## ReportRenderer.tsx / aggregateChartData

Origem: components/relatorios/report-builder/ReportRenderer.tsx:117

Parâmetros: data: any[], xField: string, yField: string, operation: string

```typescript
{
  const map = new Map<string, number[]>();
  for (const row of data) {
    const key = String(row[xField] ?? '');
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(parseFloat(String(row[yField] ?? 0)) || 0);
  }
  const entries: { label: string; value: number }[] = [];
  map.forEach((vals, key) => {
    let value: number;
    if (operation === 'contagem') value = vals.length;
    else if (operation === 'media') value = vals.length > 0 ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
    else value = vals.reduce((a, b) => a + b, 0);
    entries.push({ label: key, value });
  });
  entries.sort((a, b) => b.value - a.value);
  return {
    labels: entries.map(e => e.label),
    values: entries.map(e => e.value),
  };
}
```

## ReportRenderer.tsx / buildRowItems

Origem: components/relatorios/report-builder/ReportRenderer.tsx:299

Parâmetros: data: any[], layout: ReportLayout

```typescript
{
  const items: RowItem[] = [];
  if (layout.grouping) {
    const grouped = groupData(data, layout.grouping.fields);
    let idx = 0;
    for (const [key, rows] of Object.entries(grouped)) {
      items.push({ type: 'group-header', key });
      for (const row of rows as any[]) {
        items.push({ type: 'data', row, idx: idx++ });
      }
      if (layout.grouping.showSubtotals) {
        items.push({ type: 'subtotal', rows: rows as any[], visibleCols: layout.columns.filter(c => c.visible), totalizers: layout.grouping!.totalizers || [] });
      }
    }
  } else {
    data.forEach((row, idx) => items.push({ type: 'data', row, idx }));
  }
  return items;
}
```

## ReportRenderer.tsx / calcPageMetrics

Origem: components/relatorios/report-builder/ReportRenderer.tsx:319

Parâmetros: layout: ReportLayout

```typescript
{
  const margins = layout.general.margins;
  const marginTopPx = margins.top * PX_PER_MM;
  const marginBottomPx = margins.bottom * PX_PER_MM;
  const usableHeightPx = A4_HEIGHT_MM * PX_PER_MM - marginTopPx - marginBottomPx;

  const headerH = layout.header.show ? (layout.header.showLogo ? 72 : 48) : 0;
  const footerH = layout.footer.show ? 32 : 0;
  const tableHeaderH = 28;
  const fontSize = layout.general.fontSize || 12;
  const rowH = Math.max(fontSize * 1.4 + 8, 22);

  const bodyH = usableHeightPx - headerH - footerH - tableHeaderH;
  const rowsPerPage = Math.max(3, Math.floor(bodyH / rowH));

  return {
    pageWidthMm: A4_WIDTH_MM,
    pageHeightMm: A4_HEIGHT_MM,
    marginTopPx,
    marginBottomPx,
    marginLeftPx: margins.left * PX_PER_MM,
    marginRightPx: margins.right * PX_PER_MM,
    rowsPerPage,
    rowH,
  };
}
```

## ReportRenderer.tsx / renderPage

Origem: components/relatorios/report-builder/ReportRenderer.tsx:401

Parâmetros: content: React.ReactNode, key: string

```typescript
{
    pageCounter++;
    const num = pageCounter;
    return (
      <div key={key} className="report-page" style={pageStyle}>
        <PageHeader layout={layout} logoUrl={logoUrl} alignClass={alignClass} />
        <div style={{ flex: 1, minWidth: 0, overflow: 'visible' }}>
          {content}
        </div>
        <PageFooter layout={layout} data={data} pageNum={num} totalPages={totalPages} />
      </div>
    );
  }
```

## ReportRenderer.tsx / renderDataRow

Origem: components/relatorios/report-builder/ReportRenderer.tsx:415

Parâmetros: item: RowItem, visibleCols: any[], zebra: boolean

```typescript
{
    if (item.type === 'group-header') {
      return (
        <tr key={`gh-${item.key}`}>
          <td colSpan={visibleCols.length} className="border border-gray-300 px-2 py-1 bg-indigo-50 font-bold text-[11px]">
            {item.key}
          </td>
        </tr>
      );
    }
    if (item.type === 'subtotal') {
      return (
        <tr key={`st-${Math.random()}`} className="bg-indigo-50/50">
          <td className="border border-gray-300 px-2 py-0.5 font-semibold text-[10px] italic text-right" colSpan={1}>
            Subtotal:
          </td>
          {item.visibleCols.slice(1).map((col: any) => {
            const subtotalizer = item.totalizers.find((t: any) => t.field === col.field);
            if (!subtotalizer) return <td key={col.field} className="border border-gray-300 px-2 py-0.5 text-[10px]" style={{ textAlign: col.align }} />;
            const subtotalText = computeTotalizers(item.rows, [subtotalizer], [{ field: col.field, label: col.label, format: col.format }]);
            const valueOnly = subtotalText.includes(': ') ? subtotalText.split(': ').slice(1).join(': ') : subtotalText;
            return <td key={col.field} className="border border-gray-300 px-2 py-0.5 text-[10px] font-semibold" style={{ textAlign: col.align }}>{valueOnly}</td>;
          })}
        </tr>
      );
    }
    return (
      <tr key={`r-${item.idx}`} className={zebra && item.idx % 2 === 1 ? 'bg-gray-50' : ''}>
        {visibleCols.map((col: any) => (
          <td key={col.field} className="border border-gray-300 px-2 py-0.5 text-[11px]" style={{ textAlign: col.align }}>
            {applyFormat(item.row[col.field], col.format)}
          </td>
        ))}
      </tr>
    );
  }
```

## ReportSaveModal.tsx / handleSave

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:31

Parâmetros: 

```typescript
{
    if (!name.trim()) return;
    onSave({
      name: name.trim(),
      description: description.trim(),
      category,
      target_layout: targetLayout,
      content_mode: contentMode,
      allowed_users: selectedUsers.length > 0 ? selectedUsers : null,
      allowed_groups: selectedGroups.length > 0 ? selectedGroups : null,
    });
  }
```

## ReportSaveModal.tsx / handleKeyDown

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:45

Parâmetros: e: KeyboardEvent

```typescript
{
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        e.preventDefault();
        handleSave();
      }
    }
```

## ReportSaveModal.tsx / toggleUser

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:55

Parâmetros: id: string

```typescript
{
    setSelectedUsers(prev => prev.includes(id) ? prev.filter(u => u !== id) : [...prev, id]);
  }
```

## ReportSaveModal.tsx / toggleGroup

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:59

Parâmetros: id: string

```typescript
{
    setSelectedGroups(prev => prev.includes(id) ? prev.filter(g => g !== id) : [...prev, id]);
  }
```

## ReportTree.tsx / toggleCategory

Origem: components/relatorios/report-builder/ReportTree.tsx:22

Parâmetros: cat: string

```typescript
{
    setExpandedCategories(prev => ({ ...prev, [cat]: !prev[cat] }));
  }
```

## ReportTree.tsx / getContentModeIcon

Origem: components/relatorios/report-builder/ReportTree.tsx:26

Parâmetros: mode: string

```typescript
{
    if (mode === 'data') {
      return (
        <svg className="w-3.5 h-3.5 text-blue-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h16M4 18h16" />
        </svg>
      );
    }
    if (mode === 'charts') {
      return (
        <svg className="w-3.5 h-3.5 text-green-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6m6 0h6m-6 0V9a2 2 0 012-2h2a2 2 0 012 2v10m6 0v-4a2 2 0 00-2-2h-2a2 2 0 00-2 2v4" />
        </svg>
      );
    }
    return (
      <svg className="w-3.5 h-3.5 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 10h16M4 14h10M17 14l2 2m0 0l2 2m-2-2l2-2m-2 2l-2 2" />
      </svg>
    );
  }
```

## SchemaExplorer.tsx / getTypeBadgeClass

Origem: components/relatorios/report-builder/SchemaExplorer.tsx:47

Parâmetros: type: string

```typescript
{
  return TYPE_COLORS[type] || 'bg-gray-100 text-gray-600';
}
```

## SchemaExplorer.tsx / shortType

Origem: components/relatorios/report-builder/SchemaExplorer.tsx:51

Parâmetros: type: string

```typescript
{
  const map: Record<string, string> = {
    'character varying': 'varchar',
    'timestamp with time zone': 'timestamptz',
    'timestamp without time zone': 'timestamp',
    'double precision': 'float8',
  };
  return map[type] || type;
}
```

## SchemaExplorer.tsx / fetchColumns

Origem: components/relatorios/report-builder/SchemaExplorer.tsx:84

Parâmetros: table: string

```typescript
{
      if (tableColumns[table]) return;
      setLoadingColumns((prev) => ({ ...prev, [table]: true }));
      fetch(`/api/reports/schema/columns?table=${encodeURIComponent(table)}`)
        .then((r) => r.json())
        .then((data) => setTableColumns((prev) => ({ ...prev, [table]: data.columns || [] })))
        .catch(() => {})
        .finally(() => setLoadingColumns((prev) => ({ ...prev, [table]: false })));
    }
```

## SchemaExplorer.tsx / handleTableClick

Origem: components/relatorios/report-builder/SchemaExplorer.tsx:97

Parâmetros: table: string

```typescript
{
    const isSelected = selectedTables.includes(table);
    if (isSelected) {
      if (expandedTable === table) {
        setExpandedTable(null);
      } else {
        setExpandedTable(table);
      }
    } else {
      onSelectTable(table);
      fetchColumns(table);
      setExpandedTable(table);
    }
  }
```

## SchemaExplorer.tsx / handleRemoveTable

Origem: components/relatorios/report-builder/SchemaExplorer.tsx:112

Parâmetros: e: React.MouseEvent, table: string

```typescript
{
    e.stopPropagation();
    onDeselectTable(table);
    if (expandedTable === table) setExpandedTable(null);
  }
```

## SchemaExplorer.tsx / isColumnSelected

Origem: components/relatorios/report-builder/SchemaExplorer.tsx:118

Parâmetros: table: string, column: string

```typescript
selectedColumns.some((c) => c.table === table && c.column === column)
```

## SubreportsTab.tsx / generateId

Origem: components/relatorios/report-builder/SubreportsTab.tsx:30

Parâmetros: 

```typescript
{
  return 'sub_' + Math.random().toString(36).substr(2, 9);
}
```

## SubreportsTab.tsx / isNumericType

Origem: components/relatorios/report-builder/SubreportsTab.tsx:34

Parâmetros: dataType: string

```typescript
{
  const numericTypes = ['number', 'numeric', 'integer', 'int', 'float', 'double', 'decimal', 'bigint', 'smallint', 'real', 'money'];
  return numericTypes.some(t => dataType.toLowerCase().includes(t));
}
```

## SubreportsTab.tsx / toggleExpand

Origem: components/relatorios/report-builder/SubreportsTab.tsx:43

Parâmetros: id: string

```typescript
{
    setExpandedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }
```

## SubreportsTab.tsx / addSubreport

Origem: components/relatorios/report-builder/SubreportsTab.tsx:52

Parâmetros: 

```typescript
{
    const newSub: SubreportConfig = {
      id: generateId(),
      type: 'summary',
      title: '',
      columns: [],
      totalizers: [],
      summary_config: { groupField: '', operations: [] },
    };
    onSubreportsChange([...subreports, newSub]);
    setExpandedIds(prev => new Set(prev).add(newSub.id));
  }
```

## SubreportsTab.tsx / updateSubreport

Origem: components/relatorios/report-builder/SubreportsTab.tsx:65

Parâmetros: id: string, updates: Partial<SubreportConfig>

```typescript
{
    onSubreportsChange(subreports.map(s => s.id === id ? { ...s, ...updates } : s));
  }
```

## SubreportsTab.tsx / removeSubreport

Origem: components/relatorios/report-builder/SubreportsTab.tsx:69

Parâmetros: id: string

```typescript
{
    onSubreportsChange(subreports.filter(s => s.id !== id));
  }
```

## SubreportsTab.tsx / moveSubreport

Origem: components/relatorios/report-builder/SubreportsTab.tsx:73

Parâmetros: index: number, direction: -1 | 1

```typescript
{
    const newIndex = index + direction;
    if (newIndex < 0 || newIndex >= subreports.length) return;
    const arr = [...subreports];
    [arr[index], arr[newIndex]] = [arr[newIndex], arr[index]];
    onSubreportsChange(arr);
  }
```

## SubreportsTab.tsx / testQuery

Origem: components/relatorios/report-builder/SubreportsTab.tsx:81

Parâmetros: sub: SubreportConfig

```typescript
{
    if (!sub.sql_query?.trim()) return;
    setQueryResults(prev => ({ ...prev, [sub.id]: { rows: [], fields: [], loading: true } }));
    try {
      const res = await fetch('/api/reports/preview-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sql: sub.sql_query }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Erro ao executar query');
      setQueryResults(prev => ({ ...prev, [sub.id]: { rows: data.rows || [], fields: data.fields || [] } }));
    } catch (err: any) {
      setQueryResults(prev => ({ ...prev, [sub.id]: { rows: [], fields: [], error: err.message } }));
    }
  }
```

## SubreportsTab.tsx / computeSummaryPreview

Origem: components/relatorios/report-builder/SubreportsTab.tsx:100

Parâmetros: sub: SubreportConfig

```typescript
{
    if (!parentData?.length || !sub.summary_config?.groupField) return [];
    const { groupField, operations } = sub.summary_config;
    const groups: Record<string, any[]> = {};
    parentData.forEach(row => {
      const key = String(row[groupField] ?? '(vazio)');
      if (!groups[key]) groups[key] = [];
      groups[key].push(row);
    });

    return Object.entries(groups).map(([key, rows]) => {
      const result: Record<string, any> = { [groupField]: key };
      (operations || []).forEach(({ field, op }) => {
        if (op === 'none') return;
        if (op === 'count') {
          result[field] = rows.length;
          return;
        }
        const vals = rows.map(r => Number(r[field])).filter(v => !isNaN(v));
        if (op === 'sum') result[field] = vals.reduce((a, b) => a + b, 0);
        else if (op === 'avg') result[field] = vals.length ? vals.reduce((a, b) => a + b, 0) / vals.length : 0;
        else if (op === 'min') result[field] = vals.length ? Math.min(...vals) : 0;
        else if (op === 'max') result[field] = vals.length ? Math.max(...vals) : 0;
      });
      return result;
    });
  }
```

## SubreportsTab.tsx / addColumn

Origem: components/relatorios/report-builder/SubreportsTab.tsx:128

Parâmetros: subId: string

```typescript
{
    const sub = subreports.find(s => s.id === subId);
    if (!sub) return;
    updateSubreport(subId, {
      columns: [...sub.columns, { field: '', label: '', width: 20, format: '', align: 'left' }],
    });
  }
```

## SubreportsTab.tsx / updateColumn

Origem: components/relatorios/report-builder/SubreportsTab.tsx:136

Parâmetros: subId: string, colIdx: number, updates: Partial<SubreportColumnConfig>

```typescript
{
    const sub = subreports.find(s => s.id === subId);
    if (!sub) return;
    const cols = sub.columns.map((c, i) => i === colIdx ? { ...c, ...updates } : c);
    updateSubreport(subId, { columns: cols });
  }
```

## SubreportsTab.tsx / removeColumn

Origem: components/relatorios/report-builder/SubreportsTab.tsx:143

Parâmetros: subId: string, colIdx: number

```typescript
{
    const sub = subreports.find(s => s.id === subId);
    if (!sub) return;
    updateSubreport(subId, { columns: sub.columns.filter((_, i) => i !== colIdx) });
  }
```

## WhereBuilder.tsx / addCondition

Origem: components/relatorios/report-builder/WhereBuilder.tsx:40

Parâmetros: 

```typescript
{
    onConditionsChange([
      ...conditions,
      {
        id: crypto.randomUUID(),
        field: '',
        operator: '=',
        value: '',
        connector: 'AND',
      },
    ]);
  }
```

## WhereBuilder.tsx / updateCondition

Origem: components/relatorios/report-builder/WhereBuilder.tsx:53

Parâmetros: id: string, field: keyof WhereCondition, value: string

```typescript
{
    onConditionsChange(conditions.map((c) => (c.id === id ? { ...c, [field]: value } : c)));
  }
```

## WhereBuilder.tsx / removeCondition

Origem: components/relatorios/report-builder/WhereBuilder.tsx:57

Parâmetros: id: string

```typescript
{
    onConditionsChange(conditions.filter((c) => c.id !== id));
  }
```

## WhereBuilder.tsx / isDynamic

Origem: components/relatorios/report-builder/WhereBuilder.tsx:61

Parâmetros: value: string

```typescript
value.startsWith('{{') && value.endsWith('}}')
```

## types.ts / createEmptyTemplate

Origem: components/relatorios/report-builder/types.ts:185

Parâmetros: userId?: string

```typescript
{
  return {
    id: '',
    name: '',
    description: '',
    category: 'Outros',
    target_layout: 'responsive',
    content_mode: 'both',
    sql_query: '',
    layout: { ...DEFAULT_LAYOUT },
    filters: [],
    subreports: [],
    charts: [],
    allowed_users: null,
    allowed_groups: null,
    created_by: userId || null,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    is_active: true,
  };
}
```

## types.ts / createEmptyChart

Origem: components/relatorios/report-builder/types.ts:207

Parâmetros: 

```typescript
{
  return {
    id: crypto.randomUUID(),
    type: 'bar',
    subType: 'vertical',
    title: '',
    xField: '',
    yFields: [],
    colors: COLOR_PALETTES.padrao,
    palette: 'padrao',
    position: 'after',
    width: '100%',
    showLegend: true,
    showDataLabels: false,
    showGrid: true,
  };
}
```

## reportExporters.ts / triggerDownload

Origem: utils/reportExporters.ts:5

Parâmetros: blob: Blob, filename: string

```typescript
{
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}
```

## reportExporters.ts / escapeHtml

Origem: utils/reportExporters.ts:16

Parâmetros: value: unknown

```typescript
{
  const replacements: Record<string, string> = {
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  };
  return String(value ?? '').replace(/[&<>"']/g, char => replacements[char]);
}
```

## reportExporters.ts / aggregateForExport

Origem: utils/reportExporters.ts:23

Parâmetros: data: any[], xField: string, yField: string, operation: string

```typescript
{
  const valuesByLabel = new Map<string, number[]>();
  for (const row of data) {
    const label = String(row[xField] ?? '');
    if (!valuesByLabel.has(label)) valuesByLabel.set(label, []);
    valuesByLabel.get(label)!.push(parseFloat(String(row[yField] ?? 0)) || 0);
  }
  const entries = Array.from(valuesByLabel, ([label, values]) => {
    const total = values.reduce((sum, value) => sum + value, 0);
    const value = operation === 'contagem'
      ? values.length
      : operation === 'media' ? (values.length ? total / values.length : 0) : total;
    return { label, value };
  });
  entries.sort((a, b) => b.value - a.value);
  return entries;
}
```

## reportExporters.ts / buildChartExport

Origem: utils/reportExporters.ts:41

Parâmetros: chart: ChartConfig, data: any[]

```typescript
{
  const yFields = chart.type === 'pie' ? chart.yFields.slice(0, 1) : chart.yFields;
  if (!chart.xField || yFields.length === 0) return null;
  const aggregates = yFields.map(field => ({
    field,
    entries: aggregateForExport(data, chart.xField, field.field, field.operation || 'soma'),
  }));
  const labels = aggregates[0].entries.map(entry => entry.label);
  const lookup = aggregates.map(({ entries }) => new Map(entries.map(entry => [entry.label, entry.value])));
  return {
    title: chart.title || 'Gráfico',
    columns: [chart.xField, ...yFields.map(field => field.field)],
    rows: labels.map(label => [label, ...lookup.map(values => values.get(label) ?? 0)]),
    position: chart.position,
  };
}
```

## reportExporters.ts / formatValue

Origem: utils/reportExporters.ts:58

Parâmetros: value: any, format?: ColumnFormat | string

```typescript
{
  if (value == null) return '';
  const str = String(value);
  if (!format || format === 'text') return str;
  switch (format) {
    case 'currency_brl':
    case 'currency': {
      const num = parseFloat(str);
      if (isNaN(num)) return str;
      return 'R$ ' + num.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    case 'date': {
      const d = new Date(str);
      if (isNaN(d.getTime())) return str;
      return d.toLocaleDateString('pt-BR');
    }
    case 'datetime': {
      const d = new Date(str);
      if (isNaN(d.getTime())) return str;
      return d.toLocaleString('pt-BR');
    }
    case 'cpf_cnpj': {
      const digits = str.replace(/\D/g, '');
      if (digits.length === 11) return digits.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4');
      if (digits.length === 14) return digits.replace(/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/, '$1.$2.$3/$4-$5');
      return str;
    }
    case 'percent': {
      const n = parseFloat(str);
      if (isNaN(n)) return str;
      return n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + '%';
    }
    case 'number': {
      const n2 = parseFloat(str);
      if (isNaN(n2)) return str;
      return n2.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    }
    default:
      return str;
  }
}
```

## reportExporters.ts / groupData

Origem: utils/reportExporters.ts:100

Parâmetros: data: any[], fields: string[]

```typescript
{
  const groups: Record<string, any[]> = {};
  for (const row of data) {
    const key = fields.map(f => String(row[f] ?? 'Sem grupo')).join(' / ');
    if (!groups[key]) groups[key] = [];
    groups[key].push(row);
  }
  return groups;
}
```

## reportExporters.ts / summarizeRows

Origem: utils/reportExporters.ts:110

Parâmetros: rows: any[], totalizers: { field: string; operation: string }[] | undefined, columns: { field: string; label: string; format?: ColumnFormat | string }[]

```typescript
{
  if (!totalizers?.length) return `${rows.length} registro(s)`;
  const parts: string[] = [];
  for (const totalizer of totalizers) {
    const column = columns.find(item => item.field === totalizer.field);
    const label = column?.label || totalizer.field;
    const operation = totalizer.operation;
    if (operation === 'contagem' || operation === 'count') {
      parts.push(`${label}: ${rows.length}`);
      continue;
    }
    const values = rows.map(row => Number(row[totalizer.field])).filter(Number.isFinite);
    let value: number | undefined;
    if (operation === 'soma' || operation === 'sum') {
      value = values.reduce((sum, item) => sum + item, 0);
    } else if (operation === 'media' || operation === 'avg') {
      value = values.length ? values.reduce((sum, item) => sum + item, 0) / values.length : 0;
    } else if (operation === 'maximo' || operation === 'max') {
      value = values.length ? Math.max(...values) : 0;
    } else if (operation === 'minimo' || operation === 'min') {
      value = values.length ? Math.min(...values) : 0;
    }
    if (value !== undefined) {
      const defaultFormat = operation === 'soma' || operation === 'sum' ? 'currency_brl' : 'number';
      parts.push(`${label}: ${formatValue(value, column?.format || defaultFormat)}`);
    }
  }
  return parts.length ? parts.join(' | ') : `${rows.length} registro(s)`;
}
```

## reportExporters.ts / buildHTMLTable

Origem: utils/reportExporters.ts:144

Parâmetros: data: any[], layout: ReportLayout

```typescript
{
  const visibleCols = layout.columns.filter(c => c.visible);
  let html = '<table style="width:100%;border-collapse:collapse;font-family:' + escapeHtml(layout.general.fontFamily) + ';font-size:' + Number(layout.general.fontSize) + 'px;">';
  html += '<thead><tr>';
  for (const col of visibleCols) {
    html += '<th style="border:1px solid #ccc;padding:6px 8px;background:#f0f0f0;font-weight:bold;text-align:' + escapeHtml(col.align) + ';">' + escapeHtml(col.label) + '</th>';
  }
  html += '</tr></thead><tbody>';

  const grouped = layout.grouping ? groupData(data, layout.grouping.fields) : null;

  if (grouped) {
    for (const [groupKey, rows] of Object.entries(grouped)) {
      html += '<tr><td colspan="' + visibleCols.length + '" style="border:1px solid #ccc;padding:6px 8px;background:#e0e7ff;font-weight:bold;">' + escapeHtml(groupKey) + '</td></tr>';
      for (let i = 0; i < (rows as any[]).length; i++) {
        const row = (rows as any[])[i];
        const bg = layout.general.zebra && i % 2 === 1 ? 'background:#f9fafb;' : '';
        html += '<tr style="' + bg + '">';
        for (const col of visibleCols) {
          html += '<td style="border:1px solid #ccc;padding:4px 8px;text-align:' + escapeHtml(col.align) + ';">' + escapeHtml(formatValue(row[col.field], col.format)) + '</td>';
        }
        html += '</tr>';
      }
      if (layout.grouping!.showSubtotals) {
        const subtotal = summarizeRows(rows as any[], layout.grouping!.totalizers, visibleCols);
        html += '<tr style="background:#f0f4ff;font-weight:bold;"><td colspan="' + visibleCols.length + '" style="border:1px solid #ccc;padding:4px 8px;">' + escapeHtml(subtotal) + '</td></tr>';
      }
    }
  } else {
    for (let i = 0; i < data.length; i++) {
      const row = data[i];
      const bg = layout.general.zebra && i % 2 === 1 ? 'background:#f9fafb;' : '';
      html += '<tr style="' + bg + '">';
      for (const col of visibleCols) {
        html += '<td style="border:1px solid #ccc;padding:4px 8px;text-align:' + escapeHtml(col.align) + ';">' + escapeHtml(formatValue(row[col.field], col.format)) + '</td>';
      }
      html += '</tr>';
    }
  }

  html += '</tbody>';
  if (layout.footer.showTotals) {
    html += '<tfoot><tr style="font-weight:bold;background:#e8e8e8;"><td colspan="' + visibleCols.length + '" style="border:1px solid #ccc;padding:6px 8px;">' +
      escapeHtml(summarizeRows(data, layout.footer.totalizers, visibleCols)) + '</td></tr></tfoot>';
  }
  html += '</table>';
  return html;
}
```

## reportExporters.ts / buildFullHTML

Origem: utils/reportExporters.ts:193

Parâmetros: data: any[], layout: ReportLayout, charts: ChartConfig[], subreportsData: { config: SubreportConfig; data: any[] }[], contentMode: 'data' | 'charts' | 'both', chartImages: ExportedChartImage[] = []

```typescript
{
  let html = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>' + escapeHtml(layout.header.title || 'Relatório') + '</title>';
  html += '<style>body{font-family:' + escapeHtml(layout.general.fontFamily) + ';font-size:' + Number(layout.general.fontSize) + 'px;margin:20px;} @media print{body{margin:0;}}</style></head><body>';

  if (layout.header.show) {
    const align = layout.header.alignment || 'center';
    html += '<div style="text-align:' + align + ';margin-bottom:20px;">';
    if (layout.header.showLogo && layout.header.logo) html += '<img src="' + escapeHtml(layout.header.logo) + '" style="max-height:60px;margin-bottom:8px;" />';
    if (layout.header.title) html += '<h1 style="margin:0;">' + escapeHtml(layout.header.title) + '</h1>';
    if (layout.header.subtitle) html += '<h3 style="margin:4px 0;color:#666;">' + escapeHtml(layout.header.subtitle) + '</h3>';
    if (layout.header.showDate) html += '<p style="color:#999;font-size:0.85em;">' + new Date().toLocaleDateString('pt-BR') + ' ' + new Date().toLocaleTimeString('pt-BR') + '</p>';
    html += '</div>';
  }

  const chartExports = contentMode === 'data' ? [] : charts.map(chart => buildChartExport(chart, data)).filter(Boolean);
  const beforeCharts = chartExports.filter(chart => chart!.position === 'before');
  const afterCharts = chartExports.filter(chart => chart!.position !== 'before');
  const imageHtml = (position: 'before' | 'after') => chartImages
    .filter(image => (position === 'before' ? image.position === 'before' : image.position !== 'before'))
    .map(image => `<figure style="margin:16px 0;text-align:center"><img src="${escapeHtml(image.src)}" alt="${escapeHtml(image.title)}" style="max-width:100%;height:auto"><figcaption>${escapeHtml(image.title)}</figcaption></figure>`)
    .join('');
  const chartHtml = (items: typeof chartExports) => items.map(chart => {
    if (!chart) return '';
    return `<section style="margin:20px 0"><h3>${escapeHtml(chart.title)}</h3><table style="width:100%;border-collapse:collapse"><thead><tr>${chart.columns.map(column => `<th style="border:1px solid #ccc;padding:6px;background:#f0f0f0">${escapeHtml(column)}</th>`).join('')}</tr></thead><tbody>${chart.rows.map(row => `<tr>${row.map(value => `<td style="border:1px solid #ccc;padding:4px 8px">${escapeHtml(value)}</td>`).join('')}</tr>`).join('')}</tbody></table></section>`;
  }).join('');
  html += imageHtml('before') + chartHtml(beforeCharts);
  if (contentMode !== 'charts') html += buildHTMLTable(data, layout);
  html += imageHtml('after') + chartHtml(afterCharts);

  if (subreportsData.length > 0) {
    for (const sr of subreportsData) {
      html += '<div style="margin-top:24px;">';
      html += '<h3>' + escapeHtml(sr.config.title) + '</h3>';
      const srCols = sr.config.columns;
      html += '<table style="width:100%;border-collapse:collapse;">';
      html += '<thead><tr>';
      for (const col of srCols) {
        html += '<th style="border:1px solid #ccc;padding:6px 8px;background:#f0f0f0;font-weight:bold;">' + escapeHtml(col.label) + '</th>';
      }
      html += '</tr></thead><tbody>';
      for (const row of sr.data) {
        html += '<tr>';
        for (const col of srCols) {
          html += '<td style="border:1px solid #ccc;padding:4px 8px;">' + escapeHtml(formatValue(row[col.field], col.format)) + '</td>';
        }
        html += '</tr>';
      }
      html += '</tbody>';
      if (sr.config.totalizers?.length) {
        html += '<tfoot><tr><td colspan="' + srCols.length + '" style="border:1px solid #ccc;padding:6px 8px;font-weight:bold;background:#f0f0f0;">' +
          escapeHtml(summarizeRows(sr.data, sr.config.totalizers, srCols)) + '</td></tr></tfoot>';
      }
      html += '</table></div>';
    }
  }

  if (layout.footer.show) {
    html += '<div style="margin-top:20px;border-top:1px solid #ccc;padding-top:10px;font-size:0.85em;color:#666;display:flex;justify-content:space-between;">';
    if (layout.footer.customText) html += '<span>' + escapeHtml(layout.footer.customText) + '</span>';
    if (layout.footer.showDateTime) html += '<span>' + new Date().toLocaleDateString('pt-BR') + ' ' + new Date().toLocaleTimeString('pt-BR') + '</span>';
    html += '</div>';
  }

  html += '</body></html>';
  return html;
}
```

## reportExporters.ts / exportToPrint

Origem: utils/reportExporters.ts:260

Parâmetros: data: any[], layout: ReportLayout, charts: ChartConfig[], subreportsData: { config: SubreportConfig; data: any[] }[], contentMode: 'data' | 'charts' | 'both' = 'both', chartImages: ExportedChartImage[] = []

```typescript
{
  const html = buildFullHTML(data, layout, charts, subreportsData, contentMode, chartImages);
  const printWindow = window.open('', '_blank');
  if (!printWindow) return;
  printWindow.document.write(html);
  printWindow.document.close();
  printWindow.focus();
  setTimeout(() => printWindow.print(), 500);
}
```

## reportExporters.ts / exportToPDF

Origem: utils/reportExporters.ts:270

Parâmetros: data: any[], layout: ReportLayout, charts: ChartConfig[], subreportsData: { config: SubreportConfig; data: any[] }[], contentMode: 'data' | 'charts' | 'both' = 'both', chartImages: ExportedChartImage[] = []

```typescript
{
  const pdfMakeModule = await import('pdfmake/build/pdfmake');
  const pdfFontsModule = await import('pdfmake/build/vfs_fonts');
  const pdfMake = pdfMakeModule.default || pdfMakeModule;
  const pdfFonts = pdfFontsModule.default || pdfFontsModule;
  if (pdfFonts.pdfMake) {
    pdfMake.vfs = pdfFonts.pdfMake.vfs;
  } else if (pdfFonts.vfs) {
    pdfMake.vfs = pdfFonts.vfs;
  }

  const visibleCols = layout.columns.filter(c => c.visible);
  const content: any[] = [];

  if (layout.header.show) {
    if (layout.header.title) content.push({ text: layout.header.title, style: 'header', alignment: layout.header.alignment || 'center' });
    if (layout.header.subtitle) content.push({ text: layout.header.subtitle, style: 'subheader', alignment: layout.header.alignment || 'center' });
    if (layout.header.showDate) content.push({ text: new Date().toLocaleDateString('pt-BR') + ' ' + new Date().toLocaleTimeString('pt-BR'), alignment: 'center', color: '#999', margin: [0, 0, 0, 10] });
  }

  const addChartsAtPosition = (position: 'before' | 'after') => {
    for (const chart of charts.filter(item => position === 'before' ? item.position === 'before' : item.position !== 'before')) {
      const summary = buildChartExport(chart, data);
      if (!summary) continue;
      content.push({ text: summary.title, style: 'subheader', margin: [0, 15, 0, 5] });
      content.push({
        table: {
          headerRows: 1,
          widths: summary.columns.map(() => '*'),
          body: [
            summary.columns.map(column => ({ text: column, bold: true, fillColor: '#e0e0e0' })),
            ...summary.rows.map(row => row.map(value => ({ text: String(value ?? '') }))),
          ],
        },
        layout: 'lightHorizontalLines',
      });
    }
    for (const image of chartImages.filter(item => position === 'before' ? item.position === 'before' : item.position !== 'before')) {
      content.push({ image: image.src, width: 480, margin: [0, 10, 0, 4] });
      content.push({ text: image.title, fontSize: 9, alignment: 'center', margin: [0, 0, 0, 8] });
    }
  };

  if (contentMode !== 'data') addChartsAtPosition('before');

  if (contentMode !== 'charts' && visibleCols.length > 0 && data.length > 0) {
    const tableBody: any[][] = [];
    tableBody.push(visibleCols.map(c => ({ text: c.label, bold: true, fillColor: '#e0e0e0', alignment: c.align })));

    const grouped = layout.grouping ? groupData(data, layout.grouping.fields) : null;

    if (grouped) {
      for (const [groupKey, rows] of Object.entries(grouped)) {
        tableBody.push([{ text: groupKey, colSpan: visibleCols.length, bold: true, fillColor: '#e0e7ff' }, ...Array(visibleCols.length - 1).fill({})]);
        for (let i = 0; i < (rows as any[]).length; i++) {
          const row = (rows as any[])[i];
          const fillColor = layout.general.zebra && i % 2 === 1 ? '#f9fafb' : undefined;
          tableBody.push(visibleCols.map(c => ({ text: formatValue(row[c.field], c.format), alignment: c.align, fillColor })));
        }
        if (layout.grouping!.showSubtotals) {
          tableBody.push([{ text: summarizeRows(rows as any[], layout.grouping!.totalizers, visibleCols), colSpan: visibleCols.length, bold: true, fillColor: '#f0f4ff' }, ...Array(visibleCols.length - 1).fill({})]);
        }
      }
    } else {
      for (let i = 0; i < data.length; i++) {
        const row = data[i];
        const fillColor = layout.general.zebra && i % 2 === 1 ? '#f9fafb' : undefined;
        tableBody.push(visibleCols.map(c => ({ text: formatValue(row[c.field], c.format), alignment: c.align, fillColor })));
      }
    }

    if (layout.footer.showTotals) {
      tableBody.push([{ text: summarizeRows(data, layout.footer.totalizers, visibleCols), colSpan: visibleCols.length, bold: true, fillColor: '#e8e8e8' }, ...Array(visibleCols.length - 1).fill({})]);
    }

    content.push({
      table: { headerRows: 1, widths: visibleCols.map(() => '*'), body: tableBody },
      layout: 'lightHorizontalLines',
    });
  }

  if (contentMode !== 'data') addChartsAtPosition('after');

  for (const sr of subreportsData) {
    content.push({ text: sr.config.title, style: 'subheader', margin: [0, 15, 0, 5] });
    const srCols = sr.config.columns;
    if (srCols.length > 0 && sr.data.length > 0) {
      const srBody: any[][] = [];
      srBody.push(srCols.map(c => ({ text: c.label, bold: true, fillColor: '#e0e0e0' })));
      for (const row of sr.data) {
        srBody.push(srCols.map(c => ({ text: formatValue(row[c.field], c.format) })));
      }
      if (sr.config.totalizers?.length) {
        srBody.push([
          { text: summarizeRows(sr.data, sr.config.totalizers, srCols), colSpan: srCols.length, bold: true, fillColor: '#f0f0f0' },
          ...Array(srCols.length - 1).fill({}),
        ]);
      }
      content.push({
        table: { headerRows: 1, widths: srCols.map(() => '*'), body: srBody },
        layout: 'lightHorizontalLines',
      });
    }
  }

  const docDefinition: any = {
    pageSize: layout.general.pageSize,
    pageOrientation: layout.general.orientation,
    pageMargins: [layout.general.margins.left, layout.general.margins.top, layout.general.margins.right, layout.general.margins.bottom],
    content,
    styles: {
      header: { fontSize: 18, bold: true, margin: [0, 0, 0, 5] },
      subheader: { fontSize: 14, bold: true, color: '#555', margin: [0, 0, 0, 5] },
    },
    defaultStyle: { fontSize: layout.general.fontSize, font: 'Roboto' },
    footer: (currentPage: number, pageCount: number) => {
      const items: any[] = [];
      if (layout.footer.showPageNumbers) items.push({ text: 'Página ' + currentPage + ' de ' + pageCount, alignment: 'center', fontSize: 9, color: '#999' });
      if (layout.footer.customText) items.push({ text: layout.footer.customText, alignment: 'center', fontSize: 9, color: '#999' });
      return { stack: items, margin: [20, 0] };
    },
  };

  pdfMake.createPdf(docDefinition).download((layout.header.title || 'relatorio') + '.pdf');
}
```

## reportExporters.ts / exportToExcel

Origem: utils/reportExporters.ts:396

Parâmetros: data: any[], layout: ReportLayout, charts: ChartConfig[], subreportsData: { config: SubreportConfig; data: any[] }[], contentMode: 'data' | 'charts' | 'both' = 'both'

```typescript
{
  const ExcelJS = (await import('exceljs')).default;
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet('Relatório');

  const visibleCols = contentMode === 'charts' ? [] : layout.columns.filter(c => c.visible);

  const headerRow = visibleCols.length ? sheet.addRow(visibleCols.map(c => c.label)) : null;
  headerRow?.eachCell(cell => {
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
    cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4472C4' } };
    cell.alignment = { horizontal: 'center' };
    cell.border = { bottom: { style: 'thin' } };
  });

  const grouped = contentMode !== 'charts' && layout.grouping ? groupData(data, layout.grouping.fields) : null;

  if (grouped) {
    for (const [groupKey, rows] of Object.entries(grouped)) {
      const gr = sheet.addRow([groupKey]);
      gr.font = { bold: true };
      gr.getCell(1).fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFE0E7FF' } };
      if (visibleCols.length > 1) sheet.mergeCells(gr.number, 1, gr.number, visibleCols.length);

      for (const row of (rows as any[])) {
        sheet.addRow(visibleCols.map(c => formatValue(row[c.field], c.format)));
      }

      if (layout.grouping!.showSubtotals) {
        const sr = sheet.addRow([summarizeRows(rows as any[], layout.grouping!.totalizers, visibleCols)]);
        sr.font = { bold: true, italic: true };
        if (visibleCols.length > 1) sheet.mergeCells(sr.number, 1, sr.number, visibleCols.length);
      }
    }
  } else if (contentMode !== 'charts') {
    for (const row of data) {
      sheet.addRow(visibleCols.map(c => formatValue(row[c.field], c.format)));
    }
  }

  if (contentMode !== 'data') {
    const sheetNames = new Set<string>();
    let chartIndex = 0;
    for (const chart of charts) {
      const summary = buildChartExport(chart, data);
      if (!summary) continue;
      chartIndex += 1;
      const baseName = summary.title.replace(/[\\/*?:[\]]/g, ' ').trim().substring(0, 25) || 'Gráfico';
      let sheetName = `${baseName} ${chartIndex}`.substring(0, 31);
      while (sheetNames.has(sheetName)) sheetName = `${baseName.substring(0, 20)} ${++chartIndex}`.substring(0, 31);
      sheetNames.add(sheetName);
      const chartSheet = workbook.addWorksheet(sheetName);
      chartSheet.addRow(summary.columns);
      for (const row of summary.rows) chartSheet.addRow(row);
      summary.columns.forEach((_, index) => { chartSheet.getColumn(index + 1).width = 22; });
    }
  }

  if (contentMode !== 'charts' && layout.footer.showTotals) {
    const totalRow = sheet.addRow([summarizeRows(data, layout.footer.totalizers, visibleCols)]);
    totalRow.font = { bold: true };
    if (visibleCols.length > 1) sheet.mergeCells(totalRow.number, 1, totalRow.number, visibleCols.length);
  }

  visibleCols.forEach((_, i) => {
    const col = sheet.getColumn(i + 1);
    let maxLen = visibleCols[i].label.length;
    col.eachCell({ includeEmpty: false }, cell => {
      const len = String(cell.value || '').length;
      if (len > maxLen) maxLen = len;
    });
    col.width = Math.min(maxLen + 4, 50);
  });

  const usedWorksheetNames = new Set(workbook.worksheets.map(item => item.name.toLocaleLowerCase()));
  for (const sr of subreportsData) {
    const baseName = sr.config.title.replace(/[\\/*?:[\]]/g, ' ').replace(/^'+|'+$/g, '').trim().slice(0, 31) || 'Subrelatório';
    let sheetName = baseName;
    let suffix = 2;
    while (usedWorksheetNames.has(sheetName.toLocaleLowerCase())) {
      const suffixText = ` ${suffix++}`;
      sheetName = `${baseName.slice(0, 31 - suffixText.length)}${suffixText}`;
    }
    usedWorksheetNames.add(sheetName.toLocaleLowerCase());
    const srSheet = workbook.addWorksheet(sheetName);
    const srCols = sr.config.columns;
    const srHeader = srSheet.addRow(srCols.map(c => c.label));
    srHeader.eachCell(cell => {
      cell.font = { bold: true, color: { argb: 'FFFFFFFF' } };
      cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF4472C4' } };
    });
    for (const row of sr.data) {
      srSheet.addRow(srCols.map(c => formatValue(row[c.field], c.format)));
    }
    if (sr.config.totalizers?.length && srCols.length) {
      const totalRow = srSheet.addRow([summarizeRows(sr.data, sr.config.totalizers, srCols)]);
      totalRow.font = { bold: true };
      if (srCols.length > 1) srSheet.mergeCells(totalRow.number, 1, totalRow.number, srCols.length);
    }
    srCols.forEach((_, i) => {
      const col = srSheet.getColumn(i + 1);
      let maxLen = srCols[i].label.length;
      col.eachCell({ includeEmpty: false }, cell => {
        const len = String(cell.value || '').length;
        if (len > maxLen) maxLen = len;
      });
      col.width = Math.min(maxLen + 4, 50);
    });
  }

  const buffer = await workbook.xlsx.writeBuffer();
  const blob = new Blob([buffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
  triggerDownload(blob, (layout.header.title || 'relatorio') + '.xlsx');
}
```

## reportExporters.ts / exportToWord

Origem: utils/reportExporters.ts:511

Parâmetros: data: any[], layout: ReportLayout, charts: ChartConfig[], subreportsData: { config: SubreportConfig; data: any[] }[], contentMode: 'data' | 'charts' | 'both' = 'both', chartImages: ExportedChartImage[] = []

```typescript
{
  let html = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">';
  html += '<head><meta charset="utf-8"><style>';
  html += 'body{font-family:' + escapeHtml(layout.general.fontFamily) + ';font-size:' + Number(layout.general.fontSize) + 'pt;}';
  html += 'table{border-collapse:collapse;width:100%;}';
  html += 'th,td{border:1px solid #999;padding:4px 8px;}';
  html += 'th{background:#d0d0d0;font-weight:bold;}';
  html += '@page{size:' + escapeHtml(layout.general.pageSize) + ' ' + escapeHtml(layout.general.orientation) + ';}';
  html += '</style></head><body>';

  if (layout.header.show) {
    const align = layout.header.alignment || 'center';
    if (layout.header.title) html += '<h1 style="text-align:' + escapeHtml(align) + ';">' + escapeHtml(layout.header.title) + '</h1>';
    if (layout.header.subtitle) html += '<h3 style="text-align:' + escapeHtml(align) + ';color:#555;">' + escapeHtml(layout.header.subtitle) + '</h3>';
    if (layout.header.showDate) html += '<p style="text-align:' + escapeHtml(align) + ';color:#999;">' + new Date().toLocaleDateString('pt-BR') + '</p>';
  }

  if (contentMode !== 'charts') html += buildHTMLTable(data, layout);

  if (contentMode !== 'data') {
    for (const image of chartImages) {
      html += `<figure style="margin:16px 0;text-align:center"><img src="${escapeHtml(image.src)}" alt="${escapeHtml(image.title)}" style="max-width:100%;height:auto"><figcaption>${escapeHtml(image.title)}</figcaption></figure>`;
    }
    for (const chart of charts) {
      const summary = buildChartExport(chart, data);
      if (!summary) continue;
      html += `<h3 style="margin-top:20px;">${escapeHtml(summary.title)}</h3><table><thead><tr>${summary.columns.map(column => `<th>${escapeHtml(column)}</th>`).join('')}</tr></thead><tbody>${summary.rows.map(row => `<tr>${row.map(value => `<td>${escapeHtml(value)}</td>`).join('')}</tr>`).join('')}</tbody></table>`;
    }
  }

  for (const sr of subreportsData) {
    html += '<h3 style="margin-top:20px;">' + escapeHtml(sr.config.title) + '</h3>';
    const srCols = sr.config.columns;
    html += '<table><thead><tr>';
    for (const col of srCols) html += '<th>' + escapeHtml(col.label) + '</th>';
    html += '</tr></thead><tbody>';
    for (const row of sr.data) {
      html += '<tr>';
      for (const col of srCols) html += '<td>' + escapeHtml(formatValue(row[col.field], col.format)) + '</td>';
      html += '</tr>';
    }
    html += '</tbody>';
    if (sr.config.totalizers?.length) {
      html += '<tfoot><tr><td colspan="' + srCols.length + '">' +
        escapeHtml(summarizeRows(sr.data, sr.config.totalizers, srCols)) + '</td></tr></tfoot>';
    }
    html += '</table>';
  }

  if (layout.footer.show && layout.footer.customText) {
    html += '<p style="margin-top:20px;color:#666;">' + escapeHtml(layout.footer.customText) + '</p>';
  }

  html += '</body></html>';

  const blob = new Blob(['\ufeff' + html], { type: 'application/msword' });
  triggerDownload(blob, (layout.header.title || 'relatorio') + '.doc');
}
```

## reportExporters.ts / exportToCSV

Origem: utils/reportExporters.ts:570

Parâmetros: data: any[], layout: ReportLayout, charts: ChartConfig[] = [], subreportsData: { config: SubreportConfig; data: any[] }[] = [], contentMode: 'data' | 'charts' | 'both' = 'both'

```typescript
{
  const visibleCols = contentMode === 'charts' ? [] : layout.columns.filter(c => c.visible);
  const lines: string[] = [];
  const pushSection = (title: string, headers: string[], rows: unknown[][]) => {
    if (lines.length) lines.push('');
    lines.push(`"${title.replace(/"/g, '""')}"`);
    lines.push(headers.map(value => `"${String(value).replace(/"/g, '""')}"`).join(';'));
    for (const row of rows) {
      lines.push(row.map(value => {
        let formatted = String(value ?? '');
        if (/^[\s]*[=+\-@\t\r]/.test(formatted)) formatted = `'${formatted}`;
        return `"${formatted.replace(/"/g, '""')}"`;
      }).join(';'));
    }
  };
  if (contentMode !== 'charts') {
    const rows = data.map(row => visibleCols.map(column => formatValue(row[column.field], column.format)));
    if (layout.footer.showTotals && visibleCols.length) {
      rows.push([summarizeRows(data, layout.footer.totalizers, visibleCols), ...Array(visibleCols.length - 1).fill('')]);
    }
    pushSection(layout.header.title || 'Relatório',
      visibleCols.map(column => column.label),
      rows);
  }
  if (contentMode !== 'data') {
    for (const chart of charts) {
      const summary = buildChartExport(chart, data);
      if (summary) pushSection(summary.title, summary.columns, summary.rows);
    }
  }
  for (const subreport of subreportsData) {
    const rows = subreport.data.map(row => subreport.config.columns.map(column => formatValue(row[column.field], column.format)));
    if (subreport.config.totalizers?.length && subreport.config.columns.length) {
      rows.push([summarizeRows(subreport.data, subreport.config.totalizers, subreport.config.columns), ...Array(subreport.config.columns.length - 1).fill('')]);
    }
    pushSection(subreport.config.title, subreport.config.columns.map(column => column.label),
      rows);
  }
  const bom = '\uFEFF';
  const blob = new Blob([bom + lines.join('\r\n')], { type: 'text/csv;charset=utf-8;' });
  triggerDownload(blob, (layout.header.title || 'relatorio') + '.csv');
}
```

## reportExporters.ts / exportToHTML

Origem: utils/reportExporters.ts:613

Parâmetros: data: any[], layout: ReportLayout, charts: ChartConfig[], subreportsData: { config: SubreportConfig; data: any[] }[], contentMode: 'data' | 'charts' | 'both' = 'both', chartImages: ExportedChartImage[] = []

```typescript
{
  const html = buildFullHTML(data, layout, charts, subreportsData, contentMode, chartImages);
  const blob = new Blob([html], { type: 'text/html;charset=utf-8;' });
  triggerDownload(blob, (layout.header.title || 'relatorio') + '.html');
}
```

## reportSecurity.js / isReadOnlyQuery

Origem: server/lib/reportSecurity.js:1

Parâmetros: sql

```typescript
{
  if (typeof sql !== 'string' || sql.length > 100_000) return false;
  const withoutComments = sql.replace(/--.*$/gm, '').replace(/\/\*[\s\S]*?\*\//g, '').trim();
  const normalized = withoutComments.replace(/;\s*$/, '').trim().toUpperCase();
  if (!normalized || normalized.includes(';')) return false;
  const forbidden = ['INSERT', 'UPDATE', 'DELETE', 'DROP', 'ALTER', 'TRUNCATE', 'CREATE', 'GRANT', 'REVOKE', 'COPY'];
  for (const keyword of forbidden) {
    if (new RegExp(`\\b${keyword}\\b`).test(normalized)) return false;
  }
  if (/\bSELECT\b[\s\S]*?\bINTO\b|\bFOR\s+(UPDATE|SHARE|NO\s+KEY\s+UPDATE|KEY\s+SHARE)\b/.test(normalized)) return false;
  if (/\b(NEXTVAL|SETVAL|PG_ADVISORY_[A-Z_]+|PG_SLEEP|PG_READ_FILE|PG_WRITE_FILE|DBLINK)\s*\(/.test(normalized)) return false;
  return normalized.startsWith('SELECT') || normalized.startsWith('WITH');
}
```

## reportSecurity.js / wrapReadOnlyQueryWithLimit

Origem: server/lib/reportSecurity.js:15

Parâmetros: sql, limit

```typescript
{
  return `SELECT * FROM (${sql.trim().replace(/;\s*$/, '')}) AS _report_result LIMIT ${limit}`;
}
```

## reportSecurity.js / getVisibleReportTemplate

Origem: server/lib/reportSecurity.js:19

Parâmetros: pool, user, templateId

```typescript
{
  const groupIds = Array.isArray(user.groupIds) ? user.groupIds : [];
  const result = await pool.query(`
    SELECT id, sql_query, filters, subreports FROM report_templates
    WHERE id = $1 AND is_active = true
      AND (
        allowed_users IS NULL AND allowed_groups IS NULL
        OR allowed_users @> ARRAY[$2]::uuid[]
        OR allowed_groups && $3::uuid[]
      )
  `, [templateId, user.id, groupIds]);
  return result.rows[0] || null;
}
```

## reportSecurity.js / validateReportSql

Origem: server/lib/reportSecurity.js:33

Parâmetros: sqlQuery

```typescript
{
  if (!sqlQuery || typeof sqlQuery !== 'string') {
    return 'sql_query é obrigatório e deve ser uma string.';
  }
  if (!isReadOnlyQuery(sqlQuery)) {
    return 'A query contém comandos não permitidos. Apenas consultas SELECT (ou WITH ... SELECT) são aceitas. ' +
      'Comandos como INSERT, UPDATE, DELETE, DROP, ALTER, TRUNCATE, CREATE, GRANT, REVOKE e COPY são proibidos.';
  }
  return null;
}
```

## reportSecurity.js / validateReportDefinition

Origem: server/lib/reportSecurity.js:44

Parâmetros: body = {}

```typescript
{
  const filters = body.filters === undefined ? [] : body.filters;
  const subreports = body.subreports === undefined ? [] : body.subreports;
  if (!Array.isArray(filters) || filters.length > 50) return 'A lista de filtros é inválida.';
  if (!Array.isArray(subreports) || subreports.length > 25) return 'A lista de subrelatórios é inválida.';
  const filterIds = new Set();
  for (const filter of filters) {
    if (!filter || typeof filter.id !== 'string' || !filter.id || typeof filter.placeholder !== 'string' ||
        !filter.placeholder.split('.').every(part => /^[A-Za-z_][A-Za-z0-9_]*$/.test(part)) ||
        !['text', 'date', 'number', 'select'].includes(filter.type) ||
        filterIds.has(filter.id)) {
      return 'Um ou mais filtros são inválidos.';
    }
    filterIds.add(filter.id);
  }
  for (const subreport of subreports) {
    if (!subreport || typeof subreport.id !== 'string' || !subreport.id ||
        !['query', 'summary'].includes(subreport.type)) {
      return 'Um ou mais subrelatórios são inválidos.';
    }
    if (subreport.type === 'query') {
      const sqlError = validateReportSql(subreport.sql_query);
      if (sqlError) return `Subrelatório "${subreport.title || ''}": ${sqlError}`;
    }
    if (subreport.type === 'summary' && !subreport.summary_config) {
      return `Subrelatório "${subreport.title || ''}": configuração de resumo inválida.`;
    }
  }
  if (body.target_layout !== undefined && !['responsive', 'web', 'mobile'].includes(body.target_layout)) {
    return 'Layout de destino inválido.';
  }
  if (body.content_mode !== undefined && !['data', 'charts', 'both'].includes(body.content_mode)) {
    return 'Modo de conteúdo inválido.';
  }
  return null;
}
```

## index.js / buildParameterizedQueryServer

Origem: server/index.js:1278

Parâmetros: sql, filters, filterValues

```typescript
{
  const params = [];
  let paramIndex = 1;
  let processedSql = sql;
  const vals = (filterValues && typeof filterValues === 'object') ? filterValues : {};
  for (const f of (Array.isArray(filters) ? filters : [])) {
    if (!f || typeof f.placeholder !== 'string') continue;
    const val = vals[f.id] !== undefined ? vals[f.id] : (f.defaultValue || '');
    const escapedName = f.placeholder.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const doubleBrace = new RegExp('\\{\\{' + escapedName + '\\}\\}', 'g');
    const colonStyle = new RegExp(':' + escapedName + '\\b', 'g');
    const matchesBrace = doubleBrace.test(processedSql);
    doubleBrace.lastIndex = 0;
    const matchesColon = !matchesBrace && colonStyle.test(processedSql);
    colonStyle.lastIndex = 0;
    if (matchesBrace) {
      const token = `$${paramIndex}`;
      processedSql = processedSql.replace(doubleBrace, () => token);
      params.push(val);
      paramIndex++;
    } else if (matchesColon) {
      const token = `$${paramIndex}`;
      processedSql = processedSql.replace(colonStyle, () => token);
      params.push(val);
      paramIndex++;
    }
  }
  return { sql: processedSql, params };
}
```

## index.js / requireAdminRole

Origem: server/index.js:1537

Parâmetros: req, res, next

```typescript
{
  const role = req.jwtPayload?.userRole;
  if (!role || role !== 'ADMIN') {
    return res.status(403).json({ error: 'Apenas administradores podem criar ou editar templates de relatório.' });
  }
  next();
}
```

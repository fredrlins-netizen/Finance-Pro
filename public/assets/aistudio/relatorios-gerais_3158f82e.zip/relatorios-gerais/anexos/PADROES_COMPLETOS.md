# Catálogos e padrões completos

Valores estáticos ou exemplos de fábrica. UUID e datas são gerados em execução; marcadores não são valores de registros reais.

## REPORT_CATEGORIES

```json
[
  "Cadastrais",
  "Financeiro",
  "Comercial",
  "Jurídico",
  "Negociação",
  "Cobrança",
  "Administrativo",
  "Gerenciais",
  "Outros"
]
```

## COLUMN_FORMATS

```json
[
  {
    "value": "text",
    "label": "Texto"
  },
  {
    "value": "number",
    "label": "Número"
  },
  {
    "value": "currency_brl",
    "label": "Moeda BRL"
  },
  {
    "value": "date",
    "label": "Data"
  },
  {
    "value": "cpf_cnpj",
    "label": "CPF/CNPJ"
  },
  {
    "value": "percent",
    "label": "Percentual"
  }
]
```

## AGGREGATION_OPTIONS

```json
[
  {
    "value": "nenhum",
    "label": "Nenhum"
  },
  {
    "value": "soma",
    "label": "Soma"
  },
  {
    "value": "contagem",
    "label": "Contagem"
  },
  {
    "value": "media",
    "label": "Média"
  },
  {
    "value": "min",
    "label": "Mín"
  },
  {
    "value": "max",
    "label": "Máx"
  }
]
```

## COLOR_PALETTES

```json
{
  "padrao": [
    "#3B82F6",
    "#EF4444",
    "#10B981",
    "#F59E0B",
    "#8B5CF6",
    "#EC4899",
    "#06B6D4",
    "#F97316"
  ],
  "pastel": [
    "#93C5FD",
    "#FCA5A5",
    "#6EE7B7",
    "#FDE68A",
    "#C4B5FD",
    "#FBCFE8",
    "#67E8F9",
    "#FDBA74"
  ],
  "escuro": [
    "#1E3A5F",
    "#7F1D1D",
    "#064E3B",
    "#78350F",
    "#4C1D95",
    "#831843",
    "#164E63",
    "#9A3412"
  ],
  "monocromatico": [
    "#1E40AF",
    "#2563EB",
    "#3B82F6",
    "#60A5FA",
    "#93C5FD",
    "#BFDBFE",
    "#DBEAFE",
    "#EFF6FF"
  ]
}
```

## DEFAULT_LAYOUT

```json
{
  "header": {
    "show": true,
    "title": "",
    "subtitle": "",
    "logo": "",
    "alignment": "left",
    "showDate": true,
    "showLogo": true
  },
  "columns": [],
  "grouping": null,
  "footer": {
    "show": true,
    "showTotals": false,
    "totalizers": [],
    "showPageNumbers": true,
    "showDateTime": false,
    "customText": ""
  },
  "general": {
    "pageSize": "A4",
    "orientation": "portrait",
    "fontSize": 12,
    "fontFamily": "Arial",
    "zebra": true,
    "margins": {
      "top": 20,
      "bottom": 20,
      "left": 15,
      "right": 15
    }
  }
}
```

## MODELO_NOVO

```json
{
  "id": "",
  "name": "",
  "description": "",
  "category": "Outros",
  "target_layout": "responsive",
  "content_mode": "both",
  "sql_query": "",
  "layout": {
    "header": {
      "show": true,
      "title": "",
      "subtitle": "",
      "logo": "",
      "alignment": "left",
      "showDate": true,
      "showLogo": true
    },
    "columns": [],
    "grouping": null,
    "footer": {
      "show": true,
      "showTotals": false,
      "totalizers": [],
      "showPageNumbers": true,
      "showDateTime": false,
      "customText": ""
    },
    "general": {
      "pageSize": "A4",
      "orientation": "portrait",
      "fontSize": 12,
      "fontFamily": "Arial",
      "zebra": true,
      "margins": {
        "top": 20,
        "bottom": 20,
        "left": 15,
        "right": 15
      }
    }
  },
  "filters": [],
  "subreports": [],
  "charts": [],
  "allowed_users": null,
  "allowed_groups": null,
  "created_by": null,
  "created_at": "<ISO da data/hora de criação no navegador>",
  "updated_at": "<ISO da data/hora de criação no navegador>",
  "is_active": true
}
```

## GRAFICO_NOVO

```json
{
  "id": "<UUID gerado em tempo de execução>",
  "type": "bar",
  "subType": "vertical",
  "title": "",
  "xField": "",
  "yFields": [],
  "colors": [
    "#3B82F6",
    "#EF4444",
    "#10B981",
    "#F59E0B",
    "#8B5CF6",
    "#EC4899",
    "#06B6D4",
    "#F97316"
  ],
  "palette": "padrao",
  "position": "after",
  "width": "100%",
  "showLegend": true,
  "showDataLabels": false,
  "showGrid": true
}
```

## FILTRO_NOVO

```json
{
  "id": "<UUID gerado em tempo de execução>",
  "placeholder": "campo",
  "label": "",
  "type": "text",
  "defaultValue": "",
  "options": []
}
```

## ChartConfig.tsx:CHART_TYPES

```json
[
  {
    "value": "bar",
    "label": "Barra"
  },
  {
    "value": "pie",
    "label": "Pizza"
  },
  {
    "value": "line",
    "label": "Linhas"
  },
  {
    "value": "mixed",
    "label": "Misto (Barra+Linha)"
  }
]
```

## ChartConfig.tsx:SUBTYPES

```json
{
  "bar": [
    {
      "value": "vertical",
      "label": "Vertical"
    },
    {
      "value": "horizontal",
      "label": "Horizontal"
    },
    {
      "value": "stacked",
      "label": "Empilhado"
    }
  ],
  "pie": [
    {
      "value": "pizza",
      "label": "Pizza"
    },
    {
      "value": "donut",
      "label": "Rosca (Donut)"
    }
  ],
  "line": [
    {
      "value": "line",
      "label": "Linha"
    },
    {
      "value": "area",
      "label": "Área (preenchido)"
    }
  ],
  "mixed": []
}
```

## ChartConfig.tsx:Y_OPERATIONS

```json
[
  {
    "value": "direto",
    "label": "Valor direto"
  },
  {
    "value": "soma",
    "label": "Soma"
  },
  {
    "value": "contagem",
    "label": "Contagem"
  },
  {
    "value": "media",
    "label": "Média"
  }
]
```

## WhereBuilder.tsx:OPERATORS

```json
[
  {
    "value": "=",
    "label": "="
  },
  {
    "value": "!=",
    "label": "!="
  },
  {
    "value": ">",
    "label": ">"
  },
  {
    "value": "<",
    "label": "<"
  },
  {
    "value": ">=",
    "label": ">="
  },
  {
    "value": "<=",
    "label": "<="
  },
  {
    "value": "LIKE",
    "label": "LIKE"
  },
  {
    "value": "IN",
    "label": "IN"
  },
  {
    "value": "BETWEEN",
    "label": "BETWEEN"
  },
  {
    "value": "IS NULL",
    "label": "IS NULL"
  },
  {
    "value": "IS NOT NULL",
    "label": "IS NOT NULL"
  }
]
```

## WhereBuilder.tsx:noValueOperators

```json
[
  "IS NULL",
  "IS NOT NULL"
]
```

## SubreportsTab.tsx:FORMAT_OPTIONS

```json
[
  {
    "value": "",
    "label": "Nenhum"
  },
  {
    "value": "text",
    "label": "Texto"
  },
  {
    "value": "number",
    "label": "Número"
  },
  {
    "value": "currency",
    "label": "Moeda (R$)"
  },
  {
    "value": "percent",
    "label": "Percentual (%)"
  },
  {
    "value": "date",
    "label": "Data"
  },
  {
    "value": "datetime",
    "label": "Data/Hora"
  }
]
```

## SubreportsTab.tsx:OPERATION_OPTIONS

```json
[
  {
    "value": "none",
    "label": "Nenhum"
  },
  {
    "value": "sum",
    "label": "Soma"
  },
  {
    "value": "count",
    "label": "Contagem"
  },
  {
    "value": "avg",
    "label": "Média"
  },
  {
    "value": "min",
    "label": "Mín"
  },
  {
    "value": "max",
    "label": "Máx"
  }
]
```

## GuideTab.tsx:SECTIONS

```json
[
  {
    "id": "visao_geral",
    "label": "Visao Geral"
  },
  {
    "id": "fonte_dados",
    "label": "Fonte de Dados"
  },
  {
    "id": "layout",
    "label": "Layout"
  },
  {
    "id": "graficos",
    "label": "Graficos"
  },
  {
    "id": "subreports",
    "label": "Sub-relatorios"
  },
  {
    "id": "preview",
    "label": "Preview e Exportacao"
  },
  {
    "id": "modelos",
    "label": "Modelos de Relatorios"
  },
  {
    "id": "tabelas",
    "label": "Tabelas do Banco"
  },
  {
    "id": "sql_ref",
    "label": "Referencia SQL"
  },
  {
    "id": "dicas",
    "label": "Dicas e Solucoes"
  }
]
```

## ReportBuilder.tsx:TABS

```json
[
  {
    "id": "datasource",
    "label": "Fonte de Dados"
  },
  {
    "id": "layout",
    "label": "Layout"
  },
  {
    "id": "charts",
    "label": "Gráficos"
  },
  {
    "id": "filters",
    "label": "Filtros"
  },
  {
    "id": "subreports",
    "label": "Subrelatórios"
  },
  {
    "id": "guide",
    "label": "Guia"
  }
]
```

# Todos os controles e seus acionamentos

Extração sintática das 21 unidades do construtor. Rótulos próximos são auxiliares; vínculo, arquivo e linha identificam o controle. Campos condicionais e controles repetidos são descritos por suas expressões. onChange/onClick são as ações efetivamente conectadas, não apenas descrições de intenção.

## ChartConfig.tsx — 19 controles

### button: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/ChartConfig.tsx:102

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => onMove(-1) |
| disabled | index === 0 |
| contexto |  |

### button: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/ChartConfig.tsx:111

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => onMove(1) |
| disabled | index === total - 1 |
| contexto |  |

### button: Remover gráfico

Origem: components/relatorios/report-builder/ChartConfig.tsx:124

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | onRemove |
| title | Remover gráfico |
| contexto |  |

### select: Tipo

Origem: components/relatorios/report-builder/ChartConfig.tsx:139

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | chart.type |
| onChange | (e) => handleTypeChange(e.target.value as ChartMainType) |
| contexto |  |

### select: Subtipo

Origem: components/relatorios/report-builder/ChartConfig.tsx:152

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | chart.subType |
| onChange | (e) => update({ subType: e.target.value }) |
| contexto | SUBTYPES[chart.type].length > 0 |

### input: Título do gráfico

Origem: components/relatorios/report-builder/ChartConfig.tsx:167

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | chart.title |
| onChange | (e) => update({ title: e.target.value }) |
| placeholder | Título opcional |
| contexto |  |

### select: Eixo X (categorias)

Origem: components/relatorios/report-builder/ChartConfig.tsx:179

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | chart.xField |
| onChange | (e) => update({ xField: e.target.value }) |
| contexto |  |

### select: Adicionar campo Y

Origem: components/relatorios/report-builder/ChartConfig.tsx:192

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value |  |
| onChange | (e) => { if (e.target.value) addYField(e.target.value); } |
| contexto |  |

### input: Séries Y configuradas

Origem: components/relatorios/report-builder/ChartConfig.tsx:210

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | color |
| value | yf.color |
| onChange | (e) => updateYField(i, { color: e.target.value }) |
| contexto | Repetido por chart.yFields.map ; chart.yFields.length > 0 |

### select: Séries Y configuradas

Origem: components/relatorios/report-builder/ChartConfig.tsx:217

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | yf.operation |
| onChange | (e) => updateYField(i, { operation: e.target.value as YFieldConfig['operation'] }) |
| contexto | Repetido por chart.yFields.map ; chart.yFields.length > 0 |

### select: Séries Y configuradas

Origem: components/relatorios/report-builder/ChartConfig.tsx:228

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | yf.seriesType \|\| 'bar' |
| onChange | (e) => updateYField(i, { seriesType: e.target.value as 'bar' \| 'line' }) |
| contexto | chart.type === 'mixed' ; Repetido por chart.yFields.map ; chart.yFields.length > 0 |

### input: Eixo 2

Origem: components/relatorios/report-builder/ChartConfig.tsx:237

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | yf.secondaryAxis \|\| false |
| onChange | (e) => updateYField(i, { secondaryAxis: e.target.checked }) |
| contexto | chart.type === 'mixed' ; Repetido por chart.yFields.map ; chart.yFields.length > 0 |

### button: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/ChartConfig.tsx:247

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => removeYField(i) |
| contexto | Repetido por chart.yFields.map ; chart.yFields.length > 0 |

### select: Paleta de cores

Origem: components/relatorios/report-builder/ChartConfig.tsx:263

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | chart.palette |
| onChange | (e) => handlePaletteChange(e.target.value) |
| contexto |  |

### select: Posição

Origem: components/relatorios/report-builder/ChartConfig.tsx:280

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | chart.position |
| onChange | (e) => update({ position: e.target.value as ChartConfigType['position'] }) |
| contexto |  |

### select: Largura

Origem: components/relatorios/report-builder/ChartConfig.tsx:292

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | chart.width |
| onChange | (e) => update({ width: e.target.value as '100%' \| '50%' }) |
| contexto |  |

### input: Legenda

Origem: components/relatorios/report-builder/ChartConfig.tsx:305

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | chart.showLegend |
| onChange | (e) => update({ showLegend: e.target.checked }) |
| contexto |  |

### input: Rótulos de dados

Origem: components/relatorios/report-builder/ChartConfig.tsx:314

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | chart.showDataLabels |
| onChange | (e) => update({ showDataLabels: e.target.checked }) |
| contexto |  |

### input: Grade

Origem: components/relatorios/report-builder/ChartConfig.tsx:323

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | chart.showGrid |
| onChange | (e) => update({ showGrid: e.target.checked }) |
| contexto |  |


## ChartPreview.tsx — 0 controles


## ChartsTab.tsx — 1 controles

### button: Adicionar Gráfico

Origem: components/relatorios/report-builder/ChartsTab.tsx:41

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | addChart |
| contexto |  |


## ColumnConfig.tsx — 7 controles

### button: Mover para cima

Origem: components/relatorios/report-builder/ColumnConfig.tsx:41

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => moveColumn(i, -1) |
| disabled | i === 0 |
| title | Mover para cima |
| contexto | Repetido por columns.map |

### button: Mover para baixo

Origem: components/relatorios/report-builder/ColumnConfig.tsx:51

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => moveColumn(i, 1) |
| disabled | i === columns.length - 1 |
| title | Mover para baixo |
| contexto | Repetido por columns.map |

### input: Visível

Origem: components/relatorios/report-builder/ColumnConfig.tsx:65

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | col.visible |
| onChange | (e) => updateColumn(i, { visible: e.target.checked }) |
| contexto | Repetido por columns.map |

### input: Rótulo

Origem: components/relatorios/report-builder/ColumnConfig.tsx:77

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | col.label |
| onChange | (e) => updateColumn(i, { label: e.target.value }) |
| placeholder | col.field |
| contexto | Repetido por columns.map |

### input: Largura (%)

Origem: components/relatorios/report-builder/ColumnConfig.tsx:87

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | col.width |
| onChange | (e) => updateColumn(i, { width: e.target.value }) |
| placeholder | auto |
| contexto | Repetido por columns.map |

### select: Alinhamento

Origem: components/relatorios/report-builder/ColumnConfig.tsx:97

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | col.align |
| onChange | (e) => updateColumn(i, { align: e.target.value as ColumnDef['align'] }) |
| contexto | Repetido por columns.map |

### select: Formato

Origem: components/relatorios/report-builder/ColumnConfig.tsx:109

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | col.format |
| onChange | (e) => updateColumn(i, { format: e.target.value as ColumnDef['format'] }) |
| contexto | Repetido por columns.map |


## DataSourceTab.tsx — 14 controles

### button: Visual

Origem: components/relatorios/report-builder/DataSourceTab.tsx:260

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setMode('visual') |
| contexto |  |

### button: SQL

Origem: components/relatorios/report-builder/DataSourceTab.tsx:268

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setMode('sql') |
| contexto |  |

### button: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/DataSourceTab.tsx:302

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => handleToggleColumn(col.table, col.column, col.type) |
| contexto | Repetido por selectedColumns.map ; selectedColumns.length > 0 ; mode === 'visual' ? ... : ... |

### button: + Adicionar

Origem: components/relatorios/report-builder/DataSourceTab.tsx:324

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | handleAddOrderBy |
| contexto | mode === 'visual' ? ... : ... |

### select: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/DataSourceTab.tsx:334

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | ob |
| onChange | (e) => setOrderBy((prev) => prev.map((v, i) => (i === idx ? e.target.value : v))) |
| contexto | Repetido por orderBy.map ; orderBy.length === 0 ? ... : ... ; mode === 'visual' ? ... : ... |

### button: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/DataSourceTab.tsx:345

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setOrderBy((prev) => prev.filter((_, i) => i !== idx)) |
| contexto | Repetido por orderBy.map ; orderBy.length === 0 ? ... : ... ; mode === 'visual' ? ... : ... |

### button: + Adicionar

Origem: components/relatorios/report-builder/DataSourceTab.tsx:362

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | handleAddGroupBy |
| contexto | mode === 'visual' ? ... : ... |

### select: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/DataSourceTab.tsx:372

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | gb |
| onChange | (e) => setGroupBy((prev) => prev.map((v, i) => (i === idx ? e.target.value : v))) |
| contexto | Repetido por groupBy.map ; groupBy.length === 0 ? ... : ... ; mode === 'visual' ? ... : ... |

### button: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/DataSourceTab.tsx:383

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setGroupBy((prev) => prev.filter((_, i) => i !== idx)) |
| contexto | Repetido por groupBy.map ; groupBy.length === 0 ? ... : ... ; mode === 'visual' ? ... : ... |

### button: Executar Preview

Origem: components/relatorios/report-builder/DataSourceTab.tsx:404

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | executePreview |
| contexto | rawSql ; mode === 'visual' ? ... : ... |

### button: Histórico ( {history.length} )

Origem: components/relatorios/report-builder/DataSourceTab.tsx:429

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setShowHistory(!showHistory) |
| contexto | mode === 'visual' ? ... : ... |

### button: Executar Preview

Origem: components/relatorios/report-builder/DataSourceTab.tsx:435

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | executePreview |
| disabled | !rawSql.trim() \|\| previewLoading |
| contexto | mode === 'visual' ? ... : ... |

### textarea: SELECT * FROM tabela WHERE ...

Origem: components/relatorios/report-builder/DataSourceTab.tsx:445

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | textarea |
| value | rawSql |
| onChange | (e) => setRawSql(e.target.value) |
| onBlur | handleSqlBlur |
| placeholder | SELECT * FROM tabela WHERE ... |
| rows | 10 |
| spellCheck | false |
| contexto | mode === 'visual' ? ... : ... |

### button: {entry.sql} {new Date(entry.timestamp).toLocaleTimeString('pt-BR')}

Origem: components/relatorios/report-builder/DataSourceTab.tsx:461

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| key | entry.timestamp |
| onClick | () => loadFromHistory(entry) |
| contexto | Repetido por history.map ; showHistory && history.length > 0 ; mode === 'visual' ? ... : ... |


## FiltersTab.tsx — 11 controles

### button: Adicionar Filtro

Origem: components/relatorios/report-builder/FiltersTab.tsx:64

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | addFilter |
| contexto |  |

### button: Mover para cima

Origem: components/relatorios/report-builder/FiltersTab.tsx:99

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => moveFilter(i, -1) |
| disabled | i === 0 |
| title | Mover para cima |
| contexto | Repetido por filters.map |

### button: Mover para baixo

Origem: components/relatorios/report-builder/FiltersTab.tsx:109

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => moveFilter(i, 1) |
| disabled | i === filters.length - 1 |
| title | Mover para baixo |
| contexto | Repetido por filters.map |

### button: Remover filtro

Origem: components/relatorios/report-builder/FiltersTab.tsx:119

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => removeFilter(f.id) |
| title | Remover filtro |
| contexto | Repetido por filters.map |

### input: Rótulo (exibido ao usuário)

Origem: components/relatorios/report-builder/FiltersTab.tsx:136

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | f.label |
| onChange | e => updateFilter(f.id, { label: e.target.value }) |
| placeholder | Ex: Período, Status, Cliente... |
| contexto | expandedId === f.id ; Repetido por filters.map |

### select: Coluna / Campo

Origem: components/relatorios/report-builder/FiltersTab.tsx:147

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | f.placeholder |
| onChange | e => updateFilter(f.id, { placeholder: e.target.value }) |
| contexto | availableColumns.length > 0 ? ... : ... ; expandedId === f.id ; Repetido por filters.map |

### input: Coluna / Campo

Origem: components/relatorios/report-builder/FiltersTab.tsx:157

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | f.placeholder |
| onChange | e => updateFilter(f.id, { placeholder: e.target.value }) |
| placeholder | nome_da_coluna |
| contexto | availableColumns.length > 0 ? ... : ... ; expandedId === f.id ; Repetido por filters.map |

### select: Tipo de filtro

Origem: components/relatorios/report-builder/FiltersTab.tsx:168

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | f.type |
| onChange | e => updateFilter(f.id, { type: e.target.value as FilterConfig['type'] }) |
| contexto | expandedId === f.id ; Repetido por filters.map |

### input: Valor padrão (opcional)

Origem: components/relatorios/report-builder/FiltersTab.tsx:181

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | f.defaultValue |
| onChange | e => updateFilter(f.id, { defaultValue: e.target.value }) |
| placeholder | Deixe em branco para mostrar tudo |
| contexto | expandedId === f.id ; Repetido por filters.map |

### textarea: Opções da lista (uma por linha)

Origem: components/relatorios/report-builder/FiltersTab.tsx:196

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | textarea |
| value | (f.options \|\| []).join('\n') |
| onChange | e => updateFilter(f.id, { options: e.target.value.split('\n').map(s => s.trim()).filter(Boolean) }) |
| rows | 4 |
| placeholder | 'Ativo\nInativo\nPendente' |
| contexto | f.type === 'select' ; expandedId === f.id ; Repetido por filters.map |

### button: + Adicionar primeiro filtro

Origem: components/relatorios/report-builder/FiltersTab.tsx:235

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | addFilter |
| contexto | filters.length === 0 |


## GroupConfig.tsx — 4 controles

### button: {field}

Origem: components/relatorios/report-builder/GroupConfig.tsx:68

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| key | field |
| onClick | () => toggleGroupField(field) |
| contexto | Repetido por availableFields.map |

### input: Template do cabeçalho do grupo

Origem: components/relatorios/report-builder/GroupConfig.tsx:87

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | grouping.headerTemplate |
| onChange | (e) => updateHeaderTemplate(e.target.value) |
| placeholder | Ex: Grupo: {campo} - Total de registros: {count} |
| contexto | grouping && grouping.fields.length > 0 |

### input: Exibir subtotais no rodapé do grupo

Origem: components/relatorios/report-builder/GroupConfig.tsx:98

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | grouping.showSubtotals |
| onChange | (e) => updateSubtotals(e.target.checked) |
| contexto | grouping && grouping.fields.length > 0 |

### select: Totalizadores por coluna

Origem: components/relatorios/report-builder/GroupConfig.tsx:114

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | getTotalizerOp(col.field) |
| onChange | (e) => updateTotalizer(col.field, e.target.value as AggregationOp) |
| contexto | Repetido por numericColumns.map ; grouping.showSubtotals && numericColumns.length > 0 ; grouping && grouping.fields.length > 0 |


## GuideTab.tsx — 1 controles

### button: {s.label}

Origem: components/relatorios/report-builder/GuideTab.tsx:964

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| key | s.id |
| onClick | () => setActiveSection(s.id) |
| contexto | Repetido por SECTIONS.map |


## HeaderFooterConfig.tsx — 11 controles

### input: Título

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:26

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | header.title |
| onChange | (e) => onChange({ ...header, title: e.target.value }) |
| placeholder | Título do relatório |
| contexto |  |

### input: Subtítulo

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:36

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | header.subtitle |
| onChange | (e) => onChange({ ...header, subtitle: e.target.value }) |
| placeholder | Subtítulo opcional |
| contexto |  |

### input: Logotipo

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:48

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | header.logo |
| onChange | (e) => onChange({ ...header, logo: e.target.value }) |
| placeholder | URL da imagem ou clique para fazer upload |
| contexto |  |

### input: Logotipo

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:55

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| ref | fileRef |
| type | file |
| accept | image/* |
| onChange | handleLogoFile |
| contexto |  |

### button: Fazer upload de arquivo

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:56

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => fileRef.current?.click() |
| contexto |  |

### button: {align === 'left' ? 'Esquerda' : align === 'center' ? 'Centro' : 'Direita'}

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:74

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| key | align |
| onClick | () => onChange({ ...header, alignment: align }) |
| contexto | Repetido por (['left', 'center', 'right'] as const).map |

### input: Exibir totalizadores gerais

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:121

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | footer.showTotals |
| onChange | (e) => onChange({ ...footer, showTotals: e.target.checked }) |
| contexto |  |

### select: Exibir totalizadores gerais / Exibir "Página X de Y" / Exibir data/hora de geração

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:135

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | getTotalizerOp(col.field) |
| onChange | (e) => updateTotalizer(col.field, e.target.value as AggregationOp) |
| contexto | Repetido por numericColumns.map ; footer.showTotals && numericColumns.length > 0 |

### input: Exibir "Página X de Y"

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:150

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | footer.showPageNumbers |
| onChange | (e) => onChange({ ...footer, showPageNumbers: e.target.checked }) |
| contexto |  |

### input: Exibir data/hora de geração

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:160

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | footer.showDateTime |
| onChange | (e) => onChange({ ...footer, showDateTime: e.target.checked }) |
| contexto |  |

### input: Texto personalizado

Origem: components/relatorios/report-builder/HeaderFooterConfig.tsx:171

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | footer.customText |
| onChange | (e) => onChange({ ...footer, customText: e.target.value }) |
| placeholder | Texto exibido no rodapé de cada página |
| contexto |  |


## JoinBuilder.tsx — 7 controles

### button: + Adicionar Join

Origem: components/relatorios/report-builder/JoinBuilder.tsx:109

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | addJoin |
| contexto |  |

### select: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/JoinBuilder.tsx:123

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | join.leftTable |
| onChange | (e) => updateJoin(join.id, 'leftTable', e.target.value) |
| contexto | Repetido por joins.map ; joins.length === 0 ? ... : ... |

### input: coluna

Origem: components/relatorios/report-builder/JoinBuilder.tsx:134

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | join.leftColumn |
| onChange | (e) => updateJoin(join.id, 'leftColumn', e.target.value) |
| placeholder | coluna |
| contexto | Repetido por joins.map ; joins.length === 0 ? ... : ... |

### select: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/JoinBuilder.tsx:142

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | join.joinType |
| onChange | (e) => updateJoin(join.id, 'joinType', e.target.value as JoinConfig['joinType']) |
| contexto | Repetido por joins.map ; joins.length === 0 ? ... : ... |

### select: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/JoinBuilder.tsx:152

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | join.rightTable |
| onChange | (e) => updateJoin(join.id, 'rightTable', e.target.value) |
| contexto | Repetido por joins.map ; joins.length === 0 ? ... : ... |

### input: coluna

Origem: components/relatorios/report-builder/JoinBuilder.tsx:163

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | join.rightColumn |
| onChange | (e) => updateJoin(join.id, 'rightColumn', e.target.value) |
| placeholder | coluna |
| contexto | Repetido por joins.map ; joins.length === 0 ? ... : ... |

### button: Remover join

Origem: components/relatorios/report-builder/JoinBuilder.tsx:171

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => removeJoin(join.id) |
| title | Remover join |
| contexto | Repetido por joins.map ; joins.length === 0 ? ... : ... |


## LayoutTab.tsx — 7 controles

### button: {icon} {title}

Origem: components/relatorios/report-builder/LayoutTab.tsx:24

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setOpen(!open) |
| contexto |  |

### button: {o === 'portrait' ? 'Retrato' : 'Paisagem'}

Origem: components/relatorios/report-builder/LayoutTab.tsx:128

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| key | o |
| onClick | () => updateGeneral({ ...layout.general, orientation: o }) |
| contexto | Repetido por (['portrait', 'landscape'] as const).map |

### select: Tamanho do papel

Origem: components/relatorios/report-builder/LayoutTab.tsx:144

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | layout.general.pageSize |
| onChange | (e) => updateGeneral({ ...layout.general, pageSize: e.target.value as 'A4' \| 'Letter' \| 'Legal' }) |
| contexto |  |

### input: {side === 'top' ? 'Superior' : side === 'bottom' ? 'Inferior' : side === 'left' ? 'Esquerda' : 'Direita'}

Origem: components/relatorios/report-builder/LayoutTab.tsx:164

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | number |
| value | layout.general.margins[side] |
| onChange | (e) =><br>                      updateGeneral({<br>                        ...layout.general,<br>                        margins: { ...layout.general.margins, [side]: Number(e.target.value) \|\| 0 },<br>                      }) |
| min | 0 |
| max | 100 |
| contexto | Repetido por (['top', 'bottom', 'left', 'right'] as const).map |

### select: Tamanho da fonte

Origem: components/relatorios/report-builder/LayoutTab.tsx:185

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | layout.general.fontSize |
| onChange | (e) => updateGeneral({ ...layout.general, fontSize: Number(e.target.value) }) |
| contexto |  |

### input: Linhas zebradas

Origem: components/relatorios/report-builder/LayoutTab.tsx:197

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | layout.general.zebra |
| onChange | (e) => updateGeneral({ ...layout.general, zebra: e.target.checked }) |
| contexto |  |

### button: {t === 'responsive' ? 'Responsivo' : t === 'web' ? 'Web (Desktop)' : 'Mobile'}

Origem: components/relatorios/report-builder/LayoutTab.tsx:221

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| key | t |
| onClick | () => onTargetLayoutChange(t) |
| contexto | Repetido por (['responsive', 'web', 'mobile'] as const).map |


## PreviewTab.tsx — 10 controles

### button: Limpar filtros ( {activeFilterCount} )

Origem: components/relatorios/report-builder/PreviewTab.tsx:238

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => {<br>                  setFilterValues({});<br>                  setExecuted(false);<br>                  setError(null);<br>                } |
| contexto | activeFilterCount > 0 ; filters.length > 0 |

### select: {f.label || f.placeholder}

Origem: components/relatorios/report-builder/PreviewTab.tsx:260

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | currentVal |
| onChange | e => handleFilterChange(f.id, e.target.value) |
| contexto | f.type === 'select' ? ... : ... ; Repetido por filters.map ; filters.length > 0 |

### input: {f.label || f.placeholder}

Origem: components/relatorios/report-builder/PreviewTab.tsx:271

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | f.type === 'date' ? 'date' : f.type === 'number' ? 'number' : 'text' |
| value | currentVal |
| onChange | e => handleFilterChange(f.id, e.target.value) |
| placeholder | f.type === 'text' ? 'Todos (deixe vazio)' : '' |
| contexto | f.type === 'select' ? ... : ... ; Repetido por filters.map ; filters.length > 0 |

### button: {loading ? ( <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" /> ) : ( <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /> </svg> )} Gerar Relatório

Origem: components/relatorios/report-builder/PreviewTab.tsx:293

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | executeQuery |
| disabled | loading \|\| !sqlQuery.trim() |
| contexto |  |

### button: Imprimir

Origem: components/relatorios/report-builder/PreviewTab.tsx:318

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => exportToPrint(data, layoutWithLogo, charts, subreportsData, contentMode, chartImages) |
| contexto | executed && (data.length > 0 \|\| subreportsData.some(subreport => subreport.data.length > 0)) |

### button: PDF

Origem: components/relatorios/report-builder/PreviewTab.tsx:319

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => exportToPDF(data, layoutWithLogo, charts, subreportsData, contentMode, chartImages) |
| contexto | executed && (data.length > 0 \|\| subreportsData.some(subreport => subreport.data.length > 0)) |

### button: Excel

Origem: components/relatorios/report-builder/PreviewTab.tsx:320

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => exportToExcel(data, layoutWithLogo, charts, subreportsData, contentMode) |
| contexto | executed && (data.length > 0 \|\| subreportsData.some(subreport => subreport.data.length > 0)) |

### button: Word

Origem: components/relatorios/report-builder/PreviewTab.tsx:321

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => exportToWord(data, layoutWithLogo, charts, subreportsData, contentMode, chartImages) |
| contexto | executed && (data.length > 0 \|\| subreportsData.some(subreport => subreport.data.length > 0)) |

### button: CSV

Origem: components/relatorios/report-builder/PreviewTab.tsx:322

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => exportToCSV(data, layoutWithLogo, charts, subreportsData, contentMode) |
| contexto | executed && (data.length > 0 \|\| subreportsData.some(subreport => subreport.data.length > 0)) |

### button: HTML

Origem: components/relatorios/report-builder/PreviewTab.tsx:323

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => exportToHTML(data, layoutWithLogo, charts, subreportsData, contentMode, chartImages) |
| contexto | executed && (data.length > 0 \|\| subreportsData.some(subreport => subreport.data.length > 0)) |


## QueryPreview.tsx — 0 controles


## ReportBuilder.tsx — 11 controles

### button: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/ReportBuilder.tsx:273

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setSidebarOpen(false) |
| contexto | isNarrow ? ... : ... |

### button: sidebarOpen ? 'Ocultar painel de relatórios' : 'Mostrar painel de relatórios'

Origem: components/relatorios/report-builder/ReportBuilder.tsx:305

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setSidebarOpen(v => !v) |
| title | sidebarOpen ? 'Ocultar painel de relatórios' : 'Mostrar painel de relatórios' |
| contexto |  |

### button: Novo

Origem: components/relatorios/report-builder/ReportBuilder.tsx:314

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | handleNew |
| contexto | currentUser?.role === 'ADMIN' |

### button: Salvar

Origem: components/relatorios/report-builder/ReportBuilder.tsx:323

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setShowSaveModal(true) |
| contexto | currentUser?.role === 'ADMIN' |

### button: Excluir

Origem: components/relatorios/report-builder/ReportBuilder.tsx:332

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | handleDelete |
| disabled | !currentTemplate.id |
| contexto | currentUser?.role === 'ADMIN' |

### button: {mobilePreviewOpen ? 'Voltar ao editor' : 'Abrir preview'}

Origem: components/relatorios/report-builder/ReportBuilder.tsx:344

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setMobilePreviewOpen(value => !value) |
| contexto | isNarrow |

### select: Conteúdo:

Origem: components/relatorios/report-builder/ReportBuilder.tsx:356

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | currentTemplate.content_mode |
| onChange | e => setCurrentTemplate(prev => ({ ...prev, content_mode: e.target.value as any })) |
| contexto |  |

### select: Layout:

Origem: components/relatorios/report-builder/ReportBuilder.tsx:369

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | currentTemplate.target_layout |
| onChange | e => setCurrentTemplate(prev => ({ ...prev, target_layout: e.target.value as any })) |
| contexto |  |

### button: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/ReportBuilder.tsx:405

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setError(null) |
| contexto | error |

### button: {tab.label}

Origem: components/relatorios/report-builder/ReportBuilder.tsx:417

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| key | tab.id |
| onClick | () => setActiveTab(tab.id) |
| contexto | Repetido por TABS.map ; currentUser?.role === 'ADMIN' |

### button: Voltar ao editor

Origem: components/relatorios/report-builder/ReportBuilder.tsx:449

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => setMobilePreviewOpen(false) |
| contexto | isNarrow |


## ReportRenderer.tsx — 0 controles


## ReportSaveModal.tsx — 10 controles

### button: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:68

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | onClose |
| contexto |  |

### input: Nome *

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:78

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | name |
| onChange | e => setName(e.target.value) |
| placeholder | Nome do relatório |
| contexto |  |

### textarea: Descrição

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:89

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | textarea |
| value | description |
| onChange | e => setDescription(e.target.value) |
| rows | 2 |
| placeholder | Descrição do relatório |
| contexto |  |

### select: Categoria

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:101

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | category |
| onChange | e => setCategory(e.target.value) |
| contexto |  |

### select: Layout

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:111

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | targetLayout |
| onChange | e => setTargetLayout(e.target.value as any) |
| contexto |  |

### select: Conteúdo

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:123

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | contentMode |
| onChange | e => setContentMode(e.target.value as any) |
| contexto |  |

### input: {u.name}

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:140

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | selectedUsers.includes(u.id) |
| onChange | () => toggleUser(u.id) |
| contexto | Repetido por (config.users \|\| []).map |

### input: {g.name}

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:159

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | selectedGroups.includes(g.id) |
| onChange | () => toggleGroup(g.id) |
| contexto | Repetido por (config.userGroups \|\| []).map |

### button: Cancelar

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:175

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | onClose |
| contexto |  |

### button: Salvar

Origem: components/relatorios/report-builder/ReportSaveModal.tsx:181

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | handleSave |
| disabled | !name.trim() |
| contexto |  |


## ReportTree.tsx — 2 controles

### button: {cat} {items.length}

Origem: components/relatorios/report-builder/ReportTree.tsx:59

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => toggleCategory(cat) |
| contexto | Repetido por REPORT_CATEGORIES.map |

### button: {getContentModeIcon(tpl.content_mode)} {tpl.name} {(tpl.allowed_users || tpl.allowed_groups) && ( <svg className="w-3 h-3 text-amber-500 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" /> </svg> )}

Origem: components/relatorios/report-builder/ReportTree.tsx:72

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| key | tpl.id |
| onClick | () => onSelect(tpl) |
| contexto | Repetido por items.map ; isExpanded && items.length > 0 ; Repetido por REPORT_CATEGORIES.map |


## SchemaExplorer.tsx — 3 controles

### input: Buscar tabela...

Origem: components/relatorios/report-builder/SchemaExplorer.tsx:127

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| placeholder | Buscar tabela... |
| value | search |
| onChange | (e) => setSearch(e.target.value) |
| contexto |  |

### button: {table} {selected && ( <span onClick={(e) => handleRemoveTable(e, table)} className="text-red-400 hover:text-red-600 p-0.5" title="Remover tabela" > <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /> </svg> </span> )}

Origem: components/relatorios/report-builder/SchemaExplorer.tsx:149

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => handleTableClick(table) |
| contexto | Repetido por filteredTables.map ; filteredTables.length === 0 ? ... : ... ; loadingTables ? ... : ... |

### input: {col.column_name} {shortType(col.data_type)}

Origem: components/relatorios/report-builder/SchemaExplorer.tsx:194

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | checkbox |
| checked | isColumnSelected(table, col.column_name) |
| onChange | () => onToggleColumn(table, col.column_name, col.data_type) |
| contexto | Repetido por cols.map ; cols && cols.length > 0 ? ... : ... ; colLoading ? ... : ... ; expanded && selected ; Repetido por filteredTables.map |


## SubreportsTab.tsx — 19 controles

### button: Adicionar Subrelatório

Origem: components/relatorios/report-builder/SubreportsTab.tsx:152

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | addSubreport |
| contexto |  |

### button: Mover para cima

Origem: components/relatorios/report-builder/SubreportsTab.tsx:202

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => moveSubreport(index, -1) |
| disabled | index === 0 |
| title | Mover para cima |
| contexto | Repetido por subreports.map |

### button: Mover para baixo

Origem: components/relatorios/report-builder/SubreportsTab.tsx:212

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => moveSubreport(index, 1) |
| disabled | index === subreports.length - 1 |
| title | Mover para baixo |
| contexto | Repetido por subreports.map |

### button: Remover subrelatório

Origem: components/relatorios/report-builder/SubreportsTab.tsx:222

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => removeSubreport(sub.id) |
| title | Remover subrelatório |
| contexto | Repetido por subreports.map |

### input: Título

Origem: components/relatorios/report-builder/SubreportsTab.tsx:238

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | sub.title |
| onChange | e => updateSubreport(sub.id, { title: e.target.value }) |
| placeholder | Título do subrelatório |
| contexto | isExpanded ; Repetido por subreports.map |

### button: Resumo Automático

Origem: components/relatorios/report-builder/SubreportsTab.tsx:250

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => updateSubreport(sub.id, {<br>                        type: 'summary',<br>                        summary_config: sub.summary_config \|\| { groupField: '', operations: [] },<br>                      }) |
| contexto | isExpanded ; Repetido por subreports.map |

### button: Query Independente

Origem: components/relatorios/report-builder/SubreportsTab.tsx:263

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => updateSubreport(sub.id, { type: 'query', sql_query: sub.sql_query \|\| '' }) |
| contexto | isExpanded ; Repetido por subreports.map |

### select: Campo de Agrupamento

Origem: components/relatorios/report-builder/SubreportsTab.tsx:280

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | sub.summary_config?.groupField \|\| '' |
| onChange | e => updateSubreport(sub.id, {<br>                          summary_config: { ...sub.summary_config!, groupField: e.target.value, operations: sub.summary_config?.operations \|\| [] },<br>                        }) |
| contexto | sub.type === 'summary' ; isExpanded ; Repetido por subreports.map |

### select: Operações por Coluna Numérica

Origem: components/relatorios/report-builder/SubreportsTab.tsx:303

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | existing?.op \|\| 'none' |
| onChange | e => {<br>                                    const ops = (sub.summary_config?.operations \|\| []).filter(o => o.field !== col.name);<br>                                    if (e.target.value !== 'none') {<br>                                      ops.push({ field: col.name, op: e.target.value });<br>                                    }<br>                                    updateSubreport(sub.id, {<br>                                      summary_config: { ...sub.summary_config!, operations: ops },<br>                                    });<br>                                  } |
| contexto | Repetido por numericColumns.map ; numericColumns.length > 0 ; sub.type === 'summary' ; isExpanded ; Repetido por subreports.map |

### textarea: Query SQL

Origem: components/relatorios/report-builder/SubreportsTab.tsx:368

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | textarea |
| value | sub.sql_query \|\| '' |
| onChange | e => updateSubreport(sub.id, { sql_query: e.target.value }) |
| placeholder | SELECT ... FROM ... |
| rows | 5 |
| contexto | sub.type === 'query' ; isExpanded ; Repetido por subreports.map |

### button: {qr?.loading ? ( <svg className="animate-spin h-4 w-4" viewBox="0 0 24 24"> <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" /> <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" /> </svg> ) : ( <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" /> <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /> </svg> )} Testar Query

Origem: components/relatorios/report-builder/SubreportsTab.tsx:379

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => testQuery(sub) |
| disabled | !sub.sql_query?.trim() \|\| qr?.loading |
| contexto | sub.type === 'query' ; isExpanded ; Repetido por subreports.map |

### button: Coluna

Origem: components/relatorios/report-builder/SubreportsTab.tsx:438

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => addColumn(sub.id) |
| contexto | isExpanded ; Repetido por subreports.map |

### input: Campo

Origem: components/relatorios/report-builder/SubreportsTab.tsx:458

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | col.field |
| onChange | e => updateColumn(sub.id, colIdx, { field: e.target.value }) |
| placeholder | campo |
| contexto | Repetido por sub.columns.map ; isExpanded ; Repetido por subreports.map |

### input: Rótulo

Origem: components/relatorios/report-builder/SubreportsTab.tsx:468

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | col.label |
| onChange | e => updateColumn(sub.id, colIdx, { label: e.target.value }) |
| placeholder | Rótulo |
| contexto | Repetido por sub.columns.map ; isExpanded ; Repetido por subreports.map |

### input: Largura %

Origem: components/relatorios/report-builder/SubreportsTab.tsx:478

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | number |
| value | col.width |
| onChange | e => updateColumn(sub.id, colIdx, { width: Number(e.target.value) }) |
| min | 1 |
| max | 100 |
| contexto | Repetido por sub.columns.map ; isExpanded ; Repetido por subreports.map |

### select: Formato

Origem: components/relatorios/report-builder/SubreportsTab.tsx:489

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | col.format |
| onChange | e => updateColumn(sub.id, colIdx, { format: e.target.value }) |
| contexto | Repetido por sub.columns.map ; isExpanded ; Repetido por subreports.map |

### select: Alinhamento

Origem: components/relatorios/report-builder/SubreportsTab.tsx:501

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | col.align |
| onChange | e => updateColumn(sub.id, colIdx, { align: e.target.value }) |
| contexto | Repetido por sub.columns.map ; isExpanded ; Repetido por subreports.map |

### button: Remover coluna

Origem: components/relatorios/report-builder/SubreportsTab.tsx:512

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => removeColumn(sub.id, colIdx) |
| title | Remover coluna |
| contexto | Repetido por sub.columns.map ; isExpanded ; Repetido por subreports.map |

### select: Totalizadores

Origem: components/relatorios/report-builder/SubreportsTab.tsx:536

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | totalizer?.operation \|\| 'none' |
| onChange | e => {<br>                                const tots = sub.totalizers.filter(t => t.field !== col.field);<br>                                if (e.target.value !== 'none') {<br>                                  tots.push({ field: col.field, operation: e.target.value });<br>                                }<br>                                updateSubreport(sub.id, { totalizers: tots });<br>                              } |
| contexto | Repetido por sub.columns.map ; sub.columns.length > 0 ; isExpanded ; Repetido por subreports.map |


## WhereBuilder.tsx — 6 controles

### button: + Adicionar Filtro

Origem: components/relatorios/report-builder/WhereBuilder.tsx:67

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | addCondition |
| contexto |  |

### select: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/WhereBuilder.tsx:82

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | cond.connector |
| onChange | (e) => updateCondition(cond.id, 'connector', e.target.value) |
| contexto | idx > 0 ; Repetido por conditions.map ; conditions.length === 0 ? ... : ... |

### select: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/WhereBuilder.tsx:92

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | cond.field |
| onChange | (e) => updateCondition(cond.id, 'field', e.target.value) |
| contexto | Repetido por conditions.map ; conditions.length === 0 ? ... : ... |

### select: (sem rótulo textual próprio; identificar pelo vínculo/ação)

Origem: components/relatorios/report-builder/WhereBuilder.tsx:105

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | select |
| value | cond.operator |
| onChange | (e) => updateCondition(cond.id, 'operator', e.target.value) |
| contexto | Repetido por conditions.map ; conditions.length === 0 ? ... : ... |

### input: Valor ou {{filtro}}

Origem: components/relatorios/report-builder/WhereBuilder.tsx:117

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | input |
| type | text |
| value | cond.value |
| onChange | (e) => updateCondition(cond.id, 'value', e.target.value) |
| placeholder | Valor ou {{filtro}} |
| contexto | !noValueOperators.includes(cond.operator) ; Repetido por conditions.map ; conditions.length === 0 ? ... : ... |

### button: Remover filtro

Origem: components/relatorios/report-builder/WhereBuilder.tsx:136

| Propriedade | Conteúdo / expressão |
| --- | --- |
| elemento | button |
| onClick | () => removeCondition(cond.id) |
| title | Remover filtro |
| contexto | Repetido por conditions.map ; conditions.length === 0 ? ... : ... |


# Acompanhamento Jurídico — Inventário funcional e técnico

# 01 — Escopo, leitura e limites da verificação
Este levantamento descreve a implementação encontrada no projeto local no momento da extração. Não é uma proposta de sistema novo. O nome correto do menu é **Acompanhamento Jurídico**.

## Como consultar
- Abra **LEIA-ME.html** no navegador para ler o relatório inteiro, pesquisar texto e navegar pelo índice.
- O relatório também está em **RELATORIO-COMPLETO.md**, em formato textual editável.
- **dicionario-campos.csv** reúne os campos de negócio, seus padrões, opções e efeitos.
- **controles-e-acionamentos.csv** e **catalogo-controles.json** enumeram os controles reais e suas expressões de acionamento, com referência de arquivo e linha.
- **estados-e-padroes.csv** e o JSON correspondente registram todos os estados React extraídos das telas e componentes compartilhados analisados.
- **variaveis-impressao.csv** e seu JSON registram cada substituição implementada por contexto.
- **catalogo-acoes-tecnicas.json** preserva as implementações dos manipuladores de ações selecionados, para esclarecer condições e transformações exatas.
- **fontes-e-integridade.json** registra arquivos de referência e seus hashes SHA-256. Os arquivos de aplicação não são copiados integralmente.

## Classificação das evidências
- **Implementado no código:** declaração ou caminho de execução encontrado. Não significa que foi executado com dados reais.
- **Limitação identificada:** diferença observável entre interface, transporte, resposta ou persistência.
- **Não verificado em sessão autenticada:** telas internas, permissões reais de um usuário, dados cadastrados, impressão efetiva e operações de gravação.
- **Externo ao menu:** dependência ou integração existente em outra área; não deve ser confundida com um submenu deste módulo.

## Verificação realizada sem alterar dados
A página inicial respondeu e exibiu o login. A consulta HTTP sem sessão a /api/legal-processes/dashboard-data retornou **401**, conforme a proteção de autenticação. A captura não teve sessão autenticada: **a aparência e o funcionamento das telas internas não foram verificados no navegador**. Não foram criados processos, enviados alertas, anexados documentos, alterados registros nem executadas exclusões.

O material é completo em relação aos elementos encontrados nos seis componentes centrais e às dependências explicitamente catalogadas. Não se afirma completude de comportamentos dinâmicos de bibliotecas de terceiros nem de configurações privadas não consultadas. Valores de listas cadastrais são descritos por sua origem; nomes reais de pessoas, documentos, arquivos, grupos, unidades e credenciais não são exportados.

Nenhuma alteração funcional foi feita no aplicativo. Não houve acesso ao banco de produção nem certificação de schema aplicado. As estruturas de banco citadas são as declarações de migração do repositório, não uma leitura do catálogo de uma instalação.


# 02 — Hierarquia, estrutura geral e navegação
## Árvore integral do menu
- Acompanhamento Jurídico — identificador acomp_juridico.
  - Dashboard — jur_dashboard.
  - Processos — jur_processos.
  - Prazos e Audiências — jur_prazos.
    - Aba Prazos.
    - Aba Audiências.

Não há outros submenus subordinados na definição atual. As cinco abas de cadastro e os painéis de detalhes são estados internos de Processos, não novos itens da barra lateral.

## Acionamento
O layout carrega LegalTrackingPanel sob demanda. Selecionar jur_processos monta ProcessList; selecionar jur_prazos monta DeadlinesPanel; selecionar jur_dashboard ou o identificador-pai monta LegalDashboard. A navegação usa estado currentView do layout, e não URLs distintas por submenu. Não há deep link próprio comprovado para um processo, prazo ou audiência.

O layout verifica temAcesso antes de navegar. O painel jurídico fica dentro de um contêiner flexível de altura disponível, largura mínima zero e overflow oculto. Processos administra três modos: LIST, FORM e DETAIL. A lista é a entrada padrão. Formulário abre uma sobreposição de tela inteira; detalhe substitui a lista dentro do painel.

## Origem dos dados por tela
- Processos e Prazos e Audiências usam config.companyLegalProcesses, carregado pela configuração autenticada /api/config.
- Dashboard usa estado próprio dashboardProcesses, obtido por GET /api/legal-processes/dashboard-data.
- Clientes/parceiros: config.clients; unidades: config.units; colaboradores: config.collaborators; modelos: config.formTemplates.
- O servidor mapeia campos snake_case para propriedades camelCase na configuração. As respostas da API jurídica têm outro mapeamento, que não é equivalente em todos os campos.

## Atualização
Ao entrar no Dashboard, o painel solicita seus dados. Alterações de processos também acionam nova consulta dos indicadores. O domínio legal recebe eventos Socket.IO dashboard:invalidate originados de invalidações de banco; o hook agrupa eventos em 250 ms e posterga trabalho de abas ocultas até sua visibilidade.

**Limitação importante:** incluir, alterar e excluir não atualiza diretamente config.companyLegalProcesses. O painel ignora o objeto retornado por POST/PUT e só atualiza dashboardProcesses. Não passa onRefresh nem setConfig a ProcessList/DeadlinesPanel. Assim, a lista e os registros filhos podem permanecer com valores antigos até uma recarga externa da configuração. A disponibilidade de refreshConfig no App não prova que essas ações a acionem.


# 03 — Dashboard: todos os indicadores, quadros e regras
## Estrutura da tela
Título Dashboard Jurídico; subtítulo Visão geral do acompanhamento de processos da empresa; cinco cartões; três painéis de distribuição; dois quadros tabulares inferiores. Cartões se organizam em uma coluna, duas a partir de sm e cinco em lg. Distribuições passam para três colunas em lg; quadros inferiores para duas.

## Cartões e conteúdo padrão
| Elemento | Cálculo exato e abrangência | Sem registros |
| --- | --- | --- |
| Processos Ativos | Conta status exatamente ATIVO | 0 |
| Prazos Vencendo (7d) | Prazos PENDENTE cuja data convertida está entre agora e agora + 7 x 24h, inclusive | 0 |
| Audiências Próximas (7d) | Audiências AGENDADA na mesma janela temporal | 0 |
| Valor Provisionado | Soma provisionValue de todos os processos recebidos, não apenas ativos; remove pontos e troca vírgula por ponto antes de parseFloat; NaN soma zero; exibe BRL | Valor zero formatado |
| Risco (Ativos) | Conta apenas ativos por BAIXO, MEDIO, ALTO, CRITICO; só mostra categorias com quantidade positiva | Nenhum processo ativo |

Os cartões são informativos: não há onClick que filtre, abra modal ou navegue para registros.

## Distribuições existentes
- Processos por Tipo: todos os processos; contagem por tipo; ordem decrescente de quantidade; largura relativa à maior categoria, não percentual do total.
- Processos por Status: todos os processos; anel proporcional à participação de cada status; total no centro; legenda com quantidade. Sem ação de seleção ou drill-down.
- Processos por Unidade: agrupa por nome fantasia, senão razão social, senão Sem Unidade; ordena por quantidade; largura relativa ao maior grupo. Unidades diferentes com o mesmo nome de exibição podem aparecer agregadas.
- Sem dados: Nenhum dado disponível.

## Quadro Próximos Prazos
Colunas: Processo, Descrição, Data, Responsável, Prazo.
Reúne todos os prazos PENDENTE, ordena por dueDate crescente e limita a dez. **Inclui vencidos** e não se limita a sete dias, ao contrário do cartão. Processo é texto monoespaçado, não link. Descrição é truncada com título completo no hover; responsável é resolvido pelo ID do colaborador ou —.

Dias restantes = ceil((data - agora) / 86400000). Menor que zero: Vencido (Nd), vermelho. De zero até menos de três: Nd, vermelho. De três a sete: amarelo. Acima de sete: verde. Não há ação Cumprido nesse quadro, nem editar, excluir ou paginar. Ausência: Nenhum prazo pendente.

## Quadro Próximas Audiências
Colunas: Processo, Data/Hora, Tipo, Local, Prazo.
Somente AGENDADA com data maior ou igual a agora; ordem crescente por data; dez primeiras; não compara hora para ordenar. Local ausente aparece —. Mesmo badge de dias do quadro anterior. Ausência: Nenhuma audiência agendada. Não há CRUD nesse quadro.

## Ressalvas de interpretação
As comparações usam Date JavaScript e, em vários pontos, a hora atual, não o início do dia. Uma data sem horário de hoje pode já ficar fora dos cartões e das próximas audiências. Não há calendário de feriados, contagem de dias úteis, suspensão de prazo ou cálculo processual de vencimento. O painel não usa um filtro de período editável nem filtro de unidade próprio.


# 04 — Processos: busca, filtros, grade, CRUD e documentos
## Cabeçalho e comandos
Título Processos Judiciais; contador N processo(s) encontrado(s) calculado após filtros; botão Formulários quando elegível; Novo Processo. Novo Processo limpa seleção e abre FORM. Nenhum processo é selecionado automaticamente para edição.

## Busca e filtros
| Controle | Padrão | Efeito |
| --- | --- | --- |
| Busca livre | Vazio | Pesquisa sem distinguir maiúsculas em número, vara, comarca, parte adversa, assunto, advogado responsável e nome do parceiro |
| Filtros | Fechados | Alterna visibilidade do painel avançado; não apaga valores ao ocultar |
| Tipo | Todos | Igualdade com um dos sete tipos |
| Status | Todos | Igualdade com um dos seis status do cadastro |
| Risco | Todos | BAIXO / MEDIO / ALTO / CRITICO |
| Unidade | Todas | Igualdade de unitId; opções de config.units |
| Parceiro | Vazio | Busca no parceiro vinculado por nome, documento ou telefone; exclui registros sem parceiro correspondente quando preenchido |
| De e Até | Vazios | Limites inclusivos sobre distributionDate por comparação de strings |
| Limpar | Só aparece havendo filtro | Zera busca e sete filtros; volta à página 1 |

Todo filtro alterado volta à página 1. Busca e filtros são locais, não consultam o endpoint de listagem a cada tecla. Pesquisa não normaliza CPF/telefone nem remove acentos. Busca livre não inclui documento da parte adversa. Painel avançado distribui campos em 1/2/4/7 colunas conforme largura.

## Grade completa
| Coluna | Conteúdo e comportamento |
| --- | --- |
| Nº Processo | processNumber; ordenável; texto monoespaçado |
| Vara/Comarca | court na primeira linha, jurisdiction na segunda; ordenação somente por court |
| Parte Adversa | opposingParty; ordenável |
| Parceiro | Nome de config.clients resolvido por partnerId; — quando não encontrado; ordena pelo nome resolvido |
| Tipo | Código do tipo em etiqueta; ordenável |
| Papel | AUTOR / RÉU / TERCEIRO em etiqueta; ordenável |
| Risco | BAIXO verde, MEDIO amarelo, ALTO laranja, CRITICO vermelho; ordenação lexical |
| Status | ATIVO azul; SUSPENSO amarelo; ARQUIVADO cinza; ENCERRADO_PROCEDENTE verde; ENCERRADO_IMPROCEDENTE vermelho; ACORDO roxo |
| Advogado | responsibleLawyer ou -; ordenável |
| Últ. Mov. | lastMovementDate convertido para pt-BR ou -; ordenável |
| Valor | Prefixo R$ + causeValue, sem normalização monetária na célula; - quando vazio; ordenação textual |
| Ações | Histórico, Ver, Editar, Duplicar, Excluir |

Ordenação inicial: updatedAt decrescente, mesmo sem coluna visível desse campo. Clicar em outra coluna ordena crescente; repetir alterna crescente/decrescente. Texto é convertido para minúsculas antes da comparação. Valores de causa são strings e não números ordenados monetariamente. Há rolagem horizontal; linhas não têm edição inline nem seleção em lote.

## Paginação
Página 1; dez itens por página. Seletor desktop: 5, 10, 20, 50, 100; alterar tamanho volta à primeira página. Navegação anterior, próxima e números com reticências. Rodapé informa intervalo e total. Em telas pequenas há versão compacta. Sem registros, não renderiza paginação.

## CRUD e ações de linha
- **Ver:** seleciona processo e entra em DETAIL; o detalhe tenta localizar a versão atual no array recebido, senão conserva a seleção.
- **Editar:** seleciona o registro existente e abre FORM com os dados dele.
- **Novo Processo:** abre FORM com padrões descritos no capítulo seguinte.
- **Salvar:** decide entre onAdd e onUpdate pela presença de selectedProcess. Retorna à lista e limpa a seleção imediatamente; não aguarda confirmação da requisição.
- **Duplicar:** copia o objeto inteiro, gera identificador provisório proc- + Date.now, acrescenta (CÓPIA) ao número, esvazia movimentações/prazos/audiências e renova timestamps. Outros campos permanecem copiados, inclusive attachments se existirem no objeto. Não abre modal de revisão e não pede confirmação.
- **Excluir:** confirmação nativa Excluir o processo [número]?; cancelar não chama a API; confirmar chama DELETE. Relações filhas do processo possuem cascade nas migrações.
- **Histórico:** abre modal somente leitura, descrito no capítulo 08.

## Formulários de impressão na grade
Depende de modelo associado a jur_processos e permissão de impressão. Com um modelo, clique gera diretamente; com vários, abre menu com nome e descrição. O contexto é grid, mas a implementação preenche as variáveis **somente com o primeiro processo da página atual**. Não produz automaticamente uma relação impressa de toda a grade, nem abre seletor de processo. Sem registros, mantém o HTML sem substituir variáveis.

Concatena cabeçalho, conteúdo e rodapé do modelo, substitui variáveis e sanitiza o HTML. Abre janela com fonte Times New Roman, tamanho 14px, margens de impressão 20mm, tabelas com bordas e imagens limitadas à largura. No carregamento solicita print e close. Salvar PDF depende do diálogo do navegador; não existe gerador PDF servidor nesse comando.


# 05 — Novo/Editar Processo: campos, padrões e cinco abas
## Estrutura e ciclo de vida
Sobreposição fixa cobrindo a tela (z-50), fundo escuro translúcido, conteúdo branco. Título Novo Processo ou Editar Processo; X no topo; cinco abas; conteúdo com rolagem vertical; rodapé fixo com Cancelar e Cadastrar Processo ou Salvar Alterações. A aba inicial é Dados Gerais. Cancelar e X fecham sem confirmação de alterações não salvas. Não há salvamento automático.

O processo novo começa com strings vazias nos campos textuais, type=CÍVEL, role=RÉU, status=ATIVO, riskLevel=MEDIO, distributionDate=data UTC corrente YYYY-MM-DD, arrays de movimentos/prazos/audiências/tags vazios e timestamps ISO atuais. ID nasce vazio e é substituído no submit por proc-[timestamp]; o servidor ignora esse ID e gera UUID.

## Aba Dados Gerais
| Campo visual | Propriedade | Padrão / opções / acionamento |
| --- | --- | --- |
| Nº do Processo (CNJ) | processNumber | Texto vazio; único campo cujo trim é verificado no submit; sem máscara CNJ ou cálculo de dígitos no componente |
| Vara | court | Texto vazio |
| Comarca / Jurisdição | jurisdiction | Texto vazio |
| Tipo | type | CÍVEL; Trabalhista, Cível, Tributário, Consumidor, Criminal, Administrativo, Outro |
| Status | status | ATIVO; Ativo, Suspenso, Arquivado, Encerrado (Procedente), Encerrado (Improcedente), Acordo |
| Assunto | subject | Texto vazio |
| Unidade | unitId | Vazio / Selecione...; nomes fantasia ou razões sociais; valor persistido é ID |
| Data de Distribuição | distributionDate | Data corrente UTC; input date; editável |

Grades de uma coluna, duas em md e três em lg. Não há consulta automática ao tribunal pelo número informado.

## Aba Partes
- **Papel da Empresa:** rádio Autor=AUTOR; Réu=RÉU; Terceiro Interessado=TERCEIRO. Padrão Réu.
- **Nome da Parte Adversa:** opposingParty, texto vazio.
- **Documento (CPF/CNPJ):** opposingPartyDocument, texto vazio; sem máscara/validador específico neste formulário.
- **Parceiro Vinculado:** busca por nome, CPF/CNPJ ou telefone em config.clients. Vazio mostra os dez primeiros clientes; havendo busca, até vinte correspondências. Foco abre dropdown; clique externo fecha. Selecionar grava o ID do cliente, não o nome. Mudar o texto divergindo do selecionado limpa partnerId. X desvincula e limpa busca. Exibe cartão de confirmação com inicial do nome, nome, documento e telefone. Sem resultado: Nenhum parceiro encontrado.
- **Nome do Advogado da parte adversa:** opposingPartyLawyer, texto vazio.
- **OAB da parte adversa:** opposingPartyLawyerOAB, texto vazio.
- **Advogado Responsável:** responsibleLawyer, seletor inicialmente vazio. Só oferece colaboradores cujo jobTitle em minúsculas seja exatamente advogado invicta. A opção armazena c.name, **não c.id**. Sem opções, avisa Nenhum colaborador com cargo "Advogado Invicta" encontrado.
- **OAB do Responsável:** responsibleLawyerOAB, texto livre vazio, não é preenchido automaticamente ao escolher colaborador.

O advogado responsável é uma referência textual, diferentemente do parceiro e do responsável de prazo que usam IDs. Não se deve apresentar esse campo como vínculo relacional confiável ao cadastro de colaboradores.

## Aba Financeiro
Valor da Causa (R$)=causeValue e Valor Provisionado (R$)=provisionValue: campos de texto vazios; não geram títulos financeiros, parcelas, cobranças ou provisão contábil automática. Sem máscara monetária local. Quatro botões de Nível de Risco: Baixo, Médio, Alto, Crítico; Médio inicial. Seleção altera apenas riskLevel e realça cor, borda e anel.

## Aba Notas / Anotações
Editor TinyMCE local com licença GPL. Campos notes, notesHeader, notesFooter são HTML. Corpo inicia visualmente em <p></p> se vazio. Seções cabeçalho e rodapé começam ocultas salvo se houver conteúdo existente; botão + Cabeçalho/+ Rodapé as revela; X as oculta e retorna foco lógico à seção BODY. Ocultar não limpa explicitamente o HTML armazenado, logo não significa apagar o conteúdo.

- Corpo: undo/redo, blocos, família e tamanho de fonte, negrito, itálico, sublinhado, tachado, alinhamentos esquerdo/centro/direito/justificado, listas com marcadores/numeradas, recuo, tabelas, imagens, links, quebra de página e edição de código HTML; barra de status e redimensionamento de objetos.
- Cabeçalho e rodapé: negrito, itálico, sublinhado, alinhamentos esquerdo/centro/direito, tamanho de fonte e imagem; plugins de listas/imagens/links. Alturas 120px e 100px; corpo mínimo 400px.
- Página visual com largura máxima 210mm; fontes Times New Roman; seção ativa destacada; cabeçalho azul, corpo verde, rodapé âmbar.
- Não há integração documentada de IA ou OCR nesses editores. Diálogos internos de imagem, link e tabela pertencem ao TinyMCE; suas opções completas de biblioteca não foram inspecionadas em execução.

**Formulário de Impressão:** seletor aparece se há modelos do contexto modal. Inicia Selecione um formulário...; escolher concatena HTML do modelo, substitui variáveis e atribui previewHtml. Imprimir aparece quando previewHtml existe e abre janela de impressão; Limpar remove seleção e previewHtml. Essa seleção não aplica o modelo ao conteúdo do editor. **Não há contêiner que renderize previewHtml na tela**, apesar do nome de prévia. A lista de modelos dessa aba não repete explicitamente a checagem de IMPRIMIR feita por FormTemplateButton.

## Aba Anexos: duas áreas distintas
1. Painel de documentos do cliente: só aparece se houver partnerId; clientId=partnerId, module=LEGAL, targetType=LEGAL_PROCESS, targetId=formData.id ou undefined, compact=true. Detalhado no capítulo 09.
2. Adicionar Documento: anexos locais/base64 associados ao processo. Título do Documento opcional, inicialmente vazio; placeholder Ex: Petição Inicial, Contestação, Procuração...; Selecionar Arquivo abre input oculto.

Aceita na seleção .pdf,.doc,.docx,.jpg,.jpeg,.png,.gif,.bmp,.xls,.xlsx,.txt. Primeiro arquivo da seleção apenas. Acima de 5 x 1024 x 1024 bytes: alerta Arquivo excede o limite de 5MB. Não há validação de conteúdo/MIME nesse handler. FileReader converte em data URL base64; título vazio assume file.name; ID att-[timestamp]; limpa título e seletor depois da leitura.

Grade local: Título, Arquivo, Ações; linhas abrem em duplo clique. Visualizar abre nova janela com iframe e data URL. Excluir remove do estado sem confirmação, só se torna persistente no salvar do processo. Não há editar título nem botão de download dedicado nessa grade. Sem itens: Nenhum documento anexado. O contador da aba considera apenas attachments locais, não o painel compartilhado.

## Salvar e validações
Se processNumber.trim() vazio, retorna silenciosamente: não abre alerta nem destaca erro no handler. Caso contrário, lê HTML dos editores montados, conserva campos existentes como fallback, ajusta timestamps, adiciona attachments e chama onSave.

O formulário não exige unidade, vara, parte, advogado, valor ou data para executar onSave. O POST exige process_number e status no servidor. Valores e restrições de referências podem impedir a gravação após fechar o formulário. Não há indicador de salvamento pendente nem bloqueio local de clique repetido comprovado nesse componente.


# 06 — Detalhe do processo: informações e operações filhas
## Entrada e cabeçalho
Ver na grade abre o detalhe. Voltar à lista fecha; Gerar Documento usa os modelos do contexto modal. Não é o modal de edição: é uma tela de detalhe dentro do painel.

Resumo: número; vara — comarca; assunto; nome da unidade ou -; etiquetas status/risco/papel. Campos informativos: Tipo, Parte Adversa, Advogado Responsável ou -, Distribuição em pt-BR, Valor da Causa, Provisionado. Cartão de parceiro aparece se o ID resolve em config.clients: inicial, nome, documento, telefone e e-mail, com etiqueta Parceiro Vinculado.

Área de conteúdo: Movimentações à esquerda e Prazos/Audiências à direita em telas grandes; uma coluna nas menores. Notas / Observações aparecem ao final apenas se process.notes existe; HTML sanitizado. Cabeçalho/rodapé de notas e tabela de anexos não são mostrados aqui.

## Movimentações: CRUD completo no detalhe
Lista em linha do tempo; ordem de data decrescente. Exibe data pt-BR, etiqueta de tipo, descrição e fonte se preenchida. Cada tipo tem ícone. Editar/Excluir são revelados por hover do grupo, o que merece atenção em telas de toque.

+ Adicionar revela formulário inline, não modal. Estado inicial/reset: data UTC corrente, tipo DESPACHO, descrição e fonte vazias.
- Data: input date.
- Tipo: DESPACHO/Despacho, DECISAO/Decisão, PETICAO/Petição, CERTIDAO/Certidão, SENTENCA/Sentença, AUDIENCIA/Audiência.
- Descrição: texto.
- Fonte: texto.
- Adicionar cria mov-[timestamp] e agrega ao array; Salvar em edição substitui o item com mesmo ID.
- Ao incluir/editar, lastMovementDate recebe a data desse item, mesmo se anterior à maior data existente. Não calcula max de movimentações.
- Cancelar fecha e limpa editingMovement. Ao clicar novamente em Adicionar, reinicia os padrões.
- Excluir pede Excluir esta movimentação? e remove do array. Não recalcula lastMovementDate.

Sem validações obrigatórias de descrição/data nesse handler; data vazia assume hoje. **Fonte está disponível na tela, mas não é inserida pelos SQLs de movimentos da API jurídica.**

## Prazos no detalhe
+ Prazo revela formulário inline. Padrões: dueDate vazio; type=CONTESTAÇÃO; status=PENDENTE; descrição vazia; responsibleId vazio.
Campos visíveis: Data Limite, Tipo, Descrição, Responsável. Tipos: CONTESTAÇÃO, RECURSO, MANIFESTAÇÃO, CUMPRIMENTO, AUDIÊNCIA, OUTRO. Responsável oferece todos os colaboradores por ID; vazio Selecione....

Adicionar cria dl-[timestamp], processId atual e inclui no array. Fecha e redefine padrões. Cancelar somente fecha, podendo preservar rascunho para a próxima abertura. Não valida data/descrição antes de enviar por esse caminho. Não há seletor de status nem campo de observações nesse formulário inline, apesar de existirem no modelo de dados.

Cartão de prazo exibe descrição, data, tipo e nome do responsável se resolvido. Pendente oferece Cumprido, que altera status para CUMPRIDO. X pede Excluir este prazo? e remove. **Não há edição completa de prazo no detalhe**: usar a aba Prazos e Audiências para isso.

Cores: CUMPRIDO verde, VENCIDO vermelho, data passada vermelha, até três dias amarela, até sete âmbar, demais verde. A cor não grava automaticamente VENCIDO. Sem prazos: Nenhum prazo cadastrado.

## Audiências no detalhe
+ Audiência revela formulário inline. Padrões: data/hora/local/notas vazios; tipo INICIAL; status AGENDADA.
Campos: Data (date), Hora (time), Tipo (INICIAL/INSTRUÇÃO/JULGAMENTO/CONCILIAÇÃO/OUTRO), Local e Observações (input de texto).
Adicionar agrega hr-[timestamp], processId atual e fecha; Cancelar fecha sem zerar explicitamente. Não exige data ou hora nesse handler.

Cartões: tipo — local ou Local não informado; data, hora, status. AGENDADA azul, REALIZADA verde, ADIADA amarela, demais vermelho. X confirma Excluir esta audiência?. Não há editar, marcar realizada ou adiar no detalhe: essas ações estão no submenu consolidado. Observações não aparecem no cartão. Sem registros: Nenhuma audiência cadastrada.

Todas essas mutações reenviam o processo completo via onUpdate e dependem da permissão ALTERAR, inclusive exclusão de registros filhos.


# 07 — Prazos e Audiências: grades, modais e alertas
## Abas e preparação
Entrada padrão Prazos. Contadores de abas mostram quantidades após seus próprios filtros. As duas abas mantêm filtros e páginas independentes enquanto o componente permanece montado. Consolidam filhos de todos os processos presentes na configuração, não somente ativos. A variável activeProcesses existe, mas não é utilizada para limitar os seletores ou grades.

## Aba Prazos
Filtros: Status Todos/Pendente/Cumprido/Vencido; Tipo Todos + seis tipos; Responsável Todos + colaboradores por ID; De e Até por dueDate, inclusivos. Todos começam vazios e resetam página ao mudar. Sem busca livre nem botão Limpar específico nessa aba.

Ordenação fixa por dueDate ascendente usando localeCompare, antes da paginação; não há clique de cabeçalho para ordenar. Padrão dez itens; mesmo Pagination de Processos.

Colunas completas: Processo (texto monoespaçado, não link), Descrição (truncada), Tipo, Data Limite em dd/mm/aaaa, Responsável (nome por ID, — se vazio, ID se não encontrado), Status (badge calculado), Ações.

Status visual: CUMPRIDO mostra Cumprido azul; se status=VENCIDO ou dueDate < hoje, Vencido vermelho; hoje mostra Hoje laranja; de um a três dias, Nd amarelo; demais Nd verde. **Filtro por VENCIDO usa o status salvo, não o badge calculado**: um PENDENTE com data passada pode aparecer visualmente Vencido sem corresponder ao filtro Vencido.

Ações:
- Marcar como Cumprido: somente quando status salvo=PENDENTE; altera status, sem confirmação.
- Editar: abre modal preenchido com o registro e processo bloqueado.
- Excluir: confirmação nativa Excluir este prazo?; remove filho e envia atualização do processo.
- Novo Prazo: abre modal limpo e pré-seleciona o primeiro processo de processes, se existir.

Sem resultados: Nenhum prazo encontrado.

## Modal Novo Prazo / Editar Prazo
Fundo escuro, cartão central max-w-lg, altura máxima 90vh com rolagem, z-50, X, Cancelar e Salvar.
| Campo | Tipo / padrão no novo | Regra |
| --- | --- | --- |
| Processo * | Select; primeiro processo disponível ou vazio | Opções número — parte adversa de todos os processos; desabilitado na edição |
| Descrição * | Texto vazio | Obrigatório por teste de truthiness, sem trim |
| Data Limite * | Date vazio | Obrigatória para habilitar Salvar |
| Tipo | Select OUTRO | Seis tipos de prazo |
| Status | Select PENDENTE | PENDENTE, CUMPRIDO, VENCIDO |
| Responsável | Select vazio/Nenhum | Todos os colaboradores, grava ID no objeto |
| Observações | Textarea vazia, três linhas | Opcional; converte vazio em undefined no objeto |

Salvar desabilitado sem processo, descrição ou data. Inclusão cria ID dl-[timestamp] e agrega; edição faz map do filho no processo atual, preservando o ID. Não permite mover prazo para outro processo em edição. Fecha antes de aguardar o PUT. X/Cancelar só fecham, sem gravação.

## Aba Audiências
Filtros: Status Todos/Agendada/Realizada/Adiada/Cancelada; Tipo Todos + cinco tipos; De/Até por data inclusivos. Sem filtro de responsável e sem busca por processo. Ordenação fixa por data e depois hora ascendente via localeCompare. Paginação independente com dez itens iniciais.

Colunas completas: Processo, Data/Hora (dd/mm/aaaa às HH:mm), Tipo, Local (— se ausente), Status, Ações.
- Marcar como Realizada: só AGENDADA; status=REALIZADA, sem confirmação.
- Marcar como Adiada: só AGENDADA; status=ADIADA; **não solicita nem altera nova data**.
- Editar: modal com os dados.
- Excluir: confirma Excluir esta audiência? e remove.
- Nova Audiência: modal limpo; primeiro processo pré-selecionado.
Status: AGENDADA azul, REALIZADA verde, ADIADA amarelo, CANCELADA vermelho. Cancelamento só pela edição do status, sem botão direto na linha. Sem resultados: Nenhuma audiência encontrada.

## Modal Nova Audiência / Editar Audiência
Mesma estrutura do modal de prazo.
| Campo | Tipo / padrão | Regra |
| --- | --- | --- |
| Processo * | Select; primeiro processo ou vazio | Bloqueado ao editar; todos os processos disponíveis |
| Data * | Date vazio | Obrigatória |
| Hora * | Time vazio | Obrigatória |
| Tipo | Select INICIAL | INICIAL, INSTRUÇÃO, JULGAMENTO, CONCILIAÇÃO, OUTRO |
| Status | Select AGENDADA | AGENDADA, REALIZADA, ADIADA, CANCELADA |
| Local | Texto vazio | Placeholder Ex: Fórum Central, Sala 301 |
| Observações | Textarea vazia, três linhas | Opcional |

Salvar desabilitado sem processo/data/hora. Não valida choque de agenda, horário de expediente, local ou antecedência. Não possui responsável próprio. Edição conserva processo e ID; inclusão gera hr-[timestamp]. Local/notas vazios passam como undefined no objeto. Fecha imediatamente depois de onUpdateProcess.

## Alertas integrados à mensageria
Efeito no navegador, executado enquanto DeadlinesPanel está montado. Avalia PENDENTE e AGENDADA a exatamente **7, 5 e 3 dias** da data UTC corrente. Não há comprovação de agendamento servidor para o usuário que não abrir essa tela; não é um serviço cron.

Deduplicação somente em Set em memória do componente: chaves dl-[id]-[dias] e hr-[id]-[dias]. Remontar ou outra sessão pode reenviar. Acumula os eventos elegíveis num único texto com tipo, número, descrição, dias e data; assunto Alerta de Prazos Jurídicos.

Aciona useMessaging.sendMessage → POST /api/messages, recipientType=ALL, recipientId vazio, isSystem=true, metadata.source=acomp_juridico, alertType=deadline_warning. O contexto acrescenta identificação do usuário atual como remetente. **Não envia automaticamente WhatsApp, SMS ou e-mail por esse código**. A promessa rejeitada é capturada e descartada; a chave já foi marcada antes do envio e não há retry nesse efeito. Alertas não alteram o status dos registros.


# 08 — Modelos, variáveis, impressão e histórico
## Seleção de modelos
Registro de contexto: menuId jur_processos; rótulo Acomp. Jurídico - Processos; entityType company_legal_process; targetTypes grid e modal; prefixos anunciados cliente, empresa, colaborador, processo, geral.

useFormTemplates exige contexto conhecido e targetType suportado, mas filtra os modelos somente por menuIds incluir jur_processos. Não há separação efetiva dos modelos em conjuntos diferentes para grid e modal. Nenhum modelo padrão específico é criado pelos componentes jurídicos; nome, descrição e conteúdo vêm dos cadastros de formulários.

FormTemplateButton só aparece com modelo disponível e permissão rel_formularios:IMPRIMIR ou jur_processos:IMPRIMIR. Um modelo gera diretamente; vários abrem dropdown; clique externo fecha.

## Variáveis implementadas na grade e no detalhe
- processo: numero, vara, comarca, tipo, status, assunto, valor_causa, valor_provisionado, risco, parte_adversa, advogado_responsavel.
- cliente: nome, documento, telefone. Sem parceiro, nome/documento usam parte adversa; telefone fica vazio.
- empresa: razao_social, cnpj, cidade. Unidade vinculada, senão config.companyInfo.
- colaborador.nome: nome textual do advogado responsável.
- data.hoje: data local pt-BR.

## Variáveis adicionais somente no formulário de cadastro
Além das anteriores: processo.papel, processo.data_distribuicao, processo.documento_adversa, processo.advogado_adverso, processo.oab_adverso; cliente.email; empresa.telefone, empresa.endereco, empresa.uf; data.extenso.

No formulário, colaborador.nome procura primeiro colaborador pelo nome do responsável, senão o texto do campo. As chaves efetivas são sempre envoltas em chaves duplas, por exemplo {{processo.numero}}. O CSV e JSON de variáveis registram separadamente todas as ocorrências e as expressões exatas por tela, inclusive as repetidas.

Prefixo geral anunciado no registro **não significa substituição genérica garantida**: os manipuladores usam dicionários explícitos. Chaves não presentes permanecem no HTML. Campos de imagem/logotipo, listas de movimentações, prazos e audiências não são injetados automaticamente nesses dicionários.

## Impressão e prévia
Grade e detalhe sanitizam o HTML após substituir variáveis e escapam o título do modelo. Formulário usa seu próprio fluxo previewHtml, sem a mesma sanitização explícita nesse manipulador. Todas as saídas abrem janela via Blob de HTML e pedem impressão no carregamento. Popup blocker e capacidade do navegador afetam o resultado. Não há assinatura digital, protocolo judicial ou integração com editor externo comprovados aqui.

## Modal Histórico de Movimentações
Não confundir histórico de auditoria com a linha do tempo jurídica. Ícone na linha da grade abre modal com selo Somente Leitura e nome/número do processo. Busca GET /api/audit-logs?entity_id=[id]&limit=500 ao abrir; limpa resultados anteriores e volta à página inicial. Não usa os logs passados por props para compor a tabela.

Ordena data/hora decrescente. Cada alteração de campo vira uma linha; evento sem changes vira linha resumida. Colunas: Data/Hora, Usuário, Ação, Campo, De, separador →, Para. Valores antigos vermelhos e novos verdes; ações com etiquetas por tipo. Sem dados: Nenhuma movimentação registrada para este item; durante busca: Carregando histórico....

Quinze linhas por página; anterior/próxima; resumo de quantidade de eventos, que pode diferir da quantidade de linhas por haver vários campos num evento. Fecha por X, botão Fechar ou clique fora. Sem editar, excluir, restaurar ou exportar pelo modal. A consulta limita 500 eventos: não é garantia de todo o histórico de processos com mais eventos. Falha de fetch é silenciada pelo componente.


# 09 — Documentos compartilhados do parceiro e modais de acesso
## Condições específicas no módulo jurídico
ClientAttachmentsPanel é incorporado somente na aba Anexos e com parceiro selecionado. Recebe module LEGAL, targetType LEGAL_PROCESS e o ID do processo. Não é o mesmo armazenamento da tabela legal_process_attachments.

**allowUpload não é fornecido e seu padrão é false**: o botão Anexar arquivo desse painel compartilhado não está habilitado no uso jurídico atual. O handler genérico para upload até 20 MB existe no componente reutilizável, mas isso não o transforma em opção disponível nessa incorporação. O envio oferecido pelo formulário jurídico é o fluxo local de 5 MB.

readOnly padrão false permite exibir seleção/exclusão, sujeitas às regras reais do servidor. targetId de um processo novo pode estar undefined ou ser provisório, portanto não se deve prometer que arquivos já existentes ficarão vinculados automaticamente a um processo ainda não gravado.

## Consulta e lista
GET /api/client-attachments/ com clientId, module, targetType, targetId quando presente, search, limit=25, cursor. Filtro Filtrar... com atraso de 300ms e trim. Nova consulta cancela a anterior por AbortController. Atualizar repete página atual. Há estados de carregamento, erro e sucesso; sem dados: Nenhum documento armazenado para este contexto; busca sem resultado: Nenhum documento encontrado.

Lista com seleção individual e Selecionar todos os anexos exibidos. Exibe nome original, categoria ou Sem categoria, módulo, tamanho em KB/MB; selo textual Legado sem ACL para administradores quando aplicável. Não é uma grade editável.

Ações Ver (somente imagens/PDF), Baixar e Excluir. Ver abre /api/client-attachments/[id]/content?browser=1 em nova aba; Baixar usa /download?browser=1 com disposição de download. O navegador recebe o stream privado; não é link público do bucket. Existem regras de entrega por tipo e bloqueios do servidor.

Paginação por cursor, 25 itens; Anterior/Próxima, página e intervalo. Mantém cursores conhecidos por página; não tem salto arbitrário para página distante nem seletor de tamanho.

## Exclusão individual/em lote
Excluir ou Excluir selecionados abre confirmação inline com nome do cliente, quantidade e nomes de arquivos; avisa perda permanente; Confirmar exclusão e Cancelar. Envia DELETE por arquivo, registra sucessos e pode haver falha parcial. Não edita metadados dos documentos. O backend rejeita PUT/PATCH de metadados por imutabilidade.

Arquivos de contratos com prefixo protegido são recusados nesse DELETE com 409 e mensagem para usar a lixeira de contratos. Esse bloqueio é regra do serviço compartilhado; a lixeira não se torna submenu jurídico.

## Administração de permissões
O componente testa /acl/options; as rotas administrativas usam requireAdmin. Somente após obter opções são expostos Acesso da pasta, Histórico ACL legado, Selecionar legados exibidos, Proteger selecionados e Acesso por arquivo protegido. Usuários comuns não podem gravar essas permissões pelo servidor.

### Modal Acesso à pasta do cliente / Acesso: [arquivo]
Campos: seleção múltipla de grupos (IDs) e usuários (IDs). Em arquivo, checkbox Ativar exceção para este arquivo e substituir a regra da pasta. Desmarcar limpa listas locais; a regra herdada é usada. Pasta não tem esse checkbox.

Destinatários têm busca com atraso de 250ms, resultados paginados em lotes de cinquenta e carregamento adicional; seleção por ID; não apenas os destinatários já carregados no portal. Sem destinatários na regra: aviso de acesso exclusivo de administradores. Exceção substitui destinatários da pasta, não permissões de módulo e unidade.

GET/PUT /acl/folders/[clientId] e GET/PUT /acl/files/[attachmentId]. Salvar permissões desabilitado enquanto carrega/salva ou antes de acesso pronto. Cancelar, X e clique no fundo fecham se não estiver salvando. Erros aparecem no modal.

### Modal Confirmar proteção de anexos legados
Selecionar legados exibidos marca os da página sem ACL. Proteger selecionados limita seleção a 500. Antes de confirmar, consulta /acl/legacy/[clientId]/impact: quantidade legada, pasta configurada, número de grupos e usuários autorizados.

Exibe a relação dos arquivos selecionados, módulo e categoria. Sem regra de pasta, exige Configurar regra da pasta. Sem destinatários, alerta que só administradores terão acesso. Confirmar proteção envia POST /acl/legacy/[clientId]/protect com attachmentIds; não protege automaticamente todos os arquivos do cliente. Cancelar/X/fundo fecham quando não está salvando.

### Modal Histórico de proteção dos anexos legados
GET /acl/legacy/[clientId]/protected, paginado. Exibe nome do arquivo, módulo, categoria, nome do responsável pela adesão ou Usuário removido e data/hora. Botão Reverter proteção por registro; anterior/próxima; total de proteções; estados de erro e carregamento.

### Confirmação Reverter a proteção deste anexo?
Alertdialog com nome do arquivo e explicação de retorno às regras anteriores à adesão. Arquivo e registro permanecem intactos; não contorna módulo/unidade. Confirmar reversão envia DELETE /acl/legacy/[clientId]/protect/[attachmentId]. Cancelar mantém proteção. Não é exclusão física de documento.

## Relacionamentos e fronteiras
Os documentos compartilhados pertencem ao cliente, com metadados client_attachments e referência de alvo LEGAL_PROCESS; acesso combina autenticação, permissões do módulo, unidade e ACL quando protegidos. A leitura LEGAL exige jur_processos:VISUALIZAR nas regras do serviço. Exclusão passa pela autorização de escrita e auditoria. Acesso de um arquivo não deve ser inferido apenas por ele aparecer no formulário.

Salvar/Cancelar o formulário jurídico não reverte automaticamente alterações de ACL ou exclusões já executadas nesse painel: são requisições imediatas e independentes do POST/PUT do processo.


# 10 — API, persistência, relacionamentos e segurança
## Endpoints jurídicos
| Método e caminho | Entrada / comportamento | Resposta ou erro |
| --- | --- | --- |
| GET /api/legal-processes/dashboard-data | Exige autenticação e hasModuleAccess jur_dashboard; admin vê consulta sem filtro de unidades; demais só allowedUnitIds, vazio retorna [] | data com processos e filhos normalizados para Dashboard; 403 sem acesso |
| GET /api/legal-processes | page/limit, busca validada, unit_id/status/type/risk_level opcionais; ORDER BY updated_at DESC | data,total,page,limit,totalPages; não é a origem da lista visual deste módulo |
| GET /api/legal-processes/:id | UUID; consulta processo e quatro coleções; restringe não admin às unidades permitidas | data; 404 ausente; 403 sem unidade |
| POST /api/legal-processes | process_number e status requeridos; ignora id do cliente; whitelist de campos; filhos opcionais | 201 data; 400 referência inválida; 409 duplicidade de constraint; erro de criação |
| PUT /api/legal-processes/:id | UUID; valida acesso à unidade atual e eventual nova unidade; atualiza campos presentes; substitui coleções enviadas | data; 404/403/400/409 ou erro de atualização |
| DELETE /api/legal-processes/:id | UUID; autorização por unidade; transação, auditoria e DELETE | success true e mensagem; 404/403/500 |

A busca do endpoint de listagem usa process_number, opposing_party, subject, responsible_lawyer com ILIKE; é diferente da busca local, que inclui vara, comarca e parceiro. Não há endpoints dedicados de CRUD dos filhos nesse router.

## Transporte e comportamento das requisições
O serviço apiService usa caminhos relativos de mesma origem, credentials=include, JSON nos métodos de gravação e cabeçalho de unidade conforme seleção local. O padrão é timeout de 15 segundos e até três tentativas totais; há espera base de 500ms multiplicada pela tentativa para certos erros de servidor/rede. Erros HTTP abaixo de 500 não são repetidos por esse fluxo; aborto/timeout vira ApiError. Esse padrão não é uma confirmação de idempotência do POST jurídico e pode afetar duplicações se a conexão falhar após uma gravação já confirmada. Não há chave de idempotência específica no handler de criação de processo.

## Contrato de gravação
O frontend converte recursivamente camelCase para snake_case. String vazia em chave terminada _id vira null. O backend filtra por whitelist: unit_id, process_number, court, jurisdiction, type, role, opposing_party, opposing_party_document, opposing_party_lawyer, opposing_party_lawyer_oab, partner_id, responsible_lawyer, responsible_lawyer_oab, status, subject, cause_value, provision_value, risk_level, distribution_date, last_movement_date, notes, notes_header, notes_footer, tags, admission_id, client_id, client_name, contract_number.

Cada POST/PUT usa BEGIN/COMMIT/ROLLBACK. Filhos enviados em PUT são apagados por process_id e reinseridos; não são atualizados por seu ID. Coleção ausente preserva os registros; array vazio apaga todos da coleção. IDs provisórios de filhos não são preservados nos INSERTs. Esse desenho pode substituir IDs e afetar referências do cliente já carregadas e deduplicação de alertas. Sem controle de versão otimista comprovado: atualizações concorrentes com arrays antigos podem sobrescrever alterações.

## Tabelas e cardinalidades
| Origem | Destino / cardinalidade | Exclusão / observação |
| --- | --- | --- |
| legal_processes.id | legal_process_movements.process_id, 1:N | FK UUID, ON DELETE CASCADE |
| legal_processes.id | legal_process_deadlines.process_id, 1:N | FK UUID, ON DELETE CASCADE |
| legal_processes.id | legal_process_hearings.process_id, 1:N | FK UUID, ON DELETE CASCADE |
| legal_processes.id | legal_process_attachments.process_id, 1:N | FK UUID, ON DELETE CASCADE |
| legal_processes.unit_id | companies.id, N:1 | Migração de integridade declara UUID/FK, ON DELETE SET NULL |
| legal_processes.partner_id | clients.id, N:1 | Migração de integridade declara UUID/FK, ON DELETE SET NULL |
| legal_processes.client_id | clients.id, N:1 | Migração posterior declara UUID/FK, ON DELETE SET NULL |
| legal_processes.admission_id | admissions.id, N:1 | Migração posterior declara UUID/FK, ON DELETE SET NULL |
| Prazo.responsibleId | config.collaborators.id | Vínculo no objeto/tela; não gravado pelos INSERTs atuais desse router |
| responsibleLawyer | collaborators.name | Seleção e procura textuais, sem ID de colaborador nesse campo |
| client_attachments | Cliente + alvo LEGAL_PROCESS | Serviço compartilhado separado da tabela de anexos base64 |

As declarações de migração não substituem auditoria do catálogo instalado; o projeto também contém proteções para referências legadas. Não foi executada migração, conversão ou saneamento para este inventário.

## Schema declarado de cada coleção
- Processo: UUID primário automático; unidade; número TEXT NOT NULL; vara/comarca/tipo/papel; partes/advogados/OABs; parceiro; status TEXT NOT NULL DEFAULT ATIVO; assunto; valores TEXT; risco TEXT DEFAULT MEDIO; datas TEXT; HTML de notas/cabeçalho/rodapé; tags JSONB DEFAULT []; created_at/updated_at TIMESTAMPTZ DEFAULT NOW(); campos posteriores cliente/admissão/nome do cliente/número de contrato.
- Movimentação: id UUID automático, process_id obrigatório, date TEXT, description TEXT, type TEXT, created_at. A migração inicial não declara source.
- Prazo: id UUID automático, process_id obrigatório, type/description/due_date/status/notes TEXT, status padrão PENDENTE, created_at. A migração inicial não declara responsible_id.
- Audiência: id UUID automático, process_id obrigatório, type/date/time/location/status/notes TEXT, status padrão AGENDADA, created_at.
- Anexo local: id UUID automático, process_id obrigatório, title/file_name/file_data TEXT e created_at.

Valores enumerados na interface são uniões TypeScript e opções de tela; esse router não implementa validação exaustiva dessas enumerações no servidor. As datas dessas tabelas são declaradas TEXT na origem, não tipos processuais especiais. O índice process_number é comum na migração inicial, **não UNIQUE**: a tela não assegura unicidade apenas pelo número.

## Referências verificadas no backend
validateReferenceIds verifica client_id, partner_id, admission_id e unit_id nas tabelas correspondentes. Se há admissão e alteração de admissão/cliente, consulta o cadastro: recusa vínculo incoerente com o cliente e copia contract_number como retrato de exibição. Não reconstrói identidade por contrato ou nome para a gravação normal da API.

## Segurança e auditoria
Middleware global exige JWT/sessão válida para as APIs não públicas. /api/legal-processes não é rota pública; conferência sem sessão retornou 401. Não confundir falta de requireAuth explícito em cada rota com ausência de autenticação global.

Na interface, LegalTrackingPanel chama validarPermissao com INCLUIR, ALTERAR e EXCLUIR, sem prefixo de submenu. O contexto permite admin ou procura ação genérica/sufixo em grupos. Isso **não equivale a checagem estrita jur_processos:ALTERAR**. Botões podem aparecer e a ação ser barrada depois; a chamada de validarPermissao também pode disparar toast durante render.

No backend jurídico, além da autenticação global, há checagens explícitas de unidade e checagem de módulo no endpoint do Dashboard. O router não repete uma exigência de ação INCLUIR/ALTERAR/EXCLUIR por grupo para cada mutação. O GET de listagem aceita unit_id fornecido e não aplica ali automaticamente allowedUnitIds. Essas são propriedades do código, não uma certificação de segurança de todo o ambiente.

CREATE/UPDATE/DELETE geram auditoria obrigatória ACOMP_JURIDICO dentro da transação, com usuário, nome, IP e snapshots do processo principal. Falha da auditoria impede confirmar a transação. Os snapshots desse router não incluem as coleções filhas completas. Há também chamada logTransaction no cliente antes do HTTP; ela não substitui a evidência de sucesso no servidor.

## Erros e feedback
Toasts: Processo cadastrado com sucesso; Processo atualizado com sucesso; Processo excluído com sucesso. Sem permissão: Acesso Negado e Sem permissão para incluir/alterar/excluir. Falhas: Erro ao salvar/Erro ao excluir; mensagem retornada ou texto padrão. O formulário/modal pode já estar fechado quando a falha chega.


# 11 — Integrações externas ao menu e limitações confirmadas
## Integrações efetivas
- Configuração autenticada e cadastros de clientes, unidades e colaboradores.
- Serviço REST de processos e persistência PostgreSQL.
- Auditoria transacional e consulta de histórico.
- Mensageria interna para alertas 7/5/3 dias.
- Socket.IO e invalidação de Dashboard a partir de alterações de banco.
- Cadastro de formulários e TinyMCE para notas/documentos.
- Armazenamento compartilhado de anexos do cliente, streams privados, ACL de pasta/arquivo e proteção de legados.
- Navegador: FileReader/base64, Date/locales, confirmação nativa, janelas e impressão.

## Integrações de dados fora destes submenus
O importador/exportador geral declara legal_processes, com processo identificado para deduplicação por process_number e campos para cliente, unidade, parceiro e admissão. Nomes recebidos na importação são entradas de resolução para IDs; não mudam o contrato normal da tela.

Campos declarados no layout de importação incluem número; nome do cliente; unidade virtual; tribunal/vara; comarca; tipo; status; polo; assunto; parte contrária e documento; advogados e OABs; parceiro virtual; contrato de admissão virtual; valor da causa; provisão; risco; datas; notas/cabeçalho/rodapé; tags. O catálogo admite INATIVO no status de importação, opção que **não aparece no seletor de status do formulário jurídico**. Campos virtuais não são colunas persistidas com aquele nome.

Cliente/admissão/contrato são aceitos pela API compartilhada e fazem parte da carga de configuração, mas não têm controles próprios no formulário CompanyLegalProcess deste menu. O painel Atendimento > Jurídico reutiliza serviços jurídicos, porém **não é submenu de Acompanhamento Jurídico** e não foi confundido com este escopo.

Não foi encontrado nos seis componentes acionamento de DataJud, consulta processual de tribunal, scraping judicial, PJe, e-SAJ, eproc, assinatura digital, peticionamento, integração bancária, WhatsApp ou OCR. Não há motivo para apresentar qualquer deles como botão ativo deste módulo. A referência a número CNJ é rótulo de campo, não integração com CNJ.

## Divergências que afetam campos e acionamento
| Ponto | Evidência e consequência |
| --- | --- |
| Responsável do prazo | Tela envia responsibleId → responsible_id, mas INSERT de prazos só usa process_id,type,description,due_date,status,notes; seleção não é preservada por esse código |
| Fonte da movimentação | Tela envia source, INSERT de movimentos omite; valor não é persistido pelo router |
| OAB e nomes de propriedade | Modelo usa responsibleLawyerOAB/opposingPartyLawyerOAB; configuração retorna ...Oab. Conversão automática de OAB em snake case gera _o_a_b, diferente da whitelist _oab; pode impedir envio correto de campos editados |
| Resposta jurídica genérica | toFrontend omite campos como jurisdiction, unitId, partnerId, OABs, notesHeader/notesFooter e updatedAt; filhos ficam em shape de banco. Não equivale à projeção completa de /api/config |
| Anexos base64 na recarga | /api/config agrega movimentos/prazos/audiências, não os anexos base64; ProcessList não consulta GET por ID ao editar. Anexos já salvos podem não aparecer ao reabrir pelo caminho atual |
| Gravação e tela desatualizada | Callbacks só recarregam os indicadores; não substituem coleção da configuração nem usam resposta para atualizar lista |
| Modal fecha antes do HTTP | Sucesso ou falha pode chegar depois do fechamento, sem retorno automático ao rascunho |
| Limite real de anexos locais | Tela aceita 5MB, mas /api/legal-processes usa parser JSON global 1mb; base64 e vários anexos podem exceder o corpo antes da gravação |
| Duplicação | Não há modal de revisão; não elimina campo attachments do objeto copiado |
| Status vencido | Badge por data não significa status VENCIDO salvo; filtro e alerta podem ter interpretações diferentes |
| Última movimentação | Recebe data da movimentação editada/incluída, não a maior; excluir não recalcula |
| Alertas | Dependem de tela montada, memória por instância e envio interno ALL; não são cron nem notificação externa garantida |
| Audiência adiada | Só altera status, não agenda nova data |
| Prévia do modelo | previewHtml é calculado, mas não renderizado no formulário; usado apenas para habilitar impressão |
| Imprimir | Disponibilidade e modelos da grade/detalhe passam por FormTemplateButton; seletor interno de Notas segue caminho distinto |
| Referência de advogado | Persiste nome, não ID de colaborador; homônimos/mudanças de nome não têm resolução relacional segura nesse campo |
| Datas | Mistura UTC, hora atual e formatação local; sem cálculo de prazo em dias úteis |
| Controle concorrente | PUT substitui coleções inteiras e não verifica uma versão esperada do processo |

Essas observações não foram corrigidas: o pedido é de levantamento e entrega em ZIP. Não se executou teste destrutivo para comprová-las com registros reais.


# 12 — Matriz de operações e roteiro de acionamento
## Matriz CRUD por área
| Entidade / local | Criar | Ler | Alterar | Excluir |
| --- | --- | --- | --- | --- |
| Dashboard | Não | Indicadores e dez itens por quadro | Não | Não |
| Processo / grade | Novo Processo ou Duplicar | Grade e Ver | Editar → Salvar Alterações | Excluir → confirmação → DELETE |
| Movimentação / detalhe | + Adicionar → formulário inline | Linha do tempo | Editar → Salvar | Excluir → confirmação |
| Prazo / detalhe | + Prazo → Adicionar | Cartões | Apenas Cumprido | X → confirmação |
| Prazo / aba consolidada | Novo Prazo → modal → Salvar | Grade e modal preenchido | Editar, status completo ou Cumprido | Excluir → confirmação |
| Audiência / detalhe | + Audiência → Adicionar | Cartões | Não há edição direta | X → confirmação |
| Audiência / aba consolidada | Nova Audiência → modal → Salvar | Grade e modal preenchido | Editar, Realizada, Adiada, status Cancelada | Excluir → confirmação |
| Notas | No cadastro de processo | Detalhe sanitizado e editor | Editor e salvar processo | Esvaziar conteúdo e salvar; sem ação de exclusão separada |
| Anexo base64 do processo | Selecionar arquivo e salvar processo | Grade local / Visualizar / duplo clique | Sem renomear direto | Remove local e salva processo |
| Anexo compartilhado no uso jurídico | Upload não exposto nesse painel | Filtrar / Ver / Baixar | Metadados imutáveis; ACL admin separada | Exclusão individual/lote com confirmação e autorização |
| Histórico de auditoria | Gerado pelas operações | Modal somente leitura | Não | Não |
| Regra ACL / pasta / arquivo | Configurar como admin | Modal de acesso | Salvar permissões | Desativar exceção / ajustar regra; não é apagar arquivo |
| Proteção de legado | Opt-in explícito dos selecionados | Histórico paginado | Reverter proteção mediante confirmação | Reversão não exclui documento |

## Roteiros operacionais
1. **Cadastrar processo:** menu → Processos → Novo Processo → Dados Gerais → preencher número e revisar tipo/status/unidade/data → Partes → selecionar parceiro por ID e advogado entre as opções → Financeiro → Notas/Anexos se necessário → Cadastrar Processo → observar toast e eventual necessidade de recarga da configuração.
2. **Consultar processo e movimentações:** Processos → busca/filtros → Ver → conferir resumo → + Adicionar em Movimentações → preencher data/tipo/descrição/fonte → Adicionar. Persistência da fonte é uma limitação, não uma garantia.
3. **Cadastrar prazo com validações da tela consolidada:** Prazos e Audiências → Prazos → Novo Prazo → selecionar processo → descrição/data → tipo/status/responsável/observações → Salvar. Não confundir com formulário inline menos restritivo do detalhe.
4. **Concluir prazo:** na grade consolidada, linha PENDENTE → Marcar como Cumprido; ou no detalhe → Cumprido. Não há confirmação intermediária. É atualização do processo, não DELETE do prazo.
5. **Agendar audiência:** aba Audiências → Nova Audiência → processo/data/hora → tipo/local/status/notas → Salvar.
6. **Adiar e remarcar:** AGENDADA → Marcar como Adiada altera só status; abrir Editar para modificar data/hora quando desejado. Não há duplicação automática nem preservação de uma ocorrência anterior por essa ação.
7. **Gerar documento:** Processos → Ver → Gerar Documento → modelo; conferir que usa aquele processo. Na grade, Formulários usa apenas o primeiro registro da página.
8. **Anexar localmente:** Editar/Novo → Anexos → título opcional → Selecionar Arquivo → conferir linha/Visualizar → salvar processo. Cancelar descarta anexos ainda só locais.
9. **Consultar documentos privados do parceiro:** escolher parceiro → Anexos → painel compartilhado → Filtrar/Ver/Baixar. Não usa dados base64 do outro quadro.
10. **Acesso administrativo:** painel compartilhado → Acesso da pasta ou Acesso do arquivo → grupos/usuários → Salvar permissões. Operação imediata, separada do salvamento do processo.
11. **Excluir processo:** grade → Excluir → ler número → confirmar. A API apaga o processo e as quatro coleções filhas por cascade declarada. Não há lixeira de processo neste menu.

## Inventário de sobreposições e confirmações
- Formulário Novo/Editar Processo em tela inteira, com cinco abas.
- Novo/Editar Prazo consolidado.
- Nova/Editar Audiência consolidada.
- Histórico de Movimentações de auditoria.
- Menu suspenso de modelos de impressão.
- Dropdown de parceiro.
- Formulários inline de movimentação, prazo e audiência no detalhe (não são modais).
- Diálogos nativos de exclusão de processo/movimentação/prazo/audiência.
- Selecionador de arquivo e janela de visualização/diálogo de impressão do navegador.
- Confirmação inline de exclusão de anexos compartilhados.
- Modal Acesso à pasta/Acesso ao arquivo.
- Modal de proteção de anexos legados.
- Modal de histórico de proteção legada.
- Alertdialog de reversão de proteção.
- Diálogos de edição rich text oferecidos pela biblioteca TinyMCE, sem auditoria dinâmica de suas telas internas.

## Usabilidade e limites observáveis
Há feedback por toast, estados vazios, etiquetas coloridas, filtros com reset de página, tabelas com rolagem e modais de altura limitada. Não há confirmação geral de perda de edição, autosave, edição de células na grade, exportação CSV/XLSX direta nesses três submenus, calendário mensal, drag-and-drop de agenda, campo de pesquisa dentro dos seletores de processo ou validação local de conflito de audiência.

Formulários jurídicos centrais não declaram explicitamente role=dialog, aria-modal, trap de foco ou Escape para fechar; componentes ACL incluem papéis de diálogo e rótulos. Não foi feita auditoria completa de acessibilidade ou toque. Abas do formulário de processo não possuem overflow horizontal explícito no seu contêiner; responsividade das telas internas exige verificação autenticada para confirmar ausência de cortes.

# Financeiro > Cadastros

## Relação detalhada de telas, campos, funcionalidades, integrações e relacionamentos

### Como interpretar este documento

Levantamento do código disponível do Meu Gestor Inteligente. Não foram alterados registros nem consultados dados reais da empresa. A interface autenticada e os comportamentos em produção não foram testados nesta documentação.

- **Padrão de inclusão:** valor atribuído ao clicar em Novo; não é o valor atual da empresa.
- **Exemplo inicial local:** registro de exemplo definido nas constantes do projeto; não é cadastro obrigatório nem confirmação de que existe no banco.
- **Armazenado sem campo:** informação que existe no modelo ou na gravação, mas não tem controle editável nessa tela.
- **CRUD:** criar, consultar, alterar e excluir. O manual informa expressamente quando alguma dessas operações não existe na interface.
- **Integração interna:** compartilhamento de cadastro/identificador com outro módulo. Não implica conexão externa com banco, cartório ou órgão fiscal.
- **Painel de formulário:** substitui a listagem dentro da página. Não deve ser confundido com modal sobreposto.

## 1. Menu e abrangência

O caminho **Financeiro > Cadastros** possui exatamente estas quatro opções:

| Opção do menu | Título da tela | Finalidade |
|---|---|---|
| Fornecedores | Fornecedores | Cadastrar parceiros de natureza fornecedor, compartilhados com a base de pessoas/clientes. |
| Tipo Documento | Tipos de Documento | Definir classificações documentais dos títulos financeiros. |
| Portador | Portadores | Definir quem mantém/cobra o título e eventual vínculo com conta bancária. |
| Plano de Contas | Plano de Contas | Definir classificação financeira de receita/despesa e hierarquia sintética/analítica. |

**Conta Corrente > Cadastro** não pertence a este submenu. Contas bancárias são descritas aqui somente onde se relacionam com os quatro cadastros. Da mesma forma, Contas a Pagar, Contas a Receber, Movimentos e Conciliação são tratados como consumidores desses cadastros, não como telas integralmente documentadas.

## 2. Convenções comuns de navegação e gravação

### 2.1 Abertura e encerramento dos formulários

- **Novo Fornecedor / Novo Tipo / Novo Portador / Nova Conta:** abre um painel de inclusão na própria página.
- **Editar**, na linha: carrega uma cópia do registro no mesmo painel.
- O cabeçalho diferencia inclusão de edição.
- **Salvar:** valida e solicita persistência; mensagens informam o resultado.
- **Cancelar** ou **X do cabeçalho:** volta à listagem sem solicitar a gravação das alterações locais.
- O sistema registra o comando de salvar em **Ctrl+Enter** ou **Command+Enter**, enquanto o formulário está registrado como ativo. O contexto de atalhos consultado não implementa tecla Escape para cancelar; não se deve pressupor esse atalho.
- Para Tipo Documento, Portador e Fornecedores, o botão mostra **Salvando...** e fica desabilitado durante a solicitação; Cancelar também é desabilitado. O X do cabeçalho não tem o mesmo bloqueio explícito.
- Plano de Contas não tem esse estado visual de salvamento/desabilitação no formulário atual.

### 2.2 Permissões

Os acionamentos de inclusão e edição consultam permissões específicas de cada opção:

| Cadastro | Inclusão | Alteração | Exclusão na tela |
|---|---|---|---|
| Fornecedores | `fin_fornecedores:INCLUIR` | `fin_fornecedores:ALTERAR` | `fin_fornecedores:EXCLUIR` |
| Tipo Documento | `fin_tipo_documento:INCLUIR` | `fin_tipo_documento:ALTERAR` | Não disponível |
| Portador | `fin_portador:INCLUIR` | `fin_portador:ALTERAR` | Não disponível |
| Plano de Contas | `fin_plano_contas:INCLUIR` | `fin_plano_contas:ALTERAR` | Não disponível |

A existência visual de um botão não é garantia de autorização. Há verificações no acionamento e nas rotas de persistência. A gravação do Plano de Contas usa uma rota de configuração que exige administrador; portanto, uma permissão de tela isolada não garante que um usuário comum consiga salvar.

### 2.3 Botão comum de auditoria

Todas as quatro grades apresentam o ícone de relógio **Histórico de movimentações (somente leitura)**. Seu modal está descrito na seção 7.

## 3. Fornecedores

### 3.1 Objetivo e identidade do cadastro

Fornecedor é uma pessoa da base compartilhada de clientes/pessoas identificada pela natureza **F**. Não é uma tabela de pessoas completamente independente.

- A tela carrega a base pela API de clientes e mostra somente registros com `natureza = F`.
- A inclusão e a edição por essa tela gravam a natureza F automaticamente; não há seletor visível para alterar essa natureza.
- Relacionamentos financeiros usam o identificador da pessoa, não apenas o nome/CPF/CNPJ.
- Por compartilhar a base, esse registro pode ter vínculos além de Contas a Pagar, conforme o restante do sistema.

### 3.2 Data Grid da listagem

| Coluna | Conteúdo e apresentação |
|---|---|
| Nome / Razão Social | Nome cadastrado em destaque. |
| CPF / CNPJ | Documento informado; “—” se vazio. |
| Telefone | Telefone principal; “—” se vazio. |
| Cidade/UF | Cidade seguida de /UF quando ambos existem; “—” quando não existe cidade. |
| Ações | Histórico de auditoria, Editar e Excluir. |

**Pesquisa:** campo “Pesquisar por Nome ou CPF/CNPJ...”. Filtra localmente nome sem distinção de maiúsculas/minúsculas ou trecho do documento. Não há normalização explícita dos sinais do documento nessa busca; pesquisar somente números pode não casar com um documento formatado.

**Carregamento e vazio:** mostra “Carregando...” quando apropriado e “Nenhum fornecedor encontrado.” quando o conjunto filtrado fica vazio.

**Ordenação e volume:** a API da base usa nome crescente por padrão. A grade não tem cabeçalho de ordenação clicável nem controles visíveis de paginação. O componente solicita uma página de até 500 pessoas e filtra a natureza F depois da carga. Portanto, esta tela não comprova listar todos os fornecedores quando há mais pessoas do que o limite da página.

**Não há** seleção múltipla, duplicação, exportação, importação ou exclusão em lote nessa listagem.

### 3.3 Formulário de inclusão/edição — Dados do Fornecedor

| Campo visível | Tipo / opções | Padrão ao incluir | Regra e efeito |
|---|---|---|---|
| Tipo de Pessoa | Lista: Física (CPF), Jurídica (CNPJ) | Jurídica | Trocar altera o rótulo do documento. Não dispara consulta externa. |
| Nome / Razão Social * | Texto | Vazio | Obrigatório na validação do formulário; digitado em maiúsculas. |
| CPF ou CNPJ | Texto | Vazio | Rótulo depende do tipo. O formulário não contém máscara nem validação explícita de dígitos verificadores. |
| Telefone | Texto | Vazio | Servidor remove formatação e preserva os dígitos. Não há botão de ligação ou envio nessa tela. |
| E-mail | Campo do tipo e-mail | Vazio | Não envia mensagem; não há chamada explícita de validação completa de e-mail no método de salvar. |
| CEP | Texto | Vazio | Digitação manual; sem botão de buscar CEP ou preenchimento automático nesta tela. |
| Endereço | Texto | Vazio | Logradouro/endereço digitado manualmente. |
| Cidade | Texto | Vazio | Digitação manual. |
| Estado | Texto, até 2 caracteres | Vazio | Transformado em maiúsculas. Não há lista de UFs. |
| Bairro | Texto | Vazio | Digitação manual. |
| Anotações | Área de texto, 3 linhas | Vazio | Observações livres. |

**Campos internos ou não expostos nesse formulário**

| Informação | Tratamento |
|---|---|
| Identificador | Gerado pelo servidor na criação; reutilizado na edição e nos relacionamentos. |
| Natureza | F, forçada na gravação dessa tela. |
| Telefone secundário | Inicializado vazio, mas sem campo visível nesse formulário. |
| Número do endereço | Inicializado vazio, mas sem campo visível nesse formulário. |
| Complemento | Inicializado vazio, mas sem campo visível nesse formulário. |
| Outros atributos da pessoa existente | A edição começa copiando o registro existente; isso não significa que todos os seus atributos tenham campos nessa tela. |

**Preenchimento inicial completo:** tipo Jurídica; natureza F; nome, documento, telefone principal/secundário, e-mail, CEP, endereço, número, complemento, bairro, cidade, estado e anotações vazios.

### 3.4 CRUD e acionamentos

1. **Criar:** Novo Fornecedor → preencher Nome e demais dados → Salvar → POST na base de pessoas → mensagem “Fornecedor salvo.” → volta à listagem.
2. **Consultar:** grade, pesquisa, formulário de edição para ver os demais campos e histórico de auditoria.
3. **Alterar:** Editar → dados atuais → Salvar → PUT usando o ID existente. O registro continua de natureza F.
4. **Excluir:** Excluir → confirmação nativa do navegador `Excluir fornecedor "[nome]"?` → confirmar envia DELETE; cancelar não remove.
5. **Falhas:** salvar apresenta “Não foi possível salvar o fornecedor.”; exclusão apresenta “Erro ao excluir fornecedor.”. A mensagem genérica da tela não garante que ela mostre detalhadamente uma dependência retornada pelo servidor.

### 3.5 Relacionamentos e integrações

- **Contas a Pagar:** o título vincula pessoa por `clientId` e exibe nome do fornecedor. Baixas em lote e faturamento de títulos podem exigir o mesmo fornecedor; são operações do módulo de títulos, não do cadastro de fornecedores.
- **Seletor de fornecedor em Contas a Pagar:** o código usa a lista de pessoas recebida pelo painel, sem filtro local explícito por natureza F naquele seletor. Assim, não se deve afirmar que ele sempre mostra apenas o que esta grade mostra.
- **Exclusão protegida:** a rota de pessoas verifica vínculos em Admissões, Títulos Financeiros, Agendamentos e Documentos no Bucket antes da exclusão. Referências no banco também podem impedir a remoção.
- **Telefone e GoTalk:** após criar/alterar uma pessoa com telefone, o servidor agenda uma tentativa assíncrona de vincular retroativamente mensagens GoTalk aos telefones informados. Isso não equivale a enviar WhatsApp, criar atendimento nem garantir correspondência das mensagens.
- **E-mail, CPF/CNPJ e CEP:** são dados de cadastro nessa tela. Não foram identificadas ações de envio de e-mail, consulta Receita Federal ou consulta automática de CEP nesse formulário.
- **Unidade:** esse formulário não expõe seletor de unidade. Não se deve inferir acesso global ou entre unidades apenas por essa ausência; o escopo depende da sessão e da camada de dados.

## 4. Tipo Documento

### 4.1 Objetivo

Classifica a espécie de documento associada a um título, com categoria de aplicação, marca fiscal e indicação de exigência de número.

### 4.2 Data Grid “Tipos de Documento”

| Coluna | Conteúdo |
|---|---|
| Descrição | Nome/descrição do tipo documental. |
| Categoria | AMBOS, PAGAR ou RECEBER. |
| Fiscal | SIM ou NÃO. |
| Ações | Histórico de auditoria e Editar. |

- **Novo Tipo** abre a inclusão.
- Não há pesquisa, filtros, seleção múltipla, duplicação, paginação visual ou botão de exclusão.
- A API solicita até 500 registros e ordena pela descrição crescente. Não há navegação para páginas posteriores nessa tela.
- Quando a API não traz uma lista não vazia, o componente usa a lista de tipos recebida da configuração. Esse fallback não comprova sincronização completa nem ausência de registros no servidor.
- O status e a exigência de número não aparecem como colunas.

### 4.3 Formulário — Dados do Documento

| Campo | Controle / opções | Padrão novo | Efeito do acionamento |
|---|---|---|---|
| Descrição | Texto | Vazio | Converte digitação para maiúsculas; obrigatório para salvar. |
| Categoria | Lista | Ambos (Pagar/Receber) | Escolhe AMBOS, PAGAR ou RECEBER. Não abre outro painel. |
| Documento Fiscal | Checkbox | Desmarcado | Define `isFiscal`. Marcar não emite nota fiscal nem consulta autoridade fiscal. |
| Exige Número do Documento | Checkbox | Marcado | Define `requiresDocNumber`; é um atributo do tipo documental. |

**Armazenados sem controle visível:** ID e status. Novos tipos recebem status ATIVO; não há botão ou seletor de inativação neste formulário.

### 4.4 CRUD e confirmação

- **Criar:** Novo Tipo → descrição/categoria/marcações → Salvar.
- **Consultar:** grade e formulário.
- **Alterar:** Editar → mudar os campos → Salvar.
- **Excluir:** não há botão na interface. Embora a API genérica tenha rota de exclusão com verificação de títulos vinculados, isso não constitui uma funcionalidade acessível nessa grade.
- **Cancelar / X:** retorna à listagem sem salvar as alterações do painel.
- Sem descrição, avisa “Descrição obrigatória.”.
- Em falha de gravação, apresenta “Não foi possível salvar o tipo de documento.”.
- Gravação principal é na API de tipos; depois atualiza a lista local/configuração e solicita atualização.

### 4.5 Integrações e limites das marcações

- **Contas a Pagar e Contas a Receber:** selecionam tipo documental pelo ID e exigem a seleção na validação dos títulos.
- **Categoria PAGAR/RECEBER/AMBOS:** fica gravada, mas os seletores examinados de Pagar/Receber percorrem toda a lista efetiva, sem filtro explícito pela categoria. Não se deve prometer que a categoria bloqueia automaticamente uso no outro módulo.
- **Documento Fiscal:** a marca não cria emissão de NF-e/NFS-e, transmissão SEFAZ, XML fiscal ou integração contábil externa.
- **Exige Número do Documento:** não foi encontrado consumo dessa flag nos componentes/rotas de títulos examinados; a marca é armazenada, mas este levantamento não confirma imposição condicional da exigência por essa flag.
- **Status:** o cadastro novo é ativo. Não existe controle de inativação aqui e os seletores examinados não filtram explicitamente por status.
- **Movimentação bancária:** o contrato de dados de movimento admite referência ao tipo documental; a existência do campo no modelo não implica que todos os fluxos de movimentação o preencham.

### 4.6 Exemplos iniciais locais

São exemplos definidos nas constantes, não registros reais ou obrigatórios.

| Descrição | Categoria | Fiscal | Exige número | Status |
|---|---|---|---|---|
| NOTA FISCAL | AMBOS | Sim | Sim | ATIVO |
| BOLETO BANCÁRIO | AMBOS | Não | Sim | ATIVO |
| RECIBO | AMBOS | Não | Não | ATIVO |
| DUPLICATA | RECEBER | Sim | Sim | ATIVO |

## 5. Portador

### 5.1 Objetivo

Identifica a carteira ou entidade responsável pela guarda/encaminhamento/cobrança do título financeiro. Trata-se de classificação e eventual vínculo de conta, não credenciamento automático em instituição externa.

### 5.2 Data Grid “Portadores”

| Coluna | Conteúdo |
|---|---|
| Nome | Nome do portador. |
| Tipo | Código do tipo: CARTEIRA, BANCO, CARTORIO ou outro valor já armazenado. |
| Ações | Histórico de auditoria e Editar. |

- **Novo Portador** abre a inclusão.
- Código e conta associada não são colunas da grade.
- Não há busca, ordenação clicável, duplicação, exclusão, exportação ou paginação visual.
- Solicita até 500 portadores, ordenados por nome na API; usa a lista recebida da configuração se a resposta efetiva está vazia.

### 5.3 Formulário — Dados do Portador

| Campo | Controle / opções | Padrão novo | Regras e acionamentos |
|---|---|---|---|
| Código | Texto | Vazio | Converte para maiúsculas. A API exige código, embora a validação local confira apenas nome. Preencha-o para evitar rejeição. |
| Nome | Texto | Vazio | Obrigatório na tela e API; converte para maiúsculas. |
| Tipo | Lista: Carteira, Banco, Cartório | Carteira | Ao selecionar Banco, mostra Conta Bancária Associada. Os demais tipos ocultam esse campo. |
| Conta Bancária Associada | Lista: Selecione... + descrições das contas cadastradas | Sem seleção | Visível somente quando Tipo = Banco. Grava o ID da conta, não o nome. O formulário não exige explicitamente a seleção. |

**Campos armazenados, mas não editáveis aqui**

- Identificador.
- Status: ATIVO ao incluir, sem seletor de inativação.
- Código de agência e código de contrato: aceitos no payload/modelo, mas sem campos visíveis nesse formulário.

**Troca do tipo:** ocultar Conta Bancária Associada ao escolher Carteira/Cartório não limpa explicitamente o ID da conta do estado do formulário. Um vínculo anterior pode permanecer gravado; não se deve tratar a ocultação como desvinculação automática.

### 5.4 CRUD e mensagens

- **Criar:** Novo Portador → código/nome/tipo → se Banco, escolher conta se desejado → Salvar.
- **Consultar:** grade; Editar revela os demais campos.
- **Alterar:** Editar → campos → Salvar.
- **Excluir:** não disponível nessa tela. A API genérica dispõe de exclusão com verificação de títulos associados, mas a interface não oferece esse acionamento.
- Sem nome, aviso “Nome obrigatório.”.
- Falhas de API, inclusive falta do código, resultam na mensagem genérica “Não foi possível salvar o portador.”.
- Cancelar/X retorna sem salvar.

### 5.5 Relacionamentos e integrações

- **Portador → Conta Bancária:** opcional, por identificador de conta cadastrada em Financeiro > Conta Corrente > Cadastro. A lista mostra a descrição da conta, sem filtro explícito por status.
- **Título financeiro → Portador:** Pagar e Receber usam o portador pelo ID; o preenchimento do portador é obrigatório nas validações dos títulos.
- **Movimentos:** o modelo de movimentos admite referência de portador; isso não significa que cadastrar um portador crie movimentação ou altere saldo.
- **Banco:** selecionar Banco não cria convênio, credencial, API bancária, boleto, cobrança registrada, arquivo CNAB ou conciliação automática.
- **Cartório:** selecionar Cartório não envia protesto nem consulta cartório.
- **Jurídico/Terceiros:** existem como tipos no modelo e nos portadores iniciais do servidor, mas não constam na lista de opções editáveis do formulário atual. Registros desses tipos podem aparecer na grade com valor que o seletor não oferece. Não substituir seu tipo sem conferir o objetivo do cadastro.
- **Exclusão e uso:** referências em títulos impedem remoção pela rota que valida dependências.

### 5.6 Portadores padrão e exemplos

Quando a tabela do servidor está vazia, o inicializador prevê estes portadores ativos:

| Código | Nome | Tipo |
|---|---|---|
| 001 | CARTEIRA PRÓPRIA | CARTEIRA |
| 002 | COBRANÇA BANCÁRIA | BANCO |
| 003 | CARTÓRIO | CARTORIO |
| 004 | JURÍDICO | JURIDICO |
| 005 | TERCEIROS | TERCEIROS |

Não é uma lista de dados reais. Separadamente, as constantes locais antigas contêm exemplos **CRT / CARTEIRA (LOCAL)** e **BB-01 / COBRANÇA BB**. Esses conjuntos têm origens distintas e não devem ser somados como se fossem todos padrões efetivamente cadastrados na empresa.

## 6. Plano de Contas

### 6.1 Objetivo e hierarquia

Classificação financeira dos lançamentos:

- **Receita/Despesa:** natureza financeira da conta.
- **Sintética:** agrupadora, quando “Conta Analítica” está desmarcado.
- **Analítica:** categoria final que aceita lançamentos.
- **Conta Pai:** vínculo com uma conta sintética; sem pai, a conta é raiz.
- O vínculo hierárquico é por ID. O código estruturado é informado manualmente; digitar `1.01.01` não associa automaticamente o pai.

### 6.2 Data Grid

| Coluna | Conteúdo |
|---|---|
| Nome | Nome da conta; sintéticas em negrito, analíticas com recuo. |
| Tipo | RECEITA ou DESPESA. |
| Analítica | SIM ou NÃO. |
| Ações | Histórico de auditoria e Editar. |

- **Nova Conta** abre inclusão.
- A lista é ordenada crescentemente pelo texto do código estruturado, não por uma regra numérica de níveis.
- O código não é mostrado como coluna própria, embora seja usado para ordenar e apareça no seletor de conta pai.
- O recuo diferencia analítica/sintética, sem oferecer árvore expansível por níveis.
- Não há busca, filtros, exclusão, duplicação, importação/exportação ou paginação visual nessa grade.

### 6.3 Formulário — Dados da Conta

| Campo | Controle / opções | Padrão novo | Regra e efeito |
|---|---|---|---|
| Código Estruturado | Texto; sugestão `1.01.01` | Vazio | Obrigatório. A sugestão não é valor preenchido automaticamente; o formulário não cria sequência nem aplica máscara hierárquica. |
| Nome da Conta | Texto | Vazio | Obrigatório. Sem conversão automática de maiúsculas. |
| Tipo | Lista: Receita, Despesa | Receita | Define natureza financeira. Não restringe explicitamente a lista de pais pelo mesmo tipo. |
| Conta Pai (Sintética) | Nenhuma (Raiz) + contas sintéticas existentes | Nenhuma | Lista apenas contas não analíticas e exclui a própria conta atual; cada opção mostra código e nome. |
| Conta Analítica (Aceita Lançamentos) | Checkbox | Marcado | Marcado = analítica; desmarcado = sintética/agrupadora e elegível como pai de outras contas. |

**Campos internos:** ID; indicador `isSystem` existe no modelo e pode estar presente em registros iniciais, mas não tem controle visível nem um bloqueio de edição específico por esse indicador nesse formulário.

### 6.4 CRUD e acionamentos

- **Criar:** Nova Conta → código, nome e classificação → Salvar.
- **Consultar:** grade e formulário; sem modal específico de detalhes.
- **Alterar:** Editar → Salvar.
- **Excluir:** não disponível na interface; não há ação de remover, inativar ou duplicar.
- Sem código/nome: aviso “Código e Nome obrigatórios.”.
- Gravação do conjunto do plano pela seção de configuração; sucesso fecha o painel, falha mantém e apresenta erro.
- Cancelar/X abandona alterações locais.
- Não há validação explícita no formulário de ciclo indireto entre pais, coerência do prefixo do código, mudança de analítica já usada ou compatibilidade Receita/Despesa entre pai e filha. Este manual não garante controles que não foram observados.

### 6.5 Relacionamentos e integrações

- **Conta filha → conta pai:** `parentId`; apenas contas sintéticas são oferecidas como pai.
- **Títulos financeiros → categoria:** Pagar e Receber usam o ID da conta em `categoryId`. Os seletores examinados oferecem contas analíticas; não aplicam filtro local explícito de Receita só em Receber ou Despesa só em Pagar.
- **Movimentação bancária:** categorias de crédito/débito são filtradas por tipo de receita/despesa e por condição analítica. Depósitos usam receitas analíticas; saques usam despesas analíticas.
- **Conciliação bancária:** formulário de lançamento usa contas analíticas compatíveis com o tipo de movimento.
- **Relatórios e gerenciamento:** a classificação financeira pode acompanhar títulos e movimentos; alterar o nome/classificação não deve ser interpretado como recalcular, quitar ou reclassificar automaticamente todo histórico.
- **Integração contábil externa:** não há nesse formulário botão de exportar contabilidade, integração com escritório contábil, SPED ou lançamento automático em ERP externo.
- **Persistência distinta:** este editor usa a configuração `chartOfAccounts`, enquanto os módulos de títulos também podem buscar a tabela relacional de plano de contas. A rota de salvar seção consultada apenas atualiza a configuração; não contém sincronização imediata da tabela de lookup. Portanto, o sucesso de salvar no editor não comprova, sozinho, atualização instantânea de todos os seletores consumidores. Existe rotina separada de sincronização no projeto; sua execução não foi acionada nem validada aqui.

### 6.6 Exemplos iniciais locais

| Código | Nome | Tipo | Analítica | Pai |
|---|---|---|---|---|
| 1 | Receitas Operacionais | RECEITA | Não | Raiz |
| 1.01 | Honorários e Serviços | RECEITA | Não | 1 |
| 1.01.01 | Honorários de Consultoria | RECEITA | Sim | 1.01 |
| 1.01.02 | Comissões sobre Êxito | RECEITA | Sim | 1.01 |
| 2 | Despesas | DESPESA | Não | Raiz |
| 2.01 | Despesas Administrativas | DESPESA | Não | 2 |
| 2.01.01 | Aluguel e Condomínio | DESPESA | Sim | 2.01 |
| 2.01.02 | Energia Elétrica | DESPESA | Sim | 2.01 |

As raízes 1 e 2 têm indicador de sistema nos exemplos locais. Estes são exemplos de configuração do código, não inventário da empresa.

## 7. Modal comum — Histórico de Movimentações

### 7.1 Acionamento e consulta

- Ícone de relógio na coluna Ações dos quatro cadastros.
- Ao clicar, abre modal sobreposto **Histórico de Movimentações**, com nome do registro e etiqueta **Somente Leitura**.
- Solicita até 500 eventos da API de auditoria pelo ID do registro e ordena os eventos do mais recente para o mais antigo.
- Um contador no botão passa a indicar os eventos carregados; acima de 99, exibe 99+.
- Carregamento: “Carregando...”/“Carregando histórico...”.
- Sem eventos: “Nenhuma movimentação registrada para este item.”.

### 7.2 Data Grid do modal

| Coluna | Conteúdo |
|---|---|
| Data/Hora | Momento do evento formatado. |
| Usuário | Responsável informado no evento. |
| Ação | Inclusão, alteração, exclusão ou outra ação registrada, com etiqueta de cor. |
| Campo | Campo alterado com rótulo legível. |
| De | Valor anterior. |
| → | Separador visual entre valores. |
| Para | Novo valor; na ausência de alterações por campo, pode trazer a descrição do evento. |

- Um evento com vários campos alterados gera várias linhas.
- Se não houver mudanças detalhadas, o campo e valor anterior podem aparecer como “—”.
- **Paginação:** 15 linhas por página, botões Anterior e Próxima e indicador de página quando há mais de uma.
- **Rodapé:** quantidade de eventos e texto de histórico protegido, sem edição. Essa quantidade pode ser diferente da quantidade de linhas, pois um evento pode conter vários campos.
- **Fechar**, **X** ou clique fora do modal encerra a visualização.
- Não há criar/editar/excluir eventos, restaurar valores ou exportar histórico nesse modal.
- Não confundir “movimentações” de auditoria com movimentações de saldo bancário.

## 8. Modal relacionado — Editar Fornecedor/Parceiro em títulos financeiros

### 8.1 Onde e quando aparece

Em Contas a Pagar há botão de lápis junto ao fornecedor selecionado. Sem fornecedor selecionado, fica desabilitado.

**Condição real de abertura/renderização:** o modal de Pagar só é renderizado quando existem parceiro em edição e as propriedades adicionais de configuração/atualização. Na montagem examinada do Hub Financeiro, essas duas propriedades não são repassadas ao componente de Pagar. Assim, o botão e o componente existem, mas não se pode prometer abertura efetiva por esse caminho atual.

Contas a Receber usa o mesmo componente para editar cliente. Não é um formulário de novo fornecedor, não muda natureza para F e não substitui a tela de Fornecedores.

### 8.2 Todos os campos do modal

Os campos vêm preenchidos com os dados do parceiro existente; campos sem dados aparecem vazios.

| Campo | Tipo / característica |
|---|---|
| ID no cabeçalho | Somente leitura, identifica a pessoa editada. |
| Nome / Razão Social * | Texto; Salvar Alterações exige nome não vazio. |
| Tipo | Pessoa Física ou Pessoa Jurídica. |
| CPF / CNPJ | Texto, rótulo e sugestão de formato conforme tipo. |
| Telefone / WhatsApp | Texto; não dispara envio. |
| E-mail | Campo de e-mail. |
| Endereço | Texto. |
| Número | Texto. |
| Complemento | Texto. |
| Bairro | Texto. |
| Cidade | Texto. |
| Estado | Até dois caracteres, convertido para maiúsculas. |
| CEP | Texto. |
| Observações | Área de texto de três linhas. |

### 8.3 Ações e efeito

- **Salvar Alterações:** tenta PUT na base de pessoas; mostra Salvando... e desabilita o botão durante a chamada.
- Solicita atualização do nome do parceiro no título em edição e registra evento de auditoria pelo componente.
- **Cancelar**, **X** ou clique no fundo fecha o modal.
- **Limitação observada:** o tratamento de erro do componente também fecha o modal e aciona atualização local/auditoria, sem mensagem explícita de falha. Logo, o fechamento do modal não comprova persistência bem-sucedida; não o trate como confirmação de gravação.

## 9. Matriz de integrações e relacionamentos

| Origem | Destino | Identidade / condição | Efeito e limite |
|---|---|---|---|
| Fornecedor | Base de pessoas/clientes | ID e natureza F | Compartilha pessoa; não duplica obrigatoriamente em tabela isolada. |
| Pessoa/fornecedor | Título a pagar/receber | `clientId` | Identifica o parceiro do título; não cria título apenas ao cadastrar. |
| Pessoa com telefone | Histórico GoTalk | Telefones da pessoa | Tentativa assíncrona de vínculo retroativo; não envia mensagens. |
| Tipo Documento | Título financeiro | `documentTypeId` | Classifica documento; seleção obrigatória nos formulários examinados de títulos. |
| Tipo Documento | Regras fiscais/documentais | Flags fiscal e exige número | Armazenadas; sem emissão fiscal e sem aplicação condicional comprovada da flag de número. |
| Portador | Título financeiro | `bearerId` | Classifica portador; não registra cobrança externa. |
| Portador Banco | Conta bancária | `associatedBankAccountId` | Vínculo opcional; não cria conta nem altera saldo. |
| Plano de Contas | Conta pai | `parentId` | Estrutura hierárquica, pai sintético. |
| Plano de Contas | Títulos e movimentos | `categoryId` | Classificação de lançamento; consumidores podem usar fontes de dados diferentes. |
| Plano analítico | Movimentos/conciliação | Analítica e Receita/Despesa | Oferece categorias de acordo com o tipo do movimento. |
| Todos os cadastros | Auditoria | ID do registro | Consulta eventos somente leitura. |
| Tipo Documento/Portador | Configuração do portal | Atualização complementar após API | Rota de seção exige administrador; gravação principal usa API relacional. |
| Plano de Contas | Configuração do portal | Atualização de seção | Grava configuração; sincronização relacional imediata não demonstrada nessa rota. |

## 10. Matriz final de CRUD e recursos de grade

| Recurso | Fornecedores | Tipo Documento | Portador | Plano de Contas |
|---|---|---|---|---|
| Criar | Sim | Sim | Sim | Sim |
| Consultar | Sim | Sim | Sim | Sim |
| Alterar | Sim | Sim | Sim | Sim |
| Excluir pela interface | Sim, com confirmação e dependências | Não | Não | Não |
| Duplicar | Não | Não | Não | Não |
| Inativar pela interface | Não | Não | Não | Não |
| Pesquisa visível | Nome/documento | Não | Não | Não |
| Ordenação interativa | Não | Não | Não | Não |
| Ordenação base | Nome pela API | Descrição pela API | Nome pela API | Código textual local |
| Paginação visível da grade principal | Não | Não | Não | Não |
| Auditoria em modal | Sim | Sim | Sim | Sim |
| Formulário de cadastro em modal sobreposto | Não, painel na página | Não, painel na página | Não, painel na página | Não, painel na página |
| Importar/exportar pela tela | Não | Não | Não | Não |
| Operação externa bancária/fiscal pela tela | Não | Não | Não | Não |

## 11. Roteiros de acionamento

### Fornecedor

Financeiro → Cadastros → Fornecedores → Novo Fornecedor → Tipo de Pessoa → Nome / Razão Social → preencher demais campos → Salvar. Para corrigir: Editar. Para remover: Excluir → confirmação do navegador; a remoção depende da inexistência de vínculos impeditivos.

### Tipo Documento

Financeiro → Cadastros → Tipo Documento → Novo Tipo → Descrição → Categoria → marcar/desmarcar Fiscal e Exige Número → Salvar. Marcar Fiscal não abre emissão de nota; mudar Categoria não abre outro módulo.

### Portador

Financeiro → Cadastros → Portador → Novo Portador → Código e Nome → Tipo. Se Banco, o seletor de conta aparece; escolher conta não abre autenticação bancária. Salvar confirma o cadastro, não o envio de uma cobrança.

### Plano de Contas

Financeiro → Cadastros → Plano de Contas → Nova Conta → Código e Nome → Tipo → Conta Pai ou Raiz → marcar/desmarcar Analítica → Salvar. Para criar agrupadora, desmarque Analítica; para categoria lançável, mantenha marcada. O código e a seleção de pai são informados separadamente.

### Histórico

Na grade de qualquer um dos quatro cadastros → ícone de relógio → conferir Data/Hora, Usuário, Ação, Campo, De e Para → navegar páginas se houver → Fechar. Não altera dados.

## 12. Referências e limites da verificação

O levantamento foi conferido nos seguintes pontos do código:

- `constants.ts`: menu, exemplos iniciais de tipos, portadores e plano.
- `components/financeiro/CadastrosFinanceirosPanel.tsx`: quatro cadastros, campos, validações, grids e acionamentos.
- `components/financeiro/FinancialPanel.tsx`: montagem dos cadastros e chamadas de configuração; relacionamentos com outros módulos.
- `components/ui/AuditLogButton.tsx`: modal e grade de histórico.
- `components/financeiro/EditPartnerModal.tsx`: edição de parceiro vinculada aos títulos.
- Componentes `AccountsPayableManager`, `AccountsReceivableManager`, `BankMovementManager` e `BankReconciliationManager`: seletores e consumo dos relacionamentos.
- `server/routes/clients.js`, `lookups.js` e `crudFactory.js`: persistência, campos exigidos e dependências.
- `server/index.js`: rota de configuração por seção e inicialização de portadores.
- `server/sync-config-to-db.js`: rotina separada de sincronização e portadores iniciais.
- `types.ts`, `hooks/useEntityCRUD.ts` e `contexts/KeyboardShortcutContext.tsx`: modelos, carga paginada e atalho de salvar.

**Não foi feito:** autenticação no aplicativo, consulta a registros reais, teste de permissão por perfil, criação/edição/exclusão de dados, teste de envio GoTalk, operação bancária/fiscal, execução de sincronização ou verificação em produção. As limitações apontadas são achados de leitura do código e não comprovação de falha em uma sessão real.

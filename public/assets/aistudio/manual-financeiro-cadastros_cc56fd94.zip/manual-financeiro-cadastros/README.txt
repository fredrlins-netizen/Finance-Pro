MANUAL — FINANCEIRO > CADASTROS

Abra manual-financeiro-cadastros.html no navegador para ler ou imprimir.
A versão Markdown também está incluída.

Escopo: Fornecedores, Tipo Documento, Portador e Plano de Contas.
Inclui relacionamentos com títulos, contas bancárias, movimentações,
conciliação, histórico de auditoria e modal de edição do parceiro.

O levantamento descreve o código disponível nesta sessão. Não houve consulta
aos cadastros reais, alteração de dados, teste autenticado ou teste em produção.
Valores de inicialização e exemplos locais não representam dados reais.

Os formulários de cadastro são painéis da própria página, não modais
sobrepostos. Os modais reais e suas condições de abertura estão separados.
Funcionalidades ausentes ou condicionais estão identificadas no manual.

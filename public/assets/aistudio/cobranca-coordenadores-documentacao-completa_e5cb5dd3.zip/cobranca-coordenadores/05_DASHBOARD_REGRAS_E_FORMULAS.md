# 5. Dashboard: todas as opções e cálculos

## 5.1 Entrada e filtros
Clique **Dashboard**. Filtros próprios, todos inicialmente vazios:
- **Período De**: dueDate >= data.
- **Período Até**: dueDate <= data.
- **Colaborador**: Todos ou qualquer colaborador recebido, comparado com assignedCollaboratorId.

Aplicação imediata no estado local, sem botão Aplicar. Não há botão Limpar próprio do Dashboard: apagar as datas e escolher Todos. Não usa os filtros de status, UF, busca local de faixa e situação da Carteira, embora compartilhe a mesma página de títulos que o pai entregou. Uma busca no servidor feita na Carteira pode, assim, reduzir os dados disponíveis ao Dashboard.

Período significa **vencimento**, inclusive para os títulos pagos usados na recuperação, não data de recebimento nem data de baixa.

## 5.2 Quatro cartões de indicadores
### Taxa Inadimplência
`100 × quantidade de títulos vencidos / quantidade de títulos elegíveis filtrados`, ou zero com denominador zero. Vencido significa agingDays>0. Exibe uma casa decimal e texto **N de M títulos vencidos**. É taxa por quantidade, não por saldo.

### Taxa Recuperação
Seleciona separadamente, do array titles recebido, os títulos `type=PADRAO` e `status=PAGO`. Filtra-os pelo período de vencimento, **sem aplicar filtro de colaborador**.

`recuperado = soma de originalValue desses pagos`.

`carteiraTotal = saldoTotalElegívelFiltrado + recuperado`.

`taxa = 100 × recuperado / carteiraTotal`, ou zero com denominador zero.

Exibe uma casa decimal e **Recuperado: R$ ...**. Não soma recebimentos/settlements, não usa valor efetivamente baixado nem filtra pelo operador que recebeu.

### DSO (Dias)
Rótulo secundário **Prazo médio de recebimento**. Fórmula literal:

`saldoMédio = saldoTotal / quantidadeDeTítulos` ou 0.

`receitaDiária = recuperado > 0 ? recuperado / 30 : 1`.

`DSO = round(saldoMédio / receitaDiária × 30)` quando receitaDiária>0; senão 0.

Esse cálculo usa saldo médio por título e fator fixo de 30 dias, independentemente da duração do filtro. **Não deve ser descrito como a fórmula contábil convencional de DSO**. Sem recuperado, o fallback 1 pode produzir DSO positivo e elevado.

### Saldo Total
Soma Number(currentBalance)||0 dos títulos elegíveis após os três filtros do Dashboard. Texto complementar **Vencido: R$ ...** soma só os vencidos desse mesmo conjunto. Valores em BRL.

Os quatro cartões são informativos, sem clique de detalhamento ou exportação.

## 5.3 Carteira por Faixa de Atraso
Cinco faixas fixas:
1. A Vencer: dias <=0, inclusive hoje; verde.
2. 1-30 dias: >0 e <=30; amarelo.
3. 31-60 dias: >30 e <=60; laranja.
4. 61-90 dias: >60 e <=90; vermelho.
5. 90+ dias: >90; vermelho mais forte.

Cada linha exibe nome, barra, soma do saldo BRL e quantidade. Largura = max(saldoDaFaixa / maiorSaldoEntreFaixas ×100, 2)%; maiorSaldo tem piso 1. Assim, mesmo faixa zerada pode ter barra mínima de 2%. Não representa percentual sobre saldo total. Não há tooltip funcional, seleção de faixa ou drill-down por clique.

## 5.4 Performance por Colaborador
Agrupa o mesmo conjunto filtrado por assignedCollaboratorId; ausente vira grupo interno __sem_atribuicao__. Rótulo do cadastro ou **Sem Atribuição** se não resolvido.

Cada linha mostra nome, barra, saldo BRL e **N tít.**. Largura = max(saldoDoGrupo / maiorSaldoEntreGrupos ×100, 2)%, denominador com piso 1. Sem títulos: **Nenhum título na carteira.**.

Não mede produtividade por contatos, mensagens, acordos fechados ou receita efetivamente recuperada: mede quantidade atribuída e saldo pendente. Não há ordenação de ranking explícita; usa a ordem de criação dos grupos ao percorrer os títulos.

## 5.5 Solicitações de Cancelamento Pendentes
Card condicional: só aparece se houver notas do estado local com negotiationStatus=SOLICITA_CANCELAMENTO e cancelRequest preenchido. Conteúdo inicial vem de JSON em localStorage, chave collection_notes_v1; parse inválido vira lista vazia. Listener storage recarrega a lista quando o navegador emite o evento.

Card laranja com título, subtítulo **Solicitadas pela equipe operacional — requerem ação da coordenação** e quantidade. Começa recolhido. Clique expande/recolhe a lista; seta muda de orientação.

Cada solicitação mostra:
- Cliente: nome do título ligado se encontrado, senão clientId.
- Documento: apenas quando o título foi encontrado.
- Operador: nome do colaborador ligado, senão collaboratorName da nota.
- Data Solic.: cancelRequest.requestDate formatada ou travessão.
- Contrato: cancelRequest.admissionContract ou travessão.
- Saldo: somente se o título foi encontrado.
- Observações: cancelRequest.notes, somente preenchidas.
- Selo fixo **Pendente**.
- **Excluir**, apenas para quem pode excluir, com confirmação específica.

Não há filtro por período/colaborador aplicado a essa lista. Não há aprovação, rejeição, baixa, cancelamento de contrato nem execução automática associada a selecionar o card ou excluir a nota.

## 5.6 Alcance dos indicadores e atualizações
Os cálculos são useMemo no frontend, alimentados pela página recebida (50 registros antes das exclusões), **não por endpoint agregado de carteira completa**. O endpoint geral `/api/financial-dashboard` existe no projeto, mas não é chamado por este componente.

Trocar a página na barra externa pode mudar os números do Dashboard. Os títulos pagos usados na recuperação também são só os recebidos na página. Se a página não contiver pagos, recuperado pode ficar zero mesmo havendo recebimentos em outras páginas.

Não há filtro próprio de banco, modalidade, série, unidade, UF, status de cobrança ou faixas nesse modo; não há gráfico de evolução temporal, metas, comparativo anterior, exportação, impressão nem clique nos indicadores implementados aqui.

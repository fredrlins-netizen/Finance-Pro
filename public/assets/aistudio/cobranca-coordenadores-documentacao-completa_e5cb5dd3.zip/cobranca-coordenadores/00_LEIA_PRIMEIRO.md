# Cobrança → Coordenadores
## Inventário funcional, técnico e de relacionamentos

Este pacote documenta a implementação encontrada no código do projeto, não uma especificação idealizada nem uma proposta de alteração. A referência é a cópia de trabalho existente no momento da geração, identificada no manifesto.

## Como consultar
- Abra **DOCUMENTACAO_COMPLETA.html** em um navegador: contém os documentos reunidos, índice e pesquisa textual pelo próprio navegador.
- Os documentos numerados em Markdown permitem edição e consulta separada.
- **inventario_campos.csv** abre em Excel/LibreOffice; separador ponto e vírgula, UTF-8 com BOM.
- **inventario_campos.json** contém o mesmo catálogo de campos, opções e comportamentos.
- **evidencias_controles.json** relaciona controles, seleções, estados e chamadas encontrados nos componentes, com arquivo e linha.
- **fontes_e_integridade.json** informa os arquivos consultados, seus hashes e os hashes dos documentos.

## Escopo e limitações da verificação
Foram examinados o painel Coordenadores, seu componente de integração, os modais compartilhados diretamente alcançáveis, o histórico de auditoria, os componentes GoTalk, os endpoints de títulos, notas e admissões e os pontos de integração relevantes.

Não foram executadas inclusões, alterações, exclusões, envios de WhatsApp, consultas a bancos externos nem operações em produção. Nenhuma configuração ou código funcional do aplicativo foi alterado.

A captura pública do aplicativo apresentou a tela de autenticação. A interface autenticada e o comportamento dos provedores externos **não foram verificados em sessão autenticada**. As afirmações funcionais são fundamentadas na leitura do código. A imagem tela-publica.jpg comprova apenas esse limite, não a aparência do módulo.

“Padrão” significa valor inicial/fallback implementado. Nomes de colaboradores, unidades, bancos, templates, contratos e registros são dinâmicos: informamos sua origem e critérios, sem exportar dados pessoais ou presumir valores do banco.

## Distinção essencial
Um botão existir não comprova que sua operação esteja completamente conectada. O documento 06 apresenta separadamente os pontos de atenção encontrados. Em especial, a atribuição em lote não grava no backend no encadeamento atual, e os indicadores não representam automaticamente a carteira inteira.

# 1. Acesso, carteira, filtros e data grid

## 1.1 Navegação e composição
No menu Cobrança, selecionar **Coordenadores** aciona a visualização `fin_cob_coordenador`. O módulo de cobrança é carregado pelo layout e o componente CollectionPanel monta CollectionCoordinatorPanel.

Cabeçalho: **Cobrança — Coordenadores**. Subtítulo: **Gestão e atribuição de títulos para equipe de cobrança**.

Há dois modos: **Carteira de Títulos**, inicialmente ativo (`GRID`), e **Dashboard** (`DASHBOARD`). A troca altera o estado local, sem navegar para outra rota nem criar registros. Os filtros próprios de cada modo são mantidos enquanto o componente continuar montado.

Dados auxiliares recebidos da configuração: clientes, colaboradores, admissões, auditoria, bancos, séries, modalidades e unidades. Ausência das listas opcionais resulta em listas vazias.

## 1.2 Origem e elegibilidade dos títulos
O componente pai consulta `/api/financial-titles` pelo hook de CRUD com `filter_title_scope=RECEBER` e tamanho de página 50. Remove CANCELADO antes de entregar os títulos ao painel.

O painel aceita somente `type=PADRAO` e exclui os status CANCELADO, AGRUPADO, PAGO, ADIANTAMENTO, ADIANTAMENTO_PARCIAL, DEVOLUCAO, DEVOLUCAO_VINCULADA e DEVOLUCAO_PARCIAL. Não exige situação COBRAR nem colaborador atribuído: títulos Em Dia, Não Cobrar e sem responsável podem aparecer.

ABERTO, PARCIAL, PROTESTADO e PROVISAO são as quatro opções normais de filtro/edição. A regra de elegibilidade é por exclusão; um status adicional admitido no backend e não excluído também pode aparecer, mesmo sem uma opção própria no filtro.

## 1.3 Barra de operações
1. **Buscar cliente...**: texto inicialmente vazio. Após 300 ms sem nova digitação, chama `onSearch`, que é conectado à busca do hook no servidor. Não há filtragem textual adicional de clientes dentro de filteredTitles.
2. **Filtros**: abre/fecha o bloco avançado, inicialmente fechado; não limpa valores ao recolher.
3. **N título(s) | Saldo: R$ ...**: quantidade e soma de currentBalance da lista filtrada da página; não é o total global do servidor.
4. **Atribuir (N)**: aparece quando há IDs selecionados; abre o modal de atribuição.

## 1.4 Todos os filtros avançados
| Campo | Conteúdo inicial | Opções e origem | Efeito |
|---|---|---|---|
| Status | Todos / vazio | ABERTO=Em Aberto; PARCIAL=Parcial; PROTESTADO=Protestado; PROVISAO=Provisão | Igualdade exata com status |
| Situação Cobrança | Todos / vazio | EM_DIA=Em Dia; COBRAR=Cobrar; NAO_COBRAR=Não Cobrar | Ausência de collectionStatus equivale a EM_DIA |
| Colaborador | Todos / vazio | Todos os colaboradores recebidos, rótulo name e valor id | Igualdade com assignedCollaboratorId; não há opção específica “sem atribuição” neste filtro |
| Faixa de Atraso | Todos / vazio | A Vencer; 1-30 dias; 31-60 dias; 61-90 dias; 90+ dias | Usa agingDays e agingBucket |
| Vencimento De | Vazio | Data | dueDate maior ou igual ao início |
| Vencimento Até | Vazio | Data | dueDate menor ou igual ao fim |
| Estado (UF) | Todos os estados / vazio | UFs dos clientes dos títulos elegíveis carregados, sem vazios, normalizadas em maiúsculas e trim, distintas e ordenadas | Busca cliente por clientId e compara state em maiúsculas |
| Limpar Filtros | Botão | Sem opções | Zera os oito filtros incluindo busca textual; não limpa seleção ou ordenação |

Os filtros avançados são combinados por E e aplicados localmente sobre a página. As datas são comparadas como strings no formato esperado de data. Não há validação explícita de início maior que fim. A comparação da UF não aplica trim ao valor do cliente, embora aplique trim na montagem das opções.

## 1.5 Todas as 13 colunas
| Coluna | Campo/origem | Conteúdo e acionamento |
|---|---|---|
| Seleção | id / selectedIds | Checkbox individual; cabeçalho seleciona todos os IDs da lista filtrada ou limpa seleção |
| Cliente | clientName; clients.id=clientId | Nome clicável abre Dados do Cliente; indicador compacto de bloqueio se blocked |
| Fichas | collectionSummary[clientId].fichas | Contador de admissões AUDITADA/FINALIZADA; roxo quando positivo, cinza para zero e travessão sem resumo; não é botão |
| Aditivos | collectionSummary[clientId].aditivos | Quantidade de aditivos das fichas elegíveis; vermelho positivo, cinza zero, travessão sem resumo; não é botão |
| Documento | documentNumber | Texto; cabeçalho ordenável |
| Vencimento | dueDate | Data pt-BR; cabeçalho ordenável |
| Valor | originalValue | Moeda BRL em azul; cabeçalho ordenável numericamente |
| Saldo | currentBalance | Moeda BRL em destaque; cabeçalho ordenável numericamente |
| Atraso | Cálculo por dueDate | “Nd” vermelho quando positivo; “Em dia” verde caso contrário |
| Status | status | Badge; ABERTO azul, PARCIAL amarelo, PROTESTADO vermelho, demais cinza |
| Sit. Cobrança | collectionStatus | COBRAR âmbar, NAO_COBRAR cinza, padrão verde para EM_DIA |
| Responsável | collaborators.id=assignedCollaboratorId | Nome; travessão sem resolução |
| Ações | Identificador do título/cliente | Histórico; Editar Lançamento; Dados do Cliente; Conversas GoTalk do atendente; Excluir Título quando permitido |

Cliente também possui cabeçalho ordenável (`clientName`). Ordenação inicial: dueDate crescente; clicar no mesmo cabeçalho inverte asc/desc; outra coluna inicia crescente. Ícones ↕, ↑ e ↓. Comparação textual pelo operador JavaScript, sem ordenação linguística explícita. Atraso, status, responsável e contadores não possuem clique de ordenação.

Linhas vencidas recebem fundo vermelho discreto. Texto vazio: **Nenhum título encontrado.** Há rolagem horizontal e vertical. Não há edição direta de célula, inclusão de coluna, agrupamento manual, exportação, impressão ou menu de contexto implementados no grid principal.

## 1.6 Seleção e paginação
A seleção mantém um array de IDs local; cada checkbox alterna a presença do ID. “Selecionar todos” compara a quantidade selecionada com a quantidade visível; não verifica a igualdade dos conjuntos. Trocar filtros ou página não contém limpeza automática da seleção.

PaginationBar é renderizada pelo pai, abaixo do painel, inclusive quando está no Dashboard. Usa total e totalPages do servidor, página atual, páginas numeradas e reticências quando necessário, Anterior e Próxima. Botões ficam indisponíveis durante carregamento ou nos limites. Oculta-se se houver no máximo uma página e total até 50. Os totais da barra são da consulta do servidor antes dos filtros locais, portanto podem diferir dos contadores da carteira.

## 1.7 Datas e rótulos
agingDays zera horas de hoje e do vencimento e calcula floor da diferença em milissegundos / 86.400.000. Dias <=0 ficam em A Vencer; 1 a 30, 31 a 60, 61 a 90 e acima de 90 nas demais faixas. O texto “90+” significa, neste código, estritamente mais de 90. Vencimento de hoje é “Em dia”.

Rótulos conhecidos: ABERTO=Em Aberto; PAGO=Liquidado; PARCIAL=Parcial; CANCELADO=Cancelado; AGRUPADO=Fatura Gerada; PROTESTADO=Protestado; PROVISAO=Provisão. Códigos não mapeados aparecem como recebidos. O cálculo de atraso usa new Date(dueDate), enquanto a exibição acrescenta T00:00:00: há diferença de interpretação possível por fuso.

## 1.8 Busca no servidor e ordem entre páginas
Apesar do placeholder “Buscar cliente...”, o endpoint financeiro tem searchColumns em **client_name, description e document_number**: a busca também pode encontrar descrição e documento. A ordenação padrão da API é due_date DESC; a ordenação crescente do painel é feita depois, apenas na página recebida. Assim, a ordem entre páginas não é garantidamente a mesma ordem visual local.

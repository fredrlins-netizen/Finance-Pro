# 3. Cliente, ficha, documentos e auditoria

## 3.1 Abrir Dados do Cliente
Clique no nome do cliente ou no ícone Dados do Cliente → define selectedClientId e abre o painel na aba **Dados**. O ícone **Conversas GoTalk do atendente** abre o mesmo painel na aba **Atendimentos**, passando também assignedCollaboratorId.

O painel só é renderizado se o cliente for encontrado na lista recebida. Não faz busca do cadastro completo do cliente por API nesse handler. Fecha pelo X ou clique no fundo. Cabeçalho mostra nome (fallback Cliente) e **Dados do Cliente — Somente Leitura**.

Abas: **Dados**, sempre; **WhatsApp**, somente com GotalkChatPanel habilitado e recebido; **Atendimentos**, somente com GotalkAttendanceViewer habilitado e recebido. As abas de comunicação permitem envio, apesar do texto geral “Somente Leitura”, que descreve os dados cadastrais.

## 3.2 Dados cadastrais — todos os campos
- Nome/Razão → client.name, fallback travessão.
- CPF/CNPJ → document, fallback travessão.
- Telefone → phone, fallback travessão.
- E-mail → email, fallback travessão.
- Endereço → address ou travessão, seguido de city e state; os dois últimos vazios quando ausentes.
- Bloqueio → se blocked, exibe BlockedClientBanner completo; não há desbloqueio aqui.

Nenhum desses campos é editável. Telefones e e-mail são textos nesse bloco, sem handler de ligação ou envio próprio.

## 3.3 Títulos do Cliente
Cabeçalho informa a contagem dos títulos elegíveis carregados do cliente. Ao abrir cliente, consulta `GET /api/admissions/client-detail/:clientId`; durante a consulta exibe **carregando fichas...** / **carregando aditivos...**. Erro limpa a lista e não mostra mensagem específica.

A API retorna no máximo **50 fichas AUDITADA/FINALIZADA**, mais recentes por created_at; busca no máximo **200 títulos** ligados ao conjunto de fichas, por due_date. Retorna addendums, hasAddendum, latestAddendumDate e parcelas.

O painel agrupa pelas fichas retornadas, sem mostrar grupos sem parcelas. Grupo mostra **Ficha: contrato** (fallback **Sem contrato**) e, se houver, selo **Possui Aditivo Contratual**, com data do mais recente. Cada parcela mostra documento, descrição, saldo BRL e situação de cobrança (EM_DIA quando ausente).

A lista de parcelas retornada pela API **não aplica a mesma exclusão de status e tipo do grid**. Por isso pode conter pagos/cancelados ou outros títulos relacionados que não aparecem na carteira. O contador do cabeçalho continua sendo a contagem da carteira carregada.

Depois dos grupos, exibe títulos elegíveis do cliente que não possuem admissionId ou cujo admissionId não está entre as fichas retornadas, com documento, descrição, saldo e situação. Não há CRUD nessa lista.

## 3.4 Admissões / Contratos
É a lista `admissions` recebida, filtrada por clientId, não o mesmo conjunto de até 50 fichas buscado pela API. Cada cartão contém:
- Contrato: contractNumber ou travessão.
- Selo de aditivo, quando a informação da API existe; inclui data do último.
- Botão **Ver Ficha** para aquela admissão.
- Status bruto da admissão; verde APROVADA/FINALIZADA/CONCLUIDO, vermelho REPROVADA, amarelo os demais.
- Data da admissão, ou travessão.
- Parcelas: paidInstallments/totalInstallments, com zeros quando ausentes.
- Valor Financiado: financedAmount ou travessão, exibido como recebido.
- Dia Vencimento: dueDay ou travessão.
- Anexos pré-carregados: quantidade e links de download, título ou nome do arquivo; href=fileData, download=fileName.
- Cenários de Recálculo: label, originalDebt → newDebt e savings; somente consulta.

O botão **Ficha do Cliente**, no cabeçalho, só aparece quando há admissões recebidas do cliente. Escolhe a de maior date, deixando datas ausentes ao final. Isso não garante a ficha mais recente do banco se a configuração estiver incompleta.

## 3.5 Abrir Ficha de Admissão e resolver relacionamentos
**Ver Ficha** e **Ficha do Cliente** exigem administrador ou `com_admissao:VISUALIZAR`; sem isso o painel avisa “Sem permissão para visualizar a Ficha de Admissão.”.

Os nomes são resolvidos por IDs: admission.clientId→cliente; titularClientId→outro cliente; bankId→banco; modalityId→modalidade; collaboratorId→colaborador; seriesId→série; unitId→unidade.

Fallback de cliente: nome do cadastro, depois admission.clientName, depois clientId. Unidade: nomeFantasia, razaoSocial, companyName, name, nessa ordem. Série usa sigla. Modalidade usa description ou type. Ausência de relação não é substituída por associação pelo nome.

O modal **Ficha de Admissão** tem cabeçalho com cliente, contrato e status, quatro abas e rodapé **Somente visualização**, botão **Fechar** e X. Começa em **Identificação**. Não permite editar, aprovar ou cancelar uma admissão.

## 3.6 Aba Identificação — todos os campos
### Identificação do Processo
Cliente (Responsável); Contrato; Data Admissão; Status; Tipo Cliente (tipoCliente); Série; Colaborador; Indicação (indicationType); Origem (originType); Unidade, somente quando o nome foi resolvido.

### Dados do Responsável, quando há cliente resolvido
CPF/CNPJ; RG; Data de Nascimento; Estado Civil; Profissão; Tipo; Telefone; Telefone 2; E-mail; Endereço; Nº; Complemento; Bairro; Cidade; UF; CEP; Anotações.

Endereço aparece se address ou city; componentes vazios são omitidos. Anotações aparecem só se preenchidas. E-mail ausente fica destacado em vermelho. Demais textos sem conteúdo usam travessão pelo formatador fmt.

### Dados do Titular, quando titularClientId resolve um cliente
Nome; CPF/CNPJ; RG; Telefone; E-mail. O titular não é presumido como igual ao responsável; é outro relacionamento explícito.

### Dados do Veículo, somente se vehicleBrand estiver preenchida
Marca; Modelo; Ano; Placa; Cor; Chassi; Renavam. Cada item sem valor é omitido. isElectricVehicle adiciona selo **ELÉTRICO**.

### Informações Adicionais, condicionais
**Taxa Administração (R$)** = otherInfo1; **Primeira Parcela (R$)** = otherInfo2. Cada bloco aparece se o respectivo valor existe. São campos legados distintos de parcela1/parcela2 exibidos na aba financeira.

## 3.7 Aba Contrato / Financeiro — todos os campos
### Banco e Modalidade
Banco (bank.name, ou travessão); Modalidade (description, depois type, depois travessão); Tarifa Bancária=**Inclusa** se hasBankFeeIncluded; Contrato=**De Terceiro** se isThirdPartyContract.

Se o banco possui serviços, mostra tabela **Serviços / Percentuais de Negociação**, com **Serviço**, **% Negociação** e **Sobre Valor Financiado**. Cálculo por serviço: financedAmount convertido do formato brasileiro × negotiationPercentage / 100. Resultado positivo formatado BRL; senão travessão. Não é chamada de negociação ao banco: é cálculo de consulta com cadastro local.

### Dados Financeiros do Contrato
Valor Financiado; Valor Parcela Atual (installmentValue); Total Parcelas; Pagas / Em Atraso (paidInstallments e overdueInstallments, zero quando ausentes); Dia Vencimento; Tipo Pagamento.

Condicionais: Venc. 1ª Parcela (firstInstallmentDueDate); Taxa Administrativa (parcela1); 1ª Parcela Real (parcela2); Taxa de Cobrança (taxaCobranca); Desconto (desconto). São exibidos apenas quando o valor é truthy. Isso pode ocultar zero numérico.

### Cenários de Recálculo
Se existirem cenários: **Cenário** (label); **Dívida Orig.**; **Nova Dívida**; **Economia**; **Parcelas** (installmentsToPay ou travessão); **Vl. Parcela** (installmentValue ou travessão); **Dia Venc.** (dueDay ou travessão). Não há botão de recalcular ou selecionar proposta nesse visualizador.

## 3.8 Aba Documentos
Rótulo **Documentos (N)** soma anexos legados resolvidos e bucketCount informado pelo painel de anexos.

Ao abrir, busca `/api/admissions/:id/attachments`, com uma repetição configurada no cliente de API. Mapeia id, title, file_name e file_data. Prefere o retorno buscado aos anexos passados pelo pai. Exibe carregamento, lista vazia ou erro com **Tentar novamente**.

Cada documento legado mostra título/nome; ícone conforme imagem/PDF/outro; **Visualizar** abre nova janela com iframe; **Baixar documento** cria link de download. Imagem data:image também tem miniatura clicável. PDF é detectado pelo data MIME ou extensão .pdf.

Também monta ClientAttachmentsPanel com `module=ADMISSION`, `targetType=ADMISSION`, `targetId=admission.id`, `clientId`, **readOnly** e **compact**. Nessa configuração permite **Filtrar...**, **Atualizar**, **Ver** para imagem/PDF, **Baixar**, navegação Anterior/Próxima e informação de registros. O download autenticado usa `/api/client-attachments/:id/download?browser=1`; a visualização usa o fluxo de preview do componente. ACLs e escopo do servidor continuam aplicáveis.

Não expõe upload, seleção para exclusão, edição de acesso, proteção legada nem exclusão nesse modo. Os recursos administrativos existentes no componente compartilhado não devem ser atribuídos a este modal.

Existe JSX para “Sem permissão de acesso” nos anexos legados, mas o catch do fetch os classifica como LOAD_ERROR, sem atribuir PERMISSION_DENIED; portanto não há evidência de que esse estado específico seja atingido pelo fetch atual.

## 3.9 Aba Auditoria da admissão
Contém **Consulta jurídica registrada** e **Rounds de Auditoria (N)**.

A consulta jurídica usa admission.legalScan se já estiver presente; senão busca `/api/admissions/:id/legal-scan` ao abrir a aba. Estados: carregando; 403=sem permissão; erro; não realizada; resultado histórico.

Resultado histórico: data lastUpdate; encontrado/não encontrado; quando encontrado, número do processo, tribunal, última movimentação e parte autora, se presentes. Se allProcesses existir, lista para cada processo: numeroProcesso, tribunal, classe, assunto, parteAutora, dataAjuizamento e ultimaMovimentacao. **Não dispara nova pesquisa jurídica nem consulta DataJud**.

Cada round: número; data da crítica; crítica; autor da crítica, se presente; resposta, autor e data, quando houver. Sem rounds: “Nenhum round de auditoria registrado.”. Sem edição ou resposta por esse modal.

## 3.10 Detalhes do aviso de bloqueio e dos documentos protegidos
No indicador compacto da carteira, exibe blockStatus, vermelho e pulsante quando BLOQUEADO, âmbar nos demais casos de blocked. O banner completo nos Dados mostra **Cliente {blockStatus}**, nome, data/hora blockedAt e autor blockedBy quando presentes. **Ver motivo** expande blockReason; depois muda para **Ocultar motivo**. Não desbloqueia o cliente. Ao montar para cliente bloqueado, tenta tocar alerta sonoro pela Web Audio API, uma vez por montagem; restrições do navegador podem impedir o som.

O preview dos documentos protegidos abre `/api/client-attachments/:id/content?browser=1` em nova aba. Não carrega o documento inteiro como Blob no frontend. O modo readOnly não expõe gerenciamento de permissões ou exclusão.

# 4. Integrações, APIs, permissões e relacionamentos

## 4.1 GoTalk: quando aparece
CollectionPanel só repassa GotalkChatPanel e GotalkAttendanceViewer quando gotalkEnabled é verdadeiro. O painel Coordenadores não configura credenciais, canal, webhook ou provedor. Sem os componentes, as abas correspondentes não aparecem. O ícone de conversas da linha continua existindo no JSX; sem viewer, o conteúdo pode recair na aba de dados.

**WhatsApp** recebe clientId, area=COBRANCA_COORD e operatorName=currentUser.name. **Atendimentos** recebe clientId, collaboratorId da linha quando a abertura veio do ícone e título **Atendimentos GoTalk — Cobrança Coordenadores**. Abrir pelo nome do cliente não fixa colaborador.

## 4.2 Aba WhatsApp
Resolve o contato por `/api/gotalk/client/:clientId`. Se não houver contato, exibe “Nenhum contato WhatsApp vinculado. Use a seção acima para sincronizar.” e retorna antes de renderizar os botões do chat; não se deve presumir que a sincronização esteja acessível nesse estado.

Carrega até 100 mensagens em `/api/gotalk/messages/:clientId?limit=100`; marca leitura com POST `/api/gotalk/messages/mark-read`, corpo clientId. Possui atualização manual e atualização periódica conforme o componente. Mensagens exibem conteúdo, direção, horários, estados e mídias pelo renderizador compartilhado.

Cabeçalho mostra inicial do nome, nome e telefone do contato; ações: **Importar histórico**, **Atualizar mensagens**, **Enviar template HSM** quando suas condições são atendidas.

Compositor inicialmente vazio: **Digite uma mensagem... (Enter para enviar, Shift+Enter para nova linha)**. Remove espaços nas extremidades; não envia texto vazio nem durante envio. Verifica canais ativos por GET `/api/gotalk/channels`. Sem canal ativo exibe indisponibilidade, em vez do compositor.

Busca atendimento aberto por `/api/gotalk/attendances?clientId={id}&status=open&limit=1`. Havendo ID GoTalk e telefone, envia por POST `/api/gotalk/send-message-attendance`, corpo attendanceId, phone e body. Sem esse atendimento, usa POST `/api/gotalk/send-text`, corpo contactNumber e message, desde que o contato tenha telefone.

Sucesso limpa o texto, mostra toast e inclui mensagem otimista na conversa; erro mostra mensagem do servidor/conexão e toast. Não há upload próprio no compositor de texto deste fluxo.

### Modal Importar histórico
Abas **Por atendimento** e **Por telefone**; estado inicial attendance, campos vazios e resultado/erro vazios.
- Atendimento: ID do atendimento GoTalk obrigatório para o handler; POST `/api/gotalk/sync-attendance` com attendanceId e contactId (pode ser null nesse caminho por cliente).
- Telefone: aceita número com formatação, remove não dígitos; POST `/api/gotalk/sync-by-phone` com phone. Placeholder: “Ex.: 11999998888 ou 5511999998888”.
- Botão de confirmação usa o handler da aba; informa quantidade salva/total quando retornada; se saved>0, atualiza mensagens.
- Cancelar/X fecham e limpam resultado e erro; trocar aba também limpa resultado e erro.

### Vincular cliente — recurso compartilhado, não acionável normalmente aqui
O chat também implementa modal de busca de cliente por nome, CPF ou telefone, consulta `/api/clients?search=...&limit=20` e POST `/api/gotalk/link-client`. Porém o botão **Vincular a um cliente CRM** exige `!clientId && gotalkContactId`. Coordenadores sempre passa clientId; logo esse modal não é uma funcionalidade acionável deste menu no encadeamento atual.

## 4.3 Aba Atendimentos
Lista paginada de 20 atendimentos via `/api/gotalk/attendances`, com page, limit, clientId e opcional collaboratorId/type. Inicialmente página 1 e tipo Todos.

Filtros de tipo: **Todos**, **Cliente** (CLIENT), **Banco** (BANK). Trocar tipo volta à página 1 e limpa atendimento selecionado. O filtro de unidade do componente compartilhado só aparece sem clientId e sem collaboratorId; portanto **não aparece aqui**.

Cada cartão mostra os metadados do atendimento retornado, incluindo identificação do contato/telefone, tipo, operador, status e datas conforme disponíveis. Clicar abre a conversa; **Voltar** retorna à lista e limpa mensagens, compositor e erro.

Conversa busca `/api/gotalk/attendances/:id/messages?limit=100&offset=0`; **carregar mais** busca próximos lotes com offset, acrescentando itens. Há carregamento e contagem. Conteúdo de mídia é delegado ao renderizador compartilhado.

Campo de resposta inicialmente vazio: **Responder no atendimento... (Enter para enviar, Shift+Enter para nova linha)**. POST `/api/gotalk/send-message-attendance` com ID GoTalk, telefone e texto. Valida texto, envio em curso, atendimento selecionado, existência de gotalk_attendance_id e contact_phone. Sem esses dados mostra erro. Sucesso limpa e acrescenta mensagem otimista. Há opção **Template** quando há condições/telefone para abrir o modal HSM. Não há botão de encerrar, transferir ou apagar atendimento neste componente.

## 4.4 Modal Enviar template HSM — campos e opções
- **Canal WhatsApp**: lista de canais ativos de `/api/gotalk/channels`. Padrão é o canal ativo principal; senão o primeiro ativo. Sem nenhum, não há envio.
- **Template**: select inicialmente sem seleção. Busca `/api/gotalk/hsm-templates?channelUuid={id}`. Prefere status ausente/approved/ativo/active; se a filtragem não produzir itens, o componente usa a lista retornada integralmente. Isso não equivale a garantia de aprovação pelo provedor.
- **Variáveis do template**: um input por índice `{{n}}` detectado, inicialmente vazio, placeholder “Valor para {{n}}”.
- **Prévia**: cabeçalho/corpo/rodapé com substituição das variáveis; só leitura.
- Destinatário: telefone e nome do contato recebidos do chat/atendimento, sem redigitação no fluxo.
- **Enviar** depende de canal, template e todas as variáveis não vazias. Durante envio fica indisponível. Cancelar/X/fundo fecham.

No modo GoTalk, POST `/api/gotalk/send-active-notification`, corpo channelUuid, phone, contactName (fallback Contato), templateId do provedor e tag com as variáveis quando existem. Sucesso informa resultado e fecha após cerca de 2 segundos; erro mantém mensagem. O componente compartilhado tem modo uazapi que renderiza texto, mas Coordenadores não passa mode=uazapi nem callback para isso; **não é um modo selecionável neste painel**.

## 4.5 Mapa das APIs diretamente utilizadas
| Método/caminho | Acionamento | Dados/relação |
|---|---|---|
| GET /api/financial-titles | Montagem, busca, paginação e refresh | Escopo RECEBER; página 50; busca do hook |
| PUT /api/financial-titles/:id | Salvar edição | Título + editForm + titleScope RECEBER |
| DELETE /api/financial-titles/:id | Confirmar exclusão | ID do título |
| POST /api/admissions/collection-summary | Muda lista filtrada | clientIds únicos; retorna contagens por cliente |
| GET /api/admissions/client-detail/:clientId | Selecionar cliente | Fichas, aditivos e parcelas |
| GET /api/admissions/:id/attachments | Abrir Documentos | Arquivos legados da admissão |
| GET /api/admissions/:id/legal-scan | Abrir Auditoria sem scan pré-carregado | Consulta jurídica histórica |
| GET /api/audit-logs | Abrir histórico da linha | entity_id e limite 500 |
| DELETE /api/collection-notes/:id | Excluir solicitação | Remove nota; não cancela contrato |
| GET /api/gotalk/client/:clientId | Abrir chat | Contato vinculado |
| GET /api/gotalk/messages/:clientId | Abrir/atualizar chat | Últimas mensagens, limite 100 |
| POST /api/gotalk/messages/mark-read | Carregar mensagens | clientId |
| GET /api/gotalk/channels | Chat, atendimentos e HSM | Canais ativos e principal |
| GET /api/gotalk/attendances | Listar ou resolver aberto | Cliente, colaborador, tipo, página/status |
| GET /api/gotalk/attendances/:id/messages | Abrir atendimento/carregar mais | limit e offset |
| POST /api/gotalk/send-text | Enviar sem atendimento ativo resolvido | contactNumber e message |
| POST /api/gotalk/send-message-attendance | Responder chat/atendimento | attendanceId, phone e body |
| POST /api/gotalk/sync-attendance | Importar por ID | attendanceId e contactId |
| POST /api/gotalk/sync-by-phone | Importar por telefone | phone normalizado |
| GET /api/gotalk/hsm-templates | Escolher canal do HSM | channelUuid |
| POST /api/gotalk/send-active-notification | Enviar HSM | Canal, destinatário, template e tag |
| GET /api/client-attachments/... | Lista/preview/download de documentos | clientId, módulo ADMISSION, alvo admissão e ACL |

A listagem precisa dos controles e trechos de chamadas do frontend está em evidencias_controles.json. Parâmetros internos de provedores e credenciais não foram exportados.

## 4.6 Relacionamentos e persistência
| Origem | Destino | Finalidade |
|---|---|---|
| financial_titles.client_id | clients.id | Cliente proprietário, dados, UF e bloqueio |
| financial_titles.assigned_collaborator_id | collaborators.id | Responsável pela cobrança e recorte de atendimentos |
| financial_titles.admission_id | admissions.id | Agrupamento de parcelas por ficha |
| admissions.client_id | clients.id | Responsável da admissão |
| admissions.titular_client_id | clients.id | Titular distinto do responsável |
| admissions.bank_id | banks.id | Banco e serviços/percentuais cadastrados |
| admissions.modality_id | modalities.id | Modalidade do contrato |
| admissions.collaborator_id | collaborators.id | Colaborador da admissão, distinto do responsável da cobrança |
| admissions.series_id | séries recebidas por id | Sigla e identificação |
| admissions.unit_id | unidades recebidas por id | Unidade da admissão |
| admission_addendums.admission_id | admissions.id | Contagem e data de aditivos |
| collection_notes.title_id/client_id/collaborator_id | Títulos/clientes/colaboradores | Nota/solicitação do operacional |
| collection_notes.cancel_request.admissionId | Referência no JSON | Contrato solicitado; o frontend não resolve nem cancela automaticamente |
| audit_logs.entity_id | ID da entidade consultada | Histórico da linha, com alterações por campo |
| Anexos alvo ADMISSION + targetId | Admissão e cliente | Documentos protegidos por permissões |
| GoTalk clientId e collaboratorId | Cliente e colaborador CRM | Resolução de contato e recorte de atendimentos |

O backend de títulos valida referências e propriedade das relações de cliente antes de atualizar. Bancos e percentuais são cadastros locais nesse visualizador, não operações bancárias online. A consulta jurídica é histórica, não integração ativa de busca.

## 4.7 Notas de cobrança: integração com operacional
O operacional cria/consulta notas no backend collection_notes. O backend possui GET filtrado por ao menos clientId, collaboratorId ou titleId; POST; POST bulk; PUT e DELETE. As referências título/cliente/colaborador são validadas nas gravações correspondentes.

Padrões do POST: data atual UTC se ausente; hora 00:00; canal TELEFONE; negociação AGUARDANDO_CONTATO; vínculos opcionais null; anexos/snapshot/solicitação opcionais. Obrigatórios: id e note. PUT exige nota não vazia e aceita FECHADA, AGUARDANDO_CONTATO, ENCAMINHOU_BOLETO, RECUSA_DIVIDA, OUTROS e SOLICITA_CANCELAMENTO.

Essas opções pertencem ao registro operacional/API, não são um select editável da coordenação. O Dashboard de Coordenadores continua lendo a chave legada do navegador, sem GET das solicitações; isso pode impedir que notas novas do banco apareçam ali.

## 4.8 Segurança e escopo observado
- Entrada no módulo depende da navegação/permissões do sistema; o componente não contém sua própria guarda completa de visualização.
- Exclusão tem guarda explícita no frontend com fin_cobranca_coord:EXCLUIR; não extrapolar essa prova para todo o backend.
- Abrir ficha exige com_admissao:VISUALIZAR no frontend. Resumo/detalhe/anexos/scan de admissão também possuem guarda de leitura no servidor; administrador passa, usuário comum precisa de grupo com permissão.
- Rotas de títulos são montadas com extractUser, requireAuth e validateAccountStatus; não foi demonstrada nesta análise equivalência entre isso e uma autorização específica de coordenação para cada escrita.
- CollectionNotes aparece montado com extractUser, sem requireAuth no ponto de montagem, e o arquivo de rotas não exibe guarda específica por operação. É um ponto de atenção estático, não resultado de teste de exploração.
- Dados auxiliares dependem do que config carregou e autorizou. Não existe seletor próprio de unidade nesse painel. Escopo do servidor/RLS não deve ser deduzido só da interface.
- Bloqueio de cliente é verificado explicitamente na atribuição e exclusão de título. O handler de edição não faz a mesma verificação no componente; o banner não constitui por si só bloqueio universal.
- useDashboardInvalidation registra o tópico collection e chama refreshTitles em invalidações; isso ajuda a atualizar a consulta, mas não substitui a persistência ausente da atribuição.

## 4.9 Detalhes completos de cartões e mídias GoTalk
Na lista de atendimentos, cada cartão usa contato contact_name, depois client_name, depois contact_phone e, por fim, **Contato desconhecido**. Mostra operador ou **Sem operador**, collaborator_name quando presente, department ou subject, badges de status/tipo, started_at, message_count ou **Sem mensagens** e last_message_at quando disponível.

Na conversa, o compositor de resposta é mostrado somente se status=open, existe gotalk_attendance_id e há contact_phone. Atendimento fechado permanece para consulta; o envio não é habilitado apenas por possuir histórico. Sem canal ativo, mostra aviso de indisponibilidade. O botão HSM no atendimento exige status aberto e telefone. No chat geral, o botão HSM exige telefone do contato.

O chat geral atualiza mensagens automaticamente a cada **60 segundos**, além da atualização manual. A conversa de atendimento carrega ao selecionar e ao pedir mais; não há evidência de polling equivalente nesse componente.

O renderizador de mídia oferece, conforme tipo e dados recebidos:
- **TEXT**: texto com formatação e quebras; fallback “(mensagem vazia)”; conteúdo interativo reconhecido é apresentado em cartão de lista/botões, sem constituir criação de opções da cobrança.
- **IMAGE**: imagem, legenda quando presente, clique para ampliar em lightbox; fechar pela ação de fechamento/fundo; download quando existe proxy por messageId.
- **STICKER**: figurinha em imagem, quando há origem de mídia.
- **AUDIO/VOICE/PTT**: player HTML com controles; download e metadados MIME/tamanho; transcrição recebida pode ser expandida/recolhida. Não significa gerar uma transcrição nova por clique.
- **VIDEO**: player com controles e download/metadados quando disponíveis.
- **DOCUMENT PDF**: nome, MIME/tamanho, **Visualizar PDF** / **Recolher**, visualização embutida e link alternativo/download.
- **DOCUMENT de outros tipos**: identificação do arquivo, metadados e link/download conforme origem disponível.
- **TEMPLATE**: cartão de HSM com conteúdo recebido e informações de template/status quando presentes.
- Outros tipos: fallback textual pelo conteúdo recebido.

Com messageId, usa proxy `/api/gotalk/media/:messageId` e download com `?download=1`; sem ele, depende de attachmentUrl. Erros de imagem/áudio/vídeo mostram estado de falha e alternativa externa quando há URL. Isso é visualização de mídia recebida, não envio de novos anexos pelo compositor.

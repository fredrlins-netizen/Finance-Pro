# 6. Limitações observadas e roteiro de conferência

## 6.1 Diferenças comprováveis na leitura do código
| Item | Evidência | Consequência |
|---|---|---|
| Atribuição desconectada | Handler usa setTitles opcional; pai não fornece; sem chamada API | Confirmação pode informar sucesso sem alterar/persistir responsável ou situação |
| Reflexo da edição/exclusão | PUT/DELETE existem, atualização de lista depende do mesmo callback ausente | Backend pode ser alterado, mas linha depende de refresh/invalidação posterior |
| Dashboard paginado | Pai carrega 50, painel calcula sobre titles recebido | Valores não são total global garantido |
| Recuperação sem recorte de colaborador | Pagos filtram só tipo, status e período | Numerador pode usar pagos de outros colaboradores |
| DSO não convencional | Usa saldo médio por título, receita/30 e multiplica novamente por 30 | Não assumir aderência contábil |
| Cancelamentos legados | Coordenador lê localStorage; operacional usa API | Solicitações novas no banco podem não aparecer |
| Seleção por contagem | Selecionar todos compara quantidades, não conjuntos | Seleção mantida após filtros/páginas pode ser diferente da seleção visível |
| Títulos do cliente com fontes diferentes | Contador da página; parcelas da API sem mesmos filtros | Contagem e lista podem divergir |
| Ficha e resumo com permissão adicional | Exigem com_admissao:VISUALIZAR | Poder acessar cobrança não garante ver fichas/contadores |
| Falhas silenciadas | Resumo, detalhe e auditoria usam catches sem feedback específico | Travessão/vazio não prova ausência de dados |
| Cliente bloqueado | Guarda explícita em excluir/atribuir, não em editar neste componente | Não assumir bloqueio de todas as alterações pela interface |
| Anexos sem permissão | Branch PERMISSION_DENIED não é definido pelo catch atual | Negativa pode aparecer como erro genérico no legado |
| Notas sem guarda explícita no trecho | Montagem extractUser e handlers sem autorização específica | Requer avaliação de segurança separada; não houve teste de exploração |
| Fuso do atraso | new Date(data) no cálculo e data+T00:00:00 na exibição | Limites de atraso podem divergir da data visual por fuso |

Esses itens não foram corrigidos: a solicitação foi documentar e compactar, não modificar o sistema.

## 6.2 Roteiro de conferência com sessão autorizada
Os casos abaixo são instruções de verificação, **não testes executados neste levantamento**. Escritas e envios devem ser feitos somente em ambiente de testes com dados descartáveis e consentimento.

1. Navegar Cobrança → Coordenadores; confirmar modo inicial Carteira e cabeçalho.
2. Verificar os títulos RECEBER/PADRAO e exclusões de status com base conhecida.
3. Digitar busca e aguardar debounce; testar cada filtro isolado e combinado; limpar.
4. Conferir ordenação nas cinco colunas ordenáveis e vencimento inicial crescente.
5. Selecionar uma linha, todas, alterar filtros/página e conferir IDs efetivos selecionados.
6. Abrir atribuição; testar colaborador vazio, cliente bloqueado e confirmar com registro descartável; conferir no backend, sem confiar apenas no toast.
7. Abrir edição; verificar dez campos editáveis e três informativos; testar vencimento vazio e cancelar.
8. Salvar alterações autorizadas; confirmar payload, persistência, auditoria e refresh.
9. Excluir título descartável; conferir permissão, bloqueio de cliente, confirmação e tratamento 409.
10. Abrir cliente por nome/olho; conferir dados, fichas/aditivos, agrupamento e títulos sem ficha.
11. Abrir a última ficha e uma ficha específica; conferir todos os relacionamentos e quatro abas.
12. Em Documentos, conferir anexos legados e protegidos, preview, download, erro/repetição e ausência de controles de escrita.
13. Em Auditoria da ficha, conferir histórico jurídico sem nova consulta e rounds sem edição.
14. Abrir Histórico de Movimentações; verificar os campos De/Para e 15 linhas por página.
15. Com GoTalk habilitado e contato válido, conferir mensagens, leitura, importação por ID/telefone, atualização, envio e HSM usando destinatário de testes.
16. Abrir atendimentos pelo ícone; confirmar clientId e collaboratorId; testar Todos/Cliente/Banco, páginas e carregar mais.
17. Desabilitar integração em ambiente apropriado e confirmar abas ausentes; não alterar configuração real apenas para executar o roteiro.
18. Alternar Dashboard; validar filtros pelo vencimento e fórmulas com conjunto conhecido.
19. Alterar página e confirmar que os indicadores mudam conforme a fonte paginada.
20. Conferir solicitações locais versus banco e verificar que excluir nota não cancela contrato.
21. Validar acessos de administrador e usuário limitado, sem supor que ocultar botão proteja API.

## 6.3 O que o pacote não contém
Não contém segredos, credenciais, exportação da base, dados reais de clientes, mensagens particulares, anexos privados nem sessão autenticada. Os exemplos descrevem códigos e textos padrão encontrados no código. O conteúdo não certifica permissões efetivas em produção, disponibilidade do GoTalk nem sucesso de operações externas.

# 2. CRUD, modais e acionamentos

## 2.1 Matriz real de CRUD
| Entidade | Incluir | Consultar | Alterar | Excluir |
|---|---|---|---|---|
| Título financeiro | Não há botão/modal de inclusão neste painel | Carteira e modal de edição; dados do cliente | Modal Editar Lançamento usa PUT; atribuição tem desconexão descrita abaixo | DELETE com confirmação |
| Cliente | Não | Dados do Cliente, somente leitura | Não | Não |
| Admissão/contrato | Não | Ficha de Admissão e cartões | Não | Não |
| Solicitação de cancelamento | Não; origem é operacional | Card/lista no Dashboard | Não há aprovar, rejeitar nem executar cancelamento | Exclui a nota via DELETE |
| Auditoria | Não manualmente | Histórico de Movimentações | Não | Não |
| Mensagem GoTalk | Envio de texto e template nos componentes integrados | Conversas e atendimentos | Não há editar mensagem exposto neste fluxo | Não há excluir mensagem exposto neste fluxo |
| Anexos da ficha | Não no modo de consulta | Lista, preview e download | Não | Não |

CRUD disponível no backend não implica botão existente neste menu. Baixar um anexo não altera seu cadastro. Alterar a situação para Não Cobrar não cancela o título nem a admissão. Atribuir não cria atendimento GoTalk.

## 2.2 Modal Atribuir Colaborador
Acionamento: selecionar um ou mais títulos → **Atribuir (N)**. Título **Atribuir Colaborador**; informa a quantidade selecionada e que os títulos passarão para “Cobrar”.

Campo **Colaborador Responsável**: select, inicial vazio **Selecione...**; opções de collaborators, sem filtro adicional por ativo, cargo ou unidade neste componente. Rótulo name, valor id. Botões **Cancelar** e **Confirmar Atribuição**.

Validações, nesta ordem: colaborador obrigatório → ao menos um título → nenhum cliente bloqueado entre os títulos resolvidos pela seleção. Avisos: “Selecione um colaborador.”; “Selecione pelo menos um título.”; “Existem títulos de clientes bloqueados na seleção. Não é possível atribuir cobrança.”

Intenção implementada no handler: para cada título selecionado, assignedCollaboratorId recebe o ID e collectionStatus recebe COBRAR; registra transação CONTA_RECEBER com antes/depois; mostra sucesso com quantidade e nome; limpa seleção e colaborador e fecha o modal. Cancelar fecha e limpa só o colaborador.

**Ligação atual incompleta:** o handler usa `setTitles?.(...)`, opcional, mas CollectionPanel não fornece setTitles. Não há POST/PUT para atribuir. Portanto, nesse encadeamento, nem alteração local nem log dentro do callback são executados, embora o toast de sucesso e a limpeza aconteçam. Não se pode tratar a confirmação como atribuição persistida.

Não há modal de desatribuição em lote; a opção Sem atribuição só aparece na edição individual. O overlay de atribuição não tem fechamento por clique externo nem botão X.

## 2.3 Modal Editar Lançamento — todos os campos
Acionamento: ícone azul **Editar Lançamento** da linha. Cabeçalho apresenta cliente e documento. Os valores são copiados do título no momento da abertura.

| Campo | Tipo | Inicial/fallback | Opções/regras |
|---|---|---|---|
| Nº Documento | Texto | documentNumber ou vazio na renderização | Livre; sem required explícito |
| Vencimento * | Data | dueDate ou vazio | Único campo validado explicitamente pelo handler; sem ele avisa “Informe a data de vencimento.” |
| Previsão de Recebimento | Data | expectedDate ou vazio | Opcional |
| Status | Select | status atual | Em Aberto/ABERTO; Parcial/PARCIAL; Protestado/PROTESTADO; Provisão/PROVISAO |
| Situação de Cobrança | Select | collectionStatus ou EM_DIA | Em Dia/EM_DIA; Cobrar/COBRAR; Não Cobrar/NAO_COBRAR |
| Responsável | Select | assignedCollaboratorId ou vazio | Sem atribuição=vazio; todos os colaboradores por id/name |
| Juros (R$) | Number | interestValue ou 0 | min=0; step=0.01; parseFloat ou 0 |
| Multa (R$) | Number | penaltyValue ou 0 | min=0; step=0.01; parseFloat ou 0 |
| Desconto (R$) | Number | discountValue ou 0 | min=0; step=0.01; parseFloat ou 0 |
| Histórico / Descrição | Textarea, 3 linhas | description ou vazio | Texto livre |
| Valor original | Informação somente leitura | originalValue | BRL; não é input |
| Saldo | Informação somente leitura | currentBalance | BRL; não é input |
| Emissão | Informação somente leitura | issueDate | Data pt-BR; não é input |

Os atributos min e step não substituem validação financeira no handler, que não faz teste explícito de não negatividade desses três encargos. Não há recálculo local do saldo ao digitar juros/multa/desconto.

**Salvar Alterações**: ativa isSavingEdit; envia `PUT /api/financial-titles/:id`, mesclando o objeto inteiro do título com os campos do formulário e forçando titleScope=RECEBER. Usa res.data; preserva settlements anteriores quando existentes; tenta atualizar a lista por setTitles; registra logTransaction CONTA_RECEBER; mostra “Lançamento atualizado com sucesso.” e fecha. Em erro mostra a mensagem e mantém o modal; sempre termina o estado de salvamento.

Durante a requisição, botão de salvar exibe **Salvando...** e fica indisponível; Cancelar também. O X não possui disabled no JSX. **Cancelar** e X descartam o formulário. Não há fechamento por clique no overlay nesse modal.

Como o pai não fornece setTitles, a persistência via PUT existe, mas a atualização imediata da linha pelo callback não existe. Uma atualização posterior da consulta/invalidação pode refletir o novo valor.

## 2.4 Exclusão de título
Ícone vermelho **Excluir Título** só é mostrado para administrador ou permissão `fin_cobranca_coord:EXCLUIR`. O clique também chama validarPermissao com esse código.

Se o cliente estiver bloqueado, avisa “Cliente bloqueado — não é possível excluir este título.” e não abre a confirmação.

Modal: título **Excluir Título**; mensagem `Excluir o título "{documento}" de {cliente}? Esta ação não pode ser desfeita.`. Botões **Cancelar** e **Excluir**. Confirmação faz `DELETE /api/financial-titles/:id`; em sucesso tenta retirar a linha via setTitles, registra CONTA_RECEBER antes→null e mostra “Título removido com sucesso.”. Erro pode incluir details de ApiError e exibe toast. O fluxo final fecha a confirmação mesmo quando a operação de título falha.

Modal compartilhado: portal no body; fundo escuro; Escape e clique fora cancelam quando não está carregando; durante carregamento os botões e fechamento efetivo ficam bloqueados; confirmação mostra spinner. Não existe opção de desfazer implementada.

O backend também impede excluir PAGO e impede excluir um membro de grupo de fatura quando há outro título pago no mesmo grupo, retornando conflito 409. Outros vínculos podem provocar rejeição por integridade referencial.

## 2.5 Exclusão de solicitação
No Dashboard, expandir Solicitações de Cancelamento Pendentes → **Excluir**, apenas quando canExcluir. Valida a mesma permissão de exclusão.

Modal **Excluir Solicitação de Cancelamento**; mensagem **Excluir esta solicitação de cancelamento? Esta ação não pode ser desfeita.**.

Confirmar chama `DELETE /api/collection-notes/:id`; remove a nota do estado e grava a lista restante na chave collection_notes_v1 do localStorage; mostra “Solicitação de cancelamento excluída.”. Erro mostra “Não foi possível excluir a solicitação.”. Apagar a nota não cancela contrato, título ou parcela.

## 2.6 Histórico de Movimentações
Acionamento: ícone de relógio na linha. Modal **Histórico de Movimentações**, identificação cliente/documento, selo **Somente Leitura**. Ao abrir, zera página e lista e consulta `/api/audit-logs?entity_id={id}&limit=500`. A prop logs recebida não é usada como fonte efetiva nesse componente.

Ordena eventos do mais recente para o mais antigo. Cada alteração de campo gera uma linha: **Data/Hora; Usuário; Ação; Campo; De; →; Para**. Quando não há changes, exibe descrição em Para e travessões em Campo/De. Usuário ausente vira Sistema; unidade ausente vira GLOBAL na normalização.

As ações reconhecidas para cores incluem CREATE, UPDATE, DELETE, BAIXA, BAIXA_PARCIAL, CANCELAR_BAIXA, CANCELAR, INVOICE, RECORRENCIA, LINK e DEDUCAO; rótulos/campos/valores são traduzidos pelos utilitários de auditoria. Isso é histórico recebido, não uma lista de ações acionáveis do menu.

Paginação local de 15 linhas de alteração por página (um evento pode produzir várias linhas), contador de movimentações, navegação e fechamento pelo X ou fundo. Vazio: “Nenhuma movimentação registrada para este item.”. Falhas de carregamento são silenciadas no catch, podendo parecer ausência de histórico.

## 2.7 Atalhos
Enquanto edição ou atribuição está aberta, registra ações de salvar/cancelar no contexto de atalhos. O listener atual efetivamente aciona salvar por **Ctrl+Enter** ou **Cmd+Enter**. Não há listener de cancelamento nesse contexto; não presumir Escape para esses dois modais. O modal de exclusão implementa seu próprio Escape.

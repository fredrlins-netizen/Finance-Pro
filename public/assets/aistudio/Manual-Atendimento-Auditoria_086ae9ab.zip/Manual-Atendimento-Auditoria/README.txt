ATENDIMENTO → AUDITORIA — MANUAL FUNCIONAL

Abra manual-atendimento-auditoria.html no navegador.
O sumário permite ir diretamente ao assunto. É possível imprimir pelo navegador.

Arquivos:
- manual-atendimento-auditoria.html: versão de leitura e impressão, autossuficiente.
- manual-atendimento-auditoria.md: texto editável em Markdown.
- inventario-campos.csv: campos, ações, padrões e regras das tabelas do manual.
- variaveis-formularios.csv: todos os marcadores reconhecidos pela mesclagem de formulários.
- referencias-fontes.csv: arquivos inspecionados, tamanho e hash de identificação.

CSV: UTF-8 com BOM, separador ponto e vírgula.

Documentação baseada no código do projeto em 14/11/2026.
Nenhuma gravação operacional foi executada; a interface autenticada não foi testada.
As listas cadastradas e os conteúdos particulares dependem dos dados e permissões do sistema.
O botão Boleto cria título financeiro; não representa emissão bancária.
As limitações de persistência e integração estão explicitadas no manual.

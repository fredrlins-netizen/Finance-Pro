# Atendimento → Auditoria

## 1. Escopo e forma de leitura

Este manual relaciona as telas, campos, grades, ações, modais, padrões, validações, integrações e relacionamentos implementados na opção **Atendimento → Auditoria** do Meu Gestor Inteligente. Inclui os componentes compartilhados efetivamente acionados pelo painel.

**Base:** inspeção do código disponível no projeto em 14/11/2026. Não foi realizado login na interface autenticada, consulta a dados de clientes, execução de baixas ou gravação de registros. Não foram alterados o aplicativo nem seus dados.

Os nomes dos campos são os da interface; identificadores entre crases permitem rastrear a implementação. “Padrão” significa o valor inicial programado, não um exemplo de dado de cliente. Conteúdos dinâmicos — clientes, bancos, modelos de formulário e itens de checklist — dependem dos cadastros e permissões. Não há uma lista fixa de seus valores que possa ser afirmada apenas pelo código.

O documento separa **comportamento implementado** de mensagens da interface e de limitações. A presença de um botão não comprova emissão bancária, envio a tribunal ou persistência de todos os dados locais.

## 2. Mapa das telas e operações

| Tela ou componente | Como acessar | Finalidade e operações disponíveis |
| --- | --- | --- |
| Fila de Auditoria | Atendimento → Auditoria | Consultar admissões aprovadas, pesquisar, paginar, abrir histórico e iniciar conferência. |
| Auditoria de Processo | Botão AUDITAR na linha | Consultar a folha de rosto, marcar checklist, escolher resultado, anexar documentos e salvar. É uma página interna, não um modal de inclusão. |
| Visualização A4 | Selecionar formulário → Visualizar | Visualizar dados mesclados em modelo, imprimir e fechar. Somente leitura. |
| Gerar Lançamento — seleção | Boleto | Escolher Taxa Administrativa ou Primeira Parcela; cancelar. |
| Inclusão — Contas a Receber | Escolher o tipo de lançamento | Revisar descrição, valor e vencimento e criar título financeiro. |
| Boletos Gerados | Botão homônimo, com registros | Consultar cartões de títulos e editar valor/vencimento no próprio cartão. |
| Ficha de Admissão | Ficha | Modal de consulta com abas Identificação, Contrato / Financeiro, Documentos e Auditoria. |
| Visualização de anexo | Visualizar arquivo ou Ver | Abrir conteúdo em janela do navegador ou visualizador de documento armazenado. |
| Histórico de Movimentações | Ícone de histórico na linha da fila | Consultar eventos e alterações de campos; não altera registros. |
| Confirmação de checklist incompleto | Finalizar com itens desmarcados | Confirmação nativa do navegador; prosseguir ou interromper. |
| Confirmação de lançamentos | Gerar Lançamentos | Confirmação nativa com os valores e documentos a criar. |

Não há nesta opção botões de nova admissão, exclusão de admissão, exclusão de título financeiro, liquidação, conciliação bancária ou cadastro de bancos/clientes. Esses CRUDs pertencem a outras opções.

## 3. Fila de Auditoria: origem, pesquisa e paginação

A fila usa `config.admissions`, filtrando **exclusivamente `status === 'APROVADA'`**. Não há consulta de fila com filtros no servidor dentro deste painel. Um hook de admissões é instanciado com tamanho 500 para atualização, mas não é a fonte direta usada no filtro da grade.

| Elemento | Padrão/conteúdo | Acionamento e comportamento |
| --- | --- | --- |
| Título | Fila de Auditoria | Identifica a lista operacional. |
| Descrição | Processos aprovados pelo comercial aguardando conferência. | Texto de orientação. |
| Contador | Quantidade filtrada + PROCESSOS AGUARDANDO | Varia com a pesquisa, não é necessariamente o total de todas as admissões no banco. |
| Pesquisa | Vazia; “Pesquisar por Cliente, Nº Contrato ou Código...” | Digitar filtra imediatamente os registros já disponíveis. |
| Nome do cliente na pesquisa | `clientName` | Comparação em minúsculas; não remove acentos. |
| Contrato na pesquisa | `contractNumber` | Procura a sequência informada; o termo é convertido a minúsculas, o contrato não. |
| Código na pesquisa | ID da admissão | Não é o código do cliente exibido na linha. |
| Página inicial | 1 | Recorte local da lista filtrada. |
| Tamanho efetivo da página | 10 | Valor fixo no painel. |
| Seletor Exibir | Componente mostra 5, 10, 20, 50 e 100 | O callback de tamanho está vazio: a seleção não altera os 10 itens; apenas pode retornar à página 1. |
| Navegação | Anterior/Próxima; números de página no desktop | Altera a página; exibe intervalo e total. Em tela pequena há navegação simplificada. |
| Lista vazia | Nenhuma admissão pendente de auditoria encontrada. | Aparece também quando não há correspondências para a pesquisa. |

**Limites:** a busca não reinicia `currentPage`. Se o usuário estiver em página alta e reduzir os resultados, pode visualizar uma página vazia mesmo com correspondências em páginas anteriores. A ordem é a ordem recebida na configuração; não há ordenação por cabeçalho, seleção em lote, exportação ou filtros avançados próprios.

Embora o código contenha rótulos REVISAR para AUDITADA/RETORNO AUDITORIA, tais estados são excluídos pelo filtro APROVADA. Não se deve descrever revisão desses estados como caminho normalmente disponível nessa fila.

## 4. Data grid da fila: todas as colunas e CRUD

| Coluna/campo | Origem e padrão | Função |
| --- | --- | --- |
| Status | `admission.status` | Badge com a situação; na fila atual, APROVADA. Há estilo alternativo para AUDITADA que o filtro não alcança normalmente. |
| Contrato | `contractNumber`, prefixado por # | Identificação do contrato. |
| Cliente | `clientName` | Nome em destaque. |
| Cód. do cliente | `clientId` | Exibido abaixo do nome; não confundir com o ID pesquisado. |
| Banco | `bankId` relacionado a `config.banks` | Nome; ausência: Banco não identificado. |
| Data Admissão | `date` | Formatação brasileira pelo navegador. |
| Histórico | `admission.id` e nome do cliente | Abre Histórico de Movimentações da entidade. |
| AUDITAR | Objeto da admissão da linha | Abre o fluxo de auditoria e inicia a consulta de títulos associados. |

**CRUD da grade:** C — não cria admissões; R — pesquisa/consulta; U — abre o fluxo de análise e mudança de status; D — não disponível. Não há edição direta de células.

## 5. Abertura da auditoria e valores iniciais

| Campo/estado | Valor ao abrir AUDITAR | Consequência |
| --- | --- | --- |
| Admissão selecionada | Objeto da linha | Base da consulta e dos comandos. |
| Visualização | WORKFLOW | Substitui a fila pela Auditoria de Processo. |
| Status de auditoria | PENDENTE | Reiniciado a cada abertura; não recupera EM_ANALISE previamente escolhido. |
| Crítica | `admission.auditCritique` ou vazio | Reaproveita a crítica anterior quando presente. |
| Checklist | Todos os itens ATIVOS como `false` | Inclui itens ativos de modalidades que podem não estar visíveis. |
| Observação Manual | Vazia | Não carrega observação anterior. |
| Formulário | Nenhum selecionado | Prévia fechada. |
| Títulos/boletos | Lista inicialmente vazia | Busca títulos se o ID da admissão tiver formato UUID. |
| Edição de boleto | Nenhuma | Um cartão pode entrar em edição depois. |
| Anexos locais | `admission.attachments` ou lista vazia | Lista editável independente do quadro de anexos originais. |

A consulta inicial de títulos usa `/api/financial-titles/by-admission/:id`. Enquanto consulta, Boleto fica desabilitado. Falhas dessa consulta são capturadas sem aviso próprio; a ausência de registros na tela não comprova ausência no banco.

Clientes são buscados com `useEntityCRUD('clients', {pageSize: 2000})`. Se essa lista tiver qualquer item, ela é preferida integralmente a `config.clients`; não ocorre uma mesclagem individual de clientes faltantes.

## 6. Barra superior e comandos de navegação

| Controle | Padrão/condição | Resultado do acionamento |
| --- | --- | --- |
| Seta de retorno | Sempre no fluxo | Volta à lista e limpa a admissão selecionada. |
| Identificação | Contrato, nome do cliente e unidade | Unidade por nome fantasia, razão social, CNPJ ou Não informada. |
| Seletor de formulário | Vazio | Lista modelos vinculados ao menu `auditoria`. |
| Visualizar | Sem bloqueio visual por seleção vazia | Sem seleção, aviso; com seleção, abre prévia A4. |
| Ficha | Disponível visualmente | Valida administrador ou permissão `com_admissao:VISUALIZAR` antes de abrir. |
| Boleto | Desabilitado durante consulta ou se houver qualquer título associado carregado | Abre a seleção do tipo de lançamento. |
| Boletos Gerados | Desabilitado se a lista estiver vazia | Abre consulta/edição, com badge da quantidade. |
| Status | PENDENTE | Seleciona Pendente, Em Análise, Retornar Comercial ou Concluído. Não salva sozinho. |
| Voltar | Sempre | Retorna à fila sem confirmação de descarte. |
| CANCELAR | Rodapé | Mesmo retorno sem salvar a auditoria. |
| Botão principal | Depende do status | SALVAR PROGRESSO, DEVOLVER AO COMERCIAL ou FINALIZAR AUDITORIA. |

Não há proteção de alterações não salvas ou atalho Ctrl+Enter registrado neste painel. Cancelar/Voltar não desfazem títulos financeiros já criados ou editados, nem mensagens já disparadas.

## 7. Folha de rosto — identificação, contato e vínculos

O quadro **Resumo da Folha de Rosto / Somente Leitura** não edita cadastros. Os dados são lidos do cliente vinculado, da admissão e dos cadastros relacionados.

| Campo | Origem | Padrão/condição |
| --- | --- | --- |
| Cliente | `client.name` | Pode ficar vazio se o relacionamento não for localizado. |
| Tipo Cliente | `admission.tipoCliente` | RESPONSÁVEL quando vazio. |
| CPF/CNPJ | `client.document` | Conteúdo cadastrado. |
| RG | `client.rg` | — quando ausente. |
| Telefone | `client.phone` | — quando ausente. |
| Telefone 2 | `client.phone2` | — quando ausente. |
| E-mail | `client.email` | NÃO INFORMADO quando ausente. |
| Data Nasc. | `client.birthDate` | Data brasileira; — quando ausente. |
| Estado Civil | `client.maritalStatus` | — quando ausente. |
| Profissão | `client.profession` | — quando ausente. |
| Tipo | `client.type` | PF/PJ ou valor cadastrado; — quando ausente. |
| Endereço | `client.address` | Bloco visível quando há endereço ou cidade. |
| Número | `client.number` | Integrado à linha de endereço com Nº. |
| Complemento | `client.complement` | Somente se informado. |
| Bairro | `client.district` | Integrado ao endereço. |
| Cidade | `client.city` | Linha cidade/UF. |
| UF | `client.state` | Linha cidade/UF. |
| CEP | `client.cep` | Acrescentado quando informado. |
| Data Admissão | `admission.date` | Data brasileira. |
| Contrato Nº | `contractNumber` | Conteúdo da admissão. |
| Série | `seriesId` → `config.series.sigla` | — se não localizada. |
| Colaborador | `collaboratorId` → nome | — se não localizado. |
| Indicação | `indicationType` | — quando ausente. |
| Origem | `originType` | — quando ausente. |
| Unidade | `unitId` → `config.units` | Nome fantasia, razão social, CNPJ ou Não informada. |

## 8. Folha de rosto — titular

O bloco **01.B. Dados do Titular** só aparece quando `titularClientId` permite localizar outro cadastro na lista de clientes.

| Campo | Origem | Padrão/condição |
| --- | --- | --- |
| Nome do titular | `titular.name` | Cadastro vinculado, somente leitura. |
| CPF/CNPJ do titular | `titular.document` | Conteúdo cadastrado. |
| RG do titular | `titular.rg` | — quando ausente. |
| Nascimento do titular | `titular.birthDate` | Data brasileira ou —. |
| Telefone do titular | `titular.phone` | — quando ausente. |
| E-mail do titular | `titular.email` | — quando ausente. |
| Estado Civil do titular | `titular.maritalStatus` | — quando ausente. |
| Profissão do titular | `titular.profession` | — quando ausente. |
| Endereço do titular | `titular.address` | Com número, complemento, bairro, cidade e UF; bloco se endereço ou cidade. |
| Número do titular | `titular.number` | Parte do endereço. |
| Complemento do titular | `titular.complement` | Parte do endereço. |
| Bairro do titular | `titular.district` | Parte do endereço. |
| Cidade do titular | `titular.city` | Parte do endereço. |
| UF do titular | `titular.state` | Parte do endereço. |
| CEP do titular | `titular.cep` | Acrescentado quando informado. |

Não há seletor para trocar cliente ou titular nesta tela.

## 9. Contrato, banco e percentuais de negociação

| Campo | Origem | Padrão/funcionalidade |
| --- | --- | --- |
| Banco | `bankId` → banco | Nome da instituição do contrato; não é a seleção de conta corrente para receber. |
| Modalidade | `modalityId` → modalidade | Descrição, tipo ou —. |
| Valor Financiado | `financedAmount` | Exibido com R$. |
| Parcela Atual | `installmentValue` | Exibido com R$. |
| Total Parcelas | `totalInstallments` | Número registrado. |
| Situação — Pagas | `paidInstallments` | Compõe “Pagas / Atraso”. |
| Situação — Atraso | `overdueInstallments` | Compõe “Pagas / Atraso”. |
| Dia Vencimento | `dueDay` | Prefixo Dia. |
| Forma Pagamento | `paymentType` | — quando ausente. |
| Venc. 1ª Parcela | `firstInstallmentDueDate` | Somente se informado. |
| Tarifa Bancária Inclusa | `hasBankFeeIncluded` | Tag somente se verdadeiro. |
| Contrato de Terceiro | `isThirdPartyContract` | Tag somente se verdadeiro. |

A grade **02.B. Percentuais de Negociação** só aparece com banco e serviços cadastrados:

| Coluna/campo | Conteúdo/cálculo | CRUD/acionamento |
| --- | --- | --- |
| Serviço / Modalidade | `bank.services[].name` | Consulta; sem ação de inclusão/edição/exclusão. |
| % Neg. | `negotiationPercentage` | Percentual do cadastro do serviço. |
| Valor Calculado | Valor financiado × percentual ÷ 100 | Formatação monetária brasileira; resultado não positivo aparece como —. |
| Atual | Tag por aproximação textual | Compara trechos de seis caracteres dos nomes/descrições, não igualdade por ID. |
| Base do cálculo | Texto com o valor financiado | Referência informativa. Não cria cobrança. |

O parse de valores brasileiros remove pontos e troca vírgula por ponto; não tratar o texto de entrada como valor decimal de outro padrão sem revisão.

## 10. Veículo, recálculo e valores de cobrança

**03. Dados do Veículo** aparece somente na modalidade cujo tipo é exatamente VEÍCULOS.

| Campo | Origem | Condição/padrão |
| --- | --- | --- |
| Marca | `vehicleBrand` | — quando ausente. |
| Modelo | `vehicleModel` | — quando ausente. |
| Cor | `vehicleColor` | — quando ausente. |
| Ano | `vehicleYear` | — quando ausente. |
| Placa | `vehiclePlate` | — quando ausente. |
| RENAVAM | `vehicleRenavam` | — quando ausente. |
| Chassi | `vehicleChassis` | Campo mostrado somente quando informado. |
| ELÉTRICO | `isElectricVehicle` | Badge; também bloqueia conclusão da auditoria. |

A grade **04. Parcelas Recalculadas** é somente leitura, usa todos os `recalcScenarios` da admissão e não executa novo recálculo.

| Coluna/campo | Origem | Padrão/função |
| --- | --- | --- |
| Cenário | `label` | Identificação do cenário. |
| Dívida Orig. | `originalDebt` | Valor registrado. |
| Nova Dívida | `newDebt` | Valor registrado. |
| Economia | `savings` | Valor registrado. |
| Parcelas | `installmentsToPay` | — se ausente. |
| Vl. Parcela | `installmentValue` | — se ausente. |
| Dia Venc. | `dueDay` | — se ausente. |

Sem cenários: “Nenhum cenário de recálculo.” Não há C/U/D de cenários nessa grade.

| Campo de cobrança/adicional | Origem | Condição/função |
| --- | --- | --- |
| Parcela Adm. | `parcela1` | Aparece se preenchida; alimenta Gerar Lançamentos. |
| 1ª Parcela Real | `parcela2` | Aparece se preenchida; alimenta Gerar Lançamentos. |
| Taxa de Cobrança | `taxaCobranca` | Exibição quando preenchida; não é o valor usado pelo botão Boleto para Taxa Administrativa. |
| Taxa Administração (R$) | `otherInfo1` | Bloco Informações Adicionais; prioridade no formulário de Boleto/Taxa. |
| Primeira Parcela (R$) | `otherInfo2` | Bloco Informações Adicionais; prioridade no formulário de Boleto/Primeira Parcela. |

## 11. Histórico jurídico e Observação Manual

**Consulta jurídica registrada** usa `admission.legalScan`. Sem objeto, o componente do resumo não aparece. É compatibilidade de leitura com resultados salvos; **não faz consulta atual, não aciona DataJud e não atualiza processos externamente**.

| Campo histórico | Conteúdo | Condição |
| --- | --- | --- |
| Data da consulta | `lastUpdate` | Texto de referência se presente. |
| Localizado | `found` | Mensagem positiva ou negativa. |
| Processo | `processNumber` | Quando localizado e preenchido. |
| Tribunal | `court` | Quando localizado e preenchido. |
| Última movimentação registrada | `lastMovement` | Quando localizado e preenchido. |
| Parte autora | `plaintiff` | Quando localizado e preenchido. |
| Lista de processos — número | `allProcesses[].numeroProcesso` | Lista histórica com rolagem. |
| Lista de processos — tribunal | `allProcesses[].tribunal` | Junto ao número. |
| Lista de processos — classe | `classe` | Se preenchida. |
| Lista de processos — assunto | `assunto` | Se preenchido. |
| Lista de processos — parte autora | `parteAutora` | Se preenchida. |
| Lista de processos — ajuizamento | `dataAjuizamento` | Se preenchida; texto registrado. |
| Lista de processos — movimentação | `ultimaMovimentacao` | Se preenchida. |
| Varredura de Processos — Ref. | Documento do cliente | Referência visual, sem pesquisa externa. |
| Observação Manual | `manualScanText`, vazia | Textarea de duas linhas; placeholder Informações adicionais da varredura manual... |

**Limitação importante:** Observação Manual muda apenas o estado React e não é enviada por `handleSave`, nem incorporada ao resultado jurídico. Portanto não documentar esse campo como persistido.

## 12. Checklist de Conformidade

| Campo/regra | Padrão | Acionamento/efeito |
| --- | --- | --- |
| Origem dos itens | `config.auditCheckItems` | Conteúdo configurável em outro módulo. |
| Status do item | Somente ATIVO | Inativos não são apresentados. |
| Rótulo | `label` | Nome da verificação. |
| Descrição | `description` | Instrução abaixo do rótulo. |
| Ordem | `order` | Ordenação crescente; número com pelo menos dois dígitos. |
| Condição de modalidade | `conditionField` | Sem condição: mostra; com condição: exige igualdade com o tipo da modalidade. |
| Marcação | Desmarcada ao abrir | Clique alterna somente o valor local do item. |
| Indicadores no cabeçalho | Até três chaves do checklist | São indicadores visuais; não representam campos adicionais editáveis. |
| Item com “jurídico” | Detecção textual com acento | Ao marcar como verdadeiro, dispara rotina de notificação. Pode disparar novamente após desmarcar e remarcar. |
| Item de procuração | Primeiro ATIVO cujo rótulo contém “procuraç” | Visualizar formulário marca automaticamente, mesmo que não tenha sido impresso/assinado. |
| Pendências na conclusão | Quantidade de `false` em todo o checklist | Inclui itens ativos de modalidades não visíveis, pois todos foram inicializados. |

Marcar todos os itens **não** conclui automaticamente a auditoria. É necessário escolher Concluído e acionar FINALIZAR AUDITORIA. Os valores individuais do checklist não são incluídos no salvamento implementado; reabrir reinicia tudo desmarcado.

Não há CRUD de definição dos itens dentro do painel. Configurações de ordem, rótulo, condição e ativação pertencem ao cadastro de checklist.

## 13. Status, crítica, salvamento e transições

| Seleção | Botão principal | Status enviado à admissão | Validação/efeito |
| --- | --- | --- | --- |
| Pendente | SALVAR PROGRESSO | Mantém o status anterior | Para linha APROVADA, tenta reenviar APROVADA. Há incompatibilidade com a lista de transições do servidor, que não permite APROVADA → APROVADA. |
| Em Análise | SALVAR PROGRESSO | AUDITADA | Depois da atualização, deixa de atender ao filtro APROVADA da fila. |
| Retornar Comercial | DEVOLVER AO COMERCIAL | RETORNO AUDITORIA | Crítica com conteúdo não branco é obrigatória. |
| Concluído | FINALIZAR AUDITORIA | CONCLUIDO | Bloqueia veículo elétrico; pede confirmação se checklist tiver itens pendentes; dispara notificações antes da persistência. |
| Crítica da Auditoria | `auditCritique` | Texto da devolução | Campo só visível em Retornar Comercial; carrega crítica anterior; placeholder Descreva detalhadamente o motivo da devolução para o comercial... |

Ao devolver ao Comercial, o código monta um round com ID temporal, número igual à quantidade anterior + 1, data/hora ISO, crítica e autor literal **Auditoria**. Zera `auditResponse` no objeto de configuração. O histórico antigo permanece e o Comercial poderá responder no fluxo próprio.

Sequência implementada de salvar:

1. Validar crítica e, para conclusão, veículo/checklist.
2. Montar a lista completa `updatedAdmissions`, incluindo status, crítica, resposta, histórico e anexos locais.
3. Solicitar registro de auditoria pelo contexto `logTransaction`, com status e `legalScan`.
4. Se o ID for UUID, executar PATCH `/api/admissions/:id/status`, enviando somente `status` e `audit_critique`.
5. Executar `fetch` PUT `/api/settings/section`, com `key: admissions` e a lista montada.
6. Atualizar admissões/configuração e voltar à fila com mensagem de sucesso.

**Diferença de persistência:** PATCH atualiza a tabela de admissões em transação e registra auditoria no servidor. PUT de seção grava um espelho JSON de configuração, exige administrador e não grava diretamente as tabelas relacionais de anexos/histórico. O painel não verifica `response.ok` desse `fetch`: um HTTP 403/400 pode não ser tratado como falha. Assim, status persistido não comprova persistência de anexos, rounds e resposta no armazenamento normalizado.

As duas requisições não formam uma transação única. Se a primeira gravar e a segunda falhar, não há desfazimento automático. IDs não UUID não passam pelo PATCH. O botão final não possui estado de gravação que impeça cliques repetidos.

Mensagens previstas: Processo devolvido ao Comercial (Retorno Auditoria); Auditoria finalizada com sucesso; Progresso da auditoria salvo; ou erro ao salvar. Não há campo de assinatura, data de auditoria editável ou auditor selecionável.

## 14. Mensagens para Jurídico e Financeiro

A rotina procura o primeiro grupo cujo nome contenha “jurídico” ou “juridico” e o primeiro cujo nome contenha “financeiro” ou “financ”. Usa a função de mensagens do layout; não é um e-mail nem uma chamada bancária.

| Dado/ação | Conteúdo | Observação |
| --- | --- | --- |
| Destinatário jurídico | Tipo GROUP e ID encontrado | Sem grupo correspondente, não há envio a esse destinatário. |
| Texto jurídico | Contrato, cliente e banco; indicação de encaminhamento | Banco não encontrado aparece como Banco não identificado. |
| Evento jurídico | `AUDITORIA_CONCLUIDA_JURIDICO` | Metadados incluem `admissionId`. |
| Destinatário financeiro | Grupo localizado pelo nome | Independente da existência do grupo jurídico. |
| Texto financeiro | Cliente, contrato, banco e dados da parcela do primeiro cenário | Parcela/quantidade só se ambos disponíveis. |
| Evento financeiro | `AUDITORIA_CONCLUIDA_FINANCEIRO` | Metadados incluem `admissionId`. |
| Gatilho por checklist | Marcar item cujo rótulo contém “jurídico” | Pode acontecer antes de concluir/salvar. |
| Gatilho por conclusão | Finalizar em CONCLUIDO | Também ocorre antes do PATCH. |
| Toast | Departamentos Jurídico e Financeiro notificados. | É mostrado mesmo sem grupos encontrados; não comprova entrega. |

Os disparos não são aguardados como uma confirmação de entrega pelo painel e não há deduplicação local. Uma falha de salvamento não desfaz mensagens já disparadas.

## 15. Formulários — seleção, prévia e impressão

Os formulários vêm de `config.formTemplates`, filtrados pelo vínculo `menuIds` com `auditoria`; o contexto está cadastrado no registro de formulários. Este painel não cria nem edita modelos e não filtra explicitamente seus status.

| Campo/ação | Padrão/conteúdo | Resultado |
| --- | --- | --- |
| Selecionar Formulário | Vazio | Seleciona o ID do modelo. |
| Nenhum formulário vinculado | Lista sem modelos | Não há modelo para mesclar. |
| Visualizar | ID obrigatório | Sem ID, aviso; com ID, abre a sobreposição A4 e marca item de procuração. |
| Título da prévia | Nome do modelo + Visualização A4 | Identifica o documento. |
| Cabeçalho | `template.header` | Substitui variáveis e sanitiza HTML. |
| Corpo | `template.content` | Substitui variáveis, separa páginas e sanitiza. |
| Rodapé | `template.footer` | Substitui variáveis e repete por página. |
| Página | A4 vertical 210 × 297 mm, margem interna 15 mm | Fonte Arial, conteúdo preto. |
| Quebra de página | Marcadores CSS e TinyMCE no nível de nós do corpo | Reconhece page-break-before/after, break-before/after e mce-pagebreak/mce_pagebreak. |
| Imprimir | `window.print()` | Abre impressão do navegador; PDF apenas se escolhido pelo usuário no navegador. |
| Fechar | Botão da prévia | Fecha a sobreposição e mantém o fluxo de auditoria. |

Não há geração de arquivo DOCX, envio automático, assinatura digital ou gravação do documento impresso em anexos nesse comando. A substituição usa o dado atual em memória e o **primeiro cenário** de recálculo. Unidade da admissão é preferida; empresa geral é fallback.

O anexo **variaveis-formularios.csv** lista individualmente todos os marcadores e suas expressões de origem no código, incluindo aliases de veículo. Abrange cliente, titular, banco, colaborador, empresa, admissão, modalidade, recálculo e data/hora. Marcadores reconhecidos sem valor ficam vazios, salvo fallback explicitado. Marcadores não reconhecidos não têm substituição garantida.

Particularidades: `admissao.tipo_cliente` usa RESPONSÁVEL quando vazio; parcelas a pagar usa total menos pagas somente quando ambos os valores são avaliados como verdadeiros; `admissao.taxa_administrativa` usa `taxaCobranca`, não `otherInfo1`; não há marcador que garanta o texto de Observação Manual.

## 16. Boleto — significado, seleção e bloqueios

**A opção Boleto cria um lançamento em Contas a Receber. Não implementa emissão de boleto bancário, código de barras, linha digitável, registro bancário, remessa/retorno CNAB ou envio ao pagador.**

O botão fica bloqueado se existir **qualquer** título retornado para a admissão com origem AUDITORIA, independentemente de estar cancelado ou do tipo. Depois de criar um lançamento pelo modal, a lista local passa a ter item e bloqueia nova abertura; assim, o fluxo não oferece normalmente criar os dois tipos um após o outro pelo mesmo botão.

| Opção do modal | Documento padrão | Ação |
| --- | --- | --- |
| Taxa Administrativa | Número do contrato | Abre Inclusão — Contas a Receber para taxa. |
| Primeira Parcela | Número do contrato + `-01` | Abre a inclusão para primeira parcela. |
| Cancelar | Sem campos | Fecha a seleção, sem criar título. |

Não há confirmação extra ou botão X próprio programado nessa seleção. O fundo não possui ação explícita de fechar.

## 17. Modal Inclusão — Contas a Receber: todos os campos

| Campo | Padrão — Taxa Administrativa | Padrão — Primeira Parcela | Edição/validação |
| --- | --- | --- | --- |
| Tipo no subtítulo | Taxa Administrativa | Primeira Parcela | Consulta, determinado na etapa anterior. |
| Cliente | Nome da admissão | Nome da admissão | Somente leitura; não troca cliente. |
| Nº Contrato | Contrato atual ou — | Contrato atual ou — | Somente leitura. |
| Nº Documento | Contrato | Contrato + -01 | Preenchimento automático, não editável. |
| Descrição | Taxa Administrativa — Contrato #...; cliente, banco e modalidade | 1ª Parcela — Contrato #...; cliente, banco, modalidade e parcelas do primeiro cenário ou valor financiado | Texto editável; sem validação específica de descrição obrigatória no handler. |
| Valor (R$) | `otherInfo1`, senão `parcela1`, senão vazio | `otherInfo2`, senão `parcela2`, senão vazio | Texto; placeholder 0,00; exige número convertido maior que zero. |
| Vencimento | Data atual ISO/UTC | Primeiro vencimento da admissão ou data atual ISO/UTC | Campo date; obrigatório no handler. |
| Voltar | Etapa de seleção | Etapa de seleção | Retorna sem gravar; selecionar outro tipo recalcula valores. |
| Salvar Lançamento | Habilitado fora da gravação | Habilitado fora da gravação | Faz POST financeiro; mostra Salvando... e desabilita o botão durante a requisição. |

Exemplo de composição da descrição, sem dados reais: “Taxa Administrativa — Contrato #NÚMERO | Cliente: NOME | Banco: BANCO | Modalidade: MODALIDADE”. Na primeira parcela, acrescenta “N× de R$ VALOR” se houver cenário; caso contrário pode acrescentar o valor financiado.

O formulário não oferece campos de conta bancária, centro de custo, categoria, departamento, juros, multa, desconto ou forma de pagamento. Não preencher silenciosamente esses campos como se fossem escolhidos aqui.

## 18. Criação do título e relacionamentos financeiros

| Campo de integração | Padrão/origem | Regra |
| --- | --- | --- |
| `title_scope` | RECEBER | Sempre contas a receber, não pagar. |
| `status` | ABERTO | Situação inicial. |
| `source` | AUDITORIA | Permite localizar posteriormente pela admissão. |
| `type` | PADRAO | Não cria fatura agrupada. |
| `issue_date` | Hoje via ISO/UTC | Não é campo editável no modal. |
| `description` | Descrição do formulário | Conteúdo revisado. |
| `document_number` | Documento automático | Contrato ou contrato-01. |
| `value` | Valor convertido | Deve ser maior que zero na UI. |
| `due_date` | Vencimento do formulário | Obrigatório. |
| `client_name` | Nome da admissão | Identificação textual. |
| `client_id` | ID do cliente | Enviado se UUID. |
| `admission_id` | ID da admissão | Enviado se UUID. |
| `contract_number` | Contrato | Enviado se preenchido. |
| `unit_id` | Unidade da admissão | Enviado se preenchido. |
| `document_type_id` | Primeiro tipo cuja descrição contém “boleto” | Somente se ID UUID; não selecionável. |
| `bearer_id` | Primeiro portador com nome contendo “cobrança” ou tipo BANCO | Somente se ID UUID. |
| `seller_id` | Colaborador da admissão | Somente se UUID. |
| `assigned_collaborator_id` | Mesmo colaborador | Somente se UUID. |
| `original_value` | Servidor assume `value` se não fornecido | Valor original inicial. |
| `current_balance` | Servidor assume `value` se não fornecido | Saldo inicial. |

O servidor valida escopo, valor não negativo, enums e referências de cliente/admissão, inclusive compatibilidade dos relacionamentos. A autenticação e a situação da conta também são verificadas nas rotas montadas. IDs, acesso à unidade e relações válidas continuam sujeitos às regras aplicáveis no servidor/banco.

Após sucesso, extrai o ID retornado, registra ação `GERAR_BOLETO_AUDITORIA`, mostra mensagem e acrescenta cartão local com tipo, documento, descrição, valor, vencimento, data/hora, usuário e e-mail. O modal é fechado.

Não cria movimento de conta corrente, não baixa o título e não muda o status da auditoria. Cancelar posteriormente a análise não apaga o título criado.

## 19. Boletos Gerados — consulta e edição de cartões

A consulta por admissão retorna títulos com `admission_id` correspondente e `source = AUDITORIA`, ordenados por emissão decrescente e vencimento decrescente. Não filtra situação. O título “nesta sessão” do modal também pode incluir registros carregados do servidor.

| Campo/ação do cartão/modal | Conteúdo/padrão | Comportamento |
| --- | --- | --- |
| Cabeçalho | Boletos Gerados; contrato e cliente | Contexto da lista. |
| Quantidade | Tamanho da lista local | Inclui títulos recém-criados e consultados. |
| Total | Soma dos valores | Moeda BRL; não usa saldo nem desconta cancelados. |
| Sequência | #1, #2... | Ordem da lista. |
| Tipo | Taxa Administrativa ou Primeira Parcela | Na recarga: documento terminado em -01 significa Primeira Parcela; todos os demais são classificados como Taxa. |
| Valor | `value` | Monetário. |
| Nº Documento | `documentNumber` | Consulta, não editável nesse modal. |
| Vencimento | `dueDate` | Data brasileira ou -. |
| Descrição | `description` | Sem descrição quando vazia. |
| Gerado por | Nome/e-mail do usuário na criação local | Na recarga, usa nome do colaborador da admissão ou Sistema, não comprova o autor real da emissão. |
| E-mail | `generatedByEmail` | Só mostra se não vazio e diferente do nome. Na recarga fica vazio. |
| Data e hora | `generatedAt` | Na recarga usa `created_at` ou momento atual como fallback. |
| Editar vencimento e valor | Ícone de edição | Abre formulário dentro do cartão, não outro modal. |
| Valor em edição | Valor atual com duas casas e vírgula | Texto; exige maior que zero. |
| Vencimento em edição | Data atual do título | Exige preenchimento. |
| Cancelar edição | Botão do cartão | Abandona edição sem PUT. |
| Salvar Alterações | Desabilitado durante gravação | Faz PUT se houver ID do servidor; ao concluir atualiza só o cartão local. Sem ID, o handler interrompe com aviso. |
| Fechar / X | Cabeçalho e rodapé | Fecha o modal. |

O PUT envia `value`, `due_date`, `title_scope: RECEBER` e **`status: ABERTO`**. A ação não é neutra quanto ao status. O painel não recalcula explicitamente valor original/saldo e não consulta baixas antes de abrir a edição; o servidor continua sendo responsável por validações adicionais.

Sem `titleId`, o cartão exibe “A atualização será apenas local”, mas o handler efetivo não faz atualização local: avisa que não foi possível identificar o lançamento no servidor e retorna. O botão não fica bloqueado por essa ausência.

Não existe excluir, cancelar, emitir PDF bancário, baixar título ou liquidar a partir desses cartões. Não há paginação, filtros ou ordenação editável nesse modal.

Os documentos criados pelo comando alternativo Gerar Lançamentos usam -1/-2; ao recarregar aqui, ambos podem ser classificados como Taxa Administrativa pela regra de sufixo -01.

## 20. Gerar Lançamentos — fluxo alternativo

O cartão **Lançamentos Financeiros** aparece quando há `parcela1` ou `parcela2`. Mostra Entrada e/ou 1ª Parcela com valor e documento antes de executar.

| Elemento | Padrão/conteúdo | Regra |
| --- | --- | --- |
| Entrada (Adm.) | `parcela1` | Só cria se valor convertido for maior que zero. |
| Documento da Entrada | Contrato + -1 | Diferente do documento do modal Boleto/Taxa. |
| Descrição da Entrada | Entrada - Contrato #... | Automática. |
| Vencimento da Entrada | Hoje ISO/UTC | Independente do primeiro vencimento. |
| 1ª Parcela | `parcela2` | Só cria se maior que zero. |
| Documento da parcela | Contrato + -2 | Diferente do contrato-01 do modal Boleto. |
| Descrição da parcela | 1ª Parcela - Contrato #... | Automática. |
| Vencimento da parcela | `firstInstallmentDueDate` ou hoje | Sem formulário de revisão. |
| Gerar Lançamentos | Clique → confirmação nativa | Desabilita enquanto cria; mostra Gerando... |

Se os dois valores forem inválidos/não positivos, avisa Sem Dados. A confirmação lista as linhas a criar. Cancelar a confirmação não grava nada.

Envia título RECEBER, ABERTO, PADRAO, origem AUDITORIA, emissão de hoje, cliente, admissão e unidade quando aplicáveis. **Não** envia os padrões de tipo de documento/portador/vendedor do modal Boleto; também não envia `contract_number` nesse caminho.

As duas criações são independentes: sucesso parcial é possível. Retorno informa quantidade e erros; não há rollback do primeiro título quando o segundo falha. No sucesso completo solicita log `GERAR_LANCAMENTOS_AUDITORIA`.

O botão não aplica deduplicação nem verifica a lista `boletosGerados`; pode ser acionado novamente. Após gerar, não atualiza essa lista automaticamente no handler. Mensagem de sucesso não significa baixa, conciliação ou emissão bancária.

## 21. Anexos — quadro original e quadro editável

Há dois quadros distintos na mesma página:

1. **07. Anexos Digitais:** lê `selectedAdmission.attachments`, mostra título/nome e Visualizar Arquivo; sem edição.
2. **Anexos (Contratos, Procurações, Documentos):** usa `auditAttachments`, permite adicionar, visualizar, baixar e remover da lista local.

| Campo/ação | Padrão/conteúdo | Regra/efeito |
| --- | --- | --- |
| Adicionar | Seletor de arquivos múltiplos | `accept`: imagens, PDF, .doc e .docx. |
| ID do anexo | Prefixo att_ + timestamp + aleatório | Gerado localmente. |
| Título | Nome sem a última extensão | Gerado automaticamente, sem editor de título. |
| Nome do arquivo | `file.name` | Preservado para exibição/download. |
| Conteúdo | `FileReader.readAsDataURL` | Armazenado em memória como data URL; não é upload em streaming neste handler. |
| Ícone | Imagem, PDF ou documento genérico | Detecta prefixo MIME e extensão PDF. |
| Visualizar | Nova janela com iframe | Depende do navegador suportar o formato. |
| Baixar | Link com atributo download | Usa nome original e conteúdo local. |
| Remover | Filtra pelo ID | Remove imediatamente da lista local, sem confirmação e sem DELETE de anexo no servidor. |
| Lista vazia | Orientação para Adicionar | Sem documentos locais. |
| Salvar auditoria | Inclui lista no objeto da configuração | Sujeito às limitações de persistência descritas no capítulo de salvamento. |

O atributo accept orienta o seletor; não é validação de conteúdo/antivírus. Não há limite de tamanho explícito, campo categoria, ACL, descrição, versão ou progress bar no handler local. DOC/DOCX podem não renderizar em iframe.

A lista original não muda imediatamente quando a lista editável é modificada. Voltar/Cancelar perde mudanças locais, mas não executa limpeza de upload porque aqui não houve upload próprio. Visualização bloqueada por pop-up gera mensagem de erro no painel principal.

## 22. Histórico Auditoria / Comercial

O bloco 08 aparece quando há rounds, crítica ou resposta. Havendo rounds, estes têm prioridade sobre o fallback de crítica/resposta isoladas.

| Campo | Origem | Exibição |
| --- | --- | --- |
| Número do round | `roundNumber` | Round N. |
| Data/hora da crítica | `critiqueDate` | Formato brasileiro com horário. |
| Autor da crítica | `critiquedBy` | Fallback Auditoria. |
| Crítica | `critique` | Texto integral preservando quebras. |
| Autor da resposta | `respondedBy` | Fallback Comercial. |
| Data/hora da resposta | `responseDate` | Quando informada. |
| Resposta | `response` | Se vazia, Aguardando resposta do Comercial... |
| Crítica legada | `admission.auditCritique` | Usada quando não há rounds. |
| Resposta legada | `admission.auditResponse` | Usada quando não há rounds. |

É um histórico somente leitura. Não há editar/excluir round, responder pelo Comercial ou selecionar autor dentro da Auditoria.

## 23. Modal Ficha de Admissão — Identificação

Exige administrador ou `com_admissao:VISUALIZAR`; em negativa, mostra Acesso negado e não abre. Recebe a admissão, cliente, titular, banco, modalidade, nome do colaborador, sigla da série e nome da unidade resolvidos pelo painel.

Cabeçalho: Ficha de Admissão, cliente, contrato e status. Aba inicial: **Identificação** (`FICHA`). As quatro abas são de consulta. Fechar pelo X ou botão Fechar; não há fechamento por fundo/Escape explicitamente programado no componente.

| Grupo/campos | Conteúdo e padrão | Operações |
| --- | --- | --- |
| Identificação da admissão | Cliente; Nº Contrato; Data Admissão; Status; Tipo Cliente; Série; Colaborador; Indicação; Origem; Unidade quando disponível | R; sem inclusão/edição/exclusão. Campos vazios usam —; tipo cliente usa RESPONSÁVEL. |
| Responsável — documentos | CPF/CNPJ; RG; Data de Nascimento; Estado Civil; Profissão; Tipo | R; seção se cliente foi localizado. |
| Responsável — contato | Telefone; Telefone 2; E-mail | R; ausência formatada como —. |
| Responsável — endereço | Endereço; número; complemento; bairro; cidade; UF; CEP | R; bloco se endereço ou cidade. |
| Responsável — anotações | `client.notes` | R; só se preenchidas. |
| Titular | Nome; CPF/CNPJ; RG; Telefone; E-mail | R; seção se titular foi localizado. Esta versão resumida do titular não repete todos os campos do resumo principal. |
| Veículo | Marca; Modelo; Ano; Placa; Cor; Chassi; Renavam; tag ELÉTRICO | R; seção se marca preenchida; campos individuais só se tiverem valor. Não exige modalidade VEÍCULOS neste modal. |
| Outras informações | Taxa Administração (`otherInfo1`); Primeira Parcela (`otherInfo2`) | R; somente quando presentes. |

Os dados principais não são recarregados integralmente por GET ao abrir essa ficha; vêm do objeto fornecido pelo painel. Documentos e consulta jurídica têm carregamento próprio conforme as abas seguintes.

## 24. Modal Ficha — Contrato / Financeiro

| Grupo/campo | Conteúdo | CRUD/condição |
| --- | --- | --- |
| Banco | Banco recebido do painel | Consulta. |
| Modalidade | Descrição/tipo recebido | Consulta. |
| Tarifa Bancária Inclusa | Flag da admissão | Tag se verdadeiro. |
| Contrato de Terceiro | Flag da admissão | Tag se verdadeiro. |
| Serviços do banco | Serviço; % Negociação; Sobre Valor Financiado | Grade R, mesma ideia de percentual × financiado; sem C/U/D. |
| Valor Financiado | `financedAmount` | Consulta em R$. |
| Valor Parcela Atual | `installmentValue` | Consulta em R$. |
| Total Parcelas | `totalInstallments` | Consulta. |
| Pagas / Em Atraso | `paidInstallments` / `overdueInstallments` | Zero quando ausentes. |
| Dia Vencimento | `dueDay` | Prefixo Dia. |
| Tipo Pagamento | `paymentType` | Consulta. |
| Venc. 1ª Parcela | `firstInstallmentDueDate` | Se preenchido. |
| Taxa Administrativa | `parcela1` | Se preenchida. |
| 1ª Parcela Real | `parcela2` | Se preenchida. |
| Taxa de Cobrança | `taxaCobranca` | Se preenchida. |
| Desconto | `admission.desconto` | Se preenchido. |
| Cenários de Recálculo | Cenário; Dívida Orig.; Nova Dívida; Economia; Parcelas; Vl. Parcela; Dia Venc. | Grade R, se houver cenários. |

Não é um extrato de recebimentos e não recalcula saldos de títulos nem disponibiliza baixa.

## 25. Modal Ficha — Documentos e visualização armazenada

A aba **Documentos (N)** combina a contagem de anexos legados resolvidos com a quantidade informada pelo painel de arquivos armazenados. As fontes são distintas; a soma não é uma deduplicação por conteúdo.

| Elemento/ação | Conteúdo/padrão | Acionamento |
| --- | --- | --- |
| Arquivos armazenados | Cliente da admissão, módulo ADMISSION, alvo ADMISSION e ID da admissão | Componente em `readOnly` e compacto. |
| Nome do arquivo armazenado | `originalFilename` | Consulta. |
| Metadados armazenados | Categoria ou Sem categoria; módulo; tamanho; possível indicação Legado sem ACL | Consulta segundo permissões. |
| Filtrar... | Vazio; espera 300 ms | Pesquisa no servidor, dentro do contexto da admissão. |
| Atualizar | Página atual | Recarrega a listagem. |
| Ver | Só imagens e PDF | Abre nova aba na rota autenticada `/api/client-attachments/:id/content?browser=1`, com conteúdo transmitido pelo servidor. |
| Baixar | Arquivo escolhido | Rota de download autenticada; não gera link público permanente. |
| Paginação armazenada | 25 registros por solicitação | Anterior/Próxima por cursores e contagem. |
| Anexos legados | GET `/api/admissions/:id/attachments` na primeira abertura da aba | Carregamento assíncrono, com tentativa adicional da camada de requisição. |
| Título legado | `title` ou `fileName` | Identificação do arquivo. |
| Nome legado | `file_name` mapeado para `fileName` | Nome para download. |
| Visualizar legado | Ícone do arquivo | Nova janela com iframe. |
| Baixar legado | Botão | Cria link de download com data URL. |
| Miniatura legada | Imagens | Clicar amplia pela mesma visualização. |
| Erro/carregamento/vazio | Mensagens próprias | Há Tentar novamente no carregamento de anexos legados. |

O painel armazenado em leitura **não** mostra upload, seleção em lote, excluir, acesso à pasta/arquivo ou operações administrativas de ACL. A listagem respeita módulo, unidade e autorizações do servidor. “Somente visualização” não dispensa a autorização de download.

Anexos carregados por GET substituem a fonte legada pré-carregada nessa ficha; não são mesclados item a item com o rascunho local da auditoria. Arquivos adicionados localmente ainda não salvos não são automaticamente enviados a esse painel armazenado.

## 26. Modal Ficha — Auditoria e consulta jurídica

| Elemento | Conteúdo | Comportamento |
| --- | --- | --- |
| Consulta jurídica registrada | Objeto `legalScan` recebido, se houver | Exibição pelo componente histórico. |
| Consulta sem objeto prévio | GET `/api/admissions/:id/legal-scan` | Executado ao abrir a aba; consulta ao armazenamento do aplicativo, não a tribunal. |
| Carregamento jurídico | Carregando consulta jurídica... | Aguarda resposta. |
| Sem permissão | HTTP 403 | Mensagem específica. |
| Erro jurídico | Resposta não OK ou falha | Mensagem de erro; não trata como consulta negativa. |
| Sem consulta | Resposta sem objeto | Consulta jurídica não realizada para esta admissão. |
| Rounds de Auditoria (N) | `admission.auditHistory` | Contagem e cartões somente leitura. |
| Campos do round | Número; data; crítica; autor da crítica; resposta; autor/data da resposta | Resposta só aparece se existir. |
| Sem rounds | Nenhum round de auditoria registrado. | Não cria histórico automaticamente. |

A aba não permite executar nova varredura, editar processo, responder crítica, criar round ou excluir histórico. Não usa o fallback de crítica/resposta legadas no lugar dos rounds como o resumo principal faz.

## 27. Histórico de Movimentações — grade de auditoria técnica

Acionado no ícone da linha da fila. Busca `/api/audit-logs?entity_id=ID&limit=500`. O prop `logs` recebido pelo botão não é a fonte usada pelo componente atual; os eventos são consultados no servidor.

| Campo/ação | Padrão/conteúdo | Comportamento |
| --- | --- | --- |
| Título | Histórico de Movimentações | Badge Somente Leitura. |
| Entidade | Nome do cliente | Contexto do modal. |
| Data/hora | `timestamp` | Formatação compartilhada. |
| Usuário | `user_name` | Fallback Sistema. |
| Ação | Evento traduzido | Cor conforme CREATE, UPDATE, DELETE, baixa, cancelamento etc., quando houver esses eventos. |
| Campo | Nome traduzido do campo alterado | Uma linha por alteração. |
| Valor anterior | `oldValue` | Valor traduzido; — se ausente. |
| Indicador de alteração | Seta | Separa anterior/novo. |
| Novo valor | `newValue` | Na ausência de changes, pode usar a descrição do evento. |
| Ordenação | Mais recentes primeiro | Local pelo timestamp. |
| Paginação | 15 linhas por página | Eventos com vários campos geram várias linhas; número de eventos não é número de linhas. |
| Badge do botão | Número de eventos carregados | Máximo visual 99+. |
| Carregamento/vazio | Mensagens de consulta | Falhas são capturadas sem mensagem específica de erro; podem resultar em vazio. |
| X/fundo | Fecha modal | Clique no conteúdo não fecha. |

CRUD: somente R. Não há edição, exclusão, exportação ou criação manual de eventos nessa grade. O limite de 500 significa que não se pode garantir histórico integral ilimitado.

## 28. Integração com o Jurídico e limites do encaminhamento

Concluir a auditoria não faz, no próprio `handleSave`, um POST de processo jurídico. A integração automática identificada está no **painel Jurídico**, em um efeito executado quando esse componente acompanha as admissões/configuração.

| Condição/campo | Conteúdo | Efeito |
| --- | --- | --- |
| Admissão elegível | Status CONCLUIDO | Pré-requisito. |
| Resultado jurídico | `legalScan.found` verdadeiro e `processNumber` preenchido | Usa registro histórico existente. |
| Modalidade | Tipo VEÍCULOS, normalizado em maiúsculas | Outras modalidades não passam nesse sincronismo. |
| Duplicidade | Número do processo ainda não encontrado na lista de processos do painel | Evita nova inclusão segundo a lista disponível; restrição de banco pode também intervir. |
| Cliente/admissão/contrato | IDs e nome relacionados | Enviados ao processo. |
| Número e tribunal | Resultado jurídico salvo | Sem nova busca externa. |
| Tipo jurídico | BUSCA E APREENSÃO | Padrão desse sincronismo. |
| Status jurídico | ALERTA | Padrão inicial. |
| Tags | Importado; Auditoria | Classificação da origem. |
| Notas | Texto de importação da auditoria com data | Automático. |
| Movimento inicial | Última movimentação e autor históricos | Tipo CERTIDAO; origem textual ROBÔ JURÍDICO, que não comprova consulta atual. |

A rota acionada por esse outro painel é POST `/api/legal-processes`. Erros são capturados sem aviso individual no efeito. Não afirmar que toda conclusão cria processo imediatamente, que todo cliente tem processo ou que o envio da mensagem comprova criação jurídica.

## 29. Matriz consolidada de CRUD, integrações e persistência

| Objeto | C — incluir | R — consultar | U — alterar | D — excluir |
| --- | --- | --- | --- | --- |
| Admissão | Não neste painel | Fila, resumo e ficha | Status/crítica por PATCH; espelho de configuração por PUT | Não |
| Checklist preenchido | Estado inicial local | Marcas e instruções | Checkbox local, sem persistência individual no salvar | Reset ao reabrir; não há DELETE |
| Definições do checklist | Outro módulo | Itens ATIVOS | Não aqui | Não aqui |
| Observação Manual | Texto local | Campo local | Sem envio no salvar | Limpar texto local |
| Rounds | Montados localmente ao devolver | Resumo e ficha | Sem editor próprio | Não |
| Título a receber | Boleto ou Gerar Lançamentos | Boletos Gerados | Valor/vencimento; PUT envia ABERTO | Não aqui |
| Anexo local de auditoria | Adicionar arquivo | Visualizar/baixar | Não edita título/conteúdo | Remove do rascunho |
| Anexo armazenado da ficha | Não em readOnly | Filtrar, paginar, ver, baixar | Não | Não |
| Anexo legado da ficha | Não | GET, visualização e download | Não | Não |
| Resultado jurídico | Não faz nova consulta | Histórico salvo | Não | Não |
| Processo jurídico | Condicional no painel Jurídico | Não há grade de processos editável aqui | Não aqui | Não aqui |
| Modelo de formulário | Não | Selecionar e imprimir | Não | Não |
| Evento de log | Solicitado nas ações e pelo servidor | Modal de histórico | Não | Não |
| Mensagem interna | Gatilhos de checklist/conclusão | Sem caixa de mensagens neste painel | Não | Não |

| Integração/rota | Uso no fluxo | Dados relevantes |
| --- | --- | --- |
| `config.admissions` | Fonte da fila | Status, cliente, contrato e relações. |
| `clients` por hook | Resolver responsável/titular | Página configurada de 2000; fallback global se lista vazia. |
| PATCH `/api/admissions/:id/status` | Salvar auditoria UUID | Status e crítica; transação e log no servidor. |
| PUT `/api/settings/section` | Espelho JSON de admissões | Lista completa, admin obrigatório; sem verificação de HTTP OK no painel. |
| GET `/api/financial-titles/by-admission/:id` | Carregar títulos associados | Somente origem AUDITORIA. |
| POST `/api/financial-titles` | Criar títulos | Escopo RECEBER e vínculo da admissão quando UUID. |
| PUT `/api/financial-titles/:id` | Edição de cartão | Valor, vencimento, escopo e status ABERTO. |
| GET `/api/admissions/:id/attachments` | Documentos legados da ficha | Título, nome e conteúdo. |
| GET `/api/client-attachments/` | Arquivos armazenados | Contexto ADMISSION, cliente, alvo, filtro e cursor. |
| GET `/api/client-attachments/:id/content?browser=1` | Visualização de imagem/PDF armazenado | Nova aba autenticada, sem copiar o arquivo inteiro para Blob local. |
| GET `/api/client-attachments/:id/download?browser=1` | Download de armazenado | Acesso autenticado. |
| GET `/api/admissions/:id/legal-scan` | Consulta histórica na ficha | Objeto salvo ou ausência; sem pesquisa externa. |
| GET `/api/audit-logs` | Histórico técnico | ID da entidade, limite 500. |
| Mensagens do layout | Notificar grupos | Texto e metadados do evento. |
| POST `/api/legal-processes` | Sincronismo em outro painel | Somente condições descritas no capítulo jurídico. |

## 30. Permissões, alertas e roteiro de uso

O acesso ao menu depende do sistema de navegação/permissões do aplicativo. O painel usa `currentUser`, `isLoggedAdmin` e `temPermissao`; a checagem explícita de ação encontrada nele é a abertura da ficha. Os demais botões não possuem checagens individuais de permissão no JSX/handlers do painel; isso não dispensa autenticação, autorização e regras no servidor.

As rotas de admissões e títulos são montadas com extração de usuário, autenticação e validação da situação da conta. O PUT de configuração é expressamente administrativo. Não houve teste com perfis reais; não afirmar que um perfil comum conclui todo o fluxo.

Roteiro conforme a implementação:

1. Abrir Atendimento → Auditoria e localizar uma admissão APROVADA.
2. Pesquisar e voltar à página 1 se necessário; conferir contrato/cliente/unidade.
3. Acionar AUDITAR; aguardar a busca de títulos existentes.
4. Ler resumo, cenários, valores, anexos e histórico jurídico salvo.
5. Abrir Ficha se autorizado para consultar suas quatro abas.
6. Marcar os itens aplicáveis; lembrar que o item jurídico dispara mensagens e que as marcas não são persistidas individualmente.
7. Se necessário, selecionar formulário, Visualizar e Imprimir; isso marca o item de procuração, mas não comprova assinatura.
8. Para cobrança, escolher conscientemente entre Boleto (um lançamento revisável) e Gerar Lançamentos (até duas criações diretas), evitando repetições.
9. Incluir/remover anexos locais se necessário, observando que o caminho de salvamento não confirma gravação relacional desses arquivos.
10. Selecionar resultado; informar crítica na devolução; finalizar somente após revisar veículo elétrico, pendências e efeitos de mensagens.
11. Considerar sucesso parcial de requisições: retorno à fila não é garantia de que todos os objetos locais foram persistidos.

**Limitações relevantes reunidas:** filtro exclusivo APROVADA; tamanho 10 fixo; pesquisa sem reset de página; Pendente pode reenviar uma transição inválida; itens invisíveis entram na contagem; checklist/observação não são gravados; configuração exige admin e resposta HTTP não é verificada; notificações podem ocorrer antes de salvar; ausência de emissão bancária; gerações financeiras independentes e potencialmente repetíveis; classificação de boletos por sufixo; autoria recarregada não é necessariamente a real; edição financeira força ABERTO; anexos locais e armazenados não são a mesma fonte; consulta jurídica apenas histórica.

## 31. Fontes, rastreabilidade e arquivos do pacote

Fontes principais inspecionadas:

- `components/atendimento/AuditPanel.tsx`: fila, estado inicial, salvar, checklist, notificações, títulos, anexos, formulários e renderização.
- `components/atendimento/HistoricalLegalScan.tsx`: somente leitura do resultado jurídico salvo.
- `components/ui/AdmissionViewerModal.tsx`: quatro abas da ficha, documentos e consulta histórica.
- `components/ui/AuditLogButton.tsx`: histórico técnico por entidade e paginação.
- `components/ui/Pagination.tsx`: controles de página e seletor compartilhado.
- `components/attachments/ClientAttachmentsPanel.tsx`: listagem contextual de armazenados em modo leitura.
- `hooks/useFormTemplates.ts` e `constants.ts`: vínculo dos modelos ao contexto auditoria.
- `server/routes/admissions.js`: validação de status, transições e rotas de ficha.
- `server/routes/financialTitles.js`: criação/edição e busca por admissão.
- `server/index.js`: montagem das rotas e PUT administrativo de seção.
- `components/juridico/LegalPanel.tsx`: sincronismo condicionado de processo jurídico.
- `components/layout/DashboardLayout.tsx`: montagem do painel e callback de mensagem.

O arquivo `referencias-fontes.csv` registra tamanho e SHA-256 das fontes para identificar a versão examinada, sem copiar código do aplicativo para o pacote.

Conteúdo entregue: manual HTML com sumário e impressão; este Markdown; inventário CSV de campos/ações/regras das tabelas; CSV individual de variáveis dos formulários; referências das fontes; README. Não inclui dados reais, credenciais, código integral do aplicativo ou evidência de teste autenticado.
